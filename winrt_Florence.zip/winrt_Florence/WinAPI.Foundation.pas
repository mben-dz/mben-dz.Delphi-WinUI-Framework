{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Foundation;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  AsyncActionCompletedHandler = Winapi.CommonTypes.AsyncActionCompletedHandler;
  PAsyncActionCompletedHandler = Winapi.CommonTypes.PAsyncActionCompletedHandler;
  AsyncActionProgressHandler_1__UInt64 = Winapi.CommonTypes.AsyncActionProgressHandler_1__UInt64;
  PAsyncActionProgressHandler_1__UInt64 = Winapi.CommonTypes.PAsyncActionProgressHandler_1__UInt64;
  AsyncActionWithProgressCompletedHandler_1__UInt64 = Winapi.CommonTypes.AsyncActionWithProgressCompletedHandler_1__UInt64;
  PAsyncActionWithProgressCompletedHandler_1__UInt64 = Winapi.CommonTypes.PAsyncActionWithProgressCompletedHandler_1__UInt64;
  AsyncOperationCompletedHandler_1__Boolean = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__Boolean;
  PAsyncOperationCompletedHandler_1__Boolean = Winapi.CommonTypes.PAsyncOperationCompletedHandler_1__Boolean;
  AsyncOperationCompletedHandler_1__HSTRING = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__HSTRING;
  PAsyncOperationCompletedHandler_1__HSTRING = Winapi.CommonTypes.PAsyncOperationCompletedHandler_1__HSTRING;
  AsyncOperationCompletedHandler_1__IInspectable = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IInspectable;
  PAsyncOperationCompletedHandler_1__IInspectable = Winapi.CommonTypes.PAsyncOperationCompletedHandler_1__IInspectable;
  AsyncOperationCompletedHandler_1__IUriRuntimeClass = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IUriRuntimeClass;
  AsyncOperationProgressHandler_2__Cardinal__Cardinal = Winapi.CommonTypes.AsyncOperationProgressHandler_2__Cardinal__Cardinal;
  PAsyncOperationProgressHandler_2__Cardinal__Cardinal = Winapi.CommonTypes.PAsyncOperationProgressHandler_2__Cardinal__Cardinal;
  AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal = Winapi.CommonTypes.AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal;
  PAsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal = Winapi.CommonTypes.PAsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal;
  AsyncStatus = Winapi.CommonTypes.AsyncStatus;
  PAsyncStatus = Winapi.CommonTypes.PAsyncStatus;
  DateTime = Winapi.CommonTypes.DateTime;
  PDateTime = Winapi.CommonTypes.PDateTime;
  EventHandler_1__IInspectable = Winapi.CommonTypes.EventHandler_1__IInspectable;
  PEventHandler_1__IInspectable = Winapi.CommonTypes.PEventHandler_1__IInspectable;
  EventRegistrationToken = Winapi.CommonTypes.EventRegistrationToken;
  PEventRegistrationToken = Winapi.CommonTypes.PEventRegistrationToken;
  IAsyncAction = Winapi.CommonTypes.IAsyncAction;
  PIAsyncAction = Winapi.CommonTypes.PIAsyncAction;
  IAsyncActionWithProgress_1__UInt64 = Winapi.CommonTypes.IAsyncActionWithProgress_1__UInt64;
  PIAsyncActionWithProgress_1__UInt64 = Winapi.CommonTypes.PIAsyncActionWithProgress_1__UInt64;
  IAsyncOperation_1__Boolean = Winapi.CommonTypes.IAsyncOperation_1__Boolean;
  PIAsyncOperation_1__Boolean = Winapi.CommonTypes.PIAsyncOperation_1__Boolean;
  IAsyncOperation_1__HSTRING = Winapi.CommonTypes.IAsyncOperation_1__HSTRING;
  PIAsyncOperation_1__HSTRING = Winapi.CommonTypes.PIAsyncOperation_1__HSTRING;
  IAsyncOperation_1__IInspectable = Winapi.CommonTypes.IAsyncOperation_1__IInspectable;
  PIAsyncOperation_1__IInspectable = Winapi.CommonTypes.PIAsyncOperation_1__IInspectable;
  IAsyncOperation_1__IUriRuntimeClass = Winapi.CommonTypes.IAsyncOperation_1__IUriRuntimeClass;
  IAsyncOperationWithProgress_2__Cardinal__Cardinal = Winapi.CommonTypes.IAsyncOperationWithProgress_2__Cardinal__Cardinal;
  PIAsyncOperationWithProgress_2__Cardinal__Cardinal = Winapi.CommonTypes.PIAsyncOperationWithProgress_2__Cardinal__Cardinal;
  IDeferral = Winapi.CommonTypes.IDeferral;
  PIDeferral = Winapi.CommonTypes.PIDeferral;
  IIterable_1__Point = Winapi.CommonTypes.IIterable_1__Point;
  PIIterable_1__Point = Winapi.CommonTypes.PIIterable_1__Point;
  IIterator_1__Point = Winapi.CommonTypes.IIterator_1__Point;
  PIIterator_1__Point = Winapi.CommonTypes.PIIterator_1__Point;
  IReference_1__Byte = Winapi.CommonTypes.IReference_1__Byte;
  PIReference_1__Byte = Winapi.CommonTypes.PIReference_1__Byte;
  IReference_1__Cardinal = Winapi.CommonTypes.IReference_1__Cardinal;
  PIReference_1__Cardinal = Winapi.CommonTypes.PIReference_1__Cardinal;
  IReference_1__DateTime = Winapi.CommonTypes.IReference_1__DateTime;
  PIReference_1__DateTime = Winapi.CommonTypes.PIReference_1__DateTime;
  IReference_1__Double = Winapi.CommonTypes.IReference_1__Double;
  PIReference_1__Double = Winapi.CommonTypes.PIReference_1__Double;
  IReference_1__Integer = Winapi.CommonTypes.IReference_1__Integer;
  PIReference_1__Integer = Winapi.CommonTypes.PIReference_1__Integer;
  IReference_1__Point = Winapi.CommonTypes.IReference_1__Point;
  PIReference_1__Point = Winapi.CommonTypes.PIReference_1__Point;
  IReference_1__Rect = Winapi.CommonTypes.IReference_1__Rect;
  PIReference_1__Rect = Winapi.CommonTypes.PIReference_1__Rect;
  IReference_1__TimeSpan = Winapi.CommonTypes.IReference_1__TimeSpan;
  PIReference_1__TimeSpan = Winapi.CommonTypes.PIReference_1__TimeSpan;
  IReference_1__UInt64 = Winapi.CommonTypes.IReference_1__UInt64;
  PIReference_1__UInt64 = Winapi.CommonTypes.PIReference_1__UInt64;
  IUriRuntimeClass = Winapi.CommonTypes.IUriRuntimeClass;
  PIUriRuntimeClass = Winapi.CommonTypes.PIUriRuntimeClass;
  IWwwFormUrlDecoderRuntimeClass = Winapi.CommonTypes.IWwwFormUrlDecoderRuntimeClass;
  PIWwwFormUrlDecoderRuntimeClass = Winapi.CommonTypes.PIWwwFormUrlDecoderRuntimeClass;
  Numerics_Matrix3x2 = Winapi.CommonTypes.Numerics_Matrix3x2;
  PNumerics_Matrix3x2 = Winapi.CommonTypes.PNumerics_Matrix3x2;
  Numerics_Matrix4x4 = Winapi.CommonTypes.Numerics_Matrix4x4;
  PNumerics_Matrix4x4 = Winapi.CommonTypes.PNumerics_Matrix4x4;
  Numerics_Quaternion = Winapi.CommonTypes.Numerics_Quaternion;
  PNumerics_Quaternion = Winapi.CommonTypes.PNumerics_Quaternion;
  Numerics_Vector2 = Winapi.CommonTypes.Numerics_Vector2;
  PNumerics_Vector2 = Winapi.CommonTypes.PNumerics_Vector2;
  Numerics_Vector3 = Winapi.CommonTypes.Numerics_Vector3;
  PNumerics_Vector3 = Winapi.CommonTypes.PNumerics_Vector3;
  Numerics_Vector4 = Winapi.CommonTypes.Numerics_Vector4;
  PNumerics_Vector4 = Winapi.CommonTypes.PNumerics_Vector4;
  TimeSpan = Winapi.CommonTypes.TimeSpan;
  PTimeSpan = Winapi.CommonTypes.PTimeSpan;

  // Forward declarations for interfaces

  // Windows.Foundation.IClosable
  IClosable = interface;
  PIClosable = ^IClosable;

  // Windows.Foundation.IAsyncInfo
  IAsyncInfo = interface;
  PIAsyncInfo = ^IAsyncInfo;

  // Windows.Foundation.IWwwFormUrlDecoderEntry
  IWwwFormUrlDecoderEntry = interface;
  PIWwwFormUrlDecoderEntry = ^IWwwFormUrlDecoderEntry;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  IIterator_1__IWwwFormUrlDecoderEntry = interface;
  PIIterator_1__IWwwFormUrlDecoderEntry = ^IIterator_1__IWwwFormUrlDecoderEntry;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  IIterable_1__IWwwFormUrlDecoderEntry = interface;
  PIIterable_1__IWwwFormUrlDecoderEntry = ^IIterable_1__IWwwFormUrlDecoderEntry;

  // Windows.Foundation.IPropertyValue
  IPropertyValue = interface;
  PIPropertyValue = ^IPropertyValue;

  // Windows.Foundation.TypedEventHandler`2<Windows.Foundation.IMemoryBufferReference,Object>
  TypedEventHandler_2__IMemoryBufferReference__IInspectable = interface;
  PTypedEventHandler_2__IMemoryBufferReference__IInspectable = ^TypedEventHandler_2__IMemoryBufferReference__IInspectable;

  // Windows.Foundation.IMemoryBufferReference
  IMemoryBufferReference = interface;
  PIMemoryBufferReference = ^IMemoryBufferReference;

  // Windows.Foundation.IMemoryBuffer
  IMemoryBuffer = interface;
  PIMemoryBuffer = ^IMemoryBuffer;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.DateTime>
  IIterator_1__DateTime = interface;
  PIIterator_1__DateTime = ^IIterator_1__DateTime;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.DateTime>
  IIterable_1__DateTime = interface;
  PIIterable_1__DateTime = ^IIterable_1__DateTime;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.DateTime>
  IVectorView_1__DateTime = interface;
  PIVectorView_1__DateTime = ^IVectorView_1__DateTime;

  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.DateTime>
  IVector_1__DateTime = interface;
  PIVector_1__DateTime = ^IVector_1__DateTime;

  // Windows.Foundation.IReference`1<Single>
  IReference_1__Single = interface;
  PIReference_1__Single = ^IReference_1__Single;

  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Vector2>
  IReference_1__Numerics_Vector2 = interface;
  PIReference_1__Numerics_Vector2 = ^IReference_1__Numerics_Vector2;

  // Windows.Foundation.IReference`1<Boolean>
  IReference_1__Boolean = interface;
  PIReference_1__Boolean = ^IReference_1__Boolean;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IReference`1<Windows.Foundation.DateTime>>
  AsyncOperationCompletedHandler_1__IReference_1__DateTime = interface;
  PAsyncOperationCompletedHandler_1__IReference_1__DateTime = ^AsyncOperationCompletedHandler_1__IReference_1__DateTime;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IReference`1<Windows.Foundation.DateTime>>
  IAsyncOperation_1__IReference_1__DateTime = interface;
  PIAsyncOperation_1__IReference_1__DateTime = ^IAsyncOperation_1__IReference_1__DateTime;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>>
  AsyncOperationCompletedHandler_1__IReference_1__TimeSpan = interface;
  PAsyncOperationCompletedHandler_1__IReference_1__TimeSpan = ^AsyncOperationCompletedHandler_1__IReference_1__TimeSpan;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>>
  IAsyncOperation_1__IReference_1__TimeSpan = interface;
  PIAsyncOperation_1__IReference_1__TimeSpan = ^IAsyncOperation_1__IReference_1__TimeSpan;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>>
  IIterator_1__IIterable_1__Point = interface;
  PIIterator_1__IIterable_1__Point = ^IIterator_1__IIterable_1__Point;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>>
  IIterable_1__IIterable_1__Point = interface;
  PIIterable_1__IIterable_1__Point = ^IIterable_1__IIterable_1__Point;

  // Windows.Foundation.TypedEventHandler`2<Object,Object>
  TypedEventHandler_2__IInspectable__IInspectable = interface;
  PTypedEventHandler_2__IInspectable__IInspectable = ^TypedEventHandler_2__IInspectable__IInspectable;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Point>
  IVectorView_1__Point = interface;
  PIVectorView_1__Point = ^IVectorView_1__Point;

  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.Point>
  IVector_1__Point = interface;
  PIVector_1__Point = ^IVector_1__Point;

  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Vector3>
  IReference_1__Numerics_Vector3 = interface;
  PIReference_1__Numerics_Vector3 = ^IReference_1__Numerics_Vector3;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Rect>
  IIterator_1__Rect = interface;
  PIIterator_1__Rect = ^IIterator_1__Rect;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Rect>
  IIterable_1__Rect = interface;
  PIIterable_1__Rect = ^IIterable_1__Rect;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Rect>
  IVectorView_1__Rect = interface;
  PIVectorView_1__Rect = ^IVectorView_1__Rect;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<UInt32>
  AsyncOperationCompletedHandler_1__Cardinal = interface;
  PAsyncOperationCompletedHandler_1__Cardinal = ^AsyncOperationCompletedHandler_1__Cardinal;

  // Windows.Foundation.IAsyncOperation`1<UInt32>
  IAsyncOperation_1__Cardinal = interface;
  PIAsyncOperation_1__Cardinal = ^IAsyncOperation_1__Cardinal;

  // Windows.Foundation.IReference`1<Int16>
  IReference_1__SmallInt = interface;
  PIReference_1__SmallInt = ^IReference_1__SmallInt;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Guid>
  AsyncOperationCompletedHandler_1__TGuid = interface;
  PAsyncOperationCompletedHandler_1__TGuid = ^AsyncOperationCompletedHandler_1__TGuid;

  // Windows.Foundation.IAsyncOperation`1<Guid>
  IAsyncOperation_1__TGuid = interface;
  PIAsyncOperation_1__TGuid = ^IAsyncOperation_1__TGuid;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Int32>
  AsyncOperationCompletedHandler_1__Integer = interface;
  PAsyncOperationCompletedHandler_1__Integer = ^AsyncOperationCompletedHandler_1__Integer;

  // Windows.Foundation.IAsyncOperation`1<Int32>
  IAsyncOperation_1__Integer = interface;
  PIAsyncOperation_1__Integer = ^IAsyncOperation_1__Integer;

  // Windows.Foundation.IGetActivationFactory
  IGetActivationFactory = interface;
  PIGetActivationFactory = ^IGetActivationFactory;

  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Matrix4x4>
  IReference_1__Numerics_Matrix4x4 = interface;
  PIReference_1__Numerics_Matrix4x4 = ^IReference_1__Numerics_Matrix4x4;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IUriRuntimeClass>
  IIterator_1__IUriRuntimeClass = interface;
  PIIterator_1__IUriRuntimeClass = ^IIterator_1__IUriRuntimeClass;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IUriRuntimeClass>
  IIterable_1__IUriRuntimeClass = interface;
  PIIterable_1__IUriRuntimeClass = ^IIterable_1__IUriRuntimeClass;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.IUriRuntimeClass>
  IVectorView_1__IUriRuntimeClass = interface;
  PIVectorView_1__IUriRuntimeClass = ^IVectorView_1__IUriRuntimeClass;

  // Windows.Foundation.IReference`1<Windows.Foundation.Size>
  IReference_1__Size = interface;
  PIReference_1__Size = ^IReference_1__Size;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Size>
  IIterator_1__Size = interface;
  PIIterator_1__Size = ^IIterator_1__Size;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Size>
  IIterable_1__Size = interface;
  PIIterable_1__Size = ^IIterable_1__Size;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Size>
  IVectorView_1__Size = interface;
  PIVectorView_1__Size = ^IVectorView_1__Size;

  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.IUriRuntimeClass>
  IVector_1__IUriRuntimeClass = interface;
  PIVector_1__IUriRuntimeClass = ^IVector_1__IUriRuntimeClass;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.TimeSpan>
  IIterator_1__TimeSpan = interface;
  PIIterator_1__TimeSpan = ^IIterator_1__TimeSpan;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.TimeSpan>
  IIterable_1__TimeSpan = interface;
  PIIterable_1__TimeSpan = ^IIterable_1__TimeSpan;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.TimeSpan>
  IVectorView_1__TimeSpan = interface;
  PIVectorView_1__TimeSpan = ^IVectorView_1__TimeSpan;

  // Windows.Foundation.DeferralCompletedHandler
  DeferralCompletedHandler = interface;
  PDeferralCompletedHandler = ^DeferralCompletedHandler;

  // Windows.Foundation.Diagnostics.ITracingStatusChangedEventArgs
  Diagnostics_ITracingStatusChangedEventArgs = interface;
  PDiagnostics_ITracingStatusChangedEventArgs = ^Diagnostics_ITracingStatusChangedEventArgs;

  // Windows.Foundation.EventHandler`1<Windows.Foundation.Diagnostics.ITracingStatusChangedEventArgs>
  EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs = interface;
  PEventHandler_1__Diagnostics_ITracingStatusChangedEventArgs = ^EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs;

  // Windows.Foundation.Diagnostics.IAsyncCausalityTracerStatics
  Diagnostics_IAsyncCausalityTracerStatics = interface;
  PDiagnostics_IAsyncCausalityTracerStatics = ^Diagnostics_IAsyncCausalityTracerStatics;

  // Windows.Foundation.Diagnostics.IErrorReportingSettings
  Diagnostics_IErrorReportingSettings = interface;
  PDiagnostics_IErrorReportingSettings = ^Diagnostics_IErrorReportingSettings;

  // Windows.Foundation.IDeferralFactory
  IDeferralFactory = interface;
  PIDeferralFactory = ^IDeferralFactory;

  // Windows.Foundation.IMemoryBufferFactory
  IMemoryBufferFactory = interface;
  PIMemoryBufferFactory = ^IMemoryBufferFactory;

  // Windows.Foundation.IPropertyValueStatics
  IPropertyValueStatics = interface;
  PIPropertyValueStatics = ^IPropertyValueStatics;

  // Windows.Foundation.IStringable
  IStringable = interface;
  PIStringable = ^IStringable;

  // Windows.Foundation.IUriEscapeStatics
  IUriEscapeStatics = interface;
  PIUriEscapeStatics = ^IUriEscapeStatics;

  // Windows.Foundation.IUriRuntimeClassFactory
  IUriRuntimeClassFactory = interface;
  PIUriRuntimeClassFactory = ^IUriRuntimeClassFactory;

  // Windows.Foundation.IUriRuntimeClassWithAbsoluteCanonicalUri
  IUriRuntimeClassWithAbsoluteCanonicalUri = interface;
  PIUriRuntimeClassWithAbsoluteCanonicalUri = ^IUriRuntimeClassWithAbsoluteCanonicalUri;

  // Windows.Foundation.IWwwFormUrlDecoderRuntimeClassFactory
  IWwwFormUrlDecoderRuntimeClassFactory = interface;
  PIWwwFormUrlDecoderRuntimeClassFactory = ^IWwwFormUrlDecoderRuntimeClassFactory;

  // Windows.Foundation.Metadata.IApiInformationStatics
  Metadata_IApiInformationStatics = interface;
  PMetadata_IApiInformationStatics = ^Metadata_IApiInformationStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Int64>
  AsyncOperationCompletedHandler_1__Int64 = interface;
  PAsyncOperationCompletedHandler_1__Int64 = ^AsyncOperationCompletedHandler_1__Int64;

  // Windows.Foundation.IAsyncOperation`1<Int64>
  IAsyncOperation_1__Int64 = interface;
  PIAsyncOperation_1__Int64 = ^IAsyncOperation_1__Int64;

  // Windows.Foundation.IReference`1<Int64>
  IReference_1__Int64 = interface;
  PIReference_1__Int64 = ^IReference_1__Int64;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IClosable>
  IIterator_1__IClosable = interface;
  PIIterator_1__IClosable = ^IIterator_1__IClosable;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IClosable>
  IIterable_1__IClosable = interface;
  PIIterable_1__IClosable = ^IIterable_1__IClosable;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.IClosable>
  IVectorView_1__IClosable = interface;
  PIVectorView_1__IClosable = ^IVectorView_1__IClosable;

  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.IClosable>
  IVector_1__IClosable = interface;
  PIVector_1__IClosable = ^IVector_1__IClosable;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Boolean,Double>
  AsyncOperationProgressHandler_2__Boolean__Double = interface;
  PAsyncOperationProgressHandler_2__Boolean__Double = ^AsyncOperationProgressHandler_2__Boolean__Double;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Boolean,Double>
  AsyncOperationWithProgressCompletedHandler_2__Boolean__Double = interface;
  PAsyncOperationWithProgressCompletedHandler_2__Boolean__Double = ^AsyncOperationWithProgressCompletedHandler_2__Boolean__Double;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Boolean,Double>
  IAsyncOperationWithProgress_2__Boolean__Double = interface;
  PIAsyncOperationWithProgress_2__Boolean__Double = ^IAsyncOperationWithProgress_2__Boolean__Double;

  // Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>
  IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface;
  PIKeyValuePair_2__IUriRuntimeClass__HSTRING = ^IKeyValuePair_2__IUriRuntimeClass__HSTRING;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>>
  IIterator_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface;
  PIIterator_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = ^IIterator_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>>
  IIterable_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface;
  PIIterable_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = ^IIterable_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING;

  // Windows.Foundation.Collections.IMapView`2<Windows.Foundation.IUriRuntimeClass,String>
  IMapView_2__IUriRuntimeClass__HSTRING = interface;
  PIMapView_2__IUriRuntimeClass__HSTRING = ^IMapView_2__IUriRuntimeClass__HSTRING;

  // Windows.Foundation.Collections.IMap`2<Windows.Foundation.IUriRuntimeClass,String>
  IMap_2__IUriRuntimeClass__HSTRING = interface;
  PIMap_2__IUriRuntimeClass__HSTRING = ^IMap_2__IUriRuntimeClass__HSTRING;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<UInt64>
  AsyncOperationCompletedHandler_1__UInt64 = interface;
  PAsyncOperationCompletedHandler_1__UInt64 = ^AsyncOperationCompletedHandler_1__UInt64;

  // Windows.Foundation.IAsyncOperation`1<UInt64>
  IAsyncOperation_1__UInt64 = interface;
  PIAsyncOperation_1__UInt64 = ^IAsyncOperation_1__UInt64;

  // Windows.Foundation.AsyncOperationProgressHandler`2<UInt64,UInt64>
  AsyncOperationProgressHandler_2__UInt64__UInt64 = interface;
  PAsyncOperationProgressHandler_2__UInt64__UInt64 = ^AsyncOperationProgressHandler_2__UInt64__UInt64;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<UInt64,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64 = interface;
  PAsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64 = ^AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64;

  // Windows.Foundation.IAsyncOperationWithProgress`2<UInt64,UInt64>
  IAsyncOperationWithProgress_2__UInt64__UInt64 = interface;
  PIAsyncOperationWithProgress_2__UInt64__UInt64 = ^IAsyncOperationWithProgress_2__UInt64__UInt64;

  // Windows.Foundation.AsyncOperationProgressHandler`2<String,UInt64>
  AsyncOperationProgressHandler_2__HSTRING__UInt64 = interface;
  PAsyncOperationProgressHandler_2__HSTRING__UInt64 = ^AsyncOperationProgressHandler_2__HSTRING__UInt64;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<String,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64 = interface;
  PAsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64 = ^AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64;

  // Windows.Foundation.IAsyncOperationWithProgress`2<String,UInt64>
  IAsyncOperationWithProgress_2__HSTRING__UInt64 = interface;
  PIAsyncOperationWithProgress_2__HSTRING__UInt64 = ^IAsyncOperationWithProgress_2__HSTRING__UInt64;

  // Windows.Foundation.AsyncActionProgressHandler`1<Double>
  AsyncActionProgressHandler_1__Double = interface;
  PAsyncActionProgressHandler_1__Double = ^AsyncActionProgressHandler_1__Double;

  // Windows.Foundation.AsyncActionWithProgressCompletedHandler`1<Double>
  AsyncActionWithProgressCompletedHandler_1__Double = interface;
  PAsyncActionWithProgressCompletedHandler_1__Double = ^AsyncActionWithProgressCompletedHandler_1__Double;

  // Windows.Foundation.IAsyncActionWithProgress`1<Double>
  IAsyncActionWithProgress_1__Double = interface;
  PIAsyncActionWithProgress_1__Double = ^IAsyncActionWithProgress_1__Double;

  // Windows.Foundation.IReference`1<Guid>
  IReference_1__TGuid = interface;
  PIReference_1__TGuid = ^IReference_1__TGuid;

  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Quaternion>
  IReference_1__Numerics_Quaternion = interface;
  PIReference_1__Numerics_Quaternion = ^IReference_1__Numerics_Quaternion;

  // Windows.Foundation Enums

  // Windows.Foundation.Diagnostics.CausalityRelation
  Diagnostics_CausalityRelation = (
    AssignDelegate = 0,
    Join = 1,
    Choice = 2,
    Cancel = 3,
    Error = 4
  );
  PDiagnostics_CausalityRelation = ^Diagnostics_CausalityRelation;

  // Windows.Foundation.Diagnostics.CausalitySource
  Diagnostics_CausalitySource = (
    Application = 0,
    &Library = 1,
    System = 2
  );
  PDiagnostics_CausalitySource = ^Diagnostics_CausalitySource;

  // Windows.Foundation.Diagnostics.CausalitySynchronousWork
  Diagnostics_CausalitySynchronousWork = (
    CompletionNotification = 0,
    ProgressNotification = 1,
    Execution = 2
  );
  PDiagnostics_CausalitySynchronousWork = ^Diagnostics_CausalitySynchronousWork;

  // Windows.Foundation.Diagnostics.CausalityTraceLevel
  Diagnostics_CausalityTraceLevel = (
    Required = 0,
    Important = 1,
    Verbose = 2
  );
  PDiagnostics_CausalityTraceLevel = ^Diagnostics_CausalityTraceLevel;

  // Windows.Foundation.Diagnostics.ErrorOptions
  Diagnostics_ErrorOptions = (
    None = 0,
    SuppressExceptions = 1,
    ForceExceptions = 2,
    UseSetErrorInfo = 4,
    SuppressSetErrorInfo = 8
  );
  PDiagnostics_ErrorOptions = ^Diagnostics_ErrorOptions;

  // Windows.Foundation.Diagnostics.LoggingFieldFormat
  Diagnostics_LoggingFieldFormat = (
    Default = 0,
    Hidden = 1,
    &String = 2,
    Boolean = 3,
    Hexadecimal = 4,
    ProcessId = 5,
    ThreadId = 6,
    Port = 7,
    Ipv4Address = 8,
    Ipv6Address = 9,
    SocketAddress = 10,
    Xml = 11,
    Json = 12,
    Win32Error = 13,
    NTStatus = 14,
    HResult = 15,
    FileTime = 16,
    Signed = 17,
    Unsigned = 18
  );
  PDiagnostics_LoggingFieldFormat = ^Diagnostics_LoggingFieldFormat;

  // Windows.Foundation.Diagnostics.LoggingLevel
  Diagnostics_LoggingLevel = (
    Verbose = 0,
    Information = 1,
    Warning = 2,
    Error = 3,
    Critical = 4
  );
  PDiagnostics_LoggingLevel = ^Diagnostics_LoggingLevel;

  // Windows.Foundation.Diagnostics.LoggingOpcode
  Diagnostics_LoggingOpcode = (
    Info = 0,
    Start = 1,
    Stop = 2,
    Reply = 6,
    Resume = 7,
    Suspend = 8,
    Send = 9
  );
  PDiagnostics_LoggingOpcode = ^Diagnostics_LoggingOpcode;

  // Windows.Foundation.Metadata.AttributeTargets
  Metadata_AttributeTargets = (
    All = -1,
    Delegate = 1,
    Enum = 2,
    Event = 4,
    Field = 8,
    &Interface = 16,
    Method = 64,
    Parameter = 128,
    &Property = 256,
    RuntimeClass = 512,
    Struct = 1024,
    InterfaceImpl = 2048,
    ApiContract = 8192
  );
  PMetadata_AttributeTargets = ^Metadata_AttributeTargets;

  // Windows.Foundation.Metadata.CompositionType
  Metadata_CompositionType = (
    &Protected = 1,
    &Public = 2
  );
  PMetadata_CompositionType = ^Metadata_CompositionType;

  // Windows.Foundation.Metadata.DeprecationType
  Metadata_DeprecationType = (
    Deprecate = 0,
    Remove = 1
  );
  PMetadata_DeprecationType = ^Metadata_DeprecationType;

  // Windows.Foundation.Metadata.FeatureStage
  Metadata_FeatureStage = (
    AlwaysDisabled = 0,
    DisabledByDefault = 1,
    EnabledByDefault = 2,
    AlwaysEnabled = 3
  );
  PMetadata_FeatureStage = ^Metadata_FeatureStage;

  // Windows.Foundation.Metadata.GCPressureAmount
  Metadata_GCPressureAmount = (
    Low = 0,
    Medium = 1,
    High = 2
  );
  PMetadata_GCPressureAmount = ^Metadata_GCPressureAmount;

  // Windows.Foundation.Metadata.MarshalingType
  Metadata_MarshalingType = (
    None = 1,
    Agile = 2,
    Standard = 3,
    InvalidMarshaling = 0
  );
  PMetadata_MarshalingType = ^Metadata_MarshalingType;

  // Windows.Foundation.Metadata.Platform
  Metadata_Platform = (
    Windows = 0,
    WindowsPhone = 1
  );
  PMetadata_Platform = ^Metadata_Platform;

  // Windows.Foundation.Metadata.ThreadingModel
  Metadata_ThreadingModel = (
    STA = 1,
    MTA = 2,
    Both = 3,
    InvalidThreading = 0
  );
  PMetadata_ThreadingModel = ^Metadata_ThreadingModel;

  // Windows.Foundation.PropertyType
  PropertyType = (
    Empty = 0,
    UInt8 = 1,
    Int16 = 2,
    UInt16 = 3,
    Int32 = 4,
    UInt32 = 5,
    Int64 = 6,
    UInt64 = 7,
    Single = 8,
    Double = 9,
    Char16 = 10,
    Boolean = 11,
    &String = 12,
    Inspectable = 13,
    DateTime = 14,
    TimeSpan = 15,
    Guid = 16,
    Point = 17,
    Size = 18,
    Rect = 19,
    OtherType = 20,
    UInt8Array = 1025,
    Int16Array = 1026,
    UInt16Array = 1027,
    Int32Array = 1028,
    UInt32Array = 1029,
    Int64Array = 1030,
    UInt64Array = 1031,
    SingleArray = 1032,
    DoubleArray = 1033,
    Char16Array = 1034,
    BooleanArray = 1035,
    StringArray = 1036,
    InspectableArray = 1037,
    DateTimeArray = 1038,
    TimeSpanArray = 1039,
    GuidArray = 1040,
    PointArray = 1041,
    SizeArray = 1042,
    RectArray = 1043,
    OtherTypeArray = 1044
  );
  PPropertyType = ^PropertyType;

  // Windows.Foundation Records

  // Windows.Foundation.FoundationContract
  FoundationContract = record
  end;
  PFoundationContract = ^FoundationContract;

  // Windows.Foundation.Numerics.Plane
  Numerics_Plane = record
    Normal: Numerics_Vector3;
    D: Single;
  end;
  PNumerics_Plane = ^Numerics_Plane;

  // Windows.Foundation.Numerics.Rational
  Numerics_Rational = record
    Numerator: Cardinal;
    Denominator: Cardinal;
  end;
  PNumerics_Rational = ^Numerics_Rational;

  // Windows.Foundation.UniversalApiContract
  UniversalApiContract = record
  end;
  PUniversalApiContract = ^UniversalApiContract;

  // Windows.Foundation Interfaces

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IClosable
  IClosable = interface(IInspectable)
  ['{30D5A829-7FA4-4026-83BB-D75BAE4EA99E}']
    procedure Close; safecall;
  end;

  // Windows.Foundation.IAsyncInfo
  IAsyncInfo = interface(IInspectable)
  ['{00000036-0000-0000-C000-000000000046}']
    function get_Id: Cardinal; safecall;
    function get_Status: AsyncStatus; safecall;
    function get_ErrorCode: HRESULT; safecall;
    procedure Cancel; safecall;
    procedure Close; safecall;
    property ErrorCode: HRESULT read get_ErrorCode;
    property Id: Cardinal read get_Id;
    property Status: AsyncStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IWwwFormUrlDecoderEntry
  IWwwFormUrlDecoderEntry = interface(IInspectable)
  ['{125E7431-F678-4E8E-B670-20A9B06C512D}']
    function get_Name: HSTRING; safecall;
    function get_Value: HSTRING; safecall;
    property Name: HSTRING read get_Name;
    property Value: HSTRING read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.WwwFormUrlDecoderEntry>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  IIterator_1__IWwwFormUrlDecoderEntry = interface(IInspectable)
  ['{C4378382-3475-5AFA-9243-86B8395773E1}']
    function get_Current: IWwwFormUrlDecoderEntry; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIWwwFormUrlDecoderEntry): Cardinal; safecall;
    property Current: IWwwFormUrlDecoderEntry read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.WwwFormUrlDecoderEntry>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  IIterable_1__IWwwFormUrlDecoderEntry = interface(IInspectable)
  ['{E8E08338-7257-51CE-BBDE-DA8949BCB54D}']
    function First: IIterator_1__IWwwFormUrlDecoderEntry; safecall;
  end;

  // Windows.Foundation.IPropertyValue
  IPropertyValue = interface(IInspectable)
  ['{4BD682DD-7554-40E9-9A9B-82654EDE7E62}']
    function get_Type: PropertyType; safecall;
    function get_IsNumericScalar: Boolean; safecall;
    function GetUInt8: Byte; safecall;
    function GetInt16: SmallInt; safecall;
    function GetUInt16: Word; safecall;
    function GetInt32: Integer; safecall;
    function GetUInt32: Cardinal; safecall;
    function GetInt64: Int64; safecall;
    function GetUInt64: UInt64; safecall;
    function GetSingle: Single; safecall;
    function GetDouble: Double; safecall;
    function GetChar16: Char; safecall;
    function GetBoolean: Boolean; safecall;
    function GetString: HSTRING; safecall;
    function GetGuid: TGuid; safecall;
    function GetDateTime: DateTime; safecall;
    function GetTimeSpan: TimeSpan; safecall;
    function GetPoint: TPointF; safecall;
    function GetSize: TSizeF; safecall;
    function GetRect: TRectF; safecall;
    procedure GetUInt8Array(valueSize: Cardinal; value: PByte); safecall;
    procedure GetInt16Array(valueSize: Cardinal; value: PSmallInt); safecall;
    procedure GetUInt16Array(valueSize: Cardinal; value: PWord); safecall;
    procedure GetInt32Array(valueSize: Cardinal; value: PInteger); safecall;
    procedure GetUInt32Array(valueSize: Cardinal; value: PCardinal); safecall;
    procedure GetInt64Array(valueSize: Cardinal; value: PInt64); safecall;
    procedure GetUInt64Array(valueSize: Cardinal; value: PUInt64); safecall;
    procedure GetSingleArray(valueSize: Cardinal; value: PSingle); safecall;
    procedure GetDoubleArray(valueSize: Cardinal; value: PDouble); safecall;
    procedure GetChar16Array(valueSize: Cardinal; value: PChar); safecall;
    procedure GetBooleanArray(valueSize: Cardinal; value: PBoolean); safecall;
    procedure GetStringArray(valueSize: Cardinal; value: PHSTRING); safecall;
    procedure GetInspectableArray(valueSize: Cardinal; value: PIInspectable); safecall;
    procedure GetGuidArray(valueSize: Cardinal; value: PGuid); safecall;
    procedure GetDateTimeArray(valueSize: Cardinal; value: PDateTime); safecall;
    procedure GetTimeSpanArray(valueSize: Cardinal; value: PTimeSpan); safecall;
    procedure GetPointArray(valueSize: Cardinal; value: PPointF); safecall;
    procedure GetSizeArray(valueSize: Cardinal; value: PSizeF); safecall;
    procedure GetRectArray(valueSize: Cardinal; value: PRectF); safecall;
    property IsNumericScalar: Boolean read get_IsNumericScalar;
    property &Type: PropertyType read get_Type;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Foundation.IMemoryBufferReference,Object>
  TypedEventHandler_2__IMemoryBufferReference__IInspectable = interface(IUnknown)
  ['{F4637D4A-0760-5431-BFC0-24EB1D4F6C4F}']
    procedure Invoke(sender: IMemoryBufferReference; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IMemoryBufferReference
  IMemoryBufferReference = interface(IInspectable)
  ['{FBC4DD29-245B-11E4-AF98-689423260CF8}']
    function get_Capacity: Cardinal; safecall;
    function add_Closed(handler: TypedEventHandler_2__IMemoryBufferReference__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Closed(cookie: EventRegistrationToken); safecall;
    property Capacity: Cardinal read get_Capacity;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IMemoryBuffer
  [WinRTClassNameAttribute(SWindows_Foundation_MemoryBuffer)]
  IMemoryBuffer = interface(IInspectable)
  ['{FBC4DD2A-245B-11E4-AF98-689423260CF8}']
    function CreateReference: IMemoryBufferReference; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.DateTime>
  IIterator_1__DateTime = interface(IInspectable)
  ['{F56158DF-8947-5480-96ED-36C1057877EA}']
    function get_Current: DateTime; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDateTime): Cardinal; safecall;
    property Current: DateTime read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.DateTime>
  IIterable_1__DateTime = interface(IInspectable)
  ['{576A207D-977C-5B36-B54D-624EC86C53A3}']
    function First: IIterator_1__DateTime; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.DateTime>
  IVectorView_1__DateTime = interface(IInspectable)
  ['{135A5F72-A818-54A8-B955-DFF2593A3BF5}']
    function GetAt(index: Cardinal): DateTime; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: DateTime; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDateTime): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.DateTime>
  IVector_1__DateTime = interface(IInspectable)
  ['{94390DC5-E442-5870-88B6-007E232F902C}']
    function GetAt(index: Cardinal): DateTime; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__DateTime; safecall;
    function IndexOf(value: DateTime; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: DateTime); safecall;
    procedure InsertAt(index: Cardinal; value: DateTime); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: DateTime); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDateTime): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDateTime); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Single>
  IReference_1__Single = interface(IInspectable)
  ['{719CC2BA-3E76-5DEF-9F1A-38D85A145EA8}']
    function get_Value: Single; safecall;
    property Value: Single read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Vector2>
  IReference_1__Numerics_Vector2 = interface(IInspectable)
  ['{48F6A69E-8465-57AE-9400-9764087F65AD}']
    function get_Value: Numerics_Vector2; safecall;
    property Value: Numerics_Vector2 read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Boolean>
  IReference_1__Boolean = interface(IInspectable)
  ['{3C00FD60-2950-5939-A21A-2D12C5A01B8A}']
    function get_Value: Boolean; safecall;
    property Value: Boolean read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IReference`1<Windows.Foundation.DateTime>>
  AsyncOperationCompletedHandler_1__IReference_1__DateTime = interface(IUnknown)
  ['{C4225D5E-1B7C-571E-9B88-2AB2EEFA8C8F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IReference_1__DateTime; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IReference`1<Windows.Foundation.DateTime>>
  IAsyncOperation_1__IReference_1__DateTime = interface(IInspectable)
  ['{2025B34F-4214-56AB-ABFE-2FBE6595DA9D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IReference_1__DateTime); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IReference_1__DateTime; safecall;
    function GetResults: IReference_1__DateTime; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IReference_1__DateTime read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>>
  AsyncOperationCompletedHandler_1__IReference_1__TimeSpan = interface(IUnknown)
  ['{E137B677-BFEF-54B0-B200-95C5C2902A25}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IReference_1__TimeSpan; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>>
  IAsyncOperation_1__IReference_1__TimeSpan = interface(IInspectable)
  ['{24A901AD-910F-5C0F-B23C-67007577A558}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IReference_1__TimeSpan); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IReference_1__TimeSpan; safecall;
    function GetResults: IReference_1__TimeSpan; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IReference_1__TimeSpan read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>>
  IIterator_1__IIterable_1__Point = interface(IInspectable)
  ['{377F6162-6E4D-574E-BF01-77F4FD021D0E}']
    function get_Current: IIterable_1__Point; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIIterable_1__Point): Cardinal; safecall;
    property Current: IIterable_1__Point read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>>
  IIterable_1__IIterable_1__Point = interface(IInspectable)
  ['{AE44597E-D411-5B7F-BBEC-6A96C94A107A}']
    function First: IIterator_1__IIterable_1__Point; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Object,Object>
  TypedEventHandler_2__IInspectable__IInspectable = interface(IUnknown)
  ['{C7E65CE2-FAD5-5E3B-9C58-186CA8C1DD57}']
    procedure Invoke(sender: IInspectable; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Point>
  IVectorView_1__Point = interface(IInspectable)
  ['{0B7B4C9D-182F-582A-BDDB-42B1AAC30CAD}']
    function GetAt(index: Cardinal): TPointF; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TPointF; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPointF): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.Point>
  [WinRTClassNameAttribute(SMicrosoft_UI_Xaml_Media_PointCollection)]
  IVector_1__Point = interface(IInspectable)
  ['{C0D513A9-EC4A-5A5D-B6D5-B707DEFDB9F7}']
    function GetAt(index: Cardinal): TPointF; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Point; safecall;
    function IndexOf(value: TPointF; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: TPointF); safecall;
    procedure InsertAt(index: Cardinal; value: TPointF); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: TPointF); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPointF): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PPointF); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Vector3>
  IReference_1__Numerics_Vector3 = interface(IInspectable)
  ['{1EE770FF-C954-59CA-A754-6199A9BE282C}']
    function get_Value: Numerics_Vector3; safecall;
    property Value: Numerics_Vector3 read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Rect>
  IIterator_1__Rect = interface(IInspectable)
  ['{3487AA9D-505F-550E-874E-5B6194C618EB}']
    function get_Current: TRectF; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PRectF): Cardinal; safecall;
    property Current: TRectF read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Rect>
  IIterable_1__Rect = interface(IInspectable)
  ['{F7A49934-2BCD-50B0-A10A-750045D95578}']
    function First: IIterator_1__Rect; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Rect>
  IVectorView_1__Rect = interface(IInspectable)
  ['{0B651AD6-9755-5BE5-8918-6BD61EED3795}']
    function GetAt(index: Cardinal): TRectF; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TRectF; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PRectF): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<UInt32>
  AsyncOperationCompletedHandler_1__Cardinal = interface(IUnknown)
  ['{9343B6E7-E3D2-5E4A-AB2D-2BCE4919A6A4}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Cardinal; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<UInt32>
  IAsyncOperation_1__Cardinal = interface(IInspectable)
  ['{EF60385F-BE78-584B-AAEF-7829ADA2B0DE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Cardinal); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Cardinal; safecall;
    function GetResults: Cardinal; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Cardinal read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Int16>
  IReference_1__SmallInt = interface(IInspectable)
  ['{6EC9E41B-6709-5647-9918-A1270110FC4E}']
    function get_Value: SmallInt; safecall;
    property Value: SmallInt read get_Value;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Guid>
  AsyncOperationCompletedHandler_1__TGuid = interface(IUnknown)
  ['{5233899B-BA7E-504F-BB83-CEEBAC62DECF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__TGuid; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Guid>
  IAsyncOperation_1__TGuid = interface(IInspectable)
  ['{6607BC41-294B-5975-9C3F-4B49836D0916}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__TGuid); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__TGuid; safecall;
    function GetResults: TGuid; safecall;
    property Completed: AsyncOperationCompletedHandler_1__TGuid read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Int32>
  AsyncOperationCompletedHandler_1__Integer = interface(IUnknown)
  ['{D60CAE9D-88CB-59F1-8576-3FBA44796BE8}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Integer; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Int32>
  IAsyncOperation_1__Integer = interface(IInspectable)
  ['{968B9665-06ED-5774-8F53-8EDEABD5F7B5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Integer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Integer; safecall;
    function GetResults: Integer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Integer read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IGetActivationFactory
  IGetActivationFactory = interface(IInspectable)
  ['{4EDB8EE2-96DD-49A7-94F7-4607DDAB8E3C}']
    function GetActivationFactory(activatableClassId: HSTRING): IInspectable; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Matrix4x4>
  IReference_1__Numerics_Matrix4x4 = interface(IInspectable)
  ['{A18146A2-ABDA-5958-86A7-48D13EFFA294}']
    function get_Value: Numerics_Matrix4x4; safecall;
    property Value: Numerics_Matrix4x4 read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Uri>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IUriRuntimeClass>
  IIterator_1__IUriRuntimeClass = interface(IInspectable)
  ['{1C157D0F-5EFE-5CEC-BBD6-0C6CE9AF07A5}']
    function get_Current: IUriRuntimeClass; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIUriRuntimeClass): Cardinal; safecall;
    property Current: IUriRuntimeClass read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Uri>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IUriRuntimeClass>
  IIterable_1__IUriRuntimeClass = interface(IInspectable)
  ['{B0D63B78-78AD-5E31-B6D8-E32A0E16C447}']
    function First: IIterator_1__IUriRuntimeClass; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.IUriRuntimeClass>
  IVectorView_1__IUriRuntimeClass = interface(IInspectable)
  ['{D38FF558-9620-5253-B2C2-7B2F4B27AF6F}']
    function GetAt(index: Cardinal): IUriRuntimeClass; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IUriRuntimeClass; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIUriRuntimeClass): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Windows.Foundation.Size>
  IReference_1__Size = interface(IInspectable)
  ['{61723086-8E53-5276-9F36-2A4BB93E2B75}']
    function get_Value: TSizeF; safecall;
    property Value: TSizeF read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Size>
  IIterator_1__Size = interface(IInspectable)
  ['{A3508EE0-3527-5144-894D-422EADEF43D7}']
    function get_Current: TSizeF; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSizeF): Cardinal; safecall;
    property Current: TSizeF read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Size>
  IIterable_1__Size = interface(IInspectable)
  ['{C9DF55C3-4D41-5E90-BA76-E89ED564446B}']
    function First: IIterator_1__Size; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Size>
  IVectorView_1__Size = interface(IInspectable)
  ['{CB5037FD-660B-51F5-9D28-87F40878268D}']
    function GetAt(index: Cardinal): TSizeF; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TSizeF; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSizeF): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.Uri>
  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.IUriRuntimeClass>
  IVector_1__IUriRuntimeClass = interface(IInspectable)
  ['{0D82BD8D-FE62-5D67-A7B9-7886DD75BC4E}']
    function GetAt(index: Cardinal): IUriRuntimeClass; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IUriRuntimeClass; safecall;
    function IndexOf(value: IUriRuntimeClass; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IUriRuntimeClass); safecall;
    procedure InsertAt(index: Cardinal; value: IUriRuntimeClass); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IUriRuntimeClass); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIUriRuntimeClass): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIUriRuntimeClass); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.TimeSpan>
  IIterator_1__TimeSpan = interface(IInspectable)
  ['{67E9EADB-324B-5661-A405-DED8445B1EEA}']
    function get_Current: TimeSpan; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PTimeSpan): Cardinal; safecall;
    property Current: TimeSpan read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.TimeSpan>
  IIterable_1__TimeSpan = interface(IInspectable)
  ['{E9F78726-829A-5F67-8D19-95EF154B7742}']
    function First: IIterator_1__TimeSpan; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.TimeSpan>
  IVectorView_1__TimeSpan = interface(IInspectable)
  ['{6B5828D7-6B8D-58C4-BA3A-9F796710F53C}']
    function GetAt(index: Cardinal): TimeSpan; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TimeSpan; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PTimeSpan): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.DeferralCompletedHandler
  DeferralCompletedHandler = interface(IUnknown)
  ['{ED32A372-F3C8-4FAA-9CFB-470148DA3888}']
    procedure Invoke; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Diagnostics.ITracingStatusChangedEventArgs
  Diagnostics_ITracingStatusChangedEventArgs = interface(IInspectable)
  ['{410B7711-FF3B-477F-9C9A-D2EFDA302DC3}']
    function get_Enabled: Boolean; safecall;
    function get_TraceLevel: Diagnostics_CausalityTraceLevel; safecall;
    property Enabled: Boolean read get_Enabled;
    property TraceLevel: Diagnostics_CausalityTraceLevel read get_TraceLevel;
  end;

  // UsedAPI Interface
  // Windows.Foundation.EventHandler`1<Windows.Foundation.Diagnostics.TracingStatusChangedEventArgs>
  // Windows.Foundation.EventHandler`1<Windows.Foundation.Diagnostics.ITracingStatusChangedEventArgs>
  EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs = interface(IUnknown)
  ['{2BF27008-2EB4-5675-B1CD-E9906CC5CE64}']
    procedure Invoke(sender: IInspectable; args: Diagnostics_ITracingStatusChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Diagnostics.IAsyncCausalityTracerStatics
  [WinRTClassNameAttribute(SWindows_Foundation_Diagnostics_AsyncCausalityTracer)]
  Diagnostics_IAsyncCausalityTracerStatics = interface(IInspectable)
  ['{50850B26-267E-451B-A890-AB6A370245EE}']
    procedure TraceOperationCreation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; operationName: HSTRING; relatedContext: UInt64); safecall;
    procedure TraceOperationCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; status: AsyncStatus); safecall;
    procedure TraceOperationRelation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; relation: Diagnostics_CausalityRelation); safecall;
    procedure TraceSynchronousWorkStart(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; work: Diagnostics_CausalitySynchronousWork); safecall;
    procedure TraceSynchronousWorkCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; work: Diagnostics_CausalitySynchronousWork); safecall;
    function add_TracingStatusChanged(handler: EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TracingStatusChanged(cookie: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Diagnostics.IErrorReportingSettings
  [WinRTClassNameAttribute(SWindows_Foundation_Diagnostics_RuntimeBrokerErrorSettings)]
  Diagnostics_IErrorReportingSettings = interface(IInspectable)
  ['{16369792-B03E-4BA1-8BB8-D28F4AB4D2C0}']
    procedure SetErrorOptions(value: Diagnostics_ErrorOptions); safecall;
    function GetErrorOptions: Diagnostics_ErrorOptions; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IDeferralFactory
  [WinRTClassNameAttribute(SWindows_Foundation_Deferral)]
  IDeferralFactory = interface(IInspectable)
  ['{65A1ECC5-3FB5-4832-8CA9-F061B281D13A}']
    function Create(handler: DeferralCompletedHandler): IDeferral; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IMemoryBufferFactory
  [WinRTClassNameAttribute(SWindows_Foundation_MemoryBuffer)]
  IMemoryBufferFactory = interface(IInspectable)
  ['{FBC4DD2B-245B-11E4-AF98-689423260CF8}']
    function Create(capacity: Cardinal): IMemoryBuffer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IPropertyValueStatics
  [WinRTClassNameAttribute(SWindows_Foundation_PropertyValue)]
  IPropertyValueStatics = interface(IInspectable)
  ['{629BDBC8-D932-4FF4-96B9-8D96C5C1E858}']
    function CreateEmpty: IInspectable; safecall;
    function CreateUInt8(value: Byte): IInspectable; safecall;
    function CreateInt16(value: SmallInt): IInspectable; safecall;
    function CreateUInt16(value: Word): IInspectable; safecall;
    function CreateInt32(value: Integer): IInspectable; safecall;
    function CreateUInt32(value: Cardinal): IInspectable; safecall;
    function CreateInt64(value: Int64): IInspectable; safecall;
    function CreateUInt64(value: UInt64): IInspectable; safecall;
    function CreateSingle(value: Single): IInspectable; safecall;
    function CreateDouble(value: Double): IInspectable; safecall;
    function CreateChar16(value: Char): IInspectable; safecall;
    function CreateBoolean(value: Boolean): IInspectable; safecall;
    function CreateString(value: HSTRING): IInspectable; safecall;
    function CreateInspectable(value: IInspectable): IInspectable; safecall;
    function CreateGuid(value: TGuid): IInspectable; safecall;
    function CreateDateTime(value: DateTime): IInspectable; safecall;
    function CreateTimeSpan(value: TimeSpan): IInspectable; safecall;
    function CreatePoint(value: TPointF): IInspectable; safecall;
    function CreateSize(value: TSizeF): IInspectable; safecall;
    function CreateRect(value: TRectF): IInspectable; safecall;
    function CreateUInt8Array(valueSize: Cardinal; value: PByte): IInspectable; safecall;
    function CreateInt16Array(valueSize: Cardinal; value: PSmallInt): IInspectable; safecall;
    function CreateUInt16Array(valueSize: Cardinal; value: PWord): IInspectable; safecall;
    function CreateInt32Array(valueSize: Cardinal; value: PInteger): IInspectable; safecall;
    function CreateUInt32Array(valueSize: Cardinal; value: PCardinal): IInspectable; safecall;
    function CreateInt64Array(valueSize: Cardinal; value: PInt64): IInspectable; safecall;
    function CreateUInt64Array(valueSize: Cardinal; value: PUInt64): IInspectable; safecall;
    function CreateSingleArray(valueSize: Cardinal; value: PSingle): IInspectable; safecall;
    function CreateDoubleArray(valueSize: Cardinal; value: PDouble): IInspectable; safecall;
    function CreateChar16Array(valueSize: Cardinal; value: PChar): IInspectable; safecall;
    function CreateBooleanArray(valueSize: Cardinal; value: PBoolean): IInspectable; safecall;
    function CreateStringArray(valueSize: Cardinal; value: PHSTRING): IInspectable; safecall;
    function CreateInspectableArray(valueSize: Cardinal; value: PIInspectable): IInspectable; safecall;
    function CreateGuidArray(valueSize: Cardinal; value: PGuid): IInspectable; safecall;
    function CreateDateTimeArray(valueSize: Cardinal; value: PDateTime): IInspectable; safecall;
    function CreateTimeSpanArray(valueSize: Cardinal; value: PTimeSpan): IInspectable; safecall;
    function CreatePointArray(valueSize: Cardinal; value: PPointF): IInspectable; safecall;
    function CreateSizeArray(valueSize: Cardinal; value: PSizeF): IInspectable; safecall;
    function CreateRectArray(valueSize: Cardinal; value: PRectF): IInspectable; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IStringable
  IStringable = interface(IInspectable)
  ['{96369F54-8EB6-48F0-ABCE-C1B211E627C3}']
    function ToString: HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IUriEscapeStatics
  [WinRTClassNameAttribute(SWindows_Foundation_Uri)]
  IUriEscapeStatics = interface(IInspectable)
  ['{C1D432BA-C824-4452-A7FD-512BC3BBE9A1}']
    function UnescapeComponent(toUnescape: HSTRING): HSTRING; safecall;
    function EscapeComponent(toEscape: HSTRING): HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IUriRuntimeClassFactory
  [WinRTClassNameAttribute(SWindows_Foundation_Uri)]
  IUriRuntimeClassFactory = interface(IInspectable)
  ['{44A9796F-723E-4FDF-A218-033E75B0C084}']
    function CreateUri(uri: HSTRING): IUriRuntimeClass; safecall;
    function CreateWithRelativeUri(baseUri: HSTRING; relativeUri: HSTRING): IUriRuntimeClass; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IUriRuntimeClassWithAbsoluteCanonicalUri
  IUriRuntimeClassWithAbsoluteCanonicalUri = interface(IInspectable)
  ['{758D9661-221C-480F-A339-50656673F46F}']
    function get_AbsoluteCanonicalUri: HSTRING; safecall;
    function get_DisplayIri: HSTRING; safecall;
    property AbsoluteCanonicalUri: HSTRING read get_AbsoluteCanonicalUri;
    property DisplayIri: HSTRING read get_DisplayIri;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.IWwwFormUrlDecoderRuntimeClassFactory
  [WinRTClassNameAttribute(SWindows_Foundation_WwwFormUrlDecoder)]
  IWwwFormUrlDecoderRuntimeClassFactory = interface(IInspectable)
  ['{5B8C6B3D-24AE-41B5-A1BF-F0C3D544845B}']
    function CreateWwwFormUrlDecoder(query: HSTRING): IWwwFormUrlDecoderRuntimeClass; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Metadata.IApiInformationStatics
  [WinRTClassNameAttribute(SWindows_Foundation_Metadata_ApiInformation)]
  Metadata_IApiInformationStatics = interface(IInspectable)
  ['{997439FE-F681-4A11-B416-C13A47E8BA36}']
    function IsTypePresent(typeName: HSTRING): Boolean; safecall;
    function IsMethodPresent(typeName: HSTRING; methodName: HSTRING): Boolean; overload; safecall;
    function IsMethodPresent(typeName: HSTRING; methodName: HSTRING; inputParameterCount: Cardinal): Boolean; overload; safecall;
    function IsEventPresent(typeName: HSTRING; eventName: HSTRING): Boolean; safecall;
    function IsPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; safecall;
    function IsReadOnlyPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; safecall;
    function IsWriteablePropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; safecall;
    function IsEnumNamedValuePresent(enumTypeName: HSTRING; valueName: HSTRING): Boolean; safecall;
    function IsApiContractPresent(contractName: HSTRING; majorVersion: Word): Boolean; overload; safecall;
    function IsApiContractPresent(contractName: HSTRING; majorVersion: Word; minorVersion: Word): Boolean; overload; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Int64>
  AsyncOperationCompletedHandler_1__Int64 = interface(IUnknown)
  ['{D3EF5872-7D4E-59BB-95ED-79FE0F0DBE89}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Int64; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Int64>
  IAsyncOperation_1__Int64 = interface(IInspectable)
  ['{CC468085-4BEF-5584-907C-9223D2679019}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Int64); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Int64; safecall;
    function GetResults: Int64; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Int64 read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Int64>
  IReference_1__Int64 = interface(IInspectable)
  ['{4DDA9E24-E69F-5C6A-A0A6-93427365AF2A}']
    function get_Value: Int64; safecall;
    property Value: Int64 read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ProximitySensorDisplayOnOffController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.IClosable>
  IIterator_1__IClosable = interface(IInspectable)
  ['{F57B3F9E-CF38-562C-86A8-397C67E9813B}']
    function get_Current: IClosable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIClosable): Cardinal; safecall;
    property Current: IClosable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ProximitySensorDisplayOnOffController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IClosable>
  IIterable_1__IClosable = interface(IInspectable)
  ['{1A701151-AD86-5AA8-B3ED-A9461871346D}']
    function First: IIterator_1__IClosable; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.IClosable>
  IVectorView_1__IClosable = interface(IInspectable)
  ['{26DEBA5E-F73B-5181-94DB-2FCBC1DBAF8F}']
    function GetAt(index: Cardinal): IClosable; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IClosable; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIClosable): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Sensors.ProximitySensorDisplayOnOffController>
  // Windows.Foundation.Collections.IVector`1<Windows.Foundation.IClosable>
  IVector_1__IClosable = interface(IInspectable)
  ['{659154C2-5480-5D09-A4B1-6B4B5D873C20}']
    function GetAt(index: Cardinal): IClosable; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IClosable; safecall;
    function IndexOf(value: IClosable; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IClosable); safecall;
    procedure InsertAt(index: Cardinal; value: IClosable); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IClosable); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIClosable): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIClosable); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Boolean,Double>
  AsyncOperationProgressHandler_2__Boolean__Double = interface(IUnknown)
  ['{CADF3784-1200-5633-8280-163849914AB3}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Boolean__Double; progressInfo: Double); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Boolean,Double>
  AsyncOperationWithProgressCompletedHandler_2__Boolean__Double = interface(IUnknown)
  ['{0EC5345B-B37A-5CD5-83D7-9590CDF445B5}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Boolean__Double; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Boolean,Double>
  IAsyncOperationWithProgress_2__Boolean__Double = interface(IInspectable)
  ['{AF873C66-2DF0-5A95-AB54-25634DA3FFA9}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__Boolean__Double); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__Boolean__Double; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__Boolean__Double); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__Boolean__Double; safecall;
    function GetResults: Boolean; safecall;
    property Progress: AsyncOperationProgressHandler_2__Boolean__Double read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__Boolean__Double read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>
  IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface(IInspectable)
  ['{0890DBDF-7DDE-5E36-AC91-DA629DE2443C}']
    function get_Key: IUriRuntimeClass; safecall;
    function get_Value: HSTRING; safecall;
    property Key: IUriRuntimeClass read get_Key;
    property Value: HSTRING read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.Uri,String>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>>
  IIterator_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface(IInspectable)
  ['{0C11A982-9F05-557F-B3E8-3737B26830D1}']
    function get_Current: IKeyValuePair_2__IUriRuntimeClass__HSTRING; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__IUriRuntimeClass__HSTRING): Cardinal; safecall;
    property Current: IKeyValuePair_2__IUriRuntimeClass__HSTRING read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.Uri,String>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Foundation.IUriRuntimeClass,String>>
  IIterable_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING = interface(IInspectable)
  ['{52129C53-B03D-59B3-A27E-B0385643E9FE}']
    function First: IIterator_1__IKeyValuePair_2__IUriRuntimeClass__HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<Windows.Foundation.Uri,String>
  // Windows.Foundation.Collections.IMapView`2<Windows.Foundation.IUriRuntimeClass,String>
  IMapView_2__IUriRuntimeClass__HSTRING = interface(IInspectable)
  ['{87530605-8BD4-5F0A-85F1-751E8BD20446}']
    function Lookup(key: IUriRuntimeClass): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: IUriRuntimeClass): Boolean; safecall;
    procedure Split(out first: IMapView_2__IUriRuntimeClass__HSTRING; out second: IMapView_2__IUriRuntimeClass__HSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMap`2<Windows.Foundation.IUriRuntimeClass,String>
  IMap_2__IUriRuntimeClass__HSTRING = interface(IInspectable)
  ['{C158E559-50FF-5A5C-BFCB-81B84DEF38FD}']
    function Lookup(key: IUriRuntimeClass): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: IUriRuntimeClass): Boolean; safecall;
    function GetView: IMapView_2__IUriRuntimeClass__HSTRING; safecall;
    function Insert(key: IUriRuntimeClass; value: HSTRING): Boolean; safecall;
    procedure Remove(key: IUriRuntimeClass); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<UInt64>
  AsyncOperationCompletedHandler_1__UInt64 = interface(IUnknown)
  ['{EE8AEB02-FB00-51FA-8F57-32583EA241F9}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<UInt64>
  IAsyncOperation_1__UInt64 = interface(IInspectable)
  ['{2A70D630-0767-5F0A-A1C2-DEB08126E26E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__UInt64); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__UInt64; safecall;
    function GetResults: UInt64; safecall;
    property Completed: AsyncOperationCompletedHandler_1__UInt64 read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<UInt64,UInt64>
  AsyncOperationProgressHandler_2__UInt64__UInt64 = interface(IUnknown)
  ['{FFB2B65D-4120-5D13-826D-107851E6BB1C}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__UInt64__UInt64; progressInfo: UInt64); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<UInt64,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64 = interface(IUnknown)
  ['{D2024E41-5500-5B5A-BA46-CB7009596A2F}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__UInt64__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<UInt64,UInt64>
  IAsyncOperationWithProgress_2__UInt64__UInt64 = interface(IInspectable)
  ['{8F1DB6E3-6556-5516-825C-1021EE27CD0C}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__UInt64__UInt64); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__UInt64__UInt64; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64; safecall;
    function GetResults: UInt64; safecall;
    property Progress: AsyncOperationProgressHandler_2__UInt64__UInt64 read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__UInt64__UInt64 read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<String,UInt64>
  AsyncOperationProgressHandler_2__HSTRING__UInt64 = interface(IUnknown)
  ['{14DA7DE7-40DF-5D4C-823F-CF310625AD39}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__HSTRING__UInt64; progressInfo: UInt64); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<String,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64 = interface(IUnknown)
  ['{BD75EEBE-E7B5-5AF6-8415-A4B9C9045202}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__HSTRING__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<String,UInt64>
  IAsyncOperationWithProgress_2__HSTRING__UInt64 = interface(IInspectable)
  ['{C8BBCB29-6B64-5CE2-A831-038F6E02199E}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__HSTRING__UInt64); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__HSTRING__UInt64; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64; safecall;
    function GetResults: HSTRING; safecall;
    property Progress: AsyncOperationProgressHandler_2__HSTRING__UInt64 read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__HSTRING__UInt64 read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncActionProgressHandler`1<Double>
  AsyncActionProgressHandler_1__Double = interface(IUnknown)
  ['{44825C7C-0DA9-5691-B2B4-914F231EECED}']
    procedure Invoke(asyncInfo: IAsyncActionWithProgress_1__Double; progressInfo: Double); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncActionWithProgressCompletedHandler`1<Double>
  AsyncActionWithProgressCompletedHandler_1__Double = interface(IUnknown)
  ['{94D64AC6-4491-53EF-8BE8-36481F3FF1E8}']
    procedure Invoke(asyncInfo: IAsyncActionWithProgress_1__Double; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncActionWithProgress`1<Double>
  IAsyncActionWithProgress_1__Double = interface(IInspectable)
  ['{4F1430A6-A825-56CA-B047-1A9BAD52BA67}']
    procedure put_Progress(handler: AsyncActionProgressHandler_1__Double); safecall;
    function get_Progress: AsyncActionProgressHandler_1__Double; safecall;
    procedure put_Completed(handler: AsyncActionWithProgressCompletedHandler_1__Double); safecall;
    function get_Completed: AsyncActionWithProgressCompletedHandler_1__Double; safecall;
    procedure GetResults; safecall;
    property Progress: AsyncActionProgressHandler_1__Double read get_Progress write put_Progress;
    property Completed: AsyncActionWithProgressCompletedHandler_1__Double read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Guid>
  IReference_1__TGuid = interface(IInspectable)
  ['{7D50F649-632C-51F9-849A-EE49428933EA}']
    function get_Value: TGuid; safecall;
    property Value: TGuid read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.Foundation.Numerics.Quaternion>
  IReference_1__Numerics_Quaternion = interface(IInspectable)
  ['{B27004BB-C014-5DCE-9A21-799C5A3C1461}']
    function get_Value: Numerics_Quaternion; safecall;
    property Value: Numerics_Quaternion read get_Value;
  end;

  // Windows.Foundation.Deferral
  // DualAPI
  // Implements: Windows.Foundation.IDeferral
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Foundation.IDeferralFactory"
  TDeferral = class(TWinRTGenericImportF<IDeferralFactory>)
  public
    {$REGION 'IDeferralFactory'}
    class function Create(handler: DeferralCompletedHandler): IDeferral; static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.Diagnostics.AsyncCausalityTracer
  // DualAPI
  // Statics: "Windows.Foundation.Diagnostics.IAsyncCausalityTracerStatics"
  TDiagnostics_AsyncCausalityTracer = class(TWinRTGenericImportS<Diagnostics_IAsyncCausalityTracerStatics>)
  public
    {$REGION 'Diagnostics_IAsyncCausalityTracerStatics'}
    class procedure TraceOperationCreation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; operationName: HSTRING; relatedContext: UInt64); static; inline;
    class procedure TraceOperationCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; status: AsyncStatus); static; inline;
    class procedure TraceOperationRelation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; relation: Diagnostics_CausalityRelation); static; inline;
    class procedure TraceSynchronousWorkStart(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; work: Diagnostics_CausalitySynchronousWork); static; inline;
    class procedure TraceSynchronousWorkCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; work: Diagnostics_CausalitySynchronousWork); static; inline;
    class function add_TracingStatusChanged(handler: EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs): EventRegistrationToken; static; inline;
    class procedure remove_TracingStatusChanged(cookie: EventRegistrationToken); static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.Diagnostics.RuntimeBrokerErrorSettings
  // DualAPI
  // Implements: Windows.Foundation.Diagnostics.IErrorReportingSettings
  // Instantiable: "Diagnostics_IErrorReportingSettings"
  TDiagnostics_RuntimeBrokerErrorSettings = class(TWinRTGenericImportI<Diagnostics_IErrorReportingSettings>) end;

  // Windows.Foundation.MemoryBuffer
  // DualAPI
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Foundation.IMemoryBufferFactory"
  TMemoryBuffer = class(TWinRTGenericImportF<IMemoryBufferFactory>)
  public
    {$REGION 'IMemoryBufferFactory'}
    class function Create(capacity: Cardinal): IMemoryBuffer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.Metadata.ApiInformation
  // DualAPI
  // Statics: "Windows.Foundation.Metadata.IApiInformationStatics"
  TMetadata_ApiInformation = class(TWinRTGenericImportS<Metadata_IApiInformationStatics>)
  public
    {$REGION 'Metadata_IApiInformationStatics'}
    class function IsTypePresent(typeName: HSTRING): Boolean; static; inline;
    class function IsMethodPresent(typeName: HSTRING; methodName: HSTRING): Boolean; overload; static; inline;
    class function IsMethodPresent(typeName: HSTRING; methodName: HSTRING; inputParameterCount: Cardinal): Boolean; overload; static; inline;
    class function IsEventPresent(typeName: HSTRING; eventName: HSTRING): Boolean; static; inline;
    class function IsPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; static; inline;
    class function IsReadOnlyPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; static; inline;
    class function IsWriteablePropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean; static; inline;
    class function IsEnumNamedValuePresent(enumTypeName: HSTRING; valueName: HSTRING): Boolean; static; inline;
    class function IsApiContractPresent(contractName: HSTRING; majorVersion: Word): Boolean; overload; static; inline;
    class function IsApiContractPresent(contractName: HSTRING; majorVersion: Word; minorVersion: Word): Boolean; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.PropertyValue
  // DualAPI
  // Statics: "Windows.Foundation.IPropertyValueStatics"
  TPropertyValue = class(TWinRTGenericImportS<IPropertyValueStatics>)
  public
    {$REGION 'IPropertyValueStatics'}
    class function CreateEmpty: IInspectable; static; inline;
    class function CreateUInt8(value: Byte): IInspectable; static; inline;
    class function CreateInt16(value: SmallInt): IInspectable; static; inline;
    class function CreateUInt16(value: Word): IInspectable; static; inline;
    class function CreateInt32(value: Integer): IInspectable; static; inline;
    class function CreateUInt32(value: Cardinal): IInspectable; static; inline;
    class function CreateInt64(value: Int64): IInspectable; static; inline;
    class function CreateUInt64(value: UInt64): IInspectable; static; inline;
    class function CreateSingle(value: Single): IInspectable; static; inline;
    class function CreateDouble(value: Double): IInspectable; static; inline;
    class function CreateChar16(value: Char): IInspectable; static; inline;
    class function CreateBoolean(value: Boolean): IInspectable; static; inline;
    class function CreateString(value: HSTRING): IInspectable; static; inline;
    class function CreateInspectable(value: IInspectable): IInspectable; static; inline;
    class function CreateGuid(value: TGuid): IInspectable; static; inline;
    class function CreateDateTime(value: DateTime): IInspectable; static; inline;
    class function CreateTimeSpan(value: TimeSpan): IInspectable; static; inline;
    class function CreatePoint(value: TPointF): IInspectable; static; inline;
    class function CreateSize(value: TSizeF): IInspectable; static; inline;
    class function CreateRect(value: TRectF): IInspectable; static; inline;
    class function CreateUInt8Array(valueSize: Cardinal; value: PByte): IInspectable; static; inline;
    class function CreateInt16Array(valueSize: Cardinal; value: PSmallInt): IInspectable; static; inline;
    class function CreateUInt16Array(valueSize: Cardinal; value: PWord): IInspectable; static; inline;
    class function CreateInt32Array(valueSize: Cardinal; value: PInteger): IInspectable; static; inline;
    class function CreateUInt32Array(valueSize: Cardinal; value: PCardinal): IInspectable; static; inline;
    class function CreateInt64Array(valueSize: Cardinal; value: PInt64): IInspectable; static; inline;
    class function CreateUInt64Array(valueSize: Cardinal; value: PUInt64): IInspectable; static; inline;
    class function CreateSingleArray(valueSize: Cardinal; value: PSingle): IInspectable; static; inline;
    class function CreateDoubleArray(valueSize: Cardinal; value: PDouble): IInspectable; static; inline;
    class function CreateChar16Array(valueSize: Cardinal; value: PChar): IInspectable; static; inline;
    class function CreateBooleanArray(valueSize: Cardinal; value: PBoolean): IInspectable; static; inline;
    class function CreateStringArray(valueSize: Cardinal; value: PHSTRING): IInspectable; static; inline;
    class function CreateInspectableArray(valueSize: Cardinal; value: PIInspectable): IInspectable; static; inline;
    class function CreateGuidArray(valueSize: Cardinal; value: PGuid): IInspectable; static; inline;
    class function CreateDateTimeArray(valueSize: Cardinal; value: PDateTime): IInspectable; static; inline;
    class function CreateTimeSpanArray(valueSize: Cardinal; value: PTimeSpan): IInspectable; static; inline;
    class function CreatePointArray(valueSize: Cardinal; value: PPointF): IInspectable; static; inline;
    class function CreateSizeArray(valueSize: Cardinal; value: PSizeF): IInspectable; static; inline;
    class function CreateRectArray(valueSize: Cardinal; value: PRectF): IInspectable; static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.Uri
  // DualAPI
  // Implements: Windows.Foundation.IUriRuntimeClass
  // Implements: Windows.Foundation.IUriRuntimeClassWithAbsoluteCanonicalUri
  // Implements: Windows.Foundation.IStringable
  // Statics: "Windows.Foundation.IUriEscapeStatics"
  // Factory: "Windows.Foundation.IUriRuntimeClassFactory"
  TUri = class(TWinRTGenericImportFS<IUriRuntimeClassFactory, IUriEscapeStatics>)
  public
    {$REGION 'IUriEscapeStatics'}
    class function UnescapeComponent(toUnescape: HSTRING): HSTRING; static; inline;
    class function EscapeComponent(toEscape: HSTRING): HSTRING; static; inline;
    {$ENDREGION}
    {$REGION 'IUriRuntimeClassFactory'}
    class function CreateUri(uri: HSTRING): IUriRuntimeClass; static; inline;
    class function CreateWithRelativeUri(baseUri: HSTRING; relativeUri: HSTRING): IUriRuntimeClass; static; inline;
    {$ENDREGION}
 end;

  // Windows.Foundation.WwwFormUrlDecoder
  // DualAPI
  // Implements: Windows.Foundation.IWwwFormUrlDecoderRuntimeClass
  // Implements: Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  // Implements: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.IWwwFormUrlDecoderEntry>
  // Factory: "Windows.Foundation.IWwwFormUrlDecoderRuntimeClassFactory"
  TWwwFormUrlDecoder = class(TWinRTGenericImportF<IWwwFormUrlDecoderRuntimeClassFactory>)
  public
    {$REGION 'IWwwFormUrlDecoderRuntimeClassFactory'}
    class function CreateWwwFormUrlDecoder(query: HSTRING): IWwwFormUrlDecoderRuntimeClass; static; inline;
    {$ENDREGION}
 end;

implementation

{ TDeferral }

{$REGION 'Windows.Foundation.IDeferralFactory'}
// Factory: "Windows.Foundation.IDeferralFactory"
// -> IDeferralFactory

class function TDeferral.Create(handler: DeferralCompletedHandler): IDeferral;
begin
  Result := Factory.Create(handler);
end;
{$ENDREGION}

{ TDiagnostics_AsyncCausalityTracer }

{$REGION 'Windows.Foundation.Diagnostics.IAsyncCausalityTracerStatics'}
class procedure TDiagnostics_AsyncCausalityTracer.TraceOperationCreation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; operationName: HSTRING; relatedContext: UInt64);
begin
  Statics.TraceOperationCreation(traceLevel, source, platformId, operationId, operationName, relatedContext);
end;

class procedure TDiagnostics_AsyncCausalityTracer.TraceOperationCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; status: AsyncStatus);
begin
  Statics.TraceOperationCompletion(traceLevel, source, platformId, operationId, status);
end;

class procedure TDiagnostics_AsyncCausalityTracer.TraceOperationRelation(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; relation: Diagnostics_CausalityRelation);
begin
  Statics.TraceOperationRelation(traceLevel, source, platformId, operationId, relation);
end;

class procedure TDiagnostics_AsyncCausalityTracer.TraceSynchronousWorkStart(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; platformId: TGuid; operationId: UInt64; work: Diagnostics_CausalitySynchronousWork);
begin
  Statics.TraceSynchronousWorkStart(traceLevel, source, platformId, operationId, work);
end;

class procedure TDiagnostics_AsyncCausalityTracer.TraceSynchronousWorkCompletion(traceLevel: Diagnostics_CausalityTraceLevel; source: Diagnostics_CausalitySource; work: Diagnostics_CausalitySynchronousWork);
begin
  Statics.TraceSynchronousWorkCompletion(traceLevel, source, work);
end;

class function TDiagnostics_AsyncCausalityTracer.add_TracingStatusChanged(handler: EventHandler_1__Diagnostics_ITracingStatusChangedEventArgs): EventRegistrationToken;
begin
  Result := Statics.add_TracingStatusChanged(handler);
end;

class procedure TDiagnostics_AsyncCausalityTracer.remove_TracingStatusChanged(cookie: EventRegistrationToken);
begin
  Statics.remove_TracingStatusChanged(cookie);
end;
{$ENDREGION}

{ TDiagnostics_RuntimeBrokerErrorSettings }

{ TMemoryBuffer }

{$REGION 'Windows.Foundation.IMemoryBufferFactory'}
// Factory: "Windows.Foundation.IMemoryBufferFactory"
// -> IMemoryBufferFactory

class function TMemoryBuffer.Create(capacity: Cardinal): IMemoryBuffer;
begin
  Result := Factory.Create(capacity);
end;
{$ENDREGION}

{ TMetadata_ApiInformation }

{$REGION 'Windows.Foundation.Metadata.IApiInformationStatics'}
class function TMetadata_ApiInformation.IsTypePresent(typeName: HSTRING): Boolean;
begin
  Result := Statics.IsTypePresent(typeName);
end;

class function TMetadata_ApiInformation.IsMethodPresent(typeName: HSTRING; methodName: HSTRING): Boolean;
begin
  Result := Statics.IsMethodPresent(typeName, methodName);
end;

class function TMetadata_ApiInformation.IsMethodPresent(typeName: HSTRING; methodName: HSTRING; inputParameterCount: Cardinal): Boolean;
begin
  Result := Statics.IsMethodPresent(typeName, methodName, inputParameterCount);
end;

class function TMetadata_ApiInformation.IsEventPresent(typeName: HSTRING; eventName: HSTRING): Boolean;
begin
  Result := Statics.IsEventPresent(typeName, eventName);
end;

class function TMetadata_ApiInformation.IsPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean;
begin
  Result := Statics.IsPropertyPresent(typeName, propertyName);
end;

class function TMetadata_ApiInformation.IsReadOnlyPropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean;
begin
  Result := Statics.IsReadOnlyPropertyPresent(typeName, propertyName);
end;

class function TMetadata_ApiInformation.IsWriteablePropertyPresent(typeName: HSTRING; propertyName: HSTRING): Boolean;
begin
  Result := Statics.IsWriteablePropertyPresent(typeName, propertyName);
end;

class function TMetadata_ApiInformation.IsEnumNamedValuePresent(enumTypeName: HSTRING; valueName: HSTRING): Boolean;
begin
  Result := Statics.IsEnumNamedValuePresent(enumTypeName, valueName);
end;

class function TMetadata_ApiInformation.IsApiContractPresent(contractName: HSTRING; majorVersion: Word): Boolean;
begin
  Result := Statics.IsApiContractPresent(contractName, majorVersion);
end;

class function TMetadata_ApiInformation.IsApiContractPresent(contractName: HSTRING; majorVersion: Word; minorVersion: Word): Boolean;
begin
  Result := Statics.IsApiContractPresent(contractName, majorVersion, minorVersion);
end;
{$ENDREGION}

{ TPropertyValue }

{$REGION 'Windows.Foundation.IPropertyValueStatics'}
class function TPropertyValue.CreateEmpty: IInspectable;
begin
  Result := Statics.CreateEmpty;
end;

class function TPropertyValue.CreateUInt8(value: Byte): IInspectable;
begin
  Result := Statics.CreateUInt8(value);
end;

class function TPropertyValue.CreateInt16(value: SmallInt): IInspectable;
begin
  Result := Statics.CreateInt16(value);
end;

class function TPropertyValue.CreateUInt16(value: Word): IInspectable;
begin
  Result := Statics.CreateUInt16(value);
end;

class function TPropertyValue.CreateInt32(value: Integer): IInspectable;
begin
  Result := Statics.CreateInt32(value);
end;

class function TPropertyValue.CreateUInt32(value: Cardinal): IInspectable;
begin
  Result := Statics.CreateUInt32(value);
end;

class function TPropertyValue.CreateInt64(value: Int64): IInspectable;
begin
  Result := Statics.CreateInt64(value);
end;

class function TPropertyValue.CreateUInt64(value: UInt64): IInspectable;
begin
  Result := Statics.CreateUInt64(value);
end;

class function TPropertyValue.CreateSingle(value: Single): IInspectable;
begin
  Result := Statics.CreateSingle(value);
end;

class function TPropertyValue.CreateDouble(value: Double): IInspectable;
begin
  Result := Statics.CreateDouble(value);
end;

class function TPropertyValue.CreateChar16(value: Char): IInspectable;
begin
  Result := Statics.CreateChar16(value);
end;

class function TPropertyValue.CreateBoolean(value: Boolean): IInspectable;
begin
  Result := Statics.CreateBoolean(value);
end;

class function TPropertyValue.CreateString(value: HSTRING): IInspectable;
begin
  Result := Statics.CreateString(value);
end;

class function TPropertyValue.CreateInspectable(value: IInspectable): IInspectable;
begin
  Result := Statics.CreateInspectable(value);
end;

class function TPropertyValue.CreateGuid(value: TGuid): IInspectable;
begin
  Result := Statics.CreateGuid(value);
end;

class function TPropertyValue.CreateDateTime(value: DateTime): IInspectable;
begin
  Result := Statics.CreateDateTime(value);
end;

class function TPropertyValue.CreateTimeSpan(value: TimeSpan): IInspectable;
begin
  Result := Statics.CreateTimeSpan(value);
end;

class function TPropertyValue.CreatePoint(value: TPointF): IInspectable;
begin
  Result := Statics.CreatePoint(value);
end;

class function TPropertyValue.CreateSize(value: TSizeF): IInspectable;
begin
  Result := Statics.CreateSize(value);
end;

class function TPropertyValue.CreateRect(value: TRectF): IInspectable;
begin
  Result := Statics.CreateRect(value);
end;

class function TPropertyValue.CreateUInt8Array(valueSize: Cardinal; value: PByte): IInspectable;
begin
  Result := Statics.CreateUInt8Array(valueSize, value);
end;

class function TPropertyValue.CreateInt16Array(valueSize: Cardinal; value: PSmallInt): IInspectable;
begin
  Result := Statics.CreateInt16Array(valueSize, value);
end;

class function TPropertyValue.CreateUInt16Array(valueSize: Cardinal; value: PWord): IInspectable;
begin
  Result := Statics.CreateUInt16Array(valueSize, value);
end;

class function TPropertyValue.CreateInt32Array(valueSize: Cardinal; value: PInteger): IInspectable;
begin
  Result := Statics.CreateInt32Array(valueSize, value);
end;

class function TPropertyValue.CreateUInt32Array(valueSize: Cardinal; value: PCardinal): IInspectable;
begin
  Result := Statics.CreateUInt32Array(valueSize, value);
end;

class function TPropertyValue.CreateInt64Array(valueSize: Cardinal; value: PInt64): IInspectable;
begin
  Result := Statics.CreateInt64Array(valueSize, value);
end;

class function TPropertyValue.CreateUInt64Array(valueSize: Cardinal; value: PUInt64): IInspectable;
begin
  Result := Statics.CreateUInt64Array(valueSize, value);
end;

class function TPropertyValue.CreateSingleArray(valueSize: Cardinal; value: PSingle): IInspectable;
begin
  Result := Statics.CreateSingleArray(valueSize, value);
end;

class function TPropertyValue.CreateDoubleArray(valueSize: Cardinal; value: PDouble): IInspectable;
begin
  Result := Statics.CreateDoubleArray(valueSize, value);
end;

class function TPropertyValue.CreateChar16Array(valueSize: Cardinal; value: PChar): IInspectable;
begin
  Result := Statics.CreateChar16Array(valueSize, value);
end;

class function TPropertyValue.CreateBooleanArray(valueSize: Cardinal; value: PBoolean): IInspectable;
begin
  Result := Statics.CreateBooleanArray(valueSize, value);
end;

class function TPropertyValue.CreateStringArray(valueSize: Cardinal; value: PHSTRING): IInspectable;
begin
  Result := Statics.CreateStringArray(valueSize, value);
end;

class function TPropertyValue.CreateInspectableArray(valueSize: Cardinal; value: PIInspectable): IInspectable;
begin
  Result := Statics.CreateInspectableArray(valueSize, value);
end;

class function TPropertyValue.CreateGuidArray(valueSize: Cardinal; value: PGuid): IInspectable;
begin
  Result := Statics.CreateGuidArray(valueSize, value);
end;

class function TPropertyValue.CreateDateTimeArray(valueSize: Cardinal; value: PDateTime): IInspectable;
begin
  Result := Statics.CreateDateTimeArray(valueSize, value);
end;

class function TPropertyValue.CreateTimeSpanArray(valueSize: Cardinal; value: PTimeSpan): IInspectable;
begin
  Result := Statics.CreateTimeSpanArray(valueSize, value);
end;

class function TPropertyValue.CreatePointArray(valueSize: Cardinal; value: PPointF): IInspectable;
begin
  Result := Statics.CreatePointArray(valueSize, value);
end;

class function TPropertyValue.CreateSizeArray(valueSize: Cardinal; value: PSizeF): IInspectable;
begin
  Result := Statics.CreateSizeArray(valueSize, value);
end;

class function TPropertyValue.CreateRectArray(valueSize: Cardinal; value: PRectF): IInspectable;
begin
  Result := Statics.CreateRectArray(valueSize, value);
end;
{$ENDREGION}

{ TUri }

{$REGION 'Windows.Foundation.IUriEscapeStatics'}
class function TUri.UnescapeComponent(toUnescape: HSTRING): HSTRING;
begin
  Result := Statics.UnescapeComponent(toUnescape);
end;

class function TUri.EscapeComponent(toEscape: HSTRING): HSTRING;
begin
  Result := Statics.EscapeComponent(toEscape);
end;
{$ENDREGION}

{$REGION 'Windows.Foundation.IUriRuntimeClassFactory'}
// Factory: "Windows.Foundation.IUriRuntimeClassFactory"
// -> IUriRuntimeClassFactory

class function TUri.CreateUri(uri: HSTRING): IUriRuntimeClass;
begin
  Result := Factory.CreateUri(uri);
end;

class function TUri.CreateWithRelativeUri(baseUri: HSTRING; relativeUri: HSTRING): IUriRuntimeClass;
begin
  Result := Factory.CreateWithRelativeUri(baseUri, relativeUri);
end;
{$ENDREGION}

{ TWwwFormUrlDecoder }

{$REGION 'Windows.Foundation.IWwwFormUrlDecoderRuntimeClassFactory'}
// Factory: "Windows.Foundation.IWwwFormUrlDecoderRuntimeClassFactory"
// -> IWwwFormUrlDecoderRuntimeClassFactory

class function TWwwFormUrlDecoder.CreateWwwFormUrlDecoder(query: HSTRING): IWwwFormUrlDecoderRuntimeClass;
begin
  Result := Factory.CreateWwwFormUrlDecoder(query);
end;
{$ENDREGION}

end.
