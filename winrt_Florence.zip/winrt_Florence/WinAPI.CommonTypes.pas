{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.CommonTypes;

{$WEAKPACKAGEUNIT ON}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // External: Windows.System.IUser
  IUser = interface;
  PIUser = ^IUser;

  // External: Windows.Foundation.IAsyncOperation`1<Object>
  IAsyncOperation_1__IInspectable = interface;
  PIAsyncOperation_1__IInspectable = ^IAsyncOperation_1__IInspectable;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Object>
  AsyncOperationCompletedHandler_1__IInspectable = interface;
  PAsyncOperationCompletedHandler_1__IInspectable = ^AsyncOperationCompletedHandler_1__IInspectable;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IPropertySet>
  IAsyncOperation_1__IPropertySet = interface;
  PIAsyncOperation_1__IPropertySet = ^IAsyncOperation_1__IPropertySet;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IPropertySet>
  AsyncOperationCompletedHandler_1__IPropertySet = interface;
  PAsyncOperationCompletedHandler_1__IPropertySet = ^AsyncOperationCompletedHandler_1__IPropertySet;

  // External: Windows.Foundation.Collections.IPropertySet
  IPropertySet = interface;
  PIPropertySet = ^IPropertySet;

  // External: Windows.Foundation.Collections.IVectorView`1<String>
  IVectorView_1__HSTRING = interface;
  PIVectorView_1__HSTRING = ^IVectorView_1__HSTRING;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IAsyncOperation_1__IRandomAccessStreamReference = interface;
  PIAsyncOperation_1__IRandomAccessStreamReference = ^IAsyncOperation_1__IRandomAccessStreamReference;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  AsyncOperationCompletedHandler_1__IRandomAccessStreamReference = interface;
  PAsyncOperationCompletedHandler_1__IRandomAccessStreamReference = ^AsyncOperationCompletedHandler_1__IRandomAccessStreamReference;

  // External: Windows.Storage.Streams.IRandomAccessStreamReference
  IRandomAccessStreamReference = interface;
  PIRandomAccessStreamReference = ^IRandomAccessStreamReference;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IAsyncOperation_1__IRandomAccessStreamWithContentType = interface;
  PIAsyncOperation_1__IRandomAccessStreamWithContentType = ^IAsyncOperation_1__IRandomAccessStreamWithContentType;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType = interface;
  PAsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType = ^AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType;

  // External: Windows.Storage.Streams.IRandomAccessStreamWithContentType
  IRandomAccessStreamWithContentType = interface;
  PIRandomAccessStreamWithContentType = ^IRandomAccessStreamWithContentType;

  // External: Windows.Storage.IStorageFile
  IStorageFile = interface;
  PIStorageFile = ^IStorageFile;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStream>
  IAsyncOperation_1__IRandomAccessStream = interface;
  PIAsyncOperation_1__IRandomAccessStream = ^IAsyncOperation_1__IRandomAccessStream;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStream>
  AsyncOperationCompletedHandler_1__IRandomAccessStream = interface;
  PAsyncOperationCompletedHandler_1__IRandomAccessStream = ^AsyncOperationCompletedHandler_1__IRandomAccessStream;

  // External: Windows.Storage.Streams.IRandomAccessStream
  IRandomAccessStream = interface;
  PIRandomAccessStream = ^IRandomAccessStream;

  // External: Windows.Storage.Streams.IInputStream
  IInputStream = interface;
  PIInputStream = ^IInputStream;

  // External: Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IBuffer,UInt32>
  IAsyncOperationWithProgress_2__IBuffer__Cardinal = interface;
  PIAsyncOperationWithProgress_2__IBuffer__Cardinal = ^IAsyncOperationWithProgress_2__IBuffer__Cardinal;

  // External: Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IBuffer,UInt32>
  AsyncOperationProgressHandler_2__IBuffer__Cardinal = interface;
  PAsyncOperationProgressHandler_2__IBuffer__Cardinal = ^AsyncOperationProgressHandler_2__IBuffer__Cardinal;

  // External: Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IBuffer,UInt32>
  AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal = interface;
  PAsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal = ^AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal;

  // External: Windows.Storage.Streams.IBuffer
  IBuffer = interface;
  PIBuffer = ^IBuffer;

  // External: Windows.Storage.Streams.IOutputStream
  IOutputStream = interface;
  PIOutputStream = ^IOutputStream;

  // External: Windows.Foundation.IAsyncOperationWithProgress`2<UInt32,UInt32>
  IAsyncOperationWithProgress_2__Cardinal__Cardinal = interface;
  PIAsyncOperationWithProgress_2__Cardinal__Cardinal = ^IAsyncOperationWithProgress_2__Cardinal__Cardinal;

  // External: Windows.Foundation.AsyncOperationProgressHandler`2<UInt32,UInt32>
  AsyncOperationProgressHandler_2__Cardinal__Cardinal = interface;
  PAsyncOperationProgressHandler_2__Cardinal__Cardinal = ^AsyncOperationProgressHandler_2__Cardinal__Cardinal;

  // External: Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<UInt32,UInt32>
  AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal = interface;
  PAsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal = ^AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal;

  // External: Windows.Foundation.IAsyncOperation`1<Boolean>
  IAsyncOperation_1__Boolean = interface;
  PIAsyncOperation_1__Boolean = ^IAsyncOperation_1__Boolean;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Boolean>
  AsyncOperationCompletedHandler_1__Boolean = interface;
  PAsyncOperationCompletedHandler_1__Boolean = ^AsyncOperationCompletedHandler_1__Boolean;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageStreamTransaction>
  IAsyncOperation_1__IStorageStreamTransaction = interface;
  PIAsyncOperation_1__IStorageStreamTransaction = ^IAsyncOperation_1__IStorageStreamTransaction;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageStreamTransaction>
  AsyncOperationCompletedHandler_1__IStorageStreamTransaction = interface;
  PAsyncOperationCompletedHandler_1__IStorageStreamTransaction = ^AsyncOperationCompletedHandler_1__IStorageStreamTransaction;

  // External: Windows.Storage.IStorageStreamTransaction
  IStorageStreamTransaction = interface;
  PIStorageStreamTransaction = ^IStorageStreamTransaction;

  // External: Windows.Foundation.IAsyncAction
  IAsyncAction = interface;
  PIAsyncAction = ^IAsyncAction;

  // External: Windows.Foundation.AsyncActionCompletedHandler
  AsyncActionCompletedHandler = interface;
  PAsyncActionCompletedHandler = ^AsyncActionCompletedHandler;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageFile>
  IAsyncOperation_1__IStorageFile = interface;
  PIAsyncOperation_1__IStorageFile = ^IAsyncOperation_1__IStorageFile;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageFile>
  AsyncOperationCompletedHandler_1__IStorageFile = interface;
  PAsyncOperationCompletedHandler_1__IStorageFile = ^AsyncOperationCompletedHandler_1__IStorageFile;

  // External: Windows.Storage.IStorageFolder
  IStorageFolder = interface;
  PIStorageFolder = ^IStorageFolder;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageFolder>
  IAsyncOperation_1__IStorageFolder = interface;
  PIAsyncOperation_1__IStorageFolder = ^IAsyncOperation_1__IStorageFolder;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageFolder>
  AsyncOperationCompletedHandler_1__IStorageFolder = interface;
  PAsyncOperationCompletedHandler_1__IStorageFolder = ^AsyncOperationCompletedHandler_1__IStorageFolder;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageItem>
  IAsyncOperation_1__IStorageItem = interface;
  PIAsyncOperation_1__IStorageItem = ^IAsyncOperation_1__IStorageItem;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageItem>
  AsyncOperationCompletedHandler_1__IStorageItem = interface;
  PAsyncOperationCompletedHandler_1__IStorageItem = ^AsyncOperationCompletedHandler_1__IStorageItem;

  // External: Windows.Storage.IStorageItem
  IStorageItem = interface;
  PIStorageItem = ^IStorageItem;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Storage.FileProperties.IBasicProperties>
  IAsyncOperation_1__FileProperties_IBasicProperties = interface;
  PIAsyncOperation_1__FileProperties_IBasicProperties = ^IAsyncOperation_1__FileProperties_IBasicProperties;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.FileProperties.IBasicProperties>
  AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties = interface;
  PAsyncOperationCompletedHandler_1__FileProperties_IBasicProperties = ^AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties;

  // External: Windows.Storage.FileProperties.IBasicProperties
  FileProperties_IBasicProperties = interface;
  PFileProperties_IBasicProperties = ^FileProperties_IBasicProperties;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>>
  IAsyncOperation_1__IVectorView_1__IStorageFile = interface;
  PIAsyncOperation_1__IVectorView_1__IStorageFile = ^IAsyncOperation_1__IVectorView_1__IStorageFile;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile = ^AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>
  IVectorView_1__IStorageFile = interface;
  PIVectorView_1__IStorageFile = ^IVectorView_1__IStorageFile;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>>
  IAsyncOperation_1__IVectorView_1__IStorageFolder = interface;
  PIAsyncOperation_1__IVectorView_1__IStorageFolder = ^IAsyncOperation_1__IVectorView_1__IStorageFolder;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder = ^AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>
  IVectorView_1__IStorageFolder = interface;
  PIVectorView_1__IStorageFolder = ^IVectorView_1__IStorageFolder;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>>
  IAsyncOperation_1__IVectorView_1__IStorageItem = interface;
  PIAsyncOperation_1__IVectorView_1__IStorageItem = ^IAsyncOperation_1__IVectorView_1__IStorageItem;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem = ^AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>
  IVectorView_1__IStorageItem = interface;
  PIVectorView_1__IStorageItem = ^IVectorView_1__IStorageItem;

  // External: Windows.System.RemoteSystems.IRemoteSystemConnectionRequest
  RemoteSystems_IRemoteSystemConnectionRequest = interface;
  PRemoteSystems_IRemoteSystemConnectionRequest = ^RemoteSystems_IRemoteSystemConnectionRequest;

  // External: Windows.System.RemoteSystems.IRemoteSystem
  RemoteSystems_IRemoteSystem = interface;
  PRemoteSystems_IRemoteSystem = ^RemoteSystems_IRemoteSystem;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Background.IBackgroundTaskRegistrationGroup,Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs>
  TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs = interface;
  PTypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs = ^TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskRegistrationGroup
  IBackgroundTaskRegistrationGroup = interface;
  PIBackgroundTaskRegistrationGroup = ^IBackgroundTaskRegistrationGroup;

  // External: Windows.Foundation.Collections.IMapView`2<Guid,Windows.ApplicationModel.Background.IBackgroundTaskRegistration>
  IMapView_2__TGuid__IBackgroundTaskRegistration = interface;
  PIMapView_2__TGuid__IBackgroundTaskRegistration = ^IMapView_2__TGuid__IBackgroundTaskRegistration;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskRegistration
  IBackgroundTaskRegistration = interface;
  PIBackgroundTaskRegistration = ^IBackgroundTaskRegistration;

  // External: Windows.ApplicationModel.Background.BackgroundTaskProgressEventHandler
  BackgroundTaskProgressEventHandler = interface;
  PBackgroundTaskProgressEventHandler = ^BackgroundTaskProgressEventHandler;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskProgressEventArgs
  IBackgroundTaskProgressEventArgs = interface;
  PIBackgroundTaskProgressEventArgs = ^IBackgroundTaskProgressEventArgs;

  // External: Windows.ApplicationModel.Background.BackgroundTaskCompletedEventHandler
  BackgroundTaskCompletedEventHandler = interface;
  PBackgroundTaskCompletedEventHandler = ^BackgroundTaskCompletedEventHandler;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskCompletedEventArgs
  IBackgroundTaskCompletedEventArgs = interface;
  PIBackgroundTaskCompletedEventArgs = ^IBackgroundTaskCompletedEventArgs;

  // External: Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs
  Activation_IBackgroundActivatedEventArgs = interface;
  PActivation_IBackgroundActivatedEventArgs = ^Activation_IBackgroundActivatedEventArgs;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskInstance
  IBackgroundTaskInstance = interface;
  PIBackgroundTaskInstance = ^IBackgroundTaskInstance;

  // External: Windows.ApplicationModel.Background.BackgroundTaskCanceledEventHandler
  BackgroundTaskCanceledEventHandler = interface;
  PBackgroundTaskCanceledEventHandler = ^BackgroundTaskCanceledEventHandler;

  // External: Windows.ApplicationModel.Background.IBackgroundTaskDeferral
  IBackgroundTaskDeferral = interface;
  PIBackgroundTaskDeferral = ^IBackgroundTaskDeferral;

  // External: Windows.ApplicationModel.IAppDisplayInfo
  IAppDisplayInfo = interface;
  PIAppDisplayInfo = ^IAppDisplayInfo;

  // External: Windows.ApplicationModel.IAppInfo
  IAppInfo = interface;
  PIAppInfo = ^IAppInfo;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Core.ICoreApplicationView,Windows.ApplicationModel.Activation.IActivatedEventArgs>
  TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs = interface;
  PTypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs = ^TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs;

  // External: Windows.ApplicationModel.Core.ICoreApplicationView
  ICoreApplicationView = interface;
  PICoreApplicationView = ^ICoreApplicationView;

  // External: Windows.UI.Core.ICoreWindow
  ICoreWindow = interface;
  PICoreWindow = ^ICoreWindow;

  // External: Windows.UI.Core.ICoreDispatcher
  ICoreDispatcher = interface;
  PICoreDispatcher = ^ICoreDispatcher;

  // External: Windows.UI.Core.DispatchedHandler
  DispatchedHandler = interface;
  PDispatchedHandler = ^DispatchedHandler;

  // External: Windows.UI.Core.IdleDispatchedHandler
  IdleDispatchedHandler = interface;
  PIdleDispatchedHandler = ^IdleDispatchedHandler;

  // External: Windows.UI.Core.IIdleDispatchedHandlerArgs
  IIdleDispatchedHandlerArgs = interface;
  PIIdleDispatchedHandlerArgs = ^IIdleDispatchedHandlerArgs;

  // External: Windows.UI.Core.ICoreCursor
  ICoreCursor = interface;
  PICoreCursor = ^ICoreCursor;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IWindowActivatedEventArgs>
  TypedEventHandler_2__ICoreWindow__IWindowActivatedEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IWindowActivatedEventArgs = ^TypedEventHandler_2__ICoreWindow__IWindowActivatedEventArgs;

  // External: Windows.UI.Core.IWindowActivatedEventArgs
  IWindowActivatedEventArgs = interface;
  PIWindowActivatedEventArgs = ^IWindowActivatedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IAutomationProviderRequestedEventArgs>
  TypedEventHandler_2__ICoreWindow__IAutomationProviderRequestedEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IAutomationProviderRequestedEventArgs = ^TypedEventHandler_2__ICoreWindow__IAutomationProviderRequestedEventArgs;

  // External: Windows.UI.Core.IAutomationProviderRequestedEventArgs
  IAutomationProviderRequestedEventArgs = interface;
  PIAutomationProviderRequestedEventArgs = ^IAutomationProviderRequestedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ICharacterReceivedEventArgs>
  TypedEventHandler_2__ICoreWindow__ICharacterReceivedEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__ICharacterReceivedEventArgs = ^TypedEventHandler_2__ICoreWindow__ICharacterReceivedEventArgs;

  // External: Windows.UI.Core.ICharacterReceivedEventArgs
  ICharacterReceivedEventArgs = interface;
  PICharacterReceivedEventArgs = ^ICharacterReceivedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ICoreWindowEventArgs>
  TypedEventHandler_2__ICoreWindow__ICoreWindowEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__ICoreWindowEventArgs = ^TypedEventHandler_2__ICoreWindow__ICoreWindowEventArgs;

  // External: Windows.UI.Core.ICoreWindowEventArgs
  ICoreWindowEventArgs = interface;
  PICoreWindowEventArgs = ^ICoreWindowEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IInputEnabledEventArgs>
  TypedEventHandler_2__ICoreWindow__IInputEnabledEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IInputEnabledEventArgs = ^TypedEventHandler_2__ICoreWindow__IInputEnabledEventArgs;

  // External: Windows.UI.Core.IInputEnabledEventArgs
  IInputEnabledEventArgs = interface;
  PIInputEnabledEventArgs = ^IInputEnabledEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IKeyEventArgs>
  TypedEventHandler_2__ICoreWindow__IKeyEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IKeyEventArgs = ^TypedEventHandler_2__ICoreWindow__IKeyEventArgs;

  // External: Windows.UI.Core.IKeyEventArgs
  IKeyEventArgs = interface;
  PIKeyEventArgs = ^IKeyEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IPointerEventArgs>
  TypedEventHandler_2__ICoreWindow__IPointerEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IPointerEventArgs = ^TypedEventHandler_2__ICoreWindow__IPointerEventArgs;

  // External: Windows.UI.Core.IPointerEventArgs
  IPointerEventArgs = interface;
  PIPointerEventArgs = ^IPointerEventArgs;

  // External: Windows.UI.Input.IPointerPoint
  IPointerPoint = interface;
  PIPointerPoint = ^IPointerPoint;

  // External: Windows.Devices.Input.IPointerDevice
  Input_IPointerDevice = interface;
  PInput_IPointerDevice = ^Input_IPointerDevice;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Input.PointerDeviceUsage>
  IVectorView_1__Input_PointerDeviceUsage = interface;
  PIVectorView_1__Input_PointerDeviceUsage = ^IVectorView_1__Input_PointerDeviceUsage;

  // External: Windows.UI.Input.IPointerPointProperties
  IPointerPointProperties = interface;
  PIPointerPointProperties = ^IPointerPointProperties;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Input.IPointerPoint>
  IVector_1__IPointerPoint = interface;
  PIVector_1__IPointerPoint = ^IVector_1__IPointerPoint;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.IPointerPoint>
  IVectorView_1__IPointerPoint = interface;
  PIVectorView_1__IPointerPoint = ^IVectorView_1__IPointerPoint;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ITouchHitTestingEventArgs>
  TypedEventHandler_2__ICoreWindow__ITouchHitTestingEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__ITouchHitTestingEventArgs = ^TypedEventHandler_2__ICoreWindow__ITouchHitTestingEventArgs;

  // External: Windows.UI.Core.ITouchHitTestingEventArgs
  ITouchHitTestingEventArgs = interface;
  PITouchHitTestingEventArgs = ^ITouchHitTestingEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IWindowSizeChangedEventArgs>
  TypedEventHandler_2__ICoreWindow__IWindowSizeChangedEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IWindowSizeChangedEventArgs = ^TypedEventHandler_2__ICoreWindow__IWindowSizeChangedEventArgs;

  // External: Windows.UI.Core.IWindowSizeChangedEventArgs
  IWindowSizeChangedEventArgs = interface;
  PIWindowSizeChangedEventArgs = ^IWindowSizeChangedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IVisibilityChangedEventArgs>
  TypedEventHandler_2__ICoreWindow__IVisibilityChangedEventArgs = interface;
  PTypedEventHandler_2__ICoreWindow__IVisibilityChangedEventArgs = ^TypedEventHandler_2__ICoreWindow__IVisibilityChangedEventArgs;

  // External: Windows.UI.Core.IVisibilityChangedEventArgs
  IVisibilityChangedEventArgs = interface;
  PIVisibilityChangedEventArgs = ^IVisibilityChangedEventArgs;

  // External: Windows.ApplicationModel.Activation.IActivatedEventArgs
  Activation_IActivatedEventArgs = interface;
  PActivation_IActivatedEventArgs = ^Activation_IActivatedEventArgs;

  // External: Windows.ApplicationModel.Activation.ISplashScreen
  Activation_ISplashScreen = interface;
  PActivation_ISplashScreen = ^Activation_ISplashScreen;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Activation.ISplashScreen,Object>
  TypedEventHandler_2__Activation_ISplashScreen__IInspectable = interface;
  PTypedEventHandler_2__Activation_ISplashScreen__IInspectable = ^TypedEventHandler_2__Activation_ISplashScreen__IInspectable;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.System.IUserChangedEventArgs>
  TypedEventHandler_2__Input_IGameController__IUserChangedEventArgs = interface;
  PTypedEventHandler_2__Input_IGameController__IUserChangedEventArgs = ^TypedEventHandler_2__Input_IGameController__IUserChangedEventArgs;

  // External: Windows.Gaming.Input.IGameController
  Input_IGameController = interface;
  PInput_IGameController = ^Input_IGameController;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.Gaming.Input.IHeadset>
  TypedEventHandler_2__Input_IGameController__Input_IHeadset = interface;
  PTypedEventHandler_2__Input_IGameController__Input_IHeadset = ^TypedEventHandler_2__Input_IGameController__Input_IHeadset;

  // External: Windows.Gaming.Input.IHeadset
  Input_IHeadset = interface;
  PInput_IHeadset = ^Input_IHeadset;

  // External: Windows.System.IUserChangedEventArgs
  IUserChangedEventArgs = interface;
  PIUserChangedEventArgs = ^IUserChangedEventArgs;

  // External: Windows.Devices.Power.IBatteryReport
  Power_IBatteryReport = interface;
  PPower_IBatteryReport = ^Power_IBatteryReport;

  // External: Windows.Foundation.IReference`1<Int32>
  IReference_1__Integer = interface;
  PIReference_1__Integer = ^IReference_1__Integer;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.ISimpleHapticsController>
  IVectorView_1__Haptics_ISimpleHapticsController = interface;
  PIVectorView_1__Haptics_ISimpleHapticsController = ^IVectorView_1__Haptics_ISimpleHapticsController;

  // External: Windows.Devices.Haptics.ISimpleHapticsController
  Haptics_ISimpleHapticsController = interface;
  PHaptics_ISimpleHapticsController = ^Haptics_ISimpleHapticsController;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  IVectorView_1__Haptics_ISimpleHapticsControllerFeedback = interface;
  PIVectorView_1__Haptics_ISimpleHapticsControllerFeedback = ^IVectorView_1__Haptics_ISimpleHapticsControllerFeedback;

  // External: Windows.Devices.Haptics.ISimpleHapticsControllerFeedback
  Haptics_ISimpleHapticsControllerFeedback = interface;
  PHaptics_ISimpleHapticsControllerFeedback = ^Haptics_ISimpleHapticsControllerFeedback;

  // External: Windows.Foundation.Collections.IMapView`2<String,Windows.Foundation.Collections.IVectorView`1<String>>
  IMapView_2__HSTRING__IVectorView_1__HSTRING = interface;
  PIMapView_2__HSTRING__IVectorView_1__HSTRING = ^IMapView_2__HSTRING__IVectorView_1__HSTRING;

  // External: Windows.Devices.Enumeration.IDeviceInformation
  IDeviceInformation = interface;
  PIDeviceInformation = ^IDeviceInformation;

  // External: Windows.Devices.Enumeration.IEnclosureLocation
  IEnclosureLocation = interface;
  PIEnclosureLocation = ^IEnclosureLocation;

  // External: Windows.Foundation.Collections.IMapView`2<String,Object>
  IMapView_2__HSTRING__IInspectable = interface;
  PIMapView_2__HSTRING__IInspectable = ^IMapView_2__HSTRING__IInspectable;

  // External: Windows.Devices.Enumeration.IDeviceInformationUpdate
  IDeviceInformationUpdate = interface;
  PIDeviceInformationUpdate = ^IDeviceInformationUpdate;

  // External: Windows.Foundation.Collections.IIterable`1<String>
  IIterable_1__HSTRING = interface;
  PIIterable_1__HSTRING = ^IIterable_1__HSTRING;

  // External: Windows.Foundation.Collections.IIterator`1<String>
  IIterator_1__HSTRING = interface;
  PIIterator_1__HSTRING = ^IIterator_1__HSTRING;

  // External: Windows.Foundation.Collections.IVectorChangedEventArgs
  IVectorChangedEventArgs = interface;
  PIVectorChangedEventArgs = ^IVectorChangedEventArgs;

  // External: Windows.Foundation.Collections.IMapView`2<Guid,Object>
  IMapView_2__TGuid__IInspectable = interface;
  PIMapView_2__TGuid__IInspectable = ^IMapView_2__TGuid__IInspectable;

  // External: Windows.Foundation.Collections.IMap`2<Guid,Object>
  IMap_2__TGuid__IInspectable = interface;
  PIMap_2__TGuid__IInspectable = ^IMap_2__TGuid__IInspectable;

  // External: Windows.Devices.Enumeration.IDevicePickerAppearance
  IDevicePickerAppearance = interface;
  PIDevicePickerAppearance = ^IDevicePickerAppearance;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlaybackItem,Windows.Foundation.Collections.IVectorChangedEventArgs>
  TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs = interface;
  PTypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs = ^TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs;

  // External: Windows.Media.Playback.IMediaPlaybackItem
  Playback_IMediaPlaybackItem = interface;
  PPlayback_IMediaPlaybackItem = ^Playback_IMediaPlaybackItem;

  // External: Windows.Media.Core.IMediaSource2
  Core_IMediaSource2 = interface;
  PCore_IMediaSource2 = ^Core_IMediaSource2;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.IMediaSource2,Windows.Media.Core.IMediaSourceOpenOperationCompletedEventArgs>
  TypedEventHandler_2__Core_IMediaSource2__Core_IMediaSourceOpenOperationCompletedEventArgs = interface;
  PTypedEventHandler_2__Core_IMediaSource2__Core_IMediaSourceOpenOperationCompletedEventArgs = ^TypedEventHandler_2__Core_IMediaSource2__Core_IMediaSourceOpenOperationCompletedEventArgs;

  // External: Windows.Media.Core.IMediaSourceOpenOperationCompletedEventArgs
  Core_IMediaSourceOpenOperationCompletedEventArgs = interface;
  PCore_IMediaSourceOpenOperationCompletedEventArgs = ^Core_IMediaSourceOpenOperationCompletedEventArgs;

  // External: Windows.Media.Core.IMediaSourceError
  Core_IMediaSourceError = interface;
  PCore_IMediaSourceError = ^Core_IMediaSourceError;

  // External: Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>
  IReference_1__TimeSpan = interface;
  PIReference_1__TimeSpan = ^IReference_1__TimeSpan;

  // External: Windows.Foundation.Collections.IObservableVector`1<Windows.Media.Core.ITimedTextSource>
  IObservableVector_1__Core_ITimedTextSource = interface;
  PIObservableVector_1__Core_ITimedTextSource = ^IObservableVector_1__Core_ITimedTextSource;

  // External: Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.ITimedTextSource>
  VectorChangedEventHandler_1__Core_ITimedTextSource = interface;
  PVectorChangedEventHandler_1__Core_ITimedTextSource = ^VectorChangedEventHandler_1__Core_ITimedTextSource;

  // External: Windows.Foundation.Collections.IObservableVector`1<Windows.Media.Core.ITimedMetadataTrack>
  IObservableVector_1__Core_ITimedMetadataTrack = interface;
  PIObservableVector_1__Core_ITimedMetadataTrack = ^IObservableVector_1__Core_ITimedMetadataTrack;

  // External: Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.ITimedMetadataTrack>
  VectorChangedEventHandler_1__Core_ITimedMetadataTrack = interface;
  PVectorChangedEventHandler_1__Core_ITimedMetadataTrack = ^VectorChangedEventHandler_1__Core_ITimedMetadataTrack;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IMediaTrack>
  IVectorView_1__Core_IMediaTrack = interface;
  PIVectorView_1__Core_IMediaTrack = ^IVectorView_1__Core_IMediaTrack;

  // External: Windows.Media.Core.IMediaTrack
  Core_IMediaTrack = interface;
  PCore_IMediaTrack = ^Core_IMediaTrack;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.ITimedMetadataTrack>
  IVectorView_1__Core_ITimedMetadataTrack = interface;
  PIVectorView_1__Core_ITimedMetadataTrack = ^IVectorView_1__Core_ITimedMetadataTrack;

  // External: Windows.Media.Core.ITimedMetadataTrack
  Core_ITimedMetadataTrack = interface;
  PCore_ITimedMetadataTrack = ^Core_ITimedMetadataTrack;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.ITimedMetadataTrack,Windows.Media.Core.IMediaCueEventArgs>
  TypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs = interface;
  PTypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs = ^TypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs;

  // External: Windows.Media.Core.IMediaCueEventArgs
  Core_IMediaCueEventArgs = interface;
  PCore_IMediaCueEventArgs = ^Core_IMediaCueEventArgs;

  // External: Windows.Media.Core.IMediaCue
  Core_IMediaCue = interface;
  PCore_IMediaCue = ^Core_IMediaCue;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.ITimedMetadataTrack,Windows.Media.Core.ITimedMetadataTrackFailedEventArgs>
  TypedEventHandler_2__Core_ITimedMetadataTrack__Core_ITimedMetadataTrackFailedEventArgs = interface;
  PTypedEventHandler_2__Core_ITimedMetadataTrack__Core_ITimedMetadataTrackFailedEventArgs = ^TypedEventHandler_2__Core_ITimedMetadataTrack__Core_ITimedMetadataTrackFailedEventArgs;

  // External: Windows.Media.Core.ITimedMetadataTrackFailedEventArgs
  Core_ITimedMetadataTrackFailedEventArgs = interface;
  PCore_ITimedMetadataTrackFailedEventArgs = ^Core_ITimedMetadataTrackFailedEventArgs;

  // External: Windows.Media.Core.ITimedMetadataTrackError
  Core_ITimedMetadataTrackError = interface;
  PCore_ITimedMetadataTrackError = ^Core_ITimedMetadataTrackError;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IMediaCue>
  IVectorView_1__Core_IMediaCue = interface;
  PIVectorView_1__Core_IMediaCue = ^IVectorView_1__Core_IMediaCue;

  // External: Windows.Storage.FileProperties.IMusicProperties
  FileProperties_IMusicProperties = interface;
  PFileProperties_IMusicProperties = ^FileProperties_IMusicProperties;

  // External: Windows.Foundation.Collections.IVector`1<String>
  IVector_1__HSTRING = interface;
  PIVector_1__HSTRING = ^IVector_1__HSTRING;

  // External: Windows.Storage.FileProperties.IVideoProperties
  FileProperties_IVideoProperties = interface;
  PFileProperties_IVideoProperties = ^FileProperties_IVideoProperties;

  // External: Windows.Foundation.IReference`1<Double>
  IReference_1__Double = interface;
  PIReference_1__Double = ^IReference_1__Double;

  // External: Windows.Foundation.Collections.IVectorView`1<UInt32>
  IVectorView_1__Cardinal = interface;
  PIVectorView_1__Cardinal = ^IVectorView_1__Cardinal;

  // External: Windows.Foundation.Collections.IMap`2<String,String>
  IMap_2__HSTRING__HSTRING = interface;
  PIMap_2__HSTRING__HSTRING = ^IMap_2__HSTRING__HSTRING;

  // External: Windows.Foundation.Collections.IMapView`2<String,String>
  IMapView_2__HSTRING__HSTRING = interface;
  PIMapView_2__HSTRING__HSTRING = ^IMapView_2__HSTRING__HSTRING;

  // External: Windows.Globalization.ILanguage
  ILanguage = interface;
  PILanguage = ^ILanguage;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Globalization.ILanguage>
  IVectorView_1__ILanguage = interface;
  PIVectorView_1__ILanguage = ^IVectorView_1__ILanguage;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Storage.IStorageFile>
  IVector_1__IStorageFile = interface;
  PIVector_1__IStorageFile = ^IVector_1__IStorageFile;

  // External: Windows.Media.Effects.IAudioCaptureEffectsManager
  Effects_IAudioCaptureEffectsManager = interface;
  PEffects_IAudioCaptureEffectsManager = ^Effects_IAudioCaptureEffectsManager;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Effects.IAudioCaptureEffectsManager,Object>
  TypedEventHandler_2__Effects_IAudioCaptureEffectsManager__IInspectable = interface;
  PTypedEventHandler_2__Effects_IAudioCaptureEffectsManager__IInspectable = ^TypedEventHandler_2__Effects_IAudioCaptureEffectsManager__IInspectable;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Effects.IAudioEffect>
  IVectorView_1__Effects_IAudioEffect = interface;
  PIVectorView_1__Effects_IAudioEffect = ^IVectorView_1__Effects_IAudioEffect;

  // External: Windows.Media.Effects.IAudioEffect
  Effects_IAudioEffect = interface;
  PEffects_IAudioEffect = ^Effects_IAudioEffect;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.IAudioStreamDescriptor>
  IIterable_1__Core_IAudioStreamDescriptor = interface;
  PIIterable_1__Core_IAudioStreamDescriptor = ^IIterable_1__Core_IAudioStreamDescriptor;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.IAudioStreamDescriptor>
  IIterator_1__Core_IAudioStreamDescriptor = interface;
  PIIterator_1__Core_IAudioStreamDescriptor = ^IIterator_1__Core_IAudioStreamDescriptor;

  // External: Windows.Media.Core.IAudioStreamDescriptor
  Core_IAudioStreamDescriptor = interface;
  PCore_IAudioStreamDescriptor = ^Core_IAudioStreamDescriptor;

  // External: Windows.Media.MediaProperties.IAudioEncodingProperties
  IAudioEncodingProperties = interface;
  PIAudioEncodingProperties = ^IAudioEncodingProperties;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Media.Core.IAudioStreamDescriptor>
  IVector_1__Core_IAudioStreamDescriptor = interface;
  PIVector_1__Core_IAudioStreamDescriptor = ^IVector_1__Core_IAudioStreamDescriptor;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IAudioStreamDescriptor>
  IVectorView_1__Core_IAudioStreamDescriptor = interface;
  PIVectorView_1__Core_IAudioStreamDescriptor = ^IVectorView_1__Core_IAudioStreamDescriptor;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.IVideoStreamDescriptor>
  IIterable_1__Core_IVideoStreamDescriptor = interface;
  PIIterable_1__Core_IVideoStreamDescriptor = ^IIterable_1__Core_IVideoStreamDescriptor;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.IVideoStreamDescriptor>
  IIterator_1__Core_IVideoStreamDescriptor = interface;
  PIIterator_1__Core_IVideoStreamDescriptor = ^IIterator_1__Core_IVideoStreamDescriptor;

  // External: Windows.Media.Core.IVideoStreamDescriptor
  Core_IVideoStreamDescriptor = interface;
  PCore_IVideoStreamDescriptor = ^Core_IVideoStreamDescriptor;

  // External: Windows.Media.MediaProperties.IVideoEncodingProperties
  IVideoEncodingProperties = interface;
  PIVideoEncodingProperties = ^IVideoEncodingProperties;

  // External: Windows.Media.MediaProperties.IMediaRatio
  IMediaRatio = interface;
  PIMediaRatio = ^IMediaRatio;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Media.Core.IVideoStreamDescriptor>
  IVector_1__Core_IVideoStreamDescriptor = interface;
  PIVector_1__Core_IVideoStreamDescriptor = ^IVector_1__Core_IVideoStreamDescriptor;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IVideoStreamDescriptor>
  IVectorView_1__Core_IVideoStreamDescriptor = interface;
  PIVectorView_1__Core_IVideoStreamDescriptor = ^IVectorView_1__Core_IVideoStreamDescriptor;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  IIterable_1__Core_ITimedMetadataStreamDescriptor = interface;
  PIIterable_1__Core_ITimedMetadataStreamDescriptor = ^IIterable_1__Core_ITimedMetadataStreamDescriptor;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  IIterator_1__Core_ITimedMetadataStreamDescriptor = interface;
  PIIterator_1__Core_ITimedMetadataStreamDescriptor = ^IIterator_1__Core_ITimedMetadataStreamDescriptor;

  // External: Windows.Media.Core.ITimedMetadataStreamDescriptor
  Core_ITimedMetadataStreamDescriptor = interface;
  PCore_ITimedMetadataStreamDescriptor = ^Core_ITimedMetadataStreamDescriptor;

  // External: Windows.Media.MediaProperties.ITimedMetadataEncodingProperties
  ITimedMetadataEncodingProperties = interface;
  PITimedMetadataEncodingProperties = ^ITimedMetadataEncodingProperties;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  IVector_1__Core_ITimedMetadataStreamDescriptor = interface;
  PIVector_1__Core_ITimedMetadataStreamDescriptor = ^IVector_1__Core_ITimedMetadataStreamDescriptor;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  IVectorView_1__Core_ITimedMetadataStreamDescriptor = interface;
  PIVectorView_1__Core_ITimedMetadataStreamDescriptor = ^IVectorView_1__Core_ITimedMetadataStreamDescriptor;

  // External: Windows.Networking.IHostName
  IHostName = interface;
  PIHostName = ^IHostName;

  // External: Windows.Networking.Connectivity.IIPInformation
  IIPInformation = interface;
  PIIPInformation = ^IIPInformation;

  // External: Windows.Networking.Connectivity.INetworkAdapter
  INetworkAdapter = interface;
  PINetworkAdapter = ^INetworkAdapter;

  // External: Windows.Networking.Connectivity.INetworkItem
  INetworkItem = interface;
  PINetworkItem = ^INetworkItem;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Networking.Connectivity.IConnectionProfile>
  IAsyncOperation_1__IConnectionProfile = interface;
  PIAsyncOperation_1__IConnectionProfile = ^IAsyncOperation_1__IConnectionProfile;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.Connectivity.IConnectionProfile>
  AsyncOperationCompletedHandler_1__IConnectionProfile = interface;
  PAsyncOperationCompletedHandler_1__IConnectionProfile = ^AsyncOperationCompletedHandler_1__IConnectionProfile;

  // External: Windows.Networking.Connectivity.IConnectionProfile
  IConnectionProfile = interface;
  PIConnectionProfile = ^IConnectionProfile;

  // External: Windows.Networking.Connectivity.IConnectionCost
  IConnectionCost = interface;
  PIConnectionCost = ^IConnectionCost;

  // External: Windows.Networking.Connectivity.IDataPlanStatus
  IDataPlanStatus = interface;
  PIDataPlanStatus = ^IDataPlanStatus;

  // External: Windows.Networking.Connectivity.IDataPlanUsage
  IDataPlanUsage = interface;
  PIDataPlanUsage = ^IDataPlanUsage;

  // External: Windows.Foundation.IReference`1<UInt32>
  IReference_1__Cardinal = interface;
  PIReference_1__Cardinal = ^IReference_1__Cardinal;

  // External: Windows.Foundation.IReference`1<UInt64>
  IReference_1__UInt64 = interface;
  PIReference_1__UInt64 = ^IReference_1__UInt64;

  // External: Windows.Foundation.IReference`1<Windows.Foundation.DateTime>
  IReference_1__DateTime = interface;
  PIReference_1__DateTime = ^IReference_1__DateTime;

  // External: Windows.Networking.Connectivity.IDataUsage
  IDataUsage = interface;
  PIDataUsage = ^IDataUsage;

  // External: Windows.Networking.Connectivity.INetworkSecuritySettings
  INetworkSecuritySettings = interface;
  PINetworkSecuritySettings = ^INetworkSecuritySettings;

  // External: Windows.Foundation.IReference`1<UInt8>
  IReference_1__Byte = interface;
  PIReference_1__Byte = ^IReference_1__Byte;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IHostName>
  IVectorView_1__IHostName = interface;
  PIVectorView_1__IHostName = ^IVectorView_1__IHostName;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>
  IVectorView_1__IEndpointPair = interface;
  PIVectorView_1__IEndpointPair = ^IVectorView_1__IEndpointPair;

  // External: Windows.Networking.IEndpointPair
  IEndpointPair = interface;
  PIEndpointPair = ^IEndpointPair;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Networking.IEndpointPair>
  IIterable_1__IEndpointPair = interface;
  PIIterable_1__IEndpointPair = ^IIterable_1__IEndpointPair;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Networking.IEndpointPair>
  IIterator_1__IEndpointPair = interface;
  PIIterator_1__IEndpointPair = ^IIterator_1__IEndpointPair;

  // External: Windows.System.IDispatcherQueue
  IDispatcherQueue = interface;
  PIDispatcherQueue = ^IDispatcherQueue;

  // External: Windows.System.IDispatcherQueueTimer
  IDispatcherQueueTimer = interface;
  PIDispatcherQueueTimer = ^IDispatcherQueueTimer;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueueTimer,Object>
  TypedEventHandler_2__IDispatcherQueueTimer__IInspectable = interface;
  PTypedEventHandler_2__IDispatcherQueueTimer__IInspectable = ^TypedEventHandler_2__IDispatcherQueueTimer__IInspectable;

  // External: Windows.System.DispatcherQueueHandler
  DispatcherQueueHandler = interface;
  PDispatcherQueueHandler = ^DispatcherQueueHandler;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueue,Windows.System.IDispatcherQueueShutdownStartingEventArgs>
  TypedEventHandler_2__IDispatcherQueue__IDispatcherQueueShutdownStartingEventArgs = interface;
  PTypedEventHandler_2__IDispatcherQueue__IDispatcherQueueShutdownStartingEventArgs = ^TypedEventHandler_2__IDispatcherQueue__IDispatcherQueueShutdownStartingEventArgs;

  // External: Windows.System.IDispatcherQueueShutdownStartingEventArgs
  IDispatcherQueueShutdownStartingEventArgs = interface;
  PIDispatcherQueueShutdownStartingEventArgs = ^IDispatcherQueueShutdownStartingEventArgs;

  // External: Windows.Foundation.IDeferral
  IDeferral = interface;
  PIDeferral = ^IDeferral;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueue,Object>
  TypedEventHandler_2__IDispatcherQueue__IInspectable = interface;
  PTypedEventHandler_2__IDispatcherQueue__IInspectable = ^TypedEventHandler_2__IDispatcherQueue__IInspectable;

  // External: Windows.Graphics.Effects.IGraphicsEffect
  Effects_IGraphicsEffect = interface;
  PEffects_IGraphicsEffect = ^Effects_IGraphicsEffect;

  // External: Windows.Graphics.Effects.IGraphicsEffectSource
  Effects_IGraphicsEffectSource = interface;
  PEffects_IGraphicsEffectSource = ^Effects_IGraphicsEffectSource;

  // External: Windows.Graphics.IGeometrySource2D
  IGeometrySource2D = interface;
  PIGeometrySource2D = ^IGeometrySource2D;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkUnprocessedInput,Windows.UI.Core.IPointerEventArgs>
  TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs = interface;
  PTypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs = ^TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs;

  // External: Windows.UI.Input.Inking.IInkUnprocessedInput
  IInkUnprocessedInput = interface;
  PIInkUnprocessedInput = ^IInkUnprocessedInput;

  // External: Windows.UI.Input.Inking.IInkPresenter
  IInkPresenter = interface;
  PIInkPresenter = ^IInkPresenter;

  // External: Windows.UI.Input.Inking.IInkStrokeInput
  IInkStrokeInput = interface;
  PIInkStrokeInput = ^IInkStrokeInput;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkStrokeInput,Windows.UI.Core.IPointerEventArgs>
  TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs = interface;
  PTypedEventHandler_2__IInkStrokeInput__IPointerEventArgs = ^TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs;

  // External: Windows.UI.Input.Inking.IInkInputProcessingConfiguration
  IInkInputProcessingConfiguration = interface;
  PIInkInputProcessingConfiguration = ^IInkInputProcessingConfiguration;

  // External: Windows.UI.Input.Inking.IInkStrokeContainer
  IInkStrokeContainer = interface;
  PIInkStrokeContainer = ^IInkStrokeContainer;

  // External: Windows.UI.Input.Inking.IInkStroke
  IInkStroke = interface;
  PIInkStroke = ^IInkStroke;

  // External: Windows.UI.Input.Inking.IInkDrawingAttributes
  IInkDrawingAttributes = interface;
  PIInkDrawingAttributes = ^IInkDrawingAttributes;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkStrokeRenderingSegment>
  IVectorView_1__IInkStrokeRenderingSegment = interface;
  PIVectorView_1__IInkStrokeRenderingSegment = ^IVectorView_1__IInkStrokeRenderingSegment;

  // External: Windows.UI.Input.Inking.IInkStrokeRenderingSegment
  IInkStrokeRenderingSegment = interface;
  PIInkStrokeRenderingSegment = ^IInkStrokeRenderingSegment;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>
  IIterable_1__Point = interface;
  PIIterable_1__Point = ^IIterable_1__Point;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Point>
  IIterator_1__Point = interface;
  PIIterator_1__Point = ^IIterator_1__Point;

  // External: Windows.Foundation.IAsyncActionWithProgress`1<UInt64>
  IAsyncActionWithProgress_1__UInt64 = interface;
  PIAsyncActionWithProgress_1__UInt64 = ^IAsyncActionWithProgress_1__UInt64;

  // External: Windows.Foundation.AsyncActionProgressHandler`1<UInt64>
  AsyncActionProgressHandler_1__UInt64 = interface;
  PAsyncActionProgressHandler_1__UInt64 = ^AsyncActionProgressHandler_1__UInt64;

  // External: Windows.Foundation.AsyncActionWithProgressCompletedHandler`1<UInt64>
  AsyncActionWithProgressCompletedHandler_1__UInt64 = interface;
  PAsyncActionWithProgressCompletedHandler_1__UInt64 = ^AsyncActionWithProgressCompletedHandler_1__UInt64;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkRecognitionResult>
  IVectorView_1__IInkRecognitionResult = interface;
  PIVectorView_1__IInkRecognitionResult = ^IVectorView_1__IInkRecognitionResult;

  // External: Windows.UI.Input.Inking.IInkRecognitionResult
  IInkRecognitionResult = interface;
  PIInkRecognitionResult = ^IInkRecognitionResult;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkStroke>
  IVectorView_1__IInkStroke = interface;
  PIVectorView_1__IInkStroke = ^IVectorView_1__IInkStroke;

  // External: Windows.UI.Input.Inking.IInkSynchronizer
  IInkSynchronizer = interface;
  PIInkSynchronizer = ^IInkSynchronizer;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkPresenter,Windows.UI.Input.Inking.IInkStrokesCollectedEventArgs>
  TypedEventHandler_2__IInkPresenter__IInkStrokesCollectedEventArgs = interface;
  PTypedEventHandler_2__IInkPresenter__IInkStrokesCollectedEventArgs = ^TypedEventHandler_2__IInkPresenter__IInkStrokesCollectedEventArgs;

  // External: Windows.UI.Input.Inking.IInkStrokesCollectedEventArgs
  IInkStrokesCollectedEventArgs = interface;
  PIInkStrokesCollectedEventArgs = ^IInkStrokesCollectedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkPresenter,Windows.UI.Input.Inking.IInkStrokesErasedEventArgs>
  TypedEventHandler_2__IInkPresenter__IInkStrokesErasedEventArgs = interface;
  PTypedEventHandler_2__IInkPresenter__IInkStrokesErasedEventArgs = ^TypedEventHandler_2__IInkPresenter__IInkStrokesErasedEventArgs;

  // External: Windows.UI.Input.Inking.IInkStrokesErasedEventArgs
  IInkStrokesErasedEventArgs = interface;
  PIInkStrokesErasedEventArgs = ^IInkStrokesErasedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.Core.ICoreInkIndependentInputSource,Windows.UI.Core.IPointerEventArgs>
  TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs = interface;
  PTypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs = ^TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs;

  // External: Windows.UI.Input.Inking.Core.ICoreInkIndependentInputSource
  Core_ICoreInkIndependentInputSource = interface;
  PCore_ICoreInkIndependentInputSource = ^Core_ICoreInkIndependentInputSource;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.ITouchpadGesturesController,Windows.UI.Core.IPointerEventArgs>
  TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs = interface;
  PTypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs = ^TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs;

  // External: Windows.UI.Input.ITouchpadGesturesController
  ITouchpadGesturesController = interface;
  PITouchpadGesturesController = ^ITouchpadGesturesController;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.ITouchpadGesturesController,Windows.UI.Input.ITouchpadGlobalActionEventArgs>
  TypedEventHandler_2__ITouchpadGesturesController__ITouchpadGlobalActionEventArgs = interface;
  PTypedEventHandler_2__ITouchpadGesturesController__ITouchpadGlobalActionEventArgs = ^TypedEventHandler_2__ITouchpadGesturesController__ITouchpadGlobalActionEventArgs;

  // External: Windows.UI.Input.ITouchpadGlobalActionEventArgs
  ITouchpadGlobalActionEventArgs = interface;
  PITouchpadGlobalActionEventArgs = ^ITouchpadGlobalActionEventArgs;

  // External: Windows.UI.Xaml.IStyle
  IStyle = interface;
  PIStyle = ^IStyle;

  // External: Windows.UI.Xaml.ISetterBaseCollection
  ISetterBaseCollection = interface;
  PISetterBaseCollection = ^ISetterBaseCollection;

  // External: Windows.UI.Xaml.Input.ICommand
  Input_ICommand = interface;
  PInput_ICommand = ^Input_ICommand;

  // External: Windows.Foundation.EventHandler`1<Object>
  EventHandler_1__IInspectable = interface;
  PEventHandler_1__IInspectable = ^EventHandler_1__IInspectable;

  // External: Windows.UI.Xaml.RoutedEventHandler
  RoutedEventHandler = interface;
  PRoutedEventHandler = ^RoutedEventHandler;

  // External: Windows.UI.Xaml.IRoutedEventArgs
  IRoutedEventArgs = interface;
  PIRoutedEventArgs = ^IRoutedEventArgs;

  // External: Windows.UI.Xaml.IDataTemplate
  IDataTemplate = interface;
  PIDataTemplate = ^IDataTemplate;

  // External: Windows.UI.Xaml.IDependencyObject
  IDependencyObject = interface;
  PIDependencyObject = ^IDependencyObject;

  // External: Windows.UI.Xaml.IDependencyProperty
  IDependencyProperty = interface;
  PIDependencyProperty = ^IDependencyProperty;

  // External: Windows.UI.Xaml.IPropertyMetadata
  IPropertyMetadata = interface;
  PIPropertyMetadata = ^IPropertyMetadata;

  // External: Windows.UI.Xaml.CreateDefaultValueCallback
  CreateDefaultValueCallback = interface;
  PCreateDefaultValueCallback = ^CreateDefaultValueCallback;

  // External: Windows.UI.Xaml.ExceptionRoutedEventHandler
  ExceptionRoutedEventHandler = interface;
  PExceptionRoutedEventHandler = ^ExceptionRoutedEventHandler;

  // External: Windows.UI.Xaml.IExceptionRoutedEventArgs
  IExceptionRoutedEventArgs = interface;
  PIExceptionRoutedEventArgs = ^IExceptionRoutedEventArgs;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.UI.Xaml.Data.LoadMoreItemsResult>
  IAsyncOperation_1__Data_LoadMoreItemsResult = interface;
  PIAsyncOperation_1__Data_LoadMoreItemsResult = ^IAsyncOperation_1__Data_LoadMoreItemsResult;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.UI.Xaml.Data.LoadMoreItemsResult>
  AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult = interface;
  PAsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult = ^AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult;

  // External: Windows.UI.Xaml.Input.IInputScope
  Input_IInputScope = interface;
  PInput_IInputScope = ^Input_IInputScope;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Input.IInputScopeName>
  IVector_1__Input_IInputScopeName = interface;
  PIVector_1__Input_IInputScopeName = ^IVector_1__Input_IInputScopeName;

  // External: Windows.UI.Xaml.Input.IInputScopeName
  Input_IInputScopeName = interface;
  PInput_IInputScopeName = ^Input_IInputScopeName;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Input.IInputScopeName>
  IVectorView_1__Input_IInputScopeName = interface;
  PIVectorView_1__Input_IInputScopeName = ^IVectorView_1__Input_IInputScopeName;

  // External: Windows.UI.Xaml.Documents.ITextPointer
  Documents_ITextPointer = interface;
  PDocuments_ITextPointer = ^Documents_ITextPointer;

  // External: Windows.UI.Xaml.IFrameworkElement
  IFrameworkElement = interface;
  PIFrameworkElement = ^IFrameworkElement;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.ITriggerBase>
  IVector_1__ITriggerBase = interface;
  PIVector_1__ITriggerBase = ^IVector_1__ITriggerBase;

  // External: Windows.UI.Xaml.ITriggerBase
  ITriggerBase = interface;
  PITriggerBase = ^ITriggerBase;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.ITriggerBase>
  IVectorView_1__ITriggerBase = interface;
  PIVectorView_1__ITriggerBase = ^IVectorView_1__ITriggerBase;

  // External: Windows.UI.Xaml.IResourceDictionary
  IResourceDictionary = interface;
  PIResourceDictionary = ^IResourceDictionary;

  // External: Windows.Foundation.IUriRuntimeClass
  IUriRuntimeClass = interface;
  PIUriRuntimeClass = ^IUriRuntimeClass;

  // External: Windows.Foundation.IWwwFormUrlDecoderRuntimeClass
  IWwwFormUrlDecoderRuntimeClass = interface;
  PIWwwFormUrlDecoderRuntimeClass = ^IWwwFormUrlDecoderRuntimeClass;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IResourceDictionary>
  IVector_1__IResourceDictionary = interface;
  PIVector_1__IResourceDictionary = ^IVector_1__IResourceDictionary;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IResourceDictionary>
  IVectorView_1__IResourceDictionary = interface;
  PIVectorView_1__IResourceDictionary = ^IVectorView_1__IResourceDictionary;

  // External: Windows.Foundation.Collections.IMap`2<Object,Object>
  IMap_2__IInspectable__IInspectable = interface;
  PIMap_2__IInspectable__IInspectable = ^IMap_2__IInspectable__IInspectable;

  // External: Windows.Foundation.Collections.IMapView`2<Object,Object>
  IMapView_2__IInspectable__IInspectable = interface;
  PIMapView_2__IInspectable__IInspectable = ^IMapView_2__IInspectable__IInspectable;

  // External: Windows.UI.Xaml.SizeChangedEventHandler
  SizeChangedEventHandler = interface;
  PSizeChangedEventHandler = ^SizeChangedEventHandler;

  // External: Windows.UI.Xaml.ISizeChangedEventArgs
  ISizeChangedEventArgs = interface;
  PISizeChangedEventArgs = ^ISizeChangedEventArgs;

  // External: Windows.UI.Xaml.Data.IBindingBase
  Data_IBindingBase = interface;
  PData_IBindingBase = ^Data_IBindingBase;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.IBlock>
  IVector_1__Documents_IBlock = interface;
  PIVector_1__Documents_IBlock = ^IVector_1__Documents_IBlock;

  // External: Windows.UI.Xaml.Documents.IBlock
  Documents_IBlock = interface;
  PDocuments_IBlock = ^Documents_IBlock;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.IBlock>
  IVectorView_1__Documents_IBlock = interface;
  PIVectorView_1__Documents_IBlock = ^IVectorView_1__Documents_IBlock;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.IRoutedEventArgs>
  TypedEventHandler_2__ISearchBox__IRoutedEventArgs = interface;
  PTypedEventHandler_2__ISearchBox__IRoutedEventArgs = ^TypedEventHandler_2__ISearchBox__IRoutedEventArgs;

  // External: Windows.UI.Xaml.Controls.ISearchBox
  ISearchBox = interface;
  PISearchBox = ^ISearchBox;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxQueryChangedEventArgs>
  TypedEventHandler_2__ISearchBox__ISearchBoxQueryChangedEventArgs = interface;
  PTypedEventHandler_2__ISearchBox__ISearchBoxQueryChangedEventArgs = ^TypedEventHandler_2__ISearchBox__ISearchBoxQueryChangedEventArgs;

  // External: Windows.UI.Xaml.Controls.ISearchBoxQueryChangedEventArgs
  ISearchBoxQueryChangedEventArgs = interface;
  PISearchBoxQueryChangedEventArgs = ^ISearchBoxQueryChangedEventArgs;

  // External: Windows.ApplicationModel.Search.ISearchQueryLinguisticDetails
  Search_ISearchQueryLinguisticDetails = interface;
  PSearch_ISearchQueryLinguisticDetails = ^Search_ISearchQueryLinguisticDetails;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxSuggestionsRequestedEventArgs>
  TypedEventHandler_2__ISearchBox__ISearchBoxSuggestionsRequestedEventArgs = interface;
  PTypedEventHandler_2__ISearchBox__ISearchBoxSuggestionsRequestedEventArgs = ^TypedEventHandler_2__ISearchBox__ISearchBoxSuggestionsRequestedEventArgs;

  // External: Windows.UI.Xaml.Controls.ISearchBoxSuggestionsRequestedEventArgs
  ISearchBoxSuggestionsRequestedEventArgs = interface;
  PISearchBoxSuggestionsRequestedEventArgs = ^ISearchBoxSuggestionsRequestedEventArgs;

  // External: Windows.ApplicationModel.Search.ISearchSuggestionsRequest
  Search_ISearchSuggestionsRequest = interface;
  PSearch_ISearchSuggestionsRequest = ^Search_ISearchSuggestionsRequest;

  // External: Windows.ApplicationModel.Search.ISearchSuggestionCollection
  Search_ISearchSuggestionCollection = interface;
  PSearch_ISearchSuggestionCollection = ^Search_ISearchSuggestionCollection;

  // External: Windows.ApplicationModel.Search.ISearchSuggestionsRequestDeferral
  Search_ISearchSuggestionsRequestDeferral = interface;
  PSearch_ISearchSuggestionsRequestDeferral = ^Search_ISearchSuggestionsRequestDeferral;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxQuerySubmittedEventArgs>
  TypedEventHandler_2__ISearchBox__ISearchBoxQuerySubmittedEventArgs = interface;
  PTypedEventHandler_2__ISearchBox__ISearchBoxQuerySubmittedEventArgs = ^TypedEventHandler_2__ISearchBox__ISearchBoxQuerySubmittedEventArgs;

  // External: Windows.UI.Xaml.Controls.ISearchBoxQuerySubmittedEventArgs
  ISearchBoxQuerySubmittedEventArgs = interface;
  PISearchBoxQuerySubmittedEventArgs = ^ISearchBoxQuerySubmittedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxResultSuggestionChosenEventArgs>
  TypedEventHandler_2__ISearchBox__ISearchBoxResultSuggestionChosenEventArgs = interface;
  PTypedEventHandler_2__ISearchBox__ISearchBoxResultSuggestionChosenEventArgs = ^TypedEventHandler_2__ISearchBox__ISearchBoxResultSuggestionChosenEventArgs;

  // External: Windows.UI.Xaml.Controls.ISearchBoxResultSuggestionChosenEventArgs
  ISearchBoxResultSuggestionChosenEventArgs = interface;
  PISearchBoxResultSuggestionChosenEventArgs = ^ISearchBoxResultSuggestionChosenEventArgs;

  // External: Windows.ApplicationModel.Search.ILocalContentSuggestionSettings
  Search_ILocalContentSuggestionSettings = interface;
  PSearch_ILocalContentSuggestionSettings = ^Search_ILocalContentSuggestionSettings;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Storage.IStorageFolder>
  IVector_1__IStorageFolder = interface;
  PIVector_1__IStorageFolder = ^IVector_1__IStorageFolder;

  // External: Windows.UI.Xaml.Data.IValueConverter
  Data_IValueConverter = interface;
  PData_IValueConverter = ^Data_IValueConverter;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.IInline>
  IVector_1__Documents_IInline = interface;
  PIVector_1__Documents_IInline = ^IVector_1__Documents_IInline;

  // External: Windows.UI.Xaml.Documents.IInline
  Documents_IInline = interface;
  PDocuments_IInline = ^Documents_IInline;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.IInline>
  IVectorView_1__Documents_IInline = interface;
  PIVectorView_1__Documents_IInline = ^IVectorView_1__Documents_IInline;

  // External: Windows.UI.Xaml.IUIElement
  IUIElement = interface;
  PIUIElement = ^IUIElement;

  // External: Windows.UI.Xaml.Media.IRectangleGeometry
  IRectangleGeometry = interface;
  PIRectangleGeometry = ^IRectangleGeometry;

  // External: Windows.UI.Xaml.Media.ITransform
  ITransform = interface;
  PITransform = ^ITransform;

  // External: Windows.UI.Xaml.Media.IProjection
  IProjection = interface;
  PIProjection = ^IProjection;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.Animation.ITransition>
  IVector_1__Animation_ITransition = interface;
  PIVector_1__Animation_ITransition = ^IVector_1__Animation_ITransition;

  // External: Windows.UI.Xaml.Media.Animation.ITransition
  Animation_ITransition = interface;
  PAnimation_ITransition = ^Animation_ITransition;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Media.Animation.ITransition>
  IVectorView_1__Animation_ITransition = interface;
  PIVectorView_1__Animation_ITransition = ^IVectorView_1__Animation_ITransition;

  // External: Windows.UI.Xaml.Media.ICacheMode
  ICacheMode = interface;
  PICacheMode = ^ICacheMode;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Input.IPointer>
  IVectorView_1__Input_IPointer = interface;
  PIVectorView_1__Input_IPointer = ^IVectorView_1__Input_IPointer;

  // External: Windows.UI.Xaml.Input.IPointer
  Input_IPointer = interface;
  PInput_IPointer = ^Input_IPointer;

  // External: Windows.UI.Xaml.Input.KeyEventHandler
  Input_KeyEventHandler = interface;
  PInput_KeyEventHandler = ^Input_KeyEventHandler;

  // External: Windows.UI.Xaml.Input.IKeyRoutedEventArgs
  Input_IKeyRoutedEventArgs = interface;
  PInput_IKeyRoutedEventArgs = ^Input_IKeyRoutedEventArgs;

  // External: Windows.UI.Xaml.DragEventHandler
  DragEventHandler = interface;
  PDragEventHandler = ^DragEventHandler;

  // External: Windows.UI.Xaml.IDragEventArgs
  IDragEventArgs = interface;
  PIDragEventArgs = ^IDragEventArgs;

  // External: Windows.ApplicationModel.DataTransfer.IDataPackage
  IDataPackage = interface;
  PIDataPackage = ^IDataPackage;

  // External: Windows.ApplicationModel.DataTransfer.IDataPackageView
  IDataPackageView = interface;
  PIDataPackageView = ^IDataPackageView;

  // External: Windows.ApplicationModel.DataTransfer.IDataPackagePropertySetView
  IDataPackagePropertySetView = interface;
  PIDataPackagePropertySetView = ^IDataPackagePropertySetView;

  // External: Windows.Foundation.IAsyncOperation`1<String>
  IAsyncOperation_1__HSTRING = interface;
  PIAsyncOperation_1__HSTRING = ^IAsyncOperation_1__HSTRING;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<String>
  AsyncOperationCompletedHandler_1__HSTRING = interface;
  PAsyncOperationCompletedHandler_1__HSTRING = ^AsyncOperationCompletedHandler_1__HSTRING;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IUriRuntimeClass>
  IAsyncOperation_1__IUriRuntimeClass = interface;
  PIAsyncOperation_1__IUriRuntimeClass = ^IAsyncOperation_1__IUriRuntimeClass;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IUriRuntimeClass>
  AsyncOperationCompletedHandler_1__IUriRuntimeClass = interface;
  PAsyncOperationCompletedHandler_1__IUriRuntimeClass = ^AsyncOperationCompletedHandler_1__IUriRuntimeClass;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference = interface;
  PIAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference = ^IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference = interface;
  PAsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference = ^AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference;

  // External: Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  IMapView_2__HSTRING__IRandomAccessStreamReference = interface;
  PIMapView_2__HSTRING__IRandomAccessStreamReference = ^IMapView_2__HSTRING__IRandomAccessStreamReference;

  // External: Windows.ApplicationModel.DataTransfer.IDataPackagePropertySet
  IDataPackagePropertySet = interface;
  PIDataPackagePropertySet = ^IDataPackagePropertySet;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.IDataPackage,Windows.ApplicationModel.DataTransfer.IOperationCompletedEventArgs>
  TypedEventHandler_2__IDataPackage__IOperationCompletedEventArgs = interface;
  PTypedEventHandler_2__IDataPackage__IOperationCompletedEventArgs = ^TypedEventHandler_2__IDataPackage__IOperationCompletedEventArgs;

  // External: Windows.ApplicationModel.DataTransfer.IOperationCompletedEventArgs
  IOperationCompletedEventArgs = interface;
  PIOperationCompletedEventArgs = ^IOperationCompletedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.IDataPackage,Object>
  TypedEventHandler_2__IDataPackage__IInspectable = interface;
  PTypedEventHandler_2__IDataPackage__IInspectable = ^TypedEventHandler_2__IDataPackage__IInspectable;

  // External: Windows.ApplicationModel.DataTransfer.DataProviderHandler
  DataProviderHandler = interface;
  PDataProviderHandler = ^DataProviderHandler;

  // External: Windows.ApplicationModel.DataTransfer.IDataProviderRequest
  IDataProviderRequest = interface;
  PIDataProviderRequest = ^IDataProviderRequest;

  // External: Windows.ApplicationModel.DataTransfer.IDataProviderDeferral
  IDataProviderDeferral = interface;
  PIDataProviderDeferral = ^IDataProviderDeferral;

  // External: Windows.Foundation.Collections.IMap`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  IMap_2__HSTRING__IRandomAccessStreamReference = interface;
  PIMap_2__HSTRING__IRandomAccessStreamReference = ^IMap_2__HSTRING__IRandomAccessStreamReference;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.Storage.IStorageItem>
  IIterable_1__IStorageItem = interface;
  PIIterable_1__IStorageItem = ^IIterable_1__IStorageItem;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.Storage.IStorageItem>
  IIterator_1__IStorageItem = interface;
  PIIterator_1__IStorageItem = ^IIterator_1__IStorageItem;

  // External: Windows.UI.Xaml.Input.PointerEventHandler
  Input_PointerEventHandler = interface;
  PInput_PointerEventHandler = ^Input_PointerEventHandler;

  // External: Windows.UI.Xaml.Input.IPointerRoutedEventArgs
  Input_IPointerRoutedEventArgs = interface;
  PInput_IPointerRoutedEventArgs = ^Input_IPointerRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.TappedEventHandler
  Input_TappedEventHandler = interface;
  PInput_TappedEventHandler = ^Input_TappedEventHandler;

  // External: Windows.UI.Xaml.Input.ITappedRoutedEventArgs
  Input_ITappedRoutedEventArgs = interface;
  PInput_ITappedRoutedEventArgs = ^Input_ITappedRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.DoubleTappedEventHandler
  Input_DoubleTappedEventHandler = interface;
  PInput_DoubleTappedEventHandler = ^Input_DoubleTappedEventHandler;

  // External: Windows.UI.Xaml.Input.IDoubleTappedRoutedEventArgs
  Input_IDoubleTappedRoutedEventArgs = interface;
  PInput_IDoubleTappedRoutedEventArgs = ^Input_IDoubleTappedRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.HoldingEventHandler
  Input_HoldingEventHandler = interface;
  PInput_HoldingEventHandler = ^Input_HoldingEventHandler;

  // External: Windows.UI.Xaml.Input.IHoldingRoutedEventArgs
  Input_IHoldingRoutedEventArgs = interface;
  PInput_IHoldingRoutedEventArgs = ^Input_IHoldingRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.RightTappedEventHandler
  Input_RightTappedEventHandler = interface;
  PInput_RightTappedEventHandler = ^Input_RightTappedEventHandler;

  // External: Windows.UI.Xaml.Input.IRightTappedRoutedEventArgs
  Input_IRightTappedRoutedEventArgs = interface;
  PInput_IRightTappedRoutedEventArgs = ^Input_IRightTappedRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.ManipulationStartingEventHandler
  Input_ManipulationStartingEventHandler = interface;
  PInput_ManipulationStartingEventHandler = ^Input_ManipulationStartingEventHandler;

  // External: Windows.UI.Xaml.Input.IManipulationStartingRoutedEventArgs
  Input_IManipulationStartingRoutedEventArgs = interface;
  PInput_IManipulationStartingRoutedEventArgs = ^Input_IManipulationStartingRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.IManipulationPivot
  Input_IManipulationPivot = interface;
  PInput_IManipulationPivot = ^Input_IManipulationPivot;

  // External: Windows.UI.Xaml.Input.ManipulationInertiaStartingEventHandler
  Input_ManipulationInertiaStartingEventHandler = interface;
  PInput_ManipulationInertiaStartingEventHandler = ^Input_ManipulationInertiaStartingEventHandler;

  // External: Windows.UI.Xaml.Input.IManipulationInertiaStartingRoutedEventArgs
  Input_IManipulationInertiaStartingRoutedEventArgs = interface;
  PInput_IManipulationInertiaStartingRoutedEventArgs = ^Input_IManipulationInertiaStartingRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.IInertiaExpansionBehavior
  Input_IInertiaExpansionBehavior = interface;
  PInput_IInertiaExpansionBehavior = ^Input_IInertiaExpansionBehavior;

  // External: Windows.UI.Xaml.Input.IInertiaRotationBehavior
  Input_IInertiaRotationBehavior = interface;
  PInput_IInertiaRotationBehavior = ^Input_IInertiaRotationBehavior;

  // External: Windows.UI.Xaml.Input.IInertiaTranslationBehavior
  Input_IInertiaTranslationBehavior = interface;
  PInput_IInertiaTranslationBehavior = ^Input_IInertiaTranslationBehavior;

  // External: Windows.UI.Xaml.Input.ManipulationStartedEventHandler
  Input_ManipulationStartedEventHandler = interface;
  PInput_ManipulationStartedEventHandler = ^Input_ManipulationStartedEventHandler;

  // External: Windows.UI.Xaml.Input.IManipulationStartedRoutedEventArgs
  Input_IManipulationStartedRoutedEventArgs = interface;
  PInput_IManipulationStartedRoutedEventArgs = ^Input_IManipulationStartedRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.ManipulationDeltaEventHandler
  Input_ManipulationDeltaEventHandler = interface;
  PInput_ManipulationDeltaEventHandler = ^Input_ManipulationDeltaEventHandler;

  // External: Windows.UI.Xaml.Input.IManipulationDeltaRoutedEventArgs
  Input_IManipulationDeltaRoutedEventArgs = interface;
  PInput_IManipulationDeltaRoutedEventArgs = ^Input_IManipulationDeltaRoutedEventArgs;

  // External: Windows.UI.Xaml.Input.ManipulationCompletedEventHandler
  Input_ManipulationCompletedEventHandler = interface;
  PInput_ManipulationCompletedEventHandler = ^Input_ManipulationCompletedEventHandler;

  // External: Windows.UI.Xaml.Input.IManipulationCompletedRoutedEventArgs
  Input_IManipulationCompletedRoutedEventArgs = interface;
  PInput_IManipulationCompletedRoutedEventArgs = ^Input_IManipulationCompletedRoutedEventArgs;

  // External: Windows.UI.Xaml.IRoutedEvent
  IRoutedEvent = interface;
  PIRoutedEvent = ^IRoutedEvent;

  // External: Windows.UI.Xaml.Media.IGeneralTransform
  IGeneralTransform = interface;
  PIGeneralTransform = ^IGeneralTransform;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IUIElement>
  IVector_1__IUIElement = interface;
  PIVector_1__IUIElement = ^IVector_1__IUIElement;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IUIElement>
  IVectorView_1__IUIElement = interface;
  PIVectorView_1__IUIElement = ^IVectorView_1__IUIElement;

  // External: Windows.UI.Xaml.IBrushTransition
  IBrushTransition = interface;
  PIBrushTransition = ^IBrushTransition;

  // External: Windows.UI.Xaml.DependencyPropertyChangedEventHandler
  DependencyPropertyChangedEventHandler = interface;
  PDependencyPropertyChangedEventHandler = ^DependencyPropertyChangedEventHandler;

  // External: Windows.UI.Xaml.IDependencyPropertyChangedEventArgs
  IDependencyPropertyChangedEventArgs = interface;
  PIDependencyPropertyChangedEventArgs = ^IDependencyPropertyChangedEventArgs;

  // External: Windows.UI.Xaml.Input.ICharacterReceivedRoutedEventArgs
  Input_ICharacterReceivedRoutedEventArgs = interface;
  PInput_ICharacterReceivedRoutedEventArgs = ^Input_ICharacterReceivedRoutedEventArgs;

  // External: Windows.UI.Xaml.Navigation.NavigatedEventHandler
  Navigation_NavigatedEventHandler = interface;
  PNavigation_NavigatedEventHandler = ^Navigation_NavigatedEventHandler;

  // External: Windows.UI.Xaml.Navigation.INavigationEventArgs
  Navigation_INavigationEventArgs = interface;
  PNavigation_INavigationEventArgs = ^Navigation_INavigationEventArgs;

  // External: Windows.UI.Xaml.Navigation.NavigatingCancelEventHandler
  Navigation_NavigatingCancelEventHandler = interface;
  PNavigation_NavigatingCancelEventHandler = ^Navigation_NavigatingCancelEventHandler;

  // External: Windows.UI.Xaml.Navigation.INavigatingCancelEventArgs
  Navigation_INavigatingCancelEventArgs = interface;
  PNavigation_INavigatingCancelEventArgs = ^Navigation_INavigatingCancelEventArgs;

  // External: Windows.UI.Xaml.Navigation.NavigationFailedEventHandler
  Navigation_NavigationFailedEventHandler = interface;
  PNavigation_NavigationFailedEventHandler = ^Navigation_NavigationFailedEventHandler;

  // External: Windows.UI.Xaml.Navigation.INavigationFailedEventArgs
  Navigation_INavigationFailedEventArgs = interface;
  PNavigation_INavigationFailedEventArgs = ^Navigation_INavigationFailedEventArgs;

  // External: Windows.UI.Xaml.Navigation.NavigationStoppedEventHandler
  Navigation_NavigationStoppedEventHandler = interface;
  PNavigation_NavigationStoppedEventHandler = ^Navigation_NavigationStoppedEventHandler;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Navigation.IPageStackEntry>
  IVector_1__Navigation_IPageStackEntry = interface;
  PIVector_1__Navigation_IPageStackEntry = ^IVector_1__Navigation_IPageStackEntry;

  // External: Windows.UI.Xaml.Navigation.IPageStackEntry
  Navigation_IPageStackEntry = interface;
  PNavigation_IPageStackEntry = ^Navigation_IPageStackEntry;

  // External: Windows.UI.Xaml.Media.Animation.INavigationTransitionInfo
  Animation_INavigationTransitionInfo = interface;
  PAnimation_INavigationTransitionInfo = ^Animation_INavigationTransitionInfo;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Navigation.IPageStackEntry>
  IVectorView_1__Navigation_IPageStackEntry = interface;
  PIVectorView_1__Navigation_IPageStackEntry = ^IVectorView_1__Navigation_IPageStackEntry;

  // External: Windows.UI.Xaml.Navigation.IFrameNavigationOptions
  Navigation_IFrameNavigationOptions = interface;
  PNavigation_IFrameNavigationOptions = ^Navigation_IFrameNavigationOptions;

  // External: Windows.Foundation.Collections.IObservableVector`1<Windows.UI.Xaml.IDependencyObject>
  IObservableVector_1__IDependencyObject = interface;
  PIObservableVector_1__IDependencyObject = ^IObservableVector_1__IDependencyObject;

  // External: Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.UI.Xaml.IDependencyObject>
  VectorChangedEventHandler_1__IDependencyObject = interface;
  PVectorChangedEventHandler_1__IDependencyObject = ^VectorChangedEventHandler_1__IDependencyObject;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Data.IItemIndexRange>
  IVectorView_1__Data_IItemIndexRange = interface;
  PIVectorView_1__Data_IItemIndexRange = ^IVectorView_1__Data_IItemIndexRange;

  // External: Windows.UI.Xaml.Data.IItemIndexRange
  Data_IItemIndexRange = interface;
  PData_IItemIndexRange = ^Data_IItemIndexRange;

  // External: Windows.UI.Xaml.Documents.IContentLinkProviderCollection
  Documents_IContentLinkProviderCollection = interface;
  PDocuments_IContentLinkProviderCollection = ^Documents_IContentLinkProviderCollection;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.IRichEditBox,Windows.UI.Xaml.Documents.IContentLinkInvokedEventArgs>
  TypedEventHandler_2__IRichEditBox__Documents_IContentLinkInvokedEventArgs = interface;
  PTypedEventHandler_2__IRichEditBox__Documents_IContentLinkInvokedEventArgs = ^TypedEventHandler_2__IRichEditBox__Documents_IContentLinkInvokedEventArgs;

  // External: Windows.UI.Xaml.Controls.IRichEditBox
  IRichEditBox = interface;
  PIRichEditBox = ^IRichEditBox;

  // External: Windows.UI.Text.ITextDocument
  ITextDocument = interface;
  PITextDocument = ^ITextDocument;

  // External: Windows.UI.Text.ITextSelection
  ITextSelection = interface;
  PITextSelection = ^ITextSelection;

  // External: Windows.UI.Text.ITextCharacterFormat
  ITextCharacterFormat = interface;
  PITextCharacterFormat = ^ITextCharacterFormat;

  // External: Windows.UI.Text.ITextParagraphFormat
  ITextParagraphFormat = interface;
  PITextParagraphFormat = ^ITextParagraphFormat;

  // External: Windows.UI.Text.ITextRange
  ITextRange = interface;
  PITextRange = ^ITextRange;

  // External: Windows.UI.Xaml.Controls.ContextMenuOpeningEventHandler
  ContextMenuOpeningEventHandler = interface;
  PContextMenuOpeningEventHandler = ^ContextMenuOpeningEventHandler;

  // External: Windows.UI.Xaml.Controls.IContextMenuEventArgs
  IContextMenuEventArgs = interface;
  PIContextMenuEventArgs = ^IContextMenuEventArgs;

  // External: Windows.UI.Xaml.Documents.IContentLinkInvokedEventArgs
  Documents_IContentLinkInvokedEventArgs = interface;
  PDocuments_IContentLinkInvokedEventArgs = ^Documents_IContentLinkInvokedEventArgs;

  // External: Windows.UI.Text.IContentLinkInfo
  IContentLinkInfo = interface;
  PIContentLinkInfo = ^IContentLinkInfo;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.ITextHighlighter>
  IVector_1__Documents_ITextHighlighter = interface;
  PIVector_1__Documents_ITextHighlighter = ^IVector_1__Documents_ITextHighlighter;

  // External: Windows.UI.Xaml.Documents.ITextHighlighter
  Documents_ITextHighlighter = interface;
  PDocuments_ITextHighlighter = ^Documents_ITextHighlighter;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.TextRange>
  IVector_1__Documents_TextRange = interface;
  PIVector_1__Documents_TextRange = ^IVector_1__Documents_TextRange;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.TextRange>
  IVectorView_1__Documents_TextRange = interface;
  PIVectorView_1__Documents_TextRange = ^IVectorView_1__Documents_TextRange;

  // External: Windows.UI.Xaml.Media.IBrush
  IBrush = interface;
  PIBrush = ^IBrush;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.ITextHighlighter>
  IVectorView_1__Documents_ITextHighlighter = interface;
  PIVectorView_1__Documents_ITextHighlighter = ^IVectorView_1__Documents_ITextHighlighter;

  // External: Windows.UI.Xaml.Navigation.LoadCompletedEventHandler
  Navigation_LoadCompletedEventHandler = interface;
  PNavigation_LoadCompletedEventHandler = ^Navigation_LoadCompletedEventHandler;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IDependencyObject>
  IVector_1__IDependencyObject = interface;
  PIVector_1__IDependencyObject = ^IVector_1__IDependencyObject;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IDependencyObject>
  IVectorView_1__IDependencyObject = interface;
  PIVectorView_1__IDependencyObject = ^IVectorView_1__IDependencyObject;

  // External: Windows.Foundation.IReference`1<Windows.UI.Xaml.Thickness>
  IReference_1__Thickness = interface;
  PIReference_1__Thickness = ^IReference_1__Thickness;

  // External: Windows.UI.Xaml.Input.IProcessKeyboardAcceleratorEventArgs
  Input_IProcessKeyboardAcceleratorEventArgs = interface;
  PInput_IProcessKeyboardAcceleratorEventArgs = ^Input_IProcessKeyboardAcceleratorEventArgs;

  // External: Windows.UI.Xaml.IXamlRoot
  IXamlRoot = interface;
  PIXamlRoot = ^IXamlRoot;

  // External: Windows.UI.IUIContext
  IUIContext = interface;
  PIUIContext = ^IUIContext;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.IXamlRoot,Windows.UI.Xaml.IXamlRootChangedEventArgs>
  TypedEventHandler_2__IXamlRoot__IXamlRootChangedEventArgs = interface;
  PTypedEventHandler_2__IXamlRoot__IXamlRootChangedEventArgs = ^TypedEventHandler_2__IXamlRoot__IXamlRootChangedEventArgs;

  // External: Windows.UI.Xaml.IXamlRootChangedEventArgs
  IXamlRootChangedEventArgs = interface;
  PIXamlRootChangedEventArgs = ^IXamlRootChangedEventArgs;

  // External: Windows.UI.Xaml.Controls.IMediaElement
  IMediaElement = interface;
  PIMediaElement = ^IMediaElement;

  // External: Windows.UI.Xaml.Media.IImageSource
  IImageSource = interface;
  PIImageSource = ^IImageSource;

  // External: Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.ITimelineMarker>
  IVector_1__ITimelineMarker = interface;
  PIVector_1__ITimelineMarker = ^IVector_1__ITimelineMarker;

  // External: Windows.UI.Xaml.Media.ITimelineMarker
  ITimelineMarker = interface;
  PITimelineMarker = ^ITimelineMarker;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Media.ITimelineMarker>
  IVectorView_1__ITimelineMarker = interface;
  PIVectorView_1__ITimelineMarker = ^IVectorView_1__ITimelineMarker;

  // External: Windows.Media.PlayTo.IPlayToSource
  PlayTo_IPlayToSource = interface;
  PPlayTo_IPlayToSource = ^PlayTo_IPlayToSource;

  // External: Windows.Media.PlayTo.IPlayToConnection
  PlayTo_IPlayToConnection = interface;
  PPlayTo_IPlayToConnection = ^PlayTo_IPlayToConnection;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionStateChangedEventArgs>
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionStateChangedEventArgs = interface;
  PTypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionStateChangedEventArgs = ^TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionStateChangedEventArgs;

  // External: Windows.Media.PlayTo.IPlayToConnectionStateChangedEventArgs
  PlayTo_IPlayToConnectionStateChangedEventArgs = interface;
  PPlayTo_IPlayToConnectionStateChangedEventArgs = ^PlayTo_IPlayToConnectionStateChangedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionTransferredEventArgs>
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionTransferredEventArgs = interface;
  PTypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionTransferredEventArgs = ^TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionTransferredEventArgs;

  // External: Windows.Media.PlayTo.IPlayToConnectionTransferredEventArgs
  PlayTo_IPlayToConnectionTransferredEventArgs = interface;
  PPlayTo_IPlayToConnectionTransferredEventArgs = ^PlayTo_IPlayToConnectionTransferredEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionErrorEventArgs>
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionErrorEventArgs = interface;
  PTypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionErrorEventArgs = ^TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionErrorEventArgs;

  // External: Windows.Media.PlayTo.IPlayToConnectionErrorEventArgs
  PlayTo_IPlayToConnectionErrorEventArgs = interface;
  PPlayTo_IPlayToConnectionErrorEventArgs = ^PlayTo_IPlayToConnectionErrorEventArgs;

  // External: Windows.Media.Protection.IMediaProtectionManager
  Protection_IMediaProtectionManager = interface;
  PProtection_IMediaProtectionManager = ^Protection_IMediaProtectionManager;

  // External: Windows.Media.Protection.ServiceRequestedEventHandler
  Protection_ServiceRequestedEventHandler = interface;
  PProtection_ServiceRequestedEventHandler = ^Protection_ServiceRequestedEventHandler;

  // External: Windows.Media.Protection.IServiceRequestedEventArgs
  Protection_IServiceRequestedEventArgs = interface;
  PProtection_IServiceRequestedEventArgs = ^Protection_IServiceRequestedEventArgs;

  // External: Windows.Media.Protection.IMediaProtectionServiceRequest
  Protection_IMediaProtectionServiceRequest = interface;
  PProtection_IMediaProtectionServiceRequest = ^Protection_IMediaProtectionServiceRequest;

  // External: Windows.Media.Protection.IMediaProtectionServiceCompletion
  Protection_IMediaProtectionServiceCompletion = interface;
  PProtection_IMediaProtectionServiceCompletion = ^Protection_IMediaProtectionServiceCompletion;

  // External: Windows.Media.Protection.RebootNeededEventHandler
  Protection_RebootNeededEventHandler = interface;
  PProtection_RebootNeededEventHandler = ^Protection_RebootNeededEventHandler;

  // External: Windows.Media.Protection.ComponentLoadFailedEventHandler
  Protection_ComponentLoadFailedEventHandler = interface;
  PProtection_ComponentLoadFailedEventHandler = ^Protection_ComponentLoadFailedEventHandler;

  // External: Windows.Media.Protection.IComponentLoadFailedEventArgs
  Protection_IComponentLoadFailedEventArgs = interface;
  PProtection_IComponentLoadFailedEventArgs = ^Protection_IComponentLoadFailedEventArgs;

  // External: Windows.Media.Protection.IRevocationAndRenewalInformation
  Protection_IRevocationAndRenewalInformation = interface;
  PProtection_IRevocationAndRenewalInformation = ^Protection_IRevocationAndRenewalInformation;

  // External: Windows.Foundation.Collections.IVector`1<Windows.Media.Protection.IRevocationAndRenewalItem>
  IVector_1__Protection_IRevocationAndRenewalItem = interface;
  PIVector_1__Protection_IRevocationAndRenewalItem = ^IVector_1__Protection_IRevocationAndRenewalItem;

  // External: Windows.Media.Protection.IRevocationAndRenewalItem
  Protection_IRevocationAndRenewalItem = interface;
  PProtection_IRevocationAndRenewalItem = ^Protection_IRevocationAndRenewalItem;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.Media.Protection.IRevocationAndRenewalItem>
  IVectorView_1__Protection_IRevocationAndRenewalItem = interface;
  PIVectorView_1__Protection_IRevocationAndRenewalItem = ^IVectorView_1__Protection_IRevocationAndRenewalItem;

  // External: Windows.UI.Xaml.Media.TimelineMarkerRoutedEventHandler
  TimelineMarkerRoutedEventHandler = interface;
  PTimelineMarkerRoutedEventHandler = ^TimelineMarkerRoutedEventHandler;

  // External: Windows.UI.Xaml.Media.ITimelineMarkerRoutedEventArgs
  ITimelineMarkerRoutedEventArgs = interface;
  PITimelineMarkerRoutedEventArgs = ^ITimelineMarkerRoutedEventArgs;

  // External: Windows.UI.Xaml.Media.RateChangedRoutedEventHandler
  RateChangedRoutedEventHandler = interface;
  PRateChangedRoutedEventHandler = ^RateChangedRoutedEventHandler;

  // External: Windows.UI.Xaml.Media.IRateChangedRoutedEventArgs
  IRateChangedRoutedEventArgs = interface;
  PIRateChangedRoutedEventArgs = ^IRateChangedRoutedEventArgs;

  // External: Windows.Foundation.Collections.IIterable`1<Windows.UI.Xaml.IUIElement>
  IIterable_1__IUIElement = interface;
  PIIterable_1__IUIElement = ^IIterable_1__IUIElement;

  // External: Windows.Foundation.Collections.IIterator`1<Windows.UI.Xaml.IUIElement>
  IIterator_1__IUIElement = interface;
  PIIterator_1__IUIElement = ^IIterator_1__IUIElement;

  // External: Windows.UI.Xaml.Controls.IListViewBase
  IListViewBase = interface;
  PIListViewBase = ^IListViewBase;

  // External: Windows.Foundation.Collections.IVector`1<Object>
  IVector_1__IInspectable = interface;
  PIVector_1__IInspectable = ^IVector_1__IInspectable;

  // External: Windows.Foundation.Collections.IVectorView`1<Object>
  IVectorView_1__IInspectable = interface;
  PIVectorView_1__IInspectable = ^IVectorView_1__IInspectable;

  // External: Windows.UI.Xaml.Controls.ItemClickEventHandler
  ItemClickEventHandler = interface;
  PItemClickEventHandler = ^ItemClickEventHandler;

  // External: Windows.UI.Xaml.Controls.IItemClickEventArgs
  IItemClickEventArgs = interface;
  PIItemClickEventArgs = ^IItemClickEventArgs;

  // External: Windows.UI.Xaml.Controls.DragItemsStartingEventHandler
  DragItemsStartingEventHandler = interface;
  PDragItemsStartingEventHandler = ^DragItemsStartingEventHandler;

  // External: Windows.UI.Xaml.Controls.IDragItemsStartingEventArgs
  IDragItemsStartingEventArgs = interface;
  PIDragItemsStartingEventArgs = ^IDragItemsStartingEventArgs;

  // External: Windows.UI.Xaml.IUIElementWeakCollection
  IUIElementWeakCollection = interface;
  PIUIElementWeakCollection = ^IUIElementWeakCollection;

  // External: Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Controls.Primitives.IPopup>
  IVectorView_1__Primitives_IPopup = interface;
  PIVectorView_1__Primitives_IPopup = ^IVectorView_1__Primitives_IPopup;

  // External: Windows.UI.Xaml.Controls.Primitives.IPopup
  Primitives_IPopup = interface;
  PPrimitives_IPopup = ^Primitives_IPopup;

  // External: Windows.UI.Xaml.IWindow
  IWindow = interface;
  PIWindow = ^IWindow;

  // External: Windows.UI.Xaml.WindowActivatedEventHandler
  WindowActivatedEventHandler = interface;
  PWindowActivatedEventHandler = ^WindowActivatedEventHandler;

  // External: Windows.UI.Xaml.WindowClosedEventHandler
  WindowClosedEventHandler = interface;
  PWindowClosedEventHandler = ^WindowClosedEventHandler;

  // External: Windows.UI.Xaml.WindowSizeChangedEventHandler
  WindowSizeChangedEventHandler = interface;
  PWindowSizeChangedEventHandler = ^WindowSizeChangedEventHandler;

  // External: Windows.UI.Xaml.WindowVisibilityChangedEventHandler
  WindowVisibilityChangedEventHandler = interface;
  PWindowVisibilityChangedEventHandler = ^WindowVisibilityChangedEventHandler;

  // External: Windows.UI.Xaml.Controls.IMediaTransportControls
  IMediaTransportControls = interface;
  PIMediaTransportControls = ^IMediaTransportControls;

  // External: Windows.Foundation.IReference`1<Windows.Foundation.Point>
  IReference_1__Point = interface;
  PIReference_1__Point = ^IReference_1__Point;

  // External: Windows.Foundation.IReference`1<Windows.Foundation.Rect>
  IReference_1__Rect = interface;
  PIReference_1__Rect = ^IReference_1__Rect;

  // External: Windows.Graphics.Imaging.ISoftwareBitmap
  Imaging_ISoftwareBitmap = interface;
  PImaging_ISoftwareBitmap = ^Imaging_ISoftwareBitmap;

  // External: Windows.Graphics.Imaging.IBitmapBuffer
  Imaging_IBitmapBuffer = interface;
  PImaging_IBitmapBuffer = ^Imaging_IBitmapBuffer;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.DataTransfer.DataPackageOperation>
  IAsyncOperation_1__DataPackageOperation = interface;
  PIAsyncOperation_1__DataPackageOperation = ^IAsyncOperation_1__DataPackageOperation;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.DataTransfer.DataPackageOperation>
  AsyncOperationCompletedHandler_1__DataPackageOperation = interface;
  PAsyncOperationCompletedHandler_1__DataPackageOperation = ^AsyncOperationCompletedHandler_1__DataPackageOperation;

  // External: Windows.Foundation.Collections.IObservableVector`1<Object>
  IObservableVector_1__IInspectable = interface;
  PIObservableVector_1__IInspectable = ^IObservableVector_1__IInspectable;

  // External: Windows.Foundation.Collections.VectorChangedEventHandler`1<Object>
  VectorChangedEventHandler_1__IInspectable = interface;
  PVectorChangedEventHandler_1__IInspectable = ^VectorChangedEventHandler_1__IInspectable;

  // External: Windows.Media.Casting.ICastingSource
  Casting_ICastingSource = interface;
  PCasting_ICastingSource = ^Casting_ICastingSource;

  // External: Windows.Media.Playback.IMediaPlaybackSource
  Playback_IMediaPlaybackSource = interface;
  PPlayback_IMediaPlaybackSource = ^Playback_IMediaPlaybackSource;

  // External: Windows.Media.Playback.IMediaPlayer
  Playback_IMediaPlayer = interface;
  PPlayback_IMediaPlayer = ^Playback_IMediaPlayer;

  // External: Windows.Media.Playback.IPlaybackMediaMarkerSequence
  Playback_IPlaybackMediaMarkerSequence = interface;
  PPlayback_IPlaybackMediaMarkerSequence = ^Playback_IPlaybackMediaMarkerSequence;

  // External: Windows.Media.Playback.IPlaybackMediaMarker
  Playback_IPlaybackMediaMarker = interface;
  PPlayback_IPlaybackMediaMarker = ^Playback_IPlaybackMediaMarker;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Object>
  TypedEventHandler_2__Playback_IMediaPlayer__IInspectable = interface;
  PTypedEventHandler_2__Playback_IMediaPlayer__IInspectable = ^TypedEventHandler_2__Playback_IMediaPlayer__IInspectable;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IMediaPlayerFailedEventArgs>
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerFailedEventArgs = interface;
  PTypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerFailedEventArgs = ^TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerFailedEventArgs;

  // External: Windows.Media.Playback.IMediaPlayerFailedEventArgs
  Playback_IMediaPlayerFailedEventArgs = interface;
  PPlayback_IMediaPlayerFailedEventArgs = ^Playback_IMediaPlayerFailedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IPlaybackMediaMarkerReachedEventArgs>
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IPlaybackMediaMarkerReachedEventArgs = interface;
  PTypedEventHandler_2__Playback_IMediaPlayer__Playback_IPlaybackMediaMarkerReachedEventArgs = ^TypedEventHandler_2__Playback_IMediaPlayer__Playback_IPlaybackMediaMarkerReachedEventArgs;

  // External: Windows.Media.Playback.IPlaybackMediaMarkerReachedEventArgs
  Playback_IPlaybackMediaMarkerReachedEventArgs = interface;
  PPlayback_IPlaybackMediaMarkerReachedEventArgs = ^Playback_IPlaybackMediaMarkerReachedEventArgs;

  // External: Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IMediaPlayerRateChangedEventArgs>
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerRateChangedEventArgs = interface;
  PTypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerRateChangedEventArgs = ^TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerRateChangedEventArgs;

  // External: Windows.Media.Playback.IMediaPlayerRateChangedEventArgs
  Playback_IMediaPlayerRateChangedEventArgs = interface;
  PPlayback_IMediaPlayerRateChangedEventArgs = ^Playback_IMediaPlayerRateChangedEventArgs;

  // External: Windows.Foundation.Collections.IVector`1<Int32>
  IVector_1__Integer = interface;
  PIVector_1__Integer = ^IVector_1__Integer;

  // External: Windows.Foundation.Collections.IVectorView`1<Int32>
  IVectorView_1__Integer = interface;
  PIVectorView_1__Integer = ^IVectorView_1__Integer;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<String>>
  IAsyncOperation_1__IVectorView_1__HSTRING = interface;
  PIAsyncOperation_1__IVectorView_1__HSTRING = ^IAsyncOperation_1__IVectorView_1__HSTRING;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<String>>
  AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__HSTRING = ^AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING;

  // External: Windows.Foundation.Collections.IVector`1<Single>
  IVector_1__Single = interface;
  PIVector_1__Single = ^IVector_1__Single;

  // External: Windows.Foundation.Collections.IVectorView`1<Single>
  IVectorView_1__Single = interface;
  PIVectorView_1__Single = ^IVectorView_1__Single;

  // External: Windows.Foundation.Collections.IMapView`2<String,Double>
  IMapView_2__HSTRING__Double = interface;
  PIMapView_2__HSTRING__Double = ^IMapView_2__HSTRING__Double;

  // External: Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Object>>
  IAsyncOperation_1__IVectorView_1__IInspectable = interface;
  PIAsyncOperation_1__IVectorView_1__IInspectable = ^IAsyncOperation_1__IVectorView_1__IInspectable;

  // External: Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Object>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IInspectable = ^AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable;

  // Windows.Media.Playback.MediaPlayerError
  Playback_MediaPlayerError = (
    Unknown = 0,
    Aborted = 1,
    NetworkError = 2,
    DecodingError = 3,
    SourceNotSupported = 4
  );
  PPlayback_MediaPlayerError = ^Playback_MediaPlayerError;

  // Windows.Media.Playback.MediaPlayerState
  Playback_MediaPlayerState = (
    Closed = 0,
    Opening = 1,
    Buffering = 2,
    Playing = 3,
    Paused = 4,
    Stopped = 5
  );
  PPlayback_MediaPlayerState = ^Playback_MediaPlayerState;

  // Windows.ApplicationModel.DataTransfer.DragDrop.DragDropModifiers
  DragDrop_DragDropModifiers = (
    None = 0,
    Shift = 1,
    Control = 2,
    Alt = 4,
    LeftButton = 8,
    MiddleButton = 16,
    RightButton = 32
  );
  PDragDrop_DragDropModifiers = ^DragDrop_DragDropModifiers;

  // Windows.Graphics.Imaging.BitmapBufferAccessMode
  Imaging_BitmapBufferAccessMode = (
    Read = 0,
    ReadWrite = 1,
    Write = 2
  );
  PImaging_BitmapBufferAccessMode = ^Imaging_BitmapBufferAccessMode;

  // Windows.Graphics.Imaging.BitmapAlphaMode
  Imaging_BitmapAlphaMode = (
    Premultiplied = 0,
    Straight = 1,
    Ignore = 2
  );
  PImaging_BitmapAlphaMode = ^Imaging_BitmapAlphaMode;

  // Windows.Graphics.Imaging.BitmapPixelFormat
  Imaging_BitmapPixelFormat = (
    Unknown = 0,
    Rgba16 = 12,
    Rgba8 = 30,
    Gray16 = 57,
    Gray8 = 62,
    Bgra8 = 87,
    Nv12 = 103,
    P010 = 104,
    Yuy2 = 107
  );
  PImaging_BitmapPixelFormat = ^Imaging_BitmapPixelFormat;

  // Windows.UI.Xaml.ApplicationTheme
  ApplicationTheme = (
    Light = 0,
    Dark = 1
  );
  PApplicationTheme = ^ApplicationTheme;

  // Windows.UI.Xaml.Controls.Primitives.EdgeTransitionLocation
  Primitives_EdgeTransitionLocation = (
    Left = 0,
    Top = 1,
    Right = 2,
    Bottom = 3
  );
  PPrimitives_EdgeTransitionLocation = ^Primitives_EdgeTransitionLocation;

  // Windows.UI.Xaml.Controls.Primitives.AnimationDirection
  Primitives_AnimationDirection = (
    Left = 0,
    Top = 1,
    Right = 2,
    Bottom = 3
  );
  PPrimitives_AnimationDirection = ^Primitives_AnimationDirection;

  // Windows.UI.Xaml.Controls.ScrollIntoViewAlignment
  ScrollIntoViewAlignment = (
    Default = 0,
    Leading = 1
  );
  PScrollIntoViewAlignment = ^ScrollIntoViewAlignment;

  // Windows.UI.Xaml.Controls.IncrementalLoadingTrigger
  IncrementalLoadingTrigger = (
    None = 0,
    Edge = 1
  );
  PIncrementalLoadingTrigger = ^IncrementalLoadingTrigger;

  // Windows.UI.Xaml.Controls.ListViewSelectionMode
  ListViewSelectionMode = (
    None = 0,
    Single = 1,
    Multiple = 2,
    Extended = 3
  );
  PListViewSelectionMode = ^ListViewSelectionMode;

  // Windows.UI.Xaml.Media.MediaCanPlayResponse
  MediaCanPlayResponse = (
    NotSupported = 0,
    Maybe = 1,
    Probably = 2
  );
  PMediaCanPlayResponse = ^MediaCanPlayResponse;

  // Windows.UI.Xaml.Media.Stereo3DVideoRenderMode
  Stereo3DVideoRenderMode = (
    Mono = 0,
    Stereo = 1
  );
  PStereo3DVideoRenderMode = ^Stereo3DVideoRenderMode;

  // Windows.UI.Xaml.Media.Stereo3DVideoPackingMode
  Stereo3DVideoPackingMode = (
    None = 0,
    SideBySide = 1,
    TopBottom = 2
  );
  PStereo3DVideoPackingMode = ^Stereo3DVideoPackingMode;

  // Windows.Media.Protection.RevocationAndRenewalReasons
  Protection_RevocationAndRenewalReasons = (
    UserModeComponentLoad = 1,
    KernelModeComponentLoad = 2,
    AppComponent = 4,
    GlobalRevocationListLoadFailed = 16,
    InvalidGlobalRevocationListSignature = 32,
    GlobalRevocationListAbsent = 4096,
    ComponentRevoked = 8192,
    InvalidComponentCertificateExtendedKeyUse = 16384,
    ComponentCertificateRevoked = 32768,
    InvalidComponentCertificateRoot = 65536,
    ComponentHighSecurityCertificateRevoked = 131072,
    ComponentLowSecurityCertificateRevoked = 262144,
    BootDriverVerificationFailed = 1048576,
    ComponentSignedWithTestCertificate = 16777216,
    EncryptionFailure = 268435456
  );
  PProtection_RevocationAndRenewalReasons = ^Protection_RevocationAndRenewalReasons;

  // Windows.UI.Xaml.Media.AudioDeviceType
  AudioDeviceType = (
    Console = 0,
    Multimedia = 1,
    Communications = 2
  );
  PAudioDeviceType = ^AudioDeviceType;

  // Windows.UI.Xaml.Media.AudioCategory
  AudioCategory = (
    Other = 0,
    ForegroundOnlyMedia = 1,
    BackgroundCapableMedia = 2,
    Communications = 3,
    Alerts = 4,
    SoundEffects = 5,
    GameEffects = 6,
    GameMedia = 7,
    GameChat = 8,
    Speech = 9,
    Movie = 10,
    Media = 11
  );
  PAudioCategory = ^AudioCategory;

  // Windows.Media.PlayTo.PlayToConnectionError
  PlayTo_PlayToConnectionError = (
    None = 0,
    DeviceNotResponding = 1,
    DeviceError = 2,
    DeviceLocked = 3,
    ProtectedPlaybackFailed = 4
  );
  PPlayTo_PlayToConnectionError = ^PlayTo_PlayToConnectionError;

  // Windows.Media.PlayTo.PlayToConnectionState
  PlayTo_PlayToConnectionState = (
    Disconnected = 0,
    Connected = 1,
    Rendering = 2
  );
  PPlayTo_PlayToConnectionState = ^PlayTo_PlayToConnectionState;

  // Windows.UI.Xaml.Media.MediaElementState
  MediaElementState = (
    Closed = 0,
    Opening = 1,
    Buffering = 2,
    Playing = 3,
    Paused = 4,
    Stopped = 5
  );
  PMediaElementState = ^MediaElementState;

  // Windows.UI.Text.TextSetOptions
  TextSetOptions = (
    None = 0,
    UnicodeBidi = 1,
    Unlink = 8,
    Unhide = 16,
    CheckTextLimit = 32,
    FormatRtf = 8192,
    ApplyRtfDocumentDefaults = 16384
  );
  PTextSetOptions = ^TextSetOptions;

  // Windows.UI.Text.TextGetOptions
  TextGetOptions = (
    None = 0,
    AdjustCrlf = 1,
    UseCrlf = 2,
    UseObjectText = 4,
    AllowFinalEop = 8,
    NoHidden = 32,
    IncludeNumbering = 64,
    FormatRtf = 8192,
    UseLf = 16777216
  );
  PTextGetOptions = ^TextGetOptions;

  // Windows.UI.Text.PointOptions
  PointOptions = (
    None = 0,
    IncludeInset = 1,
    Start = 32,
    ClientCoordinates = 256,
    AllowOffClient = 512,
    Transform = 1024,
    NoHorizontalScroll = 65536,
    NoVerticalScroll = 262144
  );
  PPointOptions = ^PointOptions;

  // Windows.UI.Text.VerticalCharacterAlignment
  VerticalCharacterAlignment = (
    Top = 0,
    Baseline = 1,
    Bottom = 2
  );
  PVerticalCharacterAlignment = ^VerticalCharacterAlignment;

  // Windows.UI.Text.HorizontalCharacterAlignment
  HorizontalCharacterAlignment = (
    Left = 0,
    Right = 1,
    Center = 2
  );
  PHorizontalCharacterAlignment = ^HorizontalCharacterAlignment;

  // Windows.UI.Text.FindOptions
  FindOptions = (
    None = 0,
    Word = 2,
    &Case = 4
  );
  PFindOptions = ^FindOptions;

  // Windows.UI.Text.LetterCase
  LetterCase = (
    Lower = 0,
    Upper = 1
  );
  PLetterCase = ^LetterCase;

  // Windows.UI.Text.RangeGravity
  RangeGravity = (
    UIBehavior = 0,
    Backward = 1,
    Forward = 2,
    Inward = 3,
    Outward = 4
  );
  PRangeGravity = ^RangeGravity;

  // Windows.UI.Text.TabLeader
  TabLeader = (
    Spaces = 0,
    Dots = 1,
    Dashes = 2,
    Lines = 3,
    ThickLines = 4,
    Equals = 5
  );
  PTabLeader = ^TabLeader;

  // Windows.UI.Text.TabAlignment
  TabAlignment = (
    Left = 0,
    Center = 1,
    Right = 2,
    Decimal = 3,
    Bar = 4
  );
  PTabAlignment = ^TabAlignment;

  // Windows.UI.Text.ParagraphStyle
  ParagraphStyle = (
    Undefined = 0,
    None = 1,
    Normal = 2,
    Heading1 = 3,
    Heading2 = 4,
    Heading3 = 5,
    Heading4 = 6,
    Heading5 = 7,
    Heading6 = 8,
    Heading7 = 9,
    Heading8 = 10,
    Heading9 = 11
  );
  PParagraphStyle = ^ParagraphStyle;

  // Windows.UI.Text.MarkerType
  MarkerType = (
    Undefined = 0,
    None = 1,
    Bullet = 2,
    Arabic = 3,
    LowercaseEnglishLetter = 4,
    UppercaseEnglishLetter = 5,
    LowercaseRoman = 6,
    UppercaseRoman = 7,
    UnicodeSequence = 8,
    CircledNumber = 9,
    BlackCircleWingding = 10,
    WhiteCircleWingding = 11,
    ArabicWide = 12,
    SimplifiedChinese = 13,
    TraditionalChinese = 14,
    JapanSimplifiedChinese = 15,
    JapanKorea = 16,
    ArabicDictionary = 17,
    ArabicAbjad = 18,
    Hebrew = 19,
    ThaiAlphabetic = 20,
    ThaiNumeric = 21,
    DevanagariVowel = 22,
    DevanagariConsonant = 23,
    DevanagariNumeric = 24
  );
  PMarkerType = ^MarkerType;

  // Windows.UI.Text.MarkerStyle
  MarkerStyle = (
    Undefined = 0,
    Parenthesis = 1,
    Parentheses = 2,
    Period = 3,
    Plain = 4,
    Minus = 5,
    NoNumber = 6
  );
  PMarkerStyle = ^MarkerStyle;

  // Windows.UI.Text.MarkerAlignment
  MarkerAlignment = (
    Undefined = 0,
    Left = 1,
    Center = 2,
    Right = 3
  );
  PMarkerAlignment = ^MarkerAlignment;

  // Windows.UI.Text.LineSpacingRule
  LineSpacingRule = (
    Undefined = 0,
    Single = 1,
    OneAndHalf = 2,
    Double = 3,
    AtLeast = 4,
    Exactly = 5,
    Multiple = 6,
    Percent = 7
  );
  PLineSpacingRule = ^LineSpacingRule;

  // Windows.UI.Text.ParagraphAlignment
  ParagraphAlignment = (
    Undefined = 0,
    Left = 1,
    Center = 2,
    Right = 3,
    Justify = 4
  );
  PParagraphAlignment = ^ParagraphAlignment;

  // Windows.UI.Text.UnderlineType
  UnderlineType = (
    Undefined = 0,
    None = 1,
    Single = 2,
    Words = 3,
    Double = 4,
    Dotted = 5,
    Dash = 6,
    DashDot = 7,
    DashDotDot = 8,
    Wave = 9,
    Thick = 10,
    Thin = 11,
    DoubleWave = 12,
    HeavyWave = 13,
    LongDash = 14,
    ThickDash = 15,
    ThickDashDot = 16,
    ThickDashDotDot = 17,
    ThickDotted = 18,
    ThickLongDash = 19
  );
  PUnderlineType = ^UnderlineType;

  // Windows.UI.Text.TextScript
  TextScript = (
    Undefined = 0,
    Ansi = 1,
    EastEurope = 2,
    Cyrillic = 3,
    Greek = 4,
    Turkish = 5,
    Hebrew = 6,
    Arabic = 7,
    Baltic = 8,
    Vietnamese = 9,
    Default = 10,
    Symbol = 11,
    Thai = 12,
    ShiftJis = 13,
    GB2312 = 14,
    Hangul = 15,
    Big5 = 16,
    PC437 = 17,
    Oem = 18,
    Mac = 19,
    Armenian = 20,
    Syriac = 21,
    Thaana = 22,
    Devanagari = 23,
    Bengali = 24,
    Gurmukhi = 25,
    Gujarati = 26,
    Oriya = 27,
    Tamil = 28,
    Telugu = 29,
    Kannada = 30,
    Malayalam = 31,
    Sinhala = 32,
    Lao = 33,
    Tibetan = 34,
    Myanmar = 35,
    Georgian = 36,
    Jamo = 37,
    Ethiopic = 38,
    Cherokee = 39,
    Aboriginal = 40,
    Ogham = 41,
    Runic = 42,
    Khmer = 43,
    Mongolian = 44,
    Braille = 45,
    Yi = 46,
    Limbu = 47,
    TaiLe = 48,
    NewTaiLue = 49,
    SylotiNagri = 50,
    Kharoshthi = 51,
    Kayahli = 52,
    UnicodeSymbol = 53,
    Emoji = 54,
    Glagolitic = 55,
    Lisu = 56,
    Vai = 57,
    NKo = 58,
    Osmanya = 59,
    PhagsPa = 60,
    Gothic = 61,
    Deseret = 62,
    Tifinagh = 63
  );
  PTextScript = ^TextScript;

  // Windows.UI.Text.LinkType
  LinkType = (
    Undefined = 0,
    NotALink = 1,
    ClientLink = 2,
    FriendlyLinkName = 3,
    FriendlyLinkAddress = 4,
    AutoLink = 5,
    AutoLinkEmail = 6,
    AutoLinkPhone = 7,
    AutoLinkPath = 8
  );
  PLinkType = ^LinkType;

  // Windows.UI.Text.FontStyle
  FontStyle = (
    Normal = 0,
    Oblique = 1,
    Italic = 2
  );
  PFontStyle = ^FontStyle;

  // Windows.UI.Text.FontStretch
  FontStretch = (
    Undefined = 0,
    UltraCondensed = 1,
    ExtraCondensed = 2,
    Condensed = 3,
    SemiCondensed = 4,
    Normal = 5,
    SemiExpanded = 6,
    Expanded = 7,
    ExtraExpanded = 8,
    UltraExpanded = 9
  );
  PFontStretch = ^FontStretch;

  // Windows.UI.Text.FormatEffect
  FormatEffect = (
    Off = 0,
    &On = 1,
    Toggle = 2,
    Undefined = 3
  );
  PFormatEffect = ^FormatEffect;

  // Windows.UI.Text.TextRangeUnit
  TextRangeUnit = (
    Character = 0,
    Word = 1,
    Sentence = 2,
    Paragraph = 3,
    Line = 4,
    Story = 5,
    Screen = 6,
    Section = 7,
    Window = 8,
    CharacterFormat = 9,
    ParagraphFormat = 10,
    &Object = 11,
    HardParagraph = 12,
    Cluster = 13,
    Bold = 14,
    Italic = 15,
    Underline = 16,
    Strikethrough = 17,
    ProtectedText = 18,
    Link = 19,
    SmallCaps = 20,
    AllCaps = 21,
    Hidden = 22,
    Outline = 23,
    Shadow = 24,
    Imprint = 25,
    Disabled = 26,
    Revised = 27,
    Subscript = 28,
    Superscript = 29,
    FontBound = 30,
    LinkProtected = 31,
    ContentLink = 32
  );
  PTextRangeUnit = ^TextRangeUnit;

  // Windows.UI.Text.SelectionType
  SelectionType = (
    None = 0,
    InsertionPoint = 1,
    Normal = 2,
    InlineShape = 7,
    Shape = 8
  );
  PSelectionType = ^SelectionType;

  // Windows.UI.Text.SelectionOptions
  SelectionOptions = (
    StartActive = 1,
    AtEndOfLine = 2,
    Overtype = 4,
    Active = 8,
    Replace = 16
  );
  PSelectionOptions = ^SelectionOptions;

  // Windows.UI.Text.CaretType
  CaretType = (
    Normal = 0,
    Null = 1
  );
  PCaretType = ^CaretType;

  // Windows.UI.Xaml.TextReadingOrder
  TextReadingOrder = (
    Default = 0,
    UseFlowDirection = 0,
    DetectFromContent = 1
  );
  PTextReadingOrder = ^TextReadingOrder;

  // Windows.UI.Xaml.Navigation.NavigationCacheMode
  Navigation_NavigationCacheMode = (
    Disabled = 0,
    Required = 1,
    Enabled = 2
  );
  PNavigation_NavigationCacheMode = ^Navigation_NavigationCacheMode;

  // Windows.UI.Xaml.Navigation.NavigationMode
  Navigation_NavigationMode = (
    New = 0,
    Back = 1,
    Forward = 2,
    Refresh = 3
  );
  PNavigation_NavigationMode = ^Navigation_NavigationMode;

  // Windows.UI.Xaml.ElementSoundMode
  ElementSoundMode = (
    Default = 0,
    FocusOnly = 1,
    Off = 2
  );
  PElementSoundMode = ^ElementSoundMode;

  // Windows.UI.Xaml.Input.KeyboardNavigationMode
  Input_KeyboardNavigationMode = (
    Local = 0,
    Cycle = 1,
    Once = 2
  );
  PInput_KeyboardNavigationMode = ^Input_KeyboardNavigationMode;

  // Windows.UI.Xaml.TextLineBounds
  TextLineBounds = (
    Full = 0,
    TrimToCapHeight = 1,
    TrimToBaseline = 2,
    Tight = 3
  );
  PTextLineBounds = ^TextLineBounds;

  // Windows.UI.Xaml.OpticalMarginAlignment
  OpticalMarginAlignment = (
    None = 0,
    TrimSideBearings = 1
  );
  POpticalMarginAlignment = ^OpticalMarginAlignment;

  // Windows.UI.Xaml.GridUnitType
  GridUnitType = (
    Auto = 0,
    Pixel = 1,
    Star = 2
  );
  PGridUnitType = ^GridUnitType;

  // Windows.UI.Input.HoldingState
  HoldingState = (
    Started = 0,
    Completed = 1,
    Canceled = 2
  );
  PHoldingState = ^HoldingState;

  // Windows.ApplicationModel.DataTransfer.DataPackageOperation
  DataPackageOperation = (
    None = 0,
    Copy = 1,
    Move = 2,
    Link = 4
  );
  PDataPackageOperation = ^DataPackageOperation;

  // Windows.UI.Xaml.Input.ManipulationModes
  Input_ManipulationModes = (
    None = 0,
    TranslateX = 1,
    TranslateY = 2,
    TranslateRailsX = 4,
    TranslateRailsY = 8,
    Rotate = 16,
    Scale = 32,
    TranslateInertia = 64,
    RotateInertia = 128,
    ScaleInertia = 256,
    All = 65535,
    System = 65536
  );
  PInput_ManipulationModes = ^Input_ManipulationModes;

  // Windows.UI.Xaml.Visibility
  Visibility = (
    Visible = 0,
    Collapsed = 1
  );
  PVisibility = ^Visibility;

  // Windows.UI.Xaml.LineStackingStrategy
  LineStackingStrategy = (
    MaxHeight = 0,
    BlockLineHeight = 1,
    BaselineToBaseline = 2
  );
  PLineStackingStrategy = ^LineStackingStrategy;

  // Windows.UI.Xaml.TextTrimming
  TextTrimming = (
    None = 0,
    CharacterEllipsis = 1,
    WordEllipsis = 2,
    Clip = 3
  );
  PTextTrimming = ^TextTrimming;

  // Windows.UI.Xaml.FocusState
  FocusState = (
    Unfocused = 0,
    Pointer = 1,
    Keyboard = 2,
    Programmatic = 3
  );
  PFocusState = ^FocusState;

  // Windows.UI.Xaml.Documents.LogicalDirection
  Documents_LogicalDirection = (
    Backward = 0,
    Forward = 1
  );
  PDocuments_LogicalDirection = ^Documents_LogicalDirection;

  // Windows.UI.Xaml.FlowDirection
  FlowDirection = (
    LeftToRight = 0,
    RightToLeft = 1
  );
  PFlowDirection = ^FlowDirection;

  // Windows.UI.Xaml.Input.InputScopeNameValue
  Input_InputScopeNameValue = (
    Default = 0,
    Url = 1,
    EmailSmtpAddress = 5,
    PersonalFullName = 7,
    CurrencyAmountAndSymbol = 20,
    CurrencyAmount = 21,
    DateMonthNumber = 23,
    DateDayNumber = 24,
    DateYear = 25,
    Digits = 28,
    Number = 29,
    Password = 31,
    TelephoneNumber = 32,
    TelephoneCountryCode = 33,
    TelephoneAreaCode = 34,
    TelephoneLocalNumber = 35,
    TimeHour = 37,
    TimeMinutesOrSeconds = 38,
    NumberFullWidth = 39,
    AlphanumericHalfWidth = 40,
    AlphanumericFullWidth = 41,
    Hiragana = 44,
    KatakanaHalfWidth = 45,
    KatakanaFullWidth = 46,
    Hanja = 47,
    HangulHalfWidth = 48,
    HangulFullWidth = 49,
    Search = 50,
    Formula = 51,
    SearchIncremental = 52,
    ChineseHalfWidth = 53,
    ChineseFullWidth = 54,
    NativeScript = 55,
    Text = 57,
    Chat = 58,
    NameOrPhoneNumber = 59,
    EmailNameOrAddress = 60,
    &Private = 61,
    Maps = 62,
    NumericPassword = 63,
    NumericPin = 64,
    AlphanumericPin = 65,
    FormulaNumber = 67,
    ChatWithoutEmoji = 68
  );
  PInput_InputScopeNameValue = ^Input_InputScopeNameValue;

  // Windows.UI.Xaml.TextWrapping
  TextWrapping = (
    NoWrap = 1,
    Wrap = 2,
    WrapWholeWords = 3
  );
  PTextWrapping = ^TextWrapping;

  // Windows.UI.Xaml.TextAlignment
  TextAlignment = (
    Center = 0,
    Left = 1,
    Start = 1,
    Right = 2,
    &End = 2,
    Justify = 3,
    DetectFromContent = 4
  );
  PTextAlignment = ^TextAlignment;

  // Windows.UI.Xaml.DurationType
  DurationType = (
    Automatic = 0,
    TimeSpan = 1,
    Forever = 2
  );
  PDurationType = ^DurationType;

  // Windows.UI.Xaml.VerticalAlignment
  VerticalAlignment = (
    Top = 0,
    Center = 1,
    Bottom = 2,
    Stretch = 3
  );
  PVerticalAlignment = ^VerticalAlignment;

  // Windows.UI.Xaml.HorizontalAlignment
  HorizontalAlignment = (
    Left = 0,
    Center = 1,
    Right = 2,
    Stretch = 3
  );
  PHorizontalAlignment = ^HorizontalAlignment;

  // Windows.UI.Xaml.Interop.TypeKind
  Interop_TypeKind = (
    Primitive = 0,
    Metadata = 1,
    Custom = 2
  );
  PInterop_TypeKind = ^Interop_TypeKind;

  // Windows.UI.Input.TouchpadGlobalAction
  TouchpadGlobalAction = (
    ThreeFingerTap = 0,
    FourFingerTap = 1,
    FiveFingerTap = 2,
    ThreeFingerPressDown = 3,
    FourFingerPressDown = 4,
    FiveFingerPressDown = 5,
    ThreeFingerPressUp = 6,
    FourFingerPressUp = 7,
    FiveFingerPressUp = 8
  );
  PTouchpadGlobalAction = ^TouchpadGlobalAction;

  // Windows.UI.Input.TouchpadGlobalGestureKinds
  TouchpadGlobalGestureKinds = (
    None = 0,
    ThreeFingerManipulations = 1,
    FourFingerManipulations = 2,
    FiveFingerManipulations = 4,
    ThreeFingerActions = 8,
    FourFingerActions = 16,
    FiveFingerActions = 32
  );
  PTouchpadGlobalGestureKinds = ^TouchpadGlobalGestureKinds;

  // Windows.UI.Input.Inking.InkPresenterPredefinedConfiguration
  InkPresenterPredefinedConfiguration = (
    SimpleSinglePointer = 0,
    SimpleMultiplePointer = 1
  );
  PInkPresenterPredefinedConfiguration = ^InkPresenterPredefinedConfiguration;

  // Windows.UI.Input.Inking.PenTipShape
  PenTipShape = (
    Circle = 0,
    Rectangle = 1
  );
  PPenTipShape = ^PenTipShape;

  // Windows.UI.Input.Inking.InkInputRightDragAction
  InkInputRightDragAction = (
    LeaveUnprocessed = 0,
    AllowProcessing = 1
  );
  PInkInputRightDragAction = ^InkInputRightDragAction;

  // Windows.UI.Input.Inking.InkInputProcessingMode
  InkInputProcessingMode = (
    None = 0,
    Inking = 1,
    Erasing = 2
  );
  PInkInputProcessingMode = ^InkInputProcessingMode;

  // Windows.UI.Core.CoreInputDeviceTypes
  CoreInputDeviceTypes = (
    None = 0,
    Touch = 1,
    Pen = 2,
    Mouse = 4
  );
  PCoreInputDeviceTypes = ^CoreInputDeviceTypes;

  // Windows.Graphics.DirectX.DirectXPrimitiveTopology
  DirectX_DirectXPrimitiveTopology = (
    Undefined = 0,
    PointList = 1,
    LineList = 2,
    LineStrip = 3,
    TriangleList = 4,
    TriangleStrip = 5
  );
  PDirectX_DirectXPrimitiveTopology = ^DirectX_DirectXPrimitiveTopology;

  // Windows.Graphics.DirectX.DirectXPixelFormat
  DirectX_DirectXPixelFormat = (
    Unknown = 0,
    R32G32B32A32Typeless = 1,
    R32G32B32A32Float = 2,
    R32G32B32A32UInt = 3,
    R32G32B32A32Int = 4,
    R32G32B32Typeless = 5,
    R32G32B32Float = 6,
    R32G32B32UInt = 7,
    R32G32B32Int = 8,
    R16G16B16A16Typeless = 9,
    R16G16B16A16Float = 10,
    R16G16B16A16UIntNormalized = 11,
    R16G16B16A16UInt = 12,
    R16G16B16A16IntNormalized = 13,
    R16G16B16A16Int = 14,
    R32G32Typeless = 15,
    R32G32Float = 16,
    R32G32UInt = 17,
    R32G32Int = 18,
    R32G8X24Typeless = 19,
    D32FloatS8X24UInt = 20,
    R32FloatX8X24Typeless = 21,
    X32TypelessG8X24UInt = 22,
    R10G10B10A2Typeless = 23,
    R10G10B10A2UIntNormalized = 24,
    R10G10B10A2UInt = 25,
    R11G11B10Float = 26,
    R8G8B8A8Typeless = 27,
    R8G8B8A8UIntNormalized = 28,
    R8G8B8A8UIntNormalizedSrgb = 29,
    R8G8B8A8UInt = 30,
    R8G8B8A8IntNormalized = 31,
    R8G8B8A8Int = 32,
    R16G16Typeless = 33,
    R16G16Float = 34,
    R16G16UIntNormalized = 35,
    R16G16UInt = 36,
    R16G16IntNormalized = 37,
    R16G16Int = 38,
    R32Typeless = 39,
    D32Float = 40,
    R32Float = 41,
    R32UInt = 42,
    R32Int = 43,
    R24G8Typeless = 44,
    D24UIntNormalizedS8UInt = 45,
    R24UIntNormalizedX8Typeless = 46,
    X24TypelessG8UInt = 47,
    R8G8Typeless = 48,
    R8G8UIntNormalized = 49,
    R8G8UInt = 50,
    R8G8IntNormalized = 51,
    R8G8Int = 52,
    R16Typeless = 53,
    R16Float = 54,
    D16UIntNormalized = 55,
    R16UIntNormalized = 56,
    R16UInt = 57,
    R16IntNormalized = 58,
    R16Int = 59,
    R8Typeless = 60,
    R8UIntNormalized = 61,
    R8UInt = 62,
    R8IntNormalized = 63,
    R8Int = 64,
    A8UIntNormalized = 65,
    R1UIntNormalized = 66,
    R9G9B9E5SharedExponent = 67,
    R8G8B8G8UIntNormalized = 68,
    G8R8G8B8UIntNormalized = 69,
    BC1Typeless = 70,
    BC1UIntNormalized = 71,
    BC1UIntNormalizedSrgb = 72,
    BC2Typeless = 73,
    BC2UIntNormalized = 74,
    BC2UIntNormalizedSrgb = 75,
    BC3Typeless = 76,
    BC3UIntNormalized = 77,
    BC3UIntNormalizedSrgb = 78,
    BC4Typeless = 79,
    BC4UIntNormalized = 80,
    BC4IntNormalized = 81,
    BC5Typeless = 82,
    BC5UIntNormalized = 83,
    BC5IntNormalized = 84,
    B5G6R5UIntNormalized = 85,
    B5G5R5A1UIntNormalized = 86,
    B8G8R8A8UIntNormalized = 87,
    B8G8R8X8UIntNormalized = 88,
    R10G10B10XRBiasA2UIntNormalized = 89,
    B8G8R8A8Typeless = 90,
    B8G8R8A8UIntNormalizedSrgb = 91,
    B8G8R8X8Typeless = 92,
    B8G8R8X8UIntNormalizedSrgb = 93,
    BC6HTypeless = 94,
    BC6H16UnsignedFloat = 95,
    BC6H16Float = 96,
    BC7Typeless = 97,
    BC7UIntNormalized = 98,
    BC7UIntNormalizedSrgb = 99,
    Ayuv = 100,
    Y410 = 101,
    Y416 = 102,
    NV12 = 103,
    P010 = 104,
    P016 = 105,
    Opaque420 = 106,
    Yuy2 = 107,
    Y210 = 108,
    Y216 = 109,
    NV11 = 110,
    AI44 = 111,
    IA44 = 112,
    P8 = 113,
    A8P8 = 114,
    B4G4R4A4UIntNormalized = 115,
    P208 = 130,
    V208 = 131,
    V408 = 132,
    SamplerFeedbackMinMipOpaque = 189,
    SamplerFeedbackMipRegionUsedOpaque = 190,
    A4B4G4R4 = 191
  );
  PDirectX_DirectXPixelFormat = ^DirectX_DirectXPixelFormat;

  // Windows.Graphics.DirectX.DirectXAlphaMode
  DirectX_DirectXAlphaMode = (
    Unspecified = 0,
    Premultiplied = 1,
    Straight = 2,
    Ignore = 3
  );
  PDirectX_DirectXAlphaMode = ^DirectX_DirectXAlphaMode;

  // Windows.System.DispatcherQueuePriority
  DispatcherQueuePriority = (
    Low = -10,
    Normal = 0,
    High = 10
  );
  PDispatcherQueuePriority = ^DispatcherQueuePriority;

  // Windows.Networking.Sockets.SocketSslErrorSeverity
  SocketSslErrorSeverity = (
    None = 0,
    Ignorable = 1,
    Fatal = 2
  );
  PSocketSslErrorSeverity = ^SocketSslErrorSeverity;

  // Windows.Networking.HostNameSortOptions
  HostNameSortOptions = (
    None = 0,
    OptimizeForLongConnections = 2
  );
  PHostNameSortOptions = ^HostNameSortOptions;

  // Windows.Networking.DomainNameType
  DomainNameType = (
    Suffix = 0,
    FullyQualified = 1
  );
  PDomainNameType = ^DomainNameType;

  // Windows.Networking.HostNameType
  HostNameType = (
    DomainName = 0,
    Ipv4 = 1,
    Ipv6 = 2,
    Bluetooth = 3
  );
  PHostNameType = ^HostNameType;

  // Windows.Networking.Connectivity.NetworkEncryptionType
  NetworkEncryptionType = (
    None = 0,
    Unknown = 1,
    Wep = 2,
    Wep40 = 3,
    Wep104 = 4,
    Tkip = 5,
    Ccmp = 6,
    WpaUseGroup = 7,
    RsnUseGroup = 8,
    Ihv = 9,
    Gcmp = 10,
    Gcmp256 = 11
  );
  PNetworkEncryptionType = ^NetworkEncryptionType;

  // Windows.Networking.Connectivity.NetworkAuthenticationType
  NetworkAuthenticationType = (
    None = 0,
    Unknown = 1,
    Open80211 = 2,
    SharedKey80211 = 3,
    Wpa = 4,
    WpaPsk = 5,
    WpaNone = 6,
    Rsna = 7,
    RsnaPsk = 8,
    Ihv = 9,
    Wpa3 = 10,
    Wpa3Enterprise192Bits = 10,
    Wpa3Sae = 11,
    Owe = 12,
    Wpa3Enterprise = 13
  );
  PNetworkAuthenticationType = ^NetworkAuthenticationType;

  // Windows.Networking.Connectivity.RoamingStates
  RoamingStates = (
    None = 0,
    NotRoaming = 1,
    Roaming = 2
  );
  PRoamingStates = ^RoamingStates;

  // Windows.Networking.Connectivity.NetworkCostType
  NetworkCostType = (
    Unknown = 0,
    Unrestricted = 1,
    Fixed = 2,
    Variable = 3
  );
  PNetworkCostType = ^NetworkCostType;

  // Windows.Networking.Connectivity.NetworkConnectivityLevel
  NetworkConnectivityLevel = (
    None = 0,
    LocalAccess = 1,
    ConstrainedInternetAccess = 2,
    InternetAccess = 3
  );
  PNetworkConnectivityLevel = ^NetworkConnectivityLevel;

  // Windows.Networking.Connectivity.NetworkTypes
  NetworkTypes = (
    None = 0,
    Internet = 1,
    PrivateNetwork = 2
  );
  PNetworkTypes = ^NetworkTypes;

  // Windows.Media.Effects.AudioEffectType
  Effects_AudioEffectType = (
    Other = 0,
    AcousticEchoCancellation = 1,
    NoiseSuppression = 2,
    AutomaticGainControl = 3,
    BeamForming = 4,
    ConstantToneRemoval = 5,
    Equalizer = 6,
    LoudnessEqualizer = 7,
    BassBoost = 8,
    VirtualSurround = 9,
    VirtualHeadphones = 10,
    SpeakerFill = 11,
    RoomCorrection = 12,
    BassManagement = 13,
    EnvironmentalEffects = 14,
    SpeakerProtection = 15,
    SpeakerCompensation = 16,
    DynamicRangeCompression = 17,
    FarFieldBeamForming = 18,
    DeepNoiseSuppression = 19
  );
  PEffects_AudioEffectType = ^Effects_AudioEffectType;

  // Windows.Media.Capture.MediaCaptureDeviceExclusiveControlReleaseMode
  Capture_MediaCaptureDeviceExclusiveControlReleaseMode = (
    OnDispose = 0,
    OnAllStreamsStopped = 1
  );
  PCapture_MediaCaptureDeviceExclusiveControlReleaseMode = ^Capture_MediaCaptureDeviceExclusiveControlReleaseMode;

  // Windows.Media.Capture.PowerlineFrequency
  Capture_PowerlineFrequency = (
    Disabled = 0,
    FiftyHertz = 1,
    SixtyHertz = 2,
    Auto = 3
  );
  PCapture_PowerlineFrequency = ^Capture_PowerlineFrequency;

  // Windows.Media.Capture.MediaStreamType
  Capture_MediaStreamType = (
    VideoPreview = 0,
    VideoRecord = 1,
    Audio = 2,
    Photo = 3,
    Metadata = 4
  );
  PCapture_MediaStreamType = ^Capture_MediaStreamType;

  // Windows.Storage.FileProperties.VideoOrientation
  FileProperties_VideoOrientation = (
    Normal = 0,
    Rotate90 = 90,
    Rotate180 = 180,
    Rotate270 = 270
  );
  PFileProperties_VideoOrientation = ^FileProperties_VideoOrientation;

  // Windows.Media.Core.TimedMetadataKind
  Core_TimedMetadataKind = (
    Caption = 0,
    Chapter = 1,
    Custom = 2,
    Data = 3,
    Description = 4,
    Subtitle = 5,
    ImageSubtitle = 6,
    Speech = 7
  );
  PCore_TimedMetadataKind = ^Core_TimedMetadataKind;

  // Windows.Media.Core.TimedMetadataTrackErrorCode
  Core_TimedMetadataTrackErrorCode = (
    None = 0,
    DataFormatError = 1,
    NetworkError = 2,
    InternalError = 3
  );
  PCore_TimedMetadataTrackErrorCode = ^Core_TimedMetadataTrackErrorCode;

  // Windows.Media.Core.MediaTrackKind
  Core_MediaTrackKind = (
    Audio = 0,
    Video = 1,
    TimedMetadata = 2
  );
  PCore_MediaTrackKind = ^Core_MediaTrackKind;

  // Windows.Foundation.Collections.CollectionChange
  CollectionChange = (
    Reset = 0,
    ItemInserted = 1,
    ItemRemoved = 2,
    ItemChanged = 3
  );
  PCollectionChange = ^CollectionChange;

  // Windows.Devices.Enumeration.Panel
  Panel = (
    Unknown = 0,
    Front = 1,
    Back = 2,
    Top = 3,
    Bottom = 4,
    Left = 5,
    Right = 6
  );
  PPanel = ^Panel;

  // Windows.System.Power.BatteryStatus
  Power_BatteryStatus = (
    NotPresent = 0,
    Discharging = 1,
    Idle = 2,
    Charging = 3
  );
  PPower_BatteryStatus = ^Power_BatteryStatus;

  // Windows.ApplicationModel.Activation.ApplicationExecutionState
  Activation_ApplicationExecutionState = (
    NotRunning = 0,
    Running = 1,
    Suspended = 2,
    Terminated = 3,
    ClosedByUser = 4
  );
  PActivation_ApplicationExecutionState = ^Activation_ApplicationExecutionState;

  // Windows.ApplicationModel.Activation.ActivationKind
  Activation_ActivationKind = (
    Launch = 0,
    Search = 1,
    ShareTarget = 2,
    &File = 3,
    Protocol = 4,
    FileOpenPicker = 5,
    FileSavePicker = 6,
    CachedFileUpdater = 7,
    ContactPicker = 8,
    Device = 9,
    PrintTaskSettings = 10,
    CameraSettings = 11,
    RestrictedLaunch = 12,
    AppointmentsProvider = 13,
    Contact = 14,
    LockScreenCall = 15,
    VoiceCommand = 16,
    LockScreen = 17,
    PickerReturned = 1000,
    WalletAction = 1001,
    PickFileContinuation = 1002,
    PickSaveFileContinuation = 1003,
    PickFolderContinuation = 1004,
    WebAuthenticationBrokerContinuation = 1005,
    WebAccountProvider = 1006,
    ComponentUI = 1007,
    ProtocolForResults = 1009,
    ToastNotification = 1010,
    Print3DWorkflow = 1011,
    DialReceiver = 1012,
    DevicePairing = 1013,
    UserDataAccountsProvider = 1014,
    FilePickerExperience = 1015,
    LockScreenComponent = 1016,
    ContactPanel = 1017,
    PrintWorkflowForegroundTask = 1018,
    GameUIProvider = 1019,
    StartupTask = 1020,
    CommandLineLaunch = 1021,
    BarcodeScannerProvider = 1022,
    PrintSupportJobUI = 1023,
    PrintSupportSettingsUI = 1024,
    PhoneCallActivation = 1025,
    VpnForeground = 1026
  );
  PActivation_ActivationKind = ^Activation_ActivationKind;

  // Windows.System.VirtualKeyModifiers
  VirtualKeyModifiers = (
    None = 0,
    Control = 1,
    Menu = 2,
    Shift = 4,
    Windows = 8
  );
  PVirtualKeyModifiers = ^VirtualKeyModifiers;

  // Windows.UI.Input.PointerUpdateKind
  PointerUpdateKind = (
    Other = 0,
    LeftButtonPressed = 1,
    LeftButtonReleased = 2,
    RightButtonPressed = 3,
    RightButtonReleased = 4,
    MiddleButtonPressed = 5,
    MiddleButtonReleased = 6,
    XButton1Pressed = 7,
    XButton1Released = 8,
    XButton2Pressed = 9,
    XButton2Released = 10
  );
  PPointerUpdateKind = ^PointerUpdateKind;

  // Windows.Devices.Input.PointerDeviceType
  Input_PointerDeviceType = (
    Touch = 0,
    Pen = 1,
    Mouse = 2,
    Touchpad = 3
  );
  PInput_PointerDeviceType = ^Input_PointerDeviceType;

  // Windows.UI.Core.CoreWindowActivationState
  CoreWindowActivationState = (
    CodeActivated = 0,
    Deactivated = 1,
    PointerActivated = 2
  );
  PCoreWindowActivationState = ^CoreWindowActivationState;

  // Windows.System.VirtualKey
  VirtualKey = (
    None = 0,
    LeftButton = 1,
    RightButton = 2,
    Cancel = 3,
    MiddleButton = 4,
    XButton1 = 5,
    XButton2 = 6,
    Back = 8,
    Tab = 9,
    Clear = 12,
    Enter = 13,
    Shift = 16,
    Control = 17,
    Menu = 18,
    Pause = 19,
    CapitalLock = 20,
    Kana = 21,
    Hangul = 21,
    ImeOn = 22,
    Junja = 23,
    Final = 24,
    Hanja = 25,
    Kanji = 25,
    ImeOff = 26,
    Escape = 27,
    Convert = 28,
    NonConvert = 29,
    Accept = 30,
    ModeChange = 31,
    Space = 32,
    PageUp = 33,
    PageDown = 34,
    &End = 35,
    Home = 36,
    Left = 37,
    Up = 38,
    Right = 39,
    Down = 40,
    Select = 41,
    Print = 42,
    Execute = 43,
    Snapshot = 44,
    Insert = 45,
    Delete = 46,
    Help = 47,
    Number0 = 48,
    Number1 = 49,
    Number2 = 50,
    Number3 = 51,
    Number4 = 52,
    Number5 = 53,
    Number6 = 54,
    Number7 = 55,
    Number8 = 56,
    Number9 = 57,
    A = 65,
    B = 66,
    C = 67,
    D = 68,
    E = 69,
    F = 70,
    G = 71,
    H = 72,
    I = 73,
    J = 74,
    K = 75,
    L = 76,
    M = 77,
    N = 78,
    O = 79,
    P = 80,
    Q = 81,
    R = 82,
    S = 83,
    T = 84,
    U = 85,
    V = 86,
    W = 87,
    X = 88,
    Y = 89,
    Z = 90,
    LeftWindows = 91,
    RightWindows = 92,
    Application = 93,
    Sleep = 95,
    NumberPad0 = 96,
    NumberPad1 = 97,
    NumberPad2 = 98,
    NumberPad3 = 99,
    NumberPad4 = 100,
    NumberPad5 = 101,
    NumberPad6 = 102,
    NumberPad7 = 103,
    NumberPad8 = 104,
    NumberPad9 = 105,
    Multiply = 106,
    Add = 107,
    Separator = 108,
    Subtract = 109,
    Decimal = 110,
    Divide = 111,
    F1 = 112,
    F2 = 113,
    F3 = 114,
    F4 = 115,
    F5 = 116,
    F6 = 117,
    F7 = 118,
    F8 = 119,
    F9 = 120,
    F10 = 121,
    F11 = 122,
    F12 = 123,
    F13 = 124,
    F14 = 125,
    F15 = 126,
    F16 = 127,
    F17 = 128,
    F18 = 129,
    F19 = 130,
    F20 = 131,
    F21 = 132,
    F22 = 133,
    F23 = 134,
    F24 = 135,
    NavigationView = 136,
    NavigationMenu = 137,
    NavigationUp = 138,
    NavigationDown = 139,
    NavigationLeft = 140,
    NavigationRight = 141,
    NavigationAccept = 142,
    NavigationCancel = 143,
    NumberKeyLock = 144,
    Scroll = 145,
    LeftShift = 160,
    RightShift = 161,
    LeftControl = 162,
    RightControl = 163,
    LeftMenu = 164,
    RightMenu = 165,
    GoBack = 166,
    GoForward = 167,
    Refresh = 168,
    Stop = 169,
    Search = 170,
    Favorites = 171,
    GoHome = 172,
    GamepadA = 195,
    GamepadB = 196,
    GamepadX = 197,
    GamepadY = 198,
    GamepadRightShoulder = 199,
    GamepadLeftShoulder = 200,
    GamepadLeftTrigger = 201,
    GamepadRightTrigger = 202,
    GamepadDPadUp = 203,
    GamepadDPadDown = 204,
    GamepadDPadLeft = 205,
    GamepadDPadRight = 206,
    GamepadMenu = 207,
    GamepadView = 208,
    GamepadLeftThumbstickButton = 209,
    GamepadRightThumbstickButton = 210,
    GamepadLeftThumbstickUp = 211,
    GamepadLeftThumbstickDown = 212,
    GamepadLeftThumbstickRight = 213,
    GamepadLeftThumbstickLeft = 214,
    GamepadRightThumbstickUp = 215,
    GamepadRightThumbstickDown = 216,
    GamepadRightThumbstickRight = 217,
    GamepadRightThumbstickLeft = 218
  );
  PVirtualKey = ^VirtualKey;

  // Windows.UI.Core.CoreVirtualKeyStates
  CoreVirtualKeyStates = (
    None = 0,
    Down = 1,
    Locked = 2
  );
  PCoreVirtualKeyStates = ^CoreVirtualKeyStates;

  // Windows.UI.Core.CoreCursorType
  CoreCursorType = (
    Arrow = 0,
    Cross = 1,
    Custom = 2,
    Hand = 3,
    Help = 4,
    IBeam = 5,
    SizeAll = 6,
    SizeNortheastSouthwest = 7,
    SizeNorthSouth = 8,
    SizeNorthwestSoutheast = 9,
    SizeWestEast = 10,
    UniversalNo = 11,
    UpArrow = 12,
    Wait = 13,
    Pin = 14,
    Person = 15
  );
  PCoreCursorType = ^CoreCursorType;

  // Windows.UI.Core.CoreWindowFlowDirection
  CoreWindowFlowDirection = (
    LeftToRight = 0,
    RightToLeft = 1
  );
  PCoreWindowFlowDirection = ^CoreWindowFlowDirection;

  // Windows.UI.Core.CoreDispatcherPriority
  CoreDispatcherPriority = (
    Idle = -2,
    Low = -1,
    Normal = 0,
    High = 1
  );
  PCoreDispatcherPriority = ^CoreDispatcherPriority;

  // Windows.UI.Core.CoreProcessEventsOption
  CoreProcessEventsOption = (
    ProcessOneAndAllPending = 0,
    ProcessOneIfPresent = 1,
    ProcessUntilQuit = 2,
    ProcessAllIfPresent = 3
  );
  PCoreProcessEventsOption = ^CoreProcessEventsOption;

  // Windows.ApplicationModel.Background.BackgroundTaskCancellationReason
  BackgroundTaskCancellationReason = (
    Abort = 0,
    Terminating = 1,
    LoggingOff = 2,
    ServicingUpdate = 3,
    IdleTask = 4,
    Uninstall = 5,
    ConditionLoss = 6,
    SystemPolicy = 7,
    QuietHoursEntered = 8,
    ExecutionTimeExceeded = 9,
    ResourceRevocation = 10,
    EnergySaver = 11
  );
  PBackgroundTaskCancellationReason = ^BackgroundTaskCancellationReason;

  // Windows.System.RemoteSystems.RemoteSystemStatus
  RemoteSystems_RemoteSystemStatus = (
    Unavailable = 0,
    DiscoveringAvailability = 1,
    Available = 2,
    Unknown = 3
  );
  PRemoteSystems_RemoteSystemStatus = ^RemoteSystems_RemoteSystemStatus;

  // Windows.System.ProcessorArchitecture
  ProcessorArchitecture = (
    X86 = 0,
    Arm = 5,
    X64 = 9,
    Neutral = 11,
    Arm64 = 12,
    X86OnArm64 = 14,
    Unknown = 65535
  );
  PProcessorArchitecture = ^ProcessorArchitecture;

  // Windows.Storage.StorageItemTypes
  StorageItemTypes = (
    None = 0,
    &File = 1,
    Folder = 2
  );
  PStorageItemTypes = ^StorageItemTypes;

  // Windows.Storage.FileAttributes
  FileAttributes = (
    Normal = 0,
    ReadOnly = 1,
    Directory = 16,
    Archive = 32,
    Temporary = 256,
    LocallyIncomplete = 512
  );
  PFileAttributes = ^FileAttributes;

  // Windows.Storage.StorageDeleteOption
  StorageDeleteOption = (
    Default = 0,
    PermanentDelete = 1
  );
  PStorageDeleteOption = ^StorageDeleteOption;

  // Windows.Storage.NameCollisionOption
  NameCollisionOption = (
    GenerateUniqueName = 0,
    ReplaceExisting = 1,
    FailIfExists = 2
  );
  PNameCollisionOption = ^NameCollisionOption;

  // Windows.Storage.CreationCollisionOption
  CreationCollisionOption = (
    GenerateUniqueName = 0,
    ReplaceExisting = 1,
    FailIfExists = 2,
    OpenIfExists = 3
  );
  PCreationCollisionOption = ^CreationCollisionOption;

  // Windows.Storage.FileAccessMode
  FileAccessMode = (
    Read = 0,
    ReadWrite = 1
  );
  PFileAccessMode = ^FileAccessMode;

  // Windows.Storage.Streams.InputStreamOptions
  InputStreamOptions = (
    None = 0,
    Partial = 1,
    ReadAhead = 2
  );
  PInputStreamOptions = ^InputStreamOptions;

  // Windows.System.UserPictureSize
  UserPictureSize = (
    Size64x64 = 0,
    Size208x208 = 1,
    Size424x424 = 2,
    Size1080x1080 = 3
  );
  PUserPictureSize = ^UserPictureSize;

  // Windows.Foundation.AsyncStatus
  AsyncStatus = (
    Canceled = 2,
    Completed = 1,
    Error = 3,
    Started = 0
  );
  PAsyncStatus = ^AsyncStatus;

  // Windows.System.UserType
  UserType = (
    LocalUser = 0,
    RemoteUser = 1,
    LocalGuest = 2,
    RemoteGuest = 3,
    SystemManaged = 4
  );
  PUserType = ^UserType;

  // Windows.System.UserAuthenticationStatus
  UserAuthenticationStatus = (
    Unauthenticated = 0,
    LocallyAuthenticated = 1,
    RemotelyAuthenticated = 2
  );
  PUserAuthenticationStatus = ^UserAuthenticationStatus;

  //  Records

  // Windows.Foundation.Numerics.Vector4
  Numerics_Vector4 = record
    X: Single;
    Y: Single;
    Z: Single;
    W: Single;
  end;
  PNumerics_Vector4 = ^Numerics_Vector4;

  // Windows.Foundation.Numerics.Quaternion
  Numerics_Quaternion = record
    X: Single;
    Y: Single;
    Z: Single;
    W: Single;
  end;
  PNumerics_Quaternion = ^Numerics_Quaternion;

  // Windows.Foundation.Numerics.Matrix3x2
  Numerics_Matrix3x2 = record
    M11: Single;
    M12: Single;
    M21: Single;
    M22: Single;
    M31: Single;
    M32: Single;
  end;
  PNumerics_Matrix3x2 = ^Numerics_Matrix3x2;

  // Windows.Graphics.Imaging.BitmapPlaneDescription
  Imaging_BitmapPlaneDescription = record
    StartIndex: Integer;
    Width: Integer;
    Height: Integer;
    Stride: Integer;
  end;
  PImaging_BitmapPlaneDescription = ^Imaging_BitmapPlaneDescription;

  // Windows.Foundation.Numerics.Vector2
  Numerics_Vector2 = record
    X: Single;
    Y: Single;
  end;
  PNumerics_Vector2 = ^Numerics_Vector2;

  // Windows.Foundation.Numerics.Matrix4x4
  Numerics_Matrix4x4 = record
    M11: Single;
    M12: Single;
    M13: Single;
    M14: Single;
    M21: Single;
    M22: Single;
    M23: Single;
    M24: Single;
    M31: Single;
    M32: Single;
    M33: Single;
    M34: Single;
    M41: Single;
    M42: Single;
    M43: Single;
    M44: Single;
  end;
  PNumerics_Matrix4x4 = ^Numerics_Matrix4x4;

  // Windows.Foundation.Numerics.Vector3
  Numerics_Vector3 = record
    X: Single;
    Y: Single;
    Z: Single;
  end;
  PNumerics_Vector3 = ^Numerics_Vector3;

  // Windows.UI.Xaml.Documents.TextRange
  Documents_TextRange = record
    StartIndex: Integer;
    Length: Integer;
  end;
  PDocuments_TextRange = ^Documents_TextRange;

  // Windows.UI.Xaml.GridLength
  GridLength = record
    Value: Double;
    GridUnitType: GridUnitType;
  end;
  PGridLength = ^GridLength;

  // Windows.UI.Xaml.CornerRadius
  CornerRadius = record
    TopLeft: Double;
    TopRight: Double;
    BottomRight: Double;
    BottomLeft: Double;
  end;
  PCornerRadius = ^CornerRadius;

  // Windows.UI.Input.ManipulationVelocities
  ManipulationVelocities = record
    Linear: TPointF;
    Angular: Single;
    Expansion: Single;
  end;
  PManipulationVelocities = ^ManipulationVelocities;

  // Windows.UI.Input.ManipulationDelta
  ManipulationDelta = record
    Translation: TPointF;
    Scale: Single;
    Rotation: Single;
    Expansion: Single;
  end;
  PManipulationDelta = ^ManipulationDelta;

  // Windows.UI.Xaml.Data.LoadMoreItemsResult
  Data_LoadMoreItemsResult = record
    Count: Cardinal;
  end;
  PData_LoadMoreItemsResult = ^Data_LoadMoreItemsResult;

  // Windows.UI.Xaml.Thickness
  Thickness = record
    Left: Double;
    Top: Double;
    Right: Double;
    Bottom: Double;
  end;
  PThickness = ^Thickness;

  // Windows.UI.Xaml.Interop.TypeName
  Interop_TypeName = record
    Name: HSTRING;
    Kind: Interop_TypeKind;
  end;
  PInterop_TypeName = ^Interop_TypeName;

  // Windows.Graphics.RectInt32
  RectInt32 = record
    X: Integer;
    Y: Integer;
    Width: Integer;
    Height: Integer;
  end;
  PRectInt32 = ^RectInt32;

  // Windows.Graphics.PointInt32
  PointInt32 = record
    X: Integer;
    Y: Integer;
  end;
  PPointInt32 = ^PointInt32;

  // Windows.Graphics.SizeInt32
  SizeInt32 = record
    Width: Integer;
    Height: Integer;
  end;
  PSizeInt32 = ^SizeInt32;

  // Windows.UI.WindowId
  WindowId = record
    Value: UInt64;
  end;
  PWindowId = ^WindowId;

  // Windows.UI.Color
  Color = record
    A: Byte;
    R: Byte;
    G: Byte;
    B: Byte;
  end;
  PColor = ^Color;

  // Windows.Foundation.TimeSpan
  TimeSpan = record
    Duration: Int64;
  end;
  PTimeSpan = ^TimeSpan;

  // Windows.UI.Core.CoreProximityEvaluation
  CoreProximityEvaluation = record
    Score: Integer;
    AdjustedPoint: TPointF;
  end;
  PCoreProximityEvaluation = ^CoreProximityEvaluation;

  // Windows.Devices.Input.PointerDeviceUsage
  Input_PointerDeviceUsage = record
    UsagePage: Cardinal;
    Usage: Cardinal;
    MinLogical: Integer;
    MaxLogical: Integer;
    MinPhysical: Integer;
    MaxPhysical: Integer;
    &Unit: Cardinal;
    PhysicalMultiplier: Single;
  end;
  PInput_PointerDeviceUsage = ^Input_PointerDeviceUsage;

  // Windows.UI.Core.CorePhysicalKeyStatus
  CorePhysicalKeyStatus = record
    RepeatCount: Cardinal;
    ScanCode: Cardinal;
    IsExtendedKey: Boolean;
    IsMenuKeyDown: Boolean;
    WasKeyDown: Boolean;
    IsKeyReleased: Boolean;
  end;
  PCorePhysicalKeyStatus = ^CorePhysicalKeyStatus;

  // Windows.Foundation.EventRegistrationToken
  EventRegistrationToken = record
    Value: Int64;
  end;
  PEventRegistrationToken = ^EventRegistrationToken;

  // Windows.Foundation.DateTime
  DateTime = record
    UniversalTime: Int64;
  end;
  PDateTime = ^DateTime;

  // Windows.UI.Xaml.Duration
  Duration = record
    TimeSpan: TimeSpan;
    &Type: DurationType;
  end;
  PDuration = ^Duration;

  // DualAPI Interface
  // Windows.System.IUser
  [WinRTClassNameAttribute(SWindows_System_User)]
  IUser = interface(IInspectable)
  ['{DF9A26C6-E746-4BCD-B5D4-120103C4209B}']
    function get_NonRoamableId: HSTRING; safecall;
    function get_AuthenticationStatus: UserAuthenticationStatus; safecall;
    function get_Type: UserType; safecall;
    function GetPropertyAsync(value: HSTRING): IAsyncOperation_1__IInspectable; safecall;
    function GetPropertiesAsync(values: IVectorView_1__HSTRING): IAsyncOperation_1__IPropertySet; safecall;
    function GetPictureAsync(desiredSize: UserPictureSize): IAsyncOperation_1__IRandomAccessStreamReference; safecall;
    property AuthenticationStatus: UserAuthenticationStatus read get_AuthenticationStatus;
    property NonRoamableId: HSTRING read get_NonRoamableId;
    property &Type: UserType read get_Type;
  end;

  // Windows.Foundation.IAsyncOperation`1<Object>
  // External
  IAsyncOperation_1__IInspectable = interface(IInspectable)
  ['{ABF53C57-EE50-5342-B52A-26E3B8CC024F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IInspectable); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IInspectable; safecall;
    function GetResults: IInspectable; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IInspectable read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Object>
  // External
  AsyncOperationCompletedHandler_1__IInspectable = interface(IUnknown)
  ['{3F08262E-A2E1-5134-9297-E9211F481A2D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IInspectable; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.PropertySet>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IPropertySet>
  // External
  IAsyncOperation_1__IPropertySet = interface(IInspectable)
  ['{E3B3D8BE-D87E-5A0B-9E46-7A13FEB1A450}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IPropertySet); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IPropertySet; safecall;
    function GetResults: IPropertySet; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IPropertySet read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.PropertySet>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IPropertySet>
  // External
  AsyncOperationCompletedHandler_1__IPropertySet = interface(IUnknown)
  ['{C30D83D1-54F9-5BF2-B0F0-33CA64E0EA62}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IPropertySet; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IPropertySet
  [WinRTClassNameAttribute(SWindows_Security_Credentials_PasswordCredentialPropertyStore)]
  IPropertySet = interface(IInspectable)
  ['{8A43ED9F-F4E6-4421-ACF9-1DAB2986820C}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<String>
  // External
  IVectorView_1__HSTRING = interface(IInspectable)
  ['{2F13C006-A03A-5F69-B090-75A43E33423E}']
    function GetAt(index: Cardinal): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: HSTRING; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHSTRING): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.TargetedContentFile>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  // External
  IAsyncOperation_1__IRandomAccessStreamReference = interface(IInspectable)
  ['{BD5C30E3-29EF-57F6-97E6-B1A5C2BA73E3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IRandomAccessStreamReference); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IRandomAccessStreamReference; safecall;
    function GetResults: IRandomAccessStreamReference; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IRandomAccessStreamReference read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.TargetedContentFile>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  // External
  AsyncOperationCompletedHandler_1__IRandomAccessStreamReference = interface(IUnknown)
  ['{12049FC9-CB6B-51AB-BCC8-6E0C1930F412}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IRandomAccessStreamReference; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.Storage.Streams.IRandomAccessStreamReference
  [WinRTClassNameAttribute(SWindows_Storage_Streams_RandomAccessStreamReference)]
  IRandomAccessStreamReference = interface(IInspectable)
  ['{33EE3134-1DD6-4E3A-8067-D1C162E8642B}']
    function OpenReadAsync: IAsyncOperation_1__IRandomAccessStreamWithContentType; safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.FileProperties.StorageItemThumbnail>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  // External
  IAsyncOperation_1__IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{11C7CC5E-C04E-50E7-A65E-6F6903690C16}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType; safecall;
    function GetResults: IRandomAccessStreamWithContentType; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.FileProperties.StorageItemThumbnail>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  // External
  AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType = interface(IUnknown)
  ['{6D0036F2-A8A8-505D-B042-D087DC1FC1B7}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IRandomAccessStreamWithContentType; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Storage.Streams.IRandomAccessStreamWithContentType
  // External
  IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{CC254827-4B3D-438F-9232-10C76BC7E038}']
  end;

  // DualAPI Interface
  // Windows.Storage.IStorageFile
  [WinRTClassNameAttribute(SWindows_Storage_StorageFile)]
  IStorageFile = interface(IInspectable)
  ['{FA3F6186-4214-428C-A64C-14C9AC7315EA}']
    function get_FileType: HSTRING; safecall;
    function get_ContentType: HSTRING; safecall;
    function OpenAsync(accessMode: FileAccessMode): IAsyncOperation_1__IRandomAccessStream; safecall;
    function OpenTransactedWriteAsync: IAsyncOperation_1__IStorageStreamTransaction; safecall;
    function CopyAsync(destinationFolder: IStorageFolder): IAsyncOperation_1__IStorageFile; overload; safecall;
    function CopyAsync(destinationFolder: IStorageFolder; desiredNewName: HSTRING): IAsyncOperation_1__IStorageFile; overload; safecall;
    function CopyAsync(destinationFolder: IStorageFolder; desiredNewName: HSTRING; option: NameCollisionOption): IAsyncOperation_1__IStorageFile; overload; safecall;
    function CopyAndReplaceAsync(fileToReplace: IStorageFile): IAsyncAction; safecall;
    function MoveAsync(destinationFolder: IStorageFolder): IAsyncAction; overload; safecall;
    function MoveAsync(destinationFolder: IStorageFolder; desiredNewName: HSTRING): IAsyncAction; overload; safecall;
    function MoveAsync(destinationFolder: IStorageFolder; desiredNewName: HSTRING; option: NameCollisionOption): IAsyncAction; overload; safecall;
    function MoveAndReplaceAsync(fileToReplace: IStorageFile): IAsyncAction; safecall;
    property ContentType: HSTRING read get_ContentType;
    property FileType: HSTRING read get_FileType;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.FileRandomAccessStream>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IRandomAccessStream>
  // External
  IAsyncOperation_1__IRandomAccessStream = interface(IInspectable)
  ['{7DEFC698-0C0E-5F13-8240-38D6CE9524E4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IRandomAccessStream); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IRandomAccessStream; safecall;
    function GetResults: IRandomAccessStream; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IRandomAccessStream read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.FileRandomAccessStream>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IRandomAccessStream>
  // External
  AsyncOperationCompletedHandler_1__IRandomAccessStream = interface(IUnknown)
  ['{426CA026-2CD7-5BD8-ACE1-5C2D88A704B5}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IRandomAccessStream; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Storage.Streams.IRandomAccessStream
  // External
  IRandomAccessStream = interface(IInspectable)
  ['{905A0FE1-BC53-11DF-8C49-001E4FC686DA}']
    function get_Size: UInt64; safecall;
    procedure put_Size(value: UInt64); safecall;
    function GetInputStreamAt(position: UInt64): IInputStream; safecall;
    function GetOutputStreamAt(position: UInt64): IOutputStream; safecall;
    function get_Position: UInt64; safecall;
    procedure Seek(position: UInt64); safecall;
    function CloneStream: IRandomAccessStream; safecall;
    function get_CanRead: Boolean; safecall;
    function get_CanWrite: Boolean; safecall;
    property CanRead: Boolean read get_CanRead;
    property CanWrite: Boolean read get_CanWrite;
    property Position: UInt64 read get_Position;
    property Size: UInt64 read get_Size write put_Size;
  end;

  // DualAPI Interface
  // Windows.Storage.Streams.IInputStream
  // External
  IInputStream = interface(IInspectable)
  ['{905A0FE2-BC53-11DF-8C49-001E4FC686DA}']
    function ReadAsync(buffer: IBuffer; count: Cardinal; options: InputStreamOptions): IAsyncOperationWithProgress_2__IBuffer__Cardinal; safecall;
  end;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.Buffer,UInt32>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IBuffer,UInt32>
  // External
  IAsyncOperationWithProgress_2__IBuffer__Cardinal = interface(IInspectable)
  ['{B65E248D-E184-5797-AE90-A88CD6EC980B}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__IBuffer__Cardinal); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__IBuffer__Cardinal; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal; safecall;
    function GetResults: IBuffer; safecall;
    property Progress: AsyncOperationProgressHandler_2__IBuffer__Cardinal read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.Buffer,UInt32>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IBuffer,UInt32>
  // External
  AsyncOperationProgressHandler_2__IBuffer__Cardinal = interface(IUnknown)
  ['{38F3077E-5DB3-5086-8CFB-A84390F080BA}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IBuffer__Cardinal; progressInfo: Cardinal); safecall;
  end;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.Buffer,UInt32>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IBuffer,UInt32>
  // External
  AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal = interface(IUnknown)
  ['{CC373E50-25F3-5972-87A2-B0E2E9A8256B}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IBuffer__Cardinal; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.Storage.Streams.IBuffer
  [WinRTClassNameAttribute(SWindows_Storage_Streams_Buffer)]
  IBuffer = interface(IInspectable)
  ['{905A0FE0-BC53-11DF-8C49-001E4FC686DA}']
    function get_Capacity: Cardinal; safecall;
    function get_Length: Cardinal; safecall;
    procedure put_Length(value: Cardinal); safecall;
    property Capacity: Cardinal read get_Capacity;
    property Length: Cardinal read get_Length write put_Length;
  end;

  // DualAPI Interface
  // Windows.Storage.Streams.IOutputStream
  // External
  IOutputStream = interface(IInspectable)
  ['{905A0FE6-BC53-11DF-8C49-001E4FC686DA}']
    function WriteAsync(buffer: IBuffer): IAsyncOperationWithProgress_2__Cardinal__Cardinal; safecall;
    function FlushAsync: IAsyncOperation_1__Boolean; safecall;
  end;

  // Windows.Foundation.IAsyncOperationWithProgress`2<UInt32,UInt32>
  // External
  IAsyncOperationWithProgress_2__Cardinal__Cardinal = interface(IInspectable)
  ['{ECCB574A-C684-5572-A679-6B0842CFB57F}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__Cardinal__Cardinal); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__Cardinal__Cardinal; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal; safecall;
    function GetResults: Cardinal; safecall;
    property Progress: AsyncOperationProgressHandler_2__Cardinal__Cardinal read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationProgressHandler`2<UInt32,UInt32>
  // External
  AsyncOperationProgressHandler_2__Cardinal__Cardinal = interface(IUnknown)
  ['{EA0FE405-D432-5AC7-9EF8-5A65E1F97D7E}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Cardinal__Cardinal; progressInfo: Cardinal); safecall;
  end;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<UInt32,UInt32>
  // External
  AsyncOperationWithProgressCompletedHandler_2__Cardinal__Cardinal = interface(IUnknown)
  ['{1E466DC5-840F-54F9-B877-5E3A9F4B6C74}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Cardinal__Cardinal; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Boolean>
  // External
  IAsyncOperation_1__Boolean = interface(IInspectable)
  ['{CDB5EFB3-5788-509D-9BE1-71CCB8A3362A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Boolean); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Boolean; safecall;
    function GetResults: Boolean; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Boolean read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Boolean>
  // External
  AsyncOperationCompletedHandler_1__Boolean = interface(IUnknown)
  ['{C1D3D1A2-AE17-5A5F-B5A2-BDCC8844889A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Boolean; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.StorageStreamTransaction>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageStreamTransaction>
  // External
  IAsyncOperation_1__IStorageStreamTransaction = interface(IInspectable)
  ['{0D81405A-9BD3-5E87-82F4-9B4128A887EB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStorageStreamTransaction); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStorageStreamTransaction; safecall;
    function GetResults: IStorageStreamTransaction; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStorageStreamTransaction read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.StorageStreamTransaction>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageStreamTransaction>
  // External
  AsyncOperationCompletedHandler_1__IStorageStreamTransaction = interface(IUnknown)
  ['{D11739E6-2995-5D33-BFFF-51B6041F68C1}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStorageStreamTransaction; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Storage.IStorageStreamTransaction
  // External
  IStorageStreamTransaction = interface(IInspectable)
  ['{F67CF363-A53D-4D94-AE2C-67232D93ACDD}']
    function get_Stream: IRandomAccessStream; safecall;
    function CommitAsync: IAsyncAction; safecall;
    property Stream: IRandomAccessStream read get_Stream;
  end;

  // Windows.Foundation.IAsyncAction
  // External
  IAsyncAction = interface(IInspectable)
  ['{5A648006-843A-4DA9-865B-9D26E5DFAD7B}']
    procedure put_Completed(handler: AsyncActionCompletedHandler); safecall;
    function get_Completed: AsyncActionCompletedHandler; safecall;
    procedure GetResults; safecall;
    property Completed: AsyncActionCompletedHandler read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncActionCompletedHandler
  // External
  AsyncActionCompletedHandler = interface(IUnknown)
  ['{A4ED5C81-76C9-40BD-8BE6-B1D90FB20AE7}']
    procedure Invoke(asyncInfo: IAsyncAction; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.StorageFile>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageFile>
  // External
  IAsyncOperation_1__IStorageFile = interface(IInspectable)
  ['{5E52F8CE-ACED-5A42-95B4-F674DD84885E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStorageFile); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStorageFile; safecall;
    function GetResults: IStorageFile; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStorageFile read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.StorageFile>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageFile>
  // External
  AsyncOperationCompletedHandler_1__IStorageFile = interface(IUnknown)
  ['{E521C894-2C26-5946-9E61-2B5E188D01ED}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStorageFile; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.Storage.IStorageFolder
  [WinRTClassNameAttribute(SWindows_Storage_StorageFolder)]
  IStorageFolder = interface(IInspectable)
  ['{72D1CB78-B3EF-4F75-A80B-6FD9DAE2944B}']
    function CreateFileAsync(desiredName: HSTRING): IAsyncOperation_1__IStorageFile; overload; safecall;
    function CreateFileAsync(desiredName: HSTRING; options: CreationCollisionOption): IAsyncOperation_1__IStorageFile; overload; safecall;
    function CreateFolderAsync(desiredName: HSTRING): IAsyncOperation_1__IStorageFolder; overload; safecall;
    function CreateFolderAsync(desiredName: HSTRING; options: CreationCollisionOption): IAsyncOperation_1__IStorageFolder; overload; safecall;
    function GetFileAsync(name: HSTRING): IAsyncOperation_1__IStorageFile; safecall;
    function GetFolderAsync(name: HSTRING): IAsyncOperation_1__IStorageFolder; safecall;
    function GetItemAsync(name: HSTRING): IAsyncOperation_1__IStorageItem; safecall;
    function GetFilesAsync: IAsyncOperation_1__IVectorView_1__IStorageFile; safecall;
    function GetFoldersAsync: IAsyncOperation_1__IVectorView_1__IStorageFolder; safecall;
    function GetItemsAsync: IAsyncOperation_1__IVectorView_1__IStorageItem; safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.StorageFolder>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageFolder>
  // External
  IAsyncOperation_1__IStorageFolder = interface(IInspectable)
  ['{6BE9E7D7-E83A-5CBC-802C-1768960B52C3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStorageFolder); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStorageFolder; safecall;
    function GetResults: IStorageFolder; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStorageFolder read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.StorageFolder>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageFolder>
  // External
  AsyncOperationCompletedHandler_1__IStorageFolder = interface(IUnknown)
  ['{C211026E-9E63-5452-BA54-3A07D6A96874}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStorageFolder; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.IStorageItem>
  // External
  IAsyncOperation_1__IStorageItem = interface(IInspectable)
  ['{5FC9C137-EBB7-5E6C-9CBA-686F2EC2B0BB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStorageItem); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStorageItem; safecall;
    function GetResults: IStorageItem; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStorageItem read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.IStorageItem>
  // External
  AsyncOperationCompletedHandler_1__IStorageItem = interface(IUnknown)
  ['{92C3102F-A327-5318-A6C1-76F6B2A0ABFB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStorageItem; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.Storage.IStorageItem
  // External
  IStorageItem = interface(IInspectable)
  ['{4207A996-CA2F-42F7-BDE8-8B10457A7F30}']
    function RenameAsync(desiredName: HSTRING): IAsyncAction; overload; safecall;
    function RenameAsync(desiredName: HSTRING; option: NameCollisionOption): IAsyncAction; overload; safecall;
    function DeleteAsync: IAsyncAction; overload; safecall;
    function DeleteAsync(option: StorageDeleteOption): IAsyncAction; overload; safecall;
    function GetBasicPropertiesAsync: IAsyncOperation_1__FileProperties_IBasicProperties; safecall;
    function get_Name: HSTRING; safecall;
    function get_Path: HSTRING; safecall;
    function get_Attributes: FileAttributes; safecall;
    function get_DateCreated: DateTime; safecall;
    function IsOfType(&type: StorageItemTypes): Boolean; safecall;
    property Attributes: FileAttributes read get_Attributes;
    property DateCreated: DateTime read get_DateCreated;
    property Name: HSTRING read get_Name;
    property Path: HSTRING read get_Path;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.FileProperties.BasicProperties>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.FileProperties.IBasicProperties>
  // External
  IAsyncOperation_1__FileProperties_IBasicProperties = interface(IInspectable)
  ['{5186131A-4467-504B-977A-0785A8230485}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties; safecall;
    function GetResults: FileProperties_IBasicProperties; safecall;
    property Completed: AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.FileProperties.BasicProperties>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.FileProperties.IBasicProperties>
  // External
  AsyncOperationCompletedHandler_1__FileProperties_IBasicProperties = interface(IUnknown)
  ['{C8659AAE-4926-52AD-8F60-D89FE5A8DF5F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__FileProperties_IBasicProperties; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Storage.FileProperties.IBasicProperties
  // External
  FileProperties_IBasicProperties = interface(IInspectable)
  ['{D05D55DB-785E-4A66-BE02-9BEEC58AEA81}']
    function get_Size: UInt64; safecall;
    function get_DateModified: DateTime; safecall;
    function get_ItemDate: DateTime; safecall;
    property DateModified: DateTime read get_DateModified;
    property ItemDate: DateTime read get_ItemDate;
    property Size: UInt64 read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.StorageFile>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>>
  // External
  IAsyncOperation_1__IVectorView_1__IStorageFile = interface(IInspectable)
  ['{03362E33-E413-5F29-97D0-48A4780935F9}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile; safecall;
    function GetResults: IVectorView_1__IStorageFile; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.StorageFile>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>>
  // External
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFile = interface(IUnknown)
  ['{CB4206C5-0988-5104-AFA9-253C298F86FD}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IStorageFile; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFile>
  // External
  IVectorView_1__IStorageFile = interface(IInspectable)
  ['{4296B6E8-E219-5E74-8DDE-196F57200A82}']
    function GetAt(index: Cardinal): IStorageFile; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStorageFile; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorageFile): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.StorageFolder>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>>
  // External
  IAsyncOperation_1__IVectorView_1__IStorageFolder = interface(IInspectable)
  ['{CA40B21B-AEB1-5A61-9E08-3BD5D9594023}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder; safecall;
    function GetResults: IVectorView_1__IStorageFolder; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.StorageFolder>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>>
  // External
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageFolder = interface(IUnknown)
  ['{ED2D1D9B-26EC-5BE7-A8A3-56458933D25F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IStorageFolder; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageFolder>
  // External
  IVectorView_1__IStorageFolder = interface(IInspectable)
  ['{6A8C9209-6392-5B08-AEE9-F2ADD7DECC49}']
    function GetAt(index: Cardinal): IStorageFolder; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStorageFolder; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorageFolder): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>>
  // External
  IAsyncOperation_1__IVectorView_1__IStorageItem = interface(IInspectable)
  ['{4B1C0FD7-7A01-5E7A-A6FE-BE4500283F23}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem; safecall;
    function GetResults: IVectorView_1__IStorageItem; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>>
  // External
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorageItem = interface(IUnknown)
  ['{51436E75-ACE1-5A68-B260-F843B846F0DB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IStorageItem; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.IStorageItem>
  // External
  IVectorView_1__IStorageItem = interface(IInspectable)
  ['{85575A41-06CB-58D0-B98A-7C8F06E6E9D7}']
    function GetAt(index: Cardinal): IStorageItem; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStorageItem; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorageItem): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.System.RemoteSystems.IRemoteSystemConnectionRequest
  // External
  RemoteSystems_IRemoteSystemConnectionRequest = interface(IInspectable)
  ['{84ED4104-8D5E-4D72-8238-7621576C7A67}']
    function get_RemoteSystem: RemoteSystems_IRemoteSystem; safecall;
    property RemoteSystem: RemoteSystems_IRemoteSystem read get_RemoteSystem;
  end;

  // Windows.System.RemoteSystems.IRemoteSystem
  // External
  RemoteSystems_IRemoteSystem = interface(IInspectable)
  ['{ED5838CD-1E10-4A8C-B4A6-4E5FD6F97721}']
    function get_DisplayName: HSTRING; safecall;
    function get_Id: HSTRING; safecall;
    function get_Kind: HSTRING; safecall;
    function get_Status: RemoteSystems_RemoteSystemStatus; safecall;
    function get_IsAvailableByProximity: Boolean; safecall;
    property DisplayName: HSTRING read get_DisplayName;
    property Id: HSTRING read get_Id;
    property IsAvailableByProximity: Boolean read get_IsAvailableByProximity;
    property Kind: HSTRING read get_Kind;
    property Status: RemoteSystems_RemoteSystemStatus read get_Status;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Background.BackgroundTaskRegistrationGroup,Windows.ApplicationModel.Activation.BackgroundActivatedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Background.IBackgroundTaskRegistrationGroup,Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs>
  // External
  TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs = interface(IUnknown)
  ['{D4F89768-688F-59EC-BF24-C2AF6A310FA4}']
    procedure Invoke(sender: IBackgroundTaskRegistrationGroup; args: Activation_IBackgroundActivatedEventArgs); safecall;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskRegistrationGroup
  // External
  IBackgroundTaskRegistrationGroup = interface(IInspectable)
  ['{2AB1919A-871B-4167-8A76-055CD67B5B23}']
    function get_Id: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function add_BackgroundActivated(handler: TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs): EventRegistrationToken; safecall;
    procedure remove_BackgroundActivated(token: EventRegistrationToken); safecall;
    function get_AllTasks: IMapView_2__TGuid__IBackgroundTaskRegistration; safecall;
    property AllTasks: IMapView_2__TGuid__IBackgroundTaskRegistration read get_AllTasks;
    property Id: HSTRING read get_Id;
    property Name: HSTRING read get_Name;
  end;

  // Windows.Foundation.Collections.IMapView`2<Guid,Windows.ApplicationModel.Background.BackgroundTaskRegistration>
  // Windows.Foundation.Collections.IMapView`2<Guid,Windows.ApplicationModel.Background.IBackgroundTaskRegistration>
  // External
  IMapView_2__TGuid__IBackgroundTaskRegistration = interface(IInspectable)
  ['{2C08602F-40B1-5E97-AE21-5C04D7FB829C}']
    function Lookup(key: TGuid): IBackgroundTaskRegistration; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: TGuid): Boolean; safecall;
    procedure Split(out first: IMapView_2__TGuid__IBackgroundTaskRegistration; out second: IMapView_2__TGuid__IBackgroundTaskRegistration); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskRegistration
  // External
  IBackgroundTaskRegistration = interface(IInspectable)
  ['{10654CC2-A26E-43BF-8C12-1FB40DBFBFA0}']
    function get_TaskId: TGuid; safecall;
    function get_Name: HSTRING; safecall;
    function add_Progress(handler: BackgroundTaskProgressEventHandler): EventRegistrationToken; safecall;
    procedure remove_Progress(cookie: EventRegistrationToken); safecall;
    function add_Completed(handler: BackgroundTaskCompletedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Completed(cookie: EventRegistrationToken); safecall;
    procedure Unregister(cancelTask: Boolean); safecall;
    property Name: HSTRING read get_Name;
    property TaskId: TGuid read get_TaskId;
  end;

  // Windows.ApplicationModel.Background.BackgroundTaskProgressEventHandler
  // External
  BackgroundTaskProgressEventHandler = interface(IUnknown)
  ['{46E0683C-8A88-4C99-804C-76897F6277A6}']
    procedure Invoke(sender: IBackgroundTaskRegistration; args: IBackgroundTaskProgressEventArgs); safecall;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskProgressEventArgs
  // External
  IBackgroundTaskProgressEventArgs = interface(IInspectable)
  ['{FB1468AC-8332-4D0A-9532-03EAE684DA31}']
    function get_InstanceId: TGuid; safecall;
    function get_Progress: Cardinal; safecall;
    property InstanceId: TGuid read get_InstanceId;
    property Progress: Cardinal read get_Progress;
  end;

  // Windows.ApplicationModel.Background.BackgroundTaskCompletedEventHandler
  // External
  BackgroundTaskCompletedEventHandler = interface(IUnknown)
  ['{5B38E929-A086-46A7-A678-439135822BCF}']
    procedure Invoke(sender: IBackgroundTaskRegistration; args: IBackgroundTaskCompletedEventArgs); safecall;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskCompletedEventArgs
  // External
  IBackgroundTaskCompletedEventArgs = interface(IInspectable)
  ['{565D25CF-F209-48F4-9967-2B184F7BFBF0}']
    function get_InstanceId: TGuid; safecall;
    procedure CheckResult; safecall;
    property InstanceId: TGuid read get_InstanceId;
  end;

  // Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs
  // External
  Activation_IBackgroundActivatedEventArgs = interface(IInspectable)
  ['{AB14BEE0-E760-440E-A91C-44796DE3A92D}']
    function get_TaskInstance: IBackgroundTaskInstance; safecall;
    property TaskInstance: IBackgroundTaskInstance read get_TaskInstance;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskInstance
  // External
  IBackgroundTaskInstance = interface(IInspectable)
  ['{865BDA7A-21D8-4573-8F32-928A1B0641F6}']
    function get_InstanceId: TGuid; safecall;
    function get_Task: IBackgroundTaskRegistration; safecall;
    function get_Progress: Cardinal; safecall;
    procedure put_Progress(value: Cardinal); safecall;
    function get_TriggerDetails: IInspectable; safecall;
    function add_Canceled(cancelHandler: BackgroundTaskCanceledEventHandler): EventRegistrationToken; safecall;
    procedure remove_Canceled(cookie: EventRegistrationToken); safecall;
    function get_SuspendedCount: Cardinal; safecall;
    function GetDeferral: IBackgroundTaskDeferral; safecall;
    property InstanceId: TGuid read get_InstanceId;
    property Progress: Cardinal read get_Progress write put_Progress;
    property SuspendedCount: Cardinal read get_SuspendedCount;
    property Task: IBackgroundTaskRegistration read get_Task;
    property TriggerDetails: IInspectable read get_TriggerDetails;
  end;

  // Windows.ApplicationModel.Background.BackgroundTaskCanceledEventHandler
  // External
  BackgroundTaskCanceledEventHandler = interface(IUnknown)
  ['{A6C4BAC0-51F8-4C57-AC3F-156DD1680C4F}']
    procedure Invoke(sender: IBackgroundTaskInstance; reason: BackgroundTaskCancellationReason); safecall;
  end;

  // Windows.ApplicationModel.Background.IBackgroundTaskDeferral
  // External
  IBackgroundTaskDeferral = interface(IInspectable)
  ['{93CC156D-AF27-4DD3-846E-24EE40CADD25}']
    procedure Complete; safecall;
  end;

  // Windows.ApplicationModel.IAppDisplayInfo
  // External
  IAppDisplayInfo = interface(IInspectable)
  ['{1AEB1103-E4D4-41AA-A4F6-C4A276E79EAC}']
    function get_DisplayName: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function GetLogo(size: TSizeF): IRandomAccessStreamReference; safecall;
    property Description: HSTRING read get_Description;
    property DisplayName: HSTRING read get_DisplayName;
  end;

  // DualAPI Interface
  // Windows.ApplicationModel.IAppInfo
  [WinRTClassNameAttribute(SWindows_ApplicationModel_AppInfo)]
  IAppInfo = interface(IInspectable)
  ['{CF7F59B3-6A09-4DE8-A6C0-5792D56880D1}']
    function get_Id: HSTRING; safecall;
    function get_AppUserModelId: HSTRING; safecall;
    function get_DisplayInfo: IAppDisplayInfo; safecall;
    function get_PackageFamilyName: HSTRING; safecall;
    property AppUserModelId: HSTRING read get_AppUserModelId;
    property DisplayInfo: IAppDisplayInfo read get_DisplayInfo;
    property Id: HSTRING read get_Id;
    property PackageFamilyName: HSTRING read get_PackageFamilyName;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Core.CoreApplicationView,Windows.ApplicationModel.Activation.LockScreenComponentActivatedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Core.ICoreApplicationView,Windows.ApplicationModel.Activation.IActivatedEventArgs>
  // External
  TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs = interface(IUnknown)
  ['{71D68A1A-D6E4-5959-BA27-A596AF7151F7}']
    procedure Invoke(sender: ICoreApplicationView; args: Activation_IActivatedEventArgs); safecall;
  end;

  // Windows.ApplicationModel.Core.ICoreApplicationView
  // External
  ICoreApplicationView = interface(IInspectable)
  ['{638BB2DB-451D-4661-B099-414F34FFB9F1}']
    function get_CoreWindow: ICoreWindow; safecall;
    function add_Activated(handler: TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Activated(token: EventRegistrationToken); safecall;
    function get_IsMain: Boolean; safecall;
    function get_IsHosted: Boolean; safecall;
    property CoreWindow: ICoreWindow read get_CoreWindow;
    property IsHosted: Boolean read get_IsHosted;
    property IsMain: Boolean read get_IsMain;
  end;

  // Windows.UI.Core.ICoreWindow
  // External
  ICoreWindow = interface(IInspectable)
  ['{79B9D5F2-879E-4B89-B798-79E47598030C}']
    function get_AutomationHostProvider: IInspectable; safecall;
    function get_Bounds: TRectF; safecall;
    function get_CustomProperties: IPropertySet; safecall;
    function get_Dispatcher: ICoreDispatcher; safecall;
    function get_FlowDirection: CoreWindowFlowDirection; safecall;
    procedure put_FlowDirection(value: CoreWindowFlowDirection); safecall;
    function get_IsInputEnabled: Boolean; safecall;
    procedure put_IsInputEnabled(value: Boolean); safecall;
    function get_PointerCursor: ICoreCursor; safecall;
    procedure put_PointerCursor(value: ICoreCursor); safecall;
    function get_PointerPosition: TPointF; safecall;
    function get_Visible: Boolean; safecall;
    procedure Activate; safecall;
    procedure Close; safecall;
    function GetAsyncKeyState(virtualKey: VirtualKey): CoreVirtualKeyStates; safecall;
    function GetKeyState(virtualKey: VirtualKey): CoreVirtualKeyStates; safecall;
    procedure ReleasePointerCapture; safecall;
    procedure SetPointerCapture; safecall;
    function add_Activated(handler: TypedEventHandler_2__ICoreWindow__IWindowActivatedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Activated(cookie: EventRegistrationToken); safecall;
    function add_AutomationProviderRequested(handler: TypedEventHandler_2__ICoreWindow__IAutomationProviderRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AutomationProviderRequested(cookie: EventRegistrationToken); safecall;
    function add_CharacterReceived(handler: TypedEventHandler_2__ICoreWindow__ICharacterReceivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_CharacterReceived(cookie: EventRegistrationToken); safecall;
    function add_Closed(handler: TypedEventHandler_2__ICoreWindow__ICoreWindowEventArgs): EventRegistrationToken; safecall;
    procedure remove_Closed(cookie: EventRegistrationToken); safecall;
    function add_InputEnabled(handler: TypedEventHandler_2__ICoreWindow__IInputEnabledEventArgs): EventRegistrationToken; safecall;
    procedure remove_InputEnabled(cookie: EventRegistrationToken); safecall;
    function add_KeyDown(handler: TypedEventHandler_2__ICoreWindow__IKeyEventArgs): EventRegistrationToken; safecall;
    procedure remove_KeyDown(cookie: EventRegistrationToken); safecall;
    function add_KeyUp(handler: TypedEventHandler_2__ICoreWindow__IKeyEventArgs): EventRegistrationToken; safecall;
    procedure remove_KeyUp(cookie: EventRegistrationToken); safecall;
    function add_PointerCaptureLost(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerCaptureLost(cookie: EventRegistrationToken); safecall;
    function add_PointerEntered(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerEntered(cookie: EventRegistrationToken); safecall;
    function add_PointerExited(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerExited(cookie: EventRegistrationToken); safecall;
    function add_PointerMoved(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerMoved(cookie: EventRegistrationToken); safecall;
    function add_PointerPressed(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerPressed(cookie: EventRegistrationToken); safecall;
    function add_PointerReleased(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerReleased(cookie: EventRegistrationToken); safecall;
    function add_TouchHitTesting(handler: TypedEventHandler_2__ICoreWindow__ITouchHitTestingEventArgs): EventRegistrationToken; safecall;
    procedure remove_TouchHitTesting(cookie: EventRegistrationToken); safecall;
    function add_PointerWheelChanged(handler: TypedEventHandler_2__ICoreWindow__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerWheelChanged(cookie: EventRegistrationToken); safecall;
    function add_SizeChanged(handler: TypedEventHandler_2__ICoreWindow__IWindowSizeChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SizeChanged(cookie: EventRegistrationToken); safecall;
    function add_VisibilityChanged(handler: TypedEventHandler_2__ICoreWindow__IVisibilityChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_VisibilityChanged(cookie: EventRegistrationToken); safecall;
    property AutomationHostProvider: IInspectable read get_AutomationHostProvider;
    property Bounds: TRectF read get_Bounds;
    property CustomProperties: IPropertySet read get_CustomProperties;
    property Dispatcher: ICoreDispatcher read get_Dispatcher;
    property FlowDirection: CoreWindowFlowDirection read get_FlowDirection write put_FlowDirection;
    property IsInputEnabled: Boolean read get_IsInputEnabled write put_IsInputEnabled;
    property PointerCursor: ICoreCursor read get_PointerCursor write put_PointerCursor;
    property PointerPosition: TPointF read get_PointerPosition;
    property Visible: Boolean read get_Visible;
  end;

  // Windows.UI.Core.ICoreDispatcher
  // External
  ICoreDispatcher = interface(IInspectable)
  ['{60DB2FA8-B705-4FDE-A7D6-EBBB1891D39E}']
    function get_HasThreadAccess: Boolean; safecall;
    procedure ProcessEvents(options: CoreProcessEventsOption); safecall;
    function RunAsync(priority: CoreDispatcherPriority; agileCallback: DispatchedHandler): IAsyncAction; safecall;
    function RunIdleAsync(agileCallback: IdleDispatchedHandler): IAsyncAction; safecall;
    property HasThreadAccess: Boolean read get_HasThreadAccess;
  end;

  // Windows.UI.Core.DispatchedHandler
  // External
  DispatchedHandler = interface(IUnknown)
  ['{D1F276C4-98D8-4636-BF49-EB79507548E9}']
    procedure Invoke; safecall;
  end;

  // Windows.UI.Core.IdleDispatchedHandler
  // External
  IdleDispatchedHandler = interface(IUnknown)
  ['{A42B0C24-7F21-4ABC-99C1-8F01007F0880}']
    procedure Invoke(e: IIdleDispatchedHandlerArgs); safecall;
  end;

  // Windows.UI.Core.IIdleDispatchedHandlerArgs
  // External
  IIdleDispatchedHandlerArgs = interface(IInspectable)
  ['{98BB6A24-DC1C-43CB-B4ED-D1C0EB2391F3}']
    function get_IsDispatcherIdle: Boolean; safecall;
    property IsDispatcherIdle: Boolean read get_IsDispatcherIdle;
  end;

  // Windows.UI.Core.ICoreCursor
  // External
  ICoreCursor = interface(IInspectable)
  ['{96893ACF-111D-442C-8A77-B87992F8E2D6}']
    function get_Id: Cardinal; safecall;
    function get_Type: CoreCursorType; safecall;
    property Id: Cardinal read get_Id;
    property &Type: CoreCursorType read get_Type;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.WindowActivatedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IWindowActivatedEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IWindowActivatedEventArgs = interface(IUnknown)
  ['{26A73B35-A7F9-52DB-88D6-15726DEB2523}']
    procedure Invoke(sender: ICoreWindow; args: IWindowActivatedEventArgs); safecall;
  end;

  // Windows.UI.Core.IWindowActivatedEventArgs
  // External
  IWindowActivatedEventArgs = interface(IInspectable)
  ['{179D65E7-4658-4CB6-AA13-41D094EA255E}']
    function get_WindowActivationState: CoreWindowActivationState; safecall;
    property WindowActivationState: CoreWindowActivationState read get_WindowActivationState;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.AutomationProviderRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IAutomationProviderRequestedEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IAutomationProviderRequestedEventArgs = interface(IUnknown)
  ['{54DB5C04-81F7-5F46-9FB8-E49BEEC70A24}']
    procedure Invoke(sender: ICoreWindow; args: IAutomationProviderRequestedEventArgs); safecall;
  end;

  // Windows.UI.Core.IAutomationProviderRequestedEventArgs
  // External
  IAutomationProviderRequestedEventArgs = interface(IInspectable)
  ['{961FF258-21BF-4B42-A298-FA479D4C52E2}']
    function get_AutomationProvider: IInspectable; safecall;
    procedure put_AutomationProvider(value: IInspectable); safecall;
    property AutomationProvider: IInspectable read get_AutomationProvider write put_AutomationProvider;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.CharacterReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ICharacterReceivedEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__ICharacterReceivedEventArgs = interface(IUnknown)
  ['{73F846A8-0AF6-5872-8FB8-AE2F56D8553E}']
    procedure Invoke(sender: ICoreWindow; args: ICharacterReceivedEventArgs); safecall;
  end;

  // Windows.UI.Core.ICharacterReceivedEventArgs
  // External
  ICharacterReceivedEventArgs = interface(IInspectable)
  ['{C584659F-99B2-4BCC-BD33-04E63F42902E}']
    function get_KeyCode: Cardinal; safecall;
    function get_KeyStatus: CorePhysicalKeyStatus; safecall;
    property KeyCode: Cardinal read get_KeyCode;
    property KeyStatus: CorePhysicalKeyStatus read get_KeyStatus;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.CoreWindowEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ICoreWindowEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__ICoreWindowEventArgs = interface(IUnknown)
  ['{D08E4F66-3457-57F2-BA0C-CB347133BD15}']
    procedure Invoke(sender: ICoreWindow; args: ICoreWindowEventArgs); safecall;
  end;

  // Windows.UI.Core.ICoreWindowEventArgs
  // External
  ICoreWindowEventArgs = interface(IInspectable)
  ['{272B1EF3-C633-4DA5-A26C-C6D0F56B29DA}']
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property Handled: Boolean read get_Handled write put_Handled;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.InputEnabledEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IInputEnabledEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IInputEnabledEventArgs = interface(IUnknown)
  ['{E230A64A-506A-59C3-BB61-5559FF995663}']
    procedure Invoke(sender: ICoreWindow; args: IInputEnabledEventArgs); safecall;
  end;

  // Windows.UI.Core.IInputEnabledEventArgs
  // External
  IInputEnabledEventArgs = interface(IInspectable)
  ['{80371D4F-2FD8-4C24-AA86-3163A87B4E5A}']
    function get_InputEnabled: Boolean; safecall;
    property InputEnabled: Boolean read get_InputEnabled;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.KeyEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IKeyEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IKeyEventArgs = interface(IUnknown)
  ['{A3EC0774-55AC-5D61-8232-B35C5D35C93C}']
    procedure Invoke(sender: ICoreWindow; args: IKeyEventArgs); safecall;
  end;

  // Windows.UI.Core.IKeyEventArgs
  // External
  IKeyEventArgs = interface(IInspectable)
  ['{5FF5E930-2544-4A17-BD78-1F2FDEBB106B}']
    function get_VirtualKey: VirtualKey; safecall;
    function get_KeyStatus: CorePhysicalKeyStatus; safecall;
    property KeyStatus: CorePhysicalKeyStatus read get_KeyStatus;
    property VirtualKey_: VirtualKey read get_VirtualKey;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IPointerEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IPointerEventArgs = interface(IUnknown)
  ['{420E1BB6-E99D-5E64-8E25-07467E3CAE9E}']
    procedure Invoke(sender: ICoreWindow; args: IPointerEventArgs); safecall;
  end;

  // Windows.UI.Core.IPointerEventArgs
  // External
  IPointerEventArgs = interface(IInspectable)
  ['{920D9CB1-A5FC-4A21-8C09-49DFE6FFE25F}']
    function get_CurrentPoint: IPointerPoint; safecall;
    function get_KeyModifiers: VirtualKeyModifiers; safecall;
    function GetIntermediatePoints: IVector_1__IPointerPoint; safecall;
    property CurrentPoint: IPointerPoint read get_CurrentPoint;
    property KeyModifiers: VirtualKeyModifiers read get_KeyModifiers;
  end;

  // Windows.UI.Input.IPointerPoint
  // External
  IPointerPoint = interface(IInspectable)
  ['{E995317D-7296-42D9-8233-C5BE73B74A4A}']
    function get_PointerDevice: Input_IPointerDevice; safecall;
    function get_Position: TPointF; safecall;
    function get_RawPosition: TPointF; safecall;
    function get_PointerId: Cardinal; safecall;
    function get_FrameId: Cardinal; safecall;
    function get_Timestamp: UInt64; safecall;
    function get_IsInContact: Boolean; safecall;
    function get_Properties: IPointerPointProperties; safecall;
    property FrameId: Cardinal read get_FrameId;
    property IsInContact: Boolean read get_IsInContact;
    property PointerDevice: Input_IPointerDevice read get_PointerDevice;
    property PointerId: Cardinal read get_PointerId;
    property Position: TPointF read get_Position;
    property Properties: IPointerPointProperties read get_Properties;
    property RawPosition: TPointF read get_RawPosition;
    property Timestamp: UInt64 read get_Timestamp;
  end;

  // Windows.Devices.Input.IPointerDevice
  // External
  Input_IPointerDevice = interface(IInspectable)
  ['{93C9BAFC-EBCB-467E-82C6-276FEAE36B5A}']
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_IsIntegrated: Boolean; safecall;
    function get_MaxContacts: Cardinal; safecall;
    function get_PhysicalDeviceRect: TRectF; safecall;
    function get_ScreenRect: TRectF; safecall;
    function get_SupportedUsages: IVectorView_1__Input_PointerDeviceUsage; safecall;
    property IsIntegrated: Boolean read get_IsIntegrated;
    property MaxContacts: Cardinal read get_MaxContacts;
    property PhysicalDeviceRect: TRectF read get_PhysicalDeviceRect;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property ScreenRect: TRectF read get_ScreenRect;
    property SupportedUsages: IVectorView_1__Input_PointerDeviceUsage read get_SupportedUsages;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Input.PointerDeviceUsage>
  // External
  IVectorView_1__Input_PointerDeviceUsage = interface(IInspectable)
  ['{8E5A2C7E-3830-50D5-92BA-3163C89CBBD0}']
    function GetAt(index: Cardinal): Input_PointerDeviceUsage; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Input_PointerDeviceUsage; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInput_PointerDeviceUsage): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Input.IPointerPointProperties
  // External
  IPointerPointProperties = interface(IInspectable)
  ['{C79D8A4B-C163-4EE7-803F-67CE79F9972D}']
    function get_Pressure: Single; safecall;
    function get_IsInverted: Boolean; safecall;
    function get_IsEraser: Boolean; safecall;
    function get_Orientation: Single; safecall;
    function get_XTilt: Single; safecall;
    function get_YTilt: Single; safecall;
    function get_Twist: Single; safecall;
    function get_ContactRect: TRectF; safecall;
    function get_ContactRectRaw: TRectF; safecall;
    function get_TouchConfidence: Boolean; safecall;
    function get_IsLeftButtonPressed: Boolean; safecall;
    function get_IsRightButtonPressed: Boolean; safecall;
    function get_IsMiddleButtonPressed: Boolean; safecall;
    function get_MouseWheelDelta: Integer; safecall;
    function get_IsHorizontalMouseWheel: Boolean; safecall;
    function get_IsPrimary: Boolean; safecall;
    function get_IsInRange: Boolean; safecall;
    function get_IsCanceled: Boolean; safecall;
    function get_IsBarrelButtonPressed: Boolean; safecall;
    function get_IsXButton1Pressed: Boolean; safecall;
    function get_IsXButton2Pressed: Boolean; safecall;
    function get_PointerUpdateKind: PointerUpdateKind; safecall;
    function HasUsage(usagePage: Cardinal; usageId: Cardinal): Boolean; safecall;
    function GetUsageValue(usagePage: Cardinal; usageId: Cardinal): Integer; safecall;
    property ContactRect: TRectF read get_ContactRect;
    property ContactRectRaw: TRectF read get_ContactRectRaw;
    property IsBarrelButtonPressed: Boolean read get_IsBarrelButtonPressed;
    property IsCanceled: Boolean read get_IsCanceled;
    property IsEraser: Boolean read get_IsEraser;
    property IsHorizontalMouseWheel: Boolean read get_IsHorizontalMouseWheel;
    property IsInRange: Boolean read get_IsInRange;
    property IsInverted: Boolean read get_IsInverted;
    property IsLeftButtonPressed: Boolean read get_IsLeftButtonPressed;
    property IsMiddleButtonPressed: Boolean read get_IsMiddleButtonPressed;
    property IsPrimary: Boolean read get_IsPrimary;
    property IsRightButtonPressed: Boolean read get_IsRightButtonPressed;
    property IsXButton1Pressed: Boolean read get_IsXButton1Pressed;
    property IsXButton2Pressed: Boolean read get_IsXButton2Pressed;
    property MouseWheelDelta: Integer read get_MouseWheelDelta;
    property Orientation: Single read get_Orientation;
    property PointerUpdateKind_: PointerUpdateKind read get_PointerUpdateKind;
    property Pressure: Single read get_Pressure;
    property TouchConfidence: Boolean read get_TouchConfidence;
    property Twist: Single read get_Twist;
    property XTilt: Single read get_XTilt;
    property YTilt: Single read get_YTilt;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Input.PointerPoint>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Input.IPointerPoint>
  // External
  IVector_1__IPointerPoint = interface(IInspectable)
  ['{DFA655CF-FDE7-5048-B4BF-C909231B7EDB}']
    function GetAt(index: Cardinal): IPointerPoint; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IPointerPoint; safecall;
    function IndexOf(value: IPointerPoint; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IPointerPoint); safecall;
    procedure InsertAt(index: Cardinal; value: IPointerPoint); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IPointerPoint); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPointerPoint): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIPointerPoint); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.IPointerPoint>
  // External
  IVectorView_1__IPointerPoint = interface(IInspectable)
  ['{1697E0A0-DFE4-5BAE-AC51-F4C43FCEF82B}']
    function GetAt(index: Cardinal): IPointerPoint; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IPointerPoint; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPointerPoint): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.TouchHitTestingEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.ITouchHitTestingEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__ITouchHitTestingEventArgs = interface(IUnknown)
  ['{197654C9-0C47-502B-9AA1-0DEB03ED9702}']
    procedure Invoke(sender: ICoreWindow; args: ITouchHitTestingEventArgs); safecall;
  end;

  // Windows.UI.Core.ITouchHitTestingEventArgs
  // External
  ITouchHitTestingEventArgs = interface(IInspectable)
  ['{22F3B823-0B7C-424E-9DF7-33D4F962931B}']
    function get_ProximityEvaluation: CoreProximityEvaluation; safecall;
    procedure put_ProximityEvaluation(value: CoreProximityEvaluation); safecall;
    function get_Point: TPointF; safecall;
    function get_BoundingBox: TRectF; safecall;
    function EvaluateProximity(controlBoundingBox: TRectF): CoreProximityEvaluation; overload; safecall;
    function EvaluateProximity(controlVerticesSize: Cardinal; controlVertices: PPointF): CoreProximityEvaluation; overload; safecall;
    property BoundingBox: TRectF read get_BoundingBox;
    property Point: TPointF read get_Point;
    property ProximityEvaluation: CoreProximityEvaluation read get_ProximityEvaluation write put_ProximityEvaluation;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.WindowSizeChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IWindowSizeChangedEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IWindowSizeChangedEventArgs = interface(IUnknown)
  ['{318DBB67-4089-5690-9040-1D454FB2F686}']
    procedure Invoke(sender: ICoreWindow; args: IWindowSizeChangedEventArgs); safecall;
  end;

  // Windows.UI.Core.IWindowSizeChangedEventArgs
  // External
  IWindowSizeChangedEventArgs = interface(IInspectable)
  ['{5A200EC7-0426-47DC-B86C-6F475915E451}']
    function get_Size: TSizeF; safecall;
    property Size: TSizeF read get_Size;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.CoreWindow,Windows.UI.Core.VisibilityChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Core.ICoreWindow,Windows.UI.Core.IVisibilityChangedEventArgs>
  // External
  TypedEventHandler_2__ICoreWindow__IVisibilityChangedEventArgs = interface(IUnknown)
  ['{14B7F692-5583-52A1-AA42-FC1843C0F748}']
    procedure Invoke(sender: ICoreWindow; args: IVisibilityChangedEventArgs); safecall;
  end;

  // Windows.UI.Core.IVisibilityChangedEventArgs
  // External
  IVisibilityChangedEventArgs = interface(IInspectable)
  ['{BF9918EA-D801-4564-A495-B1E84F8AD085}']
    function get_Visible: Boolean; safecall;
    property Visible: Boolean read get_Visible;
  end;

  // Windows.ApplicationModel.Activation.IActivatedEventArgs
  // External
  Activation_IActivatedEventArgs = interface(IInspectable)
  ['{CF651713-CD08-4FD8-B697-A281B6544E2E}']
    function get_Kind: Activation_ActivationKind; safecall;
    function get_PreviousExecutionState: Activation_ApplicationExecutionState; safecall;
    function get_SplashScreen: Activation_ISplashScreen; safecall;
    property Kind: Activation_ActivationKind read get_Kind;
    property PreviousExecutionState: Activation_ApplicationExecutionState read get_PreviousExecutionState;
    property SplashScreen: Activation_ISplashScreen read get_SplashScreen;
  end;

  // Windows.ApplicationModel.Activation.ISplashScreen
  // External
  Activation_ISplashScreen = interface(IInspectable)
  ['{CA4D975C-D4D6-43F0-97C0-0833C6391C24}']
    function get_ImageLocation: TRectF; safecall;
    function add_Dismissed(handler: TypedEventHandler_2__Activation_ISplashScreen__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Dismissed(cookie: EventRegistrationToken); safecall;
    property ImageLocation: TRectF read get_ImageLocation;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Activation.SplashScreen,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.Activation.ISplashScreen,Object>
  // External
  TypedEventHandler_2__Activation_ISplashScreen__IInspectable = interface(IUnknown)
  ['{7725B2A5-287D-5ED2-A789-2A6A2673C7FE}']
    procedure Invoke(sender: Activation_ISplashScreen; args: IInspectable); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.System.UserChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.System.IUserChangedEventArgs>
  // External
  TypedEventHandler_2__Input_IGameController__IUserChangedEventArgs = interface(IUnknown)
  ['{CB753F2C-2F36-5A8F-ADAD-057BEAE73AA4}']
    procedure Invoke(sender: Input_IGameController; args: IUserChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.Gaming.Input.IGameController
  // External
  Input_IGameController = interface(IInspectable)
  ['{1BAF6522-5F64-42C5-8267-B9FE2215BFBD}']
    function add_HeadsetConnected(value: TypedEventHandler_2__Input_IGameController__Input_IHeadset): EventRegistrationToken; safecall;
    procedure remove_HeadsetConnected(token: EventRegistrationToken); safecall;
    function add_HeadsetDisconnected(value: TypedEventHandler_2__Input_IGameController__Input_IHeadset): EventRegistrationToken; safecall;
    procedure remove_HeadsetDisconnected(token: EventRegistrationToken); safecall;
    function add_UserChanged(value: TypedEventHandler_2__Input_IGameController__IUserChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_UserChanged(token: EventRegistrationToken); safecall;
    function get_Headset: Input_IHeadset; safecall;
    function get_IsWireless: Boolean; safecall;
    function get_User: IUser; safecall;
    property Headset: Input_IHeadset read get_Headset;
    property IsWireless: Boolean read get_IsWireless;
    property User: IUser read get_User;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.Gaming.Input.Headset>
  // Windows.Foundation.TypedEventHandler`2<Windows.Gaming.Input.IGameController,Windows.Gaming.Input.IHeadset>
  // External
  TypedEventHandler_2__Input_IGameController__Input_IHeadset = interface(IUnknown)
  ['{07B2F2B7-8825-5C4E-A052-FCFEDF3AEEA1}']
    procedure Invoke(sender: Input_IGameController; args: Input_IHeadset); safecall;
  end;

  // Windows.Gaming.Input.IHeadset
  // External
  Input_IHeadset = interface(IInspectable)
  ['{3FD156EF-6925-3FA8-9181-029C5223AE3B}']
    function get_CaptureDeviceId: HSTRING; safecall;
    function get_RenderDeviceId: HSTRING; safecall;
    property CaptureDeviceId: HSTRING read get_CaptureDeviceId;
    property RenderDeviceId: HSTRING read get_RenderDeviceId;
  end;

  // Windows.System.IUserChangedEventArgs
  // External
  IUserChangedEventArgs = interface(IInspectable)
  ['{086459DC-18C6-48DB-BC99-724FB9203CCC}']
    function get_User: IUser; safecall;
    property User: IUser read get_User;
  end;

  // Windows.Devices.Power.IBatteryReport
  // External
  Power_IBatteryReport = interface(IInspectable)
  ['{C9858C3A-4E13-420A-A8D0-24F18F395401}']
    function get_ChargeRateInMilliwatts: IReference_1__Integer; safecall;
    function get_DesignCapacityInMilliwattHours: IReference_1__Integer; safecall;
    function get_FullChargeCapacityInMilliwattHours: IReference_1__Integer; safecall;
    function get_RemainingCapacityInMilliwattHours: IReference_1__Integer; safecall;
    function get_Status: Power_BatteryStatus; safecall;
    property ChargeRateInMilliwatts: IReference_1__Integer read get_ChargeRateInMilliwatts;
    property DesignCapacityInMilliwattHours: IReference_1__Integer read get_DesignCapacityInMilliwattHours;
    property FullChargeCapacityInMilliwattHours: IReference_1__Integer read get_FullChargeCapacityInMilliwattHours;
    property RemainingCapacityInMilliwattHours: IReference_1__Integer read get_RemainingCapacityInMilliwattHours;
    property Status: Power_BatteryStatus read get_Status;
  end;

  // Windows.Foundation.IReference`1<Int32>
  // External
  IReference_1__Integer = interface(IInspectable)
  ['{548CEFBD-BC8A-5FA0-8DF2-957440FC8BF4}']
    function get_Value: Integer; safecall;
    property Value: Integer read get_Value;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.ISimpleHapticsController>
  // External
  IVectorView_1__Haptics_ISimpleHapticsController = interface(IInspectable)
  ['{1B1C9184-A6EB-52D4-BCBE-5DCBE538DD7F}']
    function GetAt(index: Cardinal): Haptics_ISimpleHapticsController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Haptics_ISimpleHapticsController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHaptics_ISimpleHapticsController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Devices.Haptics.ISimpleHapticsController
  // External
  Haptics_ISimpleHapticsController = interface(IInspectable)
  ['{3D577EF9-4CEE-11E6-B535-001BDC06AB3B}']
    function get_Id: HSTRING; safecall;
    function get_SupportedFeedback: IVectorView_1__Haptics_ISimpleHapticsControllerFeedback; safecall;
    function get_IsIntensitySupported: Boolean; safecall;
    function get_IsPlayCountSupported: Boolean; safecall;
    function get_IsPlayDurationSupported: Boolean; safecall;
    function get_IsReplayPauseIntervalSupported: Boolean; safecall;
    procedure StopFeedback; safecall;
    procedure SendHapticFeedback(feedback: Haptics_ISimpleHapticsControllerFeedback); overload; safecall;
    procedure SendHapticFeedback(feedback: Haptics_ISimpleHapticsControllerFeedback; intensity: Double); overload; safecall;
    procedure SendHapticFeedbackForDuration(feedback: Haptics_ISimpleHapticsControllerFeedback; intensity: Double; playDuration: TimeSpan); safecall;
    procedure SendHapticFeedbackForPlayCount(feedback: Haptics_ISimpleHapticsControllerFeedback; intensity: Double; playCount: Integer; replayPauseInterval: TimeSpan); safecall;
    property Id: HSTRING read get_Id;
    property IsIntensitySupported: Boolean read get_IsIntensitySupported;
    property IsPlayCountSupported: Boolean read get_IsPlayCountSupported;
    property IsPlayDurationSupported: Boolean read get_IsPlayDurationSupported;
    property IsReplayPauseIntervalSupported: Boolean read get_IsReplayPauseIntervalSupported;
    property SupportedFeedback: IVectorView_1__Haptics_ISimpleHapticsControllerFeedback read get_SupportedFeedback;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  // External
  IVectorView_1__Haptics_ISimpleHapticsControllerFeedback = interface(IInspectable)
  ['{FE0D7BA7-AF19-52A8-A31C-5678ACB7F93A}']
    function GetAt(index: Cardinal): Haptics_ISimpleHapticsControllerFeedback; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Haptics_ISimpleHapticsControllerFeedback; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHaptics_ISimpleHapticsControllerFeedback): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Devices.Haptics.ISimpleHapticsControllerFeedback
  // External
  Haptics_ISimpleHapticsControllerFeedback = interface(IInspectable)
  ['{3D577EF8-4CEE-11E6-B535-001BDC06AB3B}']
    function get_Waveform: Word; safecall;
    function get_Duration: TimeSpan; safecall;
    property Duration: TimeSpan read get_Duration;
    property Waveform: Word read get_Waveform;
  end;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.ApplicationModel.Resources.Core.ResourceContextLanguagesVectorView>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Foundation.Collections.IVectorView`1<String>>
  // External
  IMapView_2__HSTRING__IVectorView_1__HSTRING = interface(IInspectable)
  ['{396E79BE-5667-5843-8020-B1F2B0CE0166}']
    function Lookup(key: HSTRING): IVectorView_1__HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IVectorView_1__HSTRING; out second: IMapView_2__HSTRING__IVectorView_1__HSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformation
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformation)]
  IDeviceInformation = interface(IInspectable)
  ['{ABA0FB95-4398-489D-8E44-E6130927011F}']
    function get_Id: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_IsEnabled: Boolean; safecall;
    function get_IsDefault: Boolean; safecall;
    function get_EnclosureLocation: IEnclosureLocation; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    procedure Update(updateInfo: IDeviceInformationUpdate); safecall;
    function GetThumbnailAsync: IAsyncOperation_1__IRandomAccessStreamWithContentType; safecall;
    function GetGlyphThumbnailAsync: IAsyncOperation_1__IRandomAccessStreamWithContentType; safecall;
    property EnclosureLocation: IEnclosureLocation read get_EnclosureLocation;
    property Id: HSTRING read get_Id;
    property IsDefault: Boolean read get_IsDefault;
    property IsEnabled: Boolean read get_IsEnabled;
    property Name: HSTRING read get_Name;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Devices.Enumeration.IEnclosureLocation
  // External
  IEnclosureLocation = interface(IInspectable)
  ['{42340A27-5810-459C-AABB-C65E1F813ECF}']
    function get_InDock: Boolean; safecall;
    function get_InLid: Boolean; safecall;
    function get_Panel: Panel; safecall;
    property InDock: Boolean read get_InDock;
    property InLid: Boolean read get_InLid;
    property Panel_: Panel read get_Panel;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Object>
  // External
  IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{BB78502A-F79D-54FA-92C9-90C5039FDF7E}']
    function Lookup(key: HSTRING): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IInspectable; out second: IMapView_2__HSTRING__IInspectable); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Devices.Enumeration.IDeviceInformationUpdate
  // External
  IDeviceInformationUpdate = interface(IInspectable)
  ['{8F315305-D972-44B7-A37E-9E822C78213B}']
    function get_Id: HSTRING; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property Id: HSTRING read get_Id;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Foundation.Collections.IIterable`1<String>
  // External
  IIterable_1__HSTRING = interface(IInspectable)
  ['{E2FCC7C1-3BFC-5A0B-B2B0-72E769D1CB7E}']
    function First: IIterator_1__HSTRING; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<String>
  // External
  IIterator_1__HSTRING = interface(IInspectable)
  ['{8C304EBB-6615-50A4-8829-879ECD443236}']
    function get_Current: HSTRING; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHSTRING): Cardinal; safecall;
    property Current: HSTRING read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IVectorChangedEventArgs
  // External
  IVectorChangedEventArgs = interface(IInspectable)
  ['{575933DF-34FE-4480-AF15-07691F3D5D9B}']
    function get_CollectionChange: CollectionChange; safecall;
    function get_Index: Cardinal; safecall;
    property CollectionChange_: CollectionChange read get_CollectionChange;
    property Index: Cardinal read get_Index;
  end;

  // Windows.Foundation.Collections.IMapView`2<Guid,Object>
  // External
  IMapView_2__TGuid__IInspectable = interface(IInspectable)
  ['{E4D2C732-BBC1-5EF4-869F-5007CEB55F6E}']
    function Lookup(key: TGuid): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: TGuid): Boolean; safecall;
    procedure Split(out first: IMapView_2__TGuid__IInspectable; out second: IMapView_2__TGuid__IInspectable); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IMap`2<Guid,Object>
  [WinRTClassNameAttribute(SWindows_Media_MediaProperties_MediaPropertySet)]
  IMap_2__TGuid__IInspectable = interface(IInspectable)
  ['{5EE3189C-7DBF-5998-AD07-5414FB82567C}']
    function Lookup(key: TGuid): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: TGuid): Boolean; safecall;
    function GetView: IMapView_2__TGuid__IInspectable; safecall;
    function Insert(key: TGuid; value: IInspectable): Boolean; safecall;
    procedure Remove(key: TGuid); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Devices.Enumeration.IDevicePickerAppearance
  // External
  IDevicePickerAppearance = interface(IInspectable)
  ['{E69A12C6-E627-4ED8-9B6C-460AF445E56D}']
    function get_Title: HSTRING; safecall;
    procedure put_Title(value: HSTRING); safecall;
    function get_ForegroundColor: Color; safecall;
    procedure put_ForegroundColor(value: Color); safecall;
    function get_BackgroundColor: Color; safecall;
    procedure put_BackgroundColor(value: Color); safecall;
    function get_AccentColor: Color; safecall;
    procedure put_AccentColor(value: Color); safecall;
    function get_SelectedForegroundColor: Color; safecall;
    procedure put_SelectedForegroundColor(value: Color); safecall;
    function get_SelectedBackgroundColor: Color; safecall;
    procedure put_SelectedBackgroundColor(value: Color); safecall;
    function get_SelectedAccentColor: Color; safecall;
    procedure put_SelectedAccentColor(value: Color); safecall;
    property AccentColor: Color read get_AccentColor write put_AccentColor;
    property BackgroundColor: Color read get_BackgroundColor write put_BackgroundColor;
    property ForegroundColor: Color read get_ForegroundColor write put_ForegroundColor;
    property SelectedAccentColor: Color read get_SelectedAccentColor write put_SelectedAccentColor;
    property SelectedBackgroundColor: Color read get_SelectedBackgroundColor write put_SelectedBackgroundColor;
    property SelectedForegroundColor: Color read get_SelectedForegroundColor write put_SelectedForegroundColor;
    property Title: HSTRING read get_Title write put_Title;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.MediaPlaybackItem,Windows.Foundation.Collections.IVectorChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlaybackItem,Windows.Foundation.Collections.IVectorChangedEventArgs>
  // External
  TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs = interface(IUnknown)
  ['{2DD51918-4525-5BE5-A6C1-409BC72863A6}']
    procedure Invoke(sender: Playback_IMediaPlaybackItem; args: IVectorChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.Media.Playback.IMediaPlaybackItem
  [WinRTClassNameAttribute(SWindows_Media_Playback_MediaPlaybackItem)]
  Playback_IMediaPlaybackItem = interface(IInspectable)
  ['{047097D2-E4AF-48AB-B283-6929E674ECE2}']
    function add_AudioTracksChanged(handler: TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AudioTracksChanged(token: EventRegistrationToken); safecall;
    function add_VideoTracksChanged(handler: TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_VideoTracksChanged(token: EventRegistrationToken); safecall;
    function add_TimedMetadataTracksChanged(handler: TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TimedMetadataTracksChanged(token: EventRegistrationToken); safecall;
    function get_Source: Core_IMediaSource2; safecall;
    function get_AudioTracks: IVectorView_1__Core_IMediaTrack; safecall;
    function get_VideoTracks: IVectorView_1__Core_IMediaTrack; safecall;
    function get_TimedMetadataTracks: IVectorView_1__Core_ITimedMetadataTrack; safecall;
    property AudioTracks: IVectorView_1__Core_IMediaTrack read get_AudioTracks;
    property Source: Core_IMediaSource2 read get_Source;
    property TimedMetadataTracks: IVectorView_1__Core_ITimedMetadataTrack read get_TimedMetadataTracks;
    property VideoTracks: IVectorView_1__Core_IMediaTrack read get_VideoTracks;
  end;

  // DualAPI Interface
  // Windows.Media.Core.IMediaSource2
  // External
  Core_IMediaSource2 = interface(IInspectable)
  ['{2EB61048-655F-4C37-B813-B4E45DFA0ABE}']
    function add_OpenOperationCompleted(handler: TypedEventHandler_2__Core_IMediaSource2__Core_IMediaSourceOpenOperationCompletedEventArgs): EventRegistrationToken; safecall;
    procedure remove_OpenOperationCompleted(token: EventRegistrationToken); safecall;
    function get_CustomProperties: IPropertySet; safecall;
    function get_Duration: IReference_1__TimeSpan; safecall;
    function get_IsOpen: Boolean; safecall;
    function get_ExternalTimedTextSources: IObservableVector_1__Core_ITimedTextSource; safecall;
    function get_ExternalTimedMetadataTracks: IObservableVector_1__Core_ITimedMetadataTrack; safecall;
    property CustomProperties: IPropertySet read get_CustomProperties;
    property Duration: IReference_1__TimeSpan read get_Duration;
    property ExternalTimedMetadataTracks: IObservableVector_1__Core_ITimedMetadataTrack read get_ExternalTimedMetadataTracks;
    property ExternalTimedTextSources: IObservableVector_1__Core_ITimedTextSource read get_ExternalTimedTextSources;
    property IsOpen: Boolean read get_IsOpen;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.MediaSource,Windows.Media.Core.MediaSourceOpenOperationCompletedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.IMediaSource2,Windows.Media.Core.IMediaSourceOpenOperationCompletedEventArgs>
  // External
  TypedEventHandler_2__Core_IMediaSource2__Core_IMediaSourceOpenOperationCompletedEventArgs = interface(IUnknown)
  ['{425D53E3-FBA6-5EA3-B713-DB4D70787436}']
    procedure Invoke(sender: Core_IMediaSource2; args: Core_IMediaSourceOpenOperationCompletedEventArgs); safecall;
  end;

  // Windows.Media.Core.IMediaSourceOpenOperationCompletedEventArgs
  // External
  Core_IMediaSourceOpenOperationCompletedEventArgs = interface(IInspectable)
  ['{FC682CEB-E281-477C-A8E0-1ACD654114C8}']
    function get_Error: Core_IMediaSourceError; safecall;
    property Error: Core_IMediaSourceError read get_Error;
  end;

  // Windows.Media.Core.IMediaSourceError
  // External
  Core_IMediaSourceError = interface(IInspectable)
  ['{5C0A8965-37C5-4E9D-8D21-1CDEE90CECC6}']
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
  end;

  // Windows.Foundation.IReference`1<Windows.Foundation.TimeSpan>
  // External
  IReference_1__TimeSpan = interface(IInspectable)
  ['{604D0C4C-91DE-5C2A-935F-362F13EAF800}']
    function get_Value: TimeSpan; safecall;
    property Value: TimeSpan read get_Value;
  end;

  // Windows.Foundation.Collections.IObservableVector`1<Windows.Media.Core.ITimedTextSource>
  // External
  IObservableVector_1__Core_ITimedTextSource = interface(IInspectable)
  ['{0C98C465-6D21-5D0F-9682-7337B29F0B91}']
    function add_VectorChanged(vhnd: VectorChangedEventHandler_1__Core_ITimedTextSource): EventRegistrationToken; safecall;
    procedure remove_VectorChanged(token: EventRegistrationToken); safecall;
  end;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.TimedTextSource>
  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.ITimedTextSource>
  // External
  VectorChangedEventHandler_1__Core_ITimedTextSource = interface(IUnknown)
  ['{E12E6261-B198-56E0-9822-BA2D3BB6F8FE}']
    procedure Invoke(sender: IObservableVector_1__Core_ITimedTextSource; event: IVectorChangedEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IObservableVector`1<Windows.Media.Core.ITimedMetadataTrack>
  // External
  IObservableVector_1__Core_ITimedMetadataTrack = interface(IInspectable)
  ['{19EAC50E-BEBF-58B6-B8B7-DB6B157EEAEC}']
    function add_VectorChanged(vhnd: VectorChangedEventHandler_1__Core_ITimedMetadataTrack): EventRegistrationToken; safecall;
    procedure remove_VectorChanged(token: EventRegistrationToken); safecall;
  end;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.TimedMetadataTrack>
  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.Media.Core.ITimedMetadataTrack>
  // External
  VectorChangedEventHandler_1__Core_ITimedMetadataTrack = interface(IUnknown)
  ['{BD1DC81C-23C4-5B4B-AC38-C5D34CDF34E4}']
    procedure Invoke(sender: IObservableVector_1__Core_ITimedMetadataTrack; event: IVectorChangedEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IMediaTrack>
  // External
  IVectorView_1__Core_IMediaTrack = interface(IInspectable)
  ['{1CE05BEC-9E9B-5108-9D24-80E1C8C2866E}']
    function GetAt(index: Cardinal): Core_IMediaTrack; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_IMediaTrack; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IMediaTrack): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Media.Core.IMediaTrack
  // External
  Core_IMediaTrack = interface(IInspectable)
  ['{03E1FAFC-C931-491A-B46B-C10EE8C256B7}']
    function get_Id: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_TrackKind: Core_MediaTrackKind; safecall;
    procedure put_Label(value: HSTRING); safecall;
    function get_Label: HSTRING; safecall;
    property Id: HSTRING read get_Id;
    property &Label: HSTRING read get_Label write put_Label;
    property Language: HSTRING read get_Language;
    property TrackKind: Core_MediaTrackKind read get_TrackKind;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.ITimedMetadataTrack>
  // External
  IVectorView_1__Core_ITimedMetadataTrack = interface(IInspectable)
  ['{DD588DAC-C2FE-523F-B519-6DDEAA5281A9}']
    function GetAt(index: Cardinal): Core_ITimedMetadataTrack; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_ITimedMetadataTrack; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_ITimedMetadataTrack): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Media.Core.ITimedMetadataTrack
  [WinRTClassNameAttribute(SWindows_Media_Core_TimedMetadataTrack)]
  Core_ITimedMetadataTrack = interface(IInspectable)
  ['{9E6AED9E-F67A-49A9-B330-CF03B0E9CF07}']
    function add_CueEntered(handler: TypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs): EventRegistrationToken; safecall;
    procedure remove_CueEntered(token: EventRegistrationToken); safecall;
    function add_CueExited(handler: TypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs): EventRegistrationToken; safecall;
    procedure remove_CueExited(token: EventRegistrationToken); safecall;
    function add_TrackFailed(handler: TypedEventHandler_2__Core_ITimedMetadataTrack__Core_ITimedMetadataTrackFailedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TrackFailed(token: EventRegistrationToken); safecall;
    function get_Cues: IVectorView_1__Core_IMediaCue; safecall;
    function get_ActiveCues: IVectorView_1__Core_IMediaCue; safecall;
    function get_TimedMetadataKind: Core_TimedMetadataKind; safecall;
    function get_DispatchType: HSTRING; safecall;
    procedure AddCue(cue: Core_IMediaCue); safecall;
    procedure RemoveCue(cue: Core_IMediaCue); safecall;
    property ActiveCues: IVectorView_1__Core_IMediaCue read get_ActiveCues;
    property Cues: IVectorView_1__Core_IMediaCue read get_Cues;
    property DispatchType: HSTRING read get_DispatchType;
    property TimedMetadataKind: Core_TimedMetadataKind read get_TimedMetadataKind;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.TimedMetadataTrack,Windows.Media.Core.MediaCueEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.ITimedMetadataTrack,Windows.Media.Core.IMediaCueEventArgs>
  // External
  TypedEventHandler_2__Core_ITimedMetadataTrack__Core_IMediaCueEventArgs = interface(IUnknown)
  ['{4AAC9411-C355-5C95-8C78-5A0F5CA1A54D}']
    procedure Invoke(sender: Core_ITimedMetadataTrack; args: Core_IMediaCueEventArgs); safecall;
  end;

  // Windows.Media.Core.IMediaCueEventArgs
  // External
  Core_IMediaCueEventArgs = interface(IInspectable)
  ['{D12F47F7-5FA4-4E68-9FE5-32160DCEE57E}']
    function get_Cue: Core_IMediaCue; safecall;
    property Cue: Core_IMediaCue read get_Cue;
  end;

  // DualAPI Interface
  // Windows.Media.Core.IMediaCue
  // External
  Core_IMediaCue = interface(IInspectable)
  ['{C7D15E5D-59DC-431F-A0EE-27744323B36D}']
    procedure put_StartTime(value: TimeSpan); safecall;
    function get_StartTime: TimeSpan; safecall;
    procedure put_Duration(value: TimeSpan); safecall;
    function get_Duration: TimeSpan; safecall;
    procedure put_Id(value: HSTRING); safecall;
    function get_Id: HSTRING; safecall;
    property Duration: TimeSpan read get_Duration write put_Duration;
    property Id: HSTRING read get_Id write put_Id;
    property StartTime: TimeSpan read get_StartTime write put_StartTime;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.TimedMetadataTrack,Windows.Media.Core.TimedMetadataTrackFailedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Core.ITimedMetadataTrack,Windows.Media.Core.ITimedMetadataTrackFailedEventArgs>
  // External
  TypedEventHandler_2__Core_ITimedMetadataTrack__Core_ITimedMetadataTrackFailedEventArgs = interface(IUnknown)
  ['{8DC73162-255B-532E-B0C7-9A6D70B4BB9E}']
    procedure Invoke(sender: Core_ITimedMetadataTrack; args: Core_ITimedMetadataTrackFailedEventArgs); safecall;
  end;

  // Windows.Media.Core.ITimedMetadataTrackFailedEventArgs
  // External
  Core_ITimedMetadataTrackFailedEventArgs = interface(IInspectable)
  ['{A57FC9D1-6789-4D4D-B07F-84B4F31ACB70}']
    function get_Error: Core_ITimedMetadataTrackError; safecall;
    property Error: Core_ITimedMetadataTrackError read get_Error;
  end;

  // Windows.Media.Core.ITimedMetadataTrackError
  // External
  Core_ITimedMetadataTrackError = interface(IInspectable)
  ['{B3767915-4114-4819-B9D9-DD76089E72F8}']
    function get_ErrorCode: Core_TimedMetadataTrackErrorCode; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ErrorCode: Core_TimedMetadataTrackErrorCode read get_ErrorCode;
    property ExtendedError: HRESULT read get_ExtendedError;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IMediaCue>
  // External
  IVectorView_1__Core_IMediaCue = interface(IInspectable)
  ['{996421A1-625C-5D92-AD68-8B3911D294B0}']
    function GetAt(index: Cardinal): Core_IMediaCue; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_IMediaCue; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IMediaCue): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Storage.FileProperties.IMusicProperties
  // External
  FileProperties_IMusicProperties = interface(IInspectable)
  ['{BC8AAB62-66EC-419A-BC5D-CA65A4CB46DA}']
    function get_Album: HSTRING; safecall;
    procedure put_Album(value: HSTRING); safecall;
    function get_Artist: HSTRING; safecall;
    procedure put_Artist(value: HSTRING); safecall;
    function get_Genre: IVector_1__HSTRING; safecall;
    function get_TrackNumber: Cardinal; safecall;
    procedure put_TrackNumber(value: Cardinal); safecall;
    function get_Title: HSTRING; safecall;
    procedure put_Title(value: HSTRING); safecall;
    function get_Rating: Cardinal; safecall;
    procedure put_Rating(value: Cardinal); safecall;
    function get_Duration: TimeSpan; safecall;
    function get_Bitrate: Cardinal; safecall;
    function get_AlbumArtist: HSTRING; safecall;
    procedure put_AlbumArtist(value: HSTRING); safecall;
    function get_Composers: IVector_1__HSTRING; safecall;
    function get_Conductors: IVector_1__HSTRING; safecall;
    function get_Subtitle: HSTRING; safecall;
    procedure put_Subtitle(value: HSTRING); safecall;
    function get_Producers: IVector_1__HSTRING; safecall;
    function get_Publisher: HSTRING; safecall;
    procedure put_Publisher(value: HSTRING); safecall;
    function get_Writers: IVector_1__HSTRING; safecall;
    function get_Year: Cardinal; safecall;
    procedure put_Year(value: Cardinal); safecall;
    property Album: HSTRING read get_Album write put_Album;
    property AlbumArtist: HSTRING read get_AlbumArtist write put_AlbumArtist;
    property Artist: HSTRING read get_Artist write put_Artist;
    property Bitrate: Cardinal read get_Bitrate;
    property Composers: IVector_1__HSTRING read get_Composers;
    property Conductors: IVector_1__HSTRING read get_Conductors;
    property Duration: TimeSpan read get_Duration;
    property Genre: IVector_1__HSTRING read get_Genre;
    property Producers: IVector_1__HSTRING read get_Producers;
    property Publisher: HSTRING read get_Publisher write put_Publisher;
    property Rating: Cardinal read get_Rating write put_Rating;
    property Subtitle: HSTRING read get_Subtitle write put_Subtitle;
    property Title: HSTRING read get_Title write put_Title;
    property TrackNumber: Cardinal read get_TrackNumber write put_TrackNumber;
    property Writers: IVector_1__HSTRING read get_Writers;
    property Year: Cardinal read get_Year write put_Year;
  end;

  // Windows.Foundation.Collections.IVector`1<String>
  // External
  IVector_1__HSTRING = interface(IInspectable)
  ['{98B9ACC1-4B56-532E-AC73-03D5291CCA90}']
    function GetAt(index: Cardinal): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__HSTRING; safecall;
    function IndexOf(value: HSTRING; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: HSTRING); safecall;
    procedure InsertAt(index: Cardinal; value: HSTRING); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: HSTRING); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHSTRING): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PHSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Storage.FileProperties.IVideoProperties
  // External
  FileProperties_IVideoProperties = interface(IInspectable)
  ['{719AE507-68DE-4DB8-97DE-49998C059F2F}']
    function get_Rating: Cardinal; safecall;
    procedure put_Rating(value: Cardinal); safecall;
    function get_Keywords: IVector_1__HSTRING; safecall;
    function get_Width: Cardinal; safecall;
    function get_Height: Cardinal; safecall;
    function get_Duration: TimeSpan; safecall;
    function get_Latitude: IReference_1__Double; safecall;
    function get_Longitude: IReference_1__Double; safecall;
    function get_Title: HSTRING; safecall;
    procedure put_Title(value: HSTRING); safecall;
    function get_Subtitle: HSTRING; safecall;
    procedure put_Subtitle(value: HSTRING); safecall;
    function get_Producers: IVector_1__HSTRING; safecall;
    function get_Publisher: HSTRING; safecall;
    procedure put_Publisher(value: HSTRING); safecall;
    function get_Writers: IVector_1__HSTRING; safecall;
    function get_Year: Cardinal; safecall;
    procedure put_Year(value: Cardinal); safecall;
    function get_Bitrate: Cardinal; safecall;
    function get_Directors: IVector_1__HSTRING; safecall;
    function get_Orientation: FileProperties_VideoOrientation; safecall;
    property Bitrate: Cardinal read get_Bitrate;
    property Directors: IVector_1__HSTRING read get_Directors;
    property Duration: TimeSpan read get_Duration;
    property Height: Cardinal read get_Height;
    property Keywords: IVector_1__HSTRING read get_Keywords;
    property Latitude: IReference_1__Double read get_Latitude;
    property Longitude: IReference_1__Double read get_Longitude;
    property Orientation: FileProperties_VideoOrientation read get_Orientation;
    property Producers: IVector_1__HSTRING read get_Producers;
    property Publisher: HSTRING read get_Publisher write put_Publisher;
    property Rating: Cardinal read get_Rating write put_Rating;
    property Subtitle: HSTRING read get_Subtitle write put_Subtitle;
    property Title: HSTRING read get_Title write put_Title;
    property Width: Cardinal read get_Width;
    property Writers: IVector_1__HSTRING read get_Writers;
    property Year: Cardinal read get_Year write put_Year;
  end;

  // Windows.Foundation.IReference`1<Double>
  // External
  IReference_1__Double = interface(IInspectable)
  ['{2F2D6C29-5473-5F3E-92E7-96572BB990E2}']
    function get_Value: Double; safecall;
    property Value: Double read get_Value;
  end;

  // Windows.Foundation.Collections.IVectorView`1<UInt32>
  // External
  IVectorView_1__Cardinal = interface(IInspectable)
  ['{E5CE1A07-8D33-5007-BA64-7D2508CCF85C}']
    function GetAt(index: Cardinal): Cardinal; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Cardinal; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCardinal): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IMap`2<String,String>
  [WinRTClassNameAttribute(SWindows_Foundation_Collections_StringMap)]
  IMap_2__HSTRING__HSTRING = interface(IInspectable)
  ['{F6D1F700-49C2-52AE-8154-826F9908773C}']
    function Lookup(key: HSTRING): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    function GetView: IMapView_2__HSTRING__HSTRING; safecall;
    function Insert(key: HSTRING; value: HSTRING): Boolean; safecall;
    procedure Remove(key: HSTRING); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IMapView`2<String,String>
  // External
  IMapView_2__HSTRING__HSTRING = interface(IInspectable)
  ['{AC7F26F2-FEB7-5B2A-8AC4-345BC62CAEDE}']
    function Lookup(key: HSTRING): HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__HSTRING; out second: IMapView_2__HSTRING__HSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Globalization.ILanguage
  [WinRTClassNameAttribute(SWindows_Globalization_Language)]
  ILanguage = interface(IInspectable)
  ['{EA79A752-F7C2-4265-B1BD-C4DEC4E4F080}']
    function get_LanguageTag: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_NativeName: HSTRING; safecall;
    function get_Script: HSTRING; safecall;
    property DisplayName: HSTRING read get_DisplayName;
    property LanguageTag: HSTRING read get_LanguageTag;
    property NativeName: HSTRING read get_NativeName;
    property Script: HSTRING read get_Script;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Globalization.ILanguage>
  // External
  IVectorView_1__ILanguage = interface(IInspectable)
  ['{9026F0A6-FDC5-55A7-BEE7-500E55ECBC3F}']
    function GetAt(index: Cardinal): ILanguage; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ILanguage; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PILanguage): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Storage.StorageFile>
  // Windows.Foundation.Collections.IVector`1<Windows.Storage.IStorageFile>
  // External
  IVector_1__IStorageFile = interface(IInspectable)
  ['{FCBC8B8B-6103-5B4E-BA00-4BC2CEDB6A35}']
    function GetAt(index: Cardinal): IStorageFile; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IStorageFile; safecall;
    function IndexOf(value: IStorageFile; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IStorageFile); safecall;
    procedure InsertAt(index: Cardinal; value: IStorageFile); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IStorageFile); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorageFile): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIStorageFile); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Media.Effects.IAudioCaptureEffectsManager
  // External
  Effects_IAudioCaptureEffectsManager = interface(IInspectable)
  ['{8F85C271-038D-4393-8298-540110608EEF}']
    function add_AudioCaptureEffectsChanged(handler: TypedEventHandler_2__Effects_IAudioCaptureEffectsManager__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AudioCaptureEffectsChanged(token: EventRegistrationToken); safecall;
    function GetAudioCaptureEffects: IVectorView_1__Effects_IAudioEffect; safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Effects.AudioCaptureEffectsManager,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Effects.IAudioCaptureEffectsManager,Object>
  // External
  TypedEventHandler_2__Effects_IAudioCaptureEffectsManager__IInspectable = interface(IUnknown)
  ['{A1C5E803-A275-5BB1-9D44-2AC8AE9FFB89}']
    procedure Invoke(sender: Effects_IAudioCaptureEffectsManager; args: IInspectable); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Effects.IAudioEffect>
  // External
  IVectorView_1__Effects_IAudioEffect = interface(IInspectable)
  ['{C99A8712-7619-5C0B-8932-64385686A17D}']
    function GetAt(index: Cardinal): Effects_IAudioEffect; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Effects_IAudioEffect; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PEffects_IAudioEffect): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Media.Effects.IAudioEffect
  // External
  Effects_IAudioEffect = interface(IInspectable)
  ['{34AAFA51-9207-4055-BE93-6E5734A86AE4}']
    function get_AudioEffectType: Effects_AudioEffectType; safecall;
    property AudioEffectType: Effects_AudioEffectType read get_AudioEffectType;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.AudioStreamDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.IAudioStreamDescriptor>
  // External
  IIterable_1__Core_IAudioStreamDescriptor = interface(IInspectable)
  ['{A3E2C972-A171-5B94-8389-E983EBC3F3B9}']
    function First: IIterator_1__Core_IAudioStreamDescriptor; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.AudioStreamDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.IAudioStreamDescriptor>
  // External
  IIterator_1__Core_IAudioStreamDescriptor = interface(IInspectable)
  ['{A61A11CD-B32E-518B-A6A7-5472CBE00E83}']
    function get_Current: Core_IAudioStreamDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PCore_IAudioStreamDescriptor): Cardinal; safecall;
    property Current: Core_IAudioStreamDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // Windows.Media.Core.IAudioStreamDescriptor
  [WinRTClassNameAttribute(SWindows_Media_Core_AudioStreamDescriptor)]
  Core_IAudioStreamDescriptor = interface(IInspectable)
  ['{1E3692E4-4027-4847-A70B-DF1D9A2A7B04}']
    function get_EncodingProperties: IAudioEncodingProperties; safecall;
    property EncodingProperties: IAudioEncodingProperties read get_EncodingProperties;
  end;

  // DualAPI Interface
  // Windows.Media.MediaProperties.IAudioEncodingProperties
  [WinRTClassNameAttribute(SWindows_Media_MediaProperties_AudioEncodingProperties)]
  IAudioEncodingProperties = interface(IInspectable)
  ['{62BC7A16-005C-4B3B-8A0B-0A090E9687F3}']
    procedure put_Bitrate(value: Cardinal); safecall;
    function get_Bitrate: Cardinal; safecall;
    procedure put_ChannelCount(value: Cardinal); safecall;
    function get_ChannelCount: Cardinal; safecall;
    procedure put_SampleRate(value: Cardinal); safecall;
    function get_SampleRate: Cardinal; safecall;
    procedure put_BitsPerSample(value: Cardinal); safecall;
    function get_BitsPerSample: Cardinal; safecall;
    property Bitrate: Cardinal read get_Bitrate write put_Bitrate;
    property BitsPerSample: Cardinal read get_BitsPerSample write put_BitsPerSample;
    property ChannelCount: Cardinal read get_ChannelCount write put_ChannelCount;
    property SampleRate: Cardinal read get_SampleRate write put_SampleRate;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.AudioStreamDescriptor>
  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.IAudioStreamDescriptor>
  // External
  IVector_1__Core_IAudioStreamDescriptor = interface(IInspectable)
  ['{45AFC129-988C-5F1E-9C17-6E34B917CD1B}']
    function GetAt(index: Cardinal): Core_IAudioStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Core_IAudioStreamDescriptor; safecall;
    function IndexOf(value: Core_IAudioStreamDescriptor; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Core_IAudioStreamDescriptor); safecall;
    procedure InsertAt(index: Cardinal; value: Core_IAudioStreamDescriptor); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Core_IAudioStreamDescriptor); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IAudioStreamDescriptor): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PCore_IAudioStreamDescriptor); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IAudioStreamDescriptor>
  // External
  IVectorView_1__Core_IAudioStreamDescriptor = interface(IInspectable)
  ['{A97548F5-13ED-5B5D-86C2-D9853F89CBD3}']
    function GetAt(index: Cardinal): Core_IAudioStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_IAudioStreamDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IAudioStreamDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.VideoStreamDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.IVideoStreamDescriptor>
  // External
  IIterable_1__Core_IVideoStreamDescriptor = interface(IInspectable)
  ['{3ACBF03C-0A79-5823-AAA9-D88BC3F8F594}']
    function First: IIterator_1__Core_IVideoStreamDescriptor; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.VideoStreamDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.IVideoStreamDescriptor>
  // External
  IIterator_1__Core_IVideoStreamDescriptor = interface(IInspectable)
  ['{DA51AB3C-3C64-545C-A3F4-F9B055AAF7D9}']
    function get_Current: Core_IVideoStreamDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PCore_IVideoStreamDescriptor): Cardinal; safecall;
    property Current: Core_IVideoStreamDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // Windows.Media.Core.IVideoStreamDescriptor
  [WinRTClassNameAttribute(SWindows_Media_Core_VideoStreamDescriptor)]
  Core_IVideoStreamDescriptor = interface(IInspectable)
  ['{12EE0D55-9C2B-4440-8057-2C7A90F0CBEC}']
    function get_EncodingProperties: IVideoEncodingProperties; safecall;
    property EncodingProperties: IVideoEncodingProperties read get_EncodingProperties;
  end;

  // DualAPI Interface
  // Windows.Media.MediaProperties.IVideoEncodingProperties
  [WinRTClassNameAttribute(SWindows_Media_MediaProperties_VideoEncodingProperties)]
  IVideoEncodingProperties = interface(IInspectable)
  ['{76EE6C9A-37C2-4F2A-880A-1282BBB4373D}']
    procedure put_Bitrate(value: Cardinal); safecall;
    function get_Bitrate: Cardinal; safecall;
    procedure put_Width(value: Cardinal); safecall;
    function get_Width: Cardinal; safecall;
    procedure put_Height(value: Cardinal); safecall;
    function get_Height: Cardinal; safecall;
    function get_FrameRate: IMediaRatio; safecall;
    function get_PixelAspectRatio: IMediaRatio; safecall;
    property Bitrate: Cardinal read get_Bitrate write put_Bitrate;
    property FrameRate: IMediaRatio read get_FrameRate;
    property Height: Cardinal read get_Height write put_Height;
    property PixelAspectRatio: IMediaRatio read get_PixelAspectRatio;
    property Width: Cardinal read get_Width write put_Width;
  end;

  // Windows.Media.MediaProperties.IMediaRatio
  // External
  IMediaRatio = interface(IInspectable)
  ['{D2D0FEE5-8929-401D-AC78-7D357E378163}']
    procedure put_Numerator(value: Cardinal); safecall;
    function get_Numerator: Cardinal; safecall;
    procedure put_Denominator(value: Cardinal); safecall;
    function get_Denominator: Cardinal; safecall;
    property Denominator: Cardinal read get_Denominator write put_Denominator;
    property Numerator: Cardinal read get_Numerator write put_Numerator;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.VideoStreamDescriptor>
  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.IVideoStreamDescriptor>
  // External
  IVector_1__Core_IVideoStreamDescriptor = interface(IInspectable)
  ['{1FB064B3-636C-5988-9C97-02A9B76150F6}']
    function GetAt(index: Cardinal): Core_IVideoStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Core_IVideoStreamDescriptor; safecall;
    function IndexOf(value: Core_IVideoStreamDescriptor; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Core_IVideoStreamDescriptor); safecall;
    procedure InsertAt(index: Cardinal; value: Core_IVideoStreamDescriptor); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Core_IVideoStreamDescriptor); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IVideoStreamDescriptor): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PCore_IVideoStreamDescriptor); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.IVideoStreamDescriptor>
  // External
  IVectorView_1__Core_IVideoStreamDescriptor = interface(IInspectable)
  ['{169BE92A-80D0-5ABF-A578-524970C2FEF3}']
    function GetAt(index: Cardinal): Core_IVideoStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_IVideoStreamDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_IVideoStreamDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.TimedMetadataStreamDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  // External
  IIterable_1__Core_ITimedMetadataStreamDescriptor = interface(IInspectable)
  ['{E566DEC3-82BE-5932-A118-279E44FDB4FF}']
    function First: IIterator_1__Core_ITimedMetadataStreamDescriptor; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.TimedMetadataStreamDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  // External
  IIterator_1__Core_ITimedMetadataStreamDescriptor = interface(IInspectable)
  ['{FA175D1B-B5D9-510A-BBAF-60421A685667}']
    function get_Current: Core_ITimedMetadataStreamDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PCore_ITimedMetadataStreamDescriptor): Cardinal; safecall;
    property Current: Core_ITimedMetadataStreamDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Media.Core.ITimedMetadataStreamDescriptor
  // External
  Core_ITimedMetadataStreamDescriptor = interface(IInspectable)
  ['{133336BF-296A-463E-9FF9-01CD25691408}']
    function get_EncodingProperties: ITimedMetadataEncodingProperties; safecall;
    function Copy: Core_ITimedMetadataStreamDescriptor; safecall;
    property EncodingProperties: ITimedMetadataEncodingProperties read get_EncodingProperties;
  end;

  // Windows.Media.MediaProperties.ITimedMetadataEncodingProperties
  // External
  ITimedMetadataEncodingProperties = interface(IInspectable)
  ['{51CD30D3-D690-4CFA-97F4-4A398E9DB420}']
    procedure SetFormatUserData(valueSize: Cardinal; value: PByte); safecall;
    procedure GetFormatUserData(valueSize: Cardinal; value: PByte); safecall;
    function Copy: ITimedMetadataEncodingProperties; safecall;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.TimedMetadataStreamDescriptor>
  // Windows.Foundation.Collections.IVector`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  // External
  IVector_1__Core_ITimedMetadataStreamDescriptor = interface(IInspectable)
  ['{07A8D080-17ED-5DD0-A002-A905AAC5A85D}']
    function GetAt(index: Cardinal): Core_ITimedMetadataStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Core_ITimedMetadataStreamDescriptor; safecall;
    function IndexOf(value: Core_ITimedMetadataStreamDescriptor; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Core_ITimedMetadataStreamDescriptor); safecall;
    procedure InsertAt(index: Cardinal; value: Core_ITimedMetadataStreamDescriptor); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Core_ITimedMetadataStreamDescriptor); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_ITimedMetadataStreamDescriptor): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PCore_ITimedMetadataStreamDescriptor); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Core.ITimedMetadataStreamDescriptor>
  // External
  IVectorView_1__Core_ITimedMetadataStreamDescriptor = interface(IInspectable)
  ['{5727E975-BF2B-5175-8A15-BB2E99094563}']
    function GetAt(index: Cardinal): Core_ITimedMetadataStreamDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Core_ITimedMetadataStreamDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCore_ITimedMetadataStreamDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Networking.IHostName
  [WinRTClassNameAttribute(SWindows_Networking_HostName)]
  IHostName = interface(IInspectable)
  ['{BF8ECAAD-ED96-49A7-9084-D416CAE88DCB}']
    function get_IPInformation: IIPInformation; safecall;
    function get_RawName: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_CanonicalName: HSTRING; safecall;
    function get_Type: HostNameType; safecall;
    function IsEqual(hostName: IHostName): Boolean; safecall;
    property CanonicalName: HSTRING read get_CanonicalName;
    property DisplayName: HSTRING read get_DisplayName;
    property IPInformation: IIPInformation read get_IPInformation;
    property RawName: HSTRING read get_RawName;
    property &Type: HostNameType read get_Type;
  end;

  // Windows.Networking.Connectivity.IIPInformation
  // External
  IIPInformation = interface(IInspectable)
  ['{D85145E0-138F-47D7-9B3A-36BB488CEF33}']
    function get_NetworkAdapter: INetworkAdapter; safecall;
    function get_PrefixLength: IReference_1__Byte; safecall;
    property NetworkAdapter: INetworkAdapter read get_NetworkAdapter;
    property PrefixLength: IReference_1__Byte read get_PrefixLength;
  end;

  // Windows.Networking.Connectivity.INetworkAdapter
  // External
  INetworkAdapter = interface(IInspectable)
  ['{3B542E03-5388-496C-A8A3-AFFD39AEC2E6}']
    function get_OutboundMaxBitsPerSecond: UInt64; safecall;
    function get_InboundMaxBitsPerSecond: UInt64; safecall;
    function get_IanaInterfaceType: Cardinal; safecall;
    function get_NetworkItem: INetworkItem; safecall;
    function get_NetworkAdapterId: TGuid; safecall;
    function GetConnectedProfileAsync: IAsyncOperation_1__IConnectionProfile; safecall;
    property IanaInterfaceType: Cardinal read get_IanaInterfaceType;
    property InboundMaxBitsPerSecond: UInt64 read get_InboundMaxBitsPerSecond;
    property NetworkAdapterId: TGuid read get_NetworkAdapterId;
    property NetworkItem: INetworkItem read get_NetworkItem;
    property OutboundMaxBitsPerSecond: UInt64 read get_OutboundMaxBitsPerSecond;
  end;

  // Windows.Networking.Connectivity.INetworkItem
  // External
  INetworkItem = interface(IInspectable)
  ['{01BC4D39-F5E0-4567-A28C-42080C831B2B}']
    function get_NetworkId: TGuid; safecall;
    function GetNetworkTypes: NetworkTypes; safecall;
    property NetworkId: TGuid read get_NetworkId;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.Connectivity.ConnectionProfile>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.Connectivity.IConnectionProfile>
  // External
  IAsyncOperation_1__IConnectionProfile = interface(IInspectable)
  ['{5BF519CA-8ADB-5AB5-ABB8-FF1BBE5D2DE8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IConnectionProfile); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IConnectionProfile; safecall;
    function GetResults: IConnectionProfile; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IConnectionProfile read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.Connectivity.ConnectionProfile>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.Connectivity.IConnectionProfile>
  // External
  AsyncOperationCompletedHandler_1__IConnectionProfile = interface(IUnknown)
  ['{E4F0C96A-0571-59F4-A9A9-AFAC3E61CAA0}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IConnectionProfile; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Networking.Connectivity.IConnectionProfile
  // External
  IConnectionProfile = interface(IInspectable)
  ['{71BA143C-598E-49D0-84EB-8FEBAEDCC195}']
    function get_ProfileName: HSTRING; safecall;
    function GetNetworkConnectivityLevel: NetworkConnectivityLevel; safecall;
    function GetNetworkNames: IVectorView_1__HSTRING; safecall;
    function GetConnectionCost: IConnectionCost; safecall;
    function GetDataPlanStatus: IDataPlanStatus; safecall;
    function get_NetworkAdapter: INetworkAdapter; safecall;
    function GetLocalUsage(StartTime: DateTime; EndTime: DateTime): IDataUsage; overload; safecall;
    function GetLocalUsage(StartTime: DateTime; EndTime: DateTime; States: RoamingStates): IDataUsage; overload; safecall;
    function get_NetworkSecuritySettings: INetworkSecuritySettings; safecall;
    property NetworkAdapter: INetworkAdapter read get_NetworkAdapter;
    property NetworkSecuritySettings: INetworkSecuritySettings read get_NetworkSecuritySettings;
    property ProfileName: HSTRING read get_ProfileName;
  end;

  // Windows.Networking.Connectivity.IConnectionCost
  // External
  IConnectionCost = interface(IInspectable)
  ['{BAD7D829-3416-4B10-A202-BAC0B075BDAE}']
    function get_NetworkCostType: NetworkCostType; safecall;
    function get_Roaming: Boolean; safecall;
    function get_OverDataLimit: Boolean; safecall;
    function get_ApproachingDataLimit: Boolean; safecall;
    property ApproachingDataLimit: Boolean read get_ApproachingDataLimit;
    property NetworkCostType_: NetworkCostType read get_NetworkCostType;
    property OverDataLimit: Boolean read get_OverDataLimit;
    property Roaming: Boolean read get_Roaming;
  end;

  // Windows.Networking.Connectivity.IDataPlanStatus
  // External
  IDataPlanStatus = interface(IInspectable)
  ['{977A8B8C-3885-40F3-8851-42CD2BD568BB}']
    function get_DataPlanUsage: IDataPlanUsage; safecall;
    function get_DataLimitInMegabytes: IReference_1__Cardinal; safecall;
    function get_InboundBitsPerSecond: IReference_1__UInt64; safecall;
    function get_OutboundBitsPerSecond: IReference_1__UInt64; safecall;
    function get_NextBillingCycle: IReference_1__DateTime; safecall;
    function get_MaxTransferSizeInMegabytes: IReference_1__Cardinal; safecall;
    property DataLimitInMegabytes: IReference_1__Cardinal read get_DataLimitInMegabytes;
    property DataPlanUsage: IDataPlanUsage read get_DataPlanUsage;
    property InboundBitsPerSecond: IReference_1__UInt64 read get_InboundBitsPerSecond;
    property MaxTransferSizeInMegabytes: IReference_1__Cardinal read get_MaxTransferSizeInMegabytes;
    property NextBillingCycle: IReference_1__DateTime read get_NextBillingCycle;
    property OutboundBitsPerSecond: IReference_1__UInt64 read get_OutboundBitsPerSecond;
  end;

  // Windows.Networking.Connectivity.IDataPlanUsage
  // External
  IDataPlanUsage = interface(IInspectable)
  ['{B921492D-3B44-47FF-B361-BE59E69ED1B0}']
    function get_MegabytesUsed: Cardinal; safecall;
    function get_LastSyncTime: DateTime; safecall;
    property LastSyncTime: DateTime read get_LastSyncTime;
    property MegabytesUsed: Cardinal read get_MegabytesUsed;
  end;

  // Windows.Foundation.IReference`1<UInt32>
  // External
  IReference_1__Cardinal = interface(IInspectable)
  ['{513EF3AF-E784-5325-A91E-97C2B8111CF3}']
    function get_Value: Cardinal; safecall;
    property Value: Cardinal read get_Value;
  end;

  // Windows.Foundation.IReference`1<UInt64>
  // External
  IReference_1__UInt64 = interface(IInspectable)
  ['{6755E376-53BB-568B-A11D-17239868309E}']
    function get_Value: UInt64; safecall;
    property Value: UInt64 read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.Foundation.DateTime>
  // External
  IReference_1__DateTime = interface(IInspectable)
  ['{5541D8A7-497C-5AA4-86FC-7713ADBF2A2C}']
    function get_Value: DateTime; safecall;
    property Value: DateTime read get_Value;
  end;

  // Windows.Networking.Connectivity.IDataUsage
  // External
  IDataUsage = interface(IInspectable)
  ['{C1431DD3-B146-4D39-B959-0C69B096C512}']
    function get_BytesSent: UInt64; safecall;
    function get_BytesReceived: UInt64; safecall;
    property BytesReceived: UInt64 read get_BytesReceived;
    property BytesSent: UInt64 read get_BytesSent;
  end;

  // Windows.Networking.Connectivity.INetworkSecuritySettings
  // External
  INetworkSecuritySettings = interface(IInspectable)
  ['{7CA07E8D-917B-4B5F-B84D-28F7A5AC5402}']
    function get_NetworkAuthenticationType: NetworkAuthenticationType; safecall;
    function get_NetworkEncryptionType: NetworkEncryptionType; safecall;
    property NetworkAuthenticationType_: NetworkAuthenticationType read get_NetworkAuthenticationType;
    property NetworkEncryptionType_: NetworkEncryptionType read get_NetworkEncryptionType;
  end;

  // Windows.Foundation.IReference`1<UInt8>
  // External
  IReference_1__Byte = interface(IInspectable)
  ['{E5198CC8-2873-55F5-B0A1-84FF9E4AAD62}']
    function get_Value: Byte; safecall;
    property Value: Byte read get_Value;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IHostName>
  // External
  IVectorView_1__IHostName = interface(IInspectable)
  ['{FB26F077-BEFF-523E-81C2-5A710F18359D}']
    function GetAt(index: Cardinal): IHostName; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IHostName; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIHostName): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>
  // External
  IVectorView_1__IEndpointPair = interface(IInspectable)
  ['{C1DD3EA0-5F59-5BA6-B7B2-58413F0FAA36}']
    function GetAt(index: Cardinal): IEndpointPair; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IEndpointPair; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIEndpointPair): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Networking.IEndpointPair
  [WinRTClassNameAttribute(SWindows_Networking_EndpointPair)]
  IEndpointPair = interface(IInspectable)
  ['{33A0AA36-F8FA-4B30-B856-76517C3BD06D}']
    function get_LocalHostName: IHostName; safecall;
    procedure put_LocalHostName(value: IHostName); safecall;
    function get_LocalServiceName: HSTRING; safecall;
    procedure put_LocalServiceName(value: HSTRING); safecall;
    function get_RemoteHostName: IHostName; safecall;
    procedure put_RemoteHostName(value: IHostName); safecall;
    function get_RemoteServiceName: HSTRING; safecall;
    procedure put_RemoteServiceName(value: HSTRING); safecall;
    property LocalHostName: IHostName read get_LocalHostName write put_LocalHostName;
    property LocalServiceName: HSTRING read get_LocalServiceName write put_LocalServiceName;
    property RemoteHostName: IHostName read get_RemoteHostName write put_RemoteHostName;
    property RemoteServiceName: HSTRING read get_RemoteServiceName write put_RemoteServiceName;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.EndpointPair>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.IEndpointPair>
  // External
  IIterable_1__IEndpointPair = interface(IInspectable)
  ['{D7EC83C4-A17B-51BF-8997-AA33B9102DC9}']
    function First: IIterator_1__IEndpointPair; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.EndpointPair>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.IEndpointPair>
  // External
  IIterator_1__IEndpointPair = interface(IInspectable)
  ['{C899FF9F-E6F5-5673-810C-04E2FF98704F}']
    function get_Current: IEndpointPair; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIEndpointPair): Cardinal; safecall;
    property Current: IEndpointPair read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // Windows.System.IDispatcherQueue
  [WinRTClassNameAttribute(SWindows_System_DispatcherQueue)]
  IDispatcherQueue = interface(IInspectable)
  ['{603E88E4-A338-4FFE-A457-A5CFB9CEB899}']
    function CreateTimer: IDispatcherQueueTimer; safecall;
    function TryEnqueue(callback: DispatcherQueueHandler): Boolean; overload; safecall;
    function TryEnqueue(priority: DispatcherQueuePriority; callback: DispatcherQueueHandler): Boolean; overload; safecall;
    function add_ShutdownStarting(handler: TypedEventHandler_2__IDispatcherQueue__IDispatcherQueueShutdownStartingEventArgs): EventRegistrationToken; safecall;
    procedure remove_ShutdownStarting(token: EventRegistrationToken); safecall;
    function add_ShutdownCompleted(handler: TypedEventHandler_2__IDispatcherQueue__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ShutdownCompleted(token: EventRegistrationToken); safecall;
  end;

  // Windows.System.IDispatcherQueueTimer
  // External
  IDispatcherQueueTimer = interface(IInspectable)
  ['{5FEABB1D-A31C-4727-B1AC-37454649D56A}']
    function get_Interval: TimeSpan; safecall;
    procedure put_Interval(value: TimeSpan); safecall;
    function get_IsRunning: Boolean; safecall;
    function get_IsRepeating: Boolean; safecall;
    procedure put_IsRepeating(value: Boolean); safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    function add_Tick(handler: TypedEventHandler_2__IDispatcherQueueTimer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Tick(token: EventRegistrationToken); safecall;
    property Interval: TimeSpan read get_Interval write put_Interval;
    property IsRepeating: Boolean read get_IsRepeating write put_IsRepeating;
    property IsRunning: Boolean read get_IsRunning;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.System.DispatcherQueueTimer,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueueTimer,Object>
  // External
  TypedEventHandler_2__IDispatcherQueueTimer__IInspectable = interface(IUnknown)
  ['{8B5644C8-8B57-50CE-8933-7AB2CC5A14EF}']
    procedure Invoke(sender: IDispatcherQueueTimer; args: IInspectable); safecall;
  end;

  // Windows.System.DispatcherQueueHandler
  // External
  DispatcherQueueHandler = interface(IUnknown)
  ['{DFA2DC9C-1A2D-4917-98F2-939AF1D6E0C8}']
    procedure Invoke; safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.System.DispatcherQueue,Windows.System.DispatcherQueueShutdownStartingEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueue,Windows.System.IDispatcherQueueShutdownStartingEventArgs>
  // External
  TypedEventHandler_2__IDispatcherQueue__IDispatcherQueueShutdownStartingEventArgs = interface(IUnknown)
  ['{B58B5E24-E1C6-528E-9D99-07EC8829DEA5}']
    procedure Invoke(sender: IDispatcherQueue; args: IDispatcherQueueShutdownStartingEventArgs); safecall;
  end;

  // Windows.System.IDispatcherQueueShutdownStartingEventArgs
  // External
  IDispatcherQueueShutdownStartingEventArgs = interface(IInspectable)
  ['{C4724C4C-FF97-40C0-A226-CC0AAA545E89}']
    function GetDeferral: IDeferral; safecall;
  end;

  // DualAPI Interface
  // Windows.Foundation.IDeferral
  [WinRTClassNameAttribute(SWindows_Foundation_Deferral)]
  IDeferral = interface(IInspectable)
  ['{D6269732-3B7F-46A7-B40B-4FDCA2A2C693}']
    procedure Complete; safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.System.DispatcherQueue,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.System.IDispatcherQueue,Object>
  // External
  TypedEventHandler_2__IDispatcherQueue__IInspectable = interface(IUnknown)
  ['{FE79F855-2F40-5B88-A0C3-4C042A05DD05}']
    procedure Invoke(sender: IDispatcherQueue; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // Windows.Graphics.Effects.IGraphicsEffect
  // External
  Effects_IGraphicsEffect = interface(IInspectable)
  ['{CB51C0CE-8FE6-4636-B202-861FAA07D8F3}']
    function get_Name: HSTRING; safecall;
    procedure put_Name(name: HSTRING); safecall;
    property Name: HSTRING read get_Name write put_Name;
  end;

  // DualAPI Interface
  // Windows.Graphics.Effects.IGraphicsEffectSource
  // External
  Effects_IGraphicsEffectSource = interface(IInspectable)
  ['{2D8F9DDC-4339-4EB9-9216-F9DEB75658A2}']
  end;

  // DualAPI Interface
  // Windows.Graphics.IGeometrySource2D
  // External
  IGeometrySource2D = interface(IInspectable)
  ['{CAFF7902-670C-4181-A624-DA977203B845}']
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.InkUnprocessedInput,Windows.UI.Core.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkUnprocessedInput,Windows.UI.Core.IPointerEventArgs>
  // External
  TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs = interface(IUnknown)
  ['{4A86BD78-5BCF-5EDE-8F65-A8C65235055C}']
    procedure Invoke(sender: IInkUnprocessedInput; args: IPointerEventArgs); safecall;
  end;

  // Windows.UI.Input.Inking.IInkUnprocessedInput
  // External
  IInkUnprocessedInput = interface(IInspectable)
  ['{DB4445E0-8398-4921-AC3B-AB978C5BA256}']
    function add_PointerEntered(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerEntered(cookie: EventRegistrationToken); safecall;
    function add_PointerHovered(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerHovered(cookie: EventRegistrationToken); safecall;
    function add_PointerExited(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerExited(cookie: EventRegistrationToken); safecall;
    function add_PointerPressed(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerPressed(cookie: EventRegistrationToken); safecall;
    function add_PointerMoved(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerMoved(cookie: EventRegistrationToken); safecall;
    function add_PointerReleased(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerReleased(cookie: EventRegistrationToken); safecall;
    function add_PointerLost(handler: TypedEventHandler_2__IInkUnprocessedInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerLost(cookie: EventRegistrationToken); safecall;
    function get_InkPresenter: IInkPresenter; safecall;
    property InkPresenter: IInkPresenter read get_InkPresenter;
  end;

  // Windows.UI.Input.Inking.IInkPresenter
  // External
  IInkPresenter = interface(IInspectable)
  ['{A69B70E2-887B-458F-B173-4FE4438930A3}']
    function get_IsInputEnabled: Boolean; safecall;
    procedure put_IsInputEnabled(value: Boolean); safecall;
    function get_InputDeviceTypes: CoreInputDeviceTypes; safecall;
    procedure put_InputDeviceTypes(value: CoreInputDeviceTypes); safecall;
    function get_UnprocessedInput: IInkUnprocessedInput; safecall;
    function get_StrokeInput: IInkStrokeInput; safecall;
    function get_InputProcessingConfiguration: IInkInputProcessingConfiguration; safecall;
    function get_StrokeContainer: IInkStrokeContainer; safecall;
    procedure put_StrokeContainer(value: IInkStrokeContainer); safecall;
    function CopyDefaultDrawingAttributes: IInkDrawingAttributes; safecall;
    procedure UpdateDefaultDrawingAttributes(value: IInkDrawingAttributes); safecall;
    function ActivateCustomDrying: IInkSynchronizer; safecall;
    procedure SetPredefinedConfiguration(value: InkPresenterPredefinedConfiguration); safecall;
    function add_StrokesCollected(handler: TypedEventHandler_2__IInkPresenter__IInkStrokesCollectedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokesCollected(cookie: EventRegistrationToken); safecall;
    function add_StrokesErased(handler: TypedEventHandler_2__IInkPresenter__IInkStrokesErasedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokesErased(cookie: EventRegistrationToken); safecall;
    property InputDeviceTypes: CoreInputDeviceTypes read get_InputDeviceTypes write put_InputDeviceTypes;
    property InputProcessingConfiguration: IInkInputProcessingConfiguration read get_InputProcessingConfiguration;
    property IsInputEnabled: Boolean read get_IsInputEnabled write put_IsInputEnabled;
    property StrokeContainer: IInkStrokeContainer read get_StrokeContainer write put_StrokeContainer;
    property StrokeInput: IInkStrokeInput read get_StrokeInput;
    property UnprocessedInput: IInkUnprocessedInput read get_UnprocessedInput;
  end;

  // Windows.UI.Input.Inking.IInkStrokeInput
  // External
  IInkStrokeInput = interface(IInspectable)
  ['{CF2FFE7B-5E10-43C6-A080-88F26E1DC67D}']
    function add_StrokeStarted(handler: TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokeStarted(cookie: EventRegistrationToken); safecall;
    function add_StrokeContinued(handler: TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokeContinued(cookie: EventRegistrationToken); safecall;
    function add_StrokeEnded(handler: TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokeEnded(cookie: EventRegistrationToken); safecall;
    function add_StrokeCanceled(handler: TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_StrokeCanceled(cookie: EventRegistrationToken); safecall;
    function get_InkPresenter: IInkPresenter; safecall;
    property InkPresenter: IInkPresenter read get_InkPresenter;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.InkStrokeInput,Windows.UI.Core.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkStrokeInput,Windows.UI.Core.IPointerEventArgs>
  // External
  TypedEventHandler_2__IInkStrokeInput__IPointerEventArgs = interface(IUnknown)
  ['{BF66B962-702D-5C07-A2D5-15F21583C43A}']
    procedure Invoke(sender: IInkStrokeInput; args: IPointerEventArgs); safecall;
  end;

  // Windows.UI.Input.Inking.IInkInputProcessingConfiguration
  // External
  IInkInputProcessingConfiguration = interface(IInspectable)
  ['{2778D85E-33CA-4B06-A6D3-AC3945116D37}']
    function get_Mode: InkInputProcessingMode; safecall;
    procedure put_Mode(value: InkInputProcessingMode); safecall;
    function get_RightDragAction: InkInputRightDragAction; safecall;
    procedure put_RightDragAction(value: InkInputRightDragAction); safecall;
    property Mode: InkInputProcessingMode read get_Mode write put_Mode;
    property RightDragAction: InkInputRightDragAction read get_RightDragAction write put_RightDragAction;
  end;

  // DualAPI Interface
  // Windows.UI.Input.Inking.IInkStrokeContainer
  [WinRTClassNameAttribute(SWindows_UI_Input_Inking_InkStrokeContainer)]
  IInkStrokeContainer = interface(IInspectable)
  ['{22ACCBC6-FAA9-4F14-B68C-F6CEE670AE16}']
    function get_BoundingRect: TRectF; safecall;
    procedure AddStroke(stroke: IInkStroke); safecall;
    function DeleteSelected: TRectF; safecall;
    function MoveSelected(translation: TPointF): TRectF; safecall;
    function SelectWithPolyLine(polyline: IIterable_1__Point): TRectF; safecall;
    function SelectWithLine(from: TPointF; &to: TPointF): TRectF; safecall;
    procedure CopySelectedToClipboard; safecall;
    function PasteFromClipboard(position: TPointF): TRectF; safecall;
    function CanPasteFromClipboard: Boolean; safecall;
    function LoadAsync(inputStream: IInputStream): IAsyncActionWithProgress_1__UInt64; safecall;
    function SaveAsync(outputStream: IOutputStream): IAsyncOperationWithProgress_2__Cardinal__Cardinal; safecall;
    procedure UpdateRecognitionResults(recognitionResults: IVectorView_1__IInkRecognitionResult); safecall;
    function GetStrokes: IVectorView_1__IInkStroke; safecall;
    function GetRecognitionResults: IVectorView_1__IInkRecognitionResult; safecall;
    property BoundingRect: TRectF read get_BoundingRect;
  end;

  // Windows.UI.Input.Inking.IInkStroke
  // External
  IInkStroke = interface(IInspectable)
  ['{15144D60-CCE3-4FCF-9D52-11518AB6AFD4}']
    function get_DrawingAttributes: IInkDrawingAttributes; safecall;
    procedure put_DrawingAttributes(value: IInkDrawingAttributes); safecall;
    function get_BoundingRect: TRectF; safecall;
    function get_Selected: Boolean; safecall;
    procedure put_Selected(value: Boolean); safecall;
    function get_Recognized: Boolean; safecall;
    function GetRenderingSegments: IVectorView_1__IInkStrokeRenderingSegment; safecall;
    function Clone: IInkStroke; safecall;
    property BoundingRect: TRectF read get_BoundingRect;
    property DrawingAttributes: IInkDrawingAttributes read get_DrawingAttributes write put_DrawingAttributes;
    property Recognized: Boolean read get_Recognized;
    property Selected: Boolean read get_Selected write put_Selected;
  end;

  // DualAPI Interface
  // Windows.UI.Input.Inking.IInkDrawingAttributes
  [WinRTClassNameAttribute(SWindows_UI_Input_Inking_InkDrawingAttributes)]
  IInkDrawingAttributes = interface(IInspectable)
  ['{97A2176C-6774-48AD-84F0-48F5A9BE74F9}']
    function get_Color: Color; safecall;
    procedure put_Color(value: Color); safecall;
    function get_PenTip: PenTipShape; safecall;
    procedure put_PenTip(value: PenTipShape); safecall;
    function get_Size: TSizeF; safecall;
    procedure put_Size(value: TSizeF); safecall;
    function get_IgnorePressure: Boolean; safecall;
    procedure put_IgnorePressure(value: Boolean); safecall;
    function get_FitToCurve: Boolean; safecall;
    procedure put_FitToCurve(value: Boolean); safecall;
    property Color_: Color read get_Color write put_Color;
    property FitToCurve: Boolean read get_FitToCurve write put_FitToCurve;
    property IgnorePressure: Boolean read get_IgnorePressure write put_IgnorePressure;
    property PenTip: PenTipShape read get_PenTip write put_PenTip;
    property Size: TSizeF read get_Size write put_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkStrokeRenderingSegment>
  // External
  IVectorView_1__IInkStrokeRenderingSegment = interface(IInspectable)
  ['{533D1D1F-D4DE-5B1B-8AD2-33127C4637DD}']
    function GetAt(index: Cardinal): IInkStrokeRenderingSegment; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IInkStrokeRenderingSegment; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIInkStrokeRenderingSegment): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Input.Inking.IInkStrokeRenderingSegment
  // External
  IInkStrokeRenderingSegment = interface(IInspectable)
  ['{68510F1F-88E3-477A-A2FA-569F5F1F9BD5}']
    function get_Position: TPointF; safecall;
    function get_BezierControlPoint1: TPointF; safecall;
    function get_BezierControlPoint2: TPointF; safecall;
    function get_Pressure: Single; safecall;
    function get_TiltX: Single; safecall;
    function get_TiltY: Single; safecall;
    function get_Twist: Single; safecall;
    property BezierControlPoint1: TPointF read get_BezierControlPoint1;
    property BezierControlPoint2: TPointF read get_BezierControlPoint2;
    property Position: TPointF read get_Position;
    property Pressure: Single read get_Pressure;
    property TiltX: Single read get_TiltX;
    property TiltY: Single read get_TiltY;
    property Twist: Single read get_Twist;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Point>
  // External
  IIterable_1__Point = interface(IInspectable)
  ['{C192280D-3A09-5423-9DC5-67B83EBDE41D}']
    function First: IIterator_1__Point; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Point>
  // External
  IIterator_1__Point = interface(IInspectable)
  ['{C602B59E-0A8E-5E99-B478-2B564585278D}']
    function get_Current: TPointF; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPointF): Cardinal; safecall;
    property Current: TPointF read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.IAsyncActionWithProgress`1<UInt64>
  // External
  IAsyncActionWithProgress_1__UInt64 = interface(IInspectable)
  ['{43F713D0-C49D-5E55-AEBF-AF395768351E}']
    procedure put_Progress(handler: AsyncActionProgressHandler_1__UInt64); safecall;
    function get_Progress: AsyncActionProgressHandler_1__UInt64; safecall;
    procedure put_Completed(handler: AsyncActionWithProgressCompletedHandler_1__UInt64); safecall;
    function get_Completed: AsyncActionWithProgressCompletedHandler_1__UInt64; safecall;
    procedure GetResults; safecall;
    property Progress: AsyncActionProgressHandler_1__UInt64 read get_Progress write put_Progress;
    property Completed: AsyncActionWithProgressCompletedHandler_1__UInt64 read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncActionProgressHandler`1<UInt64>
  // External
  AsyncActionProgressHandler_1__UInt64 = interface(IUnknown)
  ['{55E233CA-F243-5AE2-853B-F9CC7C0AE0CF}']
    procedure Invoke(asyncInfo: IAsyncActionWithProgress_1__UInt64; progressInfo: UInt64); safecall;
  end;

  // Windows.Foundation.AsyncActionWithProgressCompletedHandler`1<UInt64>
  // External
  AsyncActionWithProgressCompletedHandler_1__UInt64 = interface(IUnknown)
  ['{E6FF857B-F160-571A-A934-2C61F98C862D}']
    procedure Invoke(asyncInfo: IAsyncActionWithProgress_1__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkRecognitionResult>
  // External
  IVectorView_1__IInkRecognitionResult = interface(IInspectable)
  ['{3C16D87C-E0C0-5689-A3D8-87D11003DEA9}']
    function GetAt(index: Cardinal): IInkRecognitionResult; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IInkRecognitionResult; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIInkRecognitionResult): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Input.Inking.IInkRecognitionResult
  // External
  IInkRecognitionResult = interface(IInspectable)
  ['{36461A94-5068-40EF-8A05-2C2FB60908A2}']
    function get_BoundingRect: TRectF; safecall;
    function GetTextCandidates: IVectorView_1__HSTRING; safecall;
    function GetStrokes: IVectorView_1__IInkStroke; safecall;
    property BoundingRect: TRectF read get_BoundingRect;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Input.Inking.IInkStroke>
  // External
  IVectorView_1__IInkStroke = interface(IInspectable)
  ['{C3FC26F7-5323-55A2-90F5-5EBE01DAF672}']
    function GetAt(index: Cardinal): IInkStroke; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IInkStroke; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIInkStroke): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Input.Inking.IInkSynchronizer
  // External
  IInkSynchronizer = interface(IInspectable)
  ['{9B9EA160-AE9B-45F9-8407-4B493B163661}']
    function BeginDry: IVectorView_1__IInkStroke; safecall;
    procedure EndDry; safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.InkPresenter,Windows.UI.Input.Inking.InkStrokesCollectedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkPresenter,Windows.UI.Input.Inking.IInkStrokesCollectedEventArgs>
  // External
  TypedEventHandler_2__IInkPresenter__IInkStrokesCollectedEventArgs = interface(IUnknown)
  ['{176BFA8F-C0DE-5B3A-B28C-0F3931CA52D3}']
    procedure Invoke(sender: IInkPresenter; args: IInkStrokesCollectedEventArgs); safecall;
  end;

  // Windows.UI.Input.Inking.IInkStrokesCollectedEventArgs
  // External
  IInkStrokesCollectedEventArgs = interface(IInspectable)
  ['{C4F3F229-1938-495C-B4D9-6DE4B08D4811}']
    function get_Strokes: IVectorView_1__IInkStroke; safecall;
    property Strokes: IVectorView_1__IInkStroke read get_Strokes;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.InkPresenter,Windows.UI.Input.Inking.InkStrokesErasedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.IInkPresenter,Windows.UI.Input.Inking.IInkStrokesErasedEventArgs>
  // External
  TypedEventHandler_2__IInkPresenter__IInkStrokesErasedEventArgs = interface(IUnknown)
  ['{30FEC929-14D0-550F-84F2-137FC6A9F08F}']
    procedure Invoke(sender: IInkPresenter; args: IInkStrokesErasedEventArgs); safecall;
  end;

  // Windows.UI.Input.Inking.IInkStrokesErasedEventArgs
  // External
  IInkStrokesErasedEventArgs = interface(IInspectable)
  ['{A4216A22-1503-4EBF-8FF5-2DE84584A8AA}']
    function get_Strokes: IVectorView_1__IInkStroke; safecall;
    property Strokes: IVectorView_1__IInkStroke read get_Strokes;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.Core.CoreInkIndependentInputSource,Windows.UI.Core.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.Inking.Core.ICoreInkIndependentInputSource,Windows.UI.Core.IPointerEventArgs>
  // External
  TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs = interface(IUnknown)
  ['{B83FBE98-882A-5B69-BD1C-C66690707FEF}']
    procedure Invoke(sender: Core_ICoreInkIndependentInputSource; args: IPointerEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Input.Inking.Core.ICoreInkIndependentInputSource
  [WinRTClassNameAttribute(SWindows_UI_Input_Inking_Core_CoreInkIndependentInputSource)]
  Core_ICoreInkIndependentInputSource = interface(IInspectable)
  ['{39B38DA9-7639-4499-A5B5-191D00E35B16}']
    function add_PointerEntering(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerEntering(cookie: EventRegistrationToken); safecall;
    function add_PointerHovering(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerHovering(cookie: EventRegistrationToken); safecall;
    function add_PointerExiting(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerExiting(cookie: EventRegistrationToken); safecall;
    function add_PointerPressing(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerPressing(cookie: EventRegistrationToken); safecall;
    function add_PointerMoving(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerMoving(cookie: EventRegistrationToken); safecall;
    function add_PointerReleasing(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerReleasing(cookie: EventRegistrationToken); safecall;
    function add_PointerLost(handler: TypedEventHandler_2__Core_ICoreInkIndependentInputSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerLost(cookie: EventRegistrationToken); safecall;
    function get_InkPresenter: IInkPresenter; safecall;
    property InkPresenter: IInkPresenter read get_InkPresenter;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.TouchpadGesturesController,Windows.UI.Core.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.ITouchpadGesturesController,Windows.UI.Core.IPointerEventArgs>
  // External
  TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs = interface(IUnknown)
  ['{0B05A28C-2064-5B06-94F3-324FB004ECE0}']
    procedure Invoke(sender: ITouchpadGesturesController; args: IPointerEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Input.ITouchpadGesturesController
  [WinRTClassNameAttribute(SWindows_UI_Input_TouchpadGesturesController)]
  ITouchpadGesturesController = interface(IInspectable)
  ['{28C13CDD-E068-549F-89C6-1A440C6FC327}']
    function get_Enabled: Boolean; safecall;
    procedure put_Enabled(value: Boolean); safecall;
    function get_SupportedGestures: TouchpadGlobalGestureKinds; safecall;
    procedure put_SupportedGestures(value: TouchpadGlobalGestureKinds); safecall;
    function add_PointerPressed(handler: TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerPressed(token: EventRegistrationToken); safecall;
    function add_PointerMoved(handler: TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerMoved(token: EventRegistrationToken); safecall;
    function add_PointerReleased(handler: TypedEventHandler_2__ITouchpadGesturesController__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerReleased(token: EventRegistrationToken); safecall;
    function add_GlobalActionPerformed(handler: TypedEventHandler_2__ITouchpadGesturesController__ITouchpadGlobalActionEventArgs): EventRegistrationToken; safecall;
    procedure remove_GlobalActionPerformed(token: EventRegistrationToken); safecall;
    property Enabled: Boolean read get_Enabled write put_Enabled;
    property SupportedGestures: TouchpadGlobalGestureKinds read get_SupportedGestures write put_SupportedGestures;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.TouchpadGesturesController,Windows.UI.Input.TouchpadGlobalActionEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Input.ITouchpadGesturesController,Windows.UI.Input.ITouchpadGlobalActionEventArgs>
  // External
  TypedEventHandler_2__ITouchpadGesturesController__ITouchpadGlobalActionEventArgs = interface(IUnknown)
  ['{3FDB14D0-C3B2-576E-B900-AAA14E0FF77C}']
    procedure Invoke(sender: ITouchpadGesturesController; args: ITouchpadGlobalActionEventArgs); safecall;
  end;

  // Windows.UI.Input.ITouchpadGlobalActionEventArgs
  // External
  ITouchpadGlobalActionEventArgs = interface(IInspectable)
  ['{6EDAD206-E4E3-5F39-9D13-8575E8E2A12B}']
    function get_Action: TouchpadGlobalAction; safecall;
    function get_PointerDevice: Input_IPointerDevice; safecall;
    property Action: TouchpadGlobalAction read get_Action;
    property PointerDevice: Input_IPointerDevice read get_PointerDevice;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IStyle
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Style)]
  IStyle = interface(IInspectable)
  ['{C4A9F225-9DB7-4A7D-B6D1-F74EDB9293C2}']
    function get_IsSealed: Boolean; safecall;
    function get_Setters: ISetterBaseCollection; safecall;
    function get_TargetType: Interop_TypeName; safecall;
    procedure put_TargetType(value: Interop_TypeName); safecall;
    function get_BasedOn: IStyle; safecall;
    procedure put_BasedOn(value: IStyle); safecall;
    procedure Seal; safecall;
    property BasedOn: IStyle read get_BasedOn write put_BasedOn;
    property IsSealed: Boolean read get_IsSealed;
    property Setters: ISetterBaseCollection read get_Setters;
    property TargetType: Interop_TypeName read get_TargetType write put_TargetType;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.ISetterBaseCollection
  [WinRTClassNameAttribute(SWindows_UI_Xaml_SetterBaseCollection)]
  ISetterBaseCollection = interface(IInspectable)
  ['{03C40CA8-909E-4117-811C-A4529496BDF1}']
    function get_IsSealed: Boolean; safecall;
    property IsSealed: Boolean read get_IsSealed;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.ICommand
  // External
  Input_ICommand = interface(IInspectable)
  ['{E5AF3542-CA67-4081-995B-709DD13792DF}']
    function add_CanExecuteChanged(handler: EventHandler_1__IInspectable): EventRegistrationToken; safecall;
    procedure remove_CanExecuteChanged(token: EventRegistrationToken); safecall;
    function CanExecute(parameter: IInspectable): Boolean; safecall;
    procedure Execute(parameter: IInspectable); safecall;
  end;

  // Windows.Foundation.EventHandler`1<Object>
  // External
  EventHandler_1__IInspectable = interface(IUnknown)
  ['{C50898F6-C536-5F47-8583-8B2C2438A13B}']
    procedure Invoke(sender: IInspectable; args: IInspectable); safecall;
  end;

  // Windows.UI.Xaml.RoutedEventHandler
  // External
  RoutedEventHandler = interface(IUnknown)
  ['{A856E674-B0B6-4BC3-BBA8-1BA06E40D4B5}']
    procedure Invoke(sender: IInspectable; e: IRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_RoutedEventArgs)]
  IRoutedEventArgs = interface(IInspectable)
  ['{5C985AC6-D802-4B38-A223-BF070C43FEDF}']
    function get_OriginalSource: IInspectable; safecall;
    property OriginalSource: IInspectable read get_OriginalSource;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IDataTemplate
  [WinRTClassNameAttribute(SWindows_UI_Xaml_DataTemplate)]
  IDataTemplate = interface(IInspectable)
  ['{9910AEC7-8AB5-4118-9BC6-09F45A35073D}']
    function LoadContent: IDependencyObject; safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IDependencyObject
  [WinRTClassNameAttribute(SWindows_UI_Xaml_DependencyObject)]
  IDependencyObject = interface(IInspectable)
  ['{5C526665-F60E-4912-AF59-5FE0680F089D}']
    function GetValue(dp: IDependencyProperty): IInspectable; safecall;
    procedure SetValue(dp: IDependencyProperty; value: IInspectable); safecall;
    procedure ClearValue(dp: IDependencyProperty); safecall;
    function ReadLocalValue(dp: IDependencyProperty): IInspectable; safecall;
    function GetAnimationBaseValue(dp: IDependencyProperty): IInspectable; safecall;
    function get_Dispatcher: ICoreDispatcher; safecall;
    property Dispatcher: ICoreDispatcher read get_Dispatcher;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IDependencyProperty
  [WinRTClassNameAttribute(SWindows_UI_Xaml_DependencyProperty)]
  IDependencyProperty = interface(IInspectable)
  ['{85B13970-9BC4-4E96-ACF1-30C8FD3D55C8}']
    function GetMetadata(forType: Interop_TypeName): IPropertyMetadata; safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IPropertyMetadata
  [WinRTClassNameAttribute(SWindows_UI_Xaml_PropertyMetadata)]
  IPropertyMetadata = interface(IInspectable)
  ['{814EF30D-8D18-448A-8644-F2CB51E70380}']
    function get_DefaultValue: IInspectable; safecall;
    function get_CreateDefaultValueCallback: CreateDefaultValueCallback; safecall;
    property CreateDefaultValueCallback_: CreateDefaultValueCallback read get_CreateDefaultValueCallback;
    property DefaultValue: IInspectable read get_DefaultValue;
  end;

  // Windows.UI.Xaml.CreateDefaultValueCallback
  // External
  CreateDefaultValueCallback = interface(IUnknown)
  ['{D6ECB12C-15B5-4EC8-B95C-CDD208F08153}']
    function Invoke: IInspectable; safecall;
  end;

  // Windows.UI.Xaml.ExceptionRoutedEventHandler
  // External
  ExceptionRoutedEventHandler = interface(IUnknown)
  ['{68E0E810-F6EA-42BC-855B-5D9B67E6A262}']
    procedure Invoke(sender: IInspectable; e: IExceptionRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IExceptionRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_ExceptionRoutedEventArgs)]
  IExceptionRoutedEventArgs = interface(IInspectable)
  ['{DD9FF16A-4B62-4A6C-A49D-0671EF6136BE}']
    function get_ErrorMessage: HSTRING; safecall;
    property ErrorMessage: HSTRING read get_ErrorMessage;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.UI.Xaml.Data.LoadMoreItemsResult>
  // External
  IAsyncOperation_1__Data_LoadMoreItemsResult = interface(IInspectable)
  ['{C788089D-37AB-5BA2-B865-5A309ACDFC4D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult; safecall;
    function GetResults: Data_LoadMoreItemsResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.UI.Xaml.Data.LoadMoreItemsResult>
  // External
  AsyncOperationCompletedHandler_1__Data_LoadMoreItemsResult = interface(IUnknown)
  ['{10FB738B-A63B-506E-9ED7-2EAB37915221}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Data_LoadMoreItemsResult; asyncStatus: AsyncStatus); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IInputScope
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_InputScope)]
  Input_IInputScope = interface(IInspectable)
  ['{5C0F85F3-F9D8-4220-B666-045D074D9BFA}']
    function get_Names: IVector_1__Input_IInputScopeName; safecall;
    property Names: IVector_1__Input_IInputScopeName read get_Names;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Input.InputScopeName>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Input.IInputScopeName>
  // External
  IVector_1__Input_IInputScopeName = interface(IInspectable)
  ['{703FE123-D766-562F-B210-1980BB2A0D33}']
    function GetAt(index: Cardinal): Input_IInputScopeName; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Input_IInputScopeName; safecall;
    function IndexOf(value: Input_IInputScopeName; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Input_IInputScopeName); safecall;
    procedure InsertAt(index: Cardinal; value: Input_IInputScopeName); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Input_IInputScopeName); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInput_IInputScopeName): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PInput_IInputScopeName); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IInputScopeName
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_InputScopeName)]
  Input_IInputScopeName = interface(IInspectable)
  ['{FD3E6997-08FB-4CBA-A021-792D7589FD5A}']
    function get_NameValue: Input_InputScopeNameValue; safecall;
    procedure put_NameValue(value: Input_InputScopeNameValue); safecall;
    property NameValue: Input_InputScopeNameValue read get_NameValue write put_NameValue;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Input.IInputScopeName>
  // External
  IVectorView_1__Input_IInputScopeName = interface(IInspectable)
  ['{56229622-D986-549F-B23A-A88C6939C5B9}']
    function GetAt(index: Cardinal): Input_IInputScopeName; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Input_IInputScopeName; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInput_IInputScopeName): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.Documents.ITextPointer
  // External
  Documents_ITextPointer = interface(IInspectable)
  ['{AC687AA1-6A41-43FF-851E-45348AA2CF7B}']
    function get_Parent: IDependencyObject; safecall;
    function get_VisualParent: IFrameworkElement; safecall;
    function get_LogicalDirection: Documents_LogicalDirection; safecall;
    function get_Offset: Integer; safecall;
    function GetCharacterRect(direction: Documents_LogicalDirection): TRectF; safecall;
    function GetPositionAtOffset(offset: Integer; direction: Documents_LogicalDirection): Documents_ITextPointer; safecall;
    property LogicalDirection: Documents_LogicalDirection read get_LogicalDirection;
    property Offset: Integer read get_Offset;
    property Parent: IDependencyObject read get_Parent;
    property VisualParent: IFrameworkElement read get_VisualParent;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IFrameworkElement
  [WinRTClassNameAttribute(SWindows_UI_Xaml_FrameworkElement)]
  IFrameworkElement = interface(IInspectable)
  ['{A391D09B-4A99-4B7C-9D8D-6FA5D01F6FBF}']
    function get_Triggers: IVector_1__ITriggerBase; safecall;
    function get_Resources: IResourceDictionary; safecall;
    procedure put_Resources(value: IResourceDictionary); safecall;
    function get_Tag: IInspectable; safecall;
    procedure put_Tag(value: IInspectable); safecall;
    function get_Language: HSTRING; safecall;
    procedure put_Language(value: HSTRING); safecall;
    function get_ActualWidth: Double; safecall;
    function get_ActualHeight: Double; safecall;
    function get_Width: Double; safecall;
    procedure put_Width(value: Double); safecall;
    function get_Height: Double; safecall;
    procedure put_Height(value: Double); safecall;
    function get_MinWidth: Double; safecall;
    procedure put_MinWidth(value: Double); safecall;
    function get_MaxWidth: Double; safecall;
    procedure put_MaxWidth(value: Double); safecall;
    function get_MinHeight: Double; safecall;
    procedure put_MinHeight(value: Double); safecall;
    function get_MaxHeight: Double; safecall;
    procedure put_MaxHeight(value: Double); safecall;
    function get_HorizontalAlignment: HorizontalAlignment; safecall;
    procedure put_HorizontalAlignment(value: HorizontalAlignment); safecall;
    function get_VerticalAlignment: VerticalAlignment; safecall;
    procedure put_VerticalAlignment(value: VerticalAlignment); safecall;
    function get_Margin: Thickness; safecall;
    procedure put_Margin(value: Thickness); safecall;
    function get_Name: HSTRING; safecall;
    procedure put_Name(value: HSTRING); safecall;
    function get_BaseUri: IUriRuntimeClass; safecall;
    function get_DataContext: IInspectable; safecall;
    procedure put_DataContext(value: IInspectable); safecall;
    function get_Style: IStyle; safecall;
    procedure put_Style(value: IStyle); safecall;
    function get_Parent: IDependencyObject; safecall;
    function get_FlowDirection: FlowDirection; safecall;
    procedure put_FlowDirection(value: FlowDirection); safecall;
    function add_Loaded(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Loaded(token: EventRegistrationToken); safecall;
    function add_Unloaded(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Unloaded(token: EventRegistrationToken); safecall;
    function add_SizeChanged(handler: SizeChangedEventHandler): EventRegistrationToken; safecall;
    procedure remove_SizeChanged(token: EventRegistrationToken); safecall;
    function add_LayoutUpdated(handler: EventHandler_1__IInspectable): EventRegistrationToken; safecall;
    procedure remove_LayoutUpdated(token: EventRegistrationToken); safecall;
    function FindName(name: HSTRING): IInspectable; safecall;
    procedure SetBinding(dp: IDependencyProperty; binding: Data_IBindingBase); safecall;
    property ActualHeight: Double read get_ActualHeight;
    property ActualWidth: Double read get_ActualWidth;
    property BaseUri: IUriRuntimeClass read get_BaseUri;
    property DataContext: IInspectable read get_DataContext write put_DataContext;
    property FlowDirection_: FlowDirection read get_FlowDirection write put_FlowDirection;
    property Height: Double read get_Height write put_Height;
    property HorizontalAlignment_: HorizontalAlignment read get_HorizontalAlignment write put_HorizontalAlignment;
    property Language: HSTRING read get_Language write put_Language;
    property Margin: Thickness read get_Margin write put_Margin;
    property MaxHeight: Double read get_MaxHeight write put_MaxHeight;
    property MaxWidth: Double read get_MaxWidth write put_MaxWidth;
    property MinHeight: Double read get_MinHeight write put_MinHeight;
    property MinWidth: Double read get_MinWidth write put_MinWidth;
    property Name: HSTRING read get_Name write put_Name;
    property Parent: IDependencyObject read get_Parent;
    property Resources: IResourceDictionary read get_Resources write put_Resources;
    property Style: IStyle read get_Style write put_Style;
    property Tag: IInspectable read get_Tag write put_Tag;
    property Triggers: IVector_1__ITriggerBase read get_Triggers;
    property VerticalAlignment_: VerticalAlignment read get_VerticalAlignment write put_VerticalAlignment;
    property Width: Double read get_Width write put_Width;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.TriggerBase>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.ITriggerBase>
  // External
  IVector_1__ITriggerBase = interface(IInspectable)
  ['{9149863B-B78B-5FB6-A0A1-9EBF6BBC3407}']
    function GetAt(index: Cardinal): ITriggerBase; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__ITriggerBase; safecall;
    function IndexOf(value: ITriggerBase; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: ITriggerBase); safecall;
    procedure InsertAt(index: Cardinal; value: ITriggerBase); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: ITriggerBase); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PITriggerBase): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PITriggerBase); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.ITriggerBase
  [WinRTClassNameAttribute(SWindows_UI_Xaml_TriggerBase)]
  ITriggerBase = interface(IInspectable)
  ['{E7EA222F-DEE6-4393-A8B2-8923D641F395}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.ITriggerBase>
  // External
  IVectorView_1__ITriggerBase = interface(IInspectable)
  ['{1F02B86D-8C50-56B1-A2E6-4F0DCE5DC7D6}']
    function GetAt(index: Cardinal): ITriggerBase; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ITriggerBase; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PITriggerBase): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IResourceDictionary
  [WinRTClassNameAttribute(SWindows_UI_Xaml_ResourceDictionary)]
  IResourceDictionary = interface(IInspectable)
  ['{C1EA4F24-D6DE-4191-8E3A-F48601F7489C}']
    function get_Source: IUriRuntimeClass; safecall;
    procedure put_Source(value: IUriRuntimeClass); safecall;
    function get_MergedDictionaries: IVector_1__IResourceDictionary; safecall;
    function get_ThemeDictionaries: IMap_2__IInspectable__IInspectable; safecall;
    property MergedDictionaries: IVector_1__IResourceDictionary read get_MergedDictionaries;
    property Source: IUriRuntimeClass read get_Source write put_Source;
    property ThemeDictionaries: IMap_2__IInspectable__IInspectable read get_ThemeDictionaries;
  end;

  // DualAPI Interface
  // Windows.Foundation.IUriRuntimeClass
  [WinRTClassNameAttribute(SWindows_Foundation_Uri)]
  IUriRuntimeClass = interface(IInspectable)
  ['{9E365E57-48B2-4160-956F-C7385120BBFC}']
    function get_AbsoluteUri: HSTRING; safecall;
    function get_DisplayUri: HSTRING; safecall;
    function get_Domain: HSTRING; safecall;
    function get_Extension: HSTRING; safecall;
    function get_Fragment: HSTRING; safecall;
    function get_Host: HSTRING; safecall;
    function get_Password: HSTRING; safecall;
    function get_Path: HSTRING; safecall;
    function get_Query: HSTRING; safecall;
    function get_QueryParsed: IWwwFormUrlDecoderRuntimeClass; safecall;
    function get_RawUri: HSTRING; safecall;
    function get_SchemeName: HSTRING; safecall;
    function get_UserName: HSTRING; safecall;
    function get_Port: Integer; safecall;
    function get_Suspicious: Boolean; safecall;
    function Equals(pUri: IUriRuntimeClass): Boolean; safecall;
    function CombineUri(relativeUri: HSTRING): IUriRuntimeClass; safecall;
    property AbsoluteUri: HSTRING read get_AbsoluteUri;
    property DisplayUri: HSTRING read get_DisplayUri;
    property Domain: HSTRING read get_Domain;
    property Extension: HSTRING read get_Extension;
    property Fragment: HSTRING read get_Fragment;
    property Host: HSTRING read get_Host;
    property Password: HSTRING read get_Password;
    property Path: HSTRING read get_Path;
    property Port: Integer read get_Port;
    property Query: HSTRING read get_Query;
    property QueryParsed: IWwwFormUrlDecoderRuntimeClass read get_QueryParsed;
    property RawUri: HSTRING read get_RawUri;
    property SchemeName: HSTRING read get_SchemeName;
    property Suspicious: Boolean read get_Suspicious;
    property UserName: HSTRING read get_UserName;
  end;

  // DualAPI Interface
  // Windows.Foundation.IWwwFormUrlDecoderRuntimeClass
  [WinRTClassNameAttribute(SWindows_Foundation_WwwFormUrlDecoder)]
  IWwwFormUrlDecoderRuntimeClass = interface(IInspectable)
  ['{D45A0451-F225-4542-9296-0E1DF5D254DF}']
    function GetFirstValueByName(name: HSTRING): HSTRING; safecall;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.ResourceDictionary>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IResourceDictionary>
  // External
  IVector_1__IResourceDictionary = interface(IInspectable)
  ['{FE820A0C-694D-518B-8EC5-372993F6CEAF}']
    function GetAt(index: Cardinal): IResourceDictionary; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IResourceDictionary; safecall;
    function IndexOf(value: IResourceDictionary; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IResourceDictionary); safecall;
    procedure InsertAt(index: Cardinal; value: IResourceDictionary); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IResourceDictionary); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIResourceDictionary): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIResourceDictionary); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IResourceDictionary>
  // External
  IVectorView_1__IResourceDictionary = interface(IInspectable)
  ['{7EA5E3DC-1E1E-5DA2-9355-AEE6CFB63CCF}']
    function GetAt(index: Cardinal): IResourceDictionary; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IResourceDictionary; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIResourceDictionary): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IMap`2<Object,Object>
  // External
  IMap_2__IInspectable__IInspectable = interface(IInspectable)
  ['{F5F69427-55ED-5512-8429-D4F6626DFCDD}']
    function Lookup(key: IInspectable): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: IInspectable): Boolean; safecall;
    function GetView: IMapView_2__IInspectable__IInspectable; safecall;
    function Insert(key: IInspectable; value: IInspectable): Boolean; safecall;
    procedure Remove(key: IInspectable); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IMapView`2<Object,Object>
  // External
  IMapView_2__IInspectable__IInspectable = interface(IInspectable)
  ['{EFE76D10-CB60-50AD-8A4F-6885CD6212A1}']
    function Lookup(key: IInspectable): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: IInspectable): Boolean; safecall;
    procedure Split(out first: IMapView_2__IInspectable__IInspectable; out second: IMapView_2__IInspectable__IInspectable); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.SizeChangedEventHandler
  // External
  SizeChangedEventHandler = interface(IUnknown)
  ['{1115B13C-25D2-480B-89DC-EB3DCBD6B7FA}']
    procedure Invoke(sender: IInspectable; e: ISizeChangedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.ISizeChangedEventArgs
  // External
  ISizeChangedEventArgs = interface(IInspectable)
  ['{D5312E60-5CC1-42A1-920C-1AF46BE2F986}']
    function get_PreviousSize: TSizeF; safecall;
    function get_NewSize: TSizeF; safecall;
    property NewSize: TSizeF read get_NewSize;
    property PreviousSize: TSizeF read get_PreviousSize;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Data.IBindingBase
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Data_BindingBase)]
  Data_IBindingBase = interface(IInspectable)
  ['{1589A2AB-3D15-49BC-A447-8A5448E58870}']
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.Block>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.IBlock>
  // External
  IVector_1__Documents_IBlock = interface(IInspectable)
  ['{3EE78A34-160E-50FF-B5AA-09F263A669F8}']
    function GetAt(index: Cardinal): Documents_IBlock; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Documents_IBlock; safecall;
    function IndexOf(value: Documents_IBlock; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Documents_IBlock); safecall;
    procedure InsertAt(index: Cardinal; value: Documents_IBlock); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Documents_IBlock); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_IBlock): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDocuments_IBlock); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Documents.IBlock
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Documents_Block)]
  Documents_IBlock = interface(IInspectable)
  ['{4BCE0016-DD47-4350-8CB0-E171600AC896}']
    function get_TextAlignment: TextAlignment; safecall;
    procedure put_TextAlignment(value: TextAlignment); safecall;
    function get_LineHeight: Double; safecall;
    procedure put_LineHeight(value: Double); safecall;
    function get_LineStackingStrategy: LineStackingStrategy; safecall;
    procedure put_LineStackingStrategy(value: LineStackingStrategy); safecall;
    function get_Margin: Thickness; safecall;
    procedure put_Margin(value: Thickness); safecall;
    property LineHeight: Double read get_LineHeight write put_LineHeight;
    property LineStackingStrategy_: LineStackingStrategy read get_LineStackingStrategy write put_LineStackingStrategy;
    property Margin: Thickness read get_Margin write put_Margin;
    property TextAlignment_: TextAlignment read get_TextAlignment write put_TextAlignment;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.IBlock>
  // External
  IVectorView_1__Documents_IBlock = interface(IInspectable)
  ['{FF7F1640-984C-5779-BCAD-563D20A384B5}']
    function GetAt(index: Cardinal): Documents_IBlock; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Documents_IBlock; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_IBlock): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.SearchBox,Windows.UI.Xaml.RoutedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.IRoutedEventArgs>
  // External
  TypedEventHandler_2__ISearchBox__IRoutedEventArgs = interface(IUnknown)
  ['{A16EFF3C-CC37-554C-8F10-0F7E6E2BCAAD}']
    procedure Invoke(sender: ISearchBox; args: IRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.ISearchBox
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_SearchBox)]
  ISearchBox = interface(IInspectable)
  ['{F89ECC5A-99BA-4BD4-966C-F11FA443D13C}']
    function get_SearchHistoryEnabled: Boolean; safecall;
    procedure put_SearchHistoryEnabled(value: Boolean); safecall;
    function get_SearchHistoryContext: HSTRING; safecall;
    procedure put_SearchHistoryContext(value: HSTRING); safecall;
    function get_PlaceholderText: HSTRING; safecall;
    procedure put_PlaceholderText(value: HSTRING); safecall;
    function get_QueryText: HSTRING; safecall;
    procedure put_QueryText(value: HSTRING); safecall;
    function get_FocusOnKeyboardInput: Boolean; safecall;
    procedure put_FocusOnKeyboardInput(value: Boolean); safecall;
    function get_ChooseSuggestionOnEnter: Boolean; safecall;
    procedure put_ChooseSuggestionOnEnter(value: Boolean); safecall;
    function add_QueryChanged(handler: TypedEventHandler_2__ISearchBox__ISearchBoxQueryChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_QueryChanged(token: EventRegistrationToken); safecall;
    function add_SuggestionsRequested(handler: TypedEventHandler_2__ISearchBox__ISearchBoxSuggestionsRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SuggestionsRequested(token: EventRegistrationToken); safecall;
    function add_QuerySubmitted(handler: TypedEventHandler_2__ISearchBox__ISearchBoxQuerySubmittedEventArgs): EventRegistrationToken; safecall;
    procedure remove_QuerySubmitted(token: EventRegistrationToken); safecall;
    function add_ResultSuggestionChosen(handler: TypedEventHandler_2__ISearchBox__ISearchBoxResultSuggestionChosenEventArgs): EventRegistrationToken; safecall;
    procedure remove_ResultSuggestionChosen(token: EventRegistrationToken); safecall;
    function add_PrepareForFocusOnKeyboardInput(handler: TypedEventHandler_2__ISearchBox__IRoutedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PrepareForFocusOnKeyboardInput(token: EventRegistrationToken); safecall;
    procedure SetLocalContentSuggestionSettings(settings: Search_ILocalContentSuggestionSettings); safecall;
    property ChooseSuggestionOnEnter: Boolean read get_ChooseSuggestionOnEnter write put_ChooseSuggestionOnEnter;
    property FocusOnKeyboardInput: Boolean read get_FocusOnKeyboardInput write put_FocusOnKeyboardInput;
    property PlaceholderText: HSTRING read get_PlaceholderText write put_PlaceholderText;
    property QueryText: HSTRING read get_QueryText write put_QueryText;
    property SearchHistoryContext: HSTRING read get_SearchHistoryContext write put_SearchHistoryContext;
    property SearchHistoryEnabled: Boolean read get_SearchHistoryEnabled write put_SearchHistoryEnabled;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.SearchBox,Windows.UI.Xaml.Controls.SearchBoxQueryChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxQueryChangedEventArgs>
  // External
  TypedEventHandler_2__ISearchBox__ISearchBoxQueryChangedEventArgs = interface(IUnknown)
  ['{B15CCC28-40F3-52DA-9011-87621E9C60EA}']
    procedure Invoke(sender: ISearchBox; args: ISearchBoxQueryChangedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Controls.ISearchBoxQueryChangedEventArgs
  // External
  ISearchBoxQueryChangedEventArgs = interface(IInspectable)
  ['{A9A70F8F-0CB0-4BD2-9998-2FB57AD5E731}']
    function get_QueryText: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_LinguisticDetails: Search_ISearchQueryLinguisticDetails; safecall;
    property Language: HSTRING read get_Language;
    property LinguisticDetails: Search_ISearchQueryLinguisticDetails read get_LinguisticDetails;
    property QueryText: HSTRING read get_QueryText;
  end;

  // Windows.ApplicationModel.Search.ISearchQueryLinguisticDetails
  // External
  Search_ISearchQueryLinguisticDetails = interface(IInspectable)
  ['{46A1205B-69C9-4745-B72F-A8A4FC8F24AE}']
    function get_QueryTextAlternatives: IVectorView_1__HSTRING; safecall;
    function get_QueryTextCompositionStart: Cardinal; safecall;
    function get_QueryTextCompositionLength: Cardinal; safecall;
    property QueryTextAlternatives: IVectorView_1__HSTRING read get_QueryTextAlternatives;
    property QueryTextCompositionLength: Cardinal read get_QueryTextCompositionLength;
    property QueryTextCompositionStart: Cardinal read get_QueryTextCompositionStart;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.SearchBox,Windows.UI.Xaml.Controls.SearchBoxSuggestionsRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxSuggestionsRequestedEventArgs>
  // External
  TypedEventHandler_2__ISearchBox__ISearchBoxSuggestionsRequestedEventArgs = interface(IUnknown)
  ['{287DD4FE-12FC-5289-AB8A-7C7217024A6B}']
    procedure Invoke(sender: ISearchBox; args: ISearchBoxSuggestionsRequestedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Controls.ISearchBoxSuggestionsRequestedEventArgs
  // External
  ISearchBoxSuggestionsRequestedEventArgs = interface(IInspectable)
  ['{DA15170E-E566-48CB-BD11-FE4B0F30A44D}']
    function get_QueryText: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_LinguisticDetails: Search_ISearchQueryLinguisticDetails; safecall;
    function get_Request: Search_ISearchSuggestionsRequest; safecall;
    property Language: HSTRING read get_Language;
    property LinguisticDetails: Search_ISearchQueryLinguisticDetails read get_LinguisticDetails;
    property QueryText: HSTRING read get_QueryText;
    property Request: Search_ISearchSuggestionsRequest read get_Request;
  end;

  // Windows.ApplicationModel.Search.ISearchSuggestionsRequest
  // External
  Search_ISearchSuggestionsRequest = interface(IInspectable)
  ['{4E4E26A7-44E5-4039-9099-6000EAD1F0C6}']
    function get_IsCanceled: Boolean; safecall;
    function get_SearchSuggestionCollection: Search_ISearchSuggestionCollection; safecall;
    function GetDeferral: Search_ISearchSuggestionsRequestDeferral; safecall;
    property IsCanceled: Boolean read get_IsCanceled;
    property SearchSuggestionCollection: Search_ISearchSuggestionCollection read get_SearchSuggestionCollection;
  end;

  // Windows.ApplicationModel.Search.ISearchSuggestionCollection
  // External
  Search_ISearchSuggestionCollection = interface(IInspectable)
  ['{323A8A4B-FBEA-4446-ABBC-3DA7915FDD3A}']
    function get_Size: Cardinal; safecall;
    procedure AppendQuerySuggestion(text: HSTRING); safecall;
    procedure AppendQuerySuggestions(suggestions: IIterable_1__HSTRING); safecall;
    procedure AppendResultSuggestion(text: HSTRING; detailText: HSTRING; tag: HSTRING; image: IRandomAccessStreamReference; imageAlternateText: HSTRING); safecall;
    procedure AppendSearchSeparator(&label: HSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.ApplicationModel.Search.ISearchSuggestionsRequestDeferral
  // External
  Search_ISearchSuggestionsRequestDeferral = interface(IInspectable)
  ['{B71598A9-C065-456D-A845-1ECCEC5DC28B}']
    procedure Complete; safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.SearchBox,Windows.UI.Xaml.Controls.SearchBoxQuerySubmittedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxQuerySubmittedEventArgs>
  // External
  TypedEventHandler_2__ISearchBox__ISearchBoxQuerySubmittedEventArgs = interface(IUnknown)
  ['{56D6C824-A5B2-51F4-8AF7-7B8EE582C029}']
    procedure Invoke(sender: ISearchBox; args: ISearchBoxQuerySubmittedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Controls.ISearchBoxQuerySubmittedEventArgs
  // External
  ISearchBoxQuerySubmittedEventArgs = interface(IInspectable)
  ['{126E90FD-3C4E-4CCB-9AEF-4705D19FE548}']
    function get_QueryText: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_LinguisticDetails: Search_ISearchQueryLinguisticDetails; safecall;
    function get_KeyModifiers: VirtualKeyModifiers; safecall;
    property KeyModifiers: VirtualKeyModifiers read get_KeyModifiers;
    property Language: HSTRING read get_Language;
    property LinguisticDetails: Search_ISearchQueryLinguisticDetails read get_LinguisticDetails;
    property QueryText: HSTRING read get_QueryText;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.SearchBox,Windows.UI.Xaml.Controls.SearchBoxResultSuggestionChosenEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.ISearchBox,Windows.UI.Xaml.Controls.ISearchBoxResultSuggestionChosenEventArgs>
  // External
  TypedEventHandler_2__ISearchBox__ISearchBoxResultSuggestionChosenEventArgs = interface(IUnknown)
  ['{8D18767B-A4B8-52FC-8767-F87D05B5172E}']
    procedure Invoke(sender: ISearchBox; args: ISearchBoxResultSuggestionChosenEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.ISearchBoxResultSuggestionChosenEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_SearchBoxResultSuggestionChosenEventArgs)]
  ISearchBoxResultSuggestionChosenEventArgs = interface(IInspectable)
  ['{18918C23-E4C3-4662-A03B-D054FFD0F905}']
    function get_Tag: HSTRING; safecall;
    function get_KeyModifiers: VirtualKeyModifiers; safecall;
    property KeyModifiers: VirtualKeyModifiers read get_KeyModifiers;
    property Tag: HSTRING read get_Tag;
  end;

  // Windows.ApplicationModel.Search.ILocalContentSuggestionSettings
  // External
  Search_ILocalContentSuggestionSettings = interface(IInspectable)
  ['{EEAEB062-743D-456E-84A3-23F06F2D15D7}']
    procedure put_Enabled(value: Boolean); safecall;
    function get_Enabled: Boolean; safecall;
    function get_Locations: IVector_1__IStorageFolder; safecall;
    procedure put_AqsFilter(value: HSTRING); safecall;
    function get_AqsFilter: HSTRING; safecall;
    function get_PropertiesToMatch: IVector_1__HSTRING; safecall;
    property AqsFilter: HSTRING read get_AqsFilter write put_AqsFilter;
    property Enabled: Boolean read get_Enabled write put_Enabled;
    property Locations: IVector_1__IStorageFolder read get_Locations;
    property PropertiesToMatch: IVector_1__HSTRING read get_PropertiesToMatch;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Storage.StorageFolder>
  // Windows.Foundation.Collections.IVector`1<Windows.Storage.IStorageFolder>
  // External
  IVector_1__IStorageFolder = interface(IInspectable)
  ['{6C26B7BE-5F01-5A60-9DD7-FD17BE3A9DD6}']
    function GetAt(index: Cardinal): IStorageFolder; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IStorageFolder; safecall;
    function IndexOf(value: IStorageFolder; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IStorageFolder); safecall;
    procedure InsertAt(index: Cardinal; value: IStorageFolder); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IStorageFolder); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorageFolder): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIStorageFolder); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Data.IValueConverter
  // External
  Data_IValueConverter = interface(IInspectable)
  ['{E6F2FEF0-0712-487F-B313-F300B8D79AA1}']
    function Convert(value: IInspectable; targetType: Interop_TypeName; parameter: IInspectable; language: HSTRING): IInspectable; safecall;
    function ConvertBack(value: IInspectable; targetType: Interop_TypeName; parameter: IInspectable; language: HSTRING): IInspectable; safecall;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.Inline>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.IInline>
  // External
  IVector_1__Documents_IInline = interface(IInspectable)
  ['{92EC9252-8EE3-55D6-84B4-30B635077778}']
    function GetAt(index: Cardinal): Documents_IInline; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Documents_IInline; safecall;
    function IndexOf(value: Documents_IInline; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Documents_IInline); safecall;
    procedure InsertAt(index: Cardinal; value: Documents_IInline); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Documents_IInline); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_IInline): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDocuments_IInline); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Documents.IInline
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Documents_Inline)]
  Documents_IInline = interface(IInspectable)
  ['{0C92712D-1BC9-4931-8CB1-1AEADF1CC685}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.IInline>
  // External
  IVectorView_1__Documents_IInline = interface(IInspectable)
  ['{F268A1C3-C8AE-539A-9C3A-4444DAE728EB}']
    function GetAt(index: Cardinal): Documents_IInline; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Documents_IInline; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_IInline): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IUIElement
  [WinRTClassNameAttribute(SWindows_UI_Xaml_UIElement)]
  IUIElement = interface(IInspectable)
  ['{676D0BE9-B65C-41C6-BA40-58CF87F201C1}']
    function get_DesiredSize: TSizeF; safecall;
    function get_AllowDrop: Boolean; safecall;
    procedure put_AllowDrop(value: Boolean); safecall;
    function get_Opacity: Double; safecall;
    procedure put_Opacity(value: Double); safecall;
    function get_Clip: IRectangleGeometry; safecall;
    procedure put_Clip(value: IRectangleGeometry); safecall;
    function get_RenderTransform: ITransform; safecall;
    procedure put_RenderTransform(value: ITransform); safecall;
    function get_Projection: IProjection; safecall;
    procedure put_Projection(value: IProjection); safecall;
    function get_RenderTransformOrigin: TPointF; safecall;
    procedure put_RenderTransformOrigin(value: TPointF); safecall;
    function get_IsHitTestVisible: Boolean; safecall;
    procedure put_IsHitTestVisible(value: Boolean); safecall;
    function get_Visibility: Visibility; safecall;
    procedure put_Visibility(value: Visibility); safecall;
    function get_RenderSize: TSizeF; safecall;
    function get_UseLayoutRounding: Boolean; safecall;
    procedure put_UseLayoutRounding(value: Boolean); safecall;
    function get_Transitions: IVector_1__Animation_ITransition; safecall;
    procedure put_Transitions(value: IVector_1__Animation_ITransition); safecall;
    function get_CacheMode: ICacheMode; safecall;
    procedure put_CacheMode(value: ICacheMode); safecall;
    function get_IsTapEnabled: Boolean; safecall;
    procedure put_IsTapEnabled(value: Boolean); safecall;
    function get_IsDoubleTapEnabled: Boolean; safecall;
    procedure put_IsDoubleTapEnabled(value: Boolean); safecall;
    function get_IsRightTapEnabled: Boolean; safecall;
    procedure put_IsRightTapEnabled(value: Boolean); safecall;
    function get_IsHoldingEnabled: Boolean; safecall;
    procedure put_IsHoldingEnabled(value: Boolean); safecall;
    function get_ManipulationMode: Input_ManipulationModes; safecall;
    procedure put_ManipulationMode(value: Input_ManipulationModes); safecall;
    function get_PointerCaptures: IVectorView_1__Input_IPointer; safecall;
    function add_KeyUp(handler: Input_KeyEventHandler): EventRegistrationToken; safecall;
    procedure remove_KeyUp(token: EventRegistrationToken); safecall;
    function add_KeyDown(handler: Input_KeyEventHandler): EventRegistrationToken; safecall;
    procedure remove_KeyDown(token: EventRegistrationToken); safecall;
    function add_GotFocus(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_GotFocus(token: EventRegistrationToken); safecall;
    function add_LostFocus(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_LostFocus(token: EventRegistrationToken); safecall;
    function add_DragEnter(handler: DragEventHandler): EventRegistrationToken; safecall;
    procedure remove_DragEnter(token: EventRegistrationToken); safecall;
    function add_DragLeave(handler: DragEventHandler): EventRegistrationToken; safecall;
    procedure remove_DragLeave(token: EventRegistrationToken); safecall;
    function add_DragOver(handler: DragEventHandler): EventRegistrationToken; safecall;
    procedure remove_DragOver(token: EventRegistrationToken); safecall;
    function add_Drop(handler: DragEventHandler): EventRegistrationToken; safecall;
    procedure remove_Drop(token: EventRegistrationToken); safecall;
    function add_PointerPressed(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerPressed(token: EventRegistrationToken); safecall;
    function add_PointerMoved(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerMoved(token: EventRegistrationToken); safecall;
    function add_PointerReleased(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerReleased(token: EventRegistrationToken); safecall;
    function add_PointerEntered(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerEntered(token: EventRegistrationToken); safecall;
    function add_PointerExited(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerExited(token: EventRegistrationToken); safecall;
    function add_PointerCaptureLost(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerCaptureLost(token: EventRegistrationToken); safecall;
    function add_PointerCanceled(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerCanceled(token: EventRegistrationToken); safecall;
    function add_PointerWheelChanged(handler: Input_PointerEventHandler): EventRegistrationToken; safecall;
    procedure remove_PointerWheelChanged(token: EventRegistrationToken); safecall;
    function add_Tapped(handler: Input_TappedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Tapped(token: EventRegistrationToken); safecall;
    function add_DoubleTapped(handler: Input_DoubleTappedEventHandler): EventRegistrationToken; safecall;
    procedure remove_DoubleTapped(token: EventRegistrationToken); safecall;
    function add_Holding(handler: Input_HoldingEventHandler): EventRegistrationToken; safecall;
    procedure remove_Holding(token: EventRegistrationToken); safecall;
    function add_RightTapped(handler: Input_RightTappedEventHandler): EventRegistrationToken; safecall;
    procedure remove_RightTapped(token: EventRegistrationToken); safecall;
    function add_ManipulationStarting(handler: Input_ManipulationStartingEventHandler): EventRegistrationToken; safecall;
    procedure remove_ManipulationStarting(token: EventRegistrationToken); safecall;
    function add_ManipulationInertiaStarting(handler: Input_ManipulationInertiaStartingEventHandler): EventRegistrationToken; safecall;
    procedure remove_ManipulationInertiaStarting(token: EventRegistrationToken); safecall;
    function add_ManipulationStarted(handler: Input_ManipulationStartedEventHandler): EventRegistrationToken; safecall;
    procedure remove_ManipulationStarted(token: EventRegistrationToken); safecall;
    function add_ManipulationDelta(handler: Input_ManipulationDeltaEventHandler): EventRegistrationToken; safecall;
    procedure remove_ManipulationDelta(token: EventRegistrationToken); safecall;
    function add_ManipulationCompleted(handler: Input_ManipulationCompletedEventHandler): EventRegistrationToken; safecall;
    procedure remove_ManipulationCompleted(token: EventRegistrationToken); safecall;
    procedure Measure(availableSize: TSizeF); safecall;
    procedure Arrange(finalRect: TRectF); safecall;
    function CapturePointer(value: Input_IPointer): Boolean; safecall;
    procedure ReleasePointerCapture(value: Input_IPointer); safecall;
    procedure ReleasePointerCaptures; safecall;
    procedure AddHandler(routedEvent: IRoutedEvent; handler: IInspectable; handledEventsToo: Boolean); safecall;
    procedure RemoveHandler(routedEvent: IRoutedEvent; handler: IInspectable); safecall;
    function TransformToVisual(visual: IUIElement): IGeneralTransform; safecall;
    procedure InvalidateMeasure; safecall;
    procedure InvalidateArrange; safecall;
    procedure UpdateLayout; safecall;
    property AllowDrop: Boolean read get_AllowDrop write put_AllowDrop;
    property CacheMode: ICacheMode read get_CacheMode write put_CacheMode;
    property Clip: IRectangleGeometry read get_Clip write put_Clip;
    property DesiredSize: TSizeF read get_DesiredSize;
    property IsDoubleTapEnabled: Boolean read get_IsDoubleTapEnabled write put_IsDoubleTapEnabled;
    property IsHitTestVisible: Boolean read get_IsHitTestVisible write put_IsHitTestVisible;
    property IsHoldingEnabled: Boolean read get_IsHoldingEnabled write put_IsHoldingEnabled;
    property IsRightTapEnabled: Boolean read get_IsRightTapEnabled write put_IsRightTapEnabled;
    property IsTapEnabled: Boolean read get_IsTapEnabled write put_IsTapEnabled;
    property ManipulationMode: Input_ManipulationModes read get_ManipulationMode write put_ManipulationMode;
    property Opacity: Double read get_Opacity write put_Opacity;
    property PointerCaptures: IVectorView_1__Input_IPointer read get_PointerCaptures;
    property Projection: IProjection read get_Projection write put_Projection;
    property RenderSize: TSizeF read get_RenderSize;
    property RenderTransform: ITransform read get_RenderTransform write put_RenderTransform;
    property RenderTransformOrigin: TPointF read get_RenderTransformOrigin write put_RenderTransformOrigin;
    property Transitions: IVector_1__Animation_ITransition read get_Transitions write put_Transitions;
    property UseLayoutRounding: Boolean read get_UseLayoutRounding write put_UseLayoutRounding;
    property Visibility_: Visibility read get_Visibility write put_Visibility;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IRectangleGeometry
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_RectangleGeometry)]
  IRectangleGeometry = interface(IInspectable)
  ['{A25A1F58-C575-4196-91CF-9FDFB10445C3}']
    function get_Rect: TRectF; safecall;
    procedure put_Rect(value: TRectF); safecall;
    property Rect: TRectF read get_Rect write put_Rect;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.ITransform
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Transform)]
  ITransform = interface(IInspectable)
  ['{4DF74078-BFD6-4ED1-9682-D2FD8BF2FE6F}']
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IProjection
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Projection)]
  IProjection = interface(IInspectable)
  ['{B3443557-7F39-4D04-A89C-844338CAC897}']
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.Animation.Transition>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.Animation.ITransition>
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Animation_TransitionCollection)]
  IVector_1__Animation_ITransition = interface(IInspectable)
  ['{E798571F-7E3E-5E1A-AA55-CBC93B83F821}']
    function GetAt(index: Cardinal): Animation_ITransition; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Animation_ITransition; safecall;
    function IndexOf(value: Animation_ITransition; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Animation_ITransition); safecall;
    procedure InsertAt(index: Cardinal; value: Animation_ITransition); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Animation_ITransition); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PAnimation_ITransition): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PAnimation_ITransition); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.Animation.ITransition
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Animation_Transition)]
  Animation_ITransition = interface(IInspectable)
  ['{3C677C7C-01D0-4DCE-B333-976F93312B08}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Media.Animation.ITransition>
  // External
  IVectorView_1__Animation_ITransition = interface(IInspectable)
  ['{B072CE78-3433-54DD-BD01-A738B73CAD2B}']
    function GetAt(index: Cardinal): Animation_ITransition; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Animation_ITransition; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PAnimation_ITransition): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.ICacheMode
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_CacheMode)]
  ICacheMode = interface(IInspectable)
  ['{98DC8B11-C6F9-4DAB-B838-5FD5EC8C7350}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Input.IPointer>
  // External
  IVectorView_1__Input_IPointer = interface(IInspectable)
  ['{879A97D2-041F-5B03-A17D-213B7030EDED}']
    function GetAt(index: Cardinal): Input_IPointer; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Input_IPointer; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInput_IPointer): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.Input.IPointer
  // External
  Input_IPointer = interface(IInspectable)
  ['{5EE8F39F-747D-4171-90E6-CD37A9DFFB11}']
    function get_PointerId: Cardinal; safecall;
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_IsInContact: Boolean; safecall;
    function get_IsInRange: Boolean; safecall;
    property IsInContact: Boolean read get_IsInContact;
    property IsInRange: Boolean read get_IsInRange;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property PointerId: Cardinal read get_PointerId;
  end;

  // Windows.UI.Xaml.Input.KeyEventHandler
  // External
  Input_KeyEventHandler = interface(IUnknown)
  ['{7C63D2E5-7A0E-4E12-B96A-7715AA6FF1C8}']
    procedure Invoke(sender: IInspectable; e: Input_IKeyRoutedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Input.IKeyRoutedEventArgs
  // External
  Input_IKeyRoutedEventArgs = interface(IInspectable)
  ['{D4CD3DFE-4079-42E9-A39A-3095D3F049C6}']
    function get_Key: VirtualKey; safecall;
    function get_KeyStatus: CorePhysicalKeyStatus; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property Key: VirtualKey read get_Key;
    property KeyStatus: CorePhysicalKeyStatus read get_KeyStatus;
  end;

  // Windows.UI.Xaml.DragEventHandler
  // External
  DragEventHandler = interface(IUnknown)
  ['{2AB1A205-1E73-4BCF-AABC-57B97E21961D}']
    procedure Invoke(sender: IInspectable; e: IDragEventArgs); safecall;
  end;

  // Windows.UI.Xaml.IDragEventArgs
  // External
  IDragEventArgs = interface(IInspectable)
  ['{B440C7C3-02B4-4980-9342-25DAE1C0F188}']
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_Data: IDataPackage; safecall;
    procedure put_Data(value: IDataPackage); safecall;
    function GetPosition(relativeTo: IUIElement): TPointF; safecall;
    property Data: IDataPackage read get_Data write put_Data;
    property Handled: Boolean read get_Handled write put_Handled;
  end;

  // DualAPI Interface
  // Windows.ApplicationModel.DataTransfer.IDataPackage
  [WinRTClassNameAttribute(SWindows_ApplicationModel_DataTransfer_DataPackage)]
  IDataPackage = interface(IInspectable)
  ['{61EBF5C7-EFEA-4346-9554-981D7E198FFE}']
    function GetView: IDataPackageView; safecall;
    function get_Properties: IDataPackagePropertySet; safecall;
    function get_RequestedOperation: DataPackageOperation; safecall;
    procedure put_RequestedOperation(value: DataPackageOperation); safecall;
    function add_OperationCompleted(handler: TypedEventHandler_2__IDataPackage__IOperationCompletedEventArgs): EventRegistrationToken; safecall;
    procedure remove_OperationCompleted(token: EventRegistrationToken); safecall;
    function add_Destroyed(handler: TypedEventHandler_2__IDataPackage__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Destroyed(token: EventRegistrationToken); safecall;
    procedure SetData(formatId: HSTRING; value: IInspectable); safecall;
    procedure SetDataProvider(formatId: HSTRING; delayRenderer: DataProviderHandler); safecall;
    procedure SetText(value: HSTRING); safecall;
    procedure SetUri(value: IUriRuntimeClass); safecall;
    procedure SetHtmlFormat(value: HSTRING); safecall;
    function get_ResourceMap: IMap_2__HSTRING__IRandomAccessStreamReference; safecall;
    procedure SetRtf(value: HSTRING); safecall;
    procedure SetBitmap(value: IRandomAccessStreamReference); safecall;
    procedure SetStorageItems(value: IIterable_1__IStorageItem); overload; safecall;
    procedure SetStorageItems(value: IIterable_1__IStorageItem; readOnly: Boolean); overload; safecall;
    property Properties: IDataPackagePropertySet read get_Properties;
    property RequestedOperation: DataPackageOperation read get_RequestedOperation write put_RequestedOperation;
    property ResourceMap: IMap_2__HSTRING__IRandomAccessStreamReference read get_ResourceMap;
  end;

  // Windows.ApplicationModel.DataTransfer.IDataPackageView
  // External
  IDataPackageView = interface(IInspectable)
  ['{7B840471-5900-4D85-A90B-10CB85FE3552}']
    function get_Properties: IDataPackagePropertySetView; safecall;
    function get_RequestedOperation: DataPackageOperation; safecall;
    procedure ReportOperationCompleted(value: DataPackageOperation); safecall;
    function get_AvailableFormats: IVectorView_1__HSTRING; safecall;
    function Contains(formatId: HSTRING): Boolean; safecall;
    function GetDataAsync(formatId: HSTRING): IAsyncOperation_1__IInspectable; safecall;
    function GetTextAsync: IAsyncOperation_1__HSTRING; overload; safecall;
    function GetTextAsync(formatId: HSTRING): IAsyncOperation_1__HSTRING; overload; safecall;
    function GetUriAsync: IAsyncOperation_1__IUriRuntimeClass; safecall;
    function GetHtmlFormatAsync: IAsyncOperation_1__HSTRING; safecall;
    function GetResourceMapAsync: IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference; safecall;
    function GetRtfAsync: IAsyncOperation_1__HSTRING; safecall;
    function GetBitmapAsync: IAsyncOperation_1__IRandomAccessStreamReference; safecall;
    function GetStorageItemsAsync: IAsyncOperation_1__IVectorView_1__IStorageItem; safecall;
    property AvailableFormats: IVectorView_1__HSTRING read get_AvailableFormats;
    property Properties: IDataPackagePropertySetView read get_Properties;
    property RequestedOperation: DataPackageOperation read get_RequestedOperation;
  end;

  // Windows.ApplicationModel.DataTransfer.IDataPackagePropertySetView
  // External
  IDataPackagePropertySetView = interface(IInspectable)
  ['{B94CEC01-0C1A-4C57-BE55-75D01289735D}']
    function get_Title: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_Thumbnail: IRandomAccessStreamReference; safecall;
    function get_FileTypes: IVectorView_1__HSTRING; safecall;
    function get_ApplicationName: HSTRING; safecall;
    function get_ApplicationListingUri: IUriRuntimeClass; safecall;
    property ApplicationListingUri: IUriRuntimeClass read get_ApplicationListingUri;
    property ApplicationName: HSTRING read get_ApplicationName;
    property Description: HSTRING read get_Description;
    property FileTypes: IVectorView_1__HSTRING read get_FileTypes;
    property Thumbnail: IRandomAccessStreamReference read get_Thumbnail;
    property Title: HSTRING read get_Title;
  end;

  // Windows.Foundation.IAsyncOperation`1<String>
  // External
  IAsyncOperation_1__HSTRING = interface(IInspectable)
  ['{3E1FE603-F897-5263-B328-0806426B8A79}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__HSTRING); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__HSTRING; safecall;
    function GetResults: HSTRING; safecall;
    property Completed: AsyncOperationCompletedHandler_1__HSTRING read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<String>
  // External
  AsyncOperationCompletedHandler_1__HSTRING = interface(IUnknown)
  ['{B79A741F-7FB5-50AE-9E99-911201EC3D41}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__HSTRING; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Uri>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.IUriRuntimeClass>
  // External
  IAsyncOperation_1__IUriRuntimeClass = interface(IInspectable)
  ['{641CB9DD-A28D-59E2-B8DB-A227EDA6CF2E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IUriRuntimeClass); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IUriRuntimeClass; safecall;
    function GetResults: IUriRuntimeClass; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IUriRuntimeClass read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Uri>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.IUriRuntimeClass>
  // External
  AsyncOperationCompletedHandler_1__IUriRuntimeClass = interface(IUnknown)
  ['{AD46F1CC-2BB0-585C-9885-03C2780D4D58}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IUriRuntimeClass; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.TargetedContentFile>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  // External
  IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{AD3DACED-216C-52E5-B9BF-84C272EA41D0}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference; safecall;
    function GetResults: IMapView_2__HSTRING__IRandomAccessStreamReference; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.TargetedContentFile>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  // External
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference = interface(IUnknown)
  ['{BDE0B54D-D9D5-59B1-BB12-160B38175699}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.TargetedContentFile>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  // External
  IMapView_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{9D3A887A-7C69-5A15-99A6-29A09521719E}']
    function Lookup(key: HSTRING): IRandomAccessStreamReference; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IRandomAccessStreamReference; out second: IMapView_2__HSTRING__IRandomAccessStreamReference); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.ApplicationModel.DataTransfer.IDataPackagePropertySet
  // External
  IDataPackagePropertySet = interface(IInspectable)
  ['{CD1C93EB-4C4C-443A-A8D3-F5C241E91689}']
    function get_Title: HSTRING; safecall;
    procedure put_Title(value: HSTRING); safecall;
    function get_Description: HSTRING; safecall;
    procedure put_Description(value: HSTRING); safecall;
    function get_Thumbnail: IRandomAccessStreamReference; safecall;
    procedure put_Thumbnail(value: IRandomAccessStreamReference); safecall;
    function get_FileTypes: IVector_1__HSTRING; safecall;
    function get_ApplicationName: HSTRING; safecall;
    procedure put_ApplicationName(value: HSTRING); safecall;
    function get_ApplicationListingUri: IUriRuntimeClass; safecall;
    procedure put_ApplicationListingUri(value: IUriRuntimeClass); safecall;
    property ApplicationListingUri: IUriRuntimeClass read get_ApplicationListingUri write put_ApplicationListingUri;
    property ApplicationName: HSTRING read get_ApplicationName write put_ApplicationName;
    property Description: HSTRING read get_Description write put_Description;
    property FileTypes: IVector_1__HSTRING read get_FileTypes;
    property Thumbnail: IRandomAccessStreamReference read get_Thumbnail write put_Thumbnail;
    property Title: HSTRING read get_Title write put_Title;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.DataPackage,Windows.ApplicationModel.DataTransfer.OperationCompletedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.IDataPackage,Windows.ApplicationModel.DataTransfer.IOperationCompletedEventArgs>
  // External
  TypedEventHandler_2__IDataPackage__IOperationCompletedEventArgs = interface(IUnknown)
  ['{DD48AF6C-EF9A-59CB-B326-57D9E2411F21}']
    procedure Invoke(sender: IDataPackage; args: IOperationCompletedEventArgs); safecall;
  end;

  // Windows.ApplicationModel.DataTransfer.IOperationCompletedEventArgs
  // External
  IOperationCompletedEventArgs = interface(IInspectable)
  ['{E7AF329D-051D-4FAB-B1A9-47FD77F70A41}']
    function get_Operation: DataPackageOperation; safecall;
    property Operation: DataPackageOperation read get_Operation;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.DataPackage,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.DataTransfer.IDataPackage,Object>
  // External
  TypedEventHandler_2__IDataPackage__IInspectable = interface(IUnknown)
  ['{C156B0C3-1CBC-5CA4-901C-62C5A8CA5CB5}']
    procedure Invoke(sender: IDataPackage; args: IInspectable); safecall;
  end;

  // Windows.ApplicationModel.DataTransfer.DataProviderHandler
  // External
  DataProviderHandler = interface(IUnknown)
  ['{E7ECD720-F2F4-4A2D-920E-170A2F482A27}']
    procedure Invoke(request: IDataProviderRequest); safecall;
  end;

  // Windows.ApplicationModel.DataTransfer.IDataProviderRequest
  // External
  IDataProviderRequest = interface(IInspectable)
  ['{EBBC7157-D3C8-47DA-ACDE-F82388D5F716}']
    function get_FormatId: HSTRING; safecall;
    function get_Deadline: DateTime; safecall;
    function GetDeferral: IDataProviderDeferral; safecall;
    procedure SetData(value: IInspectable); safecall;
    property Deadline: DateTime read get_Deadline;
    property FormatId: HSTRING read get_FormatId;
  end;

  // Windows.ApplicationModel.DataTransfer.IDataProviderDeferral
  // External
  IDataProviderDeferral = interface(IInspectable)
  ['{C2CF2373-2D26-43D9-B69D-DCB86D03F6DA}']
    procedure Complete; safecall;
  end;

  // Windows.Foundation.Collections.IMap`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  // External
  IMap_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{6C5B38B7-9D17-5B5F-A04F-3730A82FD9B8}']
    function Lookup(key: HSTRING): IRandomAccessStreamReference; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    function GetView: IMapView_2__HSTRING__IRandomAccessStreamReference; safecall;
    function Insert(key: HSTRING; value: IRandomAccessStreamReference): Boolean; safecall;
    procedure Remove(key: HSTRING); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.IStorageItem>
  // External
  IIterable_1__IStorageItem = interface(IInspectable)
  ['{BB8B8418-65D1-544B-B083-6D172F568C73}']
    function First: IIterator_1__IStorageItem; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.IStorageItem>
  // External
  IIterator_1__IStorageItem = interface(IInspectable)
  ['{05B487C2-3830-5D3C-98DA-25FA11542DBD}']
    function get_Current: IStorageItem; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStorageItem): Cardinal; safecall;
    property Current: IStorageItem read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.UI.Xaml.Input.PointerEventHandler
  // External
  Input_PointerEventHandler = interface(IUnknown)
  ['{E4385929-C004-4BCF-8970-359486E39F88}']
    procedure Invoke(sender: IInspectable; e: Input_IPointerRoutedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Input.IPointerRoutedEventArgs
  // External
  Input_IPointerRoutedEventArgs = interface(IInspectable)
  ['{DA628F0A-9752-49E2-BDE2-49ECCAB9194D}']
    function get_Pointer: Input_IPointer; safecall;
    function get_KeyModifiers: VirtualKeyModifiers; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function GetCurrentPoint(relativeTo: IUIElement): IPointerPoint; safecall;
    function GetIntermediatePoints(relativeTo: IUIElement): IVector_1__IPointerPoint; safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property KeyModifiers: VirtualKeyModifiers read get_KeyModifiers;
    property Pointer: Input_IPointer read get_Pointer;
  end;

  // Windows.UI.Xaml.Input.TappedEventHandler
  // External
  Input_TappedEventHandler = interface(IUnknown)
  ['{68D940CC-9FF0-49CE-B141-3F07EC477B97}']
    procedure Invoke(sender: IInspectable; e: Input_ITappedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.ITappedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_TappedRoutedEventArgs)]
  Input_ITappedRoutedEventArgs = interface(IInspectable)
  ['{A099E6BE-E624-459A-BB1D-E05C73E2CC66}']
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function GetPosition(relativeTo: IUIElement): TPointF; safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
  end;

  // Windows.UI.Xaml.Input.DoubleTappedEventHandler
  // External
  Input_DoubleTappedEventHandler = interface(IUnknown)
  ['{3124D025-04A7-4D45-825E-8204A624DBF4}']
    procedure Invoke(sender: IInspectable; e: Input_IDoubleTappedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IDoubleTappedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_DoubleTappedRoutedEventArgs)]
  Input_IDoubleTappedRoutedEventArgs = interface(IInspectable)
  ['{AF404424-26DF-44F4-8714-9359249B62D3}']
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function GetPosition(relativeTo: IUIElement): TPointF; safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
  end;

  // Windows.UI.Xaml.Input.HoldingEventHandler
  // External
  Input_HoldingEventHandler = interface(IUnknown)
  ['{ECAE8CCD-8E5E-4FBE-9846-30A6370AFCDF}']
    procedure Invoke(sender: IInspectable; e: Input_IHoldingRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IHoldingRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_HoldingRoutedEventArgs)]
  Input_IHoldingRoutedEventArgs = interface(IInspectable)
  ['{C246FF23-D80D-44DE-8DB9-0D815E269AC0}']
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_HoldingState: HoldingState; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function GetPosition(relativeTo: IUIElement): TPointF; safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property HoldingState_: HoldingState read get_HoldingState;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
  end;

  // Windows.UI.Xaml.Input.RightTappedEventHandler
  // External
  Input_RightTappedEventHandler = interface(IUnknown)
  ['{2532A062-F447-4950-9C46-F1E34A2C2238}']
    procedure Invoke(sender: IInspectable; e: Input_IRightTappedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IRightTappedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_RightTappedRoutedEventArgs)]
  Input_IRightTappedRoutedEventArgs = interface(IInspectable)
  ['{6834869D-7BD5-4033-B237-172F79ABE393}']
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function GetPosition(relativeTo: IUIElement): TPointF; safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
  end;

  // Windows.UI.Xaml.Input.ManipulationStartingEventHandler
  // External
  Input_ManipulationStartingEventHandler = interface(IUnknown)
  ['{10D0B04E-BFE4-42CB-823C-3FECD8770EF8}']
    procedure Invoke(sender: IInspectable; e: Input_IManipulationStartingRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationStartingRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationStartingRoutedEventArgs)]
  Input_IManipulationStartingRoutedEventArgs = interface(IInspectable)
  ['{18D636B7-53A4-4C15-A498-F3A9CA212A42}']
    function get_Mode: Input_ManipulationModes; safecall;
    procedure put_Mode(value: Input_ManipulationModes); safecall;
    function get_Container: IUIElement; safecall;
    procedure put_Container(value: IUIElement); safecall;
    function get_Pivot: Input_IManipulationPivot; safecall;
    procedure put_Pivot(value: Input_IManipulationPivot); safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property Container: IUIElement read get_Container write put_Container;
    property Handled: Boolean read get_Handled write put_Handled;
    property Mode: Input_ManipulationModes read get_Mode write put_Mode;
    property Pivot: Input_IManipulationPivot read get_Pivot write put_Pivot;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationPivot
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationPivot)]
  Input_IManipulationPivot = interface(IInspectable)
  ['{2E3838A5-E6C2-4998-82AC-18748B141666}']
    function get_Center: TPointF; safecall;
    procedure put_Center(value: TPointF); safecall;
    function get_Radius: Double; safecall;
    procedure put_Radius(value: Double); safecall;
    property Center: TPointF read get_Center write put_Center;
    property Radius: Double read get_Radius write put_Radius;
  end;

  // Windows.UI.Xaml.Input.ManipulationInertiaStartingEventHandler
  // External
  Input_ManipulationInertiaStartingEventHandler = interface(IUnknown)
  ['{D39D6322-7C9C-481B-827B-C8B2D9BB6FC7}']
    procedure Invoke(sender: IInspectable; e: Input_IManipulationInertiaStartingRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationInertiaStartingRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationInertiaStartingRoutedEventArgs)]
  Input_IManipulationInertiaStartingRoutedEventArgs = interface(IInspectable)
  ['{246A91A9-CA43-4C0B-ACEF-81E8B8147520}']
    function get_Container: IUIElement; safecall;
    function get_ExpansionBehavior: Input_IInertiaExpansionBehavior; safecall;
    procedure put_ExpansionBehavior(value: Input_IInertiaExpansionBehavior); safecall;
    function get_RotationBehavior: Input_IInertiaRotationBehavior; safecall;
    procedure put_RotationBehavior(value: Input_IInertiaRotationBehavior); safecall;
    function get_TranslationBehavior: Input_IInertiaTranslationBehavior; safecall;
    procedure put_TranslationBehavior(value: Input_IInertiaTranslationBehavior); safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_Delta: ManipulationDelta; safecall;
    function get_Cumulative: ManipulationDelta; safecall;
    function get_Velocities: ManipulationVelocities; safecall;
    property Container: IUIElement read get_Container;
    property Cumulative: ManipulationDelta read get_Cumulative;
    property Delta: ManipulationDelta read get_Delta;
    property ExpansionBehavior: Input_IInertiaExpansionBehavior read get_ExpansionBehavior write put_ExpansionBehavior;
    property Handled: Boolean read get_Handled write put_Handled;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property RotationBehavior: Input_IInertiaRotationBehavior read get_RotationBehavior write put_RotationBehavior;
    property TranslationBehavior: Input_IInertiaTranslationBehavior read get_TranslationBehavior write put_TranslationBehavior;
    property Velocities: ManipulationVelocities read get_Velocities;
  end;

  // Windows.UI.Xaml.Input.IInertiaExpansionBehavior
  // External
  Input_IInertiaExpansionBehavior = interface(IInspectable)
  ['{751D87E5-8D42-44C5-965E-3CD30CC9D6F7}']
    function get_DesiredDeceleration: Double; safecall;
    procedure put_DesiredDeceleration(value: Double); safecall;
    function get_DesiredExpansion: Double; safecall;
    procedure put_DesiredExpansion(value: Double); safecall;
    property DesiredDeceleration: Double read get_DesiredDeceleration write put_DesiredDeceleration;
    property DesiredExpansion: Double read get_DesiredExpansion write put_DesiredExpansion;
  end;

  // Windows.UI.Xaml.Input.IInertiaRotationBehavior
  // External
  Input_IInertiaRotationBehavior = interface(IInspectable)
  ['{424CFB2E-BBFD-4625-AE78-20C65BF1EFAF}']
    function get_DesiredDeceleration: Double; safecall;
    procedure put_DesiredDeceleration(value: Double); safecall;
    function get_DesiredRotation: Double; safecall;
    procedure put_DesiredRotation(value: Double); safecall;
    property DesiredDeceleration: Double read get_DesiredDeceleration write put_DesiredDeceleration;
    property DesiredRotation: Double read get_DesiredRotation write put_DesiredRotation;
  end;

  // Windows.UI.Xaml.Input.IInertiaTranslationBehavior
  // External
  Input_IInertiaTranslationBehavior = interface(IInspectable)
  ['{45D3A512-3B32-4882-A4C2-ECFA2D4B6DF0}']
    function get_DesiredDeceleration: Double; safecall;
    procedure put_DesiredDeceleration(value: Double); safecall;
    function get_DesiredDisplacement: Double; safecall;
    procedure put_DesiredDisplacement(value: Double); safecall;
    property DesiredDeceleration: Double read get_DesiredDeceleration write put_DesiredDeceleration;
    property DesiredDisplacement: Double read get_DesiredDisplacement write put_DesiredDisplacement;
  end;

  // Windows.UI.Xaml.Input.ManipulationStartedEventHandler
  // External
  Input_ManipulationStartedEventHandler = interface(IUnknown)
  ['{F88345F8-E0A3-4BE2-B90C-DC20E6D8BEB0}']
    procedure Invoke(sender: IInspectable; e: Input_IManipulationStartedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationStartedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationStartedRoutedEventArgs)]
  Input_IManipulationStartedRoutedEventArgs = interface(IInspectable)
  ['{5DB1AA05-9F80-48B6-AE6C-4F119DE8FF13}']
    function get_Container: IUIElement; safecall;
    function get_Position: TPointF; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    function get_Cumulative: ManipulationDelta; safecall;
    procedure Complete; safecall;
    property Container: IUIElement read get_Container;
    property Cumulative: ManipulationDelta read get_Cumulative;
    property Handled: Boolean read get_Handled write put_Handled;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property Position: TPointF read get_Position;
  end;

  // Windows.UI.Xaml.Input.ManipulationDeltaEventHandler
  // External
  Input_ManipulationDeltaEventHandler = interface(IUnknown)
  ['{AA1160CB-DFB9-4C56-ABDC-711B63C8EB94}']
    procedure Invoke(sender: IInspectable; e: Input_IManipulationDeltaRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationDeltaRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationDeltaRoutedEventArgs)]
  Input_IManipulationDeltaRoutedEventArgs = interface(IInspectable)
  ['{400D5794-4C6F-491D-82D6-3517109399C6}']
    function get_Container: IUIElement; safecall;
    function get_Position: TPointF; safecall;
    function get_IsInertial: Boolean; safecall;
    function get_Delta: ManipulationDelta; safecall;
    function get_Cumulative: ManipulationDelta; safecall;
    function get_Velocities: ManipulationVelocities; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    procedure Complete; safecall;
    property Container: IUIElement read get_Container;
    property Cumulative: ManipulationDelta read get_Cumulative;
    property Delta: ManipulationDelta read get_Delta;
    property Handled: Boolean read get_Handled write put_Handled;
    property IsInertial: Boolean read get_IsInertial;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property Position: TPointF read get_Position;
    property Velocities: ManipulationVelocities read get_Velocities;
  end;

  // Windows.UI.Xaml.Input.ManipulationCompletedEventHandler
  // External
  Input_ManipulationCompletedEventHandler = interface(IUnknown)
  ['{38EF4B0F-14F8-42DF-9A1E-A4BCC4AF77F4}']
    procedure Invoke(sender: IInspectable; e: Input_IManipulationCompletedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Input.IManipulationCompletedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Input_ManipulationCompletedRoutedEventArgs)]
  Input_IManipulationCompletedRoutedEventArgs = interface(IInspectable)
  ['{B5AD9B23-2F41-498E-8319-015EE8A75346}']
    function get_Container: IUIElement; safecall;
    function get_Position: TPointF; safecall;
    function get_IsInertial: Boolean; safecall;
    function get_Cumulative: ManipulationDelta; safecall;
    function get_Velocities: ManipulationVelocities; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_PointerDeviceType: Input_PointerDeviceType; safecall;
    property Container: IUIElement read get_Container;
    property Cumulative: ManipulationDelta read get_Cumulative;
    property Handled: Boolean read get_Handled write put_Handled;
    property IsInertial: Boolean read get_IsInertial;
    property PointerDeviceType: Input_PointerDeviceType read get_PointerDeviceType;
    property Position: TPointF read get_Position;
    property Velocities: ManipulationVelocities read get_Velocities;
  end;

  // Windows.UI.Xaml.IRoutedEvent
  // External
  IRoutedEvent = interface(IInspectable)
  ['{A6B25818-43C1-4C70-865C-7BDD5A32E327}']
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IGeneralTransform
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_GeneralTransform)]
  IGeneralTransform = interface(IInspectable)
  ['{A06798B7-A2EC-415F-ADE2-EADE9333F2C7}']
    function get_Inverse: IGeneralTransform; safecall;
    function TransformPoint(point: TPointF): TPointF; safecall;
    function TryTransform(inPoint: TPointF; out outPoint: TPointF): Boolean; safecall;
    function TransformBounds(rect: TRectF): TRectF; safecall;
    property Inverse: IGeneralTransform read get_Inverse;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.UIElement>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IUIElement>
  // External
  IVector_1__IUIElement = interface(IInspectable)
  ['{B4C1E3AC-8768-5B9D-A661-F63330B8507B}']
    function GetAt(index: Cardinal): IUIElement; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IUIElement; safecall;
    function IndexOf(value: IUIElement; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IUIElement); safecall;
    procedure InsertAt(index: Cardinal; value: IUIElement); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IUIElement); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIUIElement): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIUIElement); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IUIElement>
  // External
  IVectorView_1__IUIElement = interface(IInspectable)
  ['{8FF941EA-49F4-5F0A-A951-F83F03D3B29B}']
    function GetAt(index: Cardinal): IUIElement; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IUIElement; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIUIElement): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IBrushTransition
  [WinRTClassNameAttribute(SWindows_UI_Xaml_BrushTransition)]
  IBrushTransition = interface(IInspectable)
  ['{1116972C-9DAD-5429-A7DD-B2B7D061AB8E}']
    function get_Duration: TimeSpan; safecall;
    procedure put_Duration(value: TimeSpan); safecall;
    property Duration: TimeSpan read get_Duration write put_Duration;
  end;

  // Windows.UI.Xaml.DependencyPropertyChangedEventHandler
  // External
  DependencyPropertyChangedEventHandler = interface(IUnknown)
  ['{09223E5A-75BE-4499-8180-1DDC005421C0}']
    procedure Invoke(sender: IInspectable; e: IDependencyPropertyChangedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.IDependencyPropertyChangedEventArgs
  // External
  IDependencyPropertyChangedEventArgs = interface(IInspectable)
  ['{81212C2B-24D0-4957-ABC3-224470A93A4E}']
    function get_Property: IDependencyProperty; safecall;
    function get_OldValue: IInspectable; safecall;
    function get_NewValue: IInspectable; safecall;
    property NewValue: IInspectable read get_NewValue;
    property OldValue: IInspectable read get_OldValue;
    property &Property: IDependencyProperty read get_Property;
  end;

  // Windows.UI.Xaml.Input.ICharacterReceivedRoutedEventArgs
  // External
  Input_ICharacterReceivedRoutedEventArgs = interface(IInspectable)
  ['{7849FD82-48E4-444D-9419-93AB8892C107}']
    function get_Character: Char; safecall;
    function get_KeyStatus: CorePhysicalKeyStatus; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property Character: Char read get_Character;
    property Handled: Boolean read get_Handled write put_Handled;
    property KeyStatus: CorePhysicalKeyStatus read get_KeyStatus;
  end;

  // Windows.UI.Xaml.Navigation.NavigatedEventHandler
  // External
  Navigation_NavigatedEventHandler = interface(IUnknown)
  ['{7BD1CF54-23CF-4CCE-B2F5-4CE78D96896E}']
    procedure Invoke(sender: IInspectable; e: Navigation_INavigationEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Navigation.INavigationEventArgs
  // External
  Navigation_INavigationEventArgs = interface(IInspectable)
  ['{B6AA9834-6691-44D1-BDF7-58820C27B0D0}']
    function get_Content: IInspectable; safecall;
    function get_Parameter: IInspectable; safecall;
    function get_SourcePageType: Interop_TypeName; safecall;
    function get_NavigationMode: Navigation_NavigationMode; safecall;
    function get_Uri: IUriRuntimeClass; safecall;
    procedure put_Uri(value: IUriRuntimeClass); safecall;
    property Content: IInspectable read get_Content;
    property NavigationMode: Navigation_NavigationMode read get_NavigationMode;
    property Parameter: IInspectable read get_Parameter;
    property SourcePageType: Interop_TypeName read get_SourcePageType;
    property Uri: IUriRuntimeClass read get_Uri write put_Uri;
  end;

  // Windows.UI.Xaml.Navigation.NavigatingCancelEventHandler
  // External
  Navigation_NavigatingCancelEventHandler = interface(IUnknown)
  ['{75D6A78F-A302-4489-9898-24EA49182910}']
    procedure Invoke(sender: IInspectable; e: Navigation_INavigatingCancelEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Navigation.INavigatingCancelEventArgs
  // External
  Navigation_INavigatingCancelEventArgs = interface(IInspectable)
  ['{FD1D67AE-EAFB-4079-BE80-6DC92A03AEDF}']
    function get_Cancel: Boolean; safecall;
    procedure put_Cancel(value: Boolean); safecall;
    function get_NavigationMode: Navigation_NavigationMode; safecall;
    function get_SourcePageType: Interop_TypeName; safecall;
    property Cancel: Boolean read get_Cancel write put_Cancel;
    property NavigationMode: Navigation_NavigationMode read get_NavigationMode;
    property SourcePageType: Interop_TypeName read get_SourcePageType;
  end;

  // Windows.UI.Xaml.Navigation.NavigationFailedEventHandler
  // External
  Navigation_NavigationFailedEventHandler = interface(IUnknown)
  ['{4DAB4671-12B2-43C7-B892-9BE2DCD3E88D}']
    procedure Invoke(sender: IInspectable; e: Navigation_INavigationFailedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Navigation.INavigationFailedEventArgs
  // External
  Navigation_INavigationFailedEventArgs = interface(IInspectable)
  ['{11C1DFF7-36C2-4102-B2EF-0217A97289B3}']
    function get_Exception: HRESULT; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_SourcePageType: Interop_TypeName; safecall;
    property Exception: HRESULT read get_Exception;
    property Handled: Boolean read get_Handled write put_Handled;
    property SourcePageType: Interop_TypeName read get_SourcePageType;
  end;

  // Windows.UI.Xaml.Navigation.NavigationStoppedEventHandler
  // External
  Navigation_NavigationStoppedEventHandler = interface(IUnknown)
  ['{F0117DDB-12FA-4D8D-8B26-B383D09C2B3C}']
    procedure Invoke(sender: IInspectable; e: Navigation_INavigationEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Navigation.PageStackEntry>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Navigation.IPageStackEntry>
  // External
  IVector_1__Navigation_IPageStackEntry = interface(IInspectable)
  ['{E561A13F-89A1-5EF2-A3FE-EBA1B4539B46}']
    function GetAt(index: Cardinal): Navigation_IPageStackEntry; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Navigation_IPageStackEntry; safecall;
    function IndexOf(value: Navigation_IPageStackEntry; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Navigation_IPageStackEntry); safecall;
    procedure InsertAt(index: Cardinal; value: Navigation_IPageStackEntry); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Navigation_IPageStackEntry); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PNavigation_IPageStackEntry): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PNavigation_IPageStackEntry); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Navigation.IPageStackEntry
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Navigation_PageStackEntry)]
  Navigation_IPageStackEntry = interface(IInspectable)
  ['{EF8814A6-9388-4ACA-8572-405194069080}']
    function get_SourcePageType: Interop_TypeName; safecall;
    function get_Parameter: IInspectable; safecall;
    function get_NavigationTransitionInfo: Animation_INavigationTransitionInfo; safecall;
    property NavigationTransitionInfo: Animation_INavigationTransitionInfo read get_NavigationTransitionInfo;
    property Parameter: IInspectable read get_Parameter;
    property SourcePageType: Interop_TypeName read get_SourcePageType;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.Animation.INavigationTransitionInfo
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Animation_NavigationTransitionInfo)]
  Animation_INavigationTransitionInfo = interface(IInspectable)
  ['{A9B05091-AE4A-4372-8625-21B7A8B98CA4}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Navigation.IPageStackEntry>
  // External
  IVectorView_1__Navigation_IPageStackEntry = interface(IInspectable)
  ['{D34746AC-D201-5C5F-A7AF-5B04B3CC1A6E}']
    function GetAt(index: Cardinal): Navigation_IPageStackEntry; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Navigation_IPageStackEntry; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PNavigation_IPageStackEntry): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Navigation.IFrameNavigationOptions
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Navigation_FrameNavigationOptions)]
  Navigation_IFrameNavigationOptions = interface(IInspectable)
  ['{B539AD2A-9FB7-520A-8F41-57A50C59CF92}']
    function get_IsNavigationStackEnabled: Boolean; safecall;
    procedure put_IsNavigationStackEnabled(value: Boolean); safecall;
    function get_TransitionInfoOverride: Animation_INavigationTransitionInfo; safecall;
    procedure put_TransitionInfoOverride(value: Animation_INavigationTransitionInfo); safecall;
    property IsNavigationStackEnabled: Boolean read get_IsNavigationStackEnabled write put_IsNavigationStackEnabled;
    property TransitionInfoOverride: Animation_INavigationTransitionInfo read get_TransitionInfoOverride write put_TransitionInfoOverride;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IObservableVector`1<Windows.UI.Xaml.IDependencyObject>
  [WinRTClassNameAttribute(SWindows_UI_Xaml_DependencyObjectCollection)]
  IObservableVector_1__IDependencyObject = interface(IInspectable)
  ['{1BBADE0C-F703-5AC5-ACDE-448DE801D127}']
    function add_VectorChanged(vhnd: VectorChangedEventHandler_1__IDependencyObject): EventRegistrationToken; safecall;
    procedure remove_VectorChanged(token: EventRegistrationToken); safecall;
  end;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.UI.Xaml.DependencyObject>
  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.UI.Xaml.IDependencyObject>
  // External
  VectorChangedEventHandler_1__IDependencyObject = interface(IUnknown)
  ['{B62DEC93-A7A5-5FF5-B2D2-6BD20CA0BD4D}']
    procedure Invoke(sender: IObservableVector_1__IDependencyObject; event: IVectorChangedEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Data.IItemIndexRange>
  // External
  IVectorView_1__Data_IItemIndexRange = interface(IInspectable)
  ['{01AA146D-06B8-5B7B-BF72-DB079CA98B45}']
    function GetAt(index: Cardinal): Data_IItemIndexRange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Data_IItemIndexRange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PData_IItemIndexRange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Data.IItemIndexRange
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Data_ItemIndexRange)]
  Data_IItemIndexRange = interface(IInspectable)
  ['{83B834BE-0583-4A26-9B64-8BF4A2F65704}']
    function get_FirstIndex: Integer; safecall;
    function get_Length: Cardinal; safecall;
    function get_LastIndex: Integer; safecall;
    property FirstIndex: Integer read get_FirstIndex;
    property LastIndex: Integer read get_LastIndex;
    property Length: Cardinal read get_Length;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Documents.IContentLinkProviderCollection
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Documents_ContentLinkProviderCollection)]
  Documents_IContentLinkProviderCollection = interface(IInspectable)
  ['{F5B84D0C-A9F4-4D1A-A13C-10DEF1843734}']
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.RichEditBox,Windows.UI.Xaml.Documents.ContentLinkInvokedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.Controls.IRichEditBox,Windows.UI.Xaml.Documents.IContentLinkInvokedEventArgs>
  // External
  TypedEventHandler_2__IRichEditBox__Documents_IContentLinkInvokedEventArgs = interface(IUnknown)
  ['{E261FBA5-7714-5E51-B12E-9C0D12DA4006}']
    procedure Invoke(sender: IRichEditBox; args: Documents_IContentLinkInvokedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IRichEditBox
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_RichEditBox)]
  IRichEditBox = interface(IInspectable)
  ['{90A57A40-80B6-4FCE-B1EC-E3C616284B6A}']
    function get_IsReadOnly: Boolean; safecall;
    procedure put_IsReadOnly(value: Boolean); safecall;
    function get_AcceptsReturn: Boolean; safecall;
    procedure put_AcceptsReturn(value: Boolean); safecall;
    function get_TextAlignment: TextAlignment; safecall;
    procedure put_TextAlignment(value: TextAlignment); safecall;
    function get_TextWrapping: TextWrapping; safecall;
    procedure put_TextWrapping(value: TextWrapping); safecall;
    function get_IsSpellCheckEnabled: Boolean; safecall;
    procedure put_IsSpellCheckEnabled(value: Boolean); safecall;
    function get_IsTextPredictionEnabled: Boolean; safecall;
    procedure put_IsTextPredictionEnabled(value: Boolean); safecall;
    function get_Document: ITextDocument; safecall;
    function get_InputScope: Input_IInputScope; safecall;
    procedure put_InputScope(value: Input_IInputScope); safecall;
    function add_TextChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_TextChanged(token: EventRegistrationToken); safecall;
    function add_SelectionChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_SelectionChanged(token: EventRegistrationToken); safecall;
    function add_ContextMenuOpening(handler: ContextMenuOpeningEventHandler): EventRegistrationToken; safecall;
    procedure remove_ContextMenuOpening(token: EventRegistrationToken); safecall;
    property AcceptsReturn: Boolean read get_AcceptsReturn write put_AcceptsReturn;
    property Document: ITextDocument read get_Document;
    property InputScope: Input_IInputScope read get_InputScope write put_InputScope;
    property IsReadOnly: Boolean read get_IsReadOnly write put_IsReadOnly;
    property IsSpellCheckEnabled: Boolean read get_IsSpellCheckEnabled write put_IsSpellCheckEnabled;
    property IsTextPredictionEnabled: Boolean read get_IsTextPredictionEnabled write put_IsTextPredictionEnabled;
    property TextAlignment_: TextAlignment read get_TextAlignment write put_TextAlignment;
    property TextWrapping_: TextWrapping read get_TextWrapping write put_TextWrapping;
  end;

  // Windows.UI.Text.ITextDocument
  // External
  ITextDocument = interface(IInspectable)
  ['{BEEE4DDB-90B2-408C-A2F6-0A0AC31E33E4}']
    function get_CaretType: CaretType; safecall;
    procedure put_CaretType(value: CaretType); safecall;
    function get_DefaultTabStop: Single; safecall;
    procedure put_DefaultTabStop(value: Single); safecall;
    function get_Selection: ITextSelection; safecall;
    function get_UndoLimit: Cardinal; safecall;
    procedure put_UndoLimit(value: Cardinal); safecall;
    function CanCopy: Boolean; safecall;
    function CanPaste: Boolean; safecall;
    function CanRedo: Boolean; safecall;
    function CanUndo: Boolean; safecall;
    function ApplyDisplayUpdates: Integer; safecall;
    function BatchDisplayUpdates: Integer; safecall;
    procedure BeginUndoGroup; safecall;
    procedure EndUndoGroup; safecall;
    function GetDefaultCharacterFormat: ITextCharacterFormat; safecall;
    function GetDefaultParagraphFormat: ITextParagraphFormat; safecall;
    function GetRange(startPosition: Integer; endPosition: Integer): ITextRange; safecall;
    function GetRangeFromPoint(point: TPointF; options: PointOptions): ITextRange; safecall;
    procedure GetText(options: TextGetOptions; out value: HSTRING); safecall;
    procedure LoadFromStream(options: TextSetOptions; value: IRandomAccessStream); safecall;
    procedure Redo; safecall;
    procedure SaveToStream(options: TextGetOptions; value: IRandomAccessStream); safecall;
    procedure SetDefaultCharacterFormat(value: ITextCharacterFormat); safecall;
    procedure SetDefaultParagraphFormat(value: ITextParagraphFormat); safecall;
    procedure SetText(options: TextSetOptions; value: HSTRING); safecall;
    procedure Undo; safecall;
    property CaretType_: CaretType read get_CaretType write put_CaretType;
    property DefaultTabStop: Single read get_DefaultTabStop write put_DefaultTabStop;
    property Selection: ITextSelection read get_Selection;
    property UndoLimit: Cardinal read get_UndoLimit write put_UndoLimit;
  end;

  // Windows.UI.Text.ITextSelection
  // External
  ITextSelection = interface(IInspectable)
  ['{A6D36724-F28F-430A-B2CF-C343671EC0E9}']
    function get_Options: SelectionOptions; safecall;
    procedure put_Options(value: SelectionOptions); safecall;
    function get_Type: SelectionType; safecall;
    function EndKey(&unit: TextRangeUnit; extend: Boolean): Integer; safecall;
    function HomeKey(&unit: TextRangeUnit; extend: Boolean): Integer; safecall;
    function MoveDown(&unit: TextRangeUnit; count: Integer; extend: Boolean): Integer; safecall;
    function MoveLeft(&unit: TextRangeUnit; count: Integer; extend: Boolean): Integer; safecall;
    function MoveRight(&unit: TextRangeUnit; count: Integer; extend: Boolean): Integer; safecall;
    function MoveUp(&unit: TextRangeUnit; count: Integer; extend: Boolean): Integer; safecall;
    procedure TypeText(value: HSTRING); safecall;
    property Options: SelectionOptions read get_Options write put_Options;
    property &Type: SelectionType read get_Type;
  end;

  // Windows.UI.Text.ITextCharacterFormat
  // External
  ITextCharacterFormat = interface(IInspectable)
  ['{5ADEF3DB-05FB-442D-8065-642AFEA02CED}']
    function get_AllCaps: FormatEffect; safecall;
    procedure put_AllCaps(value: FormatEffect); safecall;
    function get_BackgroundColor: Color; safecall;
    procedure put_BackgroundColor(value: Color); safecall;
    function get_Bold: FormatEffect; safecall;
    procedure put_Bold(value: FormatEffect); safecall;
    function get_FontStretch: FontStretch; safecall;
    procedure put_FontStretch(value: FontStretch); safecall;
    function get_FontStyle: FontStyle; safecall;
    procedure put_FontStyle(value: FontStyle); safecall;
    function get_ForegroundColor: Color; safecall;
    procedure put_ForegroundColor(value: Color); safecall;
    function get_Hidden: FormatEffect; safecall;
    procedure put_Hidden(value: FormatEffect); safecall;
    function get_Italic: FormatEffect; safecall;
    procedure put_Italic(value: FormatEffect); safecall;
    function get_Kerning: Single; safecall;
    procedure put_Kerning(value: Single); safecall;
    function get_LanguageTag: HSTRING; safecall;
    procedure put_LanguageTag(value: HSTRING); safecall;
    function get_LinkType: LinkType; safecall;
    function get_Name: HSTRING; safecall;
    procedure put_Name(value: HSTRING); safecall;
    function get_Outline: FormatEffect; safecall;
    procedure put_Outline(value: FormatEffect); safecall;
    function get_Position: Single; safecall;
    procedure put_Position(value: Single); safecall;
    function get_ProtectedText: FormatEffect; safecall;
    procedure put_ProtectedText(value: FormatEffect); safecall;
    function get_Size: Single; safecall;
    procedure put_Size(value: Single); safecall;
    function get_SmallCaps: FormatEffect; safecall;
    procedure put_SmallCaps(value: FormatEffect); safecall;
    function get_Spacing: Single; safecall;
    procedure put_Spacing(value: Single); safecall;
    function get_Strikethrough: FormatEffect; safecall;
    procedure put_Strikethrough(value: FormatEffect); safecall;
    function get_Subscript: FormatEffect; safecall;
    procedure put_Subscript(value: FormatEffect); safecall;
    function get_Superscript: FormatEffect; safecall;
    procedure put_Superscript(value: FormatEffect); safecall;
    function get_TextScript: TextScript; safecall;
    procedure put_TextScript(value: TextScript); safecall;
    function get_Underline: UnderlineType; safecall;
    procedure put_Underline(value: UnderlineType); safecall;
    function get_Weight: Integer; safecall;
    procedure put_Weight(value: Integer); safecall;
    procedure SetClone(value: ITextCharacterFormat); safecall;
    function GetClone: ITextCharacterFormat; safecall;
    function IsEqual(format: ITextCharacterFormat): Boolean; safecall;
    property AllCaps: FormatEffect read get_AllCaps write put_AllCaps;
    property BackgroundColor: Color read get_BackgroundColor write put_BackgroundColor;
    property Bold: FormatEffect read get_Bold write put_Bold;
    property FontStretch_: FontStretch read get_FontStretch write put_FontStretch;
    property FontStyle_: FontStyle read get_FontStyle write put_FontStyle;
    property ForegroundColor: Color read get_ForegroundColor write put_ForegroundColor;
    property Hidden: FormatEffect read get_Hidden write put_Hidden;
    property Italic: FormatEffect read get_Italic write put_Italic;
    property Kerning: Single read get_Kerning write put_Kerning;
    property LanguageTag: HSTRING read get_LanguageTag write put_LanguageTag;
    property LinkType_: LinkType read get_LinkType;
    property Name: HSTRING read get_Name write put_Name;
    property Outline: FormatEffect read get_Outline write put_Outline;
    property Position: Single read get_Position write put_Position;
    property ProtectedText: FormatEffect read get_ProtectedText write put_ProtectedText;
    property Size: Single read get_Size write put_Size;
    property SmallCaps: FormatEffect read get_SmallCaps write put_SmallCaps;
    property Spacing: Single read get_Spacing write put_Spacing;
    property Strikethrough: FormatEffect read get_Strikethrough write put_Strikethrough;
    property Subscript: FormatEffect read get_Subscript write put_Subscript;
    property Superscript: FormatEffect read get_Superscript write put_Superscript;
    property TextScript_: TextScript read get_TextScript write put_TextScript;
    property Underline: UnderlineType read get_Underline write put_Underline;
    property Weight: Integer read get_Weight write put_Weight;
  end;

  // Windows.UI.Text.ITextParagraphFormat
  // External
  ITextParagraphFormat = interface(IInspectable)
  ['{2CF8CFA6-4676-498A-93F5-BBDBFC0BD883}']
    function get_Alignment: ParagraphAlignment; safecall;
    procedure put_Alignment(value: ParagraphAlignment); safecall;
    function get_FirstLineIndent: Single; safecall;
    function get_KeepTogether: FormatEffect; safecall;
    procedure put_KeepTogether(value: FormatEffect); safecall;
    function get_KeepWithNext: FormatEffect; safecall;
    procedure put_KeepWithNext(value: FormatEffect); safecall;
    function get_LeftIndent: Single; safecall;
    function get_LineSpacing: Single; safecall;
    function get_LineSpacingRule: LineSpacingRule; safecall;
    function get_ListAlignment: MarkerAlignment; safecall;
    procedure put_ListAlignment(value: MarkerAlignment); safecall;
    function get_ListLevelIndex: Integer; safecall;
    procedure put_ListLevelIndex(value: Integer); safecall;
    function get_ListStart: Integer; safecall;
    procedure put_ListStart(value: Integer); safecall;
    function get_ListStyle: MarkerStyle; safecall;
    procedure put_ListStyle(value: MarkerStyle); safecall;
    function get_ListTab: Single; safecall;
    procedure put_ListTab(value: Single); safecall;
    function get_ListType: MarkerType; safecall;
    procedure put_ListType(value: MarkerType); safecall;
    function get_NoLineNumber: FormatEffect; safecall;
    procedure put_NoLineNumber(value: FormatEffect); safecall;
    function get_PageBreakBefore: FormatEffect; safecall;
    procedure put_PageBreakBefore(value: FormatEffect); safecall;
    function get_RightIndent: Single; safecall;
    procedure put_RightIndent(value: Single); safecall;
    function get_RightToLeft: FormatEffect; safecall;
    procedure put_RightToLeft(value: FormatEffect); safecall;
    function get_Style: ParagraphStyle; safecall;
    procedure put_Style(value: ParagraphStyle); safecall;
    function get_SpaceAfter: Single; safecall;
    procedure put_SpaceAfter(value: Single); safecall;
    function get_SpaceBefore: Single; safecall;
    procedure put_SpaceBefore(value: Single); safecall;
    function get_WidowControl: FormatEffect; safecall;
    procedure put_WidowControl(value: FormatEffect); safecall;
    function get_TabCount: Integer; safecall;
    procedure AddTab(position: Single; align: TabAlignment; leader: TabLeader); safecall;
    procedure ClearAllTabs; safecall;
    procedure DeleteTab(position: Single); safecall;
    function GetClone: ITextParagraphFormat; safecall;
    procedure GetTab(index: Integer; out position: Single; out align: TabAlignment; out leader: TabLeader); safecall;
    function IsEqual(format: ITextParagraphFormat): Boolean; safecall;
    procedure SetClone(format: ITextParagraphFormat); safecall;
    procedure SetIndents(start: Single; left: Single; right: Single); safecall;
    procedure SetLineSpacing(rule: LineSpacingRule; spacing: Single); safecall;
    property Alignment: ParagraphAlignment read get_Alignment write put_Alignment;
    property FirstLineIndent: Single read get_FirstLineIndent;
    property KeepTogether: FormatEffect read get_KeepTogether write put_KeepTogether;
    property KeepWithNext: FormatEffect read get_KeepWithNext write put_KeepWithNext;
    property LeftIndent: Single read get_LeftIndent;
    property LineSpacing: Single read get_LineSpacing;
    property LineSpacingRule_: LineSpacingRule read get_LineSpacingRule;
    property ListAlignment: MarkerAlignment read get_ListAlignment write put_ListAlignment;
    property ListLevelIndex: Integer read get_ListLevelIndex write put_ListLevelIndex;
    property ListStart: Integer read get_ListStart write put_ListStart;
    property ListStyle: MarkerStyle read get_ListStyle write put_ListStyle;
    property ListTab: Single read get_ListTab write put_ListTab;
    property ListType: MarkerType read get_ListType write put_ListType;
    property NoLineNumber: FormatEffect read get_NoLineNumber write put_NoLineNumber;
    property PageBreakBefore: FormatEffect read get_PageBreakBefore write put_PageBreakBefore;
    property RightIndent: Single read get_RightIndent write put_RightIndent;
    property RightToLeft: FormatEffect read get_RightToLeft write put_RightToLeft;
    property SpaceAfter: Single read get_SpaceAfter write put_SpaceAfter;
    property SpaceBefore: Single read get_SpaceBefore write put_SpaceBefore;
    property Style: ParagraphStyle read get_Style write put_Style;
    property TabCount: Integer read get_TabCount;
    property WidowControl: FormatEffect read get_WidowControl write put_WidowControl;
  end;

  // Windows.UI.Text.ITextRange
  // External
  ITextRange = interface(IInspectable)
  ['{5B9E4E57-C072-42A0-8945-AF503EE54768}']
    function get_Character: Char; safecall;
    procedure put_Character(value: Char); safecall;
    function get_CharacterFormat: ITextCharacterFormat; safecall;
    procedure put_CharacterFormat(value: ITextCharacterFormat); safecall;
    function get_FormattedText: ITextRange; safecall;
    procedure put_FormattedText(value: ITextRange); safecall;
    function get_EndPosition: Integer; safecall;
    procedure put_EndPosition(value: Integer); safecall;
    function get_Gravity: RangeGravity; safecall;
    procedure put_Gravity(value: RangeGravity); safecall;
    function get_Length: Integer; safecall;
    function get_Link: HSTRING; safecall;
    procedure put_Link(value: HSTRING); safecall;
    function get_ParagraphFormat: ITextParagraphFormat; safecall;
    procedure put_ParagraphFormat(value: ITextParagraphFormat); safecall;
    function get_StartPosition: Integer; safecall;
    procedure put_StartPosition(value: Integer); safecall;
    function get_StoryLength: Integer; safecall;
    function get_Text: HSTRING; safecall;
    procedure put_Text(value: HSTRING); safecall;
    function CanPaste(format: Integer): Boolean; safecall;
    procedure ChangeCase(value: LetterCase); safecall;
    procedure Collapse(value: Boolean); safecall;
    procedure Copy; safecall;
    procedure Cut; safecall;
    function Delete(&unit: TextRangeUnit; count: Integer): Integer; safecall;
    function EndOf(&unit: TextRangeUnit; extend: Boolean): Integer; safecall;
    function Expand(&unit: TextRangeUnit): Integer; safecall;
    function FindText(value: HSTRING; scanLength: Integer; options: FindOptions): Integer; safecall;
    procedure GetCharacterUtf32(out value: Cardinal; offset: Integer); safecall;
    function GetClone: ITextRange; safecall;
    function GetIndex(&unit: TextRangeUnit): Integer; safecall;
    procedure GetPoint(horizontalAlign: HorizontalCharacterAlignment; verticalAlign: VerticalCharacterAlignment; options: PointOptions; out point: TPointF); safecall;
    procedure GetRect(options: PointOptions; out rect: TRectF; out hit: Integer); safecall;
    procedure GetText(options: TextGetOptions; out value: HSTRING); safecall;
    procedure GetTextViaStream(options: TextGetOptions; value: IRandomAccessStream); safecall;
    function InRange(range: ITextRange): Boolean; safecall;
    procedure InsertImage(width: Integer; height: Integer; ascent: Integer; verticalAlign: VerticalCharacterAlignment; alternateText: HSTRING; value: IRandomAccessStream); safecall;
    function InStory(range: ITextRange): Boolean; safecall;
    function IsEqual(range: ITextRange): Boolean; safecall;
    function Move(&unit: TextRangeUnit; count: Integer): Integer; safecall;
    function MoveEnd(&unit: TextRangeUnit; count: Integer): Integer; safecall;
    function MoveStart(&unit: TextRangeUnit; count: Integer): Integer; safecall;
    procedure Paste(format: Integer); safecall;
    procedure ScrollIntoView(value: PointOptions); safecall;
    procedure MatchSelection; safecall;
    procedure SetIndex(&unit: TextRangeUnit; index: Integer; extend: Boolean); safecall;
    procedure SetPoint(point: TPointF; options: PointOptions; extend: Boolean); safecall;
    procedure SetRange(startPosition: Integer; endPosition: Integer); safecall;
    procedure SetText(options: TextSetOptions; value: HSTRING); safecall;
    procedure SetTextViaStream(options: TextSetOptions; value: IRandomAccessStream); safecall;
    function StartOf(&unit: TextRangeUnit; extend: Boolean): Integer; safecall;
    property Character: Char read get_Character write put_Character;
    property CharacterFormat: ITextCharacterFormat read get_CharacterFormat write put_CharacterFormat;
    property EndPosition: Integer read get_EndPosition write put_EndPosition;
    property FormattedText: ITextRange read get_FormattedText write put_FormattedText;
    property Gravity: RangeGravity read get_Gravity write put_Gravity;
    property Length: Integer read get_Length;
    property Link: HSTRING read get_Link write put_Link;
    property ParagraphFormat: ITextParagraphFormat read get_ParagraphFormat write put_ParagraphFormat;
    property StartPosition: Integer read get_StartPosition write put_StartPosition;
    property StoryLength: Integer read get_StoryLength;
    property Text: HSTRING read get_Text write put_Text;
  end;

  // Windows.UI.Xaml.Controls.ContextMenuOpeningEventHandler
  // External
  ContextMenuOpeningEventHandler = interface(IUnknown)
  ['{DF945151-745C-4446-B2FC-216D765847A0}']
    procedure Invoke(sender: IInspectable; e: IContextMenuEventArgs); safecall;
  end;

  // Windows.UI.Xaml.Controls.IContextMenuEventArgs
  // External
  IContextMenuEventArgs = interface(IInspectable)
  ['{1F7DF263-C14B-4528-B6F0-637999D83CC6}']
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_CursorLeft: Double; safecall;
    function get_CursorTop: Double; safecall;
    property CursorLeft: Double read get_CursorLeft;
    property CursorTop: Double read get_CursorTop;
    property Handled: Boolean read get_Handled write put_Handled;
  end;

  // Windows.UI.Xaml.Documents.IContentLinkInvokedEventArgs
  // External
  Documents_IContentLinkInvokedEventArgs = interface(IInspectable)
  ['{546717C1-E8DF-4593-9639-97595FDF8310}']
    function get_ContentLinkInfo: IContentLinkInfo; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property ContentLinkInfo: IContentLinkInfo read get_ContentLinkInfo;
    property Handled: Boolean read get_Handled write put_Handled;
  end;

  // Windows.UI.Text.IContentLinkInfo
  // External
  IContentLinkInfo = interface(IInspectable)
  ['{1ED52525-1C5F-48CB-B335-78B50A2EE642}']
    function get_Id: Cardinal; safecall;
    procedure put_Id(value: Cardinal); safecall;
    function get_DisplayText: HSTRING; safecall;
    procedure put_DisplayText(value: HSTRING); safecall;
    function get_SecondaryText: HSTRING; safecall;
    procedure put_SecondaryText(value: HSTRING); safecall;
    function get_Uri: IUriRuntimeClass; safecall;
    procedure put_Uri(value: IUriRuntimeClass); safecall;
    function get_LinkContentKind: HSTRING; safecall;
    procedure put_LinkContentKind(value: HSTRING); safecall;
    property DisplayText: HSTRING read get_DisplayText write put_DisplayText;
    property Id: Cardinal read get_Id write put_Id;
    property LinkContentKind: HSTRING read get_LinkContentKind write put_LinkContentKind;
    property SecondaryText: HSTRING read get_SecondaryText write put_SecondaryText;
    property Uri: IUriRuntimeClass read get_Uri write put_Uri;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.TextHighlighter>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.ITextHighlighter>
  // External
  IVector_1__Documents_ITextHighlighter = interface(IInspectable)
  ['{64905558-D062-5F31-84AF-4A5FA896AE50}']
    function GetAt(index: Cardinal): Documents_ITextHighlighter; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Documents_ITextHighlighter; safecall;
    function IndexOf(value: Documents_ITextHighlighter; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Documents_ITextHighlighter); safecall;
    procedure InsertAt(index: Cardinal; value: Documents_ITextHighlighter); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Documents_ITextHighlighter); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_ITextHighlighter): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDocuments_ITextHighlighter); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Documents.ITextHighlighter
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Documents_TextHighlighter)]
  Documents_ITextHighlighter = interface(IInspectable)
  ['{BA6CB54B-7D75-4535-B30D-A81A00B637A4}']
    function get_Ranges: IVector_1__Documents_TextRange; safecall;
    function get_Foreground: IBrush; safecall;
    procedure put_Foreground(value: IBrush); safecall;
    function get_Background: IBrush; safecall;
    procedure put_Background(value: IBrush); safecall;
    property Background: IBrush read get_Background write put_Background;
    property Foreground: IBrush read get_Foreground write put_Foreground;
    property Ranges: IVector_1__Documents_TextRange read get_Ranges;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Documents.TextRange>
  // External
  IVector_1__Documents_TextRange = interface(IInspectable)
  ['{EE9D4CDA-0750-5C1F-93AA-59ADD8C1421B}']
    function GetAt(index: Cardinal): Documents_TextRange; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Documents_TextRange; safecall;
    function IndexOf(value: Documents_TextRange; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Documents_TextRange); safecall;
    procedure InsertAt(index: Cardinal; value: Documents_TextRange); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Documents_TextRange); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_TextRange): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDocuments_TextRange); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.TextRange>
  // External
  IVectorView_1__Documents_TextRange = interface(IInspectable)
  ['{C824D1D0-771A-5123-90CC-52281F0F287A}']
    function GetAt(index: Cardinal): Documents_TextRange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Documents_TextRange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_TextRange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IBrush
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_Brush)]
  IBrush = interface(IInspectable)
  ['{8806A321-1E06-422C-A1CC-01696559E021}']
    function get_Opacity: Double; safecall;
    procedure put_Opacity(value: Double); safecall;
    function get_Transform: ITransform; safecall;
    procedure put_Transform(value: ITransform); safecall;
    function get_RelativeTransform: ITransform; safecall;
    procedure put_RelativeTransform(value: ITransform); safecall;
    property Opacity: Double read get_Opacity write put_Opacity;
    property RelativeTransform: ITransform read get_RelativeTransform write put_RelativeTransform;
    property Transform: ITransform read get_Transform write put_Transform;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Documents.ITextHighlighter>
  // External
  IVectorView_1__Documents_ITextHighlighter = interface(IInspectable)
  ['{6B4C9285-E325-5E45-8BCB-9A633033D063}']
    function GetAt(index: Cardinal): Documents_ITextHighlighter; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Documents_ITextHighlighter; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDocuments_ITextHighlighter): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.Navigation.LoadCompletedEventHandler
  // External
  Navigation_LoadCompletedEventHandler = interface(IUnknown)
  ['{AEBAF785-43FC-4E2C-95C3-97AE84EABC8E}']
    procedure Invoke(sender: IInspectable; e: Navigation_INavigationEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.DependencyObject>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.IDependencyObject>
  // External
  IVector_1__IDependencyObject = interface(IInspectable)
  ['{771B857E-AB5C-5DB8-A021-397C92CDC44C}']
    function GetAt(index: Cardinal): IDependencyObject; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IDependencyObject; safecall;
    function IndexOf(value: IDependencyObject; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IDependencyObject); safecall;
    procedure InsertAt(index: Cardinal; value: IDependencyObject); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IDependencyObject); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIDependencyObject): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIDependencyObject); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.IDependencyObject>
  // External
  IVectorView_1__IDependencyObject = interface(IInspectable)
  ['{724BD94E-A094-5E1D-9BDA-8DE976BFB46D}']
    function GetAt(index: Cardinal): IDependencyObject; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IDependencyObject; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIDependencyObject): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IReference`1<Windows.UI.Xaml.Thickness>
  // External
  IReference_1__Thickness = interface(IInspectable)
  ['{A19F7BA8-D8CD-5DF2-AB44-FEFD26644484}']
    function get_Value: Thickness; safecall;
    property Value: Thickness read get_Value;
  end;

  // Windows.UI.Xaml.Input.IProcessKeyboardAcceleratorEventArgs
  // External
  Input_IProcessKeyboardAcceleratorEventArgs = interface(IInspectable)
  ['{FB79C216-972B-440C-9B83-2B4198DCF09D}']
    function get_Key: VirtualKey; safecall;
    function get_Modifiers: VirtualKeyModifiers; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property Handled: Boolean read get_Handled write put_Handled;
    property Key: VirtualKey read get_Key;
    property Modifiers: VirtualKeyModifiers read get_Modifiers;
  end;

  // Windows.UI.Xaml.IXamlRoot
  // External
  IXamlRoot = interface(IInspectable)
  ['{34B50756-1696-5B6D-8E9B-C71464CCAD5A}']
    function get_Content: IUIElement; safecall;
    function get_Size: TSizeF; safecall;
    function get_RasterizationScale: Double; safecall;
    function get_IsHostVisible: Boolean; safecall;
    function get_UIContext: IUIContext; safecall;
    function add_Changed(handler: TypedEventHandler_2__IXamlRoot__IXamlRootChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Changed(token: EventRegistrationToken); safecall;
    property Content: IUIElement read get_Content;
    property IsHostVisible: Boolean read get_IsHostVisible;
    property RasterizationScale: Double read get_RasterizationScale;
    property Size: TSizeF read get_Size;
    property UIContext: IUIContext read get_UIContext;
  end;

  // Windows.UI.IUIContext
  // External
  IUIContext = interface(IInspectable)
  ['{BB5CFACD-5BD8-59D0-A59E-1C17A4D6D243}']
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.XamlRoot,Windows.UI.Xaml.XamlRootChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.UI.Xaml.IXamlRoot,Windows.UI.Xaml.IXamlRootChangedEventArgs>
  // External
  TypedEventHandler_2__IXamlRoot__IXamlRootChangedEventArgs = interface(IUnknown)
  ['{B86311BB-2EEF-5B2C-8D0D-C178F3979B6A}']
    procedure Invoke(sender: IXamlRoot; args: IXamlRootChangedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.IXamlRootChangedEventArgs
  // External
  IXamlRootChangedEventArgs = interface(IInspectable)
  ['{92D71C21-D23C-5A17-BCB8-001504B6BB19}']
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IMediaElement
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_MediaElement)]
  IMediaElement = interface(IInspectable)
  ['{A38ED2CF-13DE-4299-ADE2-AE18F74ED353}']
    function get_PosterSource: IImageSource; safecall;
    procedure put_PosterSource(value: IImageSource); safecall;
    function get_Source: IUriRuntimeClass; safecall;
    procedure put_Source(value: IUriRuntimeClass); safecall;
    function get_IsMuted: Boolean; safecall;
    procedure put_IsMuted(value: Boolean); safecall;
    function get_IsAudioOnly: Boolean; safecall;
    function get_AutoPlay: Boolean; safecall;
    procedure put_AutoPlay(value: Boolean); safecall;
    function get_Volume: Double; safecall;
    procedure put_Volume(value: Double); safecall;
    function get_Balance: Double; safecall;
    procedure put_Balance(value: Double); safecall;
    function get_NaturalVideoHeight: Integer; safecall;
    function get_NaturalVideoWidth: Integer; safecall;
    function get_NaturalDuration: Duration; safecall;
    function get_Position: TimeSpan; safecall;
    procedure put_Position(value: TimeSpan); safecall;
    function get_DownloadProgress: Double; safecall;
    function get_BufferingProgress: Double; safecall;
    function get_DownloadProgressOffset: Double; safecall;
    function get_CurrentState: MediaElementState; safecall;
    function get_Markers: IVector_1__ITimelineMarker; safecall;
    function get_CanSeek: Boolean; safecall;
    function get_CanPause: Boolean; safecall;
    function get_AudioStreamCount: Integer; safecall;
    function get_AudioStreamIndex: IReference_1__Integer; safecall;
    procedure put_AudioStreamIndex(value: IReference_1__Integer); safecall;
    function get_PlaybackRate: Double; safecall;
    procedure put_PlaybackRate(value: Double); safecall;
    function get_IsLooping: Boolean; safecall;
    procedure put_IsLooping(value: Boolean); safecall;
    function get_PlayToSource: PlayTo_IPlayToSource; safecall;
    function get_DefaultPlaybackRate: Double; safecall;
    procedure put_DefaultPlaybackRate(value: Double); safecall;
    function get_AspectRatioWidth: Integer; safecall;
    function get_AspectRatioHeight: Integer; safecall;
    function get_RealTimePlayback: Boolean; safecall;
    procedure put_RealTimePlayback(value: Boolean); safecall;
    function get_AudioCategory: AudioCategory; safecall;
    procedure put_AudioCategory(value: AudioCategory); safecall;
    function get_AudioDeviceType: AudioDeviceType; safecall;
    procedure put_AudioDeviceType(value: AudioDeviceType); safecall;
    function get_ProtectionManager: Protection_IMediaProtectionManager; safecall;
    procedure put_ProtectionManager(value: Protection_IMediaProtectionManager); safecall;
    function get_Stereo3DVideoPackingMode: Stereo3DVideoPackingMode; safecall;
    procedure put_Stereo3DVideoPackingMode(value: Stereo3DVideoPackingMode); safecall;
    function get_Stereo3DVideoRenderMode: Stereo3DVideoRenderMode; safecall;
    procedure put_Stereo3DVideoRenderMode(value: Stereo3DVideoRenderMode); safecall;
    function get_IsStereo3DVideo: Boolean; safecall;
    function add_MediaOpened(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_MediaOpened(token: EventRegistrationToken); safecall;
    function add_MediaEnded(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_MediaEnded(token: EventRegistrationToken); safecall;
    function add_MediaFailed(handler: ExceptionRoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_MediaFailed(token: EventRegistrationToken); safecall;
    function add_DownloadProgressChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_DownloadProgressChanged(token: EventRegistrationToken); safecall;
    function add_BufferingProgressChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_BufferingProgressChanged(token: EventRegistrationToken); safecall;
    function add_CurrentStateChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_CurrentStateChanged(token: EventRegistrationToken); safecall;
    function add_MarkerReached(handler: TimelineMarkerRoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_MarkerReached(token: EventRegistrationToken); safecall;
    function add_RateChanged(handler: RateChangedRoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_RateChanged(token: EventRegistrationToken); safecall;
    function add_VolumeChanged(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_VolumeChanged(token: EventRegistrationToken); safecall;
    function add_SeekCompleted(handler: RoutedEventHandler): EventRegistrationToken; safecall;
    procedure remove_SeekCompleted(token: EventRegistrationToken); safecall;
    procedure Stop; safecall;
    procedure Play; safecall;
    procedure Pause; safecall;
    function CanPlayType(&type: HSTRING): MediaCanPlayResponse; safecall;
    procedure SetSource(stream: IRandomAccessStream; mimeType: HSTRING); safecall;
    function GetAudioStreamLanguage(index: IReference_1__Integer): HSTRING; safecall;
    procedure AddAudioEffect(effectID: HSTRING; effectOptional: Boolean; effectConfiguration: IPropertySet); safecall;
    procedure AddVideoEffect(effectID: HSTRING; effectOptional: Boolean; effectConfiguration: IPropertySet); safecall;
    procedure RemoveAllEffects; safecall;
    function get_ActualStereo3DVideoPackingMode: Stereo3DVideoPackingMode; safecall;
    property ActualStereo3DVideoPackingMode: Stereo3DVideoPackingMode read get_ActualStereo3DVideoPackingMode;
    property AspectRatioHeight: Integer read get_AspectRatioHeight;
    property AspectRatioWidth: Integer read get_AspectRatioWidth;
    property AudioCategory_: AudioCategory read get_AudioCategory write put_AudioCategory;
    property AudioDeviceType_: AudioDeviceType read get_AudioDeviceType write put_AudioDeviceType;
    property AudioStreamCount: Integer read get_AudioStreamCount;
    property AudioStreamIndex: IReference_1__Integer read get_AudioStreamIndex write put_AudioStreamIndex;
    property AutoPlay: Boolean read get_AutoPlay write put_AutoPlay;
    property Balance: Double read get_Balance write put_Balance;
    property BufferingProgress: Double read get_BufferingProgress;
    property CanPause: Boolean read get_CanPause;
    property CanSeek: Boolean read get_CanSeek;
    property CurrentState: MediaElementState read get_CurrentState;
    property DefaultPlaybackRate: Double read get_DefaultPlaybackRate write put_DefaultPlaybackRate;
    property DownloadProgress: Double read get_DownloadProgress;
    property DownloadProgressOffset: Double read get_DownloadProgressOffset;
    property IsAudioOnly: Boolean read get_IsAudioOnly;
    property IsLooping: Boolean read get_IsLooping write put_IsLooping;
    property IsMuted: Boolean read get_IsMuted write put_IsMuted;
    property IsStereo3DVideo: Boolean read get_IsStereo3DVideo;
    property Markers: IVector_1__ITimelineMarker read get_Markers;
    property NaturalDuration: Duration read get_NaturalDuration;
    property NaturalVideoHeight: Integer read get_NaturalVideoHeight;
    property NaturalVideoWidth: Integer read get_NaturalVideoWidth;
    property PlayToSource: PlayTo_IPlayToSource read get_PlayToSource;
    property PlaybackRate: Double read get_PlaybackRate write put_PlaybackRate;
    property Position: TimeSpan read get_Position write put_Position;
    property PosterSource: IImageSource read get_PosterSource write put_PosterSource;
    property ProtectionManager: Protection_IMediaProtectionManager read get_ProtectionManager write put_ProtectionManager;
    property RealTimePlayback: Boolean read get_RealTimePlayback write put_RealTimePlayback;
    property Source: IUriRuntimeClass read get_Source write put_Source;
    property Stereo3DVideoPackingMode_: Stereo3DVideoPackingMode read get_Stereo3DVideoPackingMode write put_Stereo3DVideoPackingMode;
    property Stereo3DVideoRenderMode_: Stereo3DVideoRenderMode read get_Stereo3DVideoRenderMode write put_Stereo3DVideoRenderMode;
    property Volume: Double read get_Volume write put_Volume;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IImageSource
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_ImageSource)]
  IImageSource = interface(IInspectable)
  ['{737EF309-EA41-4D96-A71C-98E98EFCAB07}']
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.TimelineMarker>
  // Windows.Foundation.Collections.IVector`1<Windows.UI.Xaml.Media.ITimelineMarker>
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_TimelineMarkerCollection)]
  IVector_1__ITimelineMarker = interface(IInspectable)
  ['{B2D8DDB4-D2B8-5930-942D-26118756BD46}']
    function GetAt(index: Cardinal): ITimelineMarker; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__ITimelineMarker; safecall;
    function IndexOf(value: ITimelineMarker; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: ITimelineMarker); safecall;
    procedure InsertAt(index: Cardinal; value: ITimelineMarker); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: ITimelineMarker); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PITimelineMarker): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PITimelineMarker); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.ITimelineMarker
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_TimelineMarker)]
  ITimelineMarker = interface(IInspectable)
  ['{A68EF02D-45BA-4E50-8CAD-AAEA3A227AF5}']
    function get_Time: TimeSpan; safecall;
    procedure put_Time(value: TimeSpan); safecall;
    function get_Type: HSTRING; safecall;
    procedure put_Type(value: HSTRING); safecall;
    function get_Text: HSTRING; safecall;
    procedure put_Text(value: HSTRING); safecall;
    property Text: HSTRING read get_Text write put_Text;
    property Time: TimeSpan read get_Time write put_Time;
    property &Type: HSTRING read get_Type write put_Type;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Media.ITimelineMarker>
  // External
  IVectorView_1__ITimelineMarker = interface(IInspectable)
  ['{3610381A-2CA3-5419-A8E5-90617DAB6DA2}']
    function GetAt(index: Cardinal): ITimelineMarker; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ITimelineMarker; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PITimelineMarker): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Media.PlayTo.IPlayToSource
  // External
  PlayTo_IPlayToSource = interface(IInspectable)
  ['{7F138A08-FBB7-4B09-8356-AA5F4E335C31}']
    function get_Connection: PlayTo_IPlayToConnection; safecall;
    function get_Next: PlayTo_IPlayToSource; safecall;
    procedure put_Next(value: PlayTo_IPlayToSource); safecall;
    procedure PlayNext; safecall;
    property Connection: PlayTo_IPlayToConnection read get_Connection;
    property Next: PlayTo_IPlayToSource read get_Next write put_Next;
  end;

  // Windows.Media.PlayTo.IPlayToConnection
  // External
  PlayTo_IPlayToConnection = interface(IInspectable)
  ['{112FBFC8-F235-4FDE-8D41-9BF27C9E9A40}']
    function get_State: PlayTo_PlayToConnectionState; safecall;
    function add_StateChanged(handler: TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    function add_Transferred(handler: TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionTransferredEventArgs): EventRegistrationToken; safecall;
    procedure remove_Transferred(token: EventRegistrationToken); safecall;
    function add_Error(handler: TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionErrorEventArgs): EventRegistrationToken; safecall;
    procedure remove_Error(token: EventRegistrationToken); safecall;
    property State: PlayTo_PlayToConnectionState read get_State;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.PlayToConnection,Windows.Media.PlayTo.PlayToConnectionStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionStateChangedEventArgs>
  // External
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionStateChangedEventArgs = interface(IUnknown)
  ['{DEF77C1C-9363-5B47-B9F8-A236C50D372E}']
    procedure Invoke(sender: PlayTo_IPlayToConnection; args: PlayTo_IPlayToConnectionStateChangedEventArgs); safecall;
  end;

  // Windows.Media.PlayTo.IPlayToConnectionStateChangedEventArgs
  // External
  PlayTo_IPlayToConnectionStateChangedEventArgs = interface(IInspectable)
  ['{68C4B50F-0C20-4980-8602-58C62238D423}']
    function get_PreviousState: PlayTo_PlayToConnectionState; safecall;
    function get_CurrentState: PlayTo_PlayToConnectionState; safecall;
    property CurrentState: PlayTo_PlayToConnectionState read get_CurrentState;
    property PreviousState: PlayTo_PlayToConnectionState read get_PreviousState;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.PlayToConnection,Windows.Media.PlayTo.PlayToConnectionTransferredEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionTransferredEventArgs>
  // External
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionTransferredEventArgs = interface(IUnknown)
  ['{7278E7F2-0360-5571-8C3E-EA032767C473}']
    procedure Invoke(sender: PlayTo_IPlayToConnection; args: PlayTo_IPlayToConnectionTransferredEventArgs); safecall;
  end;

  // Windows.Media.PlayTo.IPlayToConnectionTransferredEventArgs
  // External
  PlayTo_IPlayToConnectionTransferredEventArgs = interface(IInspectable)
  ['{FAE3193A-0683-47D9-8DF0-18CBB48984D8}']
    function get_PreviousSource: PlayTo_IPlayToSource; safecall;
    function get_CurrentSource: PlayTo_IPlayToSource; safecall;
    property CurrentSource: PlayTo_IPlayToSource read get_CurrentSource;
    property PreviousSource: PlayTo_IPlayToSource read get_PreviousSource;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.PlayToConnection,Windows.Media.PlayTo.PlayToConnectionErrorEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.PlayTo.IPlayToConnection,Windows.Media.PlayTo.IPlayToConnectionErrorEventArgs>
  // External
  TypedEventHandler_2__PlayTo_IPlayToConnection__PlayTo_IPlayToConnectionErrorEventArgs = interface(IUnknown)
  ['{8F599F3D-3655-5993-A119-741EC4EE6E42}']
    procedure Invoke(sender: PlayTo_IPlayToConnection; args: PlayTo_IPlayToConnectionErrorEventArgs); safecall;
  end;

  // Windows.Media.PlayTo.IPlayToConnectionErrorEventArgs
  // External
  PlayTo_IPlayToConnectionErrorEventArgs = interface(IInspectable)
  ['{BF5EADA6-88E6-445F-9D40-D9B9F8939896}']
    function get_Code: PlayTo_PlayToConnectionError; safecall;
    function get_Message: HSTRING; safecall;
    property Code: PlayTo_PlayToConnectionError read get_Code;
    property &Message: HSTRING read get_Message;
  end;

  // Windows.Media.Protection.IMediaProtectionManager
  // External
  Protection_IMediaProtectionManager = interface(IInspectable)
  ['{45694947-C741-434B-A79E-474C12D93D2F}']
    function add_ServiceRequested(handler: Protection_ServiceRequestedEventHandler): EventRegistrationToken; safecall;
    procedure remove_ServiceRequested(cookie: EventRegistrationToken); safecall;
    function add_RebootNeeded(handler: Protection_RebootNeededEventHandler): EventRegistrationToken; safecall;
    procedure remove_RebootNeeded(cookie: EventRegistrationToken); safecall;
    function add_ComponentLoadFailed(handler: Protection_ComponentLoadFailedEventHandler): EventRegistrationToken; safecall;
    procedure remove_ComponentLoadFailed(cookie: EventRegistrationToken); safecall;
    function get_Properties: IPropertySet; safecall;
    property Properties: IPropertySet read get_Properties;
  end;

  // Windows.Media.Protection.ServiceRequestedEventHandler
  // External
  Protection_ServiceRequestedEventHandler = interface(IUnknown)
  ['{D2D690BA-CAC9-48E1-95C0-D38495A84055}']
    procedure Invoke(sender: Protection_IMediaProtectionManager; e: Protection_IServiceRequestedEventArgs); safecall;
  end;

  // Windows.Media.Protection.IServiceRequestedEventArgs
  // External
  Protection_IServiceRequestedEventArgs = interface(IInspectable)
  ['{34283BAF-ABB4-4FC1-BD89-93F106573A49}']
    function get_Request: Protection_IMediaProtectionServiceRequest; safecall;
    function get_Completion: Protection_IMediaProtectionServiceCompletion; safecall;
    property Completion: Protection_IMediaProtectionServiceCompletion read get_Completion;
    property Request: Protection_IMediaProtectionServiceRequest read get_Request;
  end;

  // Windows.Media.Protection.IMediaProtectionServiceRequest
  // External
  Protection_IMediaProtectionServiceRequest = interface(IInspectable)
  ['{B1DE0EA6-2094-478D-87A4-8B95200F85C6}']
    function get_ProtectionSystem: TGuid; safecall;
    function get_Type: TGuid; safecall;
    property ProtectionSystem: TGuid read get_ProtectionSystem;
    property &Type: TGuid read get_Type;
  end;

  // Windows.Media.Protection.IMediaProtectionServiceCompletion
  // External
  Protection_IMediaProtectionServiceCompletion = interface(IInspectable)
  ['{8B5CCA18-CFD5-44EE-A2ED-DF76010C14B5}']
    procedure Complete(success: Boolean); safecall;
  end;

  // Windows.Media.Protection.RebootNeededEventHandler
  // External
  Protection_RebootNeededEventHandler = interface(IUnknown)
  ['{64E12A45-973B-4A3A-B260-91898A49A82C}']
    procedure Invoke(sender: Protection_IMediaProtectionManager); safecall;
  end;

  // Windows.Media.Protection.ComponentLoadFailedEventHandler
  // External
  Protection_ComponentLoadFailedEventHandler = interface(IUnknown)
  ['{95DA643C-6DB9-424B-86CA-091AF432081C}']
    procedure Invoke(sender: Protection_IMediaProtectionManager; e: Protection_IComponentLoadFailedEventArgs); safecall;
  end;

  // Windows.Media.Protection.IComponentLoadFailedEventArgs
  // External
  Protection_IComponentLoadFailedEventArgs = interface(IInspectable)
  ['{95972E93-7746-417E-8495-F031BBC5862C}']
    function get_Information: Protection_IRevocationAndRenewalInformation; safecall;
    function get_Completion: Protection_IMediaProtectionServiceCompletion; safecall;
    property Completion: Protection_IMediaProtectionServiceCompletion read get_Completion;
    property Information: Protection_IRevocationAndRenewalInformation read get_Information;
  end;

  // Windows.Media.Protection.IRevocationAndRenewalInformation
  // External
  Protection_IRevocationAndRenewalInformation = interface(IInspectable)
  ['{F3A1937B-2501-439E-A6E7-6FC95E175FCF}']
    function get_Items: IVector_1__Protection_IRevocationAndRenewalItem; safecall;
    property Items: IVector_1__Protection_IRevocationAndRenewalItem read get_Items;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Media.Protection.RevocationAndRenewalItem>
  // Windows.Foundation.Collections.IVector`1<Windows.Media.Protection.IRevocationAndRenewalItem>
  // External
  IVector_1__Protection_IRevocationAndRenewalItem = interface(IInspectable)
  ['{3623CC0C-C765-57FB-967D-C7CB6097BD78}']
    function GetAt(index: Cardinal): Protection_IRevocationAndRenewalItem; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Protection_IRevocationAndRenewalItem; safecall;
    function IndexOf(value: Protection_IRevocationAndRenewalItem; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Protection_IRevocationAndRenewalItem); safecall;
    procedure InsertAt(index: Cardinal; value: Protection_IRevocationAndRenewalItem); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Protection_IRevocationAndRenewalItem); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PProtection_IRevocationAndRenewalItem): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PProtection_IRevocationAndRenewalItem); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Media.Protection.IRevocationAndRenewalItem
  // External
  Protection_IRevocationAndRenewalItem = interface(IInspectable)
  ['{3099C20C-3CF0-49EA-902D-CAF32D2DDE2C}']
    function get_Reasons: Protection_RevocationAndRenewalReasons; safecall;
    function get_HeaderHash: HSTRING; safecall;
    function get_PublicKeyHash: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_RenewalId: HSTRING; safecall;
    property HeaderHash: HSTRING read get_HeaderHash;
    property Name: HSTRING read get_Name;
    property PublicKeyHash: HSTRING read get_PublicKeyHash;
    property Reasons: Protection_RevocationAndRenewalReasons read get_Reasons;
    property RenewalId: HSTRING read get_RenewalId;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Media.Protection.IRevocationAndRenewalItem>
  // External
  IVectorView_1__Protection_IRevocationAndRenewalItem = interface(IInspectable)
  ['{D4BED0AA-0377-58AB-829C-201E1283ABBE}']
    function GetAt(index: Cardinal): Protection_IRevocationAndRenewalItem; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Protection_IRevocationAndRenewalItem; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PProtection_IRevocationAndRenewalItem): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.Media.TimelineMarkerRoutedEventHandler
  // External
  TimelineMarkerRoutedEventHandler = interface(IUnknown)
  ['{72E2FA9C-6DEA-4CBE-A159-06CE95FBECED}']
    procedure Invoke(sender: IInspectable; e: ITimelineMarkerRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.ITimelineMarkerRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_TimelineMarkerRoutedEventArgs)]
  ITimelineMarkerRoutedEventArgs = interface(IInspectable)
  ['{7C3B3EF3-2C88-4D9C-99B6-46CDBD48D4C1}']
    function get_Marker: ITimelineMarker; safecall;
    procedure put_Marker(value: ITimelineMarker); safecall;
    property Marker: ITimelineMarker read get_Marker write put_Marker;
  end;

  // Windows.UI.Xaml.Media.RateChangedRoutedEventHandler
  // External
  RateChangedRoutedEventHandler = interface(IUnknown)
  ['{08E9A257-AE05-489B-8839-28C6225D2349}']
    procedure Invoke(sender: IInspectable; e: IRateChangedRoutedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Media.IRateChangedRoutedEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Media_RateChangedRoutedEventArgs)]
  IRateChangedRoutedEventArgs = interface(IInspectable)
  ['{9016AA6F-3CA8-4C80-8E2F-8851A68F131F}']
  end;

  // DualAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.UI.Xaml.UIElement>
  // Windows.Foundation.Collections.IIterable`1<Windows.UI.Xaml.IUIElement>
  // External
  IIterable_1__IUIElement = interface(IInspectable)
  ['{42E26AE1-D357-57E8-BB48-F75C9FF69D91}']
    function First: IIterator_1__IUIElement; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.UI.Xaml.UIElement>
  // Windows.Foundation.Collections.IIterator`1<Windows.UI.Xaml.IUIElement>
  // External
  IIterator_1__IUIElement = interface(IInspectable)
  ['{1D1F9D60-D53B-57F7-B144-8F7C487846E8}']
    function get_Current: IUIElement; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIUIElement): Cardinal; safecall;
    property Current: IUIElement read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IListViewBase
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_ListViewBase)]
  IListViewBase = interface(IInspectable)
  ['{3D0813BA-6890-4537-BFE5-796D9458EDD6}']
    function get_SelectedItems: IVector_1__IInspectable; safecall;
    function get_SelectionMode: ListViewSelectionMode; safecall;
    procedure put_SelectionMode(value: ListViewSelectionMode); safecall;
    function get_IsSwipeEnabled: Boolean; safecall;
    procedure put_IsSwipeEnabled(value: Boolean); safecall;
    function get_CanDragItems: Boolean; safecall;
    procedure put_CanDragItems(value: Boolean); safecall;
    function get_CanReorderItems: Boolean; safecall;
    procedure put_CanReorderItems(value: Boolean); safecall;
    function get_IsItemClickEnabled: Boolean; safecall;
    procedure put_IsItemClickEnabled(value: Boolean); safecall;
    function get_DataFetchSize: Double; safecall;
    procedure put_DataFetchSize(value: Double); safecall;
    function get_IncrementalLoadingThreshold: Double; safecall;
    procedure put_IncrementalLoadingThreshold(value: Double); safecall;
    function get_IncrementalLoadingTrigger: IncrementalLoadingTrigger; safecall;
    procedure put_IncrementalLoadingTrigger(value: IncrementalLoadingTrigger); safecall;
    function add_ItemClick(handler: ItemClickEventHandler): EventRegistrationToken; safecall;
    procedure remove_ItemClick(token: EventRegistrationToken); safecall;
    function add_DragItemsStarting(handler: DragItemsStartingEventHandler): EventRegistrationToken; safecall;
    procedure remove_DragItemsStarting(token: EventRegistrationToken); safecall;
    procedure ScrollIntoView(item: IInspectable); overload; safecall;
    procedure SelectAll; safecall;
    function LoadMoreItemsAsync: IAsyncOperation_1__Data_LoadMoreItemsResult; safecall;
    procedure ScrollIntoView(item: IInspectable; alignment: ScrollIntoViewAlignment); overload; safecall;
    function get_Header: IInspectable; safecall;
    procedure put_Header(value: IInspectable); safecall;
    function get_HeaderTemplate: IDataTemplate; safecall;
    procedure put_HeaderTemplate(value: IDataTemplate); safecall;
    function get_HeaderTransitions: IVector_1__Animation_ITransition; safecall;
    procedure put_HeaderTransitions(value: IVector_1__Animation_ITransition); safecall;
    property CanDragItems: Boolean read get_CanDragItems write put_CanDragItems;
    property CanReorderItems: Boolean read get_CanReorderItems write put_CanReorderItems;
    property DataFetchSize: Double read get_DataFetchSize write put_DataFetchSize;
    property Header: IInspectable read get_Header write put_Header;
    property HeaderTemplate: IDataTemplate read get_HeaderTemplate write put_HeaderTemplate;
    property HeaderTransitions: IVector_1__Animation_ITransition read get_HeaderTransitions write put_HeaderTransitions;
    property IncrementalLoadingThreshold: Double read get_IncrementalLoadingThreshold write put_IncrementalLoadingThreshold;
    property IncrementalLoadingTrigger_: IncrementalLoadingTrigger read get_IncrementalLoadingTrigger write put_IncrementalLoadingTrigger;
    property IsItemClickEnabled: Boolean read get_IsItemClickEnabled write put_IsItemClickEnabled;
    property IsSwipeEnabled: Boolean read get_IsSwipeEnabled write put_IsSwipeEnabled;
    property SelectedItems: IVector_1__IInspectable read get_SelectedItems;
    property SelectionMode: ListViewSelectionMode read get_SelectionMode write put_SelectionMode;
  end;

  // Windows.Foundation.Collections.IVector`1<Object>
  // External
  IVector_1__IInspectable = interface(IInspectable)
  ['{B32BDCA4-5E52-5B27-BC5D-D66A1A268C2A}']
    function GetAt(index: Cardinal): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IInspectable; safecall;
    function IndexOf(value: IInspectable; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IInspectable); safecall;
    procedure InsertAt(index: Cardinal; value: IInspectable); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IInspectable); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIInspectable): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIInspectable); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Object>
  // External
  IVectorView_1__IInspectable = interface(IInspectable)
  ['{A6487363-B074-5C60-AB16-866DCE4EE54D}']
    function GetAt(index: Cardinal): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IInspectable; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIInspectable): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.UI.Xaml.Controls.ItemClickEventHandler
  // External
  ItemClickEventHandler = interface(IUnknown)
  ['{3DF6D14E-E18A-4A75-9395-627C5F3CD489}']
    procedure Invoke(sender: IInspectable; e: IItemClickEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IItemClickEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_ItemClickEventArgs)]
  IItemClickEventArgs = interface(IInspectable)
  ['{9C314242-F29A-494D-A3A5-D4C7B2A46852}']
    function get_ClickedItem: IInspectable; safecall;
    property ClickedItem: IInspectable read get_ClickedItem;
  end;

  // Windows.UI.Xaml.Controls.DragItemsStartingEventHandler
  // External
  DragItemsStartingEventHandler = interface(IUnknown)
  ['{3AAEAB4C-14CB-4434-BECC-88A8585C2F89}']
    procedure Invoke(sender: IInspectable; e: IDragItemsStartingEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IDragItemsStartingEventArgs
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_DragItemsStartingEventArgs)]
  IDragItemsStartingEventArgs = interface(IInspectable)
  ['{71CF215C-DAED-4783-AA11-DC574D2713E9}']
    function get_Cancel: Boolean; safecall;
    procedure put_Cancel(value: Boolean); safecall;
    function get_Items: IVector_1__IInspectable; safecall;
    function get_Data: IDataPackage; safecall;
    property Cancel: Boolean read get_Cancel write put_Cancel;
    property Data: IDataPackage read get_Data;
    property Items: IVector_1__IInspectable read get_Items;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IUIElementWeakCollection
  [WinRTClassNameAttribute(SWindows_UI_Xaml_UIElementWeakCollection)]
  IUIElementWeakCollection = interface(IInspectable)
  ['{10341223-E66D-519E-ACF8-556BD244EAC3}']
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.UI.Xaml.Controls.Primitives.IPopup>
  // External
  IVectorView_1__Primitives_IPopup = interface(IInspectable)
  ['{722B1286-A012-51AD-BD6E-CBF8C42FCFAA}']
    function GetAt(index: Cardinal): Primitives_IPopup; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Primitives_IPopup; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPrimitives_IPopup): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.Primitives.IPopup
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_Primitives_Popup)]
  Primitives_IPopup = interface(IInspectable)
  ['{62418240-E6D3-4705-A1DC-39156456EE29}']
    function get_Child: IUIElement; safecall;
    procedure put_Child(value: IUIElement); safecall;
    function get_IsOpen: Boolean; safecall;
    procedure put_IsOpen(value: Boolean); safecall;
    function get_HorizontalOffset: Double; safecall;
    procedure put_HorizontalOffset(value: Double); safecall;
    function get_VerticalOffset: Double; safecall;
    procedure put_VerticalOffset(value: Double); safecall;
    function get_ChildTransitions: IVector_1__Animation_ITransition; safecall;
    procedure put_ChildTransitions(value: IVector_1__Animation_ITransition); safecall;
    function get_IsLightDismissEnabled: Boolean; safecall;
    procedure put_IsLightDismissEnabled(value: Boolean); safecall;
    function add_Opened(handler: EventHandler_1__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Opened(token: EventRegistrationToken); safecall;
    function add_Closed(handler: EventHandler_1__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Closed(token: EventRegistrationToken); safecall;
    property Child: IUIElement read get_Child write put_Child;
    property ChildTransitions: IVector_1__Animation_ITransition read get_ChildTransitions write put_ChildTransitions;
    property HorizontalOffset: Double read get_HorizontalOffset write put_HorizontalOffset;
    property IsLightDismissEnabled: Boolean read get_IsLightDismissEnabled write put_IsLightDismissEnabled;
    property IsOpen: Boolean read get_IsOpen write put_IsOpen;
    property VerticalOffset: Double read get_VerticalOffset write put_VerticalOffset;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.IWindow
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Window)]
  IWindow = interface(IInspectable)
  ['{3276167D-C9F6-462D-9DE2-AE4C1FD8C2E5}']
    function get_Bounds: TRectF; safecall;
    function get_Visible: Boolean; safecall;
    function get_Content: IUIElement; safecall;
    procedure put_Content(value: IUIElement); safecall;
    function get_CoreWindow: ICoreWindow; safecall;
    function get_Dispatcher: ICoreDispatcher; safecall;
    function add_Activated(handler: WindowActivatedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Activated(token: EventRegistrationToken); safecall;
    function add_Closed(handler: WindowClosedEventHandler): EventRegistrationToken; safecall;
    procedure remove_Closed(token: EventRegistrationToken); safecall;
    function add_SizeChanged(handler: WindowSizeChangedEventHandler): EventRegistrationToken; safecall;
    procedure remove_SizeChanged(token: EventRegistrationToken); safecall;
    function add_VisibilityChanged(handler: WindowVisibilityChangedEventHandler): EventRegistrationToken; safecall;
    procedure remove_VisibilityChanged(token: EventRegistrationToken); safecall;
    procedure Activate; safecall;
    procedure Close; safecall;
    property Bounds: TRectF read get_Bounds;
    property Content: IUIElement read get_Content write put_Content;
    property CoreWindow: ICoreWindow read get_CoreWindow;
    property Dispatcher: ICoreDispatcher read get_Dispatcher;
    property Visible: Boolean read get_Visible;
  end;

  // Windows.UI.Xaml.WindowActivatedEventHandler
  // External
  WindowActivatedEventHandler = interface(IUnknown)
  ['{18026348-8619-4C7B-B534-CED45D9DE219}']
    procedure Invoke(sender: IInspectable; e: IWindowActivatedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.WindowClosedEventHandler
  // External
  WindowClosedEventHandler = interface(IUnknown)
  ['{0DB89161-20D7-45DF-9122-BA89576703BA}']
    procedure Invoke(sender: IInspectable; e: ICoreWindowEventArgs); safecall;
  end;

  // Windows.UI.Xaml.WindowSizeChangedEventHandler
  // External
  WindowSizeChangedEventHandler = interface(IUnknown)
  ['{5C21C742-2CED-4FD9-BA38-7118D40E966B}']
    procedure Invoke(sender: IInspectable; e: IWindowSizeChangedEventArgs); safecall;
  end;

  // Windows.UI.Xaml.WindowVisibilityChangedEventHandler
  // External
  WindowVisibilityChangedEventHandler = interface(IUnknown)
  ['{10406AD6-B090-4A4A-B2AD-D682DF27130F}']
    procedure Invoke(sender: IInspectable; e: IVisibilityChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // Windows.UI.Xaml.Controls.IMediaTransportControls
  [WinRTClassNameAttribute(SWindows_UI_Xaml_Controls_MediaTransportControls)]
  IMediaTransportControls = interface(IInspectable)
  ['{D6F69E7D-0825-49A9-9FCE-5586D8694F0C}']
    function get_IsFullWindowButtonVisible: Boolean; safecall;
    procedure put_IsFullWindowButtonVisible(value: Boolean); safecall;
    function get_IsFullWindowEnabled: Boolean; safecall;
    procedure put_IsFullWindowEnabled(value: Boolean); safecall;
    function get_IsZoomButtonVisible: Boolean; safecall;
    procedure put_IsZoomButtonVisible(value: Boolean); safecall;
    function get_IsZoomEnabled: Boolean; safecall;
    procedure put_IsZoomEnabled(value: Boolean); safecall;
    function get_IsFastForwardButtonVisible: Boolean; safecall;
    procedure put_IsFastForwardButtonVisible(value: Boolean); safecall;
    function get_IsFastForwardEnabled: Boolean; safecall;
    procedure put_IsFastForwardEnabled(value: Boolean); safecall;
    function get_IsFastRewindButtonVisible: Boolean; safecall;
    procedure put_IsFastRewindButtonVisible(value: Boolean); safecall;
    function get_IsFastRewindEnabled: Boolean; safecall;
    procedure put_IsFastRewindEnabled(value: Boolean); safecall;
    function get_IsStopButtonVisible: Boolean; safecall;
    procedure put_IsStopButtonVisible(value: Boolean); safecall;
    function get_IsStopEnabled: Boolean; safecall;
    procedure put_IsStopEnabled(value: Boolean); safecall;
    function get_IsVolumeButtonVisible: Boolean; safecall;
    procedure put_IsVolumeButtonVisible(value: Boolean); safecall;
    function get_IsVolumeEnabled: Boolean; safecall;
    procedure put_IsVolumeEnabled(value: Boolean); safecall;
    function get_IsPlaybackRateButtonVisible: Boolean; safecall;
    procedure put_IsPlaybackRateButtonVisible(value: Boolean); safecall;
    function get_IsPlaybackRateEnabled: Boolean; safecall;
    procedure put_IsPlaybackRateEnabled(value: Boolean); safecall;
    function get_IsSeekBarVisible: Boolean; safecall;
    procedure put_IsSeekBarVisible(value: Boolean); safecall;
    function get_IsSeekEnabled: Boolean; safecall;
    procedure put_IsSeekEnabled(value: Boolean); safecall;
    function get_IsCompact: Boolean; safecall;
    procedure put_IsCompact(value: Boolean); safecall;
    property IsCompact: Boolean read get_IsCompact write put_IsCompact;
    property IsFastForwardButtonVisible: Boolean read get_IsFastForwardButtonVisible write put_IsFastForwardButtonVisible;
    property IsFastForwardEnabled: Boolean read get_IsFastForwardEnabled write put_IsFastForwardEnabled;
    property IsFastRewindButtonVisible: Boolean read get_IsFastRewindButtonVisible write put_IsFastRewindButtonVisible;
    property IsFastRewindEnabled: Boolean read get_IsFastRewindEnabled write put_IsFastRewindEnabled;
    property IsFullWindowButtonVisible: Boolean read get_IsFullWindowButtonVisible write put_IsFullWindowButtonVisible;
    property IsFullWindowEnabled: Boolean read get_IsFullWindowEnabled write put_IsFullWindowEnabled;
    property IsPlaybackRateButtonVisible: Boolean read get_IsPlaybackRateButtonVisible write put_IsPlaybackRateButtonVisible;
    property IsPlaybackRateEnabled: Boolean read get_IsPlaybackRateEnabled write put_IsPlaybackRateEnabled;
    property IsSeekBarVisible: Boolean read get_IsSeekBarVisible write put_IsSeekBarVisible;
    property IsSeekEnabled: Boolean read get_IsSeekEnabled write put_IsSeekEnabled;
    property IsStopButtonVisible: Boolean read get_IsStopButtonVisible write put_IsStopButtonVisible;
    property IsStopEnabled: Boolean read get_IsStopEnabled write put_IsStopEnabled;
    property IsVolumeButtonVisible: Boolean read get_IsVolumeButtonVisible write put_IsVolumeButtonVisible;
    property IsVolumeEnabled: Boolean read get_IsVolumeEnabled write put_IsVolumeEnabled;
    property IsZoomButtonVisible: Boolean read get_IsZoomButtonVisible write put_IsZoomButtonVisible;
    property IsZoomEnabled: Boolean read get_IsZoomEnabled write put_IsZoomEnabled;
  end;

  // Windows.Foundation.IReference`1<Windows.Foundation.Point>
  // External
  IReference_1__Point = interface(IInspectable)
  ['{84F14C22-A00A-5272-8D3D-82112E66DF00}']
    function get_Value: TPointF; safecall;
    property Value: TPointF read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.Foundation.Rect>
  // External
  IReference_1__Rect = interface(IInspectable)
  ['{80423F11-054F-5EAC-AFD3-63B6CE15E77B}']
    function get_Value: TRectF; safecall;
    property Value: TRectF read get_Value;
  end;

  // DualAPI Interface
  // Windows.Graphics.Imaging.ISoftwareBitmap
  [WinRTClassNameAttribute(SWindows_Graphics_Imaging_SoftwareBitmap)]
  Imaging_ISoftwareBitmap = interface(IInspectable)
  ['{689E0708-7EEF-483F-963F-DA938818E073}']
    function get_BitmapPixelFormat: Imaging_BitmapPixelFormat; safecall;
    function get_BitmapAlphaMode: Imaging_BitmapAlphaMode; safecall;
    function get_PixelWidth: Integer; safecall;
    function get_PixelHeight: Integer; safecall;
    function get_IsReadOnly: Boolean; safecall;
    procedure put_DpiX(value: Double); safecall;
    function get_DpiX: Double; safecall;
    procedure put_DpiY(value: Double); safecall;
    function get_DpiY: Double; safecall;
    function LockBuffer(mode: Imaging_BitmapBufferAccessMode): Imaging_IBitmapBuffer; safecall;
    procedure CopyTo(bitmap: Imaging_ISoftwareBitmap); safecall;
    procedure CopyFromBuffer(buffer: IBuffer); safecall;
    procedure CopyToBuffer(buffer: IBuffer); safecall;
    function GetReadOnlyView: Imaging_ISoftwareBitmap; safecall;
    property BitmapAlphaMode: Imaging_BitmapAlphaMode read get_BitmapAlphaMode;
    property BitmapPixelFormat: Imaging_BitmapPixelFormat read get_BitmapPixelFormat;
    property DpiX: Double read get_DpiX write put_DpiX;
    property DpiY: Double read get_DpiY write put_DpiY;
    property IsReadOnly: Boolean read get_IsReadOnly;
    property PixelHeight: Integer read get_PixelHeight;
    property PixelWidth: Integer read get_PixelWidth;
  end;

  // Windows.Graphics.Imaging.IBitmapBuffer
  // External
  Imaging_IBitmapBuffer = interface(IInspectable)
  ['{A53E04C4-399C-438C-B28F-A63A6B83D1A1}']
    function GetPlaneCount: Integer; safecall;
    function GetPlaneDescription(index: Integer): Imaging_BitmapPlaneDescription; safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.DataTransfer.DataPackageOperation>
  // External
  IAsyncOperation_1__DataPackageOperation = interface(IInspectable)
  ['{EB24761C-33D8-53EE-8C43-AC54159152D5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__DataPackageOperation); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__DataPackageOperation; safecall;
    function GetResults: DataPackageOperation; safecall;
    property Completed: AsyncOperationCompletedHandler_1__DataPackageOperation read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.DataTransfer.DataPackageOperation>
  // External
  AsyncOperationCompletedHandler_1__DataPackageOperation = interface(IUnknown)
  ['{462B2493-6766-58DE-A1BB-329D86A045D2}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__DataPackageOperation; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IObservableVector`1<Object>
  // External
  IObservableVector_1__IInspectable = interface(IInspectable)
  ['{7B81C56A-0985-518D-BAA9-0DA9AE009F65}']
    function add_VectorChanged(vhnd: VectorChangedEventHandler_1__IInspectable): EventRegistrationToken; safecall;
    procedure remove_VectorChanged(token: EventRegistrationToken); safecall;
  end;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Object>
  // External
  VectorChangedEventHandler_1__IInspectable = interface(IUnknown)
  ['{B423A801-D35E-56B9-813B-00889536CB98}']
    procedure Invoke(sender: IObservableVector_1__IInspectable; event: IVectorChangedEventArgs); safecall;
  end;

  // Windows.Media.Casting.ICastingSource
  // External
  Casting_ICastingSource = interface(IInspectable)
  ['{F429EA72-3467-47E6-A027-522923E9D727}']
    function get_PreferredSourceUri: IUriRuntimeClass; safecall;
    procedure put_PreferredSourceUri(value: IUriRuntimeClass); safecall;
    property PreferredSourceUri: IUriRuntimeClass read get_PreferredSourceUri write put_PreferredSourceUri;
  end;

  // DualAPI Interface
  // Windows.Media.Playback.IMediaPlaybackSource
  // External
  Playback_IMediaPlaybackSource = interface(IInspectable)
  ['{EF9DC2BC-9317-4696-B051-2BAD643177B5}']
  end;

  // DualAPI Interface
  // Windows.Media.Playback.IMediaPlayer
  [WinRTClassNameAttribute(SWindows_Media_Playback_MediaPlayer)]
  Playback_IMediaPlayer = interface(IInspectable)
  ['{381A83CB-6FFF-499B-8D64-2885DFC1249E}']
    function get_AutoPlay: Boolean; safecall;
    procedure put_AutoPlay(value: Boolean); safecall;
    function get_NaturalDuration: TimeSpan; safecall;
    function get_Position: TimeSpan; safecall;
    procedure put_Position(value: TimeSpan); safecall;
    function get_BufferingProgress: Double; safecall;
    function get_CurrentState: Playback_MediaPlayerState; safecall;
    function get_CanSeek: Boolean; safecall;
    function get_CanPause: Boolean; safecall;
    function get_IsLoopingEnabled: Boolean; safecall;
    procedure put_IsLoopingEnabled(value: Boolean); safecall;
    function get_IsProtected: Boolean; safecall;
    function get_IsMuted: Boolean; safecall;
    procedure put_IsMuted(value: Boolean); safecall;
    function get_PlaybackRate: Double; safecall;
    procedure put_PlaybackRate(value: Double); safecall;
    function get_Volume: Double; safecall;
    procedure put_Volume(value: Double); safecall;
    function get_PlaybackMediaMarkers: Playback_IPlaybackMediaMarkerSequence; safecall;
    function add_MediaOpened(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_MediaOpened(token: EventRegistrationToken); safecall;
    function add_MediaEnded(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_MediaEnded(token: EventRegistrationToken); safecall;
    function add_MediaFailed(value: TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerFailedEventArgs): EventRegistrationToken; safecall;
    procedure remove_MediaFailed(token: EventRegistrationToken); safecall;
    function add_CurrentStateChanged(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_CurrentStateChanged(token: EventRegistrationToken); safecall;
    function add_PlaybackMediaMarkerReached(value: TypedEventHandler_2__Playback_IMediaPlayer__Playback_IPlaybackMediaMarkerReachedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PlaybackMediaMarkerReached(token: EventRegistrationToken); safecall;
    function add_MediaPlayerRateChanged(value: TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerRateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_MediaPlayerRateChanged(token: EventRegistrationToken); safecall;
    function add_VolumeChanged(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_VolumeChanged(token: EventRegistrationToken); safecall;
    function add_SeekCompleted(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_SeekCompleted(token: EventRegistrationToken); safecall;
    function add_BufferingStarted(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_BufferingStarted(token: EventRegistrationToken); safecall;
    function add_BufferingEnded(value: TypedEventHandler_2__Playback_IMediaPlayer__IInspectable): EventRegistrationToken; safecall;
    procedure remove_BufferingEnded(token: EventRegistrationToken); safecall;
    procedure Play; safecall;
    procedure Pause; safecall;
    procedure SetUriSource(value: IUriRuntimeClass); safecall;
    property AutoPlay: Boolean read get_AutoPlay write put_AutoPlay;
    property BufferingProgress: Double read get_BufferingProgress;
    property CanPause: Boolean read get_CanPause;
    property CanSeek: Boolean read get_CanSeek;
    property CurrentState: Playback_MediaPlayerState read get_CurrentState;
    property IsLoopingEnabled: Boolean read get_IsLoopingEnabled write put_IsLoopingEnabled;
    property IsMuted: Boolean read get_IsMuted write put_IsMuted;
    property IsProtected: Boolean read get_IsProtected;
    property NaturalDuration: TimeSpan read get_NaturalDuration;
    property PlaybackMediaMarkers: Playback_IPlaybackMediaMarkerSequence read get_PlaybackMediaMarkers;
    property PlaybackRate: Double read get_PlaybackRate write put_PlaybackRate;
    property Position: TimeSpan read get_Position write put_Position;
    property Volume: Double read get_Volume write put_Volume;
  end;

  // Windows.Media.Playback.IPlaybackMediaMarkerSequence
  // External
  Playback_IPlaybackMediaMarkerSequence = interface(IInspectable)
  ['{F2810CEE-638B-46CF-8817-1D111FE9D8C4}']
    function get_Size: Cardinal; safecall;
    procedure Insert(value: Playback_IPlaybackMediaMarker); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Media.Playback.IPlaybackMediaMarker
  // External
  Playback_IPlaybackMediaMarker = interface(IInspectable)
  ['{C4D22F5C-3C1C-4444-B6B9-778B0422D41A}']
    function get_Time: TimeSpan; safecall;
    function get_MediaMarkerType: HSTRING; safecall;
    function get_Text: HSTRING; safecall;
    property MediaMarkerType: HSTRING read get_MediaMarkerType;
    property Text: HSTRING read get_Text;
    property Time: TimeSpan read get_Time;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.MediaPlayer,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Object>
  // External
  TypedEventHandler_2__Playback_IMediaPlayer__IInspectable = interface(IUnknown)
  ['{F1A6A51E-D078-5C40-BA3F-348870BA5C87}']
    procedure Invoke(sender: Playback_IMediaPlayer; args: IInspectable); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.MediaPlayer,Windows.Media.Playback.MediaPlayerFailedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IMediaPlayerFailedEventArgs>
  // External
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerFailedEventArgs = interface(IUnknown)
  ['{362C45A7-3A0A-5E27-99CE-CFF6D1B770E1}']
    procedure Invoke(sender: Playback_IMediaPlayer; args: Playback_IMediaPlayerFailedEventArgs); safecall;
  end;

  // Windows.Media.Playback.IMediaPlayerFailedEventArgs
  // External
  Playback_IMediaPlayerFailedEventArgs = interface(IInspectable)
  ['{2744E9B9-A7E3-4F16-BAC4-7914EBC08301}']
    function get_Error: Playback_MediaPlayerError; safecall;
    function get_ExtendedErrorCode: HRESULT; safecall;
    function get_ErrorMessage: HSTRING; safecall;
    property Error: Playback_MediaPlayerError read get_Error;
    property ErrorMessage: HSTRING read get_ErrorMessage;
    property ExtendedErrorCode: HRESULT read get_ExtendedErrorCode;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.MediaPlayer,Windows.Media.Playback.PlaybackMediaMarkerReachedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IPlaybackMediaMarkerReachedEventArgs>
  // External
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IPlaybackMediaMarkerReachedEventArgs = interface(IUnknown)
  ['{67A4F43C-C254-57F0-A39D-A475A342D21D}']
    procedure Invoke(sender: Playback_IMediaPlayer; args: Playback_IPlaybackMediaMarkerReachedEventArgs); safecall;
  end;

  // Windows.Media.Playback.IPlaybackMediaMarkerReachedEventArgs
  // External
  Playback_IPlaybackMediaMarkerReachedEventArgs = interface(IInspectable)
  ['{578CD1B9-90E2-4E60-ABC4-8740B01F6196}']
    function get_PlaybackMediaMarker: Playback_IPlaybackMediaMarker; safecall;
    property PlaybackMediaMarker: Playback_IPlaybackMediaMarker read get_PlaybackMediaMarker;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.MediaPlayer,Windows.Media.Playback.MediaPlayerRateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Media.Playback.IMediaPlayer,Windows.Media.Playback.IMediaPlayerRateChangedEventArgs>
  // External
  TypedEventHandler_2__Playback_IMediaPlayer__Playback_IMediaPlayerRateChangedEventArgs = interface(IUnknown)
  ['{BA51D31A-5688-5D4D-AF42-122070B1EEFA}']
    procedure Invoke(sender: Playback_IMediaPlayer; args: Playback_IMediaPlayerRateChangedEventArgs); safecall;
  end;

  // Windows.Media.Playback.IMediaPlayerRateChangedEventArgs
  // External
  Playback_IMediaPlayerRateChangedEventArgs = interface(IInspectable)
  ['{40600D58-3B61-4BB2-989F-FC65608B6CAB}']
    function get_NewRate: Double; safecall;
    property NewRate: Double read get_NewRate;
  end;

  // Windows.Foundation.Collections.IVector`1<Int32>
  // External
  IVector_1__Integer = interface(IInspectable)
  ['{B939AF5B-B45D-5489-9149-61442C1905FE}']
    function GetAt(index: Cardinal): Integer; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Integer; safecall;
    function IndexOf(value: Integer; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Integer); safecall;
    procedure InsertAt(index: Cardinal; value: Integer); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Integer); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInteger): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PInteger); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Int32>
  // External
  IVectorView_1__Integer = interface(IInspectable)
  ['{8D720CDF-3934-5D3F-9A55-40E8063B086A}']
    function GetAt(index: Cardinal): Integer; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Integer; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInteger): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Resources.Core.ResourceContextLanguagesVectorView>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<String>>
  // External
  IAsyncOperation_1__IVectorView_1__HSTRING = interface(IInspectable)
  ['{A5EBA85C-5A7F-5486-B7BD-70904F388BB7}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING; safecall;
    function GetResults: IVectorView_1__HSTRING; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Resources.Core.ResourceContextLanguagesVectorView>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<String>>
  // External
  AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING = interface(IUnknown)
  ['{2127CC2C-B103-5411-BC76-6FABB9EED000}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__HSTRING; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.Collections.IVector`1<Single>
  // External
  IVector_1__Single = interface(IInspectable)
  ['{61CF693F-DB4C-579F-B905-5DD3D23CFD4D}']
    function GetAt(index: Cardinal): Single; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Single; safecall;
    function IndexOf(value: Single; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Single); safecall;
    procedure InsertAt(index: Cardinal; value: Single); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Single); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSingle): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PSingle); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Single>
  // External
  IVectorView_1__Single = interface(IInspectable)
  ['{7BCA64FD-150C-5D50-B56B-9F4F474C5930}']
    function GetAt(index: Cardinal): Single; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Single; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSingle): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IMapView`2<String,Double>
  // External
  IMapView_2__HSTRING__Double = interface(IInspectable)
  ['{D18743CF-94D6-54AC-9DA2-F4755FA8E4F2}']
    function Lookup(key: HSTRING): Double; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__Double; out second: IMapView_2__HSTRING__Double); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Object>>
  // External
  IAsyncOperation_1__IVectorView_1__IInspectable = interface(IInspectable)
  ['{D671D332-22AA-5597-8DCC-2459EAB49418}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable; safecall;
    function GetResults: IVectorView_1__IInspectable; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Object>>
  // External
  AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable = interface(IUnknown)
  ['{261A9D81-F58F-5283-9461-CA3E31C1123C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IInspectable; asyncStatus: AsyncStatus); safecall;
  end;

implementation

end.
