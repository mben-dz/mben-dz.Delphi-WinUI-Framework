{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Microsoft.UI;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Microsoft.CommonTypes,
  Winapi.UI,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Microsoft.UI.ClosableNotifierHandler
  ClosableNotifierHandler = interface;
  PClosableNotifierHandler = ^ClosableNotifierHandler;

  // Microsoft.UI.Content.IContentCoordinateConverter
  Content_IContentCoordinateConverter = interface;
  PContent_IContentCoordinateConverter = ^Content_IContentCoordinateConverter;

  // Microsoft.UI.Content.IContentSiteEnvironmentView
  Content_IContentSiteEnvironmentView = interface;
  PContent_IContentSiteEnvironmentView = ^Content_IContentSiteEnvironmentView;

  // Microsoft.UI.Content.IContentSiteView
  Content_IContentSiteView = interface;
  PContent_IContentSiteView = ^Content_IContentSiteView;

  // Microsoft.UI.Content.IContentEnvironmentSettingChangedEventArgs
  Content_IContentEnvironmentSettingChangedEventArgs = interface;
  PContent_IContentEnvironmentSettingChangedEventArgs = ^Content_IContentEnvironmentSettingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIslandEnvironment,Microsoft.UI.Content.IContentEnvironmentSettingChangedEventArgs>
  TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentSettingChangedEventArgs = interface;
  PTypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentSettingChangedEventArgs = ^TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentSettingChangedEventArgs;

  // Microsoft.UI.Content.IContentEnvironmentStateChangedEventArgs
  Content_IContentEnvironmentStateChangedEventArgs = interface;
  PContent_IContentEnvironmentStateChangedEventArgs = ^Content_IContentEnvironmentStateChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIslandEnvironment,Microsoft.UI.Content.IContentEnvironmentStateChangedEventArgs>
  TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentStateChangedEventArgs = interface;
  PTypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentStateChangedEventArgs = ^TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentStateChangedEventArgs;

  // Microsoft.UI.Content.IContentIslandEnvironment
  Content_IContentIslandEnvironment = interface;
  PContent_IContentIslandEnvironment = ^Content_IContentIslandEnvironment;

  // Microsoft.UI.Content.IContentDeferral
  Content_IContentDeferral = interface;
  PContent_IContentDeferral = ^Content_IContentDeferral;

  // Microsoft.UI.Content.IContentIslandAutomationProviderRequestedEventArgs
  Content_IContentIslandAutomationProviderRequestedEventArgs = interface;
  PContent_IContentIslandAutomationProviderRequestedEventArgs = ^Content_IContentIslandAutomationProviderRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIsland,Microsoft.UI.Content.IContentIslandAutomationProviderRequestedEventArgs>
  TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandAutomationProviderRequestedEventArgs = interface;
  PTypedEventHandler_2__Content_IContentIsland__Content_IContentIslandAutomationProviderRequestedEventArgs = ^TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandAutomationProviderRequestedEventArgs;

  // Microsoft.UI.Content.IContentIslandStateChangedEventArgs
  Content_IContentIslandStateChangedEventArgs = interface;
  PContent_IContentIslandStateChangedEventArgs = ^Content_IContentIslandStateChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIsland,Microsoft.UI.Content.IContentIslandStateChangedEventArgs>
  TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandStateChangedEventArgs = interface;
  PTypedEventHandler_2__Content_IContentIsland__Content_IContentIslandStateChangedEventArgs = ^TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandStateChangedEventArgs;

  // Microsoft.UI.Content.IContentIsland
  Content_IContentIsland = interface;
  PContent_IContentIsland = ^Content_IContentIsland;

  // Microsoft.UI.Content.IContentCoordinateConverterFactory
  Content_IContentCoordinateConverterFactory = interface;
  PContent_IContentCoordinateConverterFactory = ^Content_IContentCoordinateConverterFactory;

  // Microsoft.UI.Content.IContentIslandEnvironmentFactory
  Content_IContentIslandEnvironmentFactory = interface;
  PContent_IContentIslandEnvironmentFactory = ^Content_IContentIslandEnvironmentFactory;

  // Microsoft.UI.Content.IContentIslandFactory
  Content_IContentIslandFactory = interface;
  PContent_IContentIslandFactory = ^Content_IContentIslandFactory;

  // Windows.Foundation.IReference`1<Microsoft.UI.Content.ContentLayoutDirection>
  IReference_1__Content_ContentLayoutDirection = interface;
  PIReference_1__Content_ContentLayoutDirection = ^IReference_1__Content_ContentLayoutDirection;

  // Microsoft.UI.Content.IContentSiteEnvironmentFactory
  Content_IContentSiteEnvironmentFactory = interface;
  PContent_IContentSiteEnvironmentFactory = ^Content_IContentSiteEnvironmentFactory;

  // Microsoft.UI.Content.IContentSiteEnvironmentViewFactory
  Content_IContentSiteEnvironmentViewFactory = interface;
  PContent_IContentSiteEnvironmentViewFactory = ^Content_IContentSiteEnvironmentViewFactory;

  // Microsoft.UI.Content.IContentSiteFactory
  Content_IContentSiteFactory = interface;
  PContent_IContentSiteFactory = ^Content_IContentSiteFactory;

  // Microsoft.UI.Content.IContentSiteViewFactory
  Content_IContentSiteViewFactory = interface;
  PContent_IContentSiteViewFactory = ^Content_IContentSiteViewFactory;

  // Microsoft.UI.Content.IDesktopChildSiteBridge
  Content_IDesktopChildSiteBridge = interface;
  PContent_IDesktopChildSiteBridge = ^Content_IDesktopChildSiteBridge;

  // Microsoft.UI.Content.IDesktopSiteBridgeFactory
  Content_IDesktopSiteBridgeFactory = interface;
  PContent_IDesktopSiteBridgeFactory = ^Content_IDesktopSiteBridgeFactory;

  // Microsoft.UI.IColorHelper
  IColorHelper = interface;
  PIColorHelper = ^IColorHelper;

  // Microsoft.UI.IColorHelperStatics
  IColorHelperStatics = interface;
  PIColorHelperStatics = ^IColorHelperStatics;

  // Microsoft.UI.IColorHelperStatics2
  IColorHelperStatics2 = interface;
  PIColorHelperStatics2 = ^IColorHelperStatics2;

  // Microsoft.UI.IColors
  IColors = interface;
  PIColors = ^IColors;

  // Microsoft.UI.IColorsStatics
  IColorsStatics = interface;
  PIColorsStatics = ^IColorsStatics;

  // Microsoft.UI.Windowing.IAppWindowPresenter
  Windowing_IAppWindowPresenter = interface;
  PWindowing_IAppWindowPresenter = ^Windowing_IAppWindowPresenter;

  // Microsoft.UI.Windowing.IAppWindowTitleBar
  Windowing_IAppWindowTitleBar = interface;
  PWindowing_IAppWindowTitleBar = ^Windowing_IAppWindowTitleBar;

  // Microsoft.UI.Windowing.IDisplayArea
  Windowing_IDisplayArea = interface;
  PWindowing_IDisplayArea = ^Windowing_IDisplayArea;

  // Microsoft.UI.Windowing.IAppWindowChangedEventArgs
  Windowing_IAppWindowChangedEventArgs = interface;
  PWindowing_IAppWindowChangedEventArgs = ^Windowing_IAppWindowChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Microsoft.UI.Windowing.IAppWindowChangedEventArgs>
  TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowChangedEventArgs = interface;
  PTypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowChangedEventArgs = ^TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowChangedEventArgs;

  // Microsoft.UI.Windowing.IAppWindowClosingEventArgs
  Windowing_IAppWindowClosingEventArgs = interface;
  PWindowing_IAppWindowClosingEventArgs = ^Windowing_IAppWindowClosingEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Microsoft.UI.Windowing.IAppWindowClosingEventArgs>
  TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowClosingEventArgs = interface;
  PTypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowClosingEventArgs = ^TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowClosingEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Object>
  TypedEventHandler_2__Windowing_IAppWindow__IInspectable = interface;
  PTypedEventHandler_2__Windowing_IAppWindow__IInspectable = ^TypedEventHandler_2__Windowing_IAppWindow__IInspectable;

  // Microsoft.UI.Windowing.IAppWindow
  Windowing_IAppWindow = interface;
  PWindowing_IAppWindow = ^Windowing_IAppWindow;

  // Microsoft.UI.Windowing.IAppWindowPresenterFactory
  Windowing_IAppWindowPresenterFactory = interface;
  PWindowing_IAppWindowPresenterFactory = ^Windowing_IAppWindowPresenterFactory;

  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Windowing.IDisplayArea>
  IIterator_1__Windowing_IDisplayArea = interface;
  PIIterator_1__Windowing_IDisplayArea = ^IIterator_1__Windowing_IDisplayArea;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Windowing.IDisplayArea>
  IIterable_1__Windowing_IDisplayArea = interface;
  PIIterable_1__Windowing_IDisplayArea = ^IIterable_1__Windowing_IDisplayArea;

  // Windows.Foundation.Collections.IVectorView`1<Microsoft.UI.Windowing.IDisplayArea>
  IVectorView_1__Windowing_IDisplayArea = interface;
  PIVectorView_1__Windowing_IDisplayArea = ^IVectorView_1__Windowing_IDisplayArea;

  // Microsoft.UI Enums

  // Microsoft.UI.Content.ContentAutomationOptions
  Content_ContentAutomationOptions = (
    None = 0,
    FrameworkBased = 1,
    FragmentBased = 2
  );
  PContent_ContentAutomationOptions = ^Content_ContentAutomationOptions;

  // Microsoft.UI.Content.ContentCoordinateRoundingMode
  Content_ContentCoordinateRoundingMode = (
    Auto = 0,
    Floor = 1,
    Round = 2,
    Ceiling = 3
  );
  PContent_ContentCoordinateRoundingMode = ^Content_ContentCoordinateRoundingMode;

  // Microsoft.UI.Content.ContentLayoutDirection
  Content_ContentLayoutDirection = (
    LeftToRight = 0,
    RightToLeft = 1
  );
  PContent_ContentLayoutDirection = ^Content_ContentLayoutDirection;

  // Microsoft.UI.Content.ContentSizePolicy
  Content_ContentSizePolicy = (
    None = 0,
    ResizeContentToParentWindow = 1,
    ResizeParentWindowToContent = 2
  );
  PContent_ContentSizePolicy = ^Content_ContentSizePolicy;

  // Microsoft.UI.Windowing.AppWindowPresenterKind
  Windowing_AppWindowPresenterKind = (
    Default = 0,
    CompactOverlay = 1,
    FullScreen = 2,
    Overlapped = 3
  );
  PWindowing_AppWindowPresenterKind = ^Windowing_AppWindowPresenterKind;

  // Microsoft.UI.Windowing.CompactOverlaySize
  Windowing_CompactOverlaySize = (
    Small = 0,
    Medium = 1,
    Large = 2
  );
  PWindowing_CompactOverlaySize = ^Windowing_CompactOverlaySize;

  // Microsoft.UI.Windowing.DisplayAreaFallback
  Windowing_DisplayAreaFallback = (
    None = 0,
    Primary = 1,
    Nearest = 2
  );
  PWindowing_DisplayAreaFallback = ^Windowing_DisplayAreaFallback;

  // Microsoft.UI.Windowing.DisplayAreaWatcherStatus
  Windowing_DisplayAreaWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopping = 3,
    Stopped = 4,
    Aborted = 5
  );
  PWindowing_DisplayAreaWatcherStatus = ^Windowing_DisplayAreaWatcherStatus;

  // Microsoft.UI.Windowing.IconShowOptions
  Windowing_IconShowOptions = (
    ShowIconAndSystemMenu = 0,
    HideIconAndSystemMenu = 1
  );
  PWindowing_IconShowOptions = ^Windowing_IconShowOptions;

  // Microsoft.UI.Windowing.OverlappedPresenterState
  Windowing_OverlappedPresenterState = (
    Maximized = 0,
    Minimized = 1,
    Restored = 2
  );
  PWindowing_OverlappedPresenterState = ^Windowing_OverlappedPresenterState;

  // Microsoft.UI.Windowing.TitleBarHeightOption
  Windowing_TitleBarHeightOption = (
    Standard = 0,
    Tall = 1,
    Collapsed = 2
  );
  PWindowing_TitleBarHeightOption = ^Windowing_TitleBarHeightOption;

  // Microsoft.UI.Windowing.TitleBarTheme
  Windowing_TitleBarTheme = (
    Legacy = 0,
    UseDefaultAppMode = 1,
    Light = 2,
    Dark = 3
  );
  PWindowing_TitleBarTheme = ^Windowing_TitleBarTheme;

  // Microsoft.UI Records

  // Microsoft.UI.DisplayId
  DisplayId = record
    Value: UInt64;
  end;
  PDisplayId = ^DisplayId;

  // Microsoft.UI.IconId
  IconId = record
    Value: UInt64;
  end;
  PIconId = ^IconId;

  // Microsoft.UI.WindowId
  WindowId = record
    Value: UInt64;
  end;
  PWindowId = ^WindowId;

  // Microsoft.UI Interfaces

  // Microsoft.UI.ClosableNotifierHandler
  ClosableNotifierHandler = interface(IUnknown)
  ['{478CEC68-EA8E-52FC-87E2-C819DE000F92}']
    procedure Invoke; safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentCoordinateConverter
  Content_IContentCoordinateConverter = interface(IInspectable)
  ['{10A11230-5EB4-5840-A346-570F4A49040F}']
    function ConvertLocalToScreen(localPoint: TPointF): PointInt32; overload; safecall;
    function ConvertLocalToScreen(localPointsSize: Cardinal; localPoints: PPointF; resultSize: Cardinal; resultValue: PPointInt32): HRESULT; overload; stdcall;
    function ConvertLocalToScreen(localPointsSize: Cardinal; localPoints: PPointF; roundingMode: Content_ContentCoordinateRoundingMode; resultSize: Cardinal; resultValue: PPointInt32): HRESULT; overload; stdcall;
    function ConvertLocalToScreen(localRect: TRectF): RectInt32; overload; safecall;
    function ConvertScreenToLocal(screenPoint: PointInt32): TPointF; overload; safecall;
    function ConvertScreenToLocal(screenPointsSize: Cardinal; screenPoints: PPointInt32; resultSize: Cardinal; resultValue: PPointF): HRESULT; overload; stdcall;
    function ConvertScreenToLocal(screenRect: RectInt32): TRectF; overload; safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentSiteEnvironmentView
  Content_IContentSiteEnvironmentView = interface(IInspectable)
  ['{5B6FE420-0BB3-54DD-8589-786CF02E38F1}']
    function get_AppWindowId: WindowId; safecall;
    function get_DisplayId: DisplayId; safecall;
    property AppWindowId: WindowId read get_AppWindowId;
    property DisplayId_: DisplayId read get_DisplayId;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentSiteView
  Content_IContentSiteView = interface(IInspectable)
  ['{2D5D8DD5-358E-5B05-993B-B2666D1786B3}']
    function get_ActualSize: Numerics_Vector2; safecall;
    function get_ClientSize: SizeInt32; safecall;
    function get_CoordinateConverter: Content_IContentCoordinateConverter; safecall;
    function get_DispatcherQueue: IDispatcherQueue; safecall;
    function get_EnvironmentView: Content_IContentSiteEnvironmentView; safecall;
    function get_IsConnected: Boolean; safecall;
    function get_IsSiteEnabled: Boolean; safecall;
    function get_IsSiteVisible: Boolean; safecall;
    function get_LayoutDirection: Content_ContentLayoutDirection; safecall;
    function get_OverrideScale: Single; safecall;
    function get_ParentScale: Single; safecall;
    function get_RasterizationScale: Single; safecall;
    function get_RequestedSize: Numerics_Vector2; safecall;
    function get_ShouldApplyRasterizationScale: Boolean; safecall;
    property ActualSize: Numerics_Vector2 read get_ActualSize;
    property ClientSize: SizeInt32 read get_ClientSize;
    property CoordinateConverter: Content_IContentCoordinateConverter read get_CoordinateConverter;
    property DispatcherQueue: IDispatcherQueue read get_DispatcherQueue;
    property EnvironmentView: Content_IContentSiteEnvironmentView read get_EnvironmentView;
    property IsConnected: Boolean read get_IsConnected;
    property IsSiteEnabled: Boolean read get_IsSiteEnabled;
    property IsSiteVisible: Boolean read get_IsSiteVisible;
    property LayoutDirection: Content_ContentLayoutDirection read get_LayoutDirection;
    property OverrideScale: Single read get_OverrideScale;
    property ParentScale: Single read get_ParentScale;
    property RasterizationScale: Single read get_RasterizationScale;
    property RequestedSize: Numerics_Vector2 read get_RequestedSize;
    property ShouldApplyRasterizationScale: Boolean read get_ShouldApplyRasterizationScale;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentEnvironmentSettingChangedEventArgs
  Content_IContentEnvironmentSettingChangedEventArgs = interface(IInspectable)
  ['{76478051-FC80-5EEC-A3F3-62606ABE06B7}']
    function get_SettingName: HSTRING; safecall;
    property SettingName: HSTRING read get_SettingName;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.ContentIslandEnvironment,Microsoft.UI.Content.ContentEnvironmentSettingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIslandEnvironment,Microsoft.UI.Content.IContentEnvironmentSettingChangedEventArgs>
  TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentSettingChangedEventArgs = interface(IUnknown)
  ['{1AD20C79-1495-5501-AC8A-A38845E8F218}']
    procedure Invoke(sender: Content_IContentIslandEnvironment; args: Content_IContentEnvironmentSettingChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentEnvironmentStateChangedEventArgs
  Content_IContentEnvironmentStateChangedEventArgs = interface(IInspectable)
  ['{8970FA4F-10BA-5F67-970B-8C72BC009B67}']
    function get_DidAppWindowIdChange: Boolean; safecall;
    function get_DidDisplayIdChange: Boolean; safecall;
    property DidAppWindowIdChange: Boolean read get_DidAppWindowIdChange;
    property DidDisplayIdChange: Boolean read get_DidDisplayIdChange;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.ContentIslandEnvironment,Microsoft.UI.Content.ContentEnvironmentStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIslandEnvironment,Microsoft.UI.Content.IContentEnvironmentStateChangedEventArgs>
  TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentStateChangedEventArgs = interface(IUnknown)
  ['{C7742341-CFD5-5EF6-AB2A-D38C65B780B5}']
    procedure Invoke(sender: Content_IContentIslandEnvironment; args: Content_IContentEnvironmentStateChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentIslandEnvironment
  Content_IContentIslandEnvironment = interface(IInspectable)
  ['{C334236D-DA88-566D-811D-74AEF2EBA978}']
    function get_AppWindowId: WindowId; safecall;
    function get_DisplayId: DisplayId; safecall;
    function add_SettingChanged(handler: TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentSettingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SettingChanged(token: EventRegistrationToken); safecall;
    function add_StateChanged(handler: TypedEventHandler_2__Content_IContentIslandEnvironment__Content_IContentEnvironmentStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    property AppWindowId: WindowId read get_AppWindowId;
    property DisplayId_: DisplayId read get_DisplayId;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentDeferral
  Content_IContentDeferral = interface(IInspectable)
  ['{470529F5-CD93-599B-968E-F8A689BC3A07}']
    procedure Complete; safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentIslandAutomationProviderRequestedEventArgs
  Content_IContentIslandAutomationProviderRequestedEventArgs = interface(IInspectable)
  ['{9FE24BED-2B9C-5137-887F-403C94841824}']
    function get_AutomationProvider: IInspectable; safecall;
    procedure put_AutomationProvider(value: IInspectable); safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    property AutomationProvider: IInspectable read get_AutomationProvider write put_AutomationProvider;
    property Handled: Boolean read get_Handled write put_Handled;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.ContentIsland,Microsoft.UI.Content.ContentIslandAutomationProviderRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIsland,Microsoft.UI.Content.IContentIslandAutomationProviderRequestedEventArgs>
  TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandAutomationProviderRequestedEventArgs = interface(IUnknown)
  ['{3B44F287-F0EF-5D10-AB5F-1B324F45F7DA}']
    procedure Invoke(sender: Content_IContentIsland; args: Content_IContentIslandAutomationProviderRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentIslandStateChangedEventArgs
  Content_IContentIslandStateChangedEventArgs = interface(IInspectable)
  ['{C828EEB2-0C62-5B40-9D48-77C06083C278}']
    function get_DidActualSizeChange: Boolean; safecall;
    function get_DidSiteEnabledChange: Boolean; safecall;
    function get_DidSiteVisibleChange: Boolean; safecall;
    function get_DidLayoutDirectionChange: Boolean; safecall;
    function get_DidRasterizationScaleChange: Boolean; safecall;
    property DidActualSizeChange: Boolean read get_DidActualSizeChange;
    property DidLayoutDirectionChange: Boolean read get_DidLayoutDirectionChange;
    property DidRasterizationScaleChange: Boolean read get_DidRasterizationScaleChange;
    property DidSiteEnabledChange: Boolean read get_DidSiteEnabledChange;
    property DidSiteVisibleChange: Boolean read get_DidSiteVisibleChange;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.ContentIsland,Microsoft.UI.Content.ContentIslandStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Content.IContentIsland,Microsoft.UI.Content.IContentIslandStateChangedEventArgs>
  TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandStateChangedEventArgs = interface(IUnknown)
  ['{CEB771A4-BF66-529D-883A-602D592F390C}']
    procedure Invoke(sender: Content_IContentIsland; args: Content_IContentIslandStateChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IContentIsland
  Content_IContentIsland = interface(IInspectable)
  ['{5B2504BA-361C-50AA-BD6E-4122C6D93889}']
    function get_ActualSize: Numerics_Vector2; safecall;
    function get_AppData: IInspectable; safecall;
    procedure put_AppData(value: IInspectable); safecall;
    function get_CoordinateConverter: Content_IContentCoordinateConverter; safecall;
    function get_CustomProperties: IPropertySet; safecall;
    function get_DispatcherQueue: IDispatcherQueue; safecall;
    function get_Environment: Content_IContentIslandEnvironment; safecall;
    function get_Id: UInt64; safecall;
    function get_IsConnected: Boolean; safecall;
    function get_IsHitTestVisibleWhenTransparent: Boolean; safecall;
    procedure put_IsHitTestVisibleWhenTransparent(value: Boolean); safecall;
    function get_IsIslandEnabled: Boolean; safecall;
    procedure put_IsIslandEnabled(value: Boolean); safecall;
    function get_IsIslandVisible: Boolean; safecall;
    procedure put_IsIslandVisible(value: Boolean); safecall;
    function get_IsSiteEnabled: Boolean; safecall;
    function get_IsSiteVisible: Boolean; safecall;
    function get_LayoutDirection: Content_ContentLayoutDirection; safecall;
    function get_RasterizationScale: Single; safecall;
    function GetAutomationHostProvider: IInspectable; safecall;
    function GetStateChangeDeferral: Content_IContentDeferral; safecall;
    procedure RequestSize(size: Numerics_Vector2); safecall;
    function add_AutomationProviderRequested(handler: TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandAutomationProviderRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AutomationProviderRequested(token: EventRegistrationToken); safecall;
    function add_StateChanged(handler: TypedEventHandler_2__Content_IContentIsland__Content_IContentIslandStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    property ActualSize: Numerics_Vector2 read get_ActualSize;
    property AppData: IInspectable read get_AppData write put_AppData;
    property CoordinateConverter: Content_IContentCoordinateConverter read get_CoordinateConverter;
    property CustomProperties: IPropertySet read get_CustomProperties;
    property DispatcherQueue: IDispatcherQueue read get_DispatcherQueue;
    property Environment: Content_IContentIslandEnvironment read get_Environment;
    property Id: UInt64 read get_Id;
    property IsConnected: Boolean read get_IsConnected;
    property IsHitTestVisibleWhenTransparent: Boolean read get_IsHitTestVisibleWhenTransparent write put_IsHitTestVisibleWhenTransparent;
    property IsIslandEnabled: Boolean read get_IsIslandEnabled write put_IsIslandEnabled;
    property IsIslandVisible: Boolean read get_IsIslandVisible write put_IsIslandVisible;
    property IsSiteEnabled: Boolean read get_IsSiteEnabled;
    property IsSiteVisible: Boolean read get_IsSiteVisible;
    property LayoutDirection: Content_ContentLayoutDirection read get_LayoutDirection;
    property RasterizationScale: Single read get_RasterizationScale;
  end;

  // Microsoft.UI.Content.IContentCoordinateConverterFactory
  Content_IContentCoordinateConverterFactory = interface(IInspectable)
  ['{A4B216EE-0E26-56BD-9209-A75CF9D80F27}']
  end;

  // Microsoft.UI.Content.IContentIslandEnvironmentFactory
  Content_IContentIslandEnvironmentFactory = interface(IInspectable)
  ['{47A782D6-B177-5C1E-BF87-90437DD809D0}']
  end;

  // Microsoft.UI.Content.IContentIslandFactory
  Content_IContentIslandFactory = interface(IInspectable)
  ['{82383F52-E81A-5EC9-A954-BAC8A931BA7D}']
  end;

  // Windows.Foundation.IReference`1<Microsoft.UI.Content.ContentLayoutDirection>
  IReference_1__Content_ContentLayoutDirection = interface(IInspectable)
  ['{76E53EED-3539-540B-8D51-4206BCA63F5F}']
    function get_Value: Content_ContentLayoutDirection; safecall;
    property Value: Content_ContentLayoutDirection read get_Value;
  end;

  // Microsoft.UI.Content.IContentSiteEnvironmentFactory
  Content_IContentSiteEnvironmentFactory = interface(IInspectable)
  ['{0BEFA998-CB15-5F16-A4A5-C0ED1674E186}']
  end;

  // Microsoft.UI.Content.IContentSiteEnvironmentViewFactory
  Content_IContentSiteEnvironmentViewFactory = interface(IInspectable)
  ['{C901EDF2-F184-5A64-8D58-8CF8EFA8B678}']
  end;

  // Microsoft.UI.Content.IContentSiteFactory
  Content_IContentSiteFactory = interface(IInspectable)
  ['{72FB98D5-B28A-57F1-91FA-24C014A342C1}']
  end;

  // Microsoft.UI.Content.IContentSiteViewFactory
  Content_IContentSiteViewFactory = interface(IInspectable)
  ['{9EFD72F0-63EF-5B6A-A50C-5685BD8100F1}']
  end;

  // UsedAPI Interface
  // Microsoft.UI.Content.IDesktopChildSiteBridge
  Content_IDesktopChildSiteBridge = interface(IInspectable)
  ['{B2F2FF7B-1825-51B0-B80B-7599889C569F}']
    function get_ResizePolicy: Content_ContentSizePolicy; safecall;
    procedure put_ResizePolicy(value: Content_ContentSizePolicy); safecall;
    function get_SiteView: Content_IContentSiteView; safecall;
    property ResizePolicy: Content_ContentSizePolicy read get_ResizePolicy write put_ResizePolicy;
    property SiteView: Content_IContentSiteView read get_SiteView;
  end;

  // Microsoft.UI.Content.IDesktopSiteBridgeFactory
  Content_IDesktopSiteBridgeFactory = interface(IInspectable)
  ['{D94EE1FF-3AF1-54D0-9311-652B29C57C5B}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Microsoft.UI.IColorHelper
  [WinRTClassNameAttribute(SMicrosoft_UI_ColorHelper)]
  IColorHelper = interface(IInspectable)
  ['{3ADDDCCD-3949-585B-A566-CCB8350DD221}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Microsoft.UI.IColorHelperStatics
  [WinRTClassNameAttribute(SMicrosoft_UI_ColorHelper)]
  IColorHelperStatics = interface(IInspectable)
  ['{1D1D85A1-EB63-538A-84F0-019210BC406B}']
    function FromArgb(a: Byte; r: Byte; g: Byte; b: Byte): Color; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Microsoft.UI.IColorHelperStatics2
  [WinRTClassNameAttribute(SMicrosoft_UI_ColorHelper)]
  IColorHelperStatics2 = interface(IInspectable)
  ['{982A2D93-0EC4-56B7-9C20-0B5C77949066}']
    function ToDisplayName(color: Color): HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Microsoft.UI.IColors
  [WinRTClassNameAttribute(SMicrosoft_UI_Colors)]
  IColors = interface(IInspectable)
  ['{8CF15863-8411-5AFD-946C-328E04DA2F2F}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Microsoft.UI.IColorsStatics
  [WinRTClassNameAttribute(SMicrosoft_UI_Colors)]
  IColorsStatics = interface(IInspectable)
  ['{8620A5B0-015A-57AC-A3F3-895D0B1269AE}']
    function get_AliceBlue: Color; safecall;
    function get_AntiqueWhite: Color; safecall;
    function get_Aqua: Color; safecall;
    function get_Aquamarine: Color; safecall;
    function get_Azure: Color; safecall;
    function get_Beige: Color; safecall;
    function get_Bisque: Color; safecall;
    function get_Black: Color; safecall;
    function get_BlanchedAlmond: Color; safecall;
    function get_Blue: Color; safecall;
    function get_BlueViolet: Color; safecall;
    function get_Brown: Color; safecall;
    function get_BurlyWood: Color; safecall;
    function get_CadetBlue: Color; safecall;
    function get_Chartreuse: Color; safecall;
    function get_Chocolate: Color; safecall;
    function get_Coral: Color; safecall;
    function get_CornflowerBlue: Color; safecall;
    function get_Cornsilk: Color; safecall;
    function get_Crimson: Color; safecall;
    function get_Cyan: Color; safecall;
    function get_DarkBlue: Color; safecall;
    function get_DarkCyan: Color; safecall;
    function get_DarkGoldenrod: Color; safecall;
    function get_DarkGray: Color; safecall;
    function get_DarkGreen: Color; safecall;
    function get_DarkKhaki: Color; safecall;
    function get_DarkMagenta: Color; safecall;
    function get_DarkOliveGreen: Color; safecall;
    function get_DarkOrange: Color; safecall;
    function get_DarkOrchid: Color; safecall;
    function get_DarkRed: Color; safecall;
    function get_DarkSalmon: Color; safecall;
    function get_DarkSeaGreen: Color; safecall;
    function get_DarkSlateBlue: Color; safecall;
    function get_DarkSlateGray: Color; safecall;
    function get_DarkTurquoise: Color; safecall;
    function get_DarkViolet: Color; safecall;
    function get_DeepPink: Color; safecall;
    function get_DeepSkyBlue: Color; safecall;
    function get_DimGray: Color; safecall;
    function get_DodgerBlue: Color; safecall;
    function get_Firebrick: Color; safecall;
    function get_FloralWhite: Color; safecall;
    function get_ForestGreen: Color; safecall;
    function get_Fuchsia: Color; safecall;
    function get_Gainsboro: Color; safecall;
    function get_GhostWhite: Color; safecall;
    function get_Gold: Color; safecall;
    function get_Goldenrod: Color; safecall;
    function get_Gray: Color; safecall;
    function get_Green: Color; safecall;
    function get_GreenYellow: Color; safecall;
    function get_Honeydew: Color; safecall;
    function get_HotPink: Color; safecall;
    function get_IndianRed: Color; safecall;
    function get_Indigo: Color; safecall;
    function get_Ivory: Color; safecall;
    function get_Khaki: Color; safecall;
    function get_Lavender: Color; safecall;
    function get_LavenderBlush: Color; safecall;
    function get_LawnGreen: Color; safecall;
    function get_LemonChiffon: Color; safecall;
    function get_LightBlue: Color; safecall;
    function get_LightCoral: Color; safecall;
    function get_LightCyan: Color; safecall;
    function get_LightGoldenrodYellow: Color; safecall;
    function get_LightGreen: Color; safecall;
    function get_LightGray: Color; safecall;
    function get_LightPink: Color; safecall;
    function get_LightSalmon: Color; safecall;
    function get_LightSeaGreen: Color; safecall;
    function get_LightSkyBlue: Color; safecall;
    function get_LightSlateGray: Color; safecall;
    function get_LightSteelBlue: Color; safecall;
    function get_LightYellow: Color; safecall;
    function get_Lime: Color; safecall;
    function get_LimeGreen: Color; safecall;
    function get_Linen: Color; safecall;
    function get_Magenta: Color; safecall;
    function get_Maroon: Color; safecall;
    function get_MediumAquamarine: Color; safecall;
    function get_MediumBlue: Color; safecall;
    function get_MediumOrchid: Color; safecall;
    function get_MediumPurple: Color; safecall;
    function get_MediumSeaGreen: Color; safecall;
    function get_MediumSlateBlue: Color; safecall;
    function get_MediumSpringGreen: Color; safecall;
    function get_MediumTurquoise: Color; safecall;
    function get_MediumVioletRed: Color; safecall;
    function get_MidnightBlue: Color; safecall;
    function get_MintCream: Color; safecall;
    function get_MistyRose: Color; safecall;
    function get_Moccasin: Color; safecall;
    function get_NavajoWhite: Color; safecall;
    function get_Navy: Color; safecall;
    function get_OldLace: Color; safecall;
    function get_Olive: Color; safecall;
    function get_OliveDrab: Color; safecall;
    function get_Orange: Color; safecall;
    function get_OrangeRed: Color; safecall;
    function get_Orchid: Color; safecall;
    function get_PaleGoldenrod: Color; safecall;
    function get_PaleGreen: Color; safecall;
    function get_PaleTurquoise: Color; safecall;
    function get_PaleVioletRed: Color; safecall;
    function get_PapayaWhip: Color; safecall;
    function get_PeachPuff: Color; safecall;
    function get_Peru: Color; safecall;
    function get_Pink: Color; safecall;
    function get_Plum: Color; safecall;
    function get_PowderBlue: Color; safecall;
    function get_Purple: Color; safecall;
    function get_Red: Color; safecall;
    function get_RosyBrown: Color; safecall;
    function get_RoyalBlue: Color; safecall;
    function get_SaddleBrown: Color; safecall;
    function get_Salmon: Color; safecall;
    function get_SandyBrown: Color; safecall;
    function get_SeaGreen: Color; safecall;
    function get_SeaShell: Color; safecall;
    function get_Sienna: Color; safecall;
    function get_Silver: Color; safecall;
    function get_SkyBlue: Color; safecall;
    function get_SlateBlue: Color; safecall;
    function get_SlateGray: Color; safecall;
    function get_Snow: Color; safecall;
    function get_SpringGreen: Color; safecall;
    function get_SteelBlue: Color; safecall;
    function get_Tan: Color; safecall;
    function get_Teal: Color; safecall;
    function get_Thistle: Color; safecall;
    function get_Tomato: Color; safecall;
    function get_Transparent: Color; safecall;
    function get_Turquoise: Color; safecall;
    function get_Violet: Color; safecall;
    function get_Wheat: Color; safecall;
    function get_White: Color; safecall;
    function get_WhiteSmoke: Color; safecall;
    function get_Yellow: Color; safecall;
    function get_YellowGreen: Color; safecall;
    property AliceBlue: Color read get_AliceBlue;
    property AntiqueWhite: Color read get_AntiqueWhite;
    property Aqua: Color read get_Aqua;
    property Aquamarine: Color read get_Aquamarine;
    property Azure: Color read get_Azure;
    property Beige: Color read get_Beige;
    property Bisque: Color read get_Bisque;
    property Black: Color read get_Black;
    property BlanchedAlmond: Color read get_BlanchedAlmond;
    property Blue: Color read get_Blue;
    property BlueViolet: Color read get_BlueViolet;
    property Brown: Color read get_Brown;
    property BurlyWood: Color read get_BurlyWood;
    property CadetBlue: Color read get_CadetBlue;
    property Chartreuse: Color read get_Chartreuse;
    property Chocolate: Color read get_Chocolate;
    property Coral: Color read get_Coral;
    property CornflowerBlue: Color read get_CornflowerBlue;
    property Cornsilk: Color read get_Cornsilk;
    property Crimson: Color read get_Crimson;
    property Cyan: Color read get_Cyan;
    property DarkBlue: Color read get_DarkBlue;
    property DarkCyan: Color read get_DarkCyan;
    property DarkGoldenrod: Color read get_DarkGoldenrod;
    property DarkGray: Color read get_DarkGray;
    property DarkGreen: Color read get_DarkGreen;
    property DarkKhaki: Color read get_DarkKhaki;
    property DarkMagenta: Color read get_DarkMagenta;
    property DarkOliveGreen: Color read get_DarkOliveGreen;
    property DarkOrange: Color read get_DarkOrange;
    property DarkOrchid: Color read get_DarkOrchid;
    property DarkRed: Color read get_DarkRed;
    property DarkSalmon: Color read get_DarkSalmon;
    property DarkSeaGreen: Color read get_DarkSeaGreen;
    property DarkSlateBlue: Color read get_DarkSlateBlue;
    property DarkSlateGray: Color read get_DarkSlateGray;
    property DarkTurquoise: Color read get_DarkTurquoise;
    property DarkViolet: Color read get_DarkViolet;
    property DeepPink: Color read get_DeepPink;
    property DeepSkyBlue: Color read get_DeepSkyBlue;
    property DimGray: Color read get_DimGray;
    property DodgerBlue: Color read get_DodgerBlue;
    property Firebrick: Color read get_Firebrick;
    property FloralWhite: Color read get_FloralWhite;
    property ForestGreen: Color read get_ForestGreen;
    property Fuchsia: Color read get_Fuchsia;
    property Gainsboro: Color read get_Gainsboro;
    property GhostWhite: Color read get_GhostWhite;
    property Gold: Color read get_Gold;
    property Goldenrod: Color read get_Goldenrod;
    property Gray: Color read get_Gray;
    property Green: Color read get_Green;
    property GreenYellow: Color read get_GreenYellow;
    property Honeydew: Color read get_Honeydew;
    property HotPink: Color read get_HotPink;
    property IndianRed: Color read get_IndianRed;
    property Indigo: Color read get_Indigo;
    property Ivory: Color read get_Ivory;
    property Khaki: Color read get_Khaki;
    property Lavender: Color read get_Lavender;
    property LavenderBlush: Color read get_LavenderBlush;
    property LawnGreen: Color read get_LawnGreen;
    property LemonChiffon: Color read get_LemonChiffon;
    property LightBlue: Color read get_LightBlue;
    property LightCoral: Color read get_LightCoral;
    property LightCyan: Color read get_LightCyan;
    property LightGoldenrodYellow: Color read get_LightGoldenrodYellow;
    property LightGray: Color read get_LightGray;
    property LightGreen: Color read get_LightGreen;
    property LightPink: Color read get_LightPink;
    property LightSalmon: Color read get_LightSalmon;
    property LightSeaGreen: Color read get_LightSeaGreen;
    property LightSkyBlue: Color read get_LightSkyBlue;
    property LightSlateGray: Color read get_LightSlateGray;
    property LightSteelBlue: Color read get_LightSteelBlue;
    property LightYellow: Color read get_LightYellow;
    property Lime: Color read get_Lime;
    property LimeGreen: Color read get_LimeGreen;
    property Linen: Color read get_Linen;
    property Magenta: Color read get_Magenta;
    property Maroon: Color read get_Maroon;
    property MediumAquamarine: Color read get_MediumAquamarine;
    property MediumBlue: Color read get_MediumBlue;
    property MediumOrchid: Color read get_MediumOrchid;
    property MediumPurple: Color read get_MediumPurple;
    property MediumSeaGreen: Color read get_MediumSeaGreen;
    property MediumSlateBlue: Color read get_MediumSlateBlue;
    property MediumSpringGreen: Color read get_MediumSpringGreen;
    property MediumTurquoise: Color read get_MediumTurquoise;
    property MediumVioletRed: Color read get_MediumVioletRed;
    property MidnightBlue: Color read get_MidnightBlue;
    property MintCream: Color read get_MintCream;
    property MistyRose: Color read get_MistyRose;
    property Moccasin: Color read get_Moccasin;
    property NavajoWhite: Color read get_NavajoWhite;
    property Navy: Color read get_Navy;
    property OldLace: Color read get_OldLace;
    property Olive: Color read get_Olive;
    property OliveDrab: Color read get_OliveDrab;
    property Orange: Color read get_Orange;
    property OrangeRed: Color read get_OrangeRed;
    property Orchid: Color read get_Orchid;
    property PaleGoldenrod: Color read get_PaleGoldenrod;
    property PaleGreen: Color read get_PaleGreen;
    property PaleTurquoise: Color read get_PaleTurquoise;
    property PaleVioletRed: Color read get_PaleVioletRed;
    property PapayaWhip: Color read get_PapayaWhip;
    property PeachPuff: Color read get_PeachPuff;
    property Peru: Color read get_Peru;
    property Pink: Color read get_Pink;
    property Plum: Color read get_Plum;
    property PowderBlue: Color read get_PowderBlue;
    property Purple: Color read get_Purple;
    property Red: Color read get_Red;
    property RosyBrown: Color read get_RosyBrown;
    property RoyalBlue: Color read get_RoyalBlue;
    property SaddleBrown: Color read get_SaddleBrown;
    property Salmon: Color read get_Salmon;
    property SandyBrown: Color read get_SandyBrown;
    property SeaGreen: Color read get_SeaGreen;
    property SeaShell: Color read get_SeaShell;
    property Sienna: Color read get_Sienna;
    property Silver: Color read get_Silver;
    property SkyBlue: Color read get_SkyBlue;
    property SlateBlue: Color read get_SlateBlue;
    property SlateGray: Color read get_SlateGray;
    property Snow: Color read get_Snow;
    property SpringGreen: Color read get_SpringGreen;
    property SteelBlue: Color read get_SteelBlue;
    property Tan: Color read get_Tan;
    property Teal: Color read get_Teal;
    property Thistle: Color read get_Thistle;
    property Tomato: Color read get_Tomato;
    property Transparent: Color read get_Transparent;
    property Turquoise: Color read get_Turquoise;
    property Violet: Color read get_Violet;
    property Wheat: Color read get_Wheat;
    property White: Color read get_White;
    property WhiteSmoke: Color read get_WhiteSmoke;
    property Yellow: Color read get_Yellow;
    property YellowGreen: Color read get_YellowGreen;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IAppWindowPresenter
  Windowing_IAppWindowPresenter = interface(IInspectable)
  ['{BC3042C2-C6C6-5632-8989-FF0EC6D3B40D}']
    function get_Kind: Windowing_AppWindowPresenterKind; safecall;
    property Kind: Windowing_AppWindowPresenterKind read get_Kind;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IAppWindowTitleBar
  Windowing_IAppWindowTitleBar = interface(IInspectable)
  ['{5574EFA2-C91C-5700-A363-539C71A7AAF4}']
    function get_BackgroundColor: IReference_1__Color; safecall;
    procedure put_BackgroundColor(value: IReference_1__Color); safecall;
    function get_ButtonBackgroundColor: IReference_1__Color; safecall;
    procedure put_ButtonBackgroundColor(value: IReference_1__Color); safecall;
    function get_ButtonForegroundColor: IReference_1__Color; safecall;
    procedure put_ButtonForegroundColor(value: IReference_1__Color); safecall;
    function get_ButtonHoverBackgroundColor: IReference_1__Color; safecall;
    procedure put_ButtonHoverBackgroundColor(value: IReference_1__Color); safecall;
    function get_ButtonHoverForegroundColor: IReference_1__Color; safecall;
    procedure put_ButtonHoverForegroundColor(value: IReference_1__Color); safecall;
    function get_ButtonInactiveBackgroundColor: IReference_1__Color; safecall;
    procedure put_ButtonInactiveBackgroundColor(value: IReference_1__Color); safecall;
    function get_ButtonInactiveForegroundColor: IReference_1__Color; safecall;
    procedure put_ButtonInactiveForegroundColor(value: IReference_1__Color); safecall;
    function get_ButtonPressedBackgroundColor: IReference_1__Color; safecall;
    procedure put_ButtonPressedBackgroundColor(value: IReference_1__Color); safecall;
    function get_ButtonPressedForegroundColor: IReference_1__Color; safecall;
    procedure put_ButtonPressedForegroundColor(value: IReference_1__Color); safecall;
    function get_ExtendsContentIntoTitleBar: Boolean; safecall;
    procedure put_ExtendsContentIntoTitleBar(value: Boolean); safecall;
    function get_ForegroundColor: IReference_1__Color; safecall;
    procedure put_ForegroundColor(value: IReference_1__Color); safecall;
    function get_Height: Integer; safecall;
    function get_IconShowOptions: Windowing_IconShowOptions; safecall;
    procedure put_IconShowOptions(value: Windowing_IconShowOptions); safecall;
    function get_InactiveBackgroundColor: IReference_1__Color; safecall;
    procedure put_InactiveBackgroundColor(value: IReference_1__Color); safecall;
    function get_InactiveForegroundColor: IReference_1__Color; safecall;
    procedure put_InactiveForegroundColor(value: IReference_1__Color); safecall;
    function get_LeftInset: Integer; safecall;
    function get_RightInset: Integer; safecall;
    procedure ResetToDefault; safecall;
    procedure SetDragRectangles(valueSize: Cardinal; value: PRectInt32); safecall;
    property BackgroundColor: IReference_1__Color read get_BackgroundColor write put_BackgroundColor;
    property ButtonBackgroundColor: IReference_1__Color read get_ButtonBackgroundColor write put_ButtonBackgroundColor;
    property ButtonForegroundColor: IReference_1__Color read get_ButtonForegroundColor write put_ButtonForegroundColor;
    property ButtonHoverBackgroundColor: IReference_1__Color read get_ButtonHoverBackgroundColor write put_ButtonHoverBackgroundColor;
    property ButtonHoverForegroundColor: IReference_1__Color read get_ButtonHoverForegroundColor write put_ButtonHoverForegroundColor;
    property ButtonInactiveBackgroundColor: IReference_1__Color read get_ButtonInactiveBackgroundColor write put_ButtonInactiveBackgroundColor;
    property ButtonInactiveForegroundColor: IReference_1__Color read get_ButtonInactiveForegroundColor write put_ButtonInactiveForegroundColor;
    property ButtonPressedBackgroundColor: IReference_1__Color read get_ButtonPressedBackgroundColor write put_ButtonPressedBackgroundColor;
    property ButtonPressedForegroundColor: IReference_1__Color read get_ButtonPressedForegroundColor write put_ButtonPressedForegroundColor;
    property ExtendsContentIntoTitleBar: Boolean read get_ExtendsContentIntoTitleBar write put_ExtendsContentIntoTitleBar;
    property ForegroundColor: IReference_1__Color read get_ForegroundColor write put_ForegroundColor;
    property Height: Integer read get_Height;
    property IconShowOptions: Windowing_IconShowOptions read get_IconShowOptions write put_IconShowOptions;
    property InactiveBackgroundColor: IReference_1__Color read get_InactiveBackgroundColor write put_InactiveBackgroundColor;
    property InactiveForegroundColor: IReference_1__Color read get_InactiveForegroundColor write put_InactiveForegroundColor;
    property LeftInset: Integer read get_LeftInset;
    property RightInset: Integer read get_RightInset;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IDisplayArea
  Windowing_IDisplayArea = interface(IInspectable)
  ['{5C7E0537-B621-5579-BCAE-A84AA8746167}']
    function get_DisplayId: DisplayId; safecall;
    function get_IsPrimary: Boolean; safecall;
    function get_OuterBounds: RectInt32; safecall;
    function get_WorkArea: RectInt32; safecall;
    property DisplayId_: DisplayId read get_DisplayId;
    property IsPrimary: Boolean read get_IsPrimary;
    property OuterBounds: RectInt32 read get_OuterBounds;
    property WorkArea: RectInt32 read get_WorkArea;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IAppWindowChangedEventArgs
  Windowing_IAppWindowChangedEventArgs = interface(IInspectable)
  ['{2182BC5D-FDAC-5C3E-BF37-7D8D684E9D1D}']
    function get_DidPositionChange: Boolean; safecall;
    function get_DidPresenterChange: Boolean; safecall;
    function get_DidSizeChange: Boolean; safecall;
    function get_DidVisibilityChange: Boolean; safecall;
    property DidPositionChange: Boolean read get_DidPositionChange;
    property DidPresenterChange: Boolean read get_DidPresenterChange;
    property DidSizeChange: Boolean read get_DidSizeChange;
    property DidVisibilityChange: Boolean read get_DidVisibilityChange;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.AppWindow,Microsoft.UI.Windowing.AppWindowChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Microsoft.UI.Windowing.IAppWindowChangedEventArgs>
  TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowChangedEventArgs = interface(IUnknown)
  ['{CDA07756-1584-5049-9AD1-CCA782242D34}']
    procedure Invoke(sender: Windowing_IAppWindow; args: Windowing_IAppWindowChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IAppWindowClosingEventArgs
  Windowing_IAppWindowClosingEventArgs = interface(IInspectable)
  ['{0E09D90B-2261-590B-9AD1-8504991D8754}']
    function get_Cancel: Boolean; safecall;
    procedure put_Cancel(value: Boolean); safecall;
    property Cancel: Boolean read get_Cancel write put_Cancel;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.AppWindow,Microsoft.UI.Windowing.AppWindowClosingEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Microsoft.UI.Windowing.IAppWindowClosingEventArgs>
  TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowClosingEventArgs = interface(IUnknown)
  ['{FD0E72C8-8DAA-50A2-959F-4D41446F1FC7}']
    procedure Invoke(sender: Windowing_IAppWindow; args: Windowing_IAppWindowClosingEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.AppWindow,Object>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Windowing.IAppWindow,Object>
  TypedEventHandler_2__Windowing_IAppWindow__IInspectable = interface(IUnknown)
  ['{EDDD665F-7D53-5B2D-901D-9C12010816E7}']
    procedure Invoke(sender: Windowing_IAppWindow; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Windowing.IAppWindow
  Windowing_IAppWindow = interface(IInspectable)
  ['{CFA788B3-643B-5C5E-AD4E-321D48A82ACD}']
    function get_Id: WindowId; safecall;
    function get_IsShownInSwitchers: Boolean; safecall;
    procedure put_IsShownInSwitchers(value: Boolean); safecall;
    function get_IsVisible: Boolean; safecall;
    function get_OwnerWindowId: WindowId; safecall;
    function get_Position: PointInt32; safecall;
    function get_Presenter: Windowing_IAppWindowPresenter; safecall;
    function get_Size: SizeInt32; safecall;
    function get_Title: HSTRING; safecall;
    procedure put_Title(value: HSTRING); safecall;
    function get_TitleBar: Windowing_IAppWindowTitleBar; safecall;
    procedure Destroy; safecall;
    procedure Hide; safecall;
    procedure Move(position: PointInt32); safecall;
    procedure MoveAndResize(rect: RectInt32); overload; safecall;
    procedure MoveAndResize(rect: RectInt32; displayarea: Windowing_IDisplayArea); overload; safecall;
    procedure Resize(size: SizeInt32); safecall;
    procedure SetIcon(iconPath: HSTRING); overload; safecall;
    procedure SetIcon(iconId: IconId); overload; safecall;
    procedure SetPresenter(appWindowPresenter: Windowing_IAppWindowPresenter); overload; safecall;
    procedure SetPresenter(appWindowPresenterKind: Windowing_AppWindowPresenterKind); overload; safecall;
    procedure Show; overload; safecall;
    procedure Show(activateWindow: Boolean); overload; safecall;
    function add_Changed(handler: TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Changed(token: EventRegistrationToken); safecall;
    function add_Closing(handler: TypedEventHandler_2__Windowing_IAppWindow__Windowing_IAppWindowClosingEventArgs): EventRegistrationToken; safecall;
    procedure remove_Closing(token: EventRegistrationToken); safecall;
    function add_Destroying(handler: TypedEventHandler_2__Windowing_IAppWindow__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Destroying(token: EventRegistrationToken); safecall;
    property Id: WindowId read get_Id;
    property IsShownInSwitchers: Boolean read get_IsShownInSwitchers write put_IsShownInSwitchers;
    property IsVisible: Boolean read get_IsVisible;
    property OwnerWindowId: WindowId read get_OwnerWindowId;
    property Position: PointInt32 read get_Position;
    property Presenter: Windowing_IAppWindowPresenter read get_Presenter;
    property Size: SizeInt32 read get_Size;
    property Title: HSTRING read get_Title write put_Title;
    property TitleBar: Windowing_IAppWindowTitleBar read get_TitleBar;
  end;

  // Microsoft.UI.Windowing.IAppWindowPresenterFactory
  Windowing_IAppWindowPresenterFactory = interface(IInspectable)
  ['{62082E3C-1368-5238-90D1-E932DC718A82}']
  end;

  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Windowing.DisplayArea>
  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Windowing.IDisplayArea>
  IIterator_1__Windowing_IDisplayArea = interface(IInspectable)
  ['{3D833884-2258-5C48-8D45-3642FE8C6755}']
    function get_Current: Windowing_IDisplayArea; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWindowing_IDisplayArea): Cardinal; safecall;
    property Current: Windowing_IDisplayArea read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Windowing.DisplayArea>
  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Windowing.IDisplayArea>
  IIterable_1__Windowing_IDisplayArea = interface(IInspectable)
  ['{FB253085-6CFC-5FA6-948E-97383F5BE36C}']
    function First: IIterator_1__Windowing_IDisplayArea; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Microsoft.UI.Windowing.IDisplayArea>
  IVectorView_1__Windowing_IDisplayArea = interface(IInspectable)
  ['{336AE55B-4B67-593B-A982-CE8AC59A8C14}']
    function GetAt(index: Cardinal): Windowing_IDisplayArea; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Windowing_IDisplayArea; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWindowing_IDisplayArea): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Microsoft.UI.ColorHelper
  // Explicitly imported
  // Implements: Microsoft.UI.IColorHelper
  // Statics: "Microsoft.UI.IColorHelperStatics"
  // Statics: "Microsoft.UI.IColorHelperStatics2"
  TColorHelper = class(TWinRTGenericImportS2<IColorHelperStatics, IColorHelperStatics2>)
  public
    {$REGION 'IColorHelperStatics'}
    class function FromArgb(a: Byte; r: Byte; g: Byte; b: Byte): Color; static; inline;
    {$ENDREGION}
    {$REGION 'IColorHelperStatics2'}
    class function ToDisplayName(color: Color): HSTRING; static; inline;
    {$ENDREGION}
 end;

  // Microsoft.UI.Colors
  // Explicitly imported
  // Implements: Microsoft.UI.IColors
  // Statics: "Microsoft.UI.IColorsStatics"
  TColors = class(TWinRTGenericImportS<IColorsStatics>)
  public
    {$REGION 'IColorsStatics'}
    class function get_AliceBlue: Color; static; inline;
    class function get_AntiqueWhite: Color; static; inline;
    class function get_Aqua: Color; static; inline;
    class function get_Aquamarine: Color; static; inline;
    class function get_Azure: Color; static; inline;
    class function get_Beige: Color; static; inline;
    class function get_Bisque: Color; static; inline;
    class function get_Black: Color; static; inline;
    class function get_BlanchedAlmond: Color; static; inline;
    class function get_Blue: Color; static; inline;
    class function get_BlueViolet: Color; static; inline;
    class function get_Brown: Color; static; inline;
    class function get_BurlyWood: Color; static; inline;
    class function get_CadetBlue: Color; static; inline;
    class function get_Chartreuse: Color; static; inline;
    class function get_Chocolate: Color; static; inline;
    class function get_Coral: Color; static; inline;
    class function get_CornflowerBlue: Color; static; inline;
    class function get_Cornsilk: Color; static; inline;
    class function get_Crimson: Color; static; inline;
    class function get_Cyan: Color; static; inline;
    class function get_DarkBlue: Color; static; inline;
    class function get_DarkCyan: Color; static; inline;
    class function get_DarkGoldenrod: Color; static; inline;
    class function get_DarkGray: Color; static; inline;
    class function get_DarkGreen: Color; static; inline;
    class function get_DarkKhaki: Color; static; inline;
    class function get_DarkMagenta: Color; static; inline;
    class function get_DarkOliveGreen: Color; static; inline;
    class function get_DarkOrange: Color; static; inline;
    class function get_DarkOrchid: Color; static; inline;
    class function get_DarkRed: Color; static; inline;
    class function get_DarkSalmon: Color; static; inline;
    class function get_DarkSeaGreen: Color; static; inline;
    class function get_DarkSlateBlue: Color; static; inline;
    class function get_DarkSlateGray: Color; static; inline;
    class function get_DarkTurquoise: Color; static; inline;
    class function get_DarkViolet: Color; static; inline;
    class function get_DeepPink: Color; static; inline;
    class function get_DeepSkyBlue: Color; static; inline;
    class function get_DimGray: Color; static; inline;
    class function get_DodgerBlue: Color; static; inline;
    class function get_Firebrick: Color; static; inline;
    class function get_FloralWhite: Color; static; inline;
    class function get_ForestGreen: Color; static; inline;
    class function get_Fuchsia: Color; static; inline;
    class function get_Gainsboro: Color; static; inline;
    class function get_GhostWhite: Color; static; inline;
    class function get_Gold: Color; static; inline;
    class function get_Goldenrod: Color; static; inline;
    class function get_Gray: Color; static; inline;
    class function get_Green: Color; static; inline;
    class function get_GreenYellow: Color; static; inline;
    class function get_Honeydew: Color; static; inline;
    class function get_HotPink: Color; static; inline;
    class function get_IndianRed: Color; static; inline;
    class function get_Indigo: Color; static; inline;
    class function get_Ivory: Color; static; inline;
    class function get_Khaki: Color; static; inline;
    class function get_Lavender: Color; static; inline;
    class function get_LavenderBlush: Color; static; inline;
    class function get_LawnGreen: Color; static; inline;
    class function get_LemonChiffon: Color; static; inline;
    class function get_LightBlue: Color; static; inline;
    class function get_LightCoral: Color; static; inline;
    class function get_LightCyan: Color; static; inline;
    class function get_LightGoldenrodYellow: Color; static; inline;
    class function get_LightGreen: Color; static; inline;
    class function get_LightGray: Color; static; inline;
    class function get_LightPink: Color; static; inline;
    class function get_LightSalmon: Color; static; inline;
    class function get_LightSeaGreen: Color; static; inline;
    class function get_LightSkyBlue: Color; static; inline;
    class function get_LightSlateGray: Color; static; inline;
    class function get_LightSteelBlue: Color; static; inline;
    class function get_LightYellow: Color; static; inline;
    class function get_Lime: Color; static; inline;
    class function get_LimeGreen: Color; static; inline;
    class function get_Linen: Color; static; inline;
    class function get_Magenta: Color; static; inline;
    class function get_Maroon: Color; static; inline;
    class function get_MediumAquamarine: Color; static; inline;
    class function get_MediumBlue: Color; static; inline;
    class function get_MediumOrchid: Color; static; inline;
    class function get_MediumPurple: Color; static; inline;
    class function get_MediumSeaGreen: Color; static; inline;
    class function get_MediumSlateBlue: Color; static; inline;
    class function get_MediumSpringGreen: Color; static; inline;
    class function get_MediumTurquoise: Color; static; inline;
    class function get_MediumVioletRed: Color; static; inline;
    class function get_MidnightBlue: Color; static; inline;
    class function get_MintCream: Color; static; inline;
    class function get_MistyRose: Color; static; inline;
    class function get_Moccasin: Color; static; inline;
    class function get_NavajoWhite: Color; static; inline;
    class function get_Navy: Color; static; inline;
    class function get_OldLace: Color; static; inline;
    class function get_Olive: Color; static; inline;
    class function get_OliveDrab: Color; static; inline;
    class function get_Orange: Color; static; inline;
    class function get_OrangeRed: Color; static; inline;
    class function get_Orchid: Color; static; inline;
    class function get_PaleGoldenrod: Color; static; inline;
    class function get_PaleGreen: Color; static; inline;
    class function get_PaleTurquoise: Color; static; inline;
    class function get_PaleVioletRed: Color; static; inline;
    class function get_PapayaWhip: Color; static; inline;
    class function get_PeachPuff: Color; static; inline;
    class function get_Peru: Color; static; inline;
    class function get_Pink: Color; static; inline;
    class function get_Plum: Color; static; inline;
    class function get_PowderBlue: Color; static; inline;
    class function get_Purple: Color; static; inline;
    class function get_Red: Color; static; inline;
    class function get_RosyBrown: Color; static; inline;
    class function get_RoyalBlue: Color; static; inline;
    class function get_SaddleBrown: Color; static; inline;
    class function get_Salmon: Color; static; inline;
    class function get_SandyBrown: Color; static; inline;
    class function get_SeaGreen: Color; static; inline;
    class function get_SeaShell: Color; static; inline;
    class function get_Sienna: Color; static; inline;
    class function get_Silver: Color; static; inline;
    class function get_SkyBlue: Color; static; inline;
    class function get_SlateBlue: Color; static; inline;
    class function get_SlateGray: Color; static; inline;
    class function get_Snow: Color; static; inline;
    class function get_SpringGreen: Color; static; inline;
    class function get_SteelBlue: Color; static; inline;
    class function get_Tan: Color; static; inline;
    class function get_Teal: Color; static; inline;
    class function get_Thistle: Color; static; inline;
    class function get_Tomato: Color; static; inline;
    class function get_Transparent: Color; static; inline;
    class function get_Turquoise: Color; static; inline;
    class function get_Violet: Color; static; inline;
    class function get_Wheat: Color; static; inline;
    class function get_White: Color; static; inline;
    class function get_WhiteSmoke: Color; static; inline;
    class function get_Yellow: Color; static; inline;
    class function get_YellowGreen: Color; static; inline;
    class property AliceBlue: Color read get_AliceBlue;
    class property AntiqueWhite: Color read get_AntiqueWhite;
    class property Aqua: Color read get_Aqua;
    class property Aquamarine: Color read get_Aquamarine;
    class property Azure: Color read get_Azure;
    class property Beige: Color read get_Beige;
    class property Bisque: Color read get_Bisque;
    class property Black: Color read get_Black;
    class property BlanchedAlmond: Color read get_BlanchedAlmond;
    class property Blue: Color read get_Blue;
    class property BlueViolet: Color read get_BlueViolet;
    class property Brown: Color read get_Brown;
    class property BurlyWood: Color read get_BurlyWood;
    class property CadetBlue: Color read get_CadetBlue;
    class property Chartreuse: Color read get_Chartreuse;
    class property Chocolate: Color read get_Chocolate;
    class property Coral: Color read get_Coral;
    class property CornflowerBlue: Color read get_CornflowerBlue;
    class property Cornsilk: Color read get_Cornsilk;
    class property Crimson: Color read get_Crimson;
    class property Cyan: Color read get_Cyan;
    class property DarkBlue: Color read get_DarkBlue;
    class property DarkCyan: Color read get_DarkCyan;
    class property DarkGoldenrod: Color read get_DarkGoldenrod;
    class property DarkGray: Color read get_DarkGray;
    class property DarkGreen: Color read get_DarkGreen;
    class property DarkKhaki: Color read get_DarkKhaki;
    class property DarkMagenta: Color read get_DarkMagenta;
    class property DarkOliveGreen: Color read get_DarkOliveGreen;
    class property DarkOrange: Color read get_DarkOrange;
    class property DarkOrchid: Color read get_DarkOrchid;
    class property DarkRed: Color read get_DarkRed;
    class property DarkSalmon: Color read get_DarkSalmon;
    class property DarkSeaGreen: Color read get_DarkSeaGreen;
    class property DarkSlateBlue: Color read get_DarkSlateBlue;
    class property DarkSlateGray: Color read get_DarkSlateGray;
    class property DarkTurquoise: Color read get_DarkTurquoise;
    class property DarkViolet: Color read get_DarkViolet;
    class property DeepPink: Color read get_DeepPink;
    class property DeepSkyBlue: Color read get_DeepSkyBlue;
    class property DimGray: Color read get_DimGray;
    class property DodgerBlue: Color read get_DodgerBlue;
    class property Firebrick: Color read get_Firebrick;
    class property FloralWhite: Color read get_FloralWhite;
    class property ForestGreen: Color read get_ForestGreen;
    class property Fuchsia: Color read get_Fuchsia;
    class property Gainsboro: Color read get_Gainsboro;
    class property GhostWhite: Color read get_GhostWhite;
    class property Gold: Color read get_Gold;
    class property Goldenrod: Color read get_Goldenrod;
    class property Gray: Color read get_Gray;
    class property Green: Color read get_Green;
    class property GreenYellow: Color read get_GreenYellow;
    class property Honeydew: Color read get_Honeydew;
    class property HotPink: Color read get_HotPink;
    class property IndianRed: Color read get_IndianRed;
    class property Indigo: Color read get_Indigo;
    class property Ivory: Color read get_Ivory;
    class property Khaki: Color read get_Khaki;
    class property Lavender: Color read get_Lavender;
    class property LavenderBlush: Color read get_LavenderBlush;
    class property LawnGreen: Color read get_LawnGreen;
    class property LemonChiffon: Color read get_LemonChiffon;
    class property LightBlue: Color read get_LightBlue;
    class property LightCoral: Color read get_LightCoral;
    class property LightCyan: Color read get_LightCyan;
    class property LightGoldenrodYellow: Color read get_LightGoldenrodYellow;
    class property LightGray: Color read get_LightGray;
    class property LightGreen: Color read get_LightGreen;
    class property LightPink: Color read get_LightPink;
    class property LightSalmon: Color read get_LightSalmon;
    class property LightSeaGreen: Color read get_LightSeaGreen;
    class property LightSkyBlue: Color read get_LightSkyBlue;
    class property LightSlateGray: Color read get_LightSlateGray;
    class property LightSteelBlue: Color read get_LightSteelBlue;
    class property LightYellow: Color read get_LightYellow;
    class property Lime: Color read get_Lime;
    class property LimeGreen: Color read get_LimeGreen;
    class property Linen: Color read get_Linen;
    class property Magenta: Color read get_Magenta;
    class property Maroon: Color read get_Maroon;
    class property MediumAquamarine: Color read get_MediumAquamarine;
    class property MediumBlue: Color read get_MediumBlue;
    class property MediumOrchid: Color read get_MediumOrchid;
    class property MediumPurple: Color read get_MediumPurple;
    class property MediumSeaGreen: Color read get_MediumSeaGreen;
    class property MediumSlateBlue: Color read get_MediumSlateBlue;
    class property MediumSpringGreen: Color read get_MediumSpringGreen;
    class property MediumTurquoise: Color read get_MediumTurquoise;
    class property MediumVioletRed: Color read get_MediumVioletRed;
    class property MidnightBlue: Color read get_MidnightBlue;
    class property MintCream: Color read get_MintCream;
    class property MistyRose: Color read get_MistyRose;
    class property Moccasin: Color read get_Moccasin;
    class property NavajoWhite: Color read get_NavajoWhite;
    class property Navy: Color read get_Navy;
    class property OldLace: Color read get_OldLace;
    class property Olive: Color read get_Olive;
    class property OliveDrab: Color read get_OliveDrab;
    class property Orange: Color read get_Orange;
    class property OrangeRed: Color read get_OrangeRed;
    class property Orchid: Color read get_Orchid;
    class property PaleGoldenrod: Color read get_PaleGoldenrod;
    class property PaleGreen: Color read get_PaleGreen;
    class property PaleTurquoise: Color read get_PaleTurquoise;
    class property PaleVioletRed: Color read get_PaleVioletRed;
    class property PapayaWhip: Color read get_PapayaWhip;
    class property PeachPuff: Color read get_PeachPuff;
    class property Peru: Color read get_Peru;
    class property Pink: Color read get_Pink;
    class property Plum: Color read get_Plum;
    class property PowderBlue: Color read get_PowderBlue;
    class property Purple: Color read get_Purple;
    class property Red: Color read get_Red;
    class property RosyBrown: Color read get_RosyBrown;
    class property RoyalBlue: Color read get_RoyalBlue;
    class property SaddleBrown: Color read get_SaddleBrown;
    class property Salmon: Color read get_Salmon;
    class property SandyBrown: Color read get_SandyBrown;
    class property SeaGreen: Color read get_SeaGreen;
    class property SeaShell: Color read get_SeaShell;
    class property Sienna: Color read get_Sienna;
    class property Silver: Color read get_Silver;
    class property SkyBlue: Color read get_SkyBlue;
    class property SlateBlue: Color read get_SlateBlue;
    class property SlateGray: Color read get_SlateGray;
    class property Snow: Color read get_Snow;
    class property SpringGreen: Color read get_SpringGreen;
    class property SteelBlue: Color read get_SteelBlue;
    class property Tan: Color read get_Tan;
    class property Teal: Color read get_Teal;
    class property Thistle: Color read get_Thistle;
    class property Tomato: Color read get_Tomato;
    class property Transparent: Color read get_Transparent;
    class property Turquoise: Color read get_Turquoise;
    class property Violet: Color read get_Violet;
    class property Wheat: Color read get_Wheat;
    class property White: Color read get_White;
    class property WhiteSmoke: Color read get_WhiteSmoke;
    class property Yellow: Color read get_Yellow;
    class property YellowGreen: Color read get_YellowGreen;
    {$ENDREGION}
 end;

implementation

{ TColorHelper }

{$REGION 'Microsoft.UI.IColorHelperStatics'}
class function TColorHelper.FromArgb(a: Byte; r: Byte; g: Byte; b: Byte): Color;
begin
  Result := Statics.FromArgb(a, r, g, b);
end;

{$ENDREGION}

{$REGION 'Microsoft.UI.IColorHelperStatics2'}
class function TColorHelper.ToDisplayName(color: Color): HSTRING;
begin
  Result := Statics2.ToDisplayName(color);
end;
{$ENDREGION}

{ TColors }

{$REGION 'Microsoft.UI.IColorsStatics'}
class function TColors.get_AliceBlue: Color;
begin
  Result := Statics.get_AliceBlue;
end;

class function TColors.get_AntiqueWhite: Color;
begin
  Result := Statics.get_AntiqueWhite;
end;

class function TColors.get_Aqua: Color;
begin
  Result := Statics.get_Aqua;
end;

class function TColors.get_Aquamarine: Color;
begin
  Result := Statics.get_Aquamarine;
end;

class function TColors.get_Azure: Color;
begin
  Result := Statics.get_Azure;
end;

class function TColors.get_Beige: Color;
begin
  Result := Statics.get_Beige;
end;

class function TColors.get_Bisque: Color;
begin
  Result := Statics.get_Bisque;
end;

class function TColors.get_Black: Color;
begin
  Result := Statics.get_Black;
end;

class function TColors.get_BlanchedAlmond: Color;
begin
  Result := Statics.get_BlanchedAlmond;
end;

class function TColors.get_Blue: Color;
begin
  Result := Statics.get_Blue;
end;

class function TColors.get_BlueViolet: Color;
begin
  Result := Statics.get_BlueViolet;
end;

class function TColors.get_Brown: Color;
begin
  Result := Statics.get_Brown;
end;

class function TColors.get_BurlyWood: Color;
begin
  Result := Statics.get_BurlyWood;
end;

class function TColors.get_CadetBlue: Color;
begin
  Result := Statics.get_CadetBlue;
end;

class function TColors.get_Chartreuse: Color;
begin
  Result := Statics.get_Chartreuse;
end;

class function TColors.get_Chocolate: Color;
begin
  Result := Statics.get_Chocolate;
end;

class function TColors.get_Coral: Color;
begin
  Result := Statics.get_Coral;
end;

class function TColors.get_CornflowerBlue: Color;
begin
  Result := Statics.get_CornflowerBlue;
end;

class function TColors.get_Cornsilk: Color;
begin
  Result := Statics.get_Cornsilk;
end;

class function TColors.get_Crimson: Color;
begin
  Result := Statics.get_Crimson;
end;

class function TColors.get_Cyan: Color;
begin
  Result := Statics.get_Cyan;
end;

class function TColors.get_DarkBlue: Color;
begin
  Result := Statics.get_DarkBlue;
end;

class function TColors.get_DarkCyan: Color;
begin
  Result := Statics.get_DarkCyan;
end;

class function TColors.get_DarkGoldenrod: Color;
begin
  Result := Statics.get_DarkGoldenrod;
end;

class function TColors.get_DarkGray: Color;
begin
  Result := Statics.get_DarkGray;
end;

class function TColors.get_DarkGreen: Color;
begin
  Result := Statics.get_DarkGreen;
end;

class function TColors.get_DarkKhaki: Color;
begin
  Result := Statics.get_DarkKhaki;
end;

class function TColors.get_DarkMagenta: Color;
begin
  Result := Statics.get_DarkMagenta;
end;

class function TColors.get_DarkOliveGreen: Color;
begin
  Result := Statics.get_DarkOliveGreen;
end;

class function TColors.get_DarkOrange: Color;
begin
  Result := Statics.get_DarkOrange;
end;

class function TColors.get_DarkOrchid: Color;
begin
  Result := Statics.get_DarkOrchid;
end;

class function TColors.get_DarkRed: Color;
begin
  Result := Statics.get_DarkRed;
end;

class function TColors.get_DarkSalmon: Color;
begin
  Result := Statics.get_DarkSalmon;
end;

class function TColors.get_DarkSeaGreen: Color;
begin
  Result := Statics.get_DarkSeaGreen;
end;

class function TColors.get_DarkSlateBlue: Color;
begin
  Result := Statics.get_DarkSlateBlue;
end;

class function TColors.get_DarkSlateGray: Color;
begin
  Result := Statics.get_DarkSlateGray;
end;

class function TColors.get_DarkTurquoise: Color;
begin
  Result := Statics.get_DarkTurquoise;
end;

class function TColors.get_DarkViolet: Color;
begin
  Result := Statics.get_DarkViolet;
end;

class function TColors.get_DeepPink: Color;
begin
  Result := Statics.get_DeepPink;
end;

class function TColors.get_DeepSkyBlue: Color;
begin
  Result := Statics.get_DeepSkyBlue;
end;

class function TColors.get_DimGray: Color;
begin
  Result := Statics.get_DimGray;
end;

class function TColors.get_DodgerBlue: Color;
begin
  Result := Statics.get_DodgerBlue;
end;

class function TColors.get_Firebrick: Color;
begin
  Result := Statics.get_Firebrick;
end;

class function TColors.get_FloralWhite: Color;
begin
  Result := Statics.get_FloralWhite;
end;

class function TColors.get_ForestGreen: Color;
begin
  Result := Statics.get_ForestGreen;
end;

class function TColors.get_Fuchsia: Color;
begin
  Result := Statics.get_Fuchsia;
end;

class function TColors.get_Gainsboro: Color;
begin
  Result := Statics.get_Gainsboro;
end;

class function TColors.get_GhostWhite: Color;
begin
  Result := Statics.get_GhostWhite;
end;

class function TColors.get_Gold: Color;
begin
  Result := Statics.get_Gold;
end;

class function TColors.get_Goldenrod: Color;
begin
  Result := Statics.get_Goldenrod;
end;

class function TColors.get_Gray: Color;
begin
  Result := Statics.get_Gray;
end;

class function TColors.get_Green: Color;
begin
  Result := Statics.get_Green;
end;

class function TColors.get_GreenYellow: Color;
begin
  Result := Statics.get_GreenYellow;
end;

class function TColors.get_Honeydew: Color;
begin
  Result := Statics.get_Honeydew;
end;

class function TColors.get_HotPink: Color;
begin
  Result := Statics.get_HotPink;
end;

class function TColors.get_IndianRed: Color;
begin
  Result := Statics.get_IndianRed;
end;

class function TColors.get_Indigo: Color;
begin
  Result := Statics.get_Indigo;
end;

class function TColors.get_Ivory: Color;
begin
  Result := Statics.get_Ivory;
end;

class function TColors.get_Khaki: Color;
begin
  Result := Statics.get_Khaki;
end;

class function TColors.get_Lavender: Color;
begin
  Result := Statics.get_Lavender;
end;

class function TColors.get_LavenderBlush: Color;
begin
  Result := Statics.get_LavenderBlush;
end;

class function TColors.get_LawnGreen: Color;
begin
  Result := Statics.get_LawnGreen;
end;

class function TColors.get_LemonChiffon: Color;
begin
  Result := Statics.get_LemonChiffon;
end;

class function TColors.get_LightBlue: Color;
begin
  Result := Statics.get_LightBlue;
end;

class function TColors.get_LightCoral: Color;
begin
  Result := Statics.get_LightCoral;
end;

class function TColors.get_LightCyan: Color;
begin
  Result := Statics.get_LightCyan;
end;

class function TColors.get_LightGoldenrodYellow: Color;
begin
  Result := Statics.get_LightGoldenrodYellow;
end;

class function TColors.get_LightGreen: Color;
begin
  Result := Statics.get_LightGreen;
end;

class function TColors.get_LightGray: Color;
begin
  Result := Statics.get_LightGray;
end;

class function TColors.get_LightPink: Color;
begin
  Result := Statics.get_LightPink;
end;

class function TColors.get_LightSalmon: Color;
begin
  Result := Statics.get_LightSalmon;
end;

class function TColors.get_LightSeaGreen: Color;
begin
  Result := Statics.get_LightSeaGreen;
end;

class function TColors.get_LightSkyBlue: Color;
begin
  Result := Statics.get_LightSkyBlue;
end;

class function TColors.get_LightSlateGray: Color;
begin
  Result := Statics.get_LightSlateGray;
end;

class function TColors.get_LightSteelBlue: Color;
begin
  Result := Statics.get_LightSteelBlue;
end;

class function TColors.get_LightYellow: Color;
begin
  Result := Statics.get_LightYellow;
end;

class function TColors.get_Lime: Color;
begin
  Result := Statics.get_Lime;
end;

class function TColors.get_LimeGreen: Color;
begin
  Result := Statics.get_LimeGreen;
end;

class function TColors.get_Linen: Color;
begin
  Result := Statics.get_Linen;
end;

class function TColors.get_Magenta: Color;
begin
  Result := Statics.get_Magenta;
end;

class function TColors.get_Maroon: Color;
begin
  Result := Statics.get_Maroon;
end;

class function TColors.get_MediumAquamarine: Color;
begin
  Result := Statics.get_MediumAquamarine;
end;

class function TColors.get_MediumBlue: Color;
begin
  Result := Statics.get_MediumBlue;
end;

class function TColors.get_MediumOrchid: Color;
begin
  Result := Statics.get_MediumOrchid;
end;

class function TColors.get_MediumPurple: Color;
begin
  Result := Statics.get_MediumPurple;
end;

class function TColors.get_MediumSeaGreen: Color;
begin
  Result := Statics.get_MediumSeaGreen;
end;

class function TColors.get_MediumSlateBlue: Color;
begin
  Result := Statics.get_MediumSlateBlue;
end;

class function TColors.get_MediumSpringGreen: Color;
begin
  Result := Statics.get_MediumSpringGreen;
end;

class function TColors.get_MediumTurquoise: Color;
begin
  Result := Statics.get_MediumTurquoise;
end;

class function TColors.get_MediumVioletRed: Color;
begin
  Result := Statics.get_MediumVioletRed;
end;

class function TColors.get_MidnightBlue: Color;
begin
  Result := Statics.get_MidnightBlue;
end;

class function TColors.get_MintCream: Color;
begin
  Result := Statics.get_MintCream;
end;

class function TColors.get_MistyRose: Color;
begin
  Result := Statics.get_MistyRose;
end;

class function TColors.get_Moccasin: Color;
begin
  Result := Statics.get_Moccasin;
end;

class function TColors.get_NavajoWhite: Color;
begin
  Result := Statics.get_NavajoWhite;
end;

class function TColors.get_Navy: Color;
begin
  Result := Statics.get_Navy;
end;

class function TColors.get_OldLace: Color;
begin
  Result := Statics.get_OldLace;
end;

class function TColors.get_Olive: Color;
begin
  Result := Statics.get_Olive;
end;

class function TColors.get_OliveDrab: Color;
begin
  Result := Statics.get_OliveDrab;
end;

class function TColors.get_Orange: Color;
begin
  Result := Statics.get_Orange;
end;

class function TColors.get_OrangeRed: Color;
begin
  Result := Statics.get_OrangeRed;
end;

class function TColors.get_Orchid: Color;
begin
  Result := Statics.get_Orchid;
end;

class function TColors.get_PaleGoldenrod: Color;
begin
  Result := Statics.get_PaleGoldenrod;
end;

class function TColors.get_PaleGreen: Color;
begin
  Result := Statics.get_PaleGreen;
end;

class function TColors.get_PaleTurquoise: Color;
begin
  Result := Statics.get_PaleTurquoise;
end;

class function TColors.get_PaleVioletRed: Color;
begin
  Result := Statics.get_PaleVioletRed;
end;

class function TColors.get_PapayaWhip: Color;
begin
  Result := Statics.get_PapayaWhip;
end;

class function TColors.get_PeachPuff: Color;
begin
  Result := Statics.get_PeachPuff;
end;

class function TColors.get_Peru: Color;
begin
  Result := Statics.get_Peru;
end;

class function TColors.get_Pink: Color;
begin
  Result := Statics.get_Pink;
end;

class function TColors.get_Plum: Color;
begin
  Result := Statics.get_Plum;
end;

class function TColors.get_PowderBlue: Color;
begin
  Result := Statics.get_PowderBlue;
end;

class function TColors.get_Purple: Color;
begin
  Result := Statics.get_Purple;
end;

class function TColors.get_Red: Color;
begin
  Result := Statics.get_Red;
end;

class function TColors.get_RosyBrown: Color;
begin
  Result := Statics.get_RosyBrown;
end;

class function TColors.get_RoyalBlue: Color;
begin
  Result := Statics.get_RoyalBlue;
end;

class function TColors.get_SaddleBrown: Color;
begin
  Result := Statics.get_SaddleBrown;
end;

class function TColors.get_Salmon: Color;
begin
  Result := Statics.get_Salmon;
end;

class function TColors.get_SandyBrown: Color;
begin
  Result := Statics.get_SandyBrown;
end;

class function TColors.get_SeaGreen: Color;
begin
  Result := Statics.get_SeaGreen;
end;

class function TColors.get_SeaShell: Color;
begin
  Result := Statics.get_SeaShell;
end;

class function TColors.get_Sienna: Color;
begin
  Result := Statics.get_Sienna;
end;

class function TColors.get_Silver: Color;
begin
  Result := Statics.get_Silver;
end;

class function TColors.get_SkyBlue: Color;
begin
  Result := Statics.get_SkyBlue;
end;

class function TColors.get_SlateBlue: Color;
begin
  Result := Statics.get_SlateBlue;
end;

class function TColors.get_SlateGray: Color;
begin
  Result := Statics.get_SlateGray;
end;

class function TColors.get_Snow: Color;
begin
  Result := Statics.get_Snow;
end;

class function TColors.get_SpringGreen: Color;
begin
  Result := Statics.get_SpringGreen;
end;

class function TColors.get_SteelBlue: Color;
begin
  Result := Statics.get_SteelBlue;
end;

class function TColors.get_Tan: Color;
begin
  Result := Statics.get_Tan;
end;

class function TColors.get_Teal: Color;
begin
  Result := Statics.get_Teal;
end;

class function TColors.get_Thistle: Color;
begin
  Result := Statics.get_Thistle;
end;

class function TColors.get_Tomato: Color;
begin
  Result := Statics.get_Tomato;
end;

class function TColors.get_Transparent: Color;
begin
  Result := Statics.get_Transparent;
end;

class function TColors.get_Turquoise: Color;
begin
  Result := Statics.get_Turquoise;
end;

class function TColors.get_Violet: Color;
begin
  Result := Statics.get_Violet;
end;

class function TColors.get_Wheat: Color;
begin
  Result := Statics.get_Wheat;
end;

class function TColors.get_White: Color;
begin
  Result := Statics.get_White;
end;

class function TColors.get_WhiteSmoke: Color;
begin
  Result := Statics.get_WhiteSmoke;
end;

class function TColors.get_Yellow: Color;
begin
  Result := Statics.get_Yellow;
end;

class function TColors.get_YellowGreen: Color;
begin
  Result := Statics.get_YellowGreen;
end;
{$ENDREGION}

end.
