{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Devices.Bluetooth;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.Foundation,
  Winapi.CommonTypes,
  Winapi.Networking.Sockets,
  Winapi.Storage.Streams,
  Winapi.Devices.Enumeration,
  Winapi.Devices,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Devices.Bluetooth.IBluetoothSignalStrengthFilter
  IBluetoothSignalStrengthFilter = interface;
  PIBluetoothSignalStrengthFilter = ^IBluetoothSignalStrengthFilter;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult
  GenericAttributeProfile_IGattReadResult = interface;
  PGenericAttributeProfile_IGattReadResult = ^GenericAttributeProfile_IGattReadResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattReadResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattReadResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCommunicationStatus>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCommunicationStatus>
  IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus = interface;
  PIAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus = ^IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor
  GenericAttributeProfile_IGattDescriptor = interface;
  PGenericAttributeProfile_IGattDescriptor = ^GenericAttributeProfile_IGattDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IIterator_1__GenericAttributeProfile_IGattDescriptor = interface;
  PIIterator_1__GenericAttributeProfile_IGattDescriptor = ^IIterator_1__GenericAttributeProfile_IGattDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IIterable_1__GenericAttributeProfile_IGattDescriptor = interface;
  PIIterable_1__GenericAttributeProfile_IGattDescriptor = ^IIterable_1__GenericAttributeProfile_IGattDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IVectorView_1__GenericAttributeProfile_IGattDescriptor = interface;
  PIVectorView_1__GenericAttributeProfile_IGattDescriptor = ^IVectorView_1__GenericAttributeProfile_IGattDescriptor;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat
  GenericAttributeProfile_IGattPresentationFormat = interface;
  PGenericAttributeProfile_IGattPresentationFormat = ^GenericAttributeProfile_IGattPresentationFormat;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IIterator_1__GenericAttributeProfile_IGattPresentationFormat = interface;
  PIIterator_1__GenericAttributeProfile_IGattPresentationFormat = ^IIterator_1__GenericAttributeProfile_IGattPresentationFormat;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IIterable_1__GenericAttributeProfile_IGattPresentationFormat = interface;
  PIIterable_1__GenericAttributeProfile_IGattPresentationFormat = ^IIterable_1__GenericAttributeProfile_IGattPresentationFormat;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IVectorView_1__GenericAttributeProfile_IGattPresentationFormat = interface;
  PIVectorView_1__GenericAttributeProfile_IGattPresentationFormat = ^IVectorView_1__GenericAttributeProfile_IGattPresentationFormat;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult
  GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface;
  PGenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = ^GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs
  GenericAttributeProfile_IGattValueChangedEventArgs = interface;
  PGenericAttributeProfile_IGattValueChangedEventArgs = ^GenericAttributeProfile_IGattValueChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattCharacteristic__GenericAttributeProfile_IGattValueChangedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattCharacteristic__GenericAttributeProfile_IGattValueChangedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattCharacteristic__GenericAttributeProfile_IGattValueChangedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic
  GenericAttributeProfile_IGattCharacteristic = interface;
  PGenericAttributeProfile_IGattCharacteristic = ^GenericAttributeProfile_IGattCharacteristic;

  // Windows.Devices.Bluetooth.IBluetoothDeviceId
  IBluetoothDeviceId = interface;
  PIBluetoothDeviceId = ^IBluetoothDeviceId;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattSession__IInspectable = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattSession__IInspectable = ^TypedEventHandler_2__GenericAttributeProfile_IGattSession__IInspectable;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatusChangedEventArgs
  GenericAttributeProfile_IGattSessionStatusChangedEventArgs = interface;
  PGenericAttributeProfile_IGattSessionStatusChangedEventArgs = ^GenericAttributeProfile_IGattSessionStatusChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatusChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattSession__GenericAttributeProfile_IGattSessionStatusChangedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattSession__GenericAttributeProfile_IGattSessionStatusChangedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattSession__GenericAttributeProfile_IGattSessionStatusChangedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession
  GenericAttributeProfile_IGattSession = interface;
  PGenericAttributeProfile_IGattSession = ^GenericAttributeProfile_IGattSession;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs
  GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface;
  PGenericAttributeProfile_IGattRequestStateChangedEventArgs = ^GenericAttributeProfile_IGattRequestStateChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattReadRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattReadRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattReadRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest
  GenericAttributeProfile_IGattReadRequest = interface;
  PGenericAttributeProfile_IGattReadRequest = ^GenericAttributeProfile_IGattReadRequest;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadRequest = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattReadRequest = ^IAsyncOperation_1__GenericAttributeProfile_IGattReadRequest;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs
  GenericAttributeProfile_IGattReadRequestedEventArgs = interface;
  PGenericAttributeProfile_IGattReadRequestedEventArgs = ^GenericAttributeProfile_IGattReadRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattReadRequestedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattReadRequestedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattReadRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattWriteRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattWriteRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattWriteRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest
  GenericAttributeProfile_IGattWriteRequest = interface;
  PGenericAttributeProfile_IGattWriteRequest = ^GenericAttributeProfile_IGattWriteRequest;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest>
  IAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest = ^IAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs
  GenericAttributeProfile_IGattWriteRequestedEventArgs = interface;
  PGenericAttributeProfile_IGattWriteRequestedEventArgs = ^GenericAttributeProfile_IGattWriteRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattWriteRequestedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattWriteRequestedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattWriteRequestedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor
  GenericAttributeProfile_IGattLocalDescriptor = interface;
  PGenericAttributeProfile_IGattLocalDescriptor = ^GenericAttributeProfile_IGattLocalDescriptor;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult
  GenericAttributeProfile_IGattLocalDescriptorResult = interface;
  PGenericAttributeProfile_IGattLocalDescriptorResult = ^GenericAttributeProfile_IGattLocalDescriptorResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorParameters
  GenericAttributeProfile_IGattLocalDescriptorParameters = interface;
  PGenericAttributeProfile_IGattLocalDescriptorParameters = ^GenericAttributeProfile_IGattLocalDescriptorParameters;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IIterator_1__GenericAttributeProfile_IGattLocalDescriptor = interface;
  PIIterator_1__GenericAttributeProfile_IGattLocalDescriptor = ^IIterator_1__GenericAttributeProfile_IGattLocalDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IIterable_1__GenericAttributeProfile_IGattLocalDescriptor = interface;
  PIIterable_1__GenericAttributeProfile_IGattLocalDescriptor = ^IIterable_1__GenericAttributeProfile_IGattLocalDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IVectorView_1__GenericAttributeProfile_IGattLocalDescriptor = interface;
  PIVectorView_1__GenericAttributeProfile_IGattLocalDescriptor = ^IVectorView_1__GenericAttributeProfile_IGattLocalDescriptor;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattSubscribedClient__IInspectable = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattSubscribedClient__IInspectable = ^TypedEventHandler_2__GenericAttributeProfile_IGattSubscribedClient__IInspectable;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient
  GenericAttributeProfile_IGattSubscribedClient = interface;
  PGenericAttributeProfile_IGattSubscribedClient = ^GenericAttributeProfile_IGattSubscribedClient;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IIterator_1__GenericAttributeProfile_IGattSubscribedClient = interface;
  PIIterator_1__GenericAttributeProfile_IGattSubscribedClient = ^IIterator_1__GenericAttributeProfile_IGattSubscribedClient;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IIterable_1__GenericAttributeProfile_IGattSubscribedClient = interface;
  PIIterable_1__GenericAttributeProfile_IGattSubscribedClient = ^IIterable_1__GenericAttributeProfile_IGattSubscribedClient;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IVectorView_1__GenericAttributeProfile_IGattSubscribedClient = interface;
  PIVectorView_1__GenericAttributeProfile_IGattSubscribedClient = ^IVectorView_1__GenericAttributeProfile_IGattSubscribedClient;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__IInspectable = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__IInspectable = ^TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__IInspectable;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattReadRequestedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattReadRequestedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattReadRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattWriteRequestedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattWriteRequestedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattWriteRequestedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult
  GenericAttributeProfile_IGattClientNotificationResult = interface;
  PGenericAttributeProfile_IGattClientNotificationResult = ^GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IIterator_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PIIterator_1__GenericAttributeProfile_IGattClientNotificationResult = ^IIterator_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IIterable_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PIIterable_1__GenericAttributeProfile_IGattClientNotificationResult = ^IIterable_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PIVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = ^IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>>
  AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = ^AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>>
  IAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PIAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = ^IAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic
  GenericAttributeProfile_IGattLocalCharacteristic = interface;
  PGenericAttributeProfile_IGattLocalCharacteristic = ^GenericAttributeProfile_IGattLocalCharacteristic;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult
  GenericAttributeProfile_IGattLocalCharacteristicResult = interface;
  PGenericAttributeProfile_IGattLocalCharacteristicResult = ^GenericAttributeProfile_IGattLocalCharacteristicResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IVector_1__GenericAttributeProfile_IGattPresentationFormat = interface;
  PIVector_1__GenericAttributeProfile_IGattPresentationFormat = ^IVector_1__GenericAttributeProfile_IGattPresentationFormat;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicParameters
  GenericAttributeProfile_IGattLocalCharacteristicParameters = interface;
  PGenericAttributeProfile_IGattLocalCharacteristicParameters = ^GenericAttributeProfile_IGattLocalCharacteristicParameters;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IIterator_1__GenericAttributeProfile_IGattLocalCharacteristic = interface;
  PIIterator_1__GenericAttributeProfile_IGattLocalCharacteristic = ^IIterator_1__GenericAttributeProfile_IGattLocalCharacteristic;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IIterable_1__GenericAttributeProfile_IGattLocalCharacteristic = interface;
  PIIterable_1__GenericAttributeProfile_IGattLocalCharacteristic = ^IIterable_1__GenericAttributeProfile_IGattLocalCharacteristic;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic = interface;
  PIVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic = ^IVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalService
  GenericAttributeProfile_IGattLocalService = interface;
  PGenericAttributeProfile_IGattLocalService = ^GenericAttributeProfile_IGattLocalService;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters = interface;
  PGenericAttributeProfile_IGattServiceProviderAdvertisingParameters = ^GenericAttributeProfile_IGattServiceProviderAdvertisingParameters;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceId
  Rfcomm_IRfcommServiceId = interface;
  PRfcomm_IRfcommServiceId = ^Rfcomm_IRfcommServiceId;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IIterator_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface;
  PIIterator_1__GenericAttributeProfile_IGattValueChangedEventArgs = ^IIterator_1__GenericAttributeProfile_IGattValueChangedEventArgs;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IIterable_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface;
  PIIterable_1__GenericAttributeProfile_IGattValueChangedEventArgs = ^IIterable_1__GenericAttributeProfile_IGattValueChangedEventArgs;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IVectorView_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface;
  PIVectorView_1__GenericAttributeProfile_IGattValueChangedEventArgs = ^IVectorView_1__GenericAttributeProfile_IGattValueChangedEventArgs;

  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection
  Background_IGattServiceProviderConnection = interface;
  PBackground_IGattServiceProviderConnection = ^Background_IGattServiceProviderConnection;

  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection2
  Background_IGattServiceProviderConnection2 = interface;
  PBackground_IGattServiceProviderConnection2 = ^Background_IGattServiceProviderConnection2;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>
  IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface;
  PIKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = ^IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>>
  IIterator_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = ^IIterator_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>>
  IIterable_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = ^IIterable_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>
  IMapView_2__HSTRING__Background_IGattServiceProviderConnection = interface;
  PIMapView_2__HSTRING__Background_IGattServiceProviderConnection = ^IMapView_2__HSTRING__Background_IGattServiceProviderConnection;

  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnectionStatics
  Background_IGattServiceProviderConnectionStatics = interface;
  PBackground_IGattServiceProviderConnectionStatics = ^Background_IGattServiceProviderConnectionStatics;

  // Windows.Devices.Bluetooth.IBluetoothClassOfDevice
  IBluetoothClassOfDevice = interface;
  PIBluetoothClassOfDevice = ^IBluetoothClassOfDevice;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService
  Rfcomm_IRfcommDeviceService = interface;
  PRfcomm_IRfcommDeviceService = ^Rfcomm_IRfcommDeviceService;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IIterator_1__Rfcomm_IRfcommDeviceService = interface;
  PIIterator_1__Rfcomm_IRfcommDeviceService = ^IIterator_1__Rfcomm_IRfcommDeviceService;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IIterable_1__Rfcomm_IRfcommDeviceService = interface;
  PIIterable_1__Rfcomm_IRfcommDeviceService = ^IIterable_1__Rfcomm_IRfcommDeviceService;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IVectorView_1__Rfcomm_IRfcommDeviceService = interface;
  PIVectorView_1__Rfcomm_IRfcommDeviceService = ^IVectorView_1__Rfcomm_IRfcommDeviceService;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.IBluetoothDevice,Object>
  TypedEventHandler_2__IBluetoothDevice__IInspectable = interface;
  PTypedEventHandler_2__IBluetoothDevice__IInspectable = ^TypedEventHandler_2__IBluetoothDevice__IInspectable;

  // Windows.Devices.Bluetooth.IBluetoothDevice
  IBluetoothDevice = interface;
  PIBluetoothDevice = ^IBluetoothDevice;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IIterator_1__GenericAttributeProfile_IGattCharacteristic = interface;
  PIIterator_1__GenericAttributeProfile_IGattCharacteristic = ^IIterator_1__GenericAttributeProfile_IGattCharacteristic;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IIterable_1__GenericAttributeProfile_IGattCharacteristic = interface;
  PIIterable_1__GenericAttributeProfile_IGattCharacteristic = ^IIterable_1__GenericAttributeProfile_IGattCharacteristic;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IVectorView_1__GenericAttributeProfile_IGattCharacteristic = interface;
  PIVectorView_1__GenericAttributeProfile_IGattCharacteristic = ^IVectorView_1__GenericAttributeProfile_IGattCharacteristic;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IIterator_1__GenericAttributeProfile_IGattDeviceService = interface;
  PIIterator_1__GenericAttributeProfile_IGattDeviceService = ^IIterator_1__GenericAttributeProfile_IGattDeviceService;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IIterable_1__GenericAttributeProfile_IGattDeviceService = interface;
  PIIterable_1__GenericAttributeProfile_IGattDeviceService = ^IIterable_1__GenericAttributeProfile_IGattDeviceService;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IVectorView_1__GenericAttributeProfile_IGattDeviceService = interface;
  PIVectorView_1__GenericAttributeProfile_IGattDeviceService = ^IVectorView_1__GenericAttributeProfile_IGattDeviceService;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService
  GenericAttributeProfile_IGattDeviceService = interface;
  PGenericAttributeProfile_IGattDeviceService = ^GenericAttributeProfile_IGattDeviceService;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic2
  GenericAttributeProfile_IGattCharacteristic2 = interface;
  PGenericAttributeProfile_IGattCharacteristic2 = ^GenericAttributeProfile_IGattCharacteristic2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult
  GenericAttributeProfile_IGattDescriptorsResult = interface;
  PGenericAttributeProfile_IGattDescriptorsResult = ^GenericAttributeProfile_IGattDescriptorsResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult
  GenericAttributeProfile_IGattWriteResult = interface;
  PGenericAttributeProfile_IGattWriteResult = ^GenericAttributeProfile_IGattWriteResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattWriteResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic3
  GenericAttributeProfile_IGattCharacteristic3 = interface;
  PGenericAttributeProfile_IGattCharacteristic3 = ^GenericAttributeProfile_IGattCharacteristic3;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicStatics
  GenericAttributeProfile_IGattCharacteristicStatics = interface;
  PGenericAttributeProfile_IGattCharacteristicStatics = ^GenericAttributeProfile_IGattCharacteristicStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics
  GenericAttributeProfile_IGattCharacteristicUuidsStatics = interface;
  PGenericAttributeProfile_IGattCharacteristicUuidsStatics = ^GenericAttributeProfile_IGattCharacteristicUuidsStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics2
  GenericAttributeProfile_IGattCharacteristicUuidsStatics2 = interface;
  PGenericAttributeProfile_IGattCharacteristicUuidsStatics2 = ^GenericAttributeProfile_IGattCharacteristicUuidsStatics2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult
  GenericAttributeProfile_IGattCharacteristicsResult = interface;
  PGenericAttributeProfile_IGattCharacteristicsResult = ^GenericAttributeProfile_IGattCharacteristicsResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult2
  GenericAttributeProfile_IGattClientNotificationResult2 = interface;
  PGenericAttributeProfile_IGattClientNotificationResult2 = ^GenericAttributeProfile_IGattClientNotificationResult2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor2
  GenericAttributeProfile_IGattDescriptor2 = interface;
  PGenericAttributeProfile_IGattDescriptor2 = ^GenericAttributeProfile_IGattDescriptor2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorStatics
  GenericAttributeProfile_IGattDescriptorStatics = interface;
  PGenericAttributeProfile_IGattDescriptorStatics = ^GenericAttributeProfile_IGattDescriptorStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorUuidsStatics
  GenericAttributeProfile_IGattDescriptorUuidsStatics = interface;
  PGenericAttributeProfile_IGattDescriptorUuidsStatics = ^GenericAttributeProfile_IGattDescriptorUuidsStatics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.IBluetoothLEDevice,Object>
  TypedEventHandler_2__IBluetoothLEDevice__IInspectable = interface;
  PTypedEventHandler_2__IBluetoothLEDevice__IInspectable = ^TypedEventHandler_2__IBluetoothLEDevice__IInspectable;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice
  IBluetoothLEDevice = interface;
  PIBluetoothLEDevice = ^IBluetoothLEDevice;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService2
  GenericAttributeProfile_IGattDeviceService2 = interface;
  PGenericAttributeProfile_IGattDeviceService2 = ^GenericAttributeProfile_IGattDeviceService2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattOpenStatus>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattOpenStatus>
  IAsyncOperation_1__GenericAttributeProfile_GattOpenStatus = interface;
  PIAsyncOperation_1__GenericAttributeProfile_GattOpenStatus = ^IAsyncOperation_1__GenericAttributeProfile_GattOpenStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult
  GenericAttributeProfile_IGattDeviceServicesResult = interface;
  PGenericAttributeProfile_IGattDeviceServicesResult = ^GenericAttributeProfile_IGattDeviceServicesResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService3
  GenericAttributeProfile_IGattDeviceService3 = interface;
  PGenericAttributeProfile_IGattDeviceService3 = ^GenericAttributeProfile_IGattDeviceService3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattDeviceService = ^IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics
  GenericAttributeProfile_IGattDeviceServiceStatics = interface;
  PGenericAttributeProfile_IGattDeviceServiceStatics = ^GenericAttributeProfile_IGattDeviceServiceStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics2
  GenericAttributeProfile_IGattDeviceServiceStatics2 = interface;
  PGenericAttributeProfile_IGattDeviceServiceStatics2 = ^GenericAttributeProfile_IGattDeviceServiceStatics2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics
  GenericAttributeProfile_IGattPresentationFormatStatics = interface;
  PGenericAttributeProfile_IGattPresentationFormatStatics = ^GenericAttributeProfile_IGattPresentationFormatStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics2
  GenericAttributeProfile_IGattPresentationFormatStatics2 = interface;
  PGenericAttributeProfile_IGattPresentationFormatStatics2 = ^GenericAttributeProfile_IGattPresentationFormatStatics2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatTypesStatics
  GenericAttributeProfile_IGattPresentationFormatTypesStatics = interface;
  PGenericAttributeProfile_IGattPresentationFormatTypesStatics = ^GenericAttributeProfile_IGattPresentationFormatTypesStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattProtocolErrorStatics
  GenericAttributeProfile_IGattProtocolErrorStatics = interface;
  PGenericAttributeProfile_IGattProtocolErrorStatics = ^GenericAttributeProfile_IGattProtocolErrorStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult2
  GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult2 = interface;
  PGenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult2 = ^GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult2
  GenericAttributeProfile_IGattReadResult2 = interface;
  PGenericAttributeProfile_IGattReadResult2 = ^GenericAttributeProfile_IGattReadResult2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction
  GenericAttributeProfile_IGattReliableWriteTransaction = interface;
  PGenericAttributeProfile_IGattReliableWriteTransaction = ^GenericAttributeProfile_IGattReliableWriteTransaction;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction2
  GenericAttributeProfile_IGattReliableWriteTransaction2 = interface;
  PGenericAttributeProfile_IGattReliableWriteTransaction2 = ^GenericAttributeProfile_IGattReliableWriteTransaction2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisementStatusChangedEventArgs
  GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = interface;
  PGenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = ^GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisementStatusChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattServiceProvider__GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = interface;
  PTypedEventHandler_2__GenericAttributeProfile_IGattServiceProvider__GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = ^TypedEventHandler_2__GenericAttributeProfile_IGattServiceProvider__GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider
  GenericAttributeProfile_IGattServiceProvider = interface;
  PGenericAttributeProfile_IGattServiceProvider = ^GenericAttributeProfile_IGattServiceProvider;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider2
  GenericAttributeProfile_IGattServiceProvider2 = interface;
  PGenericAttributeProfile_IGattServiceProvider2 = ^GenericAttributeProfile_IGattServiceProvider2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters2
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters2 = interface;
  PGenericAttributeProfile_IGattServiceProviderAdvertisingParameters2 = ^GenericAttributeProfile_IGattServiceProviderAdvertisingParameters2;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters3
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters3 = interface;
  PGenericAttributeProfile_IGattServiceProviderAdvertisingParameters3 = ^GenericAttributeProfile_IGattServiceProviderAdvertisingParameters3;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult
  GenericAttributeProfile_IGattServiceProviderResult = interface;
  PGenericAttributeProfile_IGattServiceProviderResult = ^GenericAttributeProfile_IGattServiceProviderResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult = ^IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderStatics
  GenericAttributeProfile_IGattServiceProviderStatics = interface;
  PGenericAttributeProfile_IGattServiceProviderStatics = ^GenericAttributeProfile_IGattServiceProviderStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics
  GenericAttributeProfile_IGattServiceUuidsStatics = interface;
  PGenericAttributeProfile_IGattServiceUuidsStatics = ^GenericAttributeProfile_IGattServiceUuidsStatics;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics2
  GenericAttributeProfile_IGattServiceUuidsStatics2 = interface;
  PGenericAttributeProfile_IGattServiceUuidsStatics2 = ^GenericAttributeProfile_IGattServiceUuidsStatics2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession = interface;
  PAsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession = ^AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession>
  IAsyncOperation_1__GenericAttributeProfile_IGattSession = interface;
  PIAsyncOperation_1__GenericAttributeProfile_IGattSession = ^IAsyncOperation_1__GenericAttributeProfile_IGattSession;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatics
  GenericAttributeProfile_IGattSessionStatics = interface;
  PGenericAttributeProfile_IGattSessionStatics = ^GenericAttributeProfile_IGattSessionStatics;

  // Windows.Devices.Bluetooth.IBluetoothAdapter
  IBluetoothAdapter = interface;
  PIBluetoothAdapter = ^IBluetoothAdapter;

  // Windows.Devices.Bluetooth.IBluetoothAdapter2
  IBluetoothAdapter2 = interface;
  PIBluetoothAdapter2 = ^IBluetoothAdapter2;

  // Windows.Devices.Bluetooth.IBluetoothAdapter3
  IBluetoothAdapter3 = interface;
  PIBluetoothAdapter3 = ^IBluetoothAdapter3;

  // Windows.Devices.Bluetooth.IBluetoothAdapter4
  IBluetoothAdapter4 = interface;
  PIBluetoothAdapter4 = ^IBluetoothAdapter4;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothAdapter>
  AsyncOperationCompletedHandler_1__IBluetoothAdapter = interface;
  PAsyncOperationCompletedHandler_1__IBluetoothAdapter = ^AsyncOperationCompletedHandler_1__IBluetoothAdapter;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothAdapter>
  IAsyncOperation_1__IBluetoothAdapter = interface;
  PIAsyncOperation_1__IBluetoothAdapter = ^IAsyncOperation_1__IBluetoothAdapter;

  // Windows.Devices.Bluetooth.IBluetoothAdapterStatics
  IBluetoothAdapterStatics = interface;
  PIBluetoothAdapterStatics = ^IBluetoothAdapterStatics;

  // Windows.Devices.Bluetooth.IBluetoothClassOfDeviceStatics
  IBluetoothClassOfDeviceStatics = interface;
  PIBluetoothClassOfDeviceStatics = ^IBluetoothClassOfDeviceStatics;

  // Windows.Devices.Bluetooth.IBluetoothDevice2
  IBluetoothDevice2 = interface;
  PIBluetoothDevice2 = ^IBluetoothDevice2;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult
  Rfcomm_IRfcommDeviceServicesResult = interface;
  PRfcomm_IRfcommDeviceServicesResult = ^Rfcomm_IRfcommDeviceServicesResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult = interface;
  PAsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult = ^AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult>
  IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult = interface;
  PIAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult = ^IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult;

  // Windows.Devices.Bluetooth.IBluetoothDevice3
  IBluetoothDevice3 = interface;
  PIBluetoothDevice3 = ^IBluetoothDevice3;

  // Windows.Devices.Bluetooth.IBluetoothDevice4
  IBluetoothDevice4 = interface;
  PIBluetoothDevice4 = ^IBluetoothDevice4;

  // Windows.Devices.Bluetooth.IBluetoothDevice5
  IBluetoothDevice5 = interface;
  PIBluetoothDevice5 = ^IBluetoothDevice5;

  // Windows.Devices.Bluetooth.IBluetoothDeviceIdStatics
  IBluetoothDeviceIdStatics = interface;
  PIBluetoothDeviceIdStatics = ^IBluetoothDeviceIdStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothDevice>
  AsyncOperationCompletedHandler_1__IBluetoothDevice = interface;
  PAsyncOperationCompletedHandler_1__IBluetoothDevice = ^AsyncOperationCompletedHandler_1__IBluetoothDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothDevice>
  IAsyncOperation_1__IBluetoothDevice = interface;
  PIAsyncOperation_1__IBluetoothDevice = ^IAsyncOperation_1__IBluetoothDevice;

  // Windows.Devices.Bluetooth.IBluetoothDeviceStatics
  IBluetoothDeviceStatics = interface;
  PIBluetoothDeviceStatics = ^IBluetoothDeviceStatics;

  // Windows.Devices.Bluetooth.IBluetoothDeviceStatics2
  IBluetoothDeviceStatics2 = interface;
  PIBluetoothDeviceStatics2 = ^IBluetoothDeviceStatics2;

  // Windows.Devices.Bluetooth.IBluetoothLEAppearance
  IBluetoothLEAppearance = interface;
  PIBluetoothLEAppearance = ^IBluetoothLEAppearance;

  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceCategoriesStatics
  IBluetoothLEAppearanceCategoriesStatics = interface;
  PIBluetoothLEAppearanceCategoriesStatics = ^IBluetoothLEAppearanceCategoriesStatics;

  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceStatics
  IBluetoothLEAppearanceStatics = interface;
  PIBluetoothLEAppearanceStatics = ^IBluetoothLEAppearanceStatics;

  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceSubcategoriesStatics
  IBluetoothLEAppearanceSubcategoriesStatics = interface;
  PIBluetoothLEAppearanceSubcategoriesStatics = ^IBluetoothLEAppearanceSubcategoriesStatics;

  // Windows.Devices.Bluetooth.IBluetoothLEConnectionParameters
  IBluetoothLEConnectionParameters = interface;
  PIBluetoothLEConnectionParameters = ^IBluetoothLEConnectionParameters;

  // Windows.Devices.Bluetooth.IBluetoothLEConnectionPhyInfo
  IBluetoothLEConnectionPhyInfo = interface;
  PIBluetoothLEConnectionPhyInfo = ^IBluetoothLEConnectionPhyInfo;

  // Windows.Devices.Bluetooth.IBluetoothLEConnectionPhy
  IBluetoothLEConnectionPhy = interface;
  PIBluetoothLEConnectionPhy = ^IBluetoothLEConnectionPhy;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice2
  IBluetoothLEDevice2 = interface;
  PIBluetoothLEDevice2 = ^IBluetoothLEDevice2;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice3
  IBluetoothLEDevice3 = interface;
  PIBluetoothLEDevice3 = ^IBluetoothLEDevice3;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice4
  IBluetoothLEDevice4 = interface;
  PIBluetoothLEDevice4 = ^IBluetoothLEDevice4;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice5
  IBluetoothLEDevice5 = interface;
  PIBluetoothLEDevice5 = ^IBluetoothLEDevice5;

  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersRequest
  IBluetoothLEPreferredConnectionParametersRequest = interface;
  PIBluetoothLEPreferredConnectionParametersRequest = ^IBluetoothLEPreferredConnectionParametersRequest;

  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParameters
  IBluetoothLEPreferredConnectionParameters = interface;
  PIBluetoothLEPreferredConnectionParameters = ^IBluetoothLEPreferredConnectionParameters;

  // Windows.Devices.Bluetooth.IBluetoothLEDevice6
  IBluetoothLEDevice6 = interface;
  PIBluetoothLEDevice6 = ^IBluetoothLEDevice6;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothLEDevice>
  AsyncOperationCompletedHandler_1__IBluetoothLEDevice = interface;
  PAsyncOperationCompletedHandler_1__IBluetoothLEDevice = ^AsyncOperationCompletedHandler_1__IBluetoothLEDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothLEDevice>
  IAsyncOperation_1__IBluetoothLEDevice = interface;
  PIAsyncOperation_1__IBluetoothLEDevice = ^IAsyncOperation_1__IBluetoothLEDevice;

  // Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics
  IBluetoothLEDeviceStatics = interface;
  PIBluetoothLEDeviceStatics = ^IBluetoothLEDeviceStatics;

  // Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics2
  IBluetoothLEDeviceStatics2 = interface;
  PIBluetoothLEDeviceStatics2 = ^IBluetoothLEDeviceStatics2;

  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersStatics
  IBluetoothLEPreferredConnectionParametersStatics = interface;
  PIBluetoothLEPreferredConnectionParametersStatics = ^IBluetoothLEPreferredConnectionParametersStatics;

  // Windows.Devices.Bluetooth.IBluetoothUuidHelperStatics
  IBluetoothUuidHelperStatics = interface;
  PIBluetoothUuidHelperStatics = ^IBluetoothUuidHelperStatics;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService2
  Rfcomm_IRfcommDeviceService2 = interface;
  PRfcomm_IRfcommDeviceService2 = ^Rfcomm_IRfcommDeviceService2;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService3
  Rfcomm_IRfcommDeviceService3 = interface;
  PRfcomm_IRfcommDeviceService3 = ^Rfcomm_IRfcommDeviceService3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService = interface;
  PAsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService = ^AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IAsyncOperation_1__Rfcomm_IRfcommDeviceService = interface;
  PIAsyncOperation_1__Rfcomm_IRfcommDeviceService = ^IAsyncOperation_1__Rfcomm_IRfcommDeviceService;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics
  Rfcomm_IRfcommDeviceServiceStatics = interface;
  PRfcomm_IRfcommDeviceServiceStatics = ^Rfcomm_IRfcommDeviceServiceStatics;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics2
  Rfcomm_IRfcommDeviceServiceStatics2 = interface;
  PRfcomm_IRfcommDeviceServiceStatics2 = ^Rfcomm_IRfcommDeviceServiceStatics2;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceIdStatics
  Rfcomm_IRfcommServiceIdStatics = interface;
  PRfcomm_IRfcommServiceIdStatics = ^Rfcomm_IRfcommServiceIdStatics;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider
  Rfcomm_IRfcommServiceProvider = interface;
  PRfcomm_IRfcommServiceProvider = ^Rfcomm_IRfcommServiceProvider;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider2
  Rfcomm_IRfcommServiceProvider2 = interface;
  PRfcomm_IRfcommServiceProvider2 = ^Rfcomm_IRfcommServiceProvider2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider = interface;
  PAsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider = ^AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider>
  IAsyncOperation_1__Rfcomm_IRfcommServiceProvider = interface;
  PIAsyncOperation_1__Rfcomm_IRfcommServiceProvider = ^IAsyncOperation_1__Rfcomm_IRfcommServiceProvider;

  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProviderStatics
  Rfcomm_IRfcommServiceProviderStatics = interface;
  PRfcomm_IRfcommServiceProviderStatics = ^Rfcomm_IRfcommServiceProviderStatics;

  // Windows.Devices.Bluetooth Enums

  // Windows.Devices.Bluetooth.Background.BluetoothEventTriggeringMode
  Background_BluetoothEventTriggeringMode = (
    Serial = 0,
    Batch = 1,
    KeepLatest = 2
  );
  PBackground_BluetoothEventTriggeringMode = ^Background_BluetoothEventTriggeringMode;

  // Windows.Devices.Bluetooth.BluetoothAddressType
  BluetoothAddressType = (
    &Public = 0,
    Random = 1,
    Unspecified = 2
  );
  PBluetoothAddressType = ^BluetoothAddressType;

  // Windows.Devices.Bluetooth.BluetoothCacheMode
  BluetoothCacheMode = (
    Cached = 0,
    Uncached = 1
  );
  PBluetoothCacheMode = ^BluetoothCacheMode;

  // Windows.Devices.Bluetooth.BluetoothConnectionStatus
  BluetoothConnectionStatus = (
    Disconnected = 0,
    Connected = 1
  );
  PBluetoothConnectionStatus = ^BluetoothConnectionStatus;

  // Windows.Devices.Bluetooth.BluetoothError
  BluetoothError = (
    Success = 0,
    RadioNotAvailable = 1,
    ResourceInUse = 2,
    DeviceNotConnected = 3,
    OtherError = 4,
    DisabledByPolicy = 5,
    NotSupported = 6,
    DisabledByUser = 7,
    ConsentRequired = 8,
    TransportNotSupported = 9
  );
  PBluetoothError = ^BluetoothError;

  // Windows.Devices.Bluetooth.BluetoothLEPreferredConnectionParametersRequestStatus
  BluetoothLEPreferredConnectionParametersRequestStatus = (
    Unspecified = 0,
    Success = 1,
    DeviceNotAvailable = 2,
    AccessDenied = 3
  );
  PBluetoothLEPreferredConnectionParametersRequestStatus = ^BluetoothLEPreferredConnectionParametersRequestStatus;

  // Windows.Devices.Bluetooth.BluetoothMajorClass
  BluetoothMajorClass = (
    Miscellaneous = 0,
    Computer = 1,
    Phone = 2,
    NetworkAccessPoint = 3,
    AudioVideo = 4,
    Peripheral = 5,
    Imaging = 6,
    Wearable = 7,
    Toy = 8,
    Health = 9
  );
  PBluetoothMajorClass = ^BluetoothMajorClass;

  // Windows.Devices.Bluetooth.BluetoothMinorClass
  BluetoothMinorClass = (
    Uncategorized = 0,
    ComputerDesktop = 1,
    ComputerServer = 2,
    ComputerLaptop = 3,
    ComputerHandheld = 4,
    ComputerPalmSize = 5,
    ComputerWearable = 6,
    ComputerTablet = 7,
    PhoneCellular = 1,
    PhoneCordless = 2,
    PhoneSmartPhone = 3,
    PhoneWired = 4,
    PhoneIsdn = 5,
    NetworkFullyAvailable = 0,
    NetworkUsed01To17Percent = 8,
    NetworkUsed17To33Percent = 16,
    NetworkUsed33To50Percent = 24,
    NetworkUsed50To67Percent = 32,
    NetworkUsed67To83Percent = 40,
    NetworkUsed83To99Percent = 48,
    NetworkNoServiceAvailable = 56,
    AudioVideoWearableHeadset = 1,
    AudioVideoHandsFree = 2,
    AudioVideoMicrophone = 4,
    AudioVideoLoudspeaker = 5,
    AudioVideoHeadphones = 6,
    AudioVideoPortableAudio = 7,
    AudioVideoCarAudio = 8,
    AudioVideoSetTopBox = 9,
    AudioVideoHifiAudioDevice = 10,
    AudioVideoVcr = 11,
    AudioVideoVideoCamera = 12,
    AudioVideoCamcorder = 13,
    AudioVideoVideoMonitor = 14,
    AudioVideoVideoDisplayAndLoudspeaker = 15,
    AudioVideoVideoConferencing = 16,
    AudioVideoGamingOrToy = 18,
    PeripheralJoystick = 1,
    PeripheralGamepad = 2,
    PeripheralRemoteControl = 3,
    PeripheralSensing = 4,
    PeripheralDigitizerTablet = 5,
    PeripheralCardReader = 6,
    PeripheralDigitalPen = 7,
    PeripheralHandheldScanner = 8,
    PeripheralHandheldGesture = 9,
    WearableWristwatch = 1,
    WearablePager = 2,
    WearableJacket = 3,
    WearableHelmet = 4,
    WearableGlasses = 5,
    ToyRobot = 1,
    ToyVehicle = 2,
    ToyDoll = 3,
    ToyController = 4,
    ToyGame = 5,
    HealthBloodPressureMonitor = 1,
    HealthThermometer = 2,
    HealthWeighingScale = 3,
    HealthGlucoseMeter = 4,
    HealthPulseOximeter = 5,
    HealthHeartRateMonitor = 6,
    HealthHealthDataDisplay = 7,
    HealthStepCounter = 8,
    HealthBodyCompositionAnalyzer = 9,
    HealthPeakFlowMonitor = 10,
    HealthMedicationMonitor = 11,
    HealthKneeProsthesis = 12,
    HealthAnkleProsthesis = 13,
    HealthGenericHealthManager = 14,
    HealthPersonalMobilityDevice = 15
  );
  PBluetoothMinorClass = ^BluetoothMinorClass;

  // Windows.Devices.Bluetooth.BluetoothServiceCapabilities
  BluetoothServiceCapabilities = (
    None = 0,
    LimitedDiscoverableMode = 1,
    PositioningService = 8,
    NetworkingService = 16,
    RenderingService = 32,
    CapturingService = 64,
    ObjectTransferService = 128,
    AudioService = 256,
    TelephoneService = 512,
    InformationService = 1024
  );
  PBluetoothServiceCapabilities = ^BluetoothServiceCapabilities;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristicProperties
  GenericAttributeProfile_GattCharacteristicProperties = (
    None = 0,
    Broadcast = 1,
    Read = 2,
    WriteWithoutResponse = 4,
    Write = 8,
    Notify = 16,
    Indicate = 32,
    AuthenticatedSignedWrites = 64,
    ExtendedProperties = 128,
    ReliableWrites = 256,
    WritableAuxiliaries = 512
  );
  PGenericAttributeProfile_GattCharacteristicProperties = ^GenericAttributeProfile_GattCharacteristicProperties;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientCharacteristicConfigurationDescriptorValue
  GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue = (
    None = 0,
    Notify = 1,
    Indicate = 2
  );
  PGenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue = ^GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattCommunicationStatus
  GenericAttributeProfile_GattCommunicationStatus = (
    Success = 0,
    Unreachable = 1,
    ProtocolError = 2,
    AccessDenied = 3
  );
  PGenericAttributeProfile_GattCommunicationStatus = ^GenericAttributeProfile_GattCommunicationStatus;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattOpenStatus
  GenericAttributeProfile_GattOpenStatus = (
    Unspecified = 0,
    Success = 1,
    AlreadyOpened = 2,
    NotFound = 3,
    SharingViolation = 4,
    AccessDenied = 5
  );
  PGenericAttributeProfile_GattOpenStatus = ^GenericAttributeProfile_GattOpenStatus;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattProtectionLevel
  GenericAttributeProfile_GattProtectionLevel = (
    Plain = 0,
    AuthenticationRequired = 1,
    EncryptionRequired = 2,
    EncryptionAndAuthenticationRequired = 3
  );
  PGenericAttributeProfile_GattProtectionLevel = ^GenericAttributeProfile_GattProtectionLevel;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattRequestState
  GenericAttributeProfile_GattRequestState = (
    Pending = 0,
    Completed = 1,
    Canceled = 2
  );
  PGenericAttributeProfile_GattRequestState = ^GenericAttributeProfile_GattRequestState;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProviderAdvertisementStatus
  GenericAttributeProfile_GattServiceProviderAdvertisementStatus = (
    Created = 0,
    Stopped = 1,
    Started = 2,
    Aborted = 3,
    StartedWithoutAllAdvertisementData = 4
  );
  PGenericAttributeProfile_GattServiceProviderAdvertisementStatus = ^GenericAttributeProfile_GattServiceProviderAdvertisementStatus;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattSessionStatus
  GenericAttributeProfile_GattSessionStatus = (
    Closed = 0,
    Active = 1
  );
  PGenericAttributeProfile_GattSessionStatus = ^GenericAttributeProfile_GattSessionStatus;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattSharingMode
  GenericAttributeProfile_GattSharingMode = (
    Unspecified = 0,
    Exclusive = 1,
    SharedReadOnly = 2,
    SharedReadAndWrite = 3
  );
  PGenericAttributeProfile_GattSharingMode = ^GenericAttributeProfile_GattSharingMode;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteOption
  GenericAttributeProfile_GattWriteOption = (
    WriteWithResponse = 0,
    WriteWithoutResponse = 1
  );
  PGenericAttributeProfile_GattWriteOption = ^GenericAttributeProfile_GattWriteOption;

  // Windows.Devices.Bluetooth Interfaces

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothSignalStrengthFilter
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothSignalStrengthFilter)]
  IBluetoothSignalStrengthFilter = interface(IInspectable)
  ['{DF7B7391-6BB5-4CFE-90B1-5D7324EDCF7F}']
    function get_InRangeThresholdInDBm: IReference_1__SmallInt; safecall;
    procedure put_InRangeThresholdInDBm(value: IReference_1__SmallInt); safecall;
    function get_OutOfRangeThresholdInDBm: IReference_1__SmallInt; safecall;
    procedure put_OutOfRangeThresholdInDBm(value: IReference_1__SmallInt); safecall;
    function get_OutOfRangeTimeout: IReference_1__TimeSpan; safecall;
    procedure put_OutOfRangeTimeout(value: IReference_1__TimeSpan); safecall;
    function get_SamplingInterval: IReference_1__TimeSpan; safecall;
    procedure put_SamplingInterval(value: IReference_1__TimeSpan); safecall;
    property InRangeThresholdInDBm: IReference_1__SmallInt read get_InRangeThresholdInDBm write put_InRangeThresholdInDBm;
    property OutOfRangeThresholdInDBm: IReference_1__SmallInt read get_OutOfRangeThresholdInDBm write put_OutOfRangeThresholdInDBm;
    property OutOfRangeTimeout: IReference_1__TimeSpan read get_OutOfRangeTimeout write put_OutOfRangeTimeout;
    property SamplingInterval: IReference_1__TimeSpan read get_SamplingInterval write put_SamplingInterval;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult
  GenericAttributeProfile_IGattReadResult = interface(IInspectable)
  ['{63A66F08-1AEA-4C4C-A50F-97BAE474B348}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_Value: IBuffer; safecall;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
    property Value: IBuffer read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult = interface(IUnknown)
  ['{D8992AA0-EAC2-55B7-92C5-894886BEB0CA}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattReadResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadResult = interface(IInspectable)
  ['{D40432A8-1E14-51D0-B49B-AE2CE1AA05E5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult; safecall;
    function GetResults: GenericAttributeProfile_IGattReadResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCommunicationStatus>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus = interface(IUnknown)
  ['{2154117A-978D-59DB-99CF-6B690CB3389B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCommunicationStatus>
  IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus = interface(IInspectable)
  ['{3FF69516-1BFB-52E9-9EE6-E5CDB78E1683}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus; safecall;
    function GetResults: GenericAttributeProfile_GattCommunicationStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattCommunicationStatus read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDescriptor)]
  GenericAttributeProfile_IGattDescriptor = interface(IInspectable)
  ['{92055F2B-8084-4344-B4C2-284DE19A8506}']
    function get_ProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    procedure put_ProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_Uuid: TGuid; safecall;
    function get_AttributeHandle: Word; safecall;
    function ReadValueAsync: IAsyncOperation_1__GenericAttributeProfile_IGattReadResult; overload; safecall;
    function ReadValueAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattReadResult; overload; safecall;
    function WriteValueAsync(value: IBuffer): IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; safecall;
    property AttributeHandle: Word read get_AttributeHandle;
    property ProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ProtectionLevel write put_ProtectionLevel;
    property Uuid: TGuid read get_Uuid;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IIterator_1__GenericAttributeProfile_IGattDescriptor = interface(IInspectable)
  ['{3D8DF436-CEFB-5FFB-858C-4882CE1DA079}']
    function get_Current: GenericAttributeProfile_IGattDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattDescriptor): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IIterable_1__GenericAttributeProfile_IGattDescriptor = interface(IInspectable)
  ['{30E2FFC4-3AA3-5219-9A18-CA2D0B6562E8}']
    function First: IIterator_1__GenericAttributeProfile_IGattDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor>
  IVectorView_1__GenericAttributeProfile_IGattDescriptor = interface(IInspectable)
  ['{F23D1B8A-27DF-547D-9482-1DD9089D8A99}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattPresentationFormat)]
  GenericAttributeProfile_IGattPresentationFormat = interface(IInspectable)
  ['{196D0021-FAAD-45DC-AE5B-2AC3184E84DB}']
    function get_FormatType: Byte; safecall;
    function get_Exponent: Integer; safecall;
    function get_Unit: Word; safecall;
    function get_Namespace: Byte; safecall;
    function get_Description: Word; safecall;
    property Description: Word read get_Description;
    property Exponent: Integer read get_Exponent;
    property FormatType: Byte read get_FormatType;
    property Namespace: Byte read get_Namespace;
    property &Unit: Word read get_Unit;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattPresentationFormat>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IIterator_1__GenericAttributeProfile_IGattPresentationFormat = interface(IInspectable)
  ['{20006C53-5DDA-5319-91B1-C6F28FE65933}']
    function get_Current: GenericAttributeProfile_IGattPresentationFormat; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattPresentationFormat): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattPresentationFormat read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattPresentationFormat>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IIterable_1__GenericAttributeProfile_IGattPresentationFormat = interface(IInspectable)
  ['{D75FCEF1-C10E-5B7B-B130-F5A00314D35D}']
    function First: IIterator_1__GenericAttributeProfile_IGattPresentationFormat; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IVectorView_1__GenericAttributeProfile_IGattPresentationFormat = interface(IInspectable)
  ['{E606B52C-CE92-5CAC-A4C3-6BED39EBB7D2}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattPresentationFormat; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattPresentationFormat; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattPresentationFormat): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult
  GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface(IInspectable)
  ['{63A66F09-1AEA-4C4C-A50F-97BAE474B348}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ClientCharacteristicConfigurationDescriptor: GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue; safecall;
    property ClientCharacteristicConfigurationDescriptor: GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue read get_ClientCharacteristicConfigurationDescriptor;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadClientCharacteristicConfigurationDescriptorResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface(IUnknown)
  ['{98F9A6F3-4D29-5351-8B12-751DC977A331}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadClientCharacteristicConfigurationDescriptorResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult = interface(IInspectable)
  ['{CF4444CC-4077-5719-8366-46E86B983685}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult; safecall;
    function GetResults: GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs
  GenericAttributeProfile_IGattValueChangedEventArgs = interface(IInspectable)
  ['{D21BDB54-06E3-4ED8-A263-ACFAC8BA7313}']
    function get_CharacteristicValue: IBuffer; safecall;
    function get_Timestamp: DateTime; safecall;
    property CharacteristicValue: IBuffer read get_CharacteristicValue;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.GattValueChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattCharacteristic__GenericAttributeProfile_IGattValueChangedEventArgs = interface(IUnknown)
  ['{C1F420F6-6292-5760-A2C9-9DDF98683CFC}']
    procedure Invoke(sender: GenericAttributeProfile_IGattCharacteristic; args: GenericAttributeProfile_IGattValueChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattCharacteristic)]
  GenericAttributeProfile_IGattCharacteristic = interface(IInspectable)
  ['{59CB50C1-5934-4F68-A198-EB864FA44E6B}']
    function GetDescriptors(descriptorUuid: TGuid): IVectorView_1__GenericAttributeProfile_IGattDescriptor; safecall;
    function get_CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties; safecall;
    function get_ProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    procedure put_ProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_UserDescription: HSTRING; safecall;
    function get_Uuid: TGuid; safecall;
    function get_AttributeHandle: Word; safecall;
    function get_PresentationFormats: IVectorView_1__GenericAttributeProfile_IGattPresentationFormat; safecall;
    function ReadValueAsync: IAsyncOperation_1__GenericAttributeProfile_IGattReadResult; overload; safecall;
    function ReadValueAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattReadResult; overload; safecall;
    function WriteValueAsync(value: IBuffer): IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; overload; safecall;
    function WriteValueAsync(value: IBuffer; writeOption: GenericAttributeProfile_GattWriteOption): IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; overload; safecall;
    function ReadClientCharacteristicConfigurationDescriptorAsync: IAsyncOperation_1__GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult; safecall;
    function WriteClientCharacteristicConfigurationDescriptorAsync(clientCharacteristicConfigurationDescriptorValue: GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue): IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; safecall;
    function add_ValueChanged(valueChangedHandler: TypedEventHandler_2__GenericAttributeProfile_IGattCharacteristic__GenericAttributeProfile_IGattValueChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ValueChanged(valueChangedEventCookie: EventRegistrationToken); safecall;
    property AttributeHandle: Word read get_AttributeHandle;
    property CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties read get_CharacteristicProperties;
    property PresentationFormats: IVectorView_1__GenericAttributeProfile_IGattPresentationFormat read get_PresentationFormats;
    property ProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ProtectionLevel write put_ProtectionLevel;
    property UserDescription: HSTRING read get_UserDescription;
    property Uuid: TGuid read get_Uuid;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDeviceId
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothDeviceId)]
  IBluetoothDeviceId = interface(IInspectable)
  ['{C17949AF-57C1-4642-BCCE-E6C06B20AE76}']
    function get_Id: HSTRING; safecall;
    function get_IsClassicDevice: Boolean; safecall;
    function get_IsLowEnergyDevice: Boolean; safecall;
    property Id: HSTRING read get_Id;
    property IsClassicDevice: Boolean read get_IsClassicDevice;
    property IsLowEnergyDevice: Boolean read get_IsLowEnergyDevice;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSession,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattSession__IInspectable = interface(IUnknown)
  ['{6C7EC2EC-9F00-5EA0-9A08-60E5070BCF03}']
    procedure Invoke(sender: GenericAttributeProfile_IGattSession; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatusChangedEventArgs
  GenericAttributeProfile_IGattSessionStatusChangedEventArgs = interface(IInspectable)
  ['{7605B72E-837F-404C-AB34-3163F39DDF32}']
    function get_Error: BluetoothError; safecall;
    function get_Status: GenericAttributeProfile_GattSessionStatus; safecall;
    property Error: BluetoothError read get_Error;
    property Status: GenericAttributeProfile_GattSessionStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSession,Windows.Devices.Bluetooth.GenericAttributeProfile.GattSessionStatusChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatusChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattSession__GenericAttributeProfile_IGattSessionStatusChangedEventArgs = interface(IUnknown)
  ['{0E1210F2-7B6F-543E-8ADB-A61D34AB535D}']
    procedure Invoke(sender: GenericAttributeProfile_IGattSession; args: GenericAttributeProfile_IGattSessionStatusChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattSession)]
  GenericAttributeProfile_IGattSession = interface(IInspectable)
  ['{D23B5143-E04E-4C24-999C-9C256F9856B1}']
    function get_DeviceId: IBluetoothDeviceId; safecall;
    function get_CanMaintainConnection: Boolean; safecall;
    procedure put_MaintainConnection(value: Boolean); safecall;
    function get_MaintainConnection: Boolean; safecall;
    function get_MaxPduSize: Word; safecall;
    function get_SessionStatus: GenericAttributeProfile_GattSessionStatus; safecall;
    function add_MaxPduSizeChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattSession__IInspectable): EventRegistrationToken; safecall;
    procedure remove_MaxPduSizeChanged(token: EventRegistrationToken); safecall;
    function add_SessionStatusChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattSession__GenericAttributeProfile_IGattSessionStatusChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SessionStatusChanged(token: EventRegistrationToken); safecall;
    property CanMaintainConnection: Boolean read get_CanMaintainConnection;
    property DeviceId: IBluetoothDeviceId read get_DeviceId;
    property MaintainConnection: Boolean read get_MaintainConnection write put_MaintainConnection;
    property MaxPduSize: Word read get_MaxPduSize;
    property SessionStatus: GenericAttributeProfile_GattSessionStatus read get_SessionStatus;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs
  GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface(IInspectable)
  ['{E834D92C-27BE-44B3-9D0D-4FC6E808DD3F}']
    function get_State: GenericAttributeProfile_GattRequestState; safecall;
    function get_Error: BluetoothError; safecall;
    property Error: BluetoothError read get_Error;
    property State: GenericAttributeProfile_GattRequestState read get_State;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.GattRequestStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattReadRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface(IUnknown)
  ['{0246E199-5199-5BDB-919D-8544CE30FD71}']
    procedure Invoke(sender: GenericAttributeProfile_IGattReadRequest; args: GenericAttributeProfile_IGattRequestStateChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest
  GenericAttributeProfile_IGattReadRequest = interface(IInspectable)
  ['{F1DD6535-6ACD-42A6-A4BB-D789DAE0043E}']
    function get_Offset: Cardinal; safecall;
    function get_Length: Cardinal; safecall;
    function get_State: GenericAttributeProfile_GattRequestState; safecall;
    function add_StateChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattReadRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    procedure RespondWithValue(value: IBuffer); safecall;
    procedure RespondWithProtocolError(protocolError: Byte); safecall;
    property Length: Cardinal read get_Length;
    property Offset: Cardinal read get_Offset;
    property State: GenericAttributeProfile_GattRequestState read get_State;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadRequest>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest = interface(IUnknown)
  ['{31823848-3AB2-547A-8303-964DCC377C9C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattReadRequest; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadRequest>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequest>
  IAsyncOperation_1__GenericAttributeProfile_IGattReadRequest = interface(IInspectable)
  ['{4732CEC2-D943-5CEB-8281-8D54A21B9A45}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest; safecall;
    function GetResults: GenericAttributeProfile_IGattReadRequest; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattReadRequest read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs
  GenericAttributeProfile_IGattReadRequestedEventArgs = interface(IInspectable)
  ['{93497243-F39C-484B-8AB6-996BA486CFA3}']
    function get_Session: GenericAttributeProfile_IGattSession; safecall;
    function GetDeferral: IDeferral; safecall;
    function GetRequestAsync: IAsyncOperation_1__GenericAttributeProfile_IGattReadRequest; safecall;
    property Session: GenericAttributeProfile_IGattSession read get_Session;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattReadRequestedEventArgs = interface(IUnknown)
  ['{252DCA5C-86E7-5BE1-AEED-F78C6ED466AB}']
    procedure Invoke(sender: GenericAttributeProfile_IGattLocalDescriptor; args: GenericAttributeProfile_IGattReadRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.GattRequestStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattRequestStateChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattWriteRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs = interface(IUnknown)
  ['{7744C6BC-CDCD-5283-9E4F-2E21B49A2EF2}']
    procedure Invoke(sender: GenericAttributeProfile_IGattWriteRequest; args: GenericAttributeProfile_IGattRequestStateChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest
  GenericAttributeProfile_IGattWriteRequest = interface(IInspectable)
  ['{AEB6A9ED-DE2F-4FC2-A9A8-94EA7844F13D}']
    function get_Value: IBuffer; safecall;
    function get_Offset: Cardinal; safecall;
    function get_Option: GenericAttributeProfile_GattWriteOption; safecall;
    function get_State: GenericAttributeProfile_GattRequestState; safecall;
    function add_StateChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattWriteRequest__GenericAttributeProfile_IGattRequestStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    procedure Respond; safecall;
    procedure RespondWithProtocolError(protocolError: Byte); safecall;
    property Offset: Cardinal read get_Offset;
    property Option: GenericAttributeProfile_GattWriteOption read get_Option;
    property State: GenericAttributeProfile_GattRequestState read get_State;
    property Value: IBuffer read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteRequest>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest = interface(IUnknown)
  ['{25B737F6-30FF-558E-BA16-B564C45FDC06}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteRequest>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequest>
  IAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest = interface(IInspectable)
  ['{FB8B3C18-2F60-5B43-B773-146045816E03}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest; safecall;
    function GetResults: GenericAttributeProfile_IGattWriteRequest; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteRequest read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs
  GenericAttributeProfile_IGattWriteRequestedEventArgs = interface(IInspectable)
  ['{2DEC8BBE-A73A-471A-94D5-037DEADD0806}']
    function get_Session: GenericAttributeProfile_IGattSession; safecall;
    function GetDeferral: IDeferral; safecall;
    function GetRequestAsync: IAsyncOperation_1__GenericAttributeProfile_IGattWriteRequest; safecall;
    property Session: GenericAttributeProfile_IGattSession read get_Session;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattWriteRequestedEventArgs = interface(IUnknown)
  ['{6CF5B169-3731-591B-AE7C-D939FAAA8A71}']
    procedure Invoke(sender: GenericAttributeProfile_IGattLocalDescriptor; args: GenericAttributeProfile_IGattWriteRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor
  GenericAttributeProfile_IGattLocalDescriptor = interface(IInspectable)
  ['{F48EBE06-789D-4A4B-8652-BD017B5D2FC6}']
    function get_Uuid: TGuid; safecall;
    function get_StaticValue: IBuffer; safecall;
    function get_ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    function get_WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    function add_ReadRequested(handler: TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattReadRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadRequested(token: EventRegistrationToken); safecall;
    function add_WriteRequested(handler: TypedEventHandler_2__GenericAttributeProfile_IGattLocalDescriptor__GenericAttributeProfile_IGattWriteRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_WriteRequested(token: EventRegistrationToken); safecall;
    property ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ReadProtectionLevel;
    property StaticValue: IBuffer read get_StaticValue;
    property Uuid: TGuid read get_Uuid;
    property WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_WriteProtectionLevel;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult
  GenericAttributeProfile_IGattLocalDescriptorResult = interface(IInspectable)
  ['{375791BE-321F-4366-BFC1-3BC6B82C79F8}']
    function get_Descriptor: GenericAttributeProfile_IGattLocalDescriptor; safecall;
    function get_Error: BluetoothError; safecall;
    property Descriptor: GenericAttributeProfile_IGattLocalDescriptor read get_Descriptor;
    property Error: BluetoothError read get_Error;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptorResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult = interface(IUnknown)
  ['{F2927EEC-47D9-5338-9BA5-5BE8461AD410}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptorResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult = interface(IInspectable)
  ['{3EF6D808-754F-5040-97AC-0703309C574F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult; safecall;
    function GetResults: GenericAttributeProfile_IGattLocalDescriptorResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalDescriptorResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorParameters
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattLocalDescriptorParameters)]
  GenericAttributeProfile_IGattLocalDescriptorParameters = interface(IInspectable)
  ['{5FDEDE6A-F3C1-4B66-8C4B-E3D2293B40E9}']
    procedure put_StaticValue(value: IBuffer); safecall;
    function get_StaticValue: IBuffer; safecall;
    procedure put_ReadProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    procedure put_WriteProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    property ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ReadProtectionLevel write put_ReadProtectionLevel;
    property StaticValue: IBuffer read get_StaticValue write put_StaticValue;
    property WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_WriteProtectionLevel write put_WriteProtectionLevel;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IIterator_1__GenericAttributeProfile_IGattLocalDescriptor = interface(IInspectable)
  ['{08023045-5F5C-59CC-ABD3-BBCFE6FA7030}']
    function get_Current: GenericAttributeProfile_IGattLocalDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattLocalDescriptor): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattLocalDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IIterable_1__GenericAttributeProfile_IGattLocalDescriptor = interface(IInspectable)
  ['{9016E9A2-C9F7-5D09-B0AE-552FA67796AE}']
    function First: IIterator_1__GenericAttributeProfile_IGattLocalDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptor>
  IVectorView_1__GenericAttributeProfile_IGattLocalDescriptor = interface(IInspectable)
  ['{F28FF66D-95D2-5DFE-B92C-E222DC58A527}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattLocalDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattLocalDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattLocalDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSubscribedClient,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattSubscribedClient__IInspectable = interface(IUnknown)
  ['{9C17A110-806D-594B-B33D-ED280BBF27E5}']
    procedure Invoke(sender: GenericAttributeProfile_IGattSubscribedClient; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient
  GenericAttributeProfile_IGattSubscribedClient = interface(IInspectable)
  ['{736E9001-15A4-4EC2-9248-E3F20D463BE9}']
    function get_Session: GenericAttributeProfile_IGattSession; safecall;
    function get_MaxNotificationSize: Word; safecall;
    function add_MaxNotificationSizeChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattSubscribedClient__IInspectable): EventRegistrationToken; safecall;
    procedure remove_MaxNotificationSizeChanged(token: EventRegistrationToken); safecall;
    property MaxNotificationSize: Word read get_MaxNotificationSize;
    property Session: GenericAttributeProfile_IGattSession read get_Session;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSubscribedClient>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IIterator_1__GenericAttributeProfile_IGattSubscribedClient = interface(IInspectable)
  ['{DF039115-A5FF-5D5A-B07B-20B42E078765}']
    function get_Current: GenericAttributeProfile_IGattSubscribedClient; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattSubscribedClient): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattSubscribedClient read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSubscribedClient>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IIterable_1__GenericAttributeProfile_IGattSubscribedClient = interface(IInspectable)
  ['{B19864E4-F2B1-50DE-8C11-FFF9ECA934E9}']
    function First: IIterator_1__GenericAttributeProfile_IGattSubscribedClient; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSubscribedClient>
  IVectorView_1__GenericAttributeProfile_IGattSubscribedClient = interface(IInspectable)
  ['{AC454392-B7E9-5F81-B490-8C22736E8FAF}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattSubscribedClient; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattSubscribedClient; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattSubscribedClient): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristic,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Object>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__IInspectable = interface(IUnknown)
  ['{8087ACD6-AED7-53EB-9B23-4808BB910C17}']
    procedure Invoke(sender: GenericAttributeProfile_IGattLocalCharacteristic; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.GattReadRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattReadRequestedEventArgs = interface(IUnknown)
  ['{218A3E4A-AA9D-500E-BCA7-047751BB10A3}']
    procedure Invoke(sender: GenericAttributeProfile_IGattLocalCharacteristic; args: GenericAttributeProfile_IGattReadRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteRequestedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattWriteRequestedEventArgs = interface(IUnknown)
  ['{ED61A2FB-7D2A-5BA3-8EBF-8AD878E539A9}']
    procedure Invoke(sender: GenericAttributeProfile_IGattLocalCharacteristic; args: GenericAttributeProfile_IGattWriteRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult
  GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{506D5599-0112-419A-8E3B-AE21AFABD2C2}']
    function get_SubscribedClient: GenericAttributeProfile_IGattSubscribedClient; safecall;
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ProtocolError: IReference_1__Byte; safecall;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
    property SubscribedClient: GenericAttributeProfile_IGattSubscribedClient read get_SubscribedClient;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IIterator_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{FCA87386-A3AB-55E2-A83E-21F5BFAB4049}']
    function get_Current: GenericAttributeProfile_IGattClientNotificationResult; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattClientNotificationResult): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattClientNotificationResult read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IIterable_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{D3F4B8AD-251F-5BBB-ADA2-EA47434E74D6}']
    function First: IIterator_1__GenericAttributeProfile_IGattClientNotificationResult; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{4865DCB2-E33A-5D5E-9256-8825E5354F91}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattClientNotificationResult; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattClientNotificationResult; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattClientNotificationResult): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>>
  AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IUnknown)
  ['{2F6C4343-667F-5D74-8EE7-B39DE335A960}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>>
  IAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{B6FA5848-ACCD-536B-A37E-2444D86F2C1F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult; safecall;
    function GetResults: IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IUnknown)
  ['{9783FEF1-1B62-5418-9898-933138C2BD14}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattClientNotificationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult = interface(IInspectable)
  ['{DE27C5CF-6227-5829-B997-88E575AD0680}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult; safecall;
    function GetResults: GenericAttributeProfile_IGattClientNotificationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattClientNotificationResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic
  GenericAttributeProfile_IGattLocalCharacteristic = interface(IInspectable)
  ['{AEDE376D-5412-4D74-92A8-8DEB8526829C}']
    function get_Uuid: TGuid; safecall;
    function get_StaticValue: IBuffer; safecall;
    function get_CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties; safecall;
    function get_ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    function get_WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    function CreateDescriptorAsync(descriptorUuid: TGuid; parameters: GenericAttributeProfile_IGattLocalDescriptorParameters): IAsyncOperation_1__GenericAttributeProfile_IGattLocalDescriptorResult; safecall;
    function get_Descriptors: IVectorView_1__GenericAttributeProfile_IGattLocalDescriptor; safecall;
    function get_UserDescription: HSTRING; safecall;
    function get_PresentationFormats: IVectorView_1__GenericAttributeProfile_IGattPresentationFormat; safecall;
    function get_SubscribedClients: IVectorView_1__GenericAttributeProfile_IGattSubscribedClient; safecall;
    function add_SubscribedClientsChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__IInspectable): EventRegistrationToken; safecall;
    procedure remove_SubscribedClientsChanged(token: EventRegistrationToken); safecall;
    function add_ReadRequested(handler: TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattReadRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadRequested(token: EventRegistrationToken); safecall;
    function add_WriteRequested(handler: TypedEventHandler_2__GenericAttributeProfile_IGattLocalCharacteristic__GenericAttributeProfile_IGattWriteRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_WriteRequested(token: EventRegistrationToken); safecall;
    function NotifyValueAsync(value: IBuffer): IAsyncOperation_1__IVectorView_1__GenericAttributeProfile_IGattClientNotificationResult; overload; safecall;
    function NotifyValueAsync(value: IBuffer; subscribedClient: GenericAttributeProfile_IGattSubscribedClient): IAsyncOperation_1__GenericAttributeProfile_IGattClientNotificationResult; overload; safecall;
    property CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties read get_CharacteristicProperties;
    property Descriptors: IVectorView_1__GenericAttributeProfile_IGattLocalDescriptor read get_Descriptors;
    property PresentationFormats: IVectorView_1__GenericAttributeProfile_IGattPresentationFormat read get_PresentationFormats;
    property ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ReadProtectionLevel;
    property StaticValue: IBuffer read get_StaticValue;
    property SubscribedClients: IVectorView_1__GenericAttributeProfile_IGattSubscribedClient read get_SubscribedClients;
    property UserDescription: HSTRING read get_UserDescription;
    property Uuid: TGuid read get_Uuid;
    property WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_WriteProtectionLevel;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult
  GenericAttributeProfile_IGattLocalCharacteristicResult = interface(IInspectable)
  ['{7975DE9B-0170-4397-9666-92F863F12EE6}']
    function get_Characteristic: GenericAttributeProfile_IGattLocalCharacteristic; safecall;
    function get_Error: BluetoothError; safecall;
    property Characteristic: GenericAttributeProfile_IGattLocalCharacteristic read get_Characteristic;
    property Error: BluetoothError read get_Error;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristicResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult = interface(IUnknown)
  ['{85C70EDD-D815-5284-8C84-58A8F769E388}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristicResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult = interface(IInspectable)
  ['{1F97164E-88D5-567D-90F9-75D4F6455274}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult; safecall;
    function GetResults: GenericAttributeProfile_IGattLocalCharacteristicResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattLocalCharacteristicResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattPresentationFormat>
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat>
  IVector_1__GenericAttributeProfile_IGattPresentationFormat = interface(IInspectable)
  ['{CBA635EF-1C70-5412-8EDE-7316276B9EE4}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattPresentationFormat; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__GenericAttributeProfile_IGattPresentationFormat; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattPresentationFormat; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: GenericAttributeProfile_IGattPresentationFormat); safecall;
    procedure InsertAt(index: Cardinal; value: GenericAttributeProfile_IGattPresentationFormat); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: GenericAttributeProfile_IGattPresentationFormat); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattPresentationFormat): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattPresentationFormat); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicParameters
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattLocalCharacteristicParameters)]
  GenericAttributeProfile_IGattLocalCharacteristicParameters = interface(IInspectable)
  ['{FAF73DB4-4CFF-44C7-8445-040E6EAD0063}']
    procedure put_StaticValue(value: IBuffer); safecall;
    function get_StaticValue: IBuffer; safecall;
    procedure put_CharacteristicProperties(value: GenericAttributeProfile_GattCharacteristicProperties); safecall;
    function get_CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties; safecall;
    procedure put_ReadProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    procedure put_WriteProtectionLevel(value: GenericAttributeProfile_GattProtectionLevel); safecall;
    function get_WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel; safecall;
    procedure put_UserDescription(value: HSTRING); safecall;
    function get_UserDescription: HSTRING; safecall;
    function get_PresentationFormats: IVector_1__GenericAttributeProfile_IGattPresentationFormat; safecall;
    property CharacteristicProperties: GenericAttributeProfile_GattCharacteristicProperties read get_CharacteristicProperties write put_CharacteristicProperties;
    property PresentationFormats: IVector_1__GenericAttributeProfile_IGattPresentationFormat read get_PresentationFormats;
    property ReadProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_ReadProtectionLevel write put_ReadProtectionLevel;
    property StaticValue: IBuffer read get_StaticValue write put_StaticValue;
    property UserDescription: HSTRING read get_UserDescription write put_UserDescription;
    property WriteProtectionLevel: GenericAttributeProfile_GattProtectionLevel read get_WriteProtectionLevel write put_WriteProtectionLevel;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristic>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IIterator_1__GenericAttributeProfile_IGattLocalCharacteristic = interface(IInspectable)
  ['{EDD74875-8E85-546F-83B8-1E00AA896419}']
    function get_Current: GenericAttributeProfile_IGattLocalCharacteristic; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattLocalCharacteristic): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattLocalCharacteristic read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristic>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IIterable_1__GenericAttributeProfile_IGattLocalCharacteristic = interface(IInspectable)
  ['{7082ED53-37F6-5262-8D09-939BEA9EDBD5}']
    function First: IIterator_1__GenericAttributeProfile_IGattLocalCharacteristic; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristic>
  IVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic = interface(IInspectable)
  ['{03006881-0DAA-5C2A-B84A-C036A8ED3D9D}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattLocalCharacteristic; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattLocalCharacteristic; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattLocalCharacteristic): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalService
  GenericAttributeProfile_IGattLocalService = interface(IInspectable)
  ['{F513E258-F7F7-4902-B803-57FCC7D6FE83}']
    function get_Uuid: TGuid; safecall;
    function CreateCharacteristicAsync(characteristicUuid: TGuid; parameters: GenericAttributeProfile_IGattLocalCharacteristicParameters): IAsyncOperation_1__GenericAttributeProfile_IGattLocalCharacteristicResult; safecall;
    function get_Characteristics: IVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic; safecall;
    property Characteristics: IVectorView_1__GenericAttributeProfile_IGattLocalCharacteristic read get_Characteristics;
    property Uuid: TGuid read get_Uuid;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattServiceProviderAdvertisingParameters)]
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters = interface(IInspectable)
  ['{E2CE31AB-6315-4C22-9BD7-781DBC3D8D82}']
    procedure put_IsConnectable(value: Boolean); safecall;
    function get_IsConnectable: Boolean; safecall;
    procedure put_IsDiscoverable(value: Boolean); safecall;
    function get_IsDiscoverable: Boolean; safecall;
    property IsConnectable: Boolean read get_IsConnectable write put_IsConnectable;
    property IsDiscoverable: Boolean read get_IsDiscoverable write put_IsDiscoverable;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceId
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommServiceId)]
  Rfcomm_IRfcommServiceId = interface(IInspectable)
  ['{22629204-7E02-4017-8136-DA1B6A1B9BBF}']
    function get_Uuid: TGuid; safecall;
    function AsShortId: Cardinal; safecall;
    function AsString: HSTRING; safecall;
    property Uuid: TGuid read get_Uuid;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattValueChangedEventArgs>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IIterator_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface(IInspectable)
  ['{CD20A796-AA22-521D-8E0F-FC6D4A18E287}']
    function get_Current: GenericAttributeProfile_IGattValueChangedEventArgs; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattValueChangedEventArgs): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattValueChangedEventArgs read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattValueChangedEventArgs>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IIterable_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface(IInspectable)
  ['{526A63DF-8827-51B9-9E2C-9D65021A79D7}']
    function First: IIterator_1__GenericAttributeProfile_IGattValueChangedEventArgs; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattValueChangedEventArgs>
  IVectorView_1__GenericAttributeProfile_IGattValueChangedEventArgs = interface(IInspectable)
  ['{F48A117C-6B10-5DB1-BF27-B71F13555BD7}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattValueChangedEventArgs; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattValueChangedEventArgs; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattValueChangedEventArgs): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Background_GattServiceProviderConnection)]
  Background_IGattServiceProviderConnection = interface(IInspectable)
  ['{7FA1B9B9-2F13-40B5-9582-8EB78E98EF13}']
    function get_TriggerId: HSTRING; safecall;
    function get_Service: GenericAttributeProfile_IGattLocalService; safecall;
    procedure Start; safecall;
    property Service: GenericAttributeProfile_IGattLocalService read get_Service;
    property TriggerId: HSTRING read get_TriggerId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection2
  Background_IGattServiceProviderConnection2 = interface(IInspectable)
  ['{90D12BE0-EBC0-484F-AE0A-7EB8B6266BAC}']
    procedure UpdateAdvertisingParameters(parameters: GenericAttributeProfile_IGattServiceProviderAdvertisingParameters); safecall;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>
  IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface(IInspectable)
  ['{35B7A492-E305-565E-AA7E-609DAF95C18B}']
    function get_Key: HSTRING; safecall;
    function get_Value: Background_IGattServiceProviderConnection; safecall;
    property Key: HSTRING read get_Key;
    property Value: Background_IGattServiceProviderConnection read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.GattServiceProviderConnection>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>>
  IIterator_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface(IInspectable)
  ['{6FAF610E-CF1E-50E4-B1CC-F322FCF25036}']
    function get_Current: IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.GattServiceProviderConnection>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>>
  IIterable_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection = interface(IInspectable)
  ['{EB2CECFB-DD6C-5329-8E17-7FB80A84191F}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__Background_IGattServiceProviderConnection; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Devices.Bluetooth.Background.GattServiceProviderConnection>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection>
  IMapView_2__HSTRING__Background_IGattServiceProviderConnection = interface(IInspectable)
  ['{94ECCB06-19AD-5E4F-953E-12C4AEC054E9}']
    function Lookup(key: HSTRING): Background_IGattServiceProviderConnection; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__Background_IGattServiceProviderConnection; out second: IMapView_2__HSTRING__Background_IGattServiceProviderConnection); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Background.IGattServiceProviderConnectionStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Background_GattServiceProviderConnection)]
  Background_IGattServiceProviderConnectionStatics = interface(IInspectable)
  ['{3D509F4B-0B0E-4466-B8CD-6EBDDA1FA17D}']
    function get_AllServices: IMapView_2__HSTRING__Background_IGattServiceProviderConnection; safecall;
    property AllServices: IMapView_2__HSTRING__Background_IGattServiceProviderConnection read get_AllServices;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothClassOfDevice
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothClassOfDevice)]
  IBluetoothClassOfDevice = interface(IInspectable)
  ['{D640227E-D7D7-4661-9454-65039CA17A2B}']
    function get_RawValue: Cardinal; safecall;
    function get_MajorClass: BluetoothMajorClass; safecall;
    function get_MinorClass: BluetoothMinorClass; safecall;
    function get_ServiceCapabilities: BluetoothServiceCapabilities; safecall;
    property MajorClass: BluetoothMajorClass read get_MajorClass;
    property MinorClass: BluetoothMinorClass read get_MinorClass;
    property RawValue: Cardinal read get_RawValue;
    property ServiceCapabilities: BluetoothServiceCapabilities read get_ServiceCapabilities;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommDeviceService)]
  Rfcomm_IRfcommDeviceService = interface(IInspectable)
  ['{AE81FF1F-C5A1-4C40-8C28-F3EFD69062F3}']
    function get_ConnectionHostName: IHostName; safecall;
    function get_ConnectionServiceName: HSTRING; safecall;
    function get_ServiceId: Rfcomm_IRfcommServiceId; safecall;
    function get_ProtectionLevel: SocketProtectionLevel; safecall;
    function get_MaxProtectionLevel: SocketProtectionLevel; safecall;
    function GetSdpRawAttributesAsync: IAsyncOperation_1__IMapView_2__Cardinal__IBuffer; overload; safecall;
    function GetSdpRawAttributesAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__IMapView_2__Cardinal__IBuffer; overload; safecall;
    property ConnectionHostName: IHostName read get_ConnectionHostName;
    property ConnectionServiceName: HSTRING read get_ConnectionServiceName;
    property MaxProtectionLevel: SocketProtectionLevel read get_MaxProtectionLevel;
    property ProtectionLevel: SocketProtectionLevel read get_ProtectionLevel;
    property ServiceId: Rfcomm_IRfcommServiceId read get_ServiceId;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceService>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IIterator_1__Rfcomm_IRfcommDeviceService = interface(IInspectable)
  ['{64AB0132-C64C-5A87-8113-613EF356924C}']
    function get_Current: Rfcomm_IRfcommDeviceService; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PRfcomm_IRfcommDeviceService): Cardinal; safecall;
    property Current: Rfcomm_IRfcommDeviceService read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceService>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IIterable_1__Rfcomm_IRfcommDeviceService = interface(IInspectable)
  ['{3378E9A6-F6E2-50EA-BFEE-B8109631FECA}']
    function First: IIterator_1__Rfcomm_IRfcommDeviceService; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IVectorView_1__Rfcomm_IRfcommDeviceService = interface(IInspectable)
  ['{DB646C4B-561D-568C-96C9-A904005738D7}']
    function GetAt(index: Cardinal): Rfcomm_IRfcommDeviceService; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Rfcomm_IRfcommDeviceService; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PRfcomm_IRfcommDeviceService): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.BluetoothDevice,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.IBluetoothDevice,Object>
  TypedEventHandler_2__IBluetoothDevice__IInspectable = interface(IUnknown)
  ['{DB56CE1C-5E9F-5138-9227-B1A66D60BC1B}']
    procedure Invoke(sender: IBluetoothDevice; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDevice
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothDevice)]
  IBluetoothDevice = interface(IInspectable)
  ['{2335B156-90D2-4A04-AEF5-0E20B9E6B707}']
    function get_DeviceId: HSTRING; safecall;
    function get_HostName: IHostName; safecall;
    function get_Name: HSTRING; safecall;
    function get_ClassOfDevice: IBluetoothClassOfDevice; safecall;
    function get_SdpRecords: IVectorView_1__IBuffer; safecall;
    function get_RfcommServices: IVectorView_1__Rfcomm_IRfcommDeviceService; safecall;
    function get_ConnectionStatus: BluetoothConnectionStatus; safecall;
    function get_BluetoothAddress: UInt64; safecall;
    function add_NameChanged(handler: TypedEventHandler_2__IBluetoothDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_NameChanged(token: EventRegistrationToken); safecall;
    function add_SdpRecordsChanged(handler: TypedEventHandler_2__IBluetoothDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_SdpRecordsChanged(token: EventRegistrationToken); safecall;
    function add_ConnectionStatusChanged(handler: TypedEventHandler_2__IBluetoothDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ConnectionStatusChanged(token: EventRegistrationToken); safecall;
    property BluetoothAddress: UInt64 read get_BluetoothAddress;
    property ClassOfDevice: IBluetoothClassOfDevice read get_ClassOfDevice;
    property ConnectionStatus: BluetoothConnectionStatus read get_ConnectionStatus;
    property DeviceId: HSTRING read get_DeviceId;
    property HostName: IHostName read get_HostName;
    property Name: HSTRING read get_Name;
    property RfcommServices: IVectorView_1__Rfcomm_IRfcommDeviceService read get_RfcommServices;
    property SdpRecords: IVectorView_1__IBuffer read get_SdpRecords;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristic>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IIterator_1__GenericAttributeProfile_IGattCharacteristic = interface(IInspectable)
  ['{1FFC4777-4346-5564-B7A5-59EAE385F4F6}']
    function get_Current: GenericAttributeProfile_IGattCharacteristic; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattCharacteristic): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattCharacteristic read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristic>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IIterable_1__GenericAttributeProfile_IGattCharacteristic = interface(IInspectable)
  ['{E3C56728-7F2D-5A0D-AD38-030D39C60F9F}']
    function First: IIterator_1__GenericAttributeProfile_IGattCharacteristic; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic>
  IVectorView_1__GenericAttributeProfile_IGattCharacteristic = interface(IInspectable)
  ['{F5A70A0F-15F4-57EE-9FE7-0CE390AE530B}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattCharacteristic; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattCharacteristic; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattCharacteristic): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IIterator_1__GenericAttributeProfile_IGattDeviceService = interface(IInspectable)
  ['{8BEB3A26-73CA-50F3-A1D3-418C60A9F3B2}']
    function get_Current: GenericAttributeProfile_IGattDeviceService; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGenericAttributeProfile_IGattDeviceService): Cardinal; safecall;
    property Current: GenericAttributeProfile_IGattDeviceService read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IIterable_1__GenericAttributeProfile_IGattDeviceService = interface(IInspectable)
  ['{4B192E23-4893-56B2-8EFF-439C3AB7FD1F}']
    function First: IIterator_1__GenericAttributeProfile_IGattDeviceService; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IVectorView_1__GenericAttributeProfile_IGattDeviceService = interface(IInspectable)
  ['{C44B7FD0-1C4C-56D8-A640-C159C17F1CF9}']
    function GetAt(index: Cardinal): GenericAttributeProfile_IGattDeviceService; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: GenericAttributeProfile_IGattDeviceService; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGenericAttributeProfile_IGattDeviceService): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDeviceService)]
  GenericAttributeProfile_IGattDeviceService = interface(IInspectable)
  ['{AC7B7C05-B33C-47CF-990F-6B8F5577DF71}']
    function GetCharacteristics(characteristicUuid: TGuid): IVectorView_1__GenericAttributeProfile_IGattCharacteristic; safecall;
    function GetIncludedServices(serviceUuid: TGuid): IVectorView_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function get_DeviceId: HSTRING; safecall;
    function get_Uuid: TGuid; safecall;
    function get_AttributeHandle: Word; safecall;
    property AttributeHandle: Word read get_AttributeHandle;
    property DeviceId: HSTRING read get_DeviceId;
    property Uuid: TGuid read get_Uuid;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic2
  GenericAttributeProfile_IGattCharacteristic2 = interface(IInspectable)
  ['{AE1AB578-EC06-4764-B780-9835A1D35D6E}']
    function get_Service: GenericAttributeProfile_IGattDeviceService; safecall;
    function GetAllDescriptors: IVectorView_1__GenericAttributeProfile_IGattDescriptor; safecall;
    property Service: GenericAttributeProfile_IGattDeviceService read get_Service;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult
  GenericAttributeProfile_IGattDescriptorsResult = interface(IInspectable)
  ['{9BC091F3-95E7-4489-8D25-FF81955A57B9}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ProtocolError: IReference_1__Byte; safecall;
    function get_Descriptors: IVectorView_1__GenericAttributeProfile_IGattDescriptor; safecall;
    property Descriptors: IVectorView_1__GenericAttributeProfile_IGattDescriptor read get_Descriptors;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptorsResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult = interface(IUnknown)
  ['{DF09AE77-F606-53E4-8BA6-799F5992C85E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptorsResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorsResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult = interface(IInspectable)
  ['{CEAF40C7-BE37-52A5-9A1B-63398513E597}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult; safecall;
    function GetResults: GenericAttributeProfile_IGattDescriptorsResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDescriptorsResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult
  GenericAttributeProfile_IGattWriteResult = interface(IInspectable)
  ['{4991DDB1-CB2B-44F7-99FC-D29A2871DC9B}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ProtocolError: IReference_1__Byte; safecall;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult = interface(IUnknown)
  ['{6FA8C9C3-FF7E-5FA1-A2F3-2714CF04B899}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattWriteResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattWriteResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult = interface(IInspectable)
  ['{E83B4534-BD14-5A9B-A53B-17CC02A2A8A8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult; safecall;
    function GetResults: GenericAttributeProfile_IGattWriteResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattWriteResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic3
  GenericAttributeProfile_IGattCharacteristic3 = interface(IInspectable)
  ['{3F3C663E-93D4-406B-B817-DB81F8ED53B3}']
    function GetDescriptorsAsync: IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult; overload; safecall;
    function GetDescriptorsAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult; overload; safecall;
    function GetDescriptorsForUuidAsync(descriptorUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult; overload; safecall;
    function GetDescriptorsForUuidAsync(descriptorUuid: TGuid; cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDescriptorsResult; overload; safecall;
    function WriteValueWithResultAsync(value: IBuffer): IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; overload; safecall;
    function WriteValueWithResultAsync(value: IBuffer; writeOption: GenericAttributeProfile_GattWriteOption): IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; overload; safecall;
    function WriteClientCharacteristicConfigurationDescriptorWithResultAsync(clientCharacteristicConfigurationDescriptorValue: GenericAttributeProfile_GattClientCharacteristicConfigurationDescriptorValue): IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattCharacteristic)]
  GenericAttributeProfile_IGattCharacteristicStatics = interface(IInspectable)
  ['{59CB50C3-5934-4F68-A198-EB864FA44E6B}']
    function ConvertShortIdToUuid(shortId: Word): TGuid; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattCharacteristicUuids)]
  GenericAttributeProfile_IGattCharacteristicUuidsStatics = interface(IInspectable)
  ['{58FA4586-B1DE-470C-B7DE-0D11FF44F4B7}']
    function get_BatteryLevel: TGuid; safecall;
    function get_BloodPressureFeature: TGuid; safecall;
    function get_BloodPressureMeasurement: TGuid; safecall;
    function get_BodySensorLocation: TGuid; safecall;
    function get_CscFeature: TGuid; safecall;
    function get_CscMeasurement: TGuid; safecall;
    function get_GlucoseFeature: TGuid; safecall;
    function get_GlucoseMeasurement: TGuid; safecall;
    function get_GlucoseMeasurementContext: TGuid; safecall;
    function get_HeartRateControlPoint: TGuid; safecall;
    function get_HeartRateMeasurement: TGuid; safecall;
    function get_IntermediateCuffPressure: TGuid; safecall;
    function get_IntermediateTemperature: TGuid; safecall;
    function get_MeasurementInterval: TGuid; safecall;
    function get_RecordAccessControlPoint: TGuid; safecall;
    function get_RscFeature: TGuid; safecall;
    function get_RscMeasurement: TGuid; safecall;
    function get_SCControlPoint: TGuid; safecall;
    function get_SensorLocation: TGuid; safecall;
    function get_TemperatureMeasurement: TGuid; safecall;
    function get_TemperatureType: TGuid; safecall;
    property BatteryLevel: TGuid read get_BatteryLevel;
    property BloodPressureFeature: TGuid read get_BloodPressureFeature;
    property BloodPressureMeasurement: TGuid read get_BloodPressureMeasurement;
    property BodySensorLocation: TGuid read get_BodySensorLocation;
    property CscFeature: TGuid read get_CscFeature;
    property CscMeasurement: TGuid read get_CscMeasurement;
    property GlucoseFeature: TGuid read get_GlucoseFeature;
    property GlucoseMeasurement: TGuid read get_GlucoseMeasurement;
    property GlucoseMeasurementContext: TGuid read get_GlucoseMeasurementContext;
    property HeartRateControlPoint: TGuid read get_HeartRateControlPoint;
    property HeartRateMeasurement: TGuid read get_HeartRateMeasurement;
    property IntermediateCuffPressure: TGuid read get_IntermediateCuffPressure;
    property IntermediateTemperature: TGuid read get_IntermediateTemperature;
    property MeasurementInterval: TGuid read get_MeasurementInterval;
    property RecordAccessControlPoint: TGuid read get_RecordAccessControlPoint;
    property RscFeature: TGuid read get_RscFeature;
    property RscMeasurement: TGuid read get_RscMeasurement;
    property SCControlPoint: TGuid read get_SCControlPoint;
    property SensorLocation: TGuid read get_SensorLocation;
    property TemperatureMeasurement: TGuid read get_TemperatureMeasurement;
    property TemperatureType: TGuid read get_TemperatureType;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattCharacteristicUuids)]
  GenericAttributeProfile_IGattCharacteristicUuidsStatics2 = interface(IInspectable)
  ['{1855B425-D46E-4A2C-9C3F-ED6DEA29E7BE}']
    function get_AlertCategoryId: TGuid; safecall;
    function get_AlertCategoryIdBitMask: TGuid; safecall;
    function get_AlertLevel: TGuid; safecall;
    function get_AlertNotificationControlPoint: TGuid; safecall;
    function get_AlertStatus: TGuid; safecall;
    function get_GapAppearance: TGuid; safecall;
    function get_BootKeyboardInputReport: TGuid; safecall;
    function get_BootKeyboardOutputReport: TGuid; safecall;
    function get_BootMouseInputReport: TGuid; safecall;
    function get_CurrentTime: TGuid; safecall;
    function get_CyclingPowerControlPoint: TGuid; safecall;
    function get_CyclingPowerFeature: TGuid; safecall;
    function get_CyclingPowerMeasurement: TGuid; safecall;
    function get_CyclingPowerVector: TGuid; safecall;
    function get_DateTime: TGuid; safecall;
    function get_DayDateTime: TGuid; safecall;
    function get_DayOfWeek: TGuid; safecall;
    function get_GapDeviceName: TGuid; safecall;
    function get_DstOffset: TGuid; safecall;
    function get_ExactTime256: TGuid; safecall;
    function get_FirmwareRevisionString: TGuid; safecall;
    function get_HardwareRevisionString: TGuid; safecall;
    function get_HidControlPoint: TGuid; safecall;
    function get_HidInformation: TGuid; safecall;
    function get_Ieee1107320601RegulatoryCertificationDataList: TGuid; safecall;
    function get_LnControlPoint: TGuid; safecall;
    function get_LnFeature: TGuid; safecall;
    function get_LocalTimeInformation: TGuid; safecall;
    function get_LocationAndSpeed: TGuid; safecall;
    function get_ManufacturerNameString: TGuid; safecall;
    function get_ModelNumberString: TGuid; safecall;
    function get_Navigation: TGuid; safecall;
    function get_NewAlert: TGuid; safecall;
    function get_GapPeripheralPreferredConnectionParameters: TGuid; safecall;
    function get_GapPeripheralPrivacyFlag: TGuid; safecall;
    function get_PnpId: TGuid; safecall;
    function get_PositionQuality: TGuid; safecall;
    function get_ProtocolMode: TGuid; safecall;
    function get_GapReconnectionAddress: TGuid; safecall;
    function get_ReferenceTimeInformation: TGuid; safecall;
    function get_Report: TGuid; safecall;
    function get_ReportMap: TGuid; safecall;
    function get_RingerControlPoint: TGuid; safecall;
    function get_RingerSetting: TGuid; safecall;
    function get_ScanIntervalWindow: TGuid; safecall;
    function get_ScanRefresh: TGuid; safecall;
    function get_SerialNumberString: TGuid; safecall;
    function get_GattServiceChanged: TGuid; safecall;
    function get_SoftwareRevisionString: TGuid; safecall;
    function get_SupportedNewAlertCategory: TGuid; safecall;
    function get_SupportUnreadAlertCategory: TGuid; safecall;
    function get_SystemId: TGuid; safecall;
    function get_TimeAccuracy: TGuid; safecall;
    function get_TimeSource: TGuid; safecall;
    function get_TimeUpdateControlPoint: TGuid; safecall;
    function get_TimeUpdateState: TGuid; safecall;
    function get_TimeWithDst: TGuid; safecall;
    function get_TimeZone: TGuid; safecall;
    function get_TxPowerLevel: TGuid; safecall;
    function get_UnreadAlertStatus: TGuid; safecall;
    property AlertCategoryId: TGuid read get_AlertCategoryId;
    property AlertCategoryIdBitMask: TGuid read get_AlertCategoryIdBitMask;
    property AlertLevel: TGuid read get_AlertLevel;
    property AlertNotificationControlPoint: TGuid read get_AlertNotificationControlPoint;
    property AlertStatus: TGuid read get_AlertStatus;
    property BootKeyboardInputReport: TGuid read get_BootKeyboardInputReport;
    property BootKeyboardOutputReport: TGuid read get_BootKeyboardOutputReport;
    property BootMouseInputReport: TGuid read get_BootMouseInputReport;
    property CurrentTime: TGuid read get_CurrentTime;
    property CyclingPowerControlPoint: TGuid read get_CyclingPowerControlPoint;
    property CyclingPowerFeature: TGuid read get_CyclingPowerFeature;
    property CyclingPowerMeasurement: TGuid read get_CyclingPowerMeasurement;
    property CyclingPowerVector: TGuid read get_CyclingPowerVector;
    property DateTime: TGuid read get_DateTime;
    property DayDateTime: TGuid read get_DayDateTime;
    property DayOfWeek: TGuid read get_DayOfWeek;
    property DstOffset: TGuid read get_DstOffset;
    property ExactTime256: TGuid read get_ExactTime256;
    property FirmwareRevisionString: TGuid read get_FirmwareRevisionString;
    property GapAppearance: TGuid read get_GapAppearance;
    property GapDeviceName: TGuid read get_GapDeviceName;
    property GapPeripheralPreferredConnectionParameters: TGuid read get_GapPeripheralPreferredConnectionParameters;
    property GapPeripheralPrivacyFlag: TGuid read get_GapPeripheralPrivacyFlag;
    property GapReconnectionAddress: TGuid read get_GapReconnectionAddress;
    property GattServiceChanged: TGuid read get_GattServiceChanged;
    property HardwareRevisionString: TGuid read get_HardwareRevisionString;
    property HidControlPoint: TGuid read get_HidControlPoint;
    property HidInformation: TGuid read get_HidInformation;
    property Ieee1107320601RegulatoryCertificationDataList: TGuid read get_Ieee1107320601RegulatoryCertificationDataList;
    property LnControlPoint: TGuid read get_LnControlPoint;
    property LnFeature: TGuid read get_LnFeature;
    property LocalTimeInformation: TGuid read get_LocalTimeInformation;
    property LocationAndSpeed: TGuid read get_LocationAndSpeed;
    property ManufacturerNameString: TGuid read get_ManufacturerNameString;
    property ModelNumberString: TGuid read get_ModelNumberString;
    property Navigation: TGuid read get_Navigation;
    property NewAlert: TGuid read get_NewAlert;
    property PnpId: TGuid read get_PnpId;
    property PositionQuality: TGuid read get_PositionQuality;
    property ProtocolMode: TGuid read get_ProtocolMode;
    property ReferenceTimeInformation: TGuid read get_ReferenceTimeInformation;
    property Report: TGuid read get_Report;
    property ReportMap: TGuid read get_ReportMap;
    property RingerControlPoint: TGuid read get_RingerControlPoint;
    property RingerSetting: TGuid read get_RingerSetting;
    property ScanIntervalWindow: TGuid read get_ScanIntervalWindow;
    property ScanRefresh: TGuid read get_ScanRefresh;
    property SerialNumberString: TGuid read get_SerialNumberString;
    property SoftwareRevisionString: TGuid read get_SoftwareRevisionString;
    property SupportUnreadAlertCategory: TGuid read get_SupportUnreadAlertCategory;
    property SupportedNewAlertCategory: TGuid read get_SupportedNewAlertCategory;
    property SystemId: TGuid read get_SystemId;
    property TimeAccuracy: TGuid read get_TimeAccuracy;
    property TimeSource: TGuid read get_TimeSource;
    property TimeUpdateControlPoint: TGuid read get_TimeUpdateControlPoint;
    property TimeUpdateState: TGuid read get_TimeUpdateState;
    property TimeWithDst: TGuid read get_TimeWithDst;
    property TimeZone: TGuid read get_TimeZone;
    property TxPowerLevel: TGuid read get_TxPowerLevel;
    property UnreadAlertStatus: TGuid read get_UnreadAlertStatus;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult
  GenericAttributeProfile_IGattCharacteristicsResult = interface(IInspectable)
  ['{1194945C-B257-4F3E-9DB7-F68BC9A9AEF2}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ProtocolError: IReference_1__Byte; safecall;
    function get_Characteristics: IVectorView_1__GenericAttributeProfile_IGattCharacteristic; safecall;
    property Characteristics: IVectorView_1__GenericAttributeProfile_IGattCharacteristic read get_Characteristics;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
  end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattClientNotificationResult2
  GenericAttributeProfile_IGattClientNotificationResult2 = interface(IInspectable)
  ['{8FAEC497-45E0-497E-9582-29A1FE281AD5}']
    function get_BytesSent: Word; safecall;
    property BytesSent: Word read get_BytesSent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor2
  GenericAttributeProfile_IGattDescriptor2 = interface(IInspectable)
  ['{8F563D39-D630-406C-BA11-10CDD16B0E5E}']
    function WriteValueWithResultAsync(value: IBuffer): IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDescriptor)]
  GenericAttributeProfile_IGattDescriptorStatics = interface(IInspectable)
  ['{92055F2D-8084-4344-B4C2-284DE19A8506}']
    function ConvertShortIdToUuid(shortId: Word): TGuid; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorUuidsStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDescriptorUuids)]
  GenericAttributeProfile_IGattDescriptorUuidsStatics = interface(IInspectable)
  ['{A6F862CE-9CFC-42F1-9185-FF37B75181D3}']
    function get_CharacteristicAggregateFormat: TGuid; safecall;
    function get_CharacteristicExtendedProperties: TGuid; safecall;
    function get_CharacteristicPresentationFormat: TGuid; safecall;
    function get_CharacteristicUserDescription: TGuid; safecall;
    function get_ClientCharacteristicConfiguration: TGuid; safecall;
    function get_ServerCharacteristicConfiguration: TGuid; safecall;
    property CharacteristicAggregateFormat: TGuid read get_CharacteristicAggregateFormat;
    property CharacteristicExtendedProperties: TGuid read get_CharacteristicExtendedProperties;
    property CharacteristicPresentationFormat: TGuid read get_CharacteristicPresentationFormat;
    property CharacteristicUserDescription: TGuid read get_CharacteristicUserDescription;
    property ClientCharacteristicConfiguration: TGuid read get_ClientCharacteristicConfiguration;
    property ServerCharacteristicConfiguration: TGuid read get_ServerCharacteristicConfiguration;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.BluetoothLEDevice,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.IBluetoothLEDevice,Object>
  TypedEventHandler_2__IBluetoothLEDevice__IInspectable = interface(IUnknown)
  ['{A90661E2-372E-5D1E-BBBB-B8A2CE0E7C4D}']
    procedure Invoke(sender: IBluetoothLEDevice; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEDevice)]
  IBluetoothLEDevice = interface(IInspectable)
  ['{B5EE2F7B-4AD8-4642-AC48-80A0B500E887}']
    function get_DeviceId: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_GattServices: IVectorView_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function get_ConnectionStatus: BluetoothConnectionStatus; safecall;
    function get_BluetoothAddress: UInt64; safecall;
    function GetGattService(serviceUuid: TGuid): GenericAttributeProfile_IGattDeviceService; safecall;
    function add_NameChanged(handler: TypedEventHandler_2__IBluetoothLEDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_NameChanged(token: EventRegistrationToken); safecall;
    function add_GattServicesChanged(handler: TypedEventHandler_2__IBluetoothLEDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_GattServicesChanged(token: EventRegistrationToken); safecall;
    function add_ConnectionStatusChanged(handler: TypedEventHandler_2__IBluetoothLEDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ConnectionStatusChanged(token: EventRegistrationToken); safecall;
    property BluetoothAddress: UInt64 read get_BluetoothAddress;
    property ConnectionStatus: BluetoothConnectionStatus read get_ConnectionStatus;
    property DeviceId: HSTRING read get_DeviceId;
    property GattServices: IVectorView_1__GenericAttributeProfile_IGattDeviceService read get_GattServices;
    property Name: HSTRING read get_Name;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService2
  GenericAttributeProfile_IGattDeviceService2 = interface(IInspectable)
  ['{FC54520B-0B0D-4708-BAE0-9FFD9489BC59}']
    function get_Device: IBluetoothLEDevice; safecall;
    function get_ParentServices: IVectorView_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function GetAllCharacteristics: IVectorView_1__GenericAttributeProfile_IGattCharacteristic; safecall;
    function GetAllIncludedServices: IVectorView_1__GenericAttributeProfile_IGattDeviceService; safecall;
    property Device: IBluetoothLEDevice read get_Device;
    property ParentServices: IVectorView_1__GenericAttributeProfile_IGattDeviceService read get_ParentServices;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattOpenStatus>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus = interface(IUnknown)
  ['{548B3CD0-DCE8-5D3D-98AB-6948DD7F90B8}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_GattOpenStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattOpenStatus>
  IAsyncOperation_1__GenericAttributeProfile_GattOpenStatus = interface(IInspectable)
  ['{983201AC-8777-53E8-86E0-63FA684BE1BD}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus; safecall;
    function GetResults: GenericAttributeProfile_GattOpenStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_GattOpenStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristicsResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult = interface(IUnknown)
  ['{D6A15475-1E72-5C56-98E8-88F4BC3E0313}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristicsResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicsResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult = interface(IInspectable)
  ['{0972194A-AC1C-5536-9886-27E58A18F273}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult; safecall;
    function GetResults: GenericAttributeProfile_IGattCharacteristicsResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattCharacteristicsResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult
  GenericAttributeProfile_IGattDeviceServicesResult = interface(IInspectable)
  ['{171DD3EE-016D-419D-838A-576CF475A3D8}']
    function get_Status: GenericAttributeProfile_GattCommunicationStatus; safecall;
    function get_ProtocolError: IReference_1__Byte; safecall;
    function get_Services: IVectorView_1__GenericAttributeProfile_IGattDeviceService; safecall;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
    property Services: IVectorView_1__GenericAttributeProfile_IGattDeviceService read get_Services;
    property Status: GenericAttributeProfile_GattCommunicationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceServicesResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult = interface(IUnknown)
  ['{74AB0892-A631-5D6C-B1B4-BD2E1A741A9B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceServicesResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServicesResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult = interface(IInspectable)
  ['{E7C667F6-E874-500F-86FF-760CA6F07A58}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult; safecall;
    function GetResults: GenericAttributeProfile_IGattDeviceServicesResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceServicesResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService3
  GenericAttributeProfile_IGattDeviceService3 = interface(IInspectable)
  ['{B293A950-0C53-437C-A9B3-5C3210C6E569}']
    function get_DeviceAccessInformation: IDeviceAccessInformation; safecall;
    function get_Session: GenericAttributeProfile_IGattSession; safecall;
    function get_SharingMode: GenericAttributeProfile_GattSharingMode; safecall;
    function RequestAccessAsync: IAsyncOperation_1__DeviceAccessStatus; safecall;
    function OpenAsync(sharingMode: GenericAttributeProfile_GattSharingMode): IAsyncOperation_1__GenericAttributeProfile_GattOpenStatus; safecall;
    function GetCharacteristicsAsync: IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult; overload; safecall;
    function GetCharacteristicsAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult; overload; safecall;
    function GetCharacteristicsForUuidAsync(characteristicUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult; overload; safecall;
    function GetCharacteristicsForUuidAsync(characteristicUuid: TGuid; cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattCharacteristicsResult; overload; safecall;
    function GetIncludedServicesAsync: IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetIncludedServicesAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetIncludedServicesForUuidAsync(serviceUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetIncludedServicesForUuidAsync(serviceUuid: TGuid; cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    property DeviceAccessInformation: IDeviceAccessInformation read get_DeviceAccessInformation;
    property Session: GenericAttributeProfile_IGattSession read get_Session;
    property SharingMode: GenericAttributeProfile_GattSharingMode read get_SharingMode;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService = interface(IUnknown)
  ['{2DBCF64A-262B-5708-ADB1-C3B8750BD680}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService>
  IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService = interface(IInspectable)
  ['{E5E90272-408F-5055-9BD3-88408982D301}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function GetResults: GenericAttributeProfile_IGattDeviceService; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattDeviceService read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDeviceService)]
  GenericAttributeProfile_IGattDeviceServiceStatics = interface(IInspectable)
  ['{196D0022-FAAD-45DC-AE5B-2AC3184E84DB}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function GetDeviceSelectorFromUuid(serviceUuid: TGuid): HSTRING; safecall;
    function GetDeviceSelectorFromShortId(serviceShortId: Word): HSTRING; safecall;
    function ConvertShortIdToUuid(shortId: Word): TGuid; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattDeviceService)]
  GenericAttributeProfile_IGattDeviceServiceStatics2 = interface(IInspectable)
  ['{0604186E-24A6-4B0D-A2F2-30CC01545D25}']
    function FromIdAsync(deviceId: HSTRING; sharingMode: GenericAttributeProfile_GattSharingMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService; safecall;
    function GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId; cacheMode: BluetoothCacheMode): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid; cacheMode: BluetoothCacheMode): HSTRING; overload; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattPresentationFormat)]
  GenericAttributeProfile_IGattPresentationFormatStatics = interface(IInspectable)
  ['{196D0020-FAAD-45DC-AE5B-2AC3184E84DB}']
    function get_BluetoothSigAssignedNumbers: Byte; safecall;
    property BluetoothSigAssignedNumbers: Byte read get_BluetoothSigAssignedNumbers;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattPresentationFormat)]
  GenericAttributeProfile_IGattPresentationFormatStatics2 = interface(IInspectable)
  ['{A9C21713-B82F-435E-B634-21FD85A43C07}']
    function FromParts(formatType: Byte; exponent: Integer; &unit: Word; namespaceId: Byte; description: Word): GenericAttributeProfile_IGattPresentationFormat; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatTypesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattPresentationFormatTypes)]
  GenericAttributeProfile_IGattPresentationFormatTypesStatics = interface(IInspectable)
  ['{FAF1BA0A-30BA-409C-BEF7-CFFB6D03B8FB}']
    function get_Boolean: Byte; safecall;
    function get_Bit2: Byte; safecall;
    function get_Nibble: Byte; safecall;
    function get_UInt8: Byte; safecall;
    function get_UInt12: Byte; safecall;
    function get_UInt16: Byte; safecall;
    function get_UInt24: Byte; safecall;
    function get_UInt32: Byte; safecall;
    function get_UInt48: Byte; safecall;
    function get_UInt64: Byte; safecall;
    function get_UInt128: Byte; safecall;
    function get_SInt8: Byte; safecall;
    function get_SInt12: Byte; safecall;
    function get_SInt16: Byte; safecall;
    function get_SInt24: Byte; safecall;
    function get_SInt32: Byte; safecall;
    function get_SInt48: Byte; safecall;
    function get_SInt64: Byte; safecall;
    function get_SInt128: Byte; safecall;
    function get_Float32: Byte; safecall;
    function get_Float64: Byte; safecall;
    function get_SFloat: Byte; safecall;
    function get_Float: Byte; safecall;
    function get_DUInt16: Byte; safecall;
    function get_Utf8: Byte; safecall;
    function get_Utf16: Byte; safecall;
    function get_Struct: Byte; safecall;
    property Bit2: Byte read get_Bit2;
    property Boolean: Byte read get_Boolean;
    property DUInt16: Byte read get_DUInt16;
    property Float: Byte read get_Float;
    property Float32: Byte read get_Float32;
    property Float64: Byte read get_Float64;
    property Nibble: Byte read get_Nibble;
    property SFloat: Byte read get_SFloat;
    property SInt12: Byte read get_SInt12;
    property SInt128: Byte read get_SInt128;
    property SInt16: Byte read get_SInt16;
    property SInt24: Byte read get_SInt24;
    property SInt32: Byte read get_SInt32;
    property SInt48: Byte read get_SInt48;
    property SInt64: Byte read get_SInt64;
    property SInt8: Byte read get_SInt8;
    property Struct: Byte read get_Struct;
    property UInt12: Byte read get_UInt12;
    property UInt128: Byte read get_UInt128;
    property UInt16: Byte read get_UInt16;
    property UInt24: Byte read get_UInt24;
    property UInt32: Byte read get_UInt32;
    property UInt48: Byte read get_UInt48;
    property UInt64: Byte read get_UInt64;
    property UInt8: Byte read get_UInt8;
    property Utf16: Byte read get_Utf16;
    property Utf8: Byte read get_Utf8;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattProtocolErrorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattProtocolError)]
  GenericAttributeProfile_IGattProtocolErrorStatics = interface(IInspectable)
  ['{CA46C5C5-0ECC-4809-BEA3-CF79BC991E37}']
    function get_InvalidHandle: Byte; safecall;
    function get_ReadNotPermitted: Byte; safecall;
    function get_WriteNotPermitted: Byte; safecall;
    function get_InvalidPdu: Byte; safecall;
    function get_InsufficientAuthentication: Byte; safecall;
    function get_RequestNotSupported: Byte; safecall;
    function get_InvalidOffset: Byte; safecall;
    function get_InsufficientAuthorization: Byte; safecall;
    function get_PrepareQueueFull: Byte; safecall;
    function get_AttributeNotFound: Byte; safecall;
    function get_AttributeNotLong: Byte; safecall;
    function get_InsufficientEncryptionKeySize: Byte; safecall;
    function get_InvalidAttributeValueLength: Byte; safecall;
    function get_UnlikelyError: Byte; safecall;
    function get_InsufficientEncryption: Byte; safecall;
    function get_UnsupportedGroupType: Byte; safecall;
    function get_InsufficientResources: Byte; safecall;
    property AttributeNotFound: Byte read get_AttributeNotFound;
    property AttributeNotLong: Byte read get_AttributeNotLong;
    property InsufficientAuthentication: Byte read get_InsufficientAuthentication;
    property InsufficientAuthorization: Byte read get_InsufficientAuthorization;
    property InsufficientEncryption: Byte read get_InsufficientEncryption;
    property InsufficientEncryptionKeySize: Byte read get_InsufficientEncryptionKeySize;
    property InsufficientResources: Byte read get_InsufficientResources;
    property InvalidAttributeValueLength: Byte read get_InvalidAttributeValueLength;
    property InvalidHandle: Byte read get_InvalidHandle;
    property InvalidOffset: Byte read get_InvalidOffset;
    property InvalidPdu: Byte read get_InvalidPdu;
    property PrepareQueueFull: Byte read get_PrepareQueueFull;
    property ReadNotPermitted: Byte read get_ReadNotPermitted;
    property RequestNotSupported: Byte read get_RequestNotSupported;
    property UnlikelyError: Byte read get_UnlikelyError;
    property UnsupportedGroupType: Byte read get_UnsupportedGroupType;
    property WriteNotPermitted: Byte read get_WriteNotPermitted;
  end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadClientCharacteristicConfigurationDescriptorResult2
  GenericAttributeProfile_IGattReadClientCharacteristicConfigurationDescriptorResult2 = interface(IInspectable)
  ['{1BF1A59D-BA4D-4622-8651-F4EE150D0A5D}']
    function get_ProtocolError: IReference_1__Byte; safecall;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
  end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReadResult2
  GenericAttributeProfile_IGattReadResult2 = interface(IInspectable)
  ['{A10F50A0-FB43-48AF-BAAA-638A5C6329FE}']
    function get_ProtocolError: IReference_1__Byte; safecall;
    property ProtocolError: IReference_1__Byte read get_ProtocolError;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattReliableWriteTransaction)]
  GenericAttributeProfile_IGattReliableWriteTransaction = interface(IInspectable)
  ['{63A66F07-1AEA-4C4C-A50F-97BAE474B348}']
    procedure WriteValue(characteristic: GenericAttributeProfile_IGattCharacteristic; value: IBuffer); safecall;
    function CommitAsync: IAsyncOperation_1__GenericAttributeProfile_GattCommunicationStatus; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction2
  GenericAttributeProfile_IGattReliableWriteTransaction2 = interface(IInspectable)
  ['{51113987-EF12-462F-9FB2-A1A43A679416}']
    function CommitWithResultAsync: IAsyncOperation_1__GenericAttributeProfile_IGattWriteResult; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisementStatusChangedEventArgs
  GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = interface(IInspectable)
  ['{59A5AA65-FA21-4FFC-B155-04D928012686}']
    function get_Error: BluetoothError; safecall;
    function get_Status: GenericAttributeProfile_GattServiceProviderAdvertisementStatus; safecall;
    property Error: BluetoothError read get_Error;
    property Status: GenericAttributeProfile_GattServiceProviderAdvertisementStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProvider,Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProviderAdvertisementStatusChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider,Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisementStatusChangedEventArgs>
  TypedEventHandler_2__GenericAttributeProfile_IGattServiceProvider__GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs = interface(IUnknown)
  ['{56CE41B0-2570-50D3-A1B1-7E4167E1FDE7}']
    procedure Invoke(sender: GenericAttributeProfile_IGattServiceProvider; args: GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattServiceProvider)]
  GenericAttributeProfile_IGattServiceProvider = interface(IInspectable)
  ['{7822B3CD-2889-4F86-A051-3F0AED1C2760}']
    function get_Service: GenericAttributeProfile_IGattLocalService; safecall;
    function get_AdvertisementStatus: GenericAttributeProfile_GattServiceProviderAdvertisementStatus; safecall;
    function add_AdvertisementStatusChanged(handler: TypedEventHandler_2__GenericAttributeProfile_IGattServiceProvider__GenericAttributeProfile_IGattServiceProviderAdvertisementStatusChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AdvertisementStatusChanged(token: EventRegistrationToken); safecall;
    procedure StartAdvertising; overload; safecall;
    procedure StartAdvertising(parameters: GenericAttributeProfile_IGattServiceProviderAdvertisingParameters); overload; safecall;
    procedure StopAdvertising; safecall;
    property AdvertisementStatus: GenericAttributeProfile_GattServiceProviderAdvertisementStatus read get_AdvertisementStatus;
    property Service: GenericAttributeProfile_IGattLocalService read get_Service;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider2
  GenericAttributeProfile_IGattServiceProvider2 = interface(IInspectable)
  ['{9EF531A9-CF12-59A3-A81C-362F4AABAACF}']
    procedure UpdateAdvertisingParameters(parameters: GenericAttributeProfile_IGattServiceProviderAdvertisingParameters); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters2
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters2 = interface(IInspectable)
  ['{FF68468D-CA92-4434-9743-0E90988AD879}']
    procedure put_ServiceData(value: IBuffer); safecall;
    function get_ServiceData: IBuffer; safecall;
    property ServiceData: IBuffer read get_ServiceData write put_ServiceData;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters3
  GenericAttributeProfile_IGattServiceProviderAdvertisingParameters3 = interface(IInspectable)
  ['{A23546B2-B216-5929-9055-F1313DD53E2A}']
    function get_UseLowEnergyUncoded1MPhyAsSecondaryPhy: Boolean; safecall;
    procedure put_UseLowEnergyUncoded1MPhyAsSecondaryPhy(value: Boolean); safecall;
    function get_UseLowEnergyUncoded2MPhyAsSecondaryPhy: Boolean; safecall;
    procedure put_UseLowEnergyUncoded2MPhyAsSecondaryPhy(value: Boolean); safecall;
    property UseLowEnergyUncoded1MPhyAsSecondaryPhy: Boolean read get_UseLowEnergyUncoded1MPhyAsSecondaryPhy write put_UseLowEnergyUncoded1MPhyAsSecondaryPhy;
    property UseLowEnergyUncoded2MPhyAsSecondaryPhy: Boolean read get_UseLowEnergyUncoded2MPhyAsSecondaryPhy write put_UseLowEnergyUncoded2MPhyAsSecondaryPhy;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult
  GenericAttributeProfile_IGattServiceProviderResult = interface(IInspectable)
  ['{764696D8-C53E-428C-8A48-67AFE02C3AE6}']
    function get_Error: BluetoothError; safecall;
    function get_ServiceProvider: GenericAttributeProfile_IGattServiceProvider; safecall;
    property Error: BluetoothError read get_Error;
    property ServiceProvider: GenericAttributeProfile_IGattServiceProvider read get_ServiceProvider;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProviderResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult = interface(IUnknown)
  ['{F992789A-E981-597A-9197-1FBD986F74C7}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProviderResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderResult>
  IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult = interface(IInspectable)
  ['{21781028-F5A2-5D99-A5AB-BCE6554FBC02}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult; safecall;
    function GetResults: GenericAttributeProfile_IGattServiceProviderResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattServiceProviderResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattServiceProvider)]
  GenericAttributeProfile_IGattServiceProviderStatics = interface(IInspectable)
  ['{31794063-5256-4054-A4F4-7BBE7755A57E}']
    function CreateAsync(serviceUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattServiceUuids)]
  GenericAttributeProfile_IGattServiceUuidsStatics = interface(IInspectable)
  ['{6DC57058-9ABA-4417-B8F2-DCE016D34EE2}']
    function get_Battery: TGuid; safecall;
    function get_BloodPressure: TGuid; safecall;
    function get_CyclingSpeedAndCadence: TGuid; safecall;
    function get_GenericAccess: TGuid; safecall;
    function get_GenericAttribute: TGuid; safecall;
    function get_Glucose: TGuid; safecall;
    function get_HealthThermometer: TGuid; safecall;
    function get_HeartRate: TGuid; safecall;
    function get_RunningSpeedAndCadence: TGuid; safecall;
    property Battery: TGuid read get_Battery;
    property BloodPressure: TGuid read get_BloodPressure;
    property CyclingSpeedAndCadence: TGuid read get_CyclingSpeedAndCadence;
    property GenericAccess: TGuid read get_GenericAccess;
    property GenericAttribute: TGuid read get_GenericAttribute;
    property Glucose: TGuid read get_Glucose;
    property HealthThermometer: TGuid read get_HealthThermometer;
    property HeartRate: TGuid read get_HeartRate;
    property RunningSpeedAndCadence: TGuid read get_RunningSpeedAndCadence;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattServiceUuids)]
  GenericAttributeProfile_IGattServiceUuidsStatics2 = interface(IInspectable)
  ['{D2AE94F5-3D15-4F79-9C0C-EAAFA675155C}']
    function get_AlertNotification: TGuid; safecall;
    function get_CurrentTime: TGuid; safecall;
    function get_CyclingPower: TGuid; safecall;
    function get_DeviceInformation: TGuid; safecall;
    function get_HumanInterfaceDevice: TGuid; safecall;
    function get_ImmediateAlert: TGuid; safecall;
    function get_LinkLoss: TGuid; safecall;
    function get_LocationAndNavigation: TGuid; safecall;
    function get_NextDstChange: TGuid; safecall;
    function get_PhoneAlertStatus: TGuid; safecall;
    function get_ReferenceTimeUpdate: TGuid; safecall;
    function get_ScanParameters: TGuid; safecall;
    function get_TxPower: TGuid; safecall;
    property AlertNotification: TGuid read get_AlertNotification;
    property CurrentTime: TGuid read get_CurrentTime;
    property CyclingPower: TGuid read get_CyclingPower;
    property DeviceInformation: TGuid read get_DeviceInformation;
    property HumanInterfaceDevice: TGuid read get_HumanInterfaceDevice;
    property ImmediateAlert: TGuid read get_ImmediateAlert;
    property LinkLoss: TGuid read get_LinkLoss;
    property LocationAndNavigation: TGuid read get_LocationAndNavigation;
    property NextDstChange: TGuid read get_NextDstChange;
    property PhoneAlertStatus: TGuid read get_PhoneAlertStatus;
    property ReferenceTimeUpdate: TGuid read get_ReferenceTimeUpdate;
    property ScanParameters: TGuid read get_ScanParameters;
    property TxPower: TGuid read get_TxPower;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSession>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession>
  AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession = interface(IUnknown)
  ['{CAE01A28-FD33-542E-A5AD-3D878F73DB90}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__GenericAttributeProfile_IGattSession; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.GattSession>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession>
  IAsyncOperation_1__GenericAttributeProfile_IGattSession = interface(IInspectable)
  ['{6D40B467-46B9-516F-8208-DB23B786EA48}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession; safecall;
    function GetResults: GenericAttributeProfile_IGattSession; safecall;
    property Completed: AsyncOperationCompletedHandler_1__GenericAttributeProfile_IGattSession read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_GenericAttributeProfile_GattSession)]
  GenericAttributeProfile_IGattSessionStatics = interface(IInspectable)
  ['{2E65B95C-539F-4DB7-82A8-73BDBBF73EBF}']
    function FromDeviceIdAsync(deviceId: IBluetoothDeviceId): IAsyncOperation_1__GenericAttributeProfile_IGattSession; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothAdapter
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothAdapter)]
  IBluetoothAdapter = interface(IInspectable)
  ['{7974F04C-5F7A-4A34-9225-A855F84B1A8B}']
    function get_DeviceId: HSTRING; safecall;
    function get_BluetoothAddress: UInt64; safecall;
    function get_IsClassicSupported: Boolean; safecall;
    function get_IsLowEnergySupported: Boolean; safecall;
    function get_IsPeripheralRoleSupported: Boolean; safecall;
    function get_IsCentralRoleSupported: Boolean; safecall;
    function get_IsAdvertisementOffloadSupported: Boolean; safecall;
    function GetRadioAsync: IAsyncOperation_1__Radios_IRadio; safecall;
    property BluetoothAddress: UInt64 read get_BluetoothAddress;
    property DeviceId: HSTRING read get_DeviceId;
    property IsAdvertisementOffloadSupported: Boolean read get_IsAdvertisementOffloadSupported;
    property IsCentralRoleSupported: Boolean read get_IsCentralRoleSupported;
    property IsClassicSupported: Boolean read get_IsClassicSupported;
    property IsLowEnergySupported: Boolean read get_IsLowEnergySupported;
    property IsPeripheralRoleSupported: Boolean read get_IsPeripheralRoleSupported;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothAdapter2
  IBluetoothAdapter2 = interface(IInspectable)
  ['{AC94CECC-24D5-41B3-916D-1097C50B102B}']
    function get_AreClassicSecureConnectionsSupported: Boolean; safecall;
    function get_AreLowEnergySecureConnectionsSupported: Boolean; safecall;
    property AreClassicSecureConnectionsSupported: Boolean read get_AreClassicSecureConnectionsSupported;
    property AreLowEnergySecureConnectionsSupported: Boolean read get_AreLowEnergySecureConnectionsSupported;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothAdapter3
  IBluetoothAdapter3 = interface(IInspectable)
  ['{8F8624E0-CBA9-5211-9F89-3AAC62B4C6B8}']
    function get_IsExtendedAdvertisingSupported: Boolean; safecall;
    function get_MaxAdvertisementDataLength: Cardinal; safecall;
    property IsExtendedAdvertisingSupported: Boolean read get_IsExtendedAdvertisingSupported;
    property MaxAdvertisementDataLength: Cardinal read get_MaxAdvertisementDataLength;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothAdapter4
  IBluetoothAdapter4 = interface(IInspectable)
  ['{F875F3E1-6D9A-5D5E-AEE5-A17248E5F6DD}']
    function get_IsLowEnergyUncoded2MPhySupported: Boolean; safecall;
    function get_IsLowEnergyCodedPhySupported: Boolean; safecall;
    property IsLowEnergyCodedPhySupported: Boolean read get_IsLowEnergyCodedPhySupported;
    property IsLowEnergyUncoded2MPhySupported: Boolean read get_IsLowEnergyUncoded2MPhySupported;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.BluetoothAdapter>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothAdapter>
  AsyncOperationCompletedHandler_1__IBluetoothAdapter = interface(IUnknown)
  ['{10A10A88-90E0-511A-9A08-D75FEB52A19F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IBluetoothAdapter; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.BluetoothAdapter>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothAdapter>
  IAsyncOperation_1__IBluetoothAdapter = interface(IInspectable)
  ['{46FCE70C-6C07-5A3A-B775-26F99402553F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IBluetoothAdapter); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IBluetoothAdapter; safecall;
    function GetResults: IBluetoothAdapter; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IBluetoothAdapter read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothAdapterStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothAdapter)]
  IBluetoothAdapterStatics = interface(IInspectable)
  ['{8B02FB6A-AC4C-4741-8661-8EAB7D17EA9F}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothAdapter; safecall;
    function GetDefaultAsync: IAsyncOperation_1__IBluetoothAdapter; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothClassOfDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothClassOfDevice)]
  IBluetoothClassOfDeviceStatics = interface(IInspectable)
  ['{E46135BD-0FA2-416C-91B4-C1E48CA061C1}']
    function FromRawValue(rawValue: Cardinal): IBluetoothClassOfDevice; safecall;
    function FromParts(majorClass: BluetoothMajorClass; minorClass: BluetoothMinorClass; serviceCapabilities: BluetoothServiceCapabilities): IBluetoothClassOfDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDevice2
  IBluetoothDevice2 = interface(IInspectable)
  ['{0133F954-B156-4DD0-B1F5-C11BC31A5163}']
    function get_DeviceInformation: IDeviceInformation; safecall;
    property DeviceInformation: IDeviceInformation read get_DeviceInformation;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult
  Rfcomm_IRfcommDeviceServicesResult = interface(IInspectable)
  ['{3B48388C-7CCF-488E-9625-D259A5732D55}']
    function get_Error: BluetoothError; safecall;
    function get_Services: IVectorView_1__Rfcomm_IRfcommDeviceService; safecall;
    property Error: BluetoothError read get_Error;
    property Services: IVectorView_1__Rfcomm_IRfcommDeviceService read get_Services;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceServicesResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult = interface(IUnknown)
  ['{522C25D1-866B-5DE4-BD8E-1FEB5AE60D47}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceServicesResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServicesResult>
  IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult = interface(IInspectable)
  ['{B7F2F74D-BF9C-5721-BF6E-03F1B4409588}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult; safecall;
    function GetResults: Rfcomm_IRfcommDeviceServicesResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceServicesResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDevice3
  IBluetoothDevice3 = interface(IInspectable)
  ['{57FFF78B-651A-4454-B90F-EB21EF0B0D71}']
    function get_DeviceAccessInformation: IDeviceAccessInformation; safecall;
    function RequestAccessAsync: IAsyncOperation_1__DeviceAccessStatus; safecall;
    function GetRfcommServicesAsync: IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult; overload; safecall;
    function GetRfcommServicesAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult; overload; safecall;
    function GetRfcommServicesForIdAsync(serviceId: Rfcomm_IRfcommServiceId): IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult; overload; safecall;
    function GetRfcommServicesForIdAsync(serviceId: Rfcomm_IRfcommServiceId; cacheMode: BluetoothCacheMode): IAsyncOperation_1__Rfcomm_IRfcommDeviceServicesResult; overload; safecall;
    property DeviceAccessInformation: IDeviceAccessInformation read get_DeviceAccessInformation;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDevice4
  IBluetoothDevice4 = interface(IInspectable)
  ['{817C34AD-0E9C-42B2-A8DC-3E8094940D12}']
    function get_BluetoothDeviceId: IBluetoothDeviceId; safecall;
    property BluetoothDeviceId: IBluetoothDeviceId read get_BluetoothDeviceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDevice5
  IBluetoothDevice5 = interface(IInspectable)
  ['{B5E0B385-5E85-4559-A10D-1C7281379F96}']
    function get_WasSecureConnectionUsedForPairing: Boolean; safecall;
    property WasSecureConnectionUsedForPairing: Boolean read get_WasSecureConnectionUsedForPairing;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDeviceIdStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothDeviceId)]
  IBluetoothDeviceIdStatics = interface(IInspectable)
  ['{A7884E67-3EFB-4F31-BBC2-810E09977404}']
    function FromId(deviceId: HSTRING): IBluetoothDeviceId; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.BluetoothDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothDevice>
  AsyncOperationCompletedHandler_1__IBluetoothDevice = interface(IUnknown)
  ['{B2E8CDD1-66AA-5892-85A3-8F0B165E43FC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IBluetoothDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.BluetoothDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothDevice>
  IAsyncOperation_1__IBluetoothDevice = interface(IInspectable)
  ['{B58D8D19-44BD-5AC0-A0D6-1B50800F3181}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IBluetoothDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IBluetoothDevice; safecall;
    function GetResults: IBluetoothDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IBluetoothDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothDevice)]
  IBluetoothDeviceStatics = interface(IInspectable)
  ['{0991DF51-57DB-4725-BBD7-84F64327EC2C}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothDevice; safecall;
    function FromHostNameAsync(hostName: IHostName): IAsyncOperation_1__IBluetoothDevice; safecall;
    function FromBluetoothAddressAsync(address: UInt64): IAsyncOperation_1__IBluetoothDevice; safecall;
    function GetDeviceSelector: HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothDeviceStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothDevice)]
  IBluetoothDeviceStatics2 = interface(IInspectable)
  ['{C29E8E2F-4E14-4477-AA1B-B8B47E5B7ECE}']
    function GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING; safecall;
    function GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING; safecall;
    function GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING; safecall;
    function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING; safecall;
    function GetDeviceSelectorFromClassOfDevice(classOfDevice: IBluetoothClassOfDevice): HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEAppearance
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEAppearance)]
  IBluetoothLEAppearance = interface(IInspectable)
  ['{5D2079F2-66A8-4258-985E-02B4D9509F18}']
    function get_RawValue: Word; safecall;
    function get_Category: Word; safecall;
    function get_SubCategory: Word; safecall;
    property Category: Word read get_Category;
    property RawValue: Word read get_RawValue;
    property SubCategory: Word read get_SubCategory;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceCategoriesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEAppearanceCategories)]
  IBluetoothLEAppearanceCategoriesStatics = interface(IInspectable)
  ['{6D4D54FE-046A-4185-AAB6-824CF0610861}']
    function get_Uncategorized: Word; safecall;
    function get_Phone: Word; safecall;
    function get_Computer: Word; safecall;
    function get_Watch: Word; safecall;
    function get_Clock: Word; safecall;
    function get_Display: Word; safecall;
    function get_RemoteControl: Word; safecall;
    function get_EyeGlasses: Word; safecall;
    function get_Tag: Word; safecall;
    function get_Keyring: Word; safecall;
    function get_MediaPlayer: Word; safecall;
    function get_BarcodeScanner: Word; safecall;
    function get_Thermometer: Word; safecall;
    function get_HeartRate: Word; safecall;
    function get_BloodPressure: Word; safecall;
    function get_HumanInterfaceDevice: Word; safecall;
    function get_GlucoseMeter: Word; safecall;
    function get_RunningWalking: Word; safecall;
    function get_Cycling: Word; safecall;
    function get_PulseOximeter: Word; safecall;
    function get_WeightScale: Word; safecall;
    function get_OutdoorSportActivity: Word; safecall;
    property BarcodeScanner: Word read get_BarcodeScanner;
    property BloodPressure: Word read get_BloodPressure;
    property Clock: Word read get_Clock;
    property Computer: Word read get_Computer;
    property Cycling: Word read get_Cycling;
    property Display: Word read get_Display;
    property EyeGlasses: Word read get_EyeGlasses;
    property GlucoseMeter: Word read get_GlucoseMeter;
    property HeartRate: Word read get_HeartRate;
    property HumanInterfaceDevice: Word read get_HumanInterfaceDevice;
    property Keyring: Word read get_Keyring;
    property MediaPlayer: Word read get_MediaPlayer;
    property OutdoorSportActivity: Word read get_OutdoorSportActivity;
    property Phone: Word read get_Phone;
    property PulseOximeter: Word read get_PulseOximeter;
    property RemoteControl: Word read get_RemoteControl;
    property RunningWalking: Word read get_RunningWalking;
    property Tag: Word read get_Tag;
    property Thermometer: Word read get_Thermometer;
    property Uncategorized: Word read get_Uncategorized;
    property Watch: Word read get_Watch;
    property WeightScale: Word read get_WeightScale;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEAppearance)]
  IBluetoothLEAppearanceStatics = interface(IInspectable)
  ['{A193C0C7-4504-4F4A-9BA5-CD1054E5E065}']
    function FromRawValue(rawValue: Word): IBluetoothLEAppearance; safecall;
    function FromParts(appearanceCategory: Word; appearanceSubCategory: Word): IBluetoothLEAppearance; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEAppearanceSubcategoriesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEAppearanceSubcategories)]
  IBluetoothLEAppearanceSubcategoriesStatics = interface(IInspectable)
  ['{E57BA606-2144-415A-8312-71CCF291F8D1}']
    function get_Generic: Word; safecall;
    function get_SportsWatch: Word; safecall;
    function get_ThermometerEar: Word; safecall;
    function get_HeartRateBelt: Word; safecall;
    function get_BloodPressureArm: Word; safecall;
    function get_BloodPressureWrist: Word; safecall;
    function get_Keyboard: Word; safecall;
    function get_Mouse: Word; safecall;
    function get_Joystick: Word; safecall;
    function get_Gamepad: Word; safecall;
    function get_DigitizerTablet: Word; safecall;
    function get_CardReader: Word; safecall;
    function get_DigitalPen: Word; safecall;
    function get_BarcodeScanner: Word; safecall;
    function get_RunningWalkingInShoe: Word; safecall;
    function get_RunningWalkingOnShoe: Word; safecall;
    function get_RunningWalkingOnHip: Word; safecall;
    function get_CyclingComputer: Word; safecall;
    function get_CyclingSpeedSensor: Word; safecall;
    function get_CyclingCadenceSensor: Word; safecall;
    function get_CyclingPowerSensor: Word; safecall;
    function get_CyclingSpeedCadenceSensor: Word; safecall;
    function get_OximeterFingertip: Word; safecall;
    function get_OximeterWristWorn: Word; safecall;
    function get_LocationDisplay: Word; safecall;
    function get_LocationNavigationDisplay: Word; safecall;
    function get_LocationPod: Word; safecall;
    function get_LocationNavigationPod: Word; safecall;
    property BarcodeScanner: Word read get_BarcodeScanner;
    property BloodPressureArm: Word read get_BloodPressureArm;
    property BloodPressureWrist: Word read get_BloodPressureWrist;
    property CardReader: Word read get_CardReader;
    property CyclingCadenceSensor: Word read get_CyclingCadenceSensor;
    property CyclingComputer: Word read get_CyclingComputer;
    property CyclingPowerSensor: Word read get_CyclingPowerSensor;
    property CyclingSpeedCadenceSensor: Word read get_CyclingSpeedCadenceSensor;
    property CyclingSpeedSensor: Word read get_CyclingSpeedSensor;
    property DigitalPen: Word read get_DigitalPen;
    property DigitizerTablet: Word read get_DigitizerTablet;
    property Gamepad: Word read get_Gamepad;
    property Generic: Word read get_Generic;
    property HeartRateBelt: Word read get_HeartRateBelt;
    property Joystick: Word read get_Joystick;
    property Keyboard: Word read get_Keyboard;
    property LocationDisplay: Word read get_LocationDisplay;
    property LocationNavigationDisplay: Word read get_LocationNavigationDisplay;
    property LocationNavigationPod: Word read get_LocationNavigationPod;
    property LocationPod: Word read get_LocationPod;
    property Mouse: Word read get_Mouse;
    property OximeterFingertip: Word read get_OximeterFingertip;
    property OximeterWristWorn: Word read get_OximeterWristWorn;
    property RunningWalkingInShoe: Word read get_RunningWalkingInShoe;
    property RunningWalkingOnHip: Word read get_RunningWalkingOnHip;
    property RunningWalkingOnShoe: Word read get_RunningWalkingOnShoe;
    property SportsWatch: Word read get_SportsWatch;
    property ThermometerEar: Word read get_ThermometerEar;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEConnectionParameters
  IBluetoothLEConnectionParameters = interface(IInspectable)
  ['{33CB0771-8DA9-508F-A366-1CA388C929AB}']
    function get_LinkTimeout: Word; safecall;
    function get_ConnectionLatency: Word; safecall;
    function get_ConnectionInterval: Word; safecall;
    property ConnectionInterval: Word read get_ConnectionInterval;
    property ConnectionLatency: Word read get_ConnectionLatency;
    property LinkTimeout: Word read get_LinkTimeout;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEConnectionPhyInfo
  IBluetoothLEConnectionPhyInfo = interface(IInspectable)
  ['{9A100BDD-602E-5C27-A1AE-B230015A6394}']
    function get_IsUncoded1MPhy: Boolean; safecall;
    function get_IsUncoded2MPhy: Boolean; safecall;
    function get_IsCodedPhy: Boolean; safecall;
    property IsCodedPhy: Boolean read get_IsCodedPhy;
    property IsUncoded1MPhy: Boolean read get_IsUncoded1MPhy;
    property IsUncoded2MPhy: Boolean read get_IsUncoded2MPhy;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEConnectionPhy
  IBluetoothLEConnectionPhy = interface(IInspectable)
  ['{781E5E48-621E-5A7E-8BE6-1B9561FF63C9}']
    function get_TransmitInfo: IBluetoothLEConnectionPhyInfo; safecall;
    function get_ReceiveInfo: IBluetoothLEConnectionPhyInfo; safecall;
    property ReceiveInfo: IBluetoothLEConnectionPhyInfo read get_ReceiveInfo;
    property TransmitInfo: IBluetoothLEConnectionPhyInfo read get_TransmitInfo;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice2
  IBluetoothLEDevice2 = interface(IInspectable)
  ['{26F062B3-7AEE-4D31-BABA-B1B9775F5916}']
    function get_DeviceInformation: IDeviceInformation; safecall;
    function get_Appearance: IBluetoothLEAppearance; safecall;
    function get_BluetoothAddressType: BluetoothAddressType; safecall;
    property Appearance: IBluetoothLEAppearance read get_Appearance;
    property BluetoothAddressType_: BluetoothAddressType read get_BluetoothAddressType;
    property DeviceInformation: IDeviceInformation read get_DeviceInformation;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice3
  IBluetoothLEDevice3 = interface(IInspectable)
  ['{AEE9E493-44AC-40DC-AF33-B2C13C01CA46}']
    function get_DeviceAccessInformation: IDeviceAccessInformation; safecall;
    function RequestAccessAsync: IAsyncOperation_1__DeviceAccessStatus; safecall;
    function GetGattServicesAsync: IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetGattServicesAsync(cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetGattServicesForUuidAsync(serviceUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    function GetGattServicesForUuidAsync(serviceUuid: TGuid; cacheMode: BluetoothCacheMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceServicesResult; overload; safecall;
    property DeviceAccessInformation: IDeviceAccessInformation read get_DeviceAccessInformation;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice4
  IBluetoothLEDevice4 = interface(IInspectable)
  ['{2B605031-2248-4B2F-ACF0-7CEE36FC5870}']
    function get_BluetoothDeviceId: IBluetoothDeviceId; safecall;
    property BluetoothDeviceId: IBluetoothDeviceId read get_BluetoothDeviceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice5
  IBluetoothLEDevice5 = interface(IInspectable)
  ['{9D6A1260-5287-458E-95BA-17C8B7BB326E}']
    function get_WasSecureConnectionUsedForPairing: Boolean; safecall;
    property WasSecureConnectionUsedForPairing: Boolean read get_WasSecureConnectionUsedForPairing;
  end;

  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersRequest
  IBluetoothLEPreferredConnectionParametersRequest = interface(IInspectable)
  ['{8A375276-A528-5266-B661-CCE6A5FF9739}']
    function get_Status: BluetoothLEPreferredConnectionParametersRequestStatus; safecall;
    property Status: BluetoothLEPreferredConnectionParametersRequestStatus read get_Status;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParameters
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEPreferredConnectionParameters)]
  IBluetoothLEPreferredConnectionParameters = interface(IInspectable)
  ['{F2F44344-7372-5F7B-9B34-29C944F5A715}']
    function get_LinkTimeout: Word; safecall;
    function get_ConnectionLatency: Word; safecall;
    function get_MinConnectionInterval: Word; safecall;
    function get_MaxConnectionInterval: Word; safecall;
    property ConnectionLatency: Word read get_ConnectionLatency;
    property LinkTimeout: Word read get_LinkTimeout;
    property MaxConnectionInterval: Word read get_MaxConnectionInterval;
    property MinConnectionInterval: Word read get_MinConnectionInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDevice6
  IBluetoothLEDevice6 = interface(IInspectable)
  ['{CA7190EF-0CAE-573C-A1CA-E1FC5BFC39E2}']
    function GetConnectionParameters: IBluetoothLEConnectionParameters; safecall;
    function GetConnectionPhy: IBluetoothLEConnectionPhy; safecall;
    function RequestPreferredConnectionParameters(preferredConnectionParameters: IBluetoothLEPreferredConnectionParameters): IBluetoothLEPreferredConnectionParametersRequest; safecall;
    function add_ConnectionParametersChanged(handler: TypedEventHandler_2__IBluetoothLEDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ConnectionParametersChanged(token: EventRegistrationToken); safecall;
    function add_ConnectionPhyChanged(handler: TypedEventHandler_2__IBluetoothLEDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ConnectionPhyChanged(token: EventRegistrationToken); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.BluetoothLEDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.IBluetoothLEDevice>
  AsyncOperationCompletedHandler_1__IBluetoothLEDevice = interface(IUnknown)
  ['{9156B79F-C54A-5277-8F8B-D2CC43C7E004}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IBluetoothLEDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.BluetoothLEDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.IBluetoothLEDevice>
  IAsyncOperation_1__IBluetoothLEDevice = interface(IInspectable)
  ['{375F9D67-74A2-5F91-A11D-169093718D41}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IBluetoothLEDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IBluetoothLEDevice; safecall;
    function GetResults: IBluetoothLEDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IBluetoothLEDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEDevice)]
  IBluetoothLEDeviceStatics = interface(IInspectable)
  ['{C8CF1A19-F0B6-4BF0-8689-41303DE2D9F4}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothLEDevice; safecall;
    function FromBluetoothAddressAsync(bluetoothAddress: UInt64): IAsyncOperation_1__IBluetoothLEDevice; safecall;
    function GetDeviceSelector: HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEDevice)]
  IBluetoothLEDeviceStatics2 = interface(IInspectable)
  ['{5F12C06B-3BAC-43E8-AD16-563271BD41C2}']
    function GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING; safecall;
    function GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING; safecall;
    function GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING; safecall;
    function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING; overload; safecall;
    function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): HSTRING; overload; safecall;
    function GetDeviceSelectorFromAppearance(appearance: IBluetoothLEAppearance): HSTRING; safecall;
    function FromBluetoothAddressAsync(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): IAsyncOperation_1__IBluetoothLEDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothLEPreferredConnectionParameters)]
  IBluetoothLEPreferredConnectionParametersStatics = interface(IInspectable)
  ['{0E3E8EDC-2751-55AA-A838-8FAEEE818D72}']
    function get_Balanced: IBluetoothLEPreferredConnectionParameters; safecall;
    function get_ThroughputOptimized: IBluetoothLEPreferredConnectionParameters; safecall;
    function get_PowerOptimized: IBluetoothLEPreferredConnectionParameters; safecall;
    property Balanced: IBluetoothLEPreferredConnectionParameters read get_Balanced;
    property PowerOptimized: IBluetoothLEPreferredConnectionParameters read get_PowerOptimized;
    property ThroughputOptimized: IBluetoothLEPreferredConnectionParameters read get_ThroughputOptimized;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.IBluetoothUuidHelperStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_BluetoothUuidHelper)]
  IBluetoothUuidHelperStatics = interface(IInspectable)
  ['{17DF0CD8-CF74-4B21-AFE6-F57A11BCDEA0}']
    function FromShortId(shortId: Cardinal): TGuid; safecall;
    function TryGetShortId(uuid: TGuid): IReference_1__Cardinal; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService2
  Rfcomm_IRfcommDeviceService2 = interface(IInspectable)
  ['{536CED14-EBCD-49FE-BF9F-40EFC689B20D}']
    function get_Device: IBluetoothDevice; safecall;
    property Device: IBluetoothDevice read get_Device;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService3
  Rfcomm_IRfcommDeviceService3 = interface(IInspectable)
  ['{1C22ACE6-DD44-4D23-866D-8F3486EE6490}']
    function get_DeviceAccessInformation: IDeviceAccessInformation; safecall;
    function RequestAccessAsync: IAsyncOperation_1__DeviceAccessStatus; safecall;
    property DeviceAccessInformation: IDeviceAccessInformation read get_DeviceAccessInformation;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceService>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService = interface(IUnknown)
  ['{5C772518-442F-58ED-80CB-538D34B88295}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Rfcomm_IRfcommDeviceService; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceService>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService>
  IAsyncOperation_1__Rfcomm_IRfcommDeviceService = interface(IInspectable)
  ['{0DF56BD7-C8F6-5C32-9644-AA0BCF28D78C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService; safecall;
    function GetResults: Rfcomm_IRfcommDeviceService; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommDeviceService read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommDeviceService)]
  Rfcomm_IRfcommDeviceServiceStatics = interface(IInspectable)
  ['{A4A149EF-626D-41AC-B253-87AC5C27E28A}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Rfcomm_IRfcommDeviceService; safecall;
    function GetDeviceSelector(serviceId: Rfcomm_IRfcommServiceId): HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommDeviceService)]
  Rfcomm_IRfcommDeviceServiceStatics2 = interface(IInspectable)
  ['{AA8CB1C9-E78D-4BE4-8076-0A3D87A0A05F}']
    function GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice; cacheMode: BluetoothCacheMode): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId): HSTRING; overload; safecall;
    function GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId; cacheMode: BluetoothCacheMode): HSTRING; overload; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceIdStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommServiceId)]
  Rfcomm_IRfcommServiceIdStatics = interface(IInspectable)
  ['{2A179EBA-A975-46E3-B56B-08FFD783A5FE}']
    function FromUuid(uuid: TGuid): Rfcomm_IRfcommServiceId; safecall;
    function FromShortId(shortId: Cardinal): Rfcomm_IRfcommServiceId; safecall;
    function get_SerialPort: Rfcomm_IRfcommServiceId; safecall;
    function get_ObexObjectPush: Rfcomm_IRfcommServiceId; safecall;
    function get_ObexFileTransfer: Rfcomm_IRfcommServiceId; safecall;
    function get_PhoneBookAccessPce: Rfcomm_IRfcommServiceId; safecall;
    function get_PhoneBookAccessPse: Rfcomm_IRfcommServiceId; safecall;
    function get_GenericFileTransfer: Rfcomm_IRfcommServiceId; safecall;
    property GenericFileTransfer: Rfcomm_IRfcommServiceId read get_GenericFileTransfer;
    property ObexFileTransfer: Rfcomm_IRfcommServiceId read get_ObexFileTransfer;
    property ObexObjectPush: Rfcomm_IRfcommServiceId read get_ObexObjectPush;
    property PhoneBookAccessPce: Rfcomm_IRfcommServiceId read get_PhoneBookAccessPce;
    property PhoneBookAccessPse: Rfcomm_IRfcommServiceId read get_PhoneBookAccessPse;
    property SerialPort: Rfcomm_IRfcommServiceId read get_SerialPort;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommServiceProvider)]
  Rfcomm_IRfcommServiceProvider = interface(IInspectable)
  ['{EADBFDC4-B1F6-44FF-9F7C-E7A82AB86821}']
    function get_ServiceId: Rfcomm_IRfcommServiceId; safecall;
    function get_SdpRawAttributes: IMap_2__Cardinal__IBuffer; safecall;
    procedure StartAdvertising(listener: IStreamSocketListener); safecall;
    procedure StopAdvertising; safecall;
    property SdpRawAttributes: IMap_2__Cardinal__IBuffer read get_SdpRawAttributes;
    property ServiceId: Rfcomm_IRfcommServiceId read get_ServiceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider2
  Rfcomm_IRfcommServiceProvider2 = interface(IInspectable)
  ['{736BDFC6-3C81-4D1E-BAF2-DDBB81284512}']
    procedure StartAdvertising(listener: IStreamSocketListener; radioDiscoverable: Boolean); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.RfcommServiceProvider>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider>
  AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider = interface(IUnknown)
  ['{446A7F50-8F2E-51F0-AEBB-1BC3D192905F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Rfcomm_IRfcommServiceProvider; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.RfcommServiceProvider>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider>
  IAsyncOperation_1__Rfcomm_IRfcommServiceProvider = interface(IInspectable)
  ['{FED44828-E232-554D-85D1-2F04D1322E69}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider; safecall;
    function GetResults: Rfcomm_IRfcommServiceProvider; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Rfcomm_IRfcommServiceProvider read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProviderStatics
  [WinRTClassNameAttribute(SWindows_Devices_Bluetooth_Rfcomm_RfcommServiceProvider)]
  Rfcomm_IRfcommServiceProviderStatics = interface(IInspectable)
  ['{98888303-69CA-413A-84F7-4344C7292997}']
    function CreateAsync(serviceId: Rfcomm_IRfcommServiceId): IAsyncOperation_1__Rfcomm_IRfcommServiceProvider; safecall;
  end;

  // Windows.Devices.Bluetooth.Background.GattServiceProviderConnection
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection
  // Implements: Windows.Devices.Bluetooth.Background.IGattServiceProviderConnection2
  // Statics: "Windows.Devices.Bluetooth.Background.IGattServiceProviderConnectionStatics"
  TBackground_GattServiceProviderConnection = class(TWinRTGenericImportS<Background_IGattServiceProviderConnectionStatics>)
  public
    {$REGION 'Background_IGattServiceProviderConnectionStatics'}
    class function get_AllServices: IMapView_2__HSTRING__Background_IGattServiceProviderConnection; static; inline;
    class property AllServices: IMapView_2__HSTRING__Background_IGattServiceProviderConnection read get_AllServices;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothAdapter
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothAdapter
  // Implements: Windows.Devices.Bluetooth.IBluetoothAdapter2
  // Implements: Windows.Devices.Bluetooth.IBluetoothAdapter3
  // Implements: Windows.Devices.Bluetooth.IBluetoothAdapter4
  // Statics: "Windows.Devices.Bluetooth.IBluetoothAdapterStatics"
  TBluetoothAdapter = class(TWinRTGenericImportS<IBluetoothAdapterStatics>)
  public
    {$REGION 'IBluetoothAdapterStatics'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothAdapter; static; inline;
    class function GetDefaultAsync: IAsyncOperation_1__IBluetoothAdapter; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothClassOfDevice
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothClassOfDevice
  // Statics: "Windows.Devices.Bluetooth.IBluetoothClassOfDeviceStatics"
  TBluetoothClassOfDevice = class(TWinRTGenericImportS<IBluetoothClassOfDeviceStatics>)
  public
    {$REGION 'IBluetoothClassOfDeviceStatics'}
    class function FromRawValue(rawValue: Cardinal): IBluetoothClassOfDevice; static; inline;
    class function FromParts(majorClass: BluetoothMajorClass; minorClass: BluetoothMinorClass; serviceCapabilities: BluetoothServiceCapabilities): IBluetoothClassOfDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothDevice
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothDevice
  // Implements: Windows.Devices.Bluetooth.IBluetoothDevice2
  // Implements: Windows.Devices.Bluetooth.IBluetoothDevice3
  // Implements: Windows.Devices.Bluetooth.IBluetoothDevice4
  // Implements: Windows.Devices.Bluetooth.IBluetoothDevice5
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.Bluetooth.IBluetoothDeviceStatics"
  // Statics: "Windows.Devices.Bluetooth.IBluetoothDeviceStatics2"
  TBluetoothDevice = class(TWinRTGenericImportS2<IBluetoothDeviceStatics, IBluetoothDeviceStatics2>)
  public
    {$REGION 'IBluetoothDeviceStatics'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothDevice; static; inline;
    class function FromHostNameAsync(hostName: IHostName): IAsyncOperation_1__IBluetoothDevice; static; inline;
    class function FromBluetoothAddressAsync(address: UInt64): IAsyncOperation_1__IBluetoothDevice; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    {$ENDREGION}
    {$REGION 'IBluetoothDeviceStatics2'}
    class function GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING; static; inline;
    class function GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING; static; inline;
    class function GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING; static; inline;
    class function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING; static; inline;
    class function GetDeviceSelectorFromClassOfDevice(classOfDevice: IBluetoothClassOfDevice): HSTRING; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothDeviceId
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothDeviceId
  // Statics: "Windows.Devices.Bluetooth.IBluetoothDeviceIdStatics"
  TBluetoothDeviceId = class(TWinRTGenericImportS<IBluetoothDeviceIdStatics>)
  public
    {$REGION 'IBluetoothDeviceIdStatics'}
    class function FromId(deviceId: HSTRING): IBluetoothDeviceId; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothLEAppearance
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEAppearance
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEAppearanceStatics"
  TBluetoothLEAppearance = class(TWinRTGenericImportS<IBluetoothLEAppearanceStatics>)
  public
    {$REGION 'IBluetoothLEAppearanceStatics'}
    class function FromRawValue(rawValue: Word): IBluetoothLEAppearance; static; inline;
    class function FromParts(appearanceCategory: Word; appearanceSubCategory: Word): IBluetoothLEAppearance; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothLEAppearanceCategories
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEAppearanceCategoriesStatics"
  TBluetoothLEAppearanceCategories = class(TWinRTGenericImportS<IBluetoothLEAppearanceCategoriesStatics>)
  public
    {$REGION 'IBluetoothLEAppearanceCategoriesStatics'}
    class function get_Uncategorized: Word; static; inline;
    class function get_Phone: Word; static; inline;
    class function get_Computer: Word; static; inline;
    class function get_Watch: Word; static; inline;
    class function get_Clock: Word; static; inline;
    class function get_Display: Word; static; inline;
    class function get_RemoteControl: Word; static; inline;
    class function get_EyeGlasses: Word; static; inline;
    class function get_Tag: Word; static; inline;
    class function get_Keyring: Word; static; inline;
    class function get_MediaPlayer: Word; static; inline;
    class function get_BarcodeScanner: Word; static; inline;
    class function get_Thermometer: Word; static; inline;
    class function get_HeartRate: Word; static; inline;
    class function get_BloodPressure: Word; static; inline;
    class function get_HumanInterfaceDevice: Word; static; inline;
    class function get_GlucoseMeter: Word; static; inline;
    class function get_RunningWalking: Word; static; inline;
    class function get_Cycling: Word; static; inline;
    class function get_PulseOximeter: Word; static; inline;
    class function get_WeightScale: Word; static; inline;
    class function get_OutdoorSportActivity: Word; static; inline;
    class property BarcodeScanner: Word read get_BarcodeScanner;
    class property BloodPressure: Word read get_BloodPressure;
    class property Clock: Word read get_Clock;
    class property Computer: Word read get_Computer;
    class property Cycling: Word read get_Cycling;
    class property Display: Word read get_Display;
    class property EyeGlasses: Word read get_EyeGlasses;
    class property GlucoseMeter: Word read get_GlucoseMeter;
    class property HeartRate: Word read get_HeartRate;
    class property HumanInterfaceDevice: Word read get_HumanInterfaceDevice;
    class property Keyring: Word read get_Keyring;
    class property MediaPlayer: Word read get_MediaPlayer;
    class property OutdoorSportActivity: Word read get_OutdoorSportActivity;
    class property Phone: Word read get_Phone;
    class property PulseOximeter: Word read get_PulseOximeter;
    class property RemoteControl: Word read get_RemoteControl;
    class property RunningWalking: Word read get_RunningWalking;
    class property Tag: Word read get_Tag;
    class property Thermometer: Word read get_Thermometer;
    class property Uncategorized: Word read get_Uncategorized;
    class property Watch: Word read get_Watch;
    class property WeightScale: Word read get_WeightScale;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothLEAppearanceSubcategories
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEAppearanceSubcategoriesStatics"
  TBluetoothLEAppearanceSubcategories = class(TWinRTGenericImportS<IBluetoothLEAppearanceSubcategoriesStatics>)
  public
    {$REGION 'IBluetoothLEAppearanceSubcategoriesStatics'}
    class function get_Generic: Word; static; inline;
    class function get_SportsWatch: Word; static; inline;
    class function get_ThermometerEar: Word; static; inline;
    class function get_HeartRateBelt: Word; static; inline;
    class function get_BloodPressureArm: Word; static; inline;
    class function get_BloodPressureWrist: Word; static; inline;
    class function get_Keyboard: Word; static; inline;
    class function get_Mouse: Word; static; inline;
    class function get_Joystick: Word; static; inline;
    class function get_Gamepad: Word; static; inline;
    class function get_DigitizerTablet: Word; static; inline;
    class function get_CardReader: Word; static; inline;
    class function get_DigitalPen: Word; static; inline;
    class function get_BarcodeScanner: Word; static; inline;
    class function get_RunningWalkingInShoe: Word; static; inline;
    class function get_RunningWalkingOnShoe: Word; static; inline;
    class function get_RunningWalkingOnHip: Word; static; inline;
    class function get_CyclingComputer: Word; static; inline;
    class function get_CyclingSpeedSensor: Word; static; inline;
    class function get_CyclingCadenceSensor: Word; static; inline;
    class function get_CyclingPowerSensor: Word; static; inline;
    class function get_CyclingSpeedCadenceSensor: Word; static; inline;
    class function get_OximeterFingertip: Word; static; inline;
    class function get_OximeterWristWorn: Word; static; inline;
    class function get_LocationDisplay: Word; static; inline;
    class function get_LocationNavigationDisplay: Word; static; inline;
    class function get_LocationPod: Word; static; inline;
    class function get_LocationNavigationPod: Word; static; inline;
    class property BarcodeScanner: Word read get_BarcodeScanner;
    class property BloodPressureArm: Word read get_BloodPressureArm;
    class property BloodPressureWrist: Word read get_BloodPressureWrist;
    class property CardReader: Word read get_CardReader;
    class property CyclingCadenceSensor: Word read get_CyclingCadenceSensor;
    class property CyclingComputer: Word read get_CyclingComputer;
    class property CyclingPowerSensor: Word read get_CyclingPowerSensor;
    class property CyclingSpeedCadenceSensor: Word read get_CyclingSpeedCadenceSensor;
    class property CyclingSpeedSensor: Word read get_CyclingSpeedSensor;
    class property DigitalPen: Word read get_DigitalPen;
    class property DigitizerTablet: Word read get_DigitizerTablet;
    class property Gamepad: Word read get_Gamepad;
    class property Generic: Word read get_Generic;
    class property HeartRateBelt: Word read get_HeartRateBelt;
    class property Joystick: Word read get_Joystick;
    class property Keyboard: Word read get_Keyboard;
    class property LocationDisplay: Word read get_LocationDisplay;
    class property LocationNavigationDisplay: Word read get_LocationNavigationDisplay;
    class property LocationNavigationPod: Word read get_LocationNavigationPod;
    class property LocationPod: Word read get_LocationPod;
    class property Mouse: Word read get_Mouse;
    class property OximeterFingertip: Word read get_OximeterFingertip;
    class property OximeterWristWorn: Word read get_OximeterWristWorn;
    class property RunningWalkingInShoe: Word read get_RunningWalkingInShoe;
    class property RunningWalkingOnHip: Word read get_RunningWalkingOnHip;
    class property RunningWalkingOnShoe: Word read get_RunningWalkingOnShoe;
    class property SportsWatch: Word read get_SportsWatch;
    class property ThermometerEar: Word read get_ThermometerEar;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothLEDevice
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice2
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice3
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice4
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice5
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEDevice6
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics"
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics2"
  TBluetoothLEDevice = class(TWinRTGenericImportS2<IBluetoothLEDeviceStatics, IBluetoothLEDeviceStatics2>)
  public
    {$REGION 'IBluetoothLEDeviceStatics'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothLEDevice; static; inline;
    class function FromBluetoothAddressAsync(bluetoothAddress: UInt64): IAsyncOperation_1__IBluetoothLEDevice; overload; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    {$ENDREGION}
    {$REGION 'IBluetoothLEDeviceStatics2'}
    class function GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING; static; inline;
    class function GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING; static; inline;
    class function GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING; static; inline;
    class function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING; overload; static; inline;
    class function GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): HSTRING; overload; static; inline;
    class function GetDeviceSelectorFromAppearance(appearance: IBluetoothLEAppearance): HSTRING; static; inline;
    class function FromBluetoothAddressAsync(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): IAsyncOperation_1__IBluetoothLEDevice; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothLEPreferredConnectionParameters
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParameters
  // Statics: "Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersStatics"
  TBluetoothLEPreferredConnectionParameters = class(TWinRTGenericImportS<IBluetoothLEPreferredConnectionParametersStatics>)
  public
    {$REGION 'IBluetoothLEPreferredConnectionParametersStatics'}
    class function get_Balanced: IBluetoothLEPreferredConnectionParameters; static; inline;
    class function get_ThroughputOptimized: IBluetoothLEPreferredConnectionParameters; static; inline;
    class function get_PowerOptimized: IBluetoothLEPreferredConnectionParameters; static; inline;
    class property Balanced: IBluetoothLEPreferredConnectionParameters read get_Balanced;
    class property PowerOptimized: IBluetoothLEPreferredConnectionParameters read get_PowerOptimized;
    class property ThroughputOptimized: IBluetoothLEPreferredConnectionParameters read get_ThroughputOptimized;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.BluetoothSignalStrengthFilter
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.IBluetoothSignalStrengthFilter
  // Instantiable: "IBluetoothSignalStrengthFilter"
  TBluetoothSignalStrengthFilter = class(TWinRTGenericImportI<IBluetoothSignalStrengthFilter>) end;

  // Windows.Devices.Bluetooth.BluetoothUuidHelper
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.IBluetoothUuidHelperStatics"
  TBluetoothUuidHelper = class(TWinRTGenericImportS<IBluetoothUuidHelperStatics>)
  public
    {$REGION 'IBluetoothUuidHelperStatics'}
    class function FromShortId(shortId: Cardinal): TGuid; static; inline;
    class function TryGetShortId(uuid: TGuid): IReference_1__Cardinal; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristic
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic2
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristic3
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicStatics"
  TGenericAttributeProfile_GattCharacteristic = class(TWinRTGenericImportS<GenericAttributeProfile_IGattCharacteristicStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattCharacteristicStatics'}
    class function ConvertShortIdToUuid(shortId: Word): TGuid; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattCharacteristicUuids
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics"
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics2"
  TGenericAttributeProfile_GattCharacteristicUuids = class(TWinRTGenericImportS2<GenericAttributeProfile_IGattCharacteristicUuidsStatics, GenericAttributeProfile_IGattCharacteristicUuidsStatics2>)
  public
    {$REGION 'GenericAttributeProfile_IGattCharacteristicUuidsStatics'}
    class function get_BatteryLevel: TGuid; static; inline;
    class function get_BloodPressureFeature: TGuid; static; inline;
    class function get_BloodPressureMeasurement: TGuid; static; inline;
    class function get_BodySensorLocation: TGuid; static; inline;
    class function get_CscFeature: TGuid; static; inline;
    class function get_CscMeasurement: TGuid; static; inline;
    class function get_GlucoseFeature: TGuid; static; inline;
    class function get_GlucoseMeasurement: TGuid; static; inline;
    class function get_GlucoseMeasurementContext: TGuid; static; inline;
    class function get_HeartRateControlPoint: TGuid; static; inline;
    class function get_HeartRateMeasurement: TGuid; static; inline;
    class function get_IntermediateCuffPressure: TGuid; static; inline;
    class function get_IntermediateTemperature: TGuid; static; inline;
    class function get_MeasurementInterval: TGuid; static; inline;
    class function get_RecordAccessControlPoint: TGuid; static; inline;
    class function get_RscFeature: TGuid; static; inline;
    class function get_RscMeasurement: TGuid; static; inline;
    class function get_SCControlPoint: TGuid; static; inline;
    class function get_SensorLocation: TGuid; static; inline;
    class function get_TemperatureMeasurement: TGuid; static; inline;
    class function get_TemperatureType: TGuid; static; inline;
    class property BatteryLevel: TGuid read get_BatteryLevel;
    class property BloodPressureFeature: TGuid read get_BloodPressureFeature;
    class property BloodPressureMeasurement: TGuid read get_BloodPressureMeasurement;
    class property BodySensorLocation: TGuid read get_BodySensorLocation;
    class property CscFeature: TGuid read get_CscFeature;
    class property CscMeasurement: TGuid read get_CscMeasurement;
    class property GlucoseFeature: TGuid read get_GlucoseFeature;
    class property GlucoseMeasurement: TGuid read get_GlucoseMeasurement;
    class property GlucoseMeasurementContext: TGuid read get_GlucoseMeasurementContext;
    class property HeartRateControlPoint: TGuid read get_HeartRateControlPoint;
    class property HeartRateMeasurement: TGuid read get_HeartRateMeasurement;
    class property IntermediateCuffPressure: TGuid read get_IntermediateCuffPressure;
    class property IntermediateTemperature: TGuid read get_IntermediateTemperature;
    class property MeasurementInterval: TGuid read get_MeasurementInterval;
    class property RecordAccessControlPoint: TGuid read get_RecordAccessControlPoint;
    class property RscFeature: TGuid read get_RscFeature;
    class property RscMeasurement: TGuid read get_RscMeasurement;
    class property SCControlPoint: TGuid read get_SCControlPoint;
    class property SensorLocation: TGuid read get_SensorLocation;
    class property TemperatureMeasurement: TGuid read get_TemperatureMeasurement;
    class property TemperatureType: TGuid read get_TemperatureType;
    {$ENDREGION}
    {$REGION 'GenericAttributeProfile_IGattCharacteristicUuidsStatics2'}
    class function get_AlertCategoryId: TGuid; static; inline;
    class function get_AlertCategoryIdBitMask: TGuid; static; inline;
    class function get_AlertLevel: TGuid; static; inline;
    class function get_AlertNotificationControlPoint: TGuid; static; inline;
    class function get_AlertStatus: TGuid; static; inline;
    class function get_GapAppearance: TGuid; static; inline;
    class function get_BootKeyboardInputReport: TGuid; static; inline;
    class function get_BootKeyboardOutputReport: TGuid; static; inline;
    class function get_BootMouseInputReport: TGuid; static; inline;
    class function get_CurrentTime: TGuid; static; inline;
    class function get_CyclingPowerControlPoint: TGuid; static; inline;
    class function get_CyclingPowerFeature: TGuid; static; inline;
    class function get_CyclingPowerMeasurement: TGuid; static; inline;
    class function get_CyclingPowerVector: TGuid; static; inline;
    class function get_DateTime: TGuid; static; inline;
    class function get_DayDateTime: TGuid; static; inline;
    class function get_DayOfWeek: TGuid; static; inline;
    class function get_GapDeviceName: TGuid; static; inline;
    class function get_DstOffset: TGuid; static; inline;
    class function get_ExactTime256: TGuid; static; inline;
    class function get_FirmwareRevisionString: TGuid; static; inline;
    class function get_HardwareRevisionString: TGuid; static; inline;
    class function get_HidControlPoint: TGuid; static; inline;
    class function get_HidInformation: TGuid; static; inline;
    class function get_Ieee1107320601RegulatoryCertificationDataList: TGuid; static; inline;
    class function get_LnControlPoint: TGuid; static; inline;
    class function get_LnFeature: TGuid; static; inline;
    class function get_LocalTimeInformation: TGuid; static; inline;
    class function get_LocationAndSpeed: TGuid; static; inline;
    class function get_ManufacturerNameString: TGuid; static; inline;
    class function get_ModelNumberString: TGuid; static; inline;
    class function get_Navigation: TGuid; static; inline;
    class function get_NewAlert: TGuid; static; inline;
    class function get_GapPeripheralPreferredConnectionParameters: TGuid; static; inline;
    class function get_GapPeripheralPrivacyFlag: TGuid; static; inline;
    class function get_PnpId: TGuid; static; inline;
    class function get_PositionQuality: TGuid; static; inline;
    class function get_ProtocolMode: TGuid; static; inline;
    class function get_GapReconnectionAddress: TGuid; static; inline;
    class function get_ReferenceTimeInformation: TGuid; static; inline;
    class function get_Report: TGuid; static; inline;
    class function get_ReportMap: TGuid; static; inline;
    class function get_RingerControlPoint: TGuid; static; inline;
    class function get_RingerSetting: TGuid; static; inline;
    class function get_ScanIntervalWindow: TGuid; static; inline;
    class function get_ScanRefresh: TGuid; static; inline;
    class function get_SerialNumberString: TGuid; static; inline;
    class function get_GattServiceChanged: TGuid; static; inline;
    class function get_SoftwareRevisionString: TGuid; static; inline;
    class function get_SupportedNewAlertCategory: TGuid; static; inline;
    class function get_SupportUnreadAlertCategory: TGuid; static; inline;
    class function get_SystemId: TGuid; static; inline;
    class function get_TimeAccuracy: TGuid; static; inline;
    class function get_TimeSource: TGuid; static; inline;
    class function get_TimeUpdateControlPoint: TGuid; static; inline;
    class function get_TimeUpdateState: TGuid; static; inline;
    class function get_TimeWithDst: TGuid; static; inline;
    class function get_TimeZone: TGuid; static; inline;
    class function get_TxPowerLevel: TGuid; static; inline;
    class function get_UnreadAlertStatus: TGuid; static; inline;
    class property AlertCategoryId: TGuid read get_AlertCategoryId;
    class property AlertCategoryIdBitMask: TGuid read get_AlertCategoryIdBitMask;
    class property AlertLevel: TGuid read get_AlertLevel;
    class property AlertNotificationControlPoint: TGuid read get_AlertNotificationControlPoint;
    class property AlertStatus: TGuid read get_AlertStatus;
    class property BootKeyboardInputReport: TGuid read get_BootKeyboardInputReport;
    class property BootKeyboardOutputReport: TGuid read get_BootKeyboardOutputReport;
    class property BootMouseInputReport: TGuid read get_BootMouseInputReport;
    class property CurrentTime: TGuid read get_CurrentTime;
    class property CyclingPowerControlPoint: TGuid read get_CyclingPowerControlPoint;
    class property CyclingPowerFeature: TGuid read get_CyclingPowerFeature;
    class property CyclingPowerMeasurement: TGuid read get_CyclingPowerMeasurement;
    class property CyclingPowerVector: TGuid read get_CyclingPowerVector;
    class property DateTime: TGuid read get_DateTime;
    class property DayDateTime: TGuid read get_DayDateTime;
    class property DayOfWeek: TGuid read get_DayOfWeek;
    class property DstOffset: TGuid read get_DstOffset;
    class property ExactTime256: TGuid read get_ExactTime256;
    class property FirmwareRevisionString: TGuid read get_FirmwareRevisionString;
    class property GapAppearance: TGuid read get_GapAppearance;
    class property GapDeviceName: TGuid read get_GapDeviceName;
    class property GapPeripheralPreferredConnectionParameters: TGuid read get_GapPeripheralPreferredConnectionParameters;
    class property GapPeripheralPrivacyFlag: TGuid read get_GapPeripheralPrivacyFlag;
    class property GapReconnectionAddress: TGuid read get_GapReconnectionAddress;
    class property GattServiceChanged: TGuid read get_GattServiceChanged;
    class property HardwareRevisionString: TGuid read get_HardwareRevisionString;
    class property HidControlPoint: TGuid read get_HidControlPoint;
    class property HidInformation: TGuid read get_HidInformation;
    class property Ieee1107320601RegulatoryCertificationDataList: TGuid read get_Ieee1107320601RegulatoryCertificationDataList;
    class property LnControlPoint: TGuid read get_LnControlPoint;
    class property LnFeature: TGuid read get_LnFeature;
    class property LocalTimeInformation: TGuid read get_LocalTimeInformation;
    class property LocationAndSpeed: TGuid read get_LocationAndSpeed;
    class property ManufacturerNameString: TGuid read get_ManufacturerNameString;
    class property ModelNumberString: TGuid read get_ModelNumberString;
    class property Navigation: TGuid read get_Navigation;
    class property NewAlert: TGuid read get_NewAlert;
    class property PnpId: TGuid read get_PnpId;
    class property PositionQuality: TGuid read get_PositionQuality;
    class property ProtocolMode: TGuid read get_ProtocolMode;
    class property ReferenceTimeInformation: TGuid read get_ReferenceTimeInformation;
    class property Report: TGuid read get_Report;
    class property ReportMap: TGuid read get_ReportMap;
    class property RingerControlPoint: TGuid read get_RingerControlPoint;
    class property RingerSetting: TGuid read get_RingerSetting;
    class property ScanIntervalWindow: TGuid read get_ScanIntervalWindow;
    class property ScanRefresh: TGuid read get_ScanRefresh;
    class property SerialNumberString: TGuid read get_SerialNumberString;
    class property SoftwareRevisionString: TGuid read get_SoftwareRevisionString;
    class property SupportUnreadAlertCategory: TGuid read get_SupportUnreadAlertCategory;
    class property SupportedNewAlertCategory: TGuid read get_SupportedNewAlertCategory;
    class property SystemId: TGuid read get_SystemId;
    class property TimeAccuracy: TGuid read get_TimeAccuracy;
    class property TimeSource: TGuid read get_TimeSource;
    class property TimeUpdateControlPoint: TGuid read get_TimeUpdateControlPoint;
    class property TimeUpdateState: TGuid read get_TimeUpdateState;
    class property TimeWithDst: TGuid read get_TimeWithDst;
    class property TimeZone: TGuid read get_TimeZone;
    class property TxPowerLevel: TGuid read get_TxPowerLevel;
    class property UnreadAlertStatus: TGuid read get_UnreadAlertStatus;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptor
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptor2
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorStatics"
  TGenericAttributeProfile_GattDescriptor = class(TWinRTGenericImportS<GenericAttributeProfile_IGattDescriptorStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattDescriptorStatics'}
    class function ConvertShortIdToUuid(shortId: Word): TGuid; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattDescriptorUuids
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorUuidsStatics"
  TGenericAttributeProfile_GattDescriptorUuids = class(TWinRTGenericImportS<GenericAttributeProfile_IGattDescriptorUuidsStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattDescriptorUuidsStatics'}
    class function get_CharacteristicAggregateFormat: TGuid; static; inline;
    class function get_CharacteristicExtendedProperties: TGuid; static; inline;
    class function get_CharacteristicPresentationFormat: TGuid; static; inline;
    class function get_CharacteristicUserDescription: TGuid; static; inline;
    class function get_ClientCharacteristicConfiguration: TGuid; static; inline;
    class function get_ServerCharacteristicConfiguration: TGuid; static; inline;
    class property CharacteristicAggregateFormat: TGuid read get_CharacteristicAggregateFormat;
    class property CharacteristicExtendedProperties: TGuid read get_CharacteristicExtendedProperties;
    class property CharacteristicPresentationFormat: TGuid read get_CharacteristicPresentationFormat;
    class property CharacteristicUserDescription: TGuid read get_CharacteristicUserDescription;
    class property ClientCharacteristicConfiguration: TGuid read get_ClientCharacteristicConfiguration;
    class property ServerCharacteristicConfiguration: TGuid read get_ServerCharacteristicConfiguration;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattDeviceService
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService
  // Implements: Windows.Foundation.IClosable
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService2
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceService3
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics"
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics2"
  TGenericAttributeProfile_GattDeviceService = class(TWinRTGenericImportS2<GenericAttributeProfile_IGattDeviceServiceStatics, GenericAttributeProfile_IGattDeviceServiceStatics2>)
  public
    {$REGION 'GenericAttributeProfile_IGattDeviceServiceStatics'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService; overload; static; inline;
    class function GetDeviceSelectorFromUuid(serviceUuid: TGuid): HSTRING; static; inline;
    class function GetDeviceSelectorFromShortId(serviceShortId: Word): HSTRING; static; inline;
    class function ConvertShortIdToUuid(shortId: Word): TGuid; static; inline;
    {$ENDREGION}
    {$REGION 'GenericAttributeProfile_IGattDeviceServiceStatics2'}
    class function FromIdAsync(deviceId: HSTRING; sharingMode: GenericAttributeProfile_GattSharingMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId; cacheMode: BluetoothCacheMode): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid; cacheMode: BluetoothCacheMode): HSTRING; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalCharacteristicParameters
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalCharacteristicParameters
  // Instantiable: "GenericAttributeProfile_IGattLocalCharacteristicParameters"
  TGenericAttributeProfile_GattLocalCharacteristicParameters = class(TWinRTGenericImportI<GenericAttributeProfile_IGattLocalCharacteristicParameters>) end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattLocalDescriptorParameters
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattLocalDescriptorParameters
  // Instantiable: "GenericAttributeProfile_IGattLocalDescriptorParameters"
  TGenericAttributeProfile_GattLocalDescriptorParameters = class(TWinRTGenericImportI<GenericAttributeProfile_IGattLocalDescriptorParameters>) end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattPresentationFormat
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormat
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics"
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics2"
  TGenericAttributeProfile_GattPresentationFormat = class(TWinRTGenericImportS2<GenericAttributeProfile_IGattPresentationFormatStatics, GenericAttributeProfile_IGattPresentationFormatStatics2>)
  public
    {$REGION 'GenericAttributeProfile_IGattPresentationFormatStatics'}
    class function get_BluetoothSigAssignedNumbers: Byte; static; inline;
    class property BluetoothSigAssignedNumbers: Byte read get_BluetoothSigAssignedNumbers;
    {$ENDREGION}
    {$REGION 'GenericAttributeProfile_IGattPresentationFormatStatics2'}
    class function FromParts(formatType: Byte; exponent: Integer; &unit: Word; namespaceId: Byte; description: Word): GenericAttributeProfile_IGattPresentationFormat; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattPresentationFormatTypes
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatTypesStatics"
  TGenericAttributeProfile_GattPresentationFormatTypes = class(TWinRTGenericImportS<GenericAttributeProfile_IGattPresentationFormatTypesStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattPresentationFormatTypesStatics'}
    class function get_Boolean: Byte; static; inline;
    class function get_Bit2: Byte; static; inline;
    class function get_Nibble: Byte; static; inline;
    class function get_UInt8: Byte; static; inline;
    class function get_UInt12: Byte; static; inline;
    class function get_UInt16: Byte; static; inline;
    class function get_UInt24: Byte; static; inline;
    class function get_UInt32: Byte; static; inline;
    class function get_UInt48: Byte; static; inline;
    class function get_UInt64: Byte; static; inline;
    class function get_UInt128: Byte; static; inline;
    class function get_SInt8: Byte; static; inline;
    class function get_SInt12: Byte; static; inline;
    class function get_SInt16: Byte; static; inline;
    class function get_SInt24: Byte; static; inline;
    class function get_SInt32: Byte; static; inline;
    class function get_SInt48: Byte; static; inline;
    class function get_SInt64: Byte; static; inline;
    class function get_SInt128: Byte; static; inline;
    class function get_Float32: Byte; static; inline;
    class function get_Float64: Byte; static; inline;
    class function get_SFloat: Byte; static; inline;
    class function get_Float: Byte; static; inline;
    class function get_DUInt16: Byte; static; inline;
    class function get_Utf8: Byte; static; inline;
    class function get_Utf16: Byte; static; inline;
    class function get_Struct: Byte; static; inline;
    class property Bit2: Byte read get_Bit2;
    class property Boolean: Byte read get_Boolean;
    class property DUInt16: Byte read get_DUInt16;
    class property Float: Byte read get_Float;
    class property Float32: Byte read get_Float32;
    class property Float64: Byte read get_Float64;
    class property Nibble: Byte read get_Nibble;
    class property SFloat: Byte read get_SFloat;
    class property SInt12: Byte read get_SInt12;
    class property SInt128: Byte read get_SInt128;
    class property SInt16: Byte read get_SInt16;
    class property SInt24: Byte read get_SInt24;
    class property SInt32: Byte read get_SInt32;
    class property SInt48: Byte read get_SInt48;
    class property SInt64: Byte read get_SInt64;
    class property SInt8: Byte read get_SInt8;
    class property Struct: Byte read get_Struct;
    class property UInt12: Byte read get_UInt12;
    class property UInt128: Byte read get_UInt128;
    class property UInt16: Byte read get_UInt16;
    class property UInt24: Byte read get_UInt24;
    class property UInt32: Byte read get_UInt32;
    class property UInt48: Byte read get_UInt48;
    class property UInt64: Byte read get_UInt64;
    class property UInt8: Byte read get_UInt8;
    class property Utf16: Byte read get_Utf16;
    class property Utf8: Byte read get_Utf8;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattProtocolError
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattProtocolErrorStatics"
  TGenericAttributeProfile_GattProtocolError = class(TWinRTGenericImportS<GenericAttributeProfile_IGattProtocolErrorStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattProtocolErrorStatics'}
    class function get_InvalidHandle: Byte; static; inline;
    class function get_ReadNotPermitted: Byte; static; inline;
    class function get_WriteNotPermitted: Byte; static; inline;
    class function get_InvalidPdu: Byte; static; inline;
    class function get_InsufficientAuthentication: Byte; static; inline;
    class function get_RequestNotSupported: Byte; static; inline;
    class function get_InvalidOffset: Byte; static; inline;
    class function get_InsufficientAuthorization: Byte; static; inline;
    class function get_PrepareQueueFull: Byte; static; inline;
    class function get_AttributeNotFound: Byte; static; inline;
    class function get_AttributeNotLong: Byte; static; inline;
    class function get_InsufficientEncryptionKeySize: Byte; static; inline;
    class function get_InvalidAttributeValueLength: Byte; static; inline;
    class function get_UnlikelyError: Byte; static; inline;
    class function get_InsufficientEncryption: Byte; static; inline;
    class function get_UnsupportedGroupType: Byte; static; inline;
    class function get_InsufficientResources: Byte; static; inline;
    class property AttributeNotFound: Byte read get_AttributeNotFound;
    class property AttributeNotLong: Byte read get_AttributeNotLong;
    class property InsufficientAuthentication: Byte read get_InsufficientAuthentication;
    class property InsufficientAuthorization: Byte read get_InsufficientAuthorization;
    class property InsufficientEncryption: Byte read get_InsufficientEncryption;
    class property InsufficientEncryptionKeySize: Byte read get_InsufficientEncryptionKeySize;
    class property InsufficientResources: Byte read get_InsufficientResources;
    class property InvalidAttributeValueLength: Byte read get_InvalidAttributeValueLength;
    class property InvalidHandle: Byte read get_InvalidHandle;
    class property InvalidOffset: Byte read get_InvalidOffset;
    class property InvalidPdu: Byte read get_InvalidPdu;
    class property PrepareQueueFull: Byte read get_PrepareQueueFull;
    class property ReadNotPermitted: Byte read get_ReadNotPermitted;
    class property RequestNotSupported: Byte read get_RequestNotSupported;
    class property UnlikelyError: Byte read get_UnlikelyError;
    class property UnsupportedGroupType: Byte read get_UnsupportedGroupType;
    class property WriteNotPermitted: Byte read get_WriteNotPermitted;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattReliableWriteTransaction
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattReliableWriteTransaction2
  // Instantiable: "GenericAttributeProfile_IGattReliableWriteTransaction"
  TGenericAttributeProfile_GattReliableWriteTransaction = class(TWinRTGenericImportI<GenericAttributeProfile_IGattReliableWriteTransaction>) end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProvider
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProvider2
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderStatics"
  TGenericAttributeProfile_GattServiceProvider = class(TWinRTGenericImportS<GenericAttributeProfile_IGattServiceProviderStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattServiceProviderStatics'}
    class function CreateAsync(serviceUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProviderAdvertisingParameters
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters2
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderAdvertisingParameters3
  // Instantiable: "GenericAttributeProfile_IGattServiceProviderAdvertisingParameters"
  TGenericAttributeProfile_GattServiceProviderAdvertisingParameters = class(TWinRTGenericImportI<GenericAttributeProfile_IGattServiceProviderAdvertisingParameters>) end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceUuids
  // DualAPI
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics"
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics2"
  TGenericAttributeProfile_GattServiceUuids = class(TWinRTGenericImportS2<GenericAttributeProfile_IGattServiceUuidsStatics, GenericAttributeProfile_IGattServiceUuidsStatics2>)
  public
    {$REGION 'GenericAttributeProfile_IGattServiceUuidsStatics'}
    class function get_Battery: TGuid; static; inline;
    class function get_BloodPressure: TGuid; static; inline;
    class function get_CyclingSpeedAndCadence: TGuid; static; inline;
    class function get_GenericAccess: TGuid; static; inline;
    class function get_GenericAttribute: TGuid; static; inline;
    class function get_Glucose: TGuid; static; inline;
    class function get_HealthThermometer: TGuid; static; inline;
    class function get_HeartRate: TGuid; static; inline;
    class function get_RunningSpeedAndCadence: TGuid; static; inline;
    class property Battery: TGuid read get_Battery;
    class property BloodPressure: TGuid read get_BloodPressure;
    class property CyclingSpeedAndCadence: TGuid read get_CyclingSpeedAndCadence;
    class property GenericAccess: TGuid read get_GenericAccess;
    class property GenericAttribute: TGuid read get_GenericAttribute;
    class property Glucose: TGuid read get_Glucose;
    class property HealthThermometer: TGuid read get_HealthThermometer;
    class property HeartRate: TGuid read get_HeartRate;
    class property RunningSpeedAndCadence: TGuid read get_RunningSpeedAndCadence;
    {$ENDREGION}
    {$REGION 'GenericAttributeProfile_IGattServiceUuidsStatics2'}
    class function get_AlertNotification: TGuid; static; inline;
    class function get_CurrentTime: TGuid; static; inline;
    class function get_CyclingPower: TGuid; static; inline;
    class function get_DeviceInformation: TGuid; static; inline;
    class function get_HumanInterfaceDevice: TGuid; static; inline;
    class function get_ImmediateAlert: TGuid; static; inline;
    class function get_LinkLoss: TGuid; static; inline;
    class function get_LocationAndNavigation: TGuid; static; inline;
    class function get_NextDstChange: TGuid; static; inline;
    class function get_PhoneAlertStatus: TGuid; static; inline;
    class function get_ReferenceTimeUpdate: TGuid; static; inline;
    class function get_ScanParameters: TGuid; static; inline;
    class function get_TxPower: TGuid; static; inline;
    class property AlertNotification: TGuid read get_AlertNotification;
    class property CurrentTime: TGuid read get_CurrentTime;
    class property CyclingPower: TGuid read get_CyclingPower;
    class property DeviceInformation: TGuid read get_DeviceInformation;
    class property HumanInterfaceDevice: TGuid read get_HumanInterfaceDevice;
    class property ImmediateAlert: TGuid read get_ImmediateAlert;
    class property LinkLoss: TGuid read get_LinkLoss;
    class property LocationAndNavigation: TGuid read get_LocationAndNavigation;
    class property NextDstChange: TGuid read get_NextDstChange;
    class property PhoneAlertStatus: TGuid read get_PhoneAlertStatus;
    class property ReferenceTimeUpdate: TGuid read get_ReferenceTimeUpdate;
    class property ScanParameters: TGuid read get_ScanParameters;
    class property TxPower: TGuid read get_TxPower;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.GenericAttributeProfile.GattSession
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSession
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatics"
  TGenericAttributeProfile_GattSession = class(TWinRTGenericImportS<GenericAttributeProfile_IGattSessionStatics>)
  public
    {$REGION 'GenericAttributeProfile_IGattSessionStatics'}
    class function FromDeviceIdAsync(deviceId: IBluetoothDeviceId): IAsyncOperation_1__GenericAttributeProfile_IGattSession; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.Rfcomm.RfcommDeviceService
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService2
  // Implements: Windows.Foundation.IClosable
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceService3
  // Statics: "Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics"
  // Statics: "Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics2"
  TRfcomm_RfcommDeviceService = class(TWinRTGenericImportS2<Rfcomm_IRfcommDeviceServiceStatics, Rfcomm_IRfcommDeviceServiceStatics2>)
  public
    {$REGION 'Rfcomm_IRfcommDeviceServiceStatics'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Rfcomm_IRfcommDeviceService; static; inline;
    class function GetDeviceSelector(serviceId: Rfcomm_IRfcommServiceId): HSTRING; static; inline;
    {$ENDREGION}
    {$REGION 'Rfcomm_IRfcommDeviceServiceStatics2'}
    class function GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice; cacheMode: BluetoothCacheMode): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId): HSTRING; overload; static; inline;
    class function GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId; cacheMode: BluetoothCacheMode): HSTRING; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.Rfcomm.RfcommServiceId
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceId
  // Statics: "Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceIdStatics"
  TRfcomm_RfcommServiceId = class(TWinRTGenericImportS<Rfcomm_IRfcommServiceIdStatics>)
  public
    {$REGION 'Rfcomm_IRfcommServiceIdStatics'}
    class function FromUuid(uuid: TGuid): Rfcomm_IRfcommServiceId; static; inline;
    class function FromShortId(shortId: Cardinal): Rfcomm_IRfcommServiceId; static; inline;
    class function get_SerialPort: Rfcomm_IRfcommServiceId; static; inline;
    class function get_ObexObjectPush: Rfcomm_IRfcommServiceId; static; inline;
    class function get_ObexFileTransfer: Rfcomm_IRfcommServiceId; static; inline;
    class function get_PhoneBookAccessPce: Rfcomm_IRfcommServiceId; static; inline;
    class function get_PhoneBookAccessPse: Rfcomm_IRfcommServiceId; static; inline;
    class function get_GenericFileTransfer: Rfcomm_IRfcommServiceId; static; inline;
    class property GenericFileTransfer: Rfcomm_IRfcommServiceId read get_GenericFileTransfer;
    class property ObexFileTransfer: Rfcomm_IRfcommServiceId read get_ObexFileTransfer;
    class property ObexObjectPush: Rfcomm_IRfcommServiceId read get_ObexObjectPush;
    class property PhoneBookAccessPce: Rfcomm_IRfcommServiceId read get_PhoneBookAccessPce;
    class property PhoneBookAccessPse: Rfcomm_IRfcommServiceId read get_PhoneBookAccessPse;
    class property SerialPort: Rfcomm_IRfcommServiceId read get_SerialPort;
    {$ENDREGION}
 end;

  // Windows.Devices.Bluetooth.Rfcomm.RfcommServiceProvider
  // DualAPI
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider
  // Implements: Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProvider2
  // Statics: "Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProviderStatics"
  TRfcomm_RfcommServiceProvider = class(TWinRTGenericImportS<Rfcomm_IRfcommServiceProviderStatics>)
  public
    {$REGION 'Rfcomm_IRfcommServiceProviderStatics'}
    class function CreateAsync(serviceId: Rfcomm_IRfcommServiceId): IAsyncOperation_1__Rfcomm_IRfcommServiceProvider; static; inline;
    {$ENDREGION}
 end;

implementation

{ TBackground_GattServiceProviderConnection }

{$REGION 'Windows.Devices.Bluetooth.Background.IGattServiceProviderConnectionStatics'}
class function TBackground_GattServiceProviderConnection.get_AllServices: IMapView_2__HSTRING__Background_IGattServiceProviderConnection;
begin
  Result := Statics.get_AllServices;
end;
{$ENDREGION}

{ TBluetoothAdapter }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothAdapterStatics'}
class function TBluetoothAdapter.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TBluetoothAdapter.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothAdapter;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TBluetoothAdapter.GetDefaultAsync: IAsyncOperation_1__IBluetoothAdapter;
begin
  Result := Statics.GetDefaultAsync;
end;
{$ENDREGION}

{ TBluetoothClassOfDevice }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothClassOfDeviceStatics'}
class function TBluetoothClassOfDevice.FromRawValue(rawValue: Cardinal): IBluetoothClassOfDevice;
begin
  Result := Statics.FromRawValue(rawValue);
end;

class function TBluetoothClassOfDevice.FromParts(majorClass: BluetoothMajorClass; minorClass: BluetoothMinorClass; serviceCapabilities: BluetoothServiceCapabilities): IBluetoothClassOfDevice;
begin
  Result := Statics.FromParts(majorClass, minorClass, serviceCapabilities);
end;
{$ENDREGION}

{ TBluetoothDevice }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothDeviceStatics'}
class function TBluetoothDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TBluetoothDevice.FromHostNameAsync(hostName: IHostName): IAsyncOperation_1__IBluetoothDevice;
begin
  Result := Statics.FromHostNameAsync(hostName);
end;

class function TBluetoothDevice.FromBluetoothAddressAsync(address: UInt64): IAsyncOperation_1__IBluetoothDevice;
begin
  Result := Statics.FromBluetoothAddressAsync(address);
end;

class function TBluetoothDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.IBluetoothDeviceStatics2'}
class function TBluetoothDevice.GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromPairingState(pairingState);
end;

class function TBluetoothDevice.GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromConnectionStatus(connectionStatus);
end;

class function TBluetoothDevice.GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromDeviceName(deviceName);
end;

class function TBluetoothDevice.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress);
end;

class function TBluetoothDevice.GetDeviceSelectorFromClassOfDevice(classOfDevice: IBluetoothClassOfDevice): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromClassOfDevice(classOfDevice);
end;
{$ENDREGION}

{ TBluetoothDeviceId }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothDeviceIdStatics'}
class function TBluetoothDeviceId.FromId(deviceId: HSTRING): IBluetoothDeviceId;
begin
  Result := Statics.FromId(deviceId);
end;
{$ENDREGION}

{ TBluetoothLEAppearance }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEAppearanceStatics'}
class function TBluetoothLEAppearance.FromRawValue(rawValue: Word): IBluetoothLEAppearance;
begin
  Result := Statics.FromRawValue(rawValue);
end;

class function TBluetoothLEAppearance.FromParts(appearanceCategory: Word; appearanceSubCategory: Word): IBluetoothLEAppearance;
begin
  Result := Statics.FromParts(appearanceCategory, appearanceSubCategory);
end;
{$ENDREGION}

{ TBluetoothLEAppearanceCategories }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEAppearanceCategoriesStatics'}
class function TBluetoothLEAppearanceCategories.get_Uncategorized: Word;
begin
  Result := Statics.get_Uncategorized;
end;

class function TBluetoothLEAppearanceCategories.get_Phone: Word;
begin
  Result := Statics.get_Phone;
end;

class function TBluetoothLEAppearanceCategories.get_Computer: Word;
begin
  Result := Statics.get_Computer;
end;

class function TBluetoothLEAppearanceCategories.get_Watch: Word;
begin
  Result := Statics.get_Watch;
end;

class function TBluetoothLEAppearanceCategories.get_Clock: Word;
begin
  Result := Statics.get_Clock;
end;

class function TBluetoothLEAppearanceCategories.get_Display: Word;
begin
  Result := Statics.get_Display;
end;

class function TBluetoothLEAppearanceCategories.get_RemoteControl: Word;
begin
  Result := Statics.get_RemoteControl;
end;

class function TBluetoothLEAppearanceCategories.get_EyeGlasses: Word;
begin
  Result := Statics.get_EyeGlasses;
end;

class function TBluetoothLEAppearanceCategories.get_Tag: Word;
begin
  Result := Statics.get_Tag;
end;

class function TBluetoothLEAppearanceCategories.get_Keyring: Word;
begin
  Result := Statics.get_Keyring;
end;

class function TBluetoothLEAppearanceCategories.get_MediaPlayer: Word;
begin
  Result := Statics.get_MediaPlayer;
end;

class function TBluetoothLEAppearanceCategories.get_BarcodeScanner: Word;
begin
  Result := Statics.get_BarcodeScanner;
end;

class function TBluetoothLEAppearanceCategories.get_Thermometer: Word;
begin
  Result := Statics.get_Thermometer;
end;

class function TBluetoothLEAppearanceCategories.get_HeartRate: Word;
begin
  Result := Statics.get_HeartRate;
end;

class function TBluetoothLEAppearanceCategories.get_BloodPressure: Word;
begin
  Result := Statics.get_BloodPressure;
end;

class function TBluetoothLEAppearanceCategories.get_HumanInterfaceDevice: Word;
begin
  Result := Statics.get_HumanInterfaceDevice;
end;

class function TBluetoothLEAppearanceCategories.get_GlucoseMeter: Word;
begin
  Result := Statics.get_GlucoseMeter;
end;

class function TBluetoothLEAppearanceCategories.get_RunningWalking: Word;
begin
  Result := Statics.get_RunningWalking;
end;

class function TBluetoothLEAppearanceCategories.get_Cycling: Word;
begin
  Result := Statics.get_Cycling;
end;

class function TBluetoothLEAppearanceCategories.get_PulseOximeter: Word;
begin
  Result := Statics.get_PulseOximeter;
end;

class function TBluetoothLEAppearanceCategories.get_WeightScale: Word;
begin
  Result := Statics.get_WeightScale;
end;

class function TBluetoothLEAppearanceCategories.get_OutdoorSportActivity: Word;
begin
  Result := Statics.get_OutdoorSportActivity;
end;
{$ENDREGION}

{ TBluetoothLEAppearanceSubcategories }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEAppearanceSubcategoriesStatics'}
class function TBluetoothLEAppearanceSubcategories.get_Generic: Word;
begin
  Result := Statics.get_Generic;
end;

class function TBluetoothLEAppearanceSubcategories.get_SportsWatch: Word;
begin
  Result := Statics.get_SportsWatch;
end;

class function TBluetoothLEAppearanceSubcategories.get_ThermometerEar: Word;
begin
  Result := Statics.get_ThermometerEar;
end;

class function TBluetoothLEAppearanceSubcategories.get_HeartRateBelt: Word;
begin
  Result := Statics.get_HeartRateBelt;
end;

class function TBluetoothLEAppearanceSubcategories.get_BloodPressureArm: Word;
begin
  Result := Statics.get_BloodPressureArm;
end;

class function TBluetoothLEAppearanceSubcategories.get_BloodPressureWrist: Word;
begin
  Result := Statics.get_BloodPressureWrist;
end;

class function TBluetoothLEAppearanceSubcategories.get_Keyboard: Word;
begin
  Result := Statics.get_Keyboard;
end;

class function TBluetoothLEAppearanceSubcategories.get_Mouse: Word;
begin
  Result := Statics.get_Mouse;
end;

class function TBluetoothLEAppearanceSubcategories.get_Joystick: Word;
begin
  Result := Statics.get_Joystick;
end;

class function TBluetoothLEAppearanceSubcategories.get_Gamepad: Word;
begin
  Result := Statics.get_Gamepad;
end;

class function TBluetoothLEAppearanceSubcategories.get_DigitizerTablet: Word;
begin
  Result := Statics.get_DigitizerTablet;
end;

class function TBluetoothLEAppearanceSubcategories.get_CardReader: Word;
begin
  Result := Statics.get_CardReader;
end;

class function TBluetoothLEAppearanceSubcategories.get_DigitalPen: Word;
begin
  Result := Statics.get_DigitalPen;
end;

class function TBluetoothLEAppearanceSubcategories.get_BarcodeScanner: Word;
begin
  Result := Statics.get_BarcodeScanner;
end;

class function TBluetoothLEAppearanceSubcategories.get_RunningWalkingInShoe: Word;
begin
  Result := Statics.get_RunningWalkingInShoe;
end;

class function TBluetoothLEAppearanceSubcategories.get_RunningWalkingOnShoe: Word;
begin
  Result := Statics.get_RunningWalkingOnShoe;
end;

class function TBluetoothLEAppearanceSubcategories.get_RunningWalkingOnHip: Word;
begin
  Result := Statics.get_RunningWalkingOnHip;
end;

class function TBluetoothLEAppearanceSubcategories.get_CyclingComputer: Word;
begin
  Result := Statics.get_CyclingComputer;
end;

class function TBluetoothLEAppearanceSubcategories.get_CyclingSpeedSensor: Word;
begin
  Result := Statics.get_CyclingSpeedSensor;
end;

class function TBluetoothLEAppearanceSubcategories.get_CyclingCadenceSensor: Word;
begin
  Result := Statics.get_CyclingCadenceSensor;
end;

class function TBluetoothLEAppearanceSubcategories.get_CyclingPowerSensor: Word;
begin
  Result := Statics.get_CyclingPowerSensor;
end;

class function TBluetoothLEAppearanceSubcategories.get_CyclingSpeedCadenceSensor: Word;
begin
  Result := Statics.get_CyclingSpeedCadenceSensor;
end;

class function TBluetoothLEAppearanceSubcategories.get_OximeterFingertip: Word;
begin
  Result := Statics.get_OximeterFingertip;
end;

class function TBluetoothLEAppearanceSubcategories.get_OximeterWristWorn: Word;
begin
  Result := Statics.get_OximeterWristWorn;
end;

class function TBluetoothLEAppearanceSubcategories.get_LocationDisplay: Word;
begin
  Result := Statics.get_LocationDisplay;
end;

class function TBluetoothLEAppearanceSubcategories.get_LocationNavigationDisplay: Word;
begin
  Result := Statics.get_LocationNavigationDisplay;
end;

class function TBluetoothLEAppearanceSubcategories.get_LocationPod: Word;
begin
  Result := Statics.get_LocationPod;
end;

class function TBluetoothLEAppearanceSubcategories.get_LocationNavigationPod: Word;
begin
  Result := Statics.get_LocationNavigationPod;
end;
{$ENDREGION}

{ TBluetoothLEDevice }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics'}
class function TBluetoothLEDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBluetoothLEDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TBluetoothLEDevice.FromBluetoothAddressAsync(bluetoothAddress: UInt64): IAsyncOperation_1__IBluetoothLEDevice;
begin
  Result := Statics.FromBluetoothAddressAsync(bluetoothAddress);
end;

class function TBluetoothLEDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEDeviceStatics2'}
class function TBluetoothLEDevice.GetDeviceSelectorFromPairingState(pairingState: Boolean): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromPairingState(pairingState);
end;

class function TBluetoothLEDevice.GetDeviceSelectorFromConnectionStatus(connectionStatus: BluetoothConnectionStatus): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromConnectionStatus(connectionStatus);
end;

class function TBluetoothLEDevice.GetDeviceSelectorFromDeviceName(deviceName: HSTRING): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromDeviceName(deviceName);
end;

class function TBluetoothLEDevice.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress);
end;

class function TBluetoothLEDevice.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromBluetoothAddress(bluetoothAddress, bluetoothAddressType);
end;

class function TBluetoothLEDevice.GetDeviceSelectorFromAppearance(appearance: IBluetoothLEAppearance): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorFromAppearance(appearance);
end;

class function TBluetoothLEDevice.FromBluetoothAddressAsync(bluetoothAddress: UInt64; bluetoothAddressType: BluetoothAddressType): IAsyncOperation_1__IBluetoothLEDevice;
begin
  Result := Statics2.FromBluetoothAddressAsync(bluetoothAddress, bluetoothAddressType);
end;
{$ENDREGION}

{ TBluetoothLEPreferredConnectionParameters }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothLEPreferredConnectionParametersStatics'}
class function TBluetoothLEPreferredConnectionParameters.get_Balanced: IBluetoothLEPreferredConnectionParameters;
begin
  Result := Statics.get_Balanced;
end;

class function TBluetoothLEPreferredConnectionParameters.get_ThroughputOptimized: IBluetoothLEPreferredConnectionParameters;
begin
  Result := Statics.get_ThroughputOptimized;
end;

class function TBluetoothLEPreferredConnectionParameters.get_PowerOptimized: IBluetoothLEPreferredConnectionParameters;
begin
  Result := Statics.get_PowerOptimized;
end;
{$ENDREGION}

{ TBluetoothSignalStrengthFilter }

{ TBluetoothUuidHelper }

{$REGION 'Windows.Devices.Bluetooth.IBluetoothUuidHelperStatics'}
class function TBluetoothUuidHelper.FromShortId(shortId: Cardinal): TGuid;
begin
  Result := Statics.FromShortId(shortId);
end;

class function TBluetoothUuidHelper.TryGetShortId(uuid: TGuid): IReference_1__Cardinal;
begin
  Result := Statics.TryGetShortId(uuid);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattCharacteristic }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicStatics'}
class function TGenericAttributeProfile_GattCharacteristic.ConvertShortIdToUuid(shortId: Word): TGuid;
begin
  Result := Statics.ConvertShortIdToUuid(shortId);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattCharacteristicUuids }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics'}
class function TGenericAttributeProfile_GattCharacteristicUuids.get_BatteryLevel: TGuid;
begin
  Result := Statics.get_BatteryLevel;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BloodPressureFeature: TGuid;
begin
  Result := Statics.get_BloodPressureFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BloodPressureMeasurement: TGuid;
begin
  Result := Statics.get_BloodPressureMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BodySensorLocation: TGuid;
begin
  Result := Statics.get_BodySensorLocation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CscFeature: TGuid;
begin
  Result := Statics.get_CscFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CscMeasurement: TGuid;
begin
  Result := Statics.get_CscMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GlucoseFeature: TGuid;
begin
  Result := Statics.get_GlucoseFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GlucoseMeasurement: TGuid;
begin
  Result := Statics.get_GlucoseMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GlucoseMeasurementContext: TGuid;
begin
  Result := Statics.get_GlucoseMeasurementContext;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_HeartRateControlPoint: TGuid;
begin
  Result := Statics.get_HeartRateControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_HeartRateMeasurement: TGuid;
begin
  Result := Statics.get_HeartRateMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_IntermediateCuffPressure: TGuid;
begin
  Result := Statics.get_IntermediateCuffPressure;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_IntermediateTemperature: TGuid;
begin
  Result := Statics.get_IntermediateTemperature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_MeasurementInterval: TGuid;
begin
  Result := Statics.get_MeasurementInterval;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_RecordAccessControlPoint: TGuid;
begin
  Result := Statics.get_RecordAccessControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_RscFeature: TGuid;
begin
  Result := Statics.get_RscFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_RscMeasurement: TGuid;
begin
  Result := Statics.get_RscMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SCControlPoint: TGuid;
begin
  Result := Statics.get_SCControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SensorLocation: TGuid;
begin
  Result := Statics.get_SensorLocation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TemperatureMeasurement: TGuid;
begin
  Result := Statics.get_TemperatureMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TemperatureType: TGuid;
begin
  Result := Statics.get_TemperatureType;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattCharacteristicUuidsStatics2'}
class function TGenericAttributeProfile_GattCharacteristicUuids.get_AlertCategoryId: TGuid;
begin
  Result := Statics2.get_AlertCategoryId;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_AlertCategoryIdBitMask: TGuid;
begin
  Result := Statics2.get_AlertCategoryIdBitMask;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_AlertLevel: TGuid;
begin
  Result := Statics2.get_AlertLevel;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_AlertNotificationControlPoint: TGuid;
begin
  Result := Statics2.get_AlertNotificationControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_AlertStatus: TGuid;
begin
  Result := Statics2.get_AlertStatus;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GapAppearance: TGuid;
begin
  Result := Statics2.get_GapAppearance;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BootKeyboardInputReport: TGuid;
begin
  Result := Statics2.get_BootKeyboardInputReport;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BootKeyboardOutputReport: TGuid;
begin
  Result := Statics2.get_BootKeyboardOutputReport;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_BootMouseInputReport: TGuid;
begin
  Result := Statics2.get_BootMouseInputReport;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CurrentTime: TGuid;
begin
  Result := Statics2.get_CurrentTime;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CyclingPowerControlPoint: TGuid;
begin
  Result := Statics2.get_CyclingPowerControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CyclingPowerFeature: TGuid;
begin
  Result := Statics2.get_CyclingPowerFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CyclingPowerMeasurement: TGuid;
begin
  Result := Statics2.get_CyclingPowerMeasurement;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_CyclingPowerVector: TGuid;
begin
  Result := Statics2.get_CyclingPowerVector;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_DateTime: TGuid;
begin
  Result := Statics2.get_DateTime;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_DayDateTime: TGuid;
begin
  Result := Statics2.get_DayDateTime;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_DayOfWeek: TGuid;
begin
  Result := Statics2.get_DayOfWeek;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GapDeviceName: TGuid;
begin
  Result := Statics2.get_GapDeviceName;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_DstOffset: TGuid;
begin
  Result := Statics2.get_DstOffset;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ExactTime256: TGuid;
begin
  Result := Statics2.get_ExactTime256;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_FirmwareRevisionString: TGuid;
begin
  Result := Statics2.get_FirmwareRevisionString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_HardwareRevisionString: TGuid;
begin
  Result := Statics2.get_HardwareRevisionString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_HidControlPoint: TGuid;
begin
  Result := Statics2.get_HidControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_HidInformation: TGuid;
begin
  Result := Statics2.get_HidInformation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_Ieee1107320601RegulatoryCertificationDataList: TGuid;
begin
  Result := Statics2.get_Ieee1107320601RegulatoryCertificationDataList;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_LnControlPoint: TGuid;
begin
  Result := Statics2.get_LnControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_LnFeature: TGuid;
begin
  Result := Statics2.get_LnFeature;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_LocalTimeInformation: TGuid;
begin
  Result := Statics2.get_LocalTimeInformation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_LocationAndSpeed: TGuid;
begin
  Result := Statics2.get_LocationAndSpeed;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ManufacturerNameString: TGuid;
begin
  Result := Statics2.get_ManufacturerNameString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ModelNumberString: TGuid;
begin
  Result := Statics2.get_ModelNumberString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_Navigation: TGuid;
begin
  Result := Statics2.get_Navigation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_NewAlert: TGuid;
begin
  Result := Statics2.get_NewAlert;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GapPeripheralPreferredConnectionParameters: TGuid;
begin
  Result := Statics2.get_GapPeripheralPreferredConnectionParameters;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GapPeripheralPrivacyFlag: TGuid;
begin
  Result := Statics2.get_GapPeripheralPrivacyFlag;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_PnpId: TGuid;
begin
  Result := Statics2.get_PnpId;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_PositionQuality: TGuid;
begin
  Result := Statics2.get_PositionQuality;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ProtocolMode: TGuid;
begin
  Result := Statics2.get_ProtocolMode;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GapReconnectionAddress: TGuid;
begin
  Result := Statics2.get_GapReconnectionAddress;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ReferenceTimeInformation: TGuid;
begin
  Result := Statics2.get_ReferenceTimeInformation;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_Report: TGuid;
begin
  Result := Statics2.get_Report;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ReportMap: TGuid;
begin
  Result := Statics2.get_ReportMap;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_RingerControlPoint: TGuid;
begin
  Result := Statics2.get_RingerControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_RingerSetting: TGuid;
begin
  Result := Statics2.get_RingerSetting;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ScanIntervalWindow: TGuid;
begin
  Result := Statics2.get_ScanIntervalWindow;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_ScanRefresh: TGuid;
begin
  Result := Statics2.get_ScanRefresh;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SerialNumberString: TGuid;
begin
  Result := Statics2.get_SerialNumberString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_GattServiceChanged: TGuid;
begin
  Result := Statics2.get_GattServiceChanged;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SoftwareRevisionString: TGuid;
begin
  Result := Statics2.get_SoftwareRevisionString;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SupportedNewAlertCategory: TGuid;
begin
  Result := Statics2.get_SupportedNewAlertCategory;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SupportUnreadAlertCategory: TGuid;
begin
  Result := Statics2.get_SupportUnreadAlertCategory;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_SystemId: TGuid;
begin
  Result := Statics2.get_SystemId;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeAccuracy: TGuid;
begin
  Result := Statics2.get_TimeAccuracy;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeSource: TGuid;
begin
  Result := Statics2.get_TimeSource;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeUpdateControlPoint: TGuid;
begin
  Result := Statics2.get_TimeUpdateControlPoint;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeUpdateState: TGuid;
begin
  Result := Statics2.get_TimeUpdateState;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeWithDst: TGuid;
begin
  Result := Statics2.get_TimeWithDst;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TimeZone: TGuid;
begin
  Result := Statics2.get_TimeZone;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_TxPowerLevel: TGuid;
begin
  Result := Statics2.get_TxPowerLevel;
end;

class function TGenericAttributeProfile_GattCharacteristicUuids.get_UnreadAlertStatus: TGuid;
begin
  Result := Statics2.get_UnreadAlertStatus;
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattDescriptor }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorStatics'}
class function TGenericAttributeProfile_GattDescriptor.ConvertShortIdToUuid(shortId: Word): TGuid;
begin
  Result := Statics.ConvertShortIdToUuid(shortId);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattDescriptorUuids }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDescriptorUuidsStatics'}
class function TGenericAttributeProfile_GattDescriptorUuids.get_CharacteristicAggregateFormat: TGuid;
begin
  Result := Statics.get_CharacteristicAggregateFormat;
end;

class function TGenericAttributeProfile_GattDescriptorUuids.get_CharacteristicExtendedProperties: TGuid;
begin
  Result := Statics.get_CharacteristicExtendedProperties;
end;

class function TGenericAttributeProfile_GattDescriptorUuids.get_CharacteristicPresentationFormat: TGuid;
begin
  Result := Statics.get_CharacteristicPresentationFormat;
end;

class function TGenericAttributeProfile_GattDescriptorUuids.get_CharacteristicUserDescription: TGuid;
begin
  Result := Statics.get_CharacteristicUserDescription;
end;

class function TGenericAttributeProfile_GattDescriptorUuids.get_ClientCharacteristicConfiguration: TGuid;
begin
  Result := Statics.get_ClientCharacteristicConfiguration;
end;

class function TGenericAttributeProfile_GattDescriptorUuids.get_ServerCharacteristicConfiguration: TGuid;
begin
  Result := Statics.get_ServerCharacteristicConfiguration;
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattDeviceService }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics'}
class function TGenericAttributeProfile_GattDeviceService.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorFromUuid(serviceUuid: TGuid): HSTRING;
begin
  Result := Statics.GetDeviceSelectorFromUuid(serviceUuid);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorFromShortId(serviceShortId: Word): HSTRING;
begin
  Result := Statics.GetDeviceSelectorFromShortId(serviceShortId);
end;

class function TGenericAttributeProfile_GattDeviceService.ConvertShortIdToUuid(shortId: Word): TGuid;
begin
  Result := Statics.ConvertShortIdToUuid(shortId);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattDeviceServiceStatics2'}
class function TGenericAttributeProfile_GattDeviceService.FromIdAsync(deviceId: HSTRING; sharingMode: GenericAttributeProfile_GattSharingMode): IAsyncOperation_1__GenericAttributeProfile_IGattDeviceService;
begin
  Result := Statics2.FromIdAsync(deviceId, sharingMode);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId: IBluetoothDeviceId; cacheMode: BluetoothCacheMode): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceId(bluetoothDeviceId, cacheMode);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId, serviceUuid);
end;

class function TGenericAttributeProfile_GattDeviceService.GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId: IBluetoothDeviceId; serviceUuid: TGuid; cacheMode: BluetoothCacheMode): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceIdAndUuid(bluetoothDeviceId, serviceUuid, cacheMode);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattLocalCharacteristicParameters }

{ TGenericAttributeProfile_GattLocalDescriptorParameters }

{ TGenericAttributeProfile_GattPresentationFormat }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics'}
class function TGenericAttributeProfile_GattPresentationFormat.get_BluetoothSigAssignedNumbers: Byte;
begin
  Result := Statics.get_BluetoothSigAssignedNumbers;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatStatics2'}
class function TGenericAttributeProfile_GattPresentationFormat.FromParts(formatType: Byte; exponent: Integer; &unit: Word; namespaceId: Byte; description: Word): GenericAttributeProfile_IGattPresentationFormat;
begin
  Result := Statics2.FromParts(formatType, exponent, &unit, namespaceId, description);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattPresentationFormatTypes }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattPresentationFormatTypesStatics'}
class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Boolean: Byte;
begin
  Result := Statics.get_Boolean;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Bit2: Byte;
begin
  Result := Statics.get_Bit2;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Nibble: Byte;
begin
  Result := Statics.get_Nibble;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt8: Byte;
begin
  Result := Statics.get_UInt8;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt12: Byte;
begin
  Result := Statics.get_UInt12;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt16: Byte;
begin
  Result := Statics.get_UInt16;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt24: Byte;
begin
  Result := Statics.get_UInt24;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt32: Byte;
begin
  Result := Statics.get_UInt32;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt48: Byte;
begin
  Result := Statics.get_UInt48;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt64: Byte;
begin
  Result := Statics.get_UInt64;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_UInt128: Byte;
begin
  Result := Statics.get_UInt128;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt8: Byte;
begin
  Result := Statics.get_SInt8;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt12: Byte;
begin
  Result := Statics.get_SInt12;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt16: Byte;
begin
  Result := Statics.get_SInt16;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt24: Byte;
begin
  Result := Statics.get_SInt24;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt32: Byte;
begin
  Result := Statics.get_SInt32;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt48: Byte;
begin
  Result := Statics.get_SInt48;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt64: Byte;
begin
  Result := Statics.get_SInt64;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SInt128: Byte;
begin
  Result := Statics.get_SInt128;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Float32: Byte;
begin
  Result := Statics.get_Float32;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Float64: Byte;
begin
  Result := Statics.get_Float64;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_SFloat: Byte;
begin
  Result := Statics.get_SFloat;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Float: Byte;
begin
  Result := Statics.get_Float;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_DUInt16: Byte;
begin
  Result := Statics.get_DUInt16;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Utf8: Byte;
begin
  Result := Statics.get_Utf8;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Utf16: Byte;
begin
  Result := Statics.get_Utf16;
end;

class function TGenericAttributeProfile_GattPresentationFormatTypes.get_Struct: Byte;
begin
  Result := Statics.get_Struct;
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattProtocolError }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattProtocolErrorStatics'}
class function TGenericAttributeProfile_GattProtocolError.get_InvalidHandle: Byte;
begin
  Result := Statics.get_InvalidHandle;
end;

class function TGenericAttributeProfile_GattProtocolError.get_ReadNotPermitted: Byte;
begin
  Result := Statics.get_ReadNotPermitted;
end;

class function TGenericAttributeProfile_GattProtocolError.get_WriteNotPermitted: Byte;
begin
  Result := Statics.get_WriteNotPermitted;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InvalidPdu: Byte;
begin
  Result := Statics.get_InvalidPdu;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InsufficientAuthentication: Byte;
begin
  Result := Statics.get_InsufficientAuthentication;
end;

class function TGenericAttributeProfile_GattProtocolError.get_RequestNotSupported: Byte;
begin
  Result := Statics.get_RequestNotSupported;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InvalidOffset: Byte;
begin
  Result := Statics.get_InvalidOffset;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InsufficientAuthorization: Byte;
begin
  Result := Statics.get_InsufficientAuthorization;
end;

class function TGenericAttributeProfile_GattProtocolError.get_PrepareQueueFull: Byte;
begin
  Result := Statics.get_PrepareQueueFull;
end;

class function TGenericAttributeProfile_GattProtocolError.get_AttributeNotFound: Byte;
begin
  Result := Statics.get_AttributeNotFound;
end;

class function TGenericAttributeProfile_GattProtocolError.get_AttributeNotLong: Byte;
begin
  Result := Statics.get_AttributeNotLong;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InsufficientEncryptionKeySize: Byte;
begin
  Result := Statics.get_InsufficientEncryptionKeySize;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InvalidAttributeValueLength: Byte;
begin
  Result := Statics.get_InvalidAttributeValueLength;
end;

class function TGenericAttributeProfile_GattProtocolError.get_UnlikelyError: Byte;
begin
  Result := Statics.get_UnlikelyError;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InsufficientEncryption: Byte;
begin
  Result := Statics.get_InsufficientEncryption;
end;

class function TGenericAttributeProfile_GattProtocolError.get_UnsupportedGroupType: Byte;
begin
  Result := Statics.get_UnsupportedGroupType;
end;

class function TGenericAttributeProfile_GattProtocolError.get_InsufficientResources: Byte;
begin
  Result := Statics.get_InsufficientResources;
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattReliableWriteTransaction }

{ TGenericAttributeProfile_GattServiceProvider }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceProviderStatics'}
class function TGenericAttributeProfile_GattServiceProvider.CreateAsync(serviceUuid: TGuid): IAsyncOperation_1__GenericAttributeProfile_IGattServiceProviderResult;
begin
  Result := Statics.CreateAsync(serviceUuid);
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattServiceProviderAdvertisingParameters }

{ TGenericAttributeProfile_GattServiceUuids }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics'}
class function TGenericAttributeProfile_GattServiceUuids.get_Battery: TGuid;
begin
  Result := Statics.get_Battery;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_BloodPressure: TGuid;
begin
  Result := Statics.get_BloodPressure;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_CyclingSpeedAndCadence: TGuid;
begin
  Result := Statics.get_CyclingSpeedAndCadence;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_GenericAccess: TGuid;
begin
  Result := Statics.get_GenericAccess;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_GenericAttribute: TGuid;
begin
  Result := Statics.get_GenericAttribute;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_Glucose: TGuid;
begin
  Result := Statics.get_Glucose;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_HealthThermometer: TGuid;
begin
  Result := Statics.get_HealthThermometer;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_HeartRate: TGuid;
begin
  Result := Statics.get_HeartRate;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_RunningSpeedAndCadence: TGuid;
begin
  Result := Statics.get_RunningSpeedAndCadence;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattServiceUuidsStatics2'}
class function TGenericAttributeProfile_GattServiceUuids.get_AlertNotification: TGuid;
begin
  Result := Statics2.get_AlertNotification;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_CurrentTime: TGuid;
begin
  Result := Statics2.get_CurrentTime;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_CyclingPower: TGuid;
begin
  Result := Statics2.get_CyclingPower;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_DeviceInformation: TGuid;
begin
  Result := Statics2.get_DeviceInformation;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_HumanInterfaceDevice: TGuid;
begin
  Result := Statics2.get_HumanInterfaceDevice;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_ImmediateAlert: TGuid;
begin
  Result := Statics2.get_ImmediateAlert;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_LinkLoss: TGuid;
begin
  Result := Statics2.get_LinkLoss;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_LocationAndNavigation: TGuid;
begin
  Result := Statics2.get_LocationAndNavigation;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_NextDstChange: TGuid;
begin
  Result := Statics2.get_NextDstChange;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_PhoneAlertStatus: TGuid;
begin
  Result := Statics2.get_PhoneAlertStatus;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_ReferenceTimeUpdate: TGuid;
begin
  Result := Statics2.get_ReferenceTimeUpdate;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_ScanParameters: TGuid;
begin
  Result := Statics2.get_ScanParameters;
end;

class function TGenericAttributeProfile_GattServiceUuids.get_TxPower: TGuid;
begin
  Result := Statics2.get_TxPower;
end;
{$ENDREGION}

{ TGenericAttributeProfile_GattSession }

{$REGION 'Windows.Devices.Bluetooth.GenericAttributeProfile.IGattSessionStatics'}
class function TGenericAttributeProfile_GattSession.FromDeviceIdAsync(deviceId: IBluetoothDeviceId): IAsyncOperation_1__GenericAttributeProfile_IGattSession;
begin
  Result := Statics.FromDeviceIdAsync(deviceId);
end;
{$ENDREGION}

{ TRfcomm_RfcommDeviceService }

{$REGION 'Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics'}
class function TRfcomm_RfcommDeviceService.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Rfcomm_IRfcommDeviceService;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TRfcomm_RfcommDeviceService.GetDeviceSelector(serviceId: Rfcomm_IRfcommServiceId): HSTRING;
begin
  Result := Statics.GetDeviceSelector(serviceId);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Bluetooth.Rfcomm.IRfcommDeviceServiceStatics2'}
class function TRfcomm_RfcommDeviceService.GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDevice(bluetoothDevice);
end;

class function TRfcomm_RfcommDeviceService.GetDeviceSelectorForBluetoothDevice(bluetoothDevice: IBluetoothDevice; cacheMode: BluetoothCacheMode): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDevice(bluetoothDevice, cacheMode);
end;

class function TRfcomm_RfcommDeviceService.GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice, serviceId);
end;

class function TRfcomm_RfcommDeviceService.GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice: IBluetoothDevice; serviceId: Rfcomm_IRfcommServiceId; cacheMode: BluetoothCacheMode): HSTRING;
begin
  Result := Statics2.GetDeviceSelectorForBluetoothDeviceAndServiceId(bluetoothDevice, serviceId, cacheMode);
end;
{$ENDREGION}

{ TRfcomm_RfcommServiceId }

{$REGION 'Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceIdStatics'}
class function TRfcomm_RfcommServiceId.FromUuid(uuid: TGuid): Rfcomm_IRfcommServiceId;
begin
  Result := Statics.FromUuid(uuid);
end;

class function TRfcomm_RfcommServiceId.FromShortId(shortId: Cardinal): Rfcomm_IRfcommServiceId;
begin
  Result := Statics.FromShortId(shortId);
end;

class function TRfcomm_RfcommServiceId.get_SerialPort: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_SerialPort;
end;

class function TRfcomm_RfcommServiceId.get_ObexObjectPush: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_ObexObjectPush;
end;

class function TRfcomm_RfcommServiceId.get_ObexFileTransfer: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_ObexFileTransfer;
end;

class function TRfcomm_RfcommServiceId.get_PhoneBookAccessPce: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_PhoneBookAccessPce;
end;

class function TRfcomm_RfcommServiceId.get_PhoneBookAccessPse: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_PhoneBookAccessPse;
end;

class function TRfcomm_RfcommServiceId.get_GenericFileTransfer: Rfcomm_IRfcommServiceId;
begin
  Result := Statics.get_GenericFileTransfer;
end;
{$ENDREGION}

{ TRfcomm_RfcommServiceProvider }

{$REGION 'Windows.Devices.Bluetooth.Rfcomm.IRfcommServiceProviderStatics'}
class function TRfcomm_RfcommServiceProvider.CreateAsync(serviceId: Rfcomm_IRfcommServiceId): IAsyncOperation_1__Rfcomm_IRfcommServiceProvider;
begin
  Result := Statics.CreateAsync(serviceId);
end;
{$ENDREGION}

end.
