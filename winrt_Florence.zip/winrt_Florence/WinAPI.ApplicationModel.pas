{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.ApplicationModel;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Storage,
  Winapi.ApplicationModel.DataTransfer,
  Winapi.Foundation,
  Winapi.ApplicationModel.Core,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  Activation_ActivationKind = Winapi.CommonTypes.Activation_ActivationKind;
  PActivation_ActivationKind = Winapi.CommonTypes.PActivation_ActivationKind;
  Activation_ApplicationExecutionState = Winapi.CommonTypes.Activation_ApplicationExecutionState;
  PActivation_ApplicationExecutionState = Winapi.CommonTypes.PActivation_ApplicationExecutionState;
  Activation_IActivatedEventArgs = Winapi.CommonTypes.Activation_IActivatedEventArgs;
  PActivation_IActivatedEventArgs = Winapi.CommonTypes.PActivation_IActivatedEventArgs;
  Activation_IBackgroundActivatedEventArgs = Winapi.CommonTypes.Activation_IBackgroundActivatedEventArgs;
  PActivation_IBackgroundActivatedEventArgs = Winapi.CommonTypes.PActivation_IBackgroundActivatedEventArgs;
  Activation_ISplashScreen = Winapi.CommonTypes.Activation_ISplashScreen;
  PActivation_ISplashScreen = Winapi.CommonTypes.PActivation_ISplashScreen;
  IAppDisplayInfo = Winapi.CommonTypes.IAppDisplayInfo;
  PIAppDisplayInfo = Winapi.CommonTypes.PIAppDisplayInfo;
  IAppInfo = Winapi.CommonTypes.IAppInfo;
  PIAppInfo = Winapi.CommonTypes.PIAppInfo;
  Search_ILocalContentSuggestionSettings = Winapi.CommonTypes.Search_ILocalContentSuggestionSettings;
  PSearch_ILocalContentSuggestionSettings = Winapi.CommonTypes.PSearch_ILocalContentSuggestionSettings;
  Search_ISearchQueryLinguisticDetails = Winapi.CommonTypes.Search_ISearchQueryLinguisticDetails;
  PSearch_ISearchQueryLinguisticDetails = Winapi.CommonTypes.PSearch_ISearchQueryLinguisticDetails;
  Search_ISearchSuggestionCollection = Winapi.CommonTypes.Search_ISearchSuggestionCollection;
  PSearch_ISearchSuggestionCollection = Winapi.CommonTypes.PSearch_ISearchSuggestionCollection;
  Search_ISearchSuggestionsRequest = Winapi.CommonTypes.Search_ISearchSuggestionsRequest;
  PSearch_ISearchSuggestionsRequest = Winapi.CommonTypes.PSearch_ISearchSuggestionsRequest;
  Search_ISearchSuggestionsRequestDeferral = Winapi.CommonTypes.Search_ISearchSuggestionsRequestDeferral;
  PSearch_ISearchSuggestionsRequestDeferral = Winapi.CommonTypes.PSearch_ISearchSuggestionsRequestDeferral;
  TypedEventHandler_2__Activation_ISplashScreen__IInspectable = Winapi.CommonTypes.TypedEventHandler_2__Activation_ISplashScreen__IInspectable;
  TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs = Winapi.CommonTypes.TypedEventHandler_2__IBackgroundTaskRegistrationGroup__Activation_IBackgroundActivatedEventArgs;
  TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs = Winapi.CommonTypes.TypedEventHandler_2__ICoreApplicationView__Activation_IActivatedEventArgs;

  // Forward declarations for interfaces

  // Windows.ApplicationModel.IEnteredBackgroundEventArgs
  IEnteredBackgroundEventArgs = interface;
  PIEnteredBackgroundEventArgs = ^IEnteredBackgroundEventArgs;

  // Windows.ApplicationModel.Activation.ILaunchActivatedEventArgs
  Activation_ILaunchActivatedEventArgs = interface;
  PActivation_ILaunchActivatedEventArgs = ^Activation_ILaunchActivatedEventArgs;

  // Windows.ApplicationModel.ILeavingBackgroundEventArgs
  ILeavingBackgroundEventArgs = interface;
  PILeavingBackgroundEventArgs = ^ILeavingBackgroundEventArgs;

  // Windows.ApplicationModel.ISuspendingDeferral
  ISuspendingDeferral = interface;
  PISuspendingDeferral = ^ISuspendingDeferral;

  // Windows.ApplicationModel.ISuspendingOperation
  ISuspendingOperation = interface;
  PISuspendingOperation = ^ISuspendingOperation;

  // Windows.ApplicationModel.ISuspendingEventArgs
  ISuspendingEventArgs = interface;
  PISuspendingEventArgs = ^ISuspendingEventArgs;

  // Windows.ApplicationModel.IPackageId
  IPackageId = interface;
  PIPackageId = ^IPackageId;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IPackage>
  IIterator_1__IPackage = interface;
  PIIterator_1__IPackage = ^IIterator_1__IPackage;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IPackage>
  IIterable_1__IPackage = interface;
  PIIterable_1__IPackage = ^IIterable_1__IPackage;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IPackage>
  IVectorView_1__IPackage = interface;
  PIVectorView_1__IPackage = ^IVectorView_1__IPackage;

  // Windows.ApplicationModel.IPackage
  IPackage = interface;
  PIPackage = ^IPackage;

  // Windows.ApplicationModel.Activation.ICachedFileUpdaterActivatedEventArgs
  Activation_ICachedFileUpdaterActivatedEventArgs = interface;
  PActivation_ICachedFileUpdaterActivatedEventArgs = ^Activation_ICachedFileUpdaterActivatedEventArgs;

  // Windows.ApplicationModel.Activation.IContactsProviderActivatedEventArgs
  Activation_IContactsProviderActivatedEventArgs = interface;
  PActivation_IContactsProviderActivatedEventArgs = ^Activation_IContactsProviderActivatedEventArgs;

  // Windows.ApplicationModel.Activation.IFileActivatedEventArgs
  Activation_IFileActivatedEventArgs = interface;
  PActivation_IFileActivatedEventArgs = ^Activation_IFileActivatedEventArgs;

  // Windows.ApplicationModel.Activation.IFileOpenPickerActivatedEventArgs
  Activation_IFileOpenPickerActivatedEventArgs = interface;
  PActivation_IFileOpenPickerActivatedEventArgs = ^Activation_IFileOpenPickerActivatedEventArgs;

  // Windows.ApplicationModel.Activation.IFileSavePickerActivatedEventArgs
  Activation_IFileSavePickerActivatedEventArgs = interface;
  PActivation_IFileSavePickerActivatedEventArgs = ^Activation_IFileSavePickerActivatedEventArgs;

  // Windows.ApplicationModel.Activation.ISearchActivatedEventArgs
  Activation_ISearchActivatedEventArgs = interface;
  PActivation_ISearchActivatedEventArgs = ^Activation_ISearchActivatedEventArgs;

  // Windows.ApplicationModel.Activation.IShareTargetActivatedEventArgs
  Activation_IShareTargetActivatedEventArgs = interface;
  PActivation_IShareTargetActivatedEventArgs = ^Activation_IShareTargetActivatedEventArgs;

  // Windows.ApplicationModel.AppExtensions.IAppExtension
  AppExtensions_IAppExtension = interface;
  PAppExtensions_IAppExtension = ^AppExtensions_IAppExtension;

  // Windows.ApplicationModel.AppExtensions.IAppExtension2
  AppExtensions_IAppExtension2 = interface;
  PAppExtensions_IAppExtension2 = ^AppExtensions_IAppExtension2;

  // Windows.ApplicationModel.AppExtensions.IAppExtension3
  AppExtensions_IAppExtension3 = interface;
  PAppExtensions_IAppExtension3 = ^AppExtensions_IAppExtension3;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IIterator_1__AppExtensions_IAppExtension = interface;
  PIIterator_1__AppExtensions_IAppExtension = ^IIterator_1__AppExtensions_IAppExtension;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IIterable_1__AppExtensions_IAppExtension = interface;
  PIIterable_1__AppExtensions_IAppExtension = ^IIterable_1__AppExtensions_IAppExtension;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IVectorView_1__AppExtensions_IAppExtension = interface;
  PIVectorView_1__AppExtensions_IAppExtension = ^IVectorView_1__AppExtensions_IAppExtension;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>>
  AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension = ^AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>>
  IAsyncOperation_1__IVectorView_1__AppExtensions_IAppExtension = interface;
  PIAsyncOperation_1__IVectorView_1__AppExtensions_IAppExtension = ^IAsyncOperation_1__IVectorView_1__AppExtensions_IAppExtension;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageInstalledEventArgs
  AppExtensions_IAppExtensionPackageInstalledEventArgs = interface;
  PAppExtensions_IAppExtensionPackageInstalledEventArgs = ^AppExtensions_IAppExtensionPackageInstalledEventArgs;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUpdatingEventArgs
  AppExtensions_IAppExtensionPackageUpdatingEventArgs = interface;
  PAppExtensions_IAppExtensionPackageUpdatingEventArgs = ^AppExtensions_IAppExtensionPackageUpdatingEventArgs;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUpdatedEventArgs
  AppExtensions_IAppExtensionPackageUpdatedEventArgs = interface;
  PAppExtensions_IAppExtensionPackageUpdatedEventArgs = ^AppExtensions_IAppExtensionPackageUpdatedEventArgs;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUninstallingEventArgs
  AppExtensions_IAppExtensionPackageUninstallingEventArgs = interface;
  PAppExtensions_IAppExtensionPackageUninstallingEventArgs = ^AppExtensions_IAppExtensionPackageUninstallingEventArgs;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageStatusChangedEventArgs
  AppExtensions_IAppExtensionPackageStatusChangedEventArgs = interface;
  PAppExtensions_IAppExtensionPackageStatusChangedEventArgs = ^AppExtensions_IAppExtensionPackageStatusChangedEventArgs;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IAppInfo>
  IIterator_1__IAppInfo = interface;
  PIIterator_1__IAppInfo = ^IIterator_1__IAppInfo;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IAppInfo>
  IIterable_1__IAppInfo = interface;
  PIIterable_1__IAppInfo = ^IIterable_1__IAppInfo;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>
  IVectorView_1__IAppInfo = interface;
  PIVectorView_1__IAppInfo = ^IVectorView_1__IAppInfo;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo = ^AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>>
  IAsyncOperation_1__IVectorView_1__IAppInfo = interface;
  PIAsyncOperation_1__IVectorView_1__IAppInfo = ^IAsyncOperation_1__IVectorView_1__IAppInfo;

  // Windows.ApplicationModel.AppService.IAppServiceClosedEventArgs
  AppService_IAppServiceClosedEventArgs = interface;
  PAppService_IAppServiceClosedEventArgs = ^AppService_IAppServiceClosedEventArgs;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.AppServiceConnectionStatus>
  AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus = interface;
  PAsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus = ^AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.AppServiceConnectionStatus>
  IAsyncOperation_1__AppService_AppServiceConnectionStatus = interface;
  PIAsyncOperation_1__AppService_AppServiceConnectionStatus = ^IAsyncOperation_1__AppService_AppServiceConnectionStatus;

  // Windows.ApplicationModel.AppService.IAppServiceResponse
  AppService_IAppServiceResponse = interface;
  PAppService_IAppServiceResponse = ^AppService_IAppServiceResponse;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.IAppServiceResponse>
  AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse = interface;
  PAsyncOperationCompletedHandler_1__AppService_IAppServiceResponse = ^AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.IAppServiceResponse>
  IAsyncOperation_1__AppService_IAppServiceResponse = interface;
  PIAsyncOperation_1__AppService_IAppServiceResponse = ^IAsyncOperation_1__AppService_IAppServiceResponse;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.AppServiceResponseStatus>
  AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus = interface;
  PAsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus = ^AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.AppServiceResponseStatus>
  IAsyncOperation_1__AppService_AppServiceResponseStatus = interface;
  PIAsyncOperation_1__AppService_AppServiceResponseStatus = ^IAsyncOperation_1__AppService_AppServiceResponseStatus;

  // Windows.ApplicationModel.AppService.IAppServiceRequest
  AppService_IAppServiceRequest = interface;
  PAppService_IAppServiceRequest = ^AppService_IAppServiceRequest;

  // Windows.ApplicationModel.AppService.IAppServiceDeferral
  AppService_IAppServiceDeferral = interface;
  PAppService_IAppServiceDeferral = ^AppService_IAppServiceDeferral;

  // Windows.ApplicationModel.AppService.IAppServiceRequestReceivedEventArgs
  AppService_IAppServiceRequestReceivedEventArgs = interface;
  PAppService_IAppServiceRequestReceivedEventArgs = ^AppService_IAppServiceRequestReceivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.IAppServiceConnection,Windows.ApplicationModel.AppService.IAppServiceRequestReceivedEventArgs>
  TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceRequestReceivedEventArgs = interface;
  PTypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceRequestReceivedEventArgs = ^TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceRequestReceivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.IAppServiceConnection,Windows.ApplicationModel.AppService.IAppServiceClosedEventArgs>
  TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceClosedEventArgs = interface;
  PTypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceClosedEventArgs = ^TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceClosedEventArgs;

  // Windows.ApplicationModel.AppService.IAppServiceConnection
  AppService_IAppServiceConnection = interface;
  PAppService_IAppServiceConnection = ^AppService_IAppServiceConnection;

  // Windows.ApplicationModel.AppService.IAppServiceConnection2
  AppService_IAppServiceConnection2 = interface;
  PAppService_IAppServiceConnection2 = ^AppService_IAppServiceConnection2;

  // Windows.ApplicationModel.AppService.IStatelessAppServiceResponse
  AppService_IStatelessAppServiceResponse = interface;
  PAppService_IStatelessAppServiceResponse = ^AppService_IStatelessAppServiceResponse;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.IStatelessAppServiceResponse>
  AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse = interface;
  PAsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse = ^AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.IStatelessAppServiceResponse>
  IAsyncOperation_1__AppService_IStatelessAppServiceResponse = interface;
  PIAsyncOperation_1__AppService_IStatelessAppServiceResponse = ^IAsyncOperation_1__AppService_IStatelessAppServiceResponse;

  // Windows.ApplicationModel.AppService.IAppServiceConnectionStatics
  AppService_IAppServiceConnectionStatics = interface;
  PAppService_IAppServiceConnectionStatics = ^AppService_IAppServiceConnectionStatics;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails
  AppService_IAppServiceTriggerDetails = interface;
  PAppService_IAppServiceTriggerDetails = ^AppService_IAppServiceTriggerDetails;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails2
  AppService_IAppServiceTriggerDetails2 = interface;
  PAppService_IAppServiceTriggerDetails2 = ^AppService_IAppServiceTriggerDetails2;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails3
  AppService_IAppServiceTriggerDetails3 = interface;
  PAppService_IAppServiceTriggerDetails3 = ^AppService_IAppServiceTriggerDetails3;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails4
  AppService_IAppServiceTriggerDetails4 = interface;
  PAppService_IAppServiceTriggerDetails4 = ^AppService_IAppServiceTriggerDetails4;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Calls.PhoneCallOperationStatus>
  AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus = interface;
  PAsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus = ^AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Calls.PhoneCallOperationStatus>
  IAsyncOperation_1__Calls_PhoneCallOperationStatus = interface;
  PIAsyncOperation_1__Calls_PhoneCallOperationStatus = ^IAsyncOperation_1__Calls_PhoneCallOperationStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Calls.VoipPhoneCallResourceReservationStatus>
  AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus = interface;
  PAsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus = ^AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Calls.VoipPhoneCallResourceReservationStatus>
  IAsyncOperation_1__Calls_VoipPhoneCallResourceReservationStatus = interface;
  PIAsyncOperation_1__Calls_VoipPhoneCallResourceReservationStatus = ^IAsyncOperation_1__Calls_VoipPhoneCallResourceReservationStatus;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>
  IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface;
  PIKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = ^IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>>
  IIterator_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = ^IIterator_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>>
  IIterable_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = ^IIterable_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>
  IMapView_2__HSTRING__Chat_ChatMessageStatus = interface;
  PIMapView_2__HSTRING__Chat_ChatMessageStatus = ^IMapView_2__HSTRING__Chat_ChatMessageStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationTrainingStatus>
  AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus = ^AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationTrainingStatus>
  IAsyncOperation_1__ConversationalAgent_DetectionConfigurationTrainingStatus = interface;
  PIAsyncOperation_1__ConversationalAgent_DetectionConfigurationTrainingStatus = ^IAsyncOperation_1__ConversationalAgent_DetectionConfigurationTrainingStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationSetModelDataResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = ^AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationSetModelDataResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = interface;
  PIAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = ^IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationStateChangeResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = ^AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationStateChangeResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = interface;
  PIAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = ^IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IIterator_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface;
  PIIterator_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = ^IIterator_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IIterable_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface;
  PIIterable_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = ^IIterable_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IVectorView_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface;
  PIVectorView_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = ^IVectorView_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IIterator_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface;
  PIIterator_1__ConversationalAgent_ActivationSignalDetectorPowerState = ^IIterator_1__ConversationalAgent_ActivationSignalDetectorPowerState;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IIterable_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface;
  PIIterable_1__ConversationalAgent_ActivationSignalDetectorPowerState = ^IIterable_1__ConversationalAgent_ActivationSignalDetectorPowerState;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IVectorView_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface;
  PIVectorView_1__ConversationalAgent_ActivationSignalDetectorPowerState = ^IVectorView_1__ConversationalAgent_ActivationSignalDetectorPowerState;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationRemovalResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = ^AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationRemovalResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = interface;
  PIAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = ^IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSessionUpdateResponse>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = ^AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSessionUpdateResponse>
  IAsyncOperation_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = interface;
  PIAsyncOperation_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = ^IAsyncOperation_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult = interface;
  PAsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult = ^AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationResult>
  IAsyncOperation_1__ConversationalAgent_ConversationalAgentActivationResult = interface;
  PIAsyncOperation_1__ConversationalAgent_ConversationalAgentActivationResult = ^IAsyncOperation_1__ConversationalAgent_ConversationalAgentActivationResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IIterator_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface;
  PIIterator_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^IIterator_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IIterable_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface;
  PIIterable_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^IIterable_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface;
  PIVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>>
  AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>>
  IAsyncOperation_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface;
  PIAsyncOperation_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^IAsyncOperation_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IIterator_1__ConversationalAgent_SignalDetectorResourceKind = interface;
  PIIterator_1__ConversationalAgent_SignalDetectorResourceKind = ^IIterator_1__ConversationalAgent_SignalDetectorResourceKind;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IIterable_1__ConversationalAgent_SignalDetectorResourceKind = interface;
  PIIterable_1__ConversationalAgent_SignalDetectorResourceKind = ^IIterable_1__ConversationalAgent_SignalDetectorResourceKind;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IVectorView_1__ConversationalAgent_SignalDetectorResourceKind = interface;
  PIVectorView_1__ConversationalAgent_SignalDetectorResourceKind = ^IVectorView_1__ConversationalAgent_SignalDetectorResourceKind;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.ISuspendingEventArgs>
  EventHandler_1__ISuspendingEventArgs = interface;
  PEventHandler_1__ISuspendingEventArgs = ^EventHandler_1__ISuspendingEventArgs;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs>
  EventHandler_1__Activation_IBackgroundActivatedEventArgs = interface;
  PEventHandler_1__Activation_IBackgroundActivatedEventArgs = ^EventHandler_1__Activation_IBackgroundActivatedEventArgs;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.ILeavingBackgroundEventArgs>
  EventHandler_1__ILeavingBackgroundEventArgs = interface;
  PEventHandler_1__ILeavingBackgroundEventArgs = ^EventHandler_1__ILeavingBackgroundEventArgs;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.IEnteredBackgroundEventArgs>
  EventHandler_1__IEnteredBackgroundEventArgs = interface;
  PEventHandler_1__IEnteredBackgroundEventArgs = ^EventHandler_1__IEnteredBackgroundEventArgs;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IIterator_1__Email_EmailCertificateValidationStatus = interface;
  PIIterator_1__Email_EmailCertificateValidationStatus = ^IIterator_1__Email_EmailCertificateValidationStatus;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IIterable_1__Email_EmailCertificateValidationStatus = interface;
  PIIterable_1__Email_EmailCertificateValidationStatus = ^IIterable_1__Email_EmailCertificateValidationStatus;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.Email.EmailMailboxSmimeEncryptionAlgorithm>
  IReference_1__Email_EmailMailboxSmimeEncryptionAlgorithm = interface;
  PIReference_1__Email_EmailMailboxSmimeEncryptionAlgorithm = ^IReference_1__Email_EmailMailboxSmimeEncryptionAlgorithm;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.Email.EmailMailboxSmimeSigningAlgorithm>
  IReference_1__Email_EmailMailboxSmimeSigningAlgorithm = interface;
  PIReference_1__Email_EmailMailboxSmimeSigningAlgorithm = ^IReference_1__Email_EmailMailboxSmimeSigningAlgorithm;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IVectorView_1__Email_EmailCertificateValidationStatus = interface;
  PIVectorView_1__Email_EmailCertificateValidationStatus = ^IVectorView_1__Email_EmailCertificateValidationStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus = ^AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>>
  IAsyncOperation_1__IVectorView_1__Email_EmailCertificateValidationStatus = interface;
  PIAsyncOperation_1__IVectorView_1__Email_EmailCertificateValidationStatus = ^IAsyncOperation_1__IVectorView_1__Email_EmailCertificateValidationStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Email.EmailMailboxEmptyFolderStatus>
  AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus = interface;
  PAsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus = ^AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Email.EmailMailboxEmptyFolderStatus>
  IAsyncOperation_1__Email_EmailMailboxEmptyFolderStatus = interface;
  PIAsyncOperation_1__Email_EmailMailboxEmptyFolderStatus = ^IAsyncOperation_1__Email_EmailMailboxEmptyFolderStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Email.EmailMailboxDeleteFolderStatus>
  AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus = interface;
  PAsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus = ^AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Email.EmailMailboxDeleteFolderStatus>
  IAsyncOperation_1__Email_EmailMailboxDeleteFolderStatus = interface;
  PIAsyncOperation_1__Email_EmailMailboxDeleteFolderStatus = ^IAsyncOperation_1__Email_EmailMailboxDeleteFolderStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundResult>
  AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = interface;
  PAsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = ^AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundResult>
  IAsyncOperation_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = interface;
  PIAsyncOperation_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = ^IAsyncOperation_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult>
  AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult = interface;
  PAsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult = ^AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult>
  IAsyncOperation_1__ExtendedExecution_ExtendedExecutionResult = interface;
  PIAsyncOperation_1__ExtendedExecution_ExtendedExecutionResult = ^IAsyncOperation_1__ExtendedExecution_ExtendedExecutionResult;

  // Windows.ApplicationModel.IAppInfo2
  IAppInfo2 = interface;
  PIAppInfo2 = ^IAppInfo2;

  // Windows.ApplicationModel.IAppInfo3
  IAppInfo3 = interface;
  PIAppInfo3 = ^IAppInfo3;

  // Windows.ApplicationModel.IAppInfo4
  IAppInfo4 = interface;
  PIAppInfo4 = ^IAppInfo4;

  // Windows.ApplicationModel.IAppInfoStatics
  IAppInfoStatics = interface;
  PIAppInfoStatics = ^IAppInfoStatics;

  // Windows.ApplicationModel.IAppInstallerInfo
  IAppInstallerInfo = interface;
  PIAppInstallerInfo = ^IAppInstallerInfo;

  // Windows.ApplicationModel.IAppInstallerInfo2
  IAppInstallerInfo2 = interface;
  PIAppInstallerInfo2 = ^IAppInstallerInfo2;

  // Windows.ApplicationModel.IFindRelatedPackagesOptions
  IFindRelatedPackagesOptions = interface;
  PIFindRelatedPackagesOptions = ^IFindRelatedPackagesOptions;

  // Windows.ApplicationModel.IPackage2
  IPackage2 = interface;
  PIPackage2 = ^IPackage2;

  // Windows.ApplicationModel.IPackageStatus
  IPackageStatus = interface;
  PIPackageStatus = ^IPackageStatus;

  // Windows.ApplicationModel.IPackage3
  IPackage3 = interface;
  PIPackage3 = ^IPackage3;

  // Windows.ApplicationModel.IPackage4
  IPackage4 = interface;
  PIPackage4 = ^IPackage4;

  // Windows.ApplicationModel.IPackageContentGroup
  IPackageContentGroup = interface;
  PIPackageContentGroup = ^IPackageContentGroup;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IPackageContentGroup>
  IIterator_1__IPackageContentGroup = interface;
  PIIterator_1__IPackageContentGroup = ^IIterator_1__IPackageContentGroup;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IPackageContentGroup>
  IIterable_1__IPackageContentGroup = interface;
  PIIterable_1__IPackageContentGroup = ^IIterable_1__IPackageContentGroup;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IPackageContentGroup>
  IVectorView_1__IPackageContentGroup = interface;
  PIVectorView_1__IPackageContentGroup = ^IVectorView_1__IPackageContentGroup;

  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>
  IVector_1__IPackageContentGroup = interface;
  PIVector_1__IPackageContentGroup = ^IVector_1__IPackageContentGroup;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>>
  AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup = interface;
  PAsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup = ^AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>>
  IAsyncOperation_1__IVector_1__IPackageContentGroup = interface;
  PIAsyncOperation_1__IVector_1__IPackageContentGroup = ^IAsyncOperation_1__IVector_1__IPackageContentGroup;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageContentGroup>
  AsyncOperationCompletedHandler_1__IPackageContentGroup = interface;
  PAsyncOperationCompletedHandler_1__IPackageContentGroup = ^AsyncOperationCompletedHandler_1__IPackageContentGroup;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageContentGroup>
  IAsyncOperation_1__IPackageContentGroup = interface;
  PIAsyncOperation_1__IPackageContentGroup = ^IAsyncOperation_1__IPackageContentGroup;

  // Windows.ApplicationModel.IPackage5
  IPackage5 = interface;
  PIPackage5 = ^IPackage5;

  // Windows.ApplicationModel.IPackageUpdateAvailabilityResult
  IPackageUpdateAvailabilityResult = interface;
  PIPackageUpdateAvailabilityResult = ^IPackageUpdateAvailabilityResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageUpdateAvailabilityResult>
  AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult = interface;
  PAsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult = ^AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageUpdateAvailabilityResult>
  IAsyncOperation_1__IPackageUpdateAvailabilityResult = interface;
  PIAsyncOperation_1__IPackageUpdateAvailabilityResult = ^IAsyncOperation_1__IPackageUpdateAvailabilityResult;

  // Windows.ApplicationModel.IPackage6
  IPackage6 = interface;
  PIPackage6 = ^IPackage6;

  // Windows.ApplicationModel.IPackage7
  IPackage7 = interface;
  PIPackage7 = ^IPackage7;

  // Windows.ApplicationModel.IPackage8
  IPackage8 = interface;
  PIPackage8 = ^IPackage8;

  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackage>
  IVector_1__IPackage = interface;
  PIVector_1__IPackage = ^IVector_1__IPackage;

  // Windows.ApplicationModel.IPackage9
  IPackage9 = interface;
  PIPackage9 = ^IPackage9;

  // Windows.ApplicationModel.IPackageStagingEventArgs
  IPackageStagingEventArgs = interface;
  PIPackageStagingEventArgs = ^IPackageStagingEventArgs;

  // Windows.ApplicationModel.IPackageInstallingEventArgs
  IPackageInstallingEventArgs = interface;
  PIPackageInstallingEventArgs = ^IPackageInstallingEventArgs;

  // Windows.ApplicationModel.IPackageUpdatingEventArgs
  IPackageUpdatingEventArgs = interface;
  PIPackageUpdatingEventArgs = ^IPackageUpdatingEventArgs;

  // Windows.ApplicationModel.IPackageUninstallingEventArgs
  IPackageUninstallingEventArgs = interface;
  PIPackageUninstallingEventArgs = ^IPackageUninstallingEventArgs;

  // Windows.ApplicationModel.IPackageStatusChangedEventArgs
  IPackageStatusChangedEventArgs = interface;
  PIPackageStatusChangedEventArgs = ^IPackageStatusChangedEventArgs;

  // Windows.ApplicationModel.IPackageContentGroupStagingEventArgs
  IPackageContentGroupStagingEventArgs = interface;
  PIPackageContentGroupStagingEventArgs = ^IPackageContentGroupStagingEventArgs;

  // Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult
  IPackageCatalogRemoveResourcePackagesResult = interface;
  PIPackageCatalogRemoveResourcePackagesResult = ^IPackageCatalogRemoveResourcePackagesResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult>
  AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult = interface;
  PAsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult = ^AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult>
  IAsyncOperation_1__IPackageCatalogRemoveResourcePackagesResult = interface;
  PIAsyncOperation_1__IPackageCatalogRemoveResourcePackagesResult = ^IAsyncOperation_1__IPackageCatalogRemoveResourcePackagesResult;

  // Windows.ApplicationModel.IPackageIdWithMetadata
  IPackageIdWithMetadata = interface;
  PIPackageIdWithMetadata = ^IPackageIdWithMetadata;

  // Windows.ApplicationModel.IPackageStatics
  IPackageStatics = interface;
  PIPackageStatics = ^IPackageStatics;

  // Windows.ApplicationModel.IPackageStatus2
  IPackageStatus2 = interface;
  PIPackageStatus2 = ^IPackageStatus2;

  // Windows.ApplicationModel.IPackageWithMetadata
  IPackageWithMetadata = interface;
  PIPackageWithMetadata = ^IPackageWithMetadata;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.StartupTaskState>
  AsyncOperationCompletedHandler_1__StartupTaskState = interface;
  PAsyncOperationCompletedHandler_1__StartupTaskState = ^AsyncOperationCompletedHandler_1__StartupTaskState;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.StartupTaskState>
  IAsyncOperation_1__StartupTaskState = interface;
  PIAsyncOperation_1__StartupTaskState = ^IAsyncOperation_1__StartupTaskState;

  // Windows.ApplicationModel.LockScreen.ILockScreenUnlockingDeferral
  LockScreen_ILockScreenUnlockingDeferral = interface;
  PLockScreen_ILockScreenUnlockingDeferral = ^LockScreen_ILockScreenUnlockingDeferral;

  // Windows.ApplicationModel.LockScreen.ILockScreenUnlockingEventArgs
  LockScreen_ILockScreenUnlockingEventArgs = interface;
  PLockScreen_ILockScreenUnlockingEventArgs = ^LockScreen_ILockScreenUnlockingEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.ILockApplicationHost,Windows.ApplicationModel.LockScreen.ILockScreenUnlockingEventArgs>
  TypedEventHandler_2__LockScreen_ILockApplicationHost__LockScreen_ILockScreenUnlockingEventArgs = interface;
  PTypedEventHandler_2__LockScreen_ILockApplicationHost__LockScreen_ILockScreenUnlockingEventArgs = ^TypedEventHandler_2__LockScreen_ILockApplicationHost__LockScreen_ILockScreenUnlockingEventArgs;

  // Windows.ApplicationModel.LockScreen.ILockApplicationHost
  LockScreen_ILockApplicationHost = interface;
  PLockScreen_ILockApplicationHost = ^LockScreen_ILockApplicationHost;

  // Windows.ApplicationModel.LockScreen.ILockApplicationHostStatics
  LockScreen_ILockApplicationHostStatics = interface;
  PLockScreen_ILockApplicationHostStatics = ^LockScreen_ILockApplicationHostStatics;

  // Windows.ApplicationModel.LockScreen.ILockScreenBadge
  LockScreen_ILockScreenBadge = interface;
  PLockScreen_ILockScreenBadge = ^LockScreen_ILockScreenBadge;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.ILockScreenInfo,Object>
  TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable = interface;
  PTypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable = ^TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IIterator_1__LockScreen_ILockScreenBadge = interface;
  PIIterator_1__LockScreen_ILockScreenBadge = ^IIterator_1__LockScreen_ILockScreenBadge;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IIterable_1__LockScreen_ILockScreenBadge = interface;
  PIIterable_1__LockScreen_ILockScreenBadge = ^IIterable_1__LockScreen_ILockScreenBadge;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IVectorView_1__LockScreen_ILockScreenBadge = interface;
  PIVectorView_1__LockScreen_ILockScreenBadge = ^IVectorView_1__LockScreen_ILockScreenBadge;

  // Windows.ApplicationModel.LockScreen.ILockScreenInfo
  LockScreen_ILockScreenInfo = interface;
  PLockScreen_ILockScreenInfo = ^LockScreen_ILockScreenInfo;

  // Windows.ApplicationModel.Payments.IPaymentAddress
  Payments_IPaymentAddress = interface;
  PPayments_IPaymentAddress = ^Payments_IPaymentAddress;

  // Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult
  Payments_IPaymentCanMakePaymentResult = interface;
  PPayments_IPaymentCanMakePaymentResult = ^Payments_IPaymentCanMakePaymentResult;

  // Windows.ApplicationModel.Payments.IPaymentCurrencyAmount
  Payments_IPaymentCurrencyAmount = interface;
  PPayments_IPaymentCurrencyAmount = ^Payments_IPaymentCurrencyAmount;

  // Windows.ApplicationModel.Payments.IPaymentItem
  Payments_IPaymentItem = interface;
  PPayments_IPaymentItem = ^Payments_IPaymentItem;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IIterator_1__Payments_IPaymentItem = interface;
  PIIterator_1__Payments_IPaymentItem = ^IIterator_1__Payments_IPaymentItem;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IIterable_1__Payments_IPaymentItem = interface;
  PIIterable_1__Payments_IPaymentItem = ^IIterable_1__Payments_IPaymentItem;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IVectorView_1__Payments_IPaymentItem = interface;
  PIVectorView_1__Payments_IPaymentItem = ^IVectorView_1__Payments_IPaymentItem;

  // Windows.ApplicationModel.Payments.IPaymentShippingOption
  Payments_IPaymentShippingOption = interface;
  PPayments_IPaymentShippingOption = ^Payments_IPaymentShippingOption;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IIterator_1__Payments_IPaymentShippingOption = interface;
  PIIterator_1__Payments_IPaymentShippingOption = ^IIterator_1__Payments_IPaymentShippingOption;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IIterable_1__Payments_IPaymentShippingOption = interface;
  PIIterable_1__Payments_IPaymentShippingOption = ^IIterable_1__Payments_IPaymentShippingOption;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IVectorView_1__Payments_IPaymentShippingOption = interface;
  PIVectorView_1__Payments_IPaymentShippingOption = ^IVectorView_1__Payments_IPaymentShippingOption;

  // Windows.ApplicationModel.Payments.IPaymentDetailsModifier
  Payments_IPaymentDetailsModifier = interface;
  PPayments_IPaymentDetailsModifier = ^Payments_IPaymentDetailsModifier;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IIterator_1__Payments_IPaymentDetailsModifier = interface;
  PIIterator_1__Payments_IPaymentDetailsModifier = ^IIterator_1__Payments_IPaymentDetailsModifier;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IIterable_1__Payments_IPaymentDetailsModifier = interface;
  PIIterable_1__Payments_IPaymentDetailsModifier = ^IIterable_1__Payments_IPaymentDetailsModifier;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IVectorView_1__Payments_IPaymentDetailsModifier = interface;
  PIVectorView_1__Payments_IPaymentDetailsModifier = ^IVectorView_1__Payments_IPaymentDetailsModifier;

  // Windows.ApplicationModel.Payments.IPaymentDetails
  Payments_IPaymentDetails = interface;
  PPayments_IPaymentDetails = ^Payments_IPaymentDetails;

  // Windows.ApplicationModel.Payments.IPaymentToken
  Payments_IPaymentToken = interface;
  PPayments_IPaymentToken = ^Payments_IPaymentToken;

  // Windows.ApplicationModel.Payments.IPaymentResponse
  Payments_IPaymentResponse = interface;
  PPayments_IPaymentResponse = ^Payments_IPaymentResponse;

  // Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult
  Payments_IPaymentRequestSubmitResult = interface;
  PPayments_IPaymentRequestSubmitResult = ^Payments_IPaymentRequestSubmitResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult = interface;
  PAsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult = ^AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult>
  IAsyncOperation_1__Payments_IPaymentRequestSubmitResult = interface;
  PIAsyncOperation_1__Payments_IPaymentRequestSubmitResult = ^IAsyncOperation_1__Payments_IPaymentRequestSubmitResult;

  // Windows.ApplicationModel.Payments.IPaymentMerchantInfo
  Payments_IPaymentMerchantInfo = interface;
  PPayments_IPaymentMerchantInfo = ^Payments_IPaymentMerchantInfo;

  // Windows.ApplicationModel.Payments.IPaymentMethodData
  Payments_IPaymentMethodData = interface;
  PPayments_IPaymentMethodData = ^Payments_IPaymentMethodData;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IIterator_1__Payments_IPaymentMethodData = interface;
  PIIterator_1__Payments_IPaymentMethodData = ^IIterator_1__Payments_IPaymentMethodData;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IIterable_1__Payments_IPaymentMethodData = interface;
  PIIterable_1__Payments_IPaymentMethodData = ^IIterable_1__Payments_IPaymentMethodData;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IVectorView_1__Payments_IPaymentMethodData = interface;
  PIVectorView_1__Payments_IPaymentMethodData = ^IVectorView_1__Payments_IPaymentMethodData;

  // Windows.ApplicationModel.Payments.IPaymentOptions
  Payments_IPaymentOptions = interface;
  PPayments_IPaymentOptions = ^Payments_IPaymentOptions;

  // Windows.ApplicationModel.Payments.IPaymentRequest
  Payments_IPaymentRequest = interface;
  PPayments_IPaymentRequest = ^Payments_IPaymentRequest;

  // Windows.ApplicationModel.Payments.IPaymentRequestChangedResult
  Payments_IPaymentRequestChangedResult = interface;
  PPayments_IPaymentRequestChangedResult = ^Payments_IPaymentRequestChangedResult;

  // Windows.ApplicationModel.Payments.IPaymentRequestChangedArgs
  Payments_IPaymentRequestChangedArgs = interface;
  PPayments_IPaymentRequestChangedArgs = ^Payments_IPaymentRequestChangedArgs;

  // Windows.ApplicationModel.Payments.PaymentRequestChangedHandler
  Payments_PaymentRequestChangedHandler = interface;
  PPayments_PaymentRequestChangedHandler = ^Payments_PaymentRequestChangedHandler;

  // Windows.ApplicationModel.Payments.IPaymentMediator
  Payments_IPaymentMediator = interface;
  PPayments_IPaymentMediator = ^Payments_IPaymentMediator;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult = interface;
  PAsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult = ^AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult>
  IAsyncOperation_1__Payments_IPaymentCanMakePaymentResult = interface;
  PIAsyncOperation_1__Payments_IPaymentCanMakePaymentResult = ^IAsyncOperation_1__Payments_IPaymentCanMakePaymentResult;

  // Windows.ApplicationModel.Payments.IPaymentMediator2
  Payments_IPaymentMediator2 = interface;
  PPayments_IPaymentMediator2 = ^Payments_IPaymentMediator2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentRequestChangedResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult = interface;
  PAsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult = ^AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentRequestChangedResult>
  IAsyncOperation_1__Payments_IPaymentRequestChangedResult = interface;
  PIAsyncOperation_1__Payments_IPaymentRequestChangedResult = ^IAsyncOperation_1__Payments_IPaymentRequestChangedResult;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.ApplicationModel.Search.Core.ISearchSuggestion>
  VectorChangedEventHandler_1__Search_Core_ISearchSuggestion = interface;
  PVectorChangedEventHandler_1__Search_Core_ISearchSuggestion = ^VectorChangedEventHandler_1__Search_Core_ISearchSuggestion;

  // Windows.Foundation.Collections.IObservableVector`1<Windows.ApplicationModel.Search.Core.ISearchSuggestion>
  IObservableVector_1__Search_Core_ISearchSuggestion = interface;
  PIObservableVector_1__Search_Core_ISearchSuggestion = ^IObservableVector_1__Search_Core_ISearchSuggestion;

  // Windows.ApplicationModel.Store.LicenseChangedEventHandler
  Store_LicenseChangedEventHandler = interface;
  PStore_LicenseChangedEventHandler = ^Store_LicenseChangedEventHandler;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Store.FulfillmentResult>
  AsyncOperationCompletedHandler_1__Store_FulfillmentResult = interface;
  PAsyncOperationCompletedHandler_1__Store_FulfillmentResult = ^AsyncOperationCompletedHandler_1__Store_FulfillmentResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Store.FulfillmentResult>
  IAsyncOperation_1__Store_FulfillmentResult = interface;
  PIAsyncOperation_1__Store_FulfillmentResult = ^IAsyncOperation_1__Store_FulfillmentResult;

  // Windows.ApplicationModel.Store.IProductListingWithConsumables
  Store_IProductListingWithConsumables = interface;
  PStore_IProductListingWithConsumables = ^Store_IProductListingWithConsumables;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IIterator_1__Store_Preview_StoreSystemFeature = interface;
  PIIterator_1__Store_Preview_StoreSystemFeature = ^IIterator_1__Store_Preview_StoreSystemFeature;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IIterable_1__Store_Preview_StoreSystemFeature = interface;
  PIIterable_1__Store_Preview_StoreSystemFeature = ^IIterable_1__Store_Preview_StoreSystemFeature;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IVectorView_1__Store_Preview_StoreSystemFeature = interface;
  PIVectorView_1__Store_Preview_StoreSystemFeature = ^IVectorView_1__Store_Preview_StoreSystemFeature;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature = ^AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>>
  IAsyncOperation_1__IVectorView_1__Store_Preview_StoreSystemFeature = interface;
  PIAsyncOperation_1__IVectorView_1__Store_Preview_StoreSystemFeature = ^IAsyncOperation_1__IVectorView_1__Store_Preview_StoreSystemFeature;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.UserDataTasks.UserDataTaskDaysOfWeek>
  IReference_1__UserDataTasks_UserDataTaskDaysOfWeek = interface;
  PIReference_1__UserDataTasks_UserDataTaskDaysOfWeek = ^IReference_1__UserDataTasks_UserDataTaskDaysOfWeek;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.UserDataTasks.UserDataTaskWeekOfMonth>
  IReference_1__UserDataTasks_UserDataTaskWeekOfMonth = interface;
  PIReference_1__UserDataTasks_UserDataTaskWeekOfMonth = ^IReference_1__UserDataTasks_UserDataTaskWeekOfMonth;

  // Windows.ApplicationModel Enums

  // Windows.ApplicationModel.AddResourcePackageOptions
  AddResourcePackageOptions = (
    None = 0,
    ForceTargetAppShutdown = 1,
    ApplyUpdateIfAvailable = 2
  );
  PAddResourcePackageOptions = ^AddResourcePackageOptions;

  // Windows.ApplicationModel.AppExecutionContext
  AppExecutionContext = (
    Unknown = 0,
    Host = 1,
    Guest = 2
  );
  PAppExecutionContext = ^AppExecutionContext;

  // Windows.ApplicationModel.AppInstallerPolicySource
  AppInstallerPolicySource = (
    Default = 0,
    System = 1
  );
  PAppInstallerPolicySource = ^AppInstallerPolicySource;

  // Windows.ApplicationModel.AppService.AppServiceClosedStatus
  AppService_AppServiceClosedStatus = (
    Completed = 0,
    Canceled = 1,
    ResourceLimitsExceeded = 2,
    Unknown = 3
  );
  PAppService_AppServiceClosedStatus = ^AppService_AppServiceClosedStatus;

  // Windows.ApplicationModel.AppService.AppServiceConnectionStatus
  AppService_AppServiceConnectionStatus = (
    Success = 0,
    AppNotInstalled = 1,
    AppUnavailable = 2,
    AppServiceUnavailable = 3,
    Unknown = 4,
    RemoteSystemUnavailable = 5,
    RemoteSystemNotSupportedByApp = 6,
    NotAuthorized = 7,
    AuthenticationError = 8,
    NetworkNotAvailable = 9,
    DisabledByPolicy = 10,
    WebServiceUnavailable = 11
  );
  PAppService_AppServiceConnectionStatus = ^AppService_AppServiceConnectionStatus;

  // Windows.ApplicationModel.AppService.AppServiceResponseStatus
  AppService_AppServiceResponseStatus = (
    Success = 0,
    Failure = 1,
    ResourceLimitsExceeded = 2,
    Unknown = 3,
    RemoteSystemUnavailable = 4,
    MessageSizeTooLarge = 5,
    AppUnavailable = 6,
    AuthenticationError = 7,
    NetworkNotAvailable = 8,
    DisabledByPolicy = 9,
    WebServiceUnavailable = 10
  );
  PAppService_AppServiceResponseStatus = ^AppService_AppServiceResponseStatus;

  // Windows.ApplicationModel.AppService.StatelessAppServiceResponseStatus
  AppService_StatelessAppServiceResponseStatus = (
    Success = 0,
    AppNotInstalled = 1,
    AppUnavailable = 2,
    AppServiceUnavailable = 3,
    RemoteSystemUnavailable = 4,
    RemoteSystemNotSupportedByApp = 5,
    NotAuthorized = 6,
    ResourceLimitsExceeded = 7,
    MessageSizeTooLarge = 8,
    Failure = 9,
    Unknown = 10,
    AuthenticationError = 11,
    NetworkNotAvailable = 12,
    DisabledByPolicy = 13,
    WebServiceUnavailable = 14
  );
  PAppService_StatelessAppServiceResponseStatus = ^AppService_StatelessAppServiceResponseStatus;

  // Windows.ApplicationModel.Appointments.AppointmentBusyStatus
  Appointments_AppointmentBusyStatus = (
    Busy = 0,
    Tentative = 1,
    Free = 2,
    OutOfOffice = 3,
    WorkingElsewhere = 4
  );
  PAppointments_AppointmentBusyStatus = ^Appointments_AppointmentBusyStatus;

  // Windows.ApplicationModel.Appointments.AppointmentCalendarOtherAppReadAccess
  Appointments_AppointmentCalendarOtherAppReadAccess = (
    SystemOnly = 0,
    Limited = 1,
    Full = 2,
    None = 3
  );
  PAppointments_AppointmentCalendarOtherAppReadAccess = ^Appointments_AppointmentCalendarOtherAppReadAccess;

  // Windows.ApplicationModel.Appointments.AppointmentCalendarOtherAppWriteAccess
  Appointments_AppointmentCalendarOtherAppWriteAccess = (
    None = 0,
    SystemOnly = 1,
    Limited = 2
  );
  PAppointments_AppointmentCalendarOtherAppWriteAccess = ^Appointments_AppointmentCalendarOtherAppWriteAccess;

  // Windows.ApplicationModel.Appointments.AppointmentCalendarSyncStatus
  Appointments_AppointmentCalendarSyncStatus = (
    Idle = 0,
    Syncing = 1,
    UpToDate = 2,
    AuthenticationError = 3,
    PolicyError = 4,
    UnknownError = 5,
    ManualAccountRemovalRequired = 6
  );
  PAppointments_AppointmentCalendarSyncStatus = ^Appointments_AppointmentCalendarSyncStatus;

  // Windows.ApplicationModel.Appointments.AppointmentConflictType
  Appointments_AppointmentConflictType = (
    None = 0,
    Adjacent = 1,
    Overlap = 2
  );
  PAppointments_AppointmentConflictType = ^Appointments_AppointmentConflictType;

  // Windows.ApplicationModel.Appointments.AppointmentDaysOfWeek
  Appointments_AppointmentDaysOfWeek = (
    None = 0,
    Sunday = 1,
    Monday = 2,
    Tuesday = 4,
    Wednesday = 8,
    Thursday = 16,
    Friday = 32,
    Saturday = 64
  );
  PAppointments_AppointmentDaysOfWeek = ^Appointments_AppointmentDaysOfWeek;

  // Windows.ApplicationModel.Appointments.AppointmentDetailsKind
  Appointments_AppointmentDetailsKind = (
    PlainText = 0,
    Html = 1
  );
  PAppointments_AppointmentDetailsKind = ^Appointments_AppointmentDetailsKind;

  // Windows.ApplicationModel.Appointments.AppointmentParticipantResponse
  Appointments_AppointmentParticipantResponse = (
    None = 0,
    Tentative = 1,
    Accepted = 2,
    Declined = 3,
    Unknown = 4
  );
  PAppointments_AppointmentParticipantResponse = ^Appointments_AppointmentParticipantResponse;

  // Windows.ApplicationModel.Appointments.AppointmentParticipantRole
  Appointments_AppointmentParticipantRole = (
    RequiredAttendee = 0,
    OptionalAttendee = 1,
    Resource = 2
  );
  PAppointments_AppointmentParticipantRole = ^Appointments_AppointmentParticipantRole;

  // Windows.ApplicationModel.Appointments.AppointmentRecurrenceUnit
  Appointments_AppointmentRecurrenceUnit = (
    Daily = 0,
    Weekly = 1,
    Monthly = 2,
    MonthlyOnDay = 3,
    Yearly = 4,
    YearlyOnDay = 5
  );
  PAppointments_AppointmentRecurrenceUnit = ^Appointments_AppointmentRecurrenceUnit;

  // Windows.ApplicationModel.Appointments.AppointmentSensitivity
  Appointments_AppointmentSensitivity = (
    &Public = 0,
    &Private = 1
  );
  PAppointments_AppointmentSensitivity = ^Appointments_AppointmentSensitivity;

  // Windows.ApplicationModel.Appointments.AppointmentStoreAccessType
  Appointments_AppointmentStoreAccessType = (
    AppCalendarsReadWrite = 0,
    AllCalendarsReadOnly = 1,
    AllCalendarsReadWrite = 2
  );
  PAppointments_AppointmentStoreAccessType = ^Appointments_AppointmentStoreAccessType;

  // Windows.ApplicationModel.Appointments.AppointmentStoreChangeType
  Appointments_AppointmentStoreChangeType = (
    AppointmentCreated = 0,
    AppointmentModified = 1,
    AppointmentDeleted = 2,
    ChangeTrackingLost = 3,
    CalendarCreated = 4,
    CalendarModified = 5,
    CalendarDeleted = 6
  );
  PAppointments_AppointmentStoreChangeType = ^Appointments_AppointmentStoreChangeType;

  // Windows.ApplicationModel.Appointments.AppointmentSummaryCardView
  Appointments_AppointmentSummaryCardView = (
    System = 0,
    App = 1
  );
  PAppointments_AppointmentSummaryCardView = ^Appointments_AppointmentSummaryCardView;

  // Windows.ApplicationModel.Appointments.AppointmentWeekOfMonth
  Appointments_AppointmentWeekOfMonth = (
    First = 0,
    Second = 1,
    Third = 2,
    Fourth = 3,
    Last = 4
  );
  PAppointments_AppointmentWeekOfMonth = ^Appointments_AppointmentWeekOfMonth;

  // Windows.ApplicationModel.Appointments.FindAppointmentCalendarsOptions
  Appointments_FindAppointmentCalendarsOptions = (
    None = 0,
    IncludeHidden = 1
  );
  PAppointments_FindAppointmentCalendarsOptions = ^Appointments_FindAppointmentCalendarsOptions;

  // Windows.ApplicationModel.Appointments.RecurrenceType
  Appointments_RecurrenceType = (
    Master = 0,
    Instance = 1,
    ExceptionInstance = 2
  );
  PAppointments_RecurrenceType = ^Appointments_RecurrenceType;

  // Windows.ApplicationModel.Calls.Background.PhoneCallBlockedReason
  Calls_Background_PhoneCallBlockedReason = (
    InCallBlockingList = 0,
    PrivateNumber = 1,
    UnknownNumber = 2
  );
  PCalls_Background_PhoneCallBlockedReason = ^Calls_Background_PhoneCallBlockedReason;

  // Windows.ApplicationModel.Calls.Background.PhoneIncomingCallDismissedReason
  Calls_Background_PhoneIncomingCallDismissedReason = (
    Unknown = 0,
    CallRejected = 1,
    TextReply = 2,
    ConnectionLost = 3
  );
  PCalls_Background_PhoneIncomingCallDismissedReason = ^Calls_Background_PhoneIncomingCallDismissedReason;

  // Windows.ApplicationModel.Calls.Background.PhoneLineChangeKind
  Calls_Background_PhoneLineChangeKind = (
    Added = 0,
    Removed = 1,
    PropertiesChanged = 2
  );
  PCalls_Background_PhoneLineChangeKind = ^Calls_Background_PhoneLineChangeKind;

  // Windows.ApplicationModel.Calls.Background.PhoneLineProperties
  Calls_Background_PhoneLineProperties = (
    None = 0,
    BrandingOptions = 1,
    CanDial = 2,
    CellularDetails = 4,
    DisplayColor = 8,
    DisplayName = 16,
    NetworkName = 32,
    NetworkState = 64,
    Transport = 128,
    Voicemail = 256
  );
  PCalls_Background_PhoneLineProperties = ^Calls_Background_PhoneLineProperties;

  // Windows.ApplicationModel.Calls.Background.PhoneTriggerType
  Calls_Background_PhoneTriggerType = (
    NewVoicemailMessage = 0,
    CallHistoryChanged = 1,
    LineChanged = 2,
    AirplaneModeDisabledForEmergencyCall = 3,
    CallOriginDataRequest = 4,
    CallBlocked = 5,
    IncomingCallDismissed = 6,
    IncomingCallNotification = 7
  );
  PCalls_Background_PhoneTriggerType = ^Calls_Background_PhoneTriggerType;

  // Windows.ApplicationModel.Calls.CellularDtmfMode
  Calls_CellularDtmfMode = (
    Continuous = 0,
    Burst = 1
  );
  PCalls_CellularDtmfMode = ^Calls_CellularDtmfMode;

  // Windows.ApplicationModel.Calls.DtmfKey
  Calls_DtmfKey = (
    D0 = 0,
    D1 = 1,
    D2 = 2,
    D3 = 3,
    D4 = 4,
    D5 = 5,
    D6 = 6,
    D7 = 7,
    D8 = 8,
    D9 = 9,
    Star = 10,
    Pound = 11
  );
  PCalls_DtmfKey = ^Calls_DtmfKey;

  // Windows.ApplicationModel.Calls.DtmfToneAudioPlayback
  Calls_DtmfToneAudioPlayback = (
    Play = 0,
    DoNotPlay = 1
  );
  PCalls_DtmfToneAudioPlayback = ^Calls_DtmfToneAudioPlayback;

  // Windows.ApplicationModel.Calls.PhoneAudioRoutingEndpoint
  Calls_PhoneAudioRoutingEndpoint = (
    Default = 0,
    Bluetooth = 1,
    Speakerphone = 2
  );
  PCalls_PhoneAudioRoutingEndpoint = ^Calls_PhoneAudioRoutingEndpoint;

  // Windows.ApplicationModel.Calls.PhoneCallAudioDevice
  Calls_PhoneCallAudioDevice = (
    Unknown = 0,
    LocalDevice = 1,
    RemoteDevice = 2
  );
  PCalls_PhoneCallAudioDevice = ^Calls_PhoneCallAudioDevice;

  // Windows.ApplicationModel.Calls.PhoneCallDirection
  Calls_PhoneCallDirection = (
    Unknown = 0,
    Incoming = 1,
    Outgoing = 2
  );
  PCalls_PhoneCallDirection = ^Calls_PhoneCallDirection;

  // Windows.ApplicationModel.Calls.PhoneCallHistoryEntryMedia
  Calls_PhoneCallHistoryEntryMedia = (
    Audio = 0,
    Video = 1
  );
  PCalls_PhoneCallHistoryEntryMedia = ^Calls_PhoneCallHistoryEntryMedia;

  // Windows.ApplicationModel.Calls.PhoneCallHistoryEntryOtherAppReadAccess
  Calls_PhoneCallHistoryEntryOtherAppReadAccess = (
    Full = 0,
    SystemOnly = 1
  );
  PCalls_PhoneCallHistoryEntryOtherAppReadAccess = ^Calls_PhoneCallHistoryEntryOtherAppReadAccess;

  // Windows.ApplicationModel.Calls.PhoneCallHistoryEntryQueryDesiredMedia
  Calls_PhoneCallHistoryEntryQueryDesiredMedia = (
    None = 0,
    Audio = 1,
    Video = 2,
    All = -1
  );
  PCalls_PhoneCallHistoryEntryQueryDesiredMedia = ^Calls_PhoneCallHistoryEntryQueryDesiredMedia;

  // Windows.ApplicationModel.Calls.PhoneCallHistoryEntryRawAddressKind
  Calls_PhoneCallHistoryEntryRawAddressKind = (
    PhoneNumber = 0,
    Custom = 1
  );
  PCalls_PhoneCallHistoryEntryRawAddressKind = ^Calls_PhoneCallHistoryEntryRawAddressKind;

  // Windows.ApplicationModel.Calls.PhoneCallHistorySourceIdKind
  Calls_PhoneCallHistorySourceIdKind = (
    CellularPhoneLineId = 0,
    PackageFamilyName = 1
  );
  PCalls_PhoneCallHistorySourceIdKind = ^Calls_PhoneCallHistorySourceIdKind;

  // Windows.ApplicationModel.Calls.PhoneCallHistoryStoreAccessType
  Calls_PhoneCallHistoryStoreAccessType = (
    AppEntriesReadWrite = 0,
    AllEntriesLimitedReadWrite = 1,
    AllEntriesReadWrite = 2
  );
  PCalls_PhoneCallHistoryStoreAccessType = ^Calls_PhoneCallHistoryStoreAccessType;

  // Windows.ApplicationModel.Calls.PhoneCallMedia
  Calls_PhoneCallMedia = (
    Audio = 0,
    AudioAndVideo = 1,
    AudioAndRealTimeText = 2
  );
  PCalls_PhoneCallMedia = ^Calls_PhoneCallMedia;

  // Windows.ApplicationModel.Calls.PhoneCallOperationStatus
  Calls_PhoneCallOperationStatus = (
    Succeeded = 0,
    OtherFailure = 1,
    TimedOut = 2,
    ConnectionLost = 3,
    InvalidCallState = 4
  );
  PCalls_PhoneCallOperationStatus = ^Calls_PhoneCallOperationStatus;

  // Windows.ApplicationModel.Calls.PhoneCallStatus
  Calls_PhoneCallStatus = (
    Lost = 0,
    Incoming = 1,
    Dialing = 2,
    Talking = 3,
    Held = 4,
    Ended = 5
  );
  PCalls_PhoneCallStatus = ^Calls_PhoneCallStatus;

  // Windows.ApplicationModel.Calls.PhoneLineNetworkOperatorDisplayTextLocation
  Calls_PhoneLineNetworkOperatorDisplayTextLocation = (
    Default = 0,
    Tile = 1,
    Dialer = 2,
    InCallUI = 3
  );
  PCalls_PhoneLineNetworkOperatorDisplayTextLocation = ^Calls_PhoneLineNetworkOperatorDisplayTextLocation;

  // Windows.ApplicationModel.Calls.PhoneLineOperationStatus
  Calls_PhoneLineOperationStatus = (
    Succeeded = 0,
    OtherFailure = 1,
    TimedOut = 2,
    ConnectionLost = 3,
    InvalidCallState = 4
  );
  PCalls_PhoneLineOperationStatus = ^Calls_PhoneLineOperationStatus;

  // Windows.ApplicationModel.Calls.PhoneLineTransport
  Calls_PhoneLineTransport = (
    Cellular = 0,
    VoipApp = 1,
    Bluetooth = 2
  );
  PCalls_PhoneLineTransport = ^Calls_PhoneLineTransport;

  // Windows.ApplicationModel.Calls.PhoneLineWatcherStatus
  Calls_PhoneLineWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopped = 3
  );
  PCalls_PhoneLineWatcherStatus = ^Calls_PhoneLineWatcherStatus;

  // Windows.ApplicationModel.Calls.PhoneNetworkState
  Calls_PhoneNetworkState = (
    Unknown = 0,
    NoSignal = 1,
    Deregistered = 2,
    Denied = 3,
    Searching = 4,
    Home = 5,
    RoamingInternational = 6,
    RoamingDomestic = 7
  );
  PCalls_PhoneNetworkState = ^Calls_PhoneNetworkState;

  // Windows.ApplicationModel.Calls.PhoneSimState
  Calls_PhoneSimState = (
    Unknown = 0,
    PinNotRequired = 1,
    PinUnlocked = 2,
    PinLocked = 3,
    PukLocked = 4,
    NotInserted = 5,
    Invalid = 6,
    Disabled = 7
  );
  PCalls_PhoneSimState = ^Calls_PhoneSimState;

  // Windows.ApplicationModel.Calls.PhoneVoicemailType
  Calls_PhoneVoicemailType = (
    None = 0,
    Traditional = 1,
    Visual = 2
  );
  PCalls_PhoneVoicemailType = ^Calls_PhoneVoicemailType;

  // Windows.ApplicationModel.Calls.TransportDeviceAudioRoutingStatus
  Calls_TransportDeviceAudioRoutingStatus = (
    Unknown = 0,
    CanRouteToLocalDevice = 1,
    CannotRouteToLocalDevice = 2
  );
  PCalls_TransportDeviceAudioRoutingStatus = ^Calls_TransportDeviceAudioRoutingStatus;

  // Windows.ApplicationModel.Calls.VoipCallControlDeviceKind
  Calls_VoipCallControlDeviceKind = (
    Bluetooth = 0,
    Usb = 1
  );
  PCalls_VoipCallControlDeviceKind = ^Calls_VoipCallControlDeviceKind;

  // Windows.ApplicationModel.Calls.VoipPhoneCallMedia
  Calls_VoipPhoneCallMedia = (
    None = 0,
    Audio = 1,
    Video = 2
  );
  PCalls_VoipPhoneCallMedia = ^Calls_VoipPhoneCallMedia;

  // Windows.ApplicationModel.Calls.VoipPhoneCallRejectReason
  Calls_VoipPhoneCallRejectReason = (
    UserIgnored = 0,
    TimedOut = 1,
    OtherIncomingCall = 2,
    EmergencyCallExists = 3,
    InvalidCallState = 4
  );
  PCalls_VoipPhoneCallRejectReason = ^Calls_VoipPhoneCallRejectReason;

  // Windows.ApplicationModel.Calls.VoipPhoneCallResourceReservationStatus
  Calls_VoipPhoneCallResourceReservationStatus = (
    Success = 0,
    ResourcesNotAvailable = 1
  );
  PCalls_VoipPhoneCallResourceReservationStatus = ^Calls_VoipPhoneCallResourceReservationStatus;

  // Windows.ApplicationModel.Calls.VoipPhoneCallState
  Calls_VoipPhoneCallState = (
    Ended = 0,
    Held = 1,
    Active = 2,
    Incoming = 3,
    Outgoing = 4
  );
  PCalls_VoipPhoneCallState = ^Calls_VoipPhoneCallState;

  // Windows.ApplicationModel.Chat.ChatConversationThreadingKind
  Chat_ChatConversationThreadingKind = (
    Participants = 0,
    ContactId = 1,
    ConversationId = 2,
    Custom = 3
  );
  PChat_ChatConversationThreadingKind = ^Chat_ChatConversationThreadingKind;

  // Windows.ApplicationModel.Chat.ChatItemKind
  Chat_ChatItemKind = (
    &Message = 0,
    Conversation = 1
  );
  PChat_ChatItemKind = ^Chat_ChatItemKind;

  // Windows.ApplicationModel.Chat.ChatMessageChangeType
  Chat_ChatMessageChangeType = (
    MessageCreated = 0,
    MessageModified = 1,
    MessageDeleted = 2,
    ChangeTrackingLost = 3
  );
  PChat_ChatMessageChangeType = ^Chat_ChatMessageChangeType;

  // Windows.ApplicationModel.Chat.ChatMessageKind
  Chat_ChatMessageKind = (
    Standard = 0,
    FileTransferRequest = 1,
    TransportCustom = 2,
    JoinedConversation = 3,
    LeftConversation = 4,
    OtherParticipantJoinedConversation = 5,
    OtherParticipantLeftConversation = 6
  );
  PChat_ChatMessageKind = ^Chat_ChatMessageKind;

  // Windows.ApplicationModel.Chat.ChatMessageOperatorKind
  Chat_ChatMessageOperatorKind = (
    Unspecified = 0,
    Sms = 1,
    Mms = 2,
    Rcs = 3
  );
  PChat_ChatMessageOperatorKind = ^Chat_ChatMessageOperatorKind;

  // Windows.ApplicationModel.Chat.ChatMessageStatus
  Chat_ChatMessageStatus = (
    Draft = 0,
    Sending = 1,
    Sent = 2,
    SendRetryNeeded = 3,
    SendFailed = 4,
    Received = 5,
    ReceiveDownloadNeeded = 6,
    ReceiveDownloadFailed = 7,
    ReceiveDownloading = 8,
    Deleted = 9,
    Declined = 10,
    Cancelled = 11,
    Recalled = 12,
    ReceiveRetryNeeded = 13
  );
  PChat_ChatMessageStatus = ^Chat_ChatMessageStatus;

  // Windows.ApplicationModel.Chat.ChatMessageTransportKind
  Chat_ChatMessageTransportKind = (
    Text = 0,
    Untriaged = 1,
    Blocked = 2,
    Custom = 3
  );
  PChat_ChatMessageTransportKind = ^Chat_ChatMessageTransportKind;

  // Windows.ApplicationModel.Chat.ChatMessageValidationStatus
  Chat_ChatMessageValidationStatus = (
    Valid = 0,
    NoRecipients = 1,
    InvalidData = 2,
    MessageTooLarge = 3,
    TooManyRecipients = 4,
    TransportInactive = 5,
    TransportNotFound = 6,
    TooManyAttachments = 7,
    InvalidRecipients = 8,
    InvalidBody = 9,
    InvalidOther = 10,
    ValidWithLargeMessage = 11,
    VoiceRoamingRestriction = 12,
    DataRoamingRestriction = 13
  );
  PChat_ChatMessageValidationStatus = ^Chat_ChatMessageValidationStatus;

  // Windows.ApplicationModel.Chat.ChatRestoreHistorySpan
  Chat_ChatRestoreHistorySpan = (
    LastMonth = 0,
    LastYear = 1,
    AnyTime = 2
  );
  PChat_ChatRestoreHistorySpan = ^Chat_ChatRestoreHistorySpan;

  // Windows.ApplicationModel.Chat.ChatStoreChangedEventKind
  Chat_ChatStoreChangedEventKind = (
    NotificationsMissed = 0,
    StoreModified = 1,
    MessageCreated = 2,
    MessageModified = 3,
    MessageDeleted = 4,
    ConversationModified = 5,
    ConversationDeleted = 6,
    ConversationTransportDeleted = 7
  );
  PChat_ChatStoreChangedEventKind = ^Chat_ChatStoreChangedEventKind;

  // Windows.ApplicationModel.Chat.ChatTransportErrorCodeCategory
  Chat_ChatTransportErrorCodeCategory = (
    None = 0,
    Http = 1,
    Network = 2,
    MmsServer = 3
  );
  PChat_ChatTransportErrorCodeCategory = ^Chat_ChatTransportErrorCodeCategory;

  // Windows.ApplicationModel.Chat.ChatTransportInterpretedErrorCode
  Chat_ChatTransportInterpretedErrorCode = (
    None = 0,
    Unknown = 1,
    InvalidRecipientAddress = 2,
    NetworkConnectivity = 3,
    ServiceDenied = 4,
    Timeout = 5
  );
  PChat_ChatTransportInterpretedErrorCode = ^Chat_ChatTransportInterpretedErrorCode;

  // Windows.ApplicationModel.Chat.RcsServiceKind
  Chat_RcsServiceKind = (
    Chat = 0,
    GroupChat = 1,
    FileTransfer = 2,
    Capability = 3
  );
  PChat_RcsServiceKind = ^Chat_RcsServiceKind;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationCreationStatus
  ConversationalAgent_ActivationSignalDetectionConfigurationCreationStatus = (
    Success = 0,
    SignalIdNotAvailable = 1,
    ModelIdNotSupported = 2,
    InvalidSignalId = 3,
    InvalidModelId = 4,
    InvalidDisplayName = 5,
    ConfigurationAlreadyExists = 6,
    CreationNotSupported = 7
  );
  PConversationalAgent_ActivationSignalDetectionConfigurationCreationStatus = ^ConversationalAgent_ActivationSignalDetectionConfigurationCreationStatus;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationRemovalResult
  ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = (
    Success = 0,
    NotFound = 1,
    CurrentlyEnabled = 2,
    RemovalNotSupported = 3
  );
  PConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = ^ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationSetModelDataResult
  ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = (
    Success = 0,
    EmptyModelData = 1,
    UnsupportedFormat = 2,
    ConfigurationCurrentlyEnabled = 3,
    InvalidData = 4,
    SetModelDataNotSupported = 5,
    ConfigurationNotFound = 6,
    UnknownError = 7
  );
  PConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = ^ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationStateChangeResult
  ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = (
    Success = 0,
    NoModelData = 1,
    ConfigurationNotFound = 2
  );
  PConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = ^ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat
  ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = (
    Voice8kHz8BitMono = 0,
    Voice8kHz16BitMono = 1,
    Voice16kHz8BitMono = 2,
    Voice16kHz16BitMono = 3,
    VoiceOEMDefined = 4,
    Audio44kHz8BitMono = 5,
    Audio44kHz16BitMono = 6,
    Audio48kHz8BitMono = 7,
    Audio48kHz16BitMono = 8,
    AudioOEMDefined = 9,
    OtherOEMDefined = 10
  );
  PConversationalAgent_ActivationSignalDetectionTrainingDataFormat = ^ConversationalAgent_ActivationSignalDetectionTrainingDataFormat;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorKind
  ConversationalAgent_ActivationSignalDetectorKind = (
    AudioPattern = 0,
    AudioImpulse = 1,
    HardwareEvent = 2
  );
  PConversationalAgent_ActivationSignalDetectorKind = ^ConversationalAgent_ActivationSignalDetectorKind;

  // Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState
  ConversationalAgent_ActivationSignalDetectorPowerState = (
    HighPower = 0,
    ConnectedLowPower = 1,
    DisconnectedLowPower = 2
  );
  PConversationalAgent_ActivationSignalDetectorPowerState = ^ConversationalAgent_ActivationSignalDetectorPowerState;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationKind
  ConversationalAgent_ConversationalAgentActivationKind = (
    VoiceActivationPreview = 0,
    Foreground = 1
  );
  PConversationalAgent_ConversationalAgentActivationKind = ^ConversationalAgent_ConversationalAgentActivationKind;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationResult
  ConversationalAgent_ConversationalAgentActivationResult = (
    Success = 0,
    AgentInactive = 1,
    ScreenNotAvailable = 2,
    AgentInterrupted = 3
  );
  PConversationalAgent_ConversationalAgentActivationResult = ^ConversationalAgent_ConversationalAgentActivationResult;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSessionUpdateResponse
  ConversationalAgent_ConversationalAgentSessionUpdateResponse = (
    Success = 0,
    Failed = 1
  );
  PConversationalAgent_ConversationalAgentSessionUpdateResponse = ^ConversationalAgent_ConversationalAgentSessionUpdateResponse;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentState
  ConversationalAgent_ConversationalAgentState = (
    Inactive = 0,
    Detecting = 1,
    Listening = 2,
    Working = 3,
    Speaking = 4,
    ListeningAndSpeaking = 5
  );
  PConversationalAgent_ConversationalAgentState = ^ConversationalAgent_ConversationalAgentState;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSystemStateChangeType
  ConversationalAgent_ConversationalAgentSystemStateChangeType = (
    UserAuthentication = 0,
    ScreenAvailability = 1,
    IndicatorLightAvailability = 2,
    VoiceActivationAvailability = 3
  );
  PConversationalAgent_ConversationalAgentSystemStateChangeType = ^ConversationalAgent_ConversationalAgentSystemStateChangeType;

  // Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind
  ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = (
    MicrophonePermission = 0,
    KnownAgents = 1,
    AgentAllowed = 2,
    AppCapability = 3,
    BackgroundTaskRegistration = 4,
    PolicyPermission = 5
  );
  PConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = ^ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind;

  // Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationAvailabilityChangeKind
  ConversationalAgent_DetectionConfigurationAvailabilityChangeKind = (
    SystemResourceAccess = 0,
    Permission = 1,
    LockScreenPermission = 2
  );
  PConversationalAgent_DetectionConfigurationAvailabilityChangeKind = ^ConversationalAgent_DetectionConfigurationAvailabilityChangeKind;

  // Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationTrainingStatus
  ConversationalAgent_DetectionConfigurationTrainingStatus = (
    Success = 0,
    FormatNotSupported = 1,
    VoiceTooQuiet = 2,
    VoiceTooLoud = 3,
    VoiceTooFast = 4,
    VoiceTooSlow = 5,
    VoiceQualityProblem = 6,
    TrainingSystemInternalError = 7,
    TrainingTimedOut = 8,
    ConfigurationNotFound = 9
  );
  PConversationalAgent_DetectionConfigurationTrainingStatus = ^ConversationalAgent_DetectionConfigurationTrainingStatus;

  // Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind
  ConversationalAgent_SignalDetectorResourceKind = (
    ParallelModelSupport = 0,
    ParallelModelSupportForAgent = 1,
    ParallelSignalSupport = 2,
    ParallelSignalSupportForAgent = 3,
    DisplayOffSupport = 4,
    PluggedInPower = 5,
    Detector = 6,
    SupportedSleepState = 7,
    SupportedBatterySaverState = 8,
    ScreenAvailability = 9,
    InputHardware = 10,
    AcousticEchoCancellation = 11,
    ModelIdSupport = 12,
    DataChannel = 13
  );
  PConversationalAgent_SignalDetectorResourceKind = ^ConversationalAgent_SignalDetectorResourceKind;

  // Windows.ApplicationModel.Email.EmailAttachmentDownloadState
  Email_EmailAttachmentDownloadState = (
    NotDownloaded = 0,
    Downloading = 1,
    Downloaded = 2,
    Failed = 3
  );
  PEmail_EmailAttachmentDownloadState = ^Email_EmailAttachmentDownloadState;

  // Windows.ApplicationModel.Email.EmailBatchStatus
  Email_EmailBatchStatus = (
    Success = 0,
    ServerSearchSyncManagerError = 1,
    ServerSearchUnknownError = 2
  );
  PEmail_EmailBatchStatus = ^Email_EmailBatchStatus;

  // Windows.ApplicationModel.Email.EmailCertificateValidationStatus
  Email_EmailCertificateValidationStatus = (
    Success = 0,
    NoMatch = 1,
    InvalidUsage = 2,
    InvalidCertificate = 3,
    Revoked = 4,
    ChainRevoked = 5,
    RevocationServerFailure = 6,
    Expired = 7,
    Untrusted = 8,
    ServerError = 9,
    UnknownFailure = 10
  );
  PEmail_EmailCertificateValidationStatus = ^Email_EmailCertificateValidationStatus;

  // Windows.ApplicationModel.Email.EmailFlagState
  Email_EmailFlagState = (
    Unflagged = 0,
    Flagged = 1,
    Completed = 2,
    Cleared = 3
  );
  PEmail_EmailFlagState = ^Email_EmailFlagState;

  // Windows.ApplicationModel.Email.EmailImportance
  Email_EmailImportance = (
    Normal = 0,
    High = 1,
    Low = 2
  );
  PEmail_EmailImportance = ^Email_EmailImportance;

  // Windows.ApplicationModel.Email.EmailMailboxActionKind
  Email_EmailMailboxActionKind = (
    MarkMessageAsSeen = 0,
    MarkMessageRead = 1,
    ChangeMessageFlagState = 2,
    MoveMessage = 3,
    SaveDraft = 4,
    SendMessage = 5,
    CreateResponseReplyMessage = 6,
    CreateResponseReplyAllMessage = 7,
    CreateResponseForwardMessage = 8,
    MoveFolder = 9,
    MarkFolderForSyncEnabled = 10
  );
  PEmail_EmailMailboxActionKind = ^Email_EmailMailboxActionKind;

  // Windows.ApplicationModel.Email.EmailMailboxAllowedSmimeEncryptionAlgorithmNegotiation
  Email_EmailMailboxAllowedSmimeEncryptionAlgorithmNegotiation = (
    None = 0,
    StrongAlgorithm = 1,
    AnyAlgorithm = 2
  );
  PEmail_EmailMailboxAllowedSmimeEncryptionAlgorithmNegotiation = ^Email_EmailMailboxAllowedSmimeEncryptionAlgorithmNegotiation;

  // Windows.ApplicationModel.Email.EmailMailboxAutoReplyMessageResponseKind
  Email_EmailMailboxAutoReplyMessageResponseKind = (
    Html = 0,
    PlainText = 1
  );
  PEmail_EmailMailboxAutoReplyMessageResponseKind = ^Email_EmailMailboxAutoReplyMessageResponseKind;

  // Windows.ApplicationModel.Email.EmailMailboxChangeType
  Email_EmailMailboxChangeType = (
    MessageCreated = 0,
    MessageModified = 1,
    MessageDeleted = 2,
    FolderCreated = 3,
    FolderModified = 4,
    FolderDeleted = 5,
    ChangeTrackingLost = 6
  );
  PEmail_EmailMailboxChangeType = ^Email_EmailMailboxChangeType;

  // Windows.ApplicationModel.Email.EmailMailboxCreateFolderStatus
  Email_EmailMailboxCreateFolderStatus = (
    Success = 0,
    NetworkError = 1,
    PermissionsError = 2,
    ServerError = 3,
    UnknownFailure = 4,
    NameCollision = 5,
    ServerRejected = 6
  );
  PEmail_EmailMailboxCreateFolderStatus = ^Email_EmailMailboxCreateFolderStatus;

  // Windows.ApplicationModel.Email.EmailMailboxDeleteFolderStatus
  Email_EmailMailboxDeleteFolderStatus = (
    Success = 0,
    NetworkError = 1,
    PermissionsError = 2,
    ServerError = 3,
    UnknownFailure = 4,
    CouldNotDeleteEverything = 5
  );
  PEmail_EmailMailboxDeleteFolderStatus = ^Email_EmailMailboxDeleteFolderStatus;

  // Windows.ApplicationModel.Email.EmailMailboxEmptyFolderStatus
  Email_EmailMailboxEmptyFolderStatus = (
    Success = 0,
    NetworkError = 1,
    PermissionsError = 2,
    ServerError = 3,
    UnknownFailure = 4,
    CouldNotDeleteEverything = 5
  );
  PEmail_EmailMailboxEmptyFolderStatus = ^Email_EmailMailboxEmptyFolderStatus;

  // Windows.ApplicationModel.Email.EmailMailboxOtherAppReadAccess
  Email_EmailMailboxOtherAppReadAccess = (
    SystemOnly = 0,
    Full = 1,
    None = 2
  );
  PEmail_EmailMailboxOtherAppReadAccess = ^Email_EmailMailboxOtherAppReadAccess;

  // Windows.ApplicationModel.Email.EmailMailboxOtherAppWriteAccess
  Email_EmailMailboxOtherAppWriteAccess = (
    None = 0,
    Limited = 1
  );
  PEmail_EmailMailboxOtherAppWriteAccess = ^Email_EmailMailboxOtherAppWriteAccess;

  // Windows.ApplicationModel.Email.EmailMailboxSmimeEncryptionAlgorithm
  Email_EmailMailboxSmimeEncryptionAlgorithm = (
    Any = 0,
    TripleDes = 1,
    Des = 2,
    RC2128Bit = 3,
    RC264Bit = 4,
    RC240Bit = 5
  );
  PEmail_EmailMailboxSmimeEncryptionAlgorithm = ^Email_EmailMailboxSmimeEncryptionAlgorithm;

  // Windows.ApplicationModel.Email.EmailMailboxSmimeSigningAlgorithm
  Email_EmailMailboxSmimeSigningAlgorithm = (
    Any = 0,
    Sha1 = 1,
    MD5 = 2
  );
  PEmail_EmailMailboxSmimeSigningAlgorithm = ^Email_EmailMailboxSmimeSigningAlgorithm;

  // Windows.ApplicationModel.Email.EmailMailboxSyncStatus
  Email_EmailMailboxSyncStatus = (
    Idle = 0,
    Syncing = 1,
    UpToDate = 2,
    AuthenticationError = 3,
    PolicyError = 4,
    UnknownError = 5,
    ManualAccountRemovalRequired = 6
  );
  PEmail_EmailMailboxSyncStatus = ^Email_EmailMailboxSyncStatus;

  // Windows.ApplicationModel.Email.EmailMeetingResponseType
  Email_EmailMeetingResponseType = (
    Accept = 0,
    Decline = 1,
    Tentative = 2
  );
  PEmail_EmailMeetingResponseType = ^Email_EmailMeetingResponseType;

  // Windows.ApplicationModel.Email.EmailMessageBodyKind
  Email_EmailMessageBodyKind = (
    Html = 0,
    PlainText = 1
  );
  PEmail_EmailMessageBodyKind = ^Email_EmailMessageBodyKind;

  // Windows.ApplicationModel.Email.EmailMessageDownloadState
  Email_EmailMessageDownloadState = (
    PartiallyDownloaded = 0,
    Downloading = 1,
    Downloaded = 2,
    Failed = 3
  );
  PEmail_EmailMessageDownloadState = ^Email_EmailMessageDownloadState;

  // Windows.ApplicationModel.Email.EmailMessageResponseKind
  Email_EmailMessageResponseKind = (
    None = 0,
    Reply = 1,
    ReplyAll = 2,
    Forward = 3
  );
  PEmail_EmailMessageResponseKind = ^Email_EmailMessageResponseKind;

  // Windows.ApplicationModel.Email.EmailMessageSmimeKind
  Email_EmailMessageSmimeKind = (
    None = 0,
    ClearSigned = 1,
    OpaqueSigned = 2,
    Encrypted = 3
  );
  PEmail_EmailMessageSmimeKind = ^Email_EmailMessageSmimeKind;

  // Windows.ApplicationModel.Email.EmailQueryKind
  Email_EmailQueryKind = (
    All = 0,
    Important = 1,
    Flagged = 2,
    Unread = 3,
    Read = 4,
    Unseen = 5
  );
  PEmail_EmailQueryKind = ^Email_EmailQueryKind;

  // Windows.ApplicationModel.Email.EmailQuerySearchFields
  Email_EmailQuerySearchFields = (
    None = 0,
    Subject = 1,
    Sender = 2,
    Preview = 4,
    Recipients = 8,
    All = -1
  );
  PEmail_EmailQuerySearchFields = ^Email_EmailQuerySearchFields;

  // Windows.ApplicationModel.Email.EmailQuerySearchScope
  Email_EmailQuerySearchScope = (
    Local = 0,
    Server = 1
  );
  PEmail_EmailQuerySearchScope = ^Email_EmailQuerySearchScope;

  // Windows.ApplicationModel.Email.EmailQuerySortDirection
  Email_EmailQuerySortDirection = (
    Descending = 0,
    Ascending = 1
  );
  PEmail_EmailQuerySortDirection = ^Email_EmailQuerySortDirection;

  // Windows.ApplicationModel.Email.EmailQuerySortProperty
  Email_EmailQuerySortProperty = (
    Date = 0
  );
  PEmail_EmailQuerySortProperty = ^Email_EmailQuerySortProperty;

  // Windows.ApplicationModel.Email.EmailRecipientResolutionStatus
  Email_EmailRecipientResolutionStatus = (
    Success = 0,
    RecipientNotFound = 1,
    AmbiguousRecipient = 2,
    NoCertificate = 3,
    CertificateRequestLimitReached = 4,
    CannotResolveDistributionList = 5,
    ServerError = 6,
    UnknownFailure = 7
  );
  PEmail_EmailRecipientResolutionStatus = ^Email_EmailRecipientResolutionStatus;

  // Windows.ApplicationModel.Email.EmailSpecialFolderKind
  Email_EmailSpecialFolderKind = (
    None = 0,
    Root = 1,
    Inbox = 2,
    Outbox = 3,
    Drafts = 4,
    DeletedItems = 5,
    Sent = 6
  );
  PEmail_EmailSpecialFolderKind = ^Email_EmailSpecialFolderKind;

  // Windows.ApplicationModel.Email.EmailStoreAccessType
  Email_EmailStoreAccessType = (
    AppMailboxesReadWrite = 0,
    AllMailboxesLimitedReadWrite = 1
  );
  PEmail_EmailStoreAccessType = ^Email_EmailStoreAccessType;

  // Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionReason
  ExtendedExecution_ExtendedExecutionReason = (
    Unspecified = 0,
    LocationTracking = 1,
    SavingData = 2
  );
  PExtendedExecution_ExtendedExecutionReason = ^ExtendedExecution_ExtendedExecutionReason;

  // Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult
  ExtendedExecution_ExtendedExecutionResult = (
    Allowed = 0,
    Denied = 1
  );
  PExtendedExecution_ExtendedExecutionResult = ^ExtendedExecution_ExtendedExecutionResult;

  // Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionRevokedReason
  ExtendedExecution_ExtendedExecutionRevokedReason = (
    Resumed = 0,
    SystemPolicy = 1
  );
  PExtendedExecution_ExtendedExecutionRevokedReason = ^ExtendedExecution_ExtendedExecutionRevokedReason;

  // Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundReason
  ExtendedExecution_Foreground_ExtendedExecutionForegroundReason = (
    Unspecified = 0,
    SavingData = 1,
    BackgroundAudio = 2,
    Unconstrained = 3
  );
  PExtendedExecution_Foreground_ExtendedExecutionForegroundReason = ^ExtendedExecution_Foreground_ExtendedExecutionForegroundReason;

  // Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundResult
  ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = (
    Allowed = 0,
    Denied = 1
  );
  PExtendedExecution_Foreground_ExtendedExecutionForegroundResult = ^ExtendedExecution_Foreground_ExtendedExecutionForegroundResult;

  // Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundRevokedReason
  ExtendedExecution_Foreground_ExtendedExecutionForegroundRevokedReason = (
    Resumed = 0,
    SystemPolicy = 1
  );
  PExtendedExecution_Foreground_ExtendedExecutionForegroundRevokedReason = ^ExtendedExecution_Foreground_ExtendedExecutionForegroundRevokedReason;

  // Windows.ApplicationModel.FullTrustLaunchResult
  FullTrustLaunchResult = (
    Success = 0,
    AccessDenied = 1,
    FileNotFound = 2,
    Unknown = 3
  );
  PFullTrustLaunchResult = ^FullTrustLaunchResult;

  // Windows.ApplicationModel.LimitedAccessFeatureStatus
  LimitedAccessFeatureStatus = (
    Unavailable = 0,
    Available = 1,
    AvailableWithoutToken = 2,
    Unknown = 3
  );
  PLimitedAccessFeatureStatus = ^LimitedAccessFeatureStatus;

  // Windows.ApplicationModel.PackageContentGroupState
  PackageContentGroupState = (
    NotStaged = 0,
    Queued = 1,
    Staging = 2,
    Staged = 3
  );
  PPackageContentGroupState = ^PackageContentGroupState;

  // Windows.ApplicationModel.PackageRelationship
  PackageRelationship = (
    Dependencies = 0,
    Dependents = 1,
    All = 2
  );
  PPackageRelationship = ^PackageRelationship;

  // Windows.ApplicationModel.PackageSignatureKind
  PackageSignatureKind = (
    None = 0,
    Developer = 1,
    Enterprise = 2,
    Store = 3,
    System = 4
  );
  PPackageSignatureKind = ^PackageSignatureKind;

  // Windows.ApplicationModel.PackageUpdateAvailability
  PackageUpdateAvailability = (
    Unknown = 0,
    NoUpdates = 1,
    Available = 2,
    Required = 3,
    Error = 4
  );
  PPackageUpdateAvailability = ^PackageUpdateAvailability;

  // Windows.ApplicationModel.Payments.PaymentCanMakePaymentResultStatus
  Payments_PaymentCanMakePaymentResultStatus = (
    Unknown = 0,
    Yes = 1,
    No = 2,
    NotAllowed = 3,
    UserNotSignedIn = 4,
    SpecifiedPaymentMethodIdsNotSupported = 5,
    NoQualifyingCardOnFile = 6
  );
  PPayments_PaymentCanMakePaymentResultStatus = ^Payments_PaymentCanMakePaymentResultStatus;

  // Windows.ApplicationModel.Payments.PaymentOptionPresence
  Payments_PaymentOptionPresence = (
    None = 0,
    Optional = 1,
    Required = 2
  );
  PPayments_PaymentOptionPresence = ^Payments_PaymentOptionPresence;

  // Windows.ApplicationModel.Payments.PaymentRequestChangeKind
  Payments_PaymentRequestChangeKind = (
    ShippingOption = 0,
    ShippingAddress = 1
  );
  PPayments_PaymentRequestChangeKind = ^Payments_PaymentRequestChangeKind;

  // Windows.ApplicationModel.Payments.PaymentRequestCompletionStatus
  Payments_PaymentRequestCompletionStatus = (
    Succeeded = 0,
    Failed = 1,
    Unknown = 2
  );
  PPayments_PaymentRequestCompletionStatus = ^Payments_PaymentRequestCompletionStatus;

  // Windows.ApplicationModel.Payments.PaymentRequestStatus
  Payments_PaymentRequestStatus = (
    Succeeded = 0,
    Failed = 1,
    Canceled = 2
  );
  PPayments_PaymentRequestStatus = ^Payments_PaymentRequestStatus;

  // Windows.ApplicationModel.Payments.PaymentShippingType
  Payments_PaymentShippingType = (
    Shipping = 0,
    Delivery = 1,
    Pickup = 2
  );
  PPayments_PaymentShippingType = ^Payments_PaymentShippingType;

  // Windows.ApplicationModel.Resources.Core.ResourceCandidateKind
  Resources_Core_ResourceCandidateKind = (
    &String = 0,
    &File = 1,
    EmbeddedData = 2
  );
  PResources_Core_ResourceCandidateKind = ^Resources_Core_ResourceCandidateKind;

  // Windows.ApplicationModel.Resources.Core.ResourceQualifierPersistence
  Resources_Core_ResourceQualifierPersistence = (
    None = 0,
    LocalMachine = 1
  );
  PResources_Core_ResourceQualifierPersistence = ^Resources_Core_ResourceQualifierPersistence;

  // Windows.ApplicationModel.Resources.Management.IndexedResourceType
  Resources_Management_IndexedResourceType = (
    &String = 0,
    Path = 1,
    EmbeddedData = 2
  );
  PResources_Management_IndexedResourceType = ^Resources_Management_IndexedResourceType;

  // Windows.ApplicationModel.Search.Core.SearchSuggestionKind
  Search_Core_SearchSuggestionKind = (
    Query = 0,
    Result = 1,
    Separator = 2
  );
  PSearch_Core_SearchSuggestionKind = ^Search_Core_SearchSuggestionKind;

  // Windows.ApplicationModel.SocialInfo.SocialFeedItemStyle
  SocialInfo_SocialFeedItemStyle = (
    Default = 0,
    Photo = 1
  );
  PSocialInfo_SocialFeedItemStyle = ^SocialInfo_SocialFeedItemStyle;

  // Windows.ApplicationModel.SocialInfo.SocialFeedKind
  SocialInfo_SocialFeedKind = (
    HomeFeed = 0,
    ContactFeed = 1,
    Dashboard = 2
  );
  PSocialInfo_SocialFeedKind = ^SocialInfo_SocialFeedKind;

  // Windows.ApplicationModel.SocialInfo.SocialFeedUpdateMode
  SocialInfo_SocialFeedUpdateMode = (
    Append = 0,
    Replace = 1
  );
  PSocialInfo_SocialFeedUpdateMode = ^SocialInfo_SocialFeedUpdateMode;

  // Windows.ApplicationModel.SocialInfo.SocialItemBadgeStyle
  SocialInfo_SocialItemBadgeStyle = (
    Hidden = 0,
    Visible = 1,
    VisibleWithCount = 2
  );
  PSocialInfo_SocialItemBadgeStyle = ^SocialInfo_SocialItemBadgeStyle;

  // Windows.ApplicationModel.StartupTaskState
  StartupTaskState = (
    Disabled = 0,
    DisabledByUser = 1,
    Enabled = 2,
    DisabledByPolicy = 3,
    EnabledByPolicy = 4
  );
  PStartupTaskState = ^StartupTaskState;

  // Windows.ApplicationModel.Store.FulfillmentResult
  Store_FulfillmentResult = (
    Succeeded = 0,
    NothingToFulfill = 1,
    PurchasePending = 2,
    PurchaseReverted = 3,
    ServerError = 4
  );
  PStore_FulfillmentResult = ^Store_FulfillmentResult;

  // Windows.ApplicationModel.Store.LicenseManagement.LicenseRefreshOption
  Store_LicenseManagement_LicenseRefreshOption = (
    RunningLicenses = 0,
    AllLicenses = 1
  );
  PStore_LicenseManagement_LicenseRefreshOption = ^Store_LicenseManagement_LicenseRefreshOption;

  // Windows.ApplicationModel.Store.Preview.DeliveryOptimizationDownloadMode
  Store_Preview_DeliveryOptimizationDownloadMode = (
    Simple = 0,
    HttpOnly = 1,
    Lan = 2,
    Group = 3,
    Internet = 4,
    Bypass = 5
  );
  PStore_Preview_DeliveryOptimizationDownloadMode = ^Store_Preview_DeliveryOptimizationDownloadMode;

  // Windows.ApplicationModel.Store.Preview.DeliveryOptimizationDownloadModeSource
  Store_Preview_DeliveryOptimizationDownloadModeSource = (
    Default = 0,
    Policy = 1
  );
  PStore_Preview_DeliveryOptimizationDownloadModeSource = ^Store_Preview_DeliveryOptimizationDownloadModeSource;

  // Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallState
  Store_Preview_InstallControl_AppInstallState = (
    Pending = 0,
    Starting = 1,
    AcquiringLicense = 2,
    Downloading = 3,
    RestoringData = 4,
    Installing = 5,
    Completed = 6,
    Canceled = 7,
    Paused = 8,
    Error = 9,
    PausedLowBattery = 10,
    PausedWiFiRecommended = 11,
    PausedWiFiRequired = 12,
    ReadyToDownload = 13
  );
  PStore_Preview_InstallControl_AppInstallState = ^Store_Preview_InstallControl_AppInstallState;

  // Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallType
  Store_Preview_InstallControl_AppInstallType = (
    Install = 0,
    Update = 1,
    Repair = 2
  );
  PStore_Preview_InstallControl_AppInstallType = ^Store_Preview_InstallControl_AppInstallType;

  // Windows.ApplicationModel.Store.Preview.InstallControl.AppInstallationToastNotificationMode
  Store_Preview_InstallControl_AppInstallationToastNotificationMode = (
    Default = 0,
    Toast = 1,
    ToastWithoutPopup = 2,
    NoToast = 3
  );
  PStore_Preview_InstallControl_AppInstallationToastNotificationMode = ^Store_Preview_InstallControl_AppInstallationToastNotificationMode;

  // Windows.ApplicationModel.Store.Preview.InstallControl.AutoUpdateSetting
  Store_Preview_InstallControl_AutoUpdateSetting = (
    Disabled = 0,
    Enabled = 1,
    DisabledByPolicy = 2,
    EnabledByPolicy = 3
  );
  PStore_Preview_InstallControl_AutoUpdateSetting = ^Store_Preview_InstallControl_AutoUpdateSetting;

  // Windows.ApplicationModel.Store.Preview.InstallControl.GetEntitlementStatus
  Store_Preview_InstallControl_GetEntitlementStatus = (
    Succeeded = 0,
    NoStoreAccount = 1,
    NetworkError = 2,
    ServerError = 3
  );
  PStore_Preview_InstallControl_GetEntitlementStatus = ^Store_Preview_InstallControl_GetEntitlementStatus;

  // Windows.ApplicationModel.Store.Preview.StoreLogOptions
  Store_Preview_StoreLogOptions = (
    None = 0,
    TryElevate = 1
  );
  PStore_Preview_StoreLogOptions = ^Store_Preview_StoreLogOptions;

  // Windows.ApplicationModel.Store.Preview.StorePreviewProductPurchaseStatus
  Store_Preview_StorePreviewProductPurchaseStatus = (
    Succeeded = 0,
    AlreadyPurchased = 1,
    NotFulfilled = 2,
    NotPurchased = 3
  );
  PStore_Preview_StorePreviewProductPurchaseStatus = ^Store_Preview_StorePreviewProductPurchaseStatus;

  // Windows.ApplicationModel.Store.Preview.StoreSystemFeature
  Store_Preview_StoreSystemFeature = (
    ArchitectureX86 = 0,
    ArchitectureX64 = 1,
    ArchitectureArm = 2,
    DirectX9 = 3,
    DirectX10 = 4,
    DirectX11 = 5,
    D3D12HardwareFL11 = 6,
    D3D12HardwareFL12 = 7,
    Memory300MB = 8,
    Memory750MB = 9,
    Memory1GB = 10,
    Memory2GB = 11,
    CameraFront = 12,
    CameraRear = 13,
    Gyroscope = 14,
    Hover = 15,
    Magnetometer = 16,
    Nfc = 17,
    Resolution720P = 18,
    ResolutionWvga = 19,
    ResolutionWvgaOr720P = 20,
    ResolutionWxga = 21,
    ResolutionWvgaOrWxga = 22,
    ResolutionWxgaOr720P = 23,
    Memory4GB = 24,
    Memory6GB = 25,
    Memory8GB = 26,
    Memory12GB = 27,
    Memory16GB = 28,
    Memory20GB = 29,
    VideoMemory2GB = 30,
    VideoMemory4GB = 31,
    VideoMemory6GB = 32,
    VideoMemory1GB = 33,
    ArchitectureArm64 = 34
  );
  PStore_Preview_StoreSystemFeature = ^Store_Preview_StoreSystemFeature;

  // Windows.ApplicationModel.Store.ProductPurchaseStatus
  Store_ProductPurchaseStatus = (
    Succeeded = 0,
    AlreadyPurchased = 1,
    NotFulfilled = 2,
    NotPurchased = 3
  );
  PStore_ProductPurchaseStatus = ^Store_ProductPurchaseStatus;

  // Windows.ApplicationModel.Store.ProductType
  Store_ProductType = (
    Unknown = 0,
    Durable = 1,
    Consumable = 2
  );
  PStore_ProductType = ^Store_ProductType;

  // Windows.ApplicationModel.UserActivities.UserActivityState
  UserActivities_UserActivityState = (
    New = 0,
    &Published = 1
  );
  PUserActivities_UserActivityState = ^UserActivities_UserActivityState;

  // Windows.ApplicationModel.UserDataAccounts.Provider.UserDataAccountProviderOperationKind
  UserDataAccounts_Provider_UserDataAccountProviderOperationKind = (
    AddAccount = 0,
    Settings = 1,
    ResolveErrors = 2
  );
  PUserDataAccounts_Provider_UserDataAccountProviderOperationKind = ^UserDataAccounts_Provider_UserDataAccountProviderOperationKind;

  // Windows.ApplicationModel.UserDataAccounts.Provider.UserDataAccountProviderPartnerAccountKind
  UserDataAccounts_Provider_UserDataAccountProviderPartnerAccountKind = (
    Exchange = 0,
    PopOrImap = 1
  );
  PUserDataAccounts_Provider_UserDataAccountProviderPartnerAccountKind = ^UserDataAccounts_Provider_UserDataAccountProviderPartnerAccountKind;

  // Windows.ApplicationModel.UserDataAccounts.SystemAccess.DeviceAccountAuthenticationType
  UserDataAccounts_SystemAccess_DeviceAccountAuthenticationType = (
    Basic = 0,
    OAuth = 1,
    SingleSignOn = 2
  );
  PUserDataAccounts_SystemAccess_DeviceAccountAuthenticationType = ^UserDataAccounts_SystemAccess_DeviceAccountAuthenticationType;

  // Windows.ApplicationModel.UserDataAccounts.SystemAccess.DeviceAccountIconId
  UserDataAccounts_SystemAccess_DeviceAccountIconId = (
    Exchange = 0,
    Msa = 1,
    Outlook = 2,
    Generic = 3
  );
  PUserDataAccounts_SystemAccess_DeviceAccountIconId = ^UserDataAccounts_SystemAccess_DeviceAccountIconId;

  // Windows.ApplicationModel.UserDataAccounts.SystemAccess.DeviceAccountMailAgeFilter
  UserDataAccounts_SystemAccess_DeviceAccountMailAgeFilter = (
    All = 0,
    Last1Day = 1,
    Last3Days = 2,
    Last7Days = 3,
    Last14Days = 4,
    Last30Days = 5,
    Last90Days = 6
  );
  PUserDataAccounts_SystemAccess_DeviceAccountMailAgeFilter = ^UserDataAccounts_SystemAccess_DeviceAccountMailAgeFilter;

  // Windows.ApplicationModel.UserDataAccounts.SystemAccess.DeviceAccountServerType
  UserDataAccounts_SystemAccess_DeviceAccountServerType = (
    Exchange = 0,
    Pop = 1,
    Imap = 2
  );
  PUserDataAccounts_SystemAccess_DeviceAccountServerType = ^UserDataAccounts_SystemAccess_DeviceAccountServerType;

  // Windows.ApplicationModel.UserDataAccounts.SystemAccess.DeviceAccountSyncScheduleKind
  UserDataAccounts_SystemAccess_DeviceAccountSyncScheduleKind = (
    Manual = 0,
    Every15Minutes = 1,
    Every30Minutes = 2,
    Every60Minutes = 3,
    Every2Hours = 4,
    Daily = 5,
    AsItemsArrive = 6
  );
  PUserDataAccounts_SystemAccess_DeviceAccountSyncScheduleKind = ^UserDataAccounts_SystemAccess_DeviceAccountSyncScheduleKind;

  // Windows.ApplicationModel.UserDataAccounts.UserDataAccountContentKinds
  UserDataAccounts_UserDataAccountContentKinds = (
    Email = 1,
    Contact = 2,
    Appointment = 4
  );
  PUserDataAccounts_UserDataAccountContentKinds = ^UserDataAccounts_UserDataAccountContentKinds;

  // Windows.ApplicationModel.UserDataAccounts.UserDataAccountOtherAppReadAccess
  UserDataAccounts_UserDataAccountOtherAppReadAccess = (
    SystemOnly = 0,
    Full = 1,
    None = 2
  );
  PUserDataAccounts_UserDataAccountOtherAppReadAccess = ^UserDataAccounts_UserDataAccountOtherAppReadAccess;

  // Windows.ApplicationModel.UserDataAccounts.UserDataAccountStoreAccessType
  UserDataAccounts_UserDataAccountStoreAccessType = (
    AllAccountsReadOnly = 0,
    AppAccountsReadWrite = 1
  );
  PUserDataAccounts_UserDataAccountStoreAccessType = ^UserDataAccounts_UserDataAccountStoreAccessType;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskDaysOfWeek
  UserDataTasks_UserDataTaskDaysOfWeek = (
    None = 0,
    Sunday = 1,
    Monday = 2,
    Tuesday = 4,
    Wednesday = 8,
    Thursday = 16,
    Friday = 32,
    Saturday = 64
  );
  PUserDataTasks_UserDataTaskDaysOfWeek = ^UserDataTasks_UserDataTaskDaysOfWeek;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskDetailsKind
  UserDataTasks_UserDataTaskDetailsKind = (
    PlainText = 0,
    Html = 1
  );
  PUserDataTasks_UserDataTaskDetailsKind = ^UserDataTasks_UserDataTaskDetailsKind;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskKind
  UserDataTasks_UserDataTaskKind = (
    Single = 0,
    Recurring = 1,
    Regenerating = 2
  );
  PUserDataTasks_UserDataTaskKind = ^UserDataTasks_UserDataTaskKind;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskListOtherAppReadAccess
  UserDataTasks_UserDataTaskListOtherAppReadAccess = (
    Full = 0,
    SystemOnly = 1,
    None = 2
  );
  PUserDataTasks_UserDataTaskListOtherAppReadAccess = ^UserDataTasks_UserDataTaskListOtherAppReadAccess;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskListOtherAppWriteAccess
  UserDataTasks_UserDataTaskListOtherAppWriteAccess = (
    Limited = 0,
    None = 1
  );
  PUserDataTasks_UserDataTaskListOtherAppWriteAccess = ^UserDataTasks_UserDataTaskListOtherAppWriteAccess;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskListSyncStatus
  UserDataTasks_UserDataTaskListSyncStatus = (
    Idle = 0,
    Syncing = 1,
    UpToDate = 2,
    AuthenticationError = 3,
    PolicyError = 4,
    UnknownError = 5
  );
  PUserDataTasks_UserDataTaskListSyncStatus = ^UserDataTasks_UserDataTaskListSyncStatus;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskPriority
  UserDataTasks_UserDataTaskPriority = (
    Normal = 0,
    Low = -1,
    High = 1
  );
  PUserDataTasks_UserDataTaskPriority = ^UserDataTasks_UserDataTaskPriority;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskQueryKind
  UserDataTasks_UserDataTaskQueryKind = (
    All = 0,
    Incomplete = 1,
    Complete = 2
  );
  PUserDataTasks_UserDataTaskQueryKind = ^UserDataTasks_UserDataTaskQueryKind;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskQuerySortProperty
  UserDataTasks_UserDataTaskQuerySortProperty = (
    DueDate = 0
  );
  PUserDataTasks_UserDataTaskQuerySortProperty = ^UserDataTasks_UserDataTaskQuerySortProperty;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskRecurrenceUnit
  UserDataTasks_UserDataTaskRecurrenceUnit = (
    Daily = 0,
    Weekly = 1,
    Monthly = 2,
    MonthlyOnDay = 3,
    Yearly = 4,
    YearlyOnDay = 5
  );
  PUserDataTasks_UserDataTaskRecurrenceUnit = ^UserDataTasks_UserDataTaskRecurrenceUnit;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskRegenerationUnit
  UserDataTasks_UserDataTaskRegenerationUnit = (
    Daily = 0,
    Weekly = 1,
    Monthly = 2,
    Yearly = 4
  );
  PUserDataTasks_UserDataTaskRegenerationUnit = ^UserDataTasks_UserDataTaskRegenerationUnit;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskSensitivity
  UserDataTasks_UserDataTaskSensitivity = (
    &Public = 0,
    &Private = 1
  );
  PUserDataTasks_UserDataTaskSensitivity = ^UserDataTasks_UserDataTaskSensitivity;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskStoreAccessType
  UserDataTasks_UserDataTaskStoreAccessType = (
    AppTasksReadWrite = 0,
    AllTasksLimitedReadWrite = 1
  );
  PUserDataTasks_UserDataTaskStoreAccessType = ^UserDataTasks_UserDataTaskStoreAccessType;

  // Windows.ApplicationModel.UserDataTasks.UserDataTaskWeekOfMonth
  UserDataTasks_UserDataTaskWeekOfMonth = (
    First = 0,
    Second = 1,
    Third = 2,
    Fourth = 3,
    Last = 4
  );
  PUserDataTasks_UserDataTaskWeekOfMonth = ^UserDataTasks_UserDataTaskWeekOfMonth;

  // Windows.ApplicationModel.VoiceCommands.VoiceCommandCompletionReason
  VoiceCommands_VoiceCommandCompletionReason = (
    Unknown = 0,
    CommunicationFailed = 1,
    ResourceLimitsExceeded = 2,
    Canceled = 3,
    TimeoutExceeded = 4,
    AppLaunched = 5,
    Completed = 6
  );
  PVoiceCommands_VoiceCommandCompletionReason = ^VoiceCommands_VoiceCommandCompletionReason;

  // Windows.ApplicationModel.VoiceCommands.VoiceCommandContentTileType
  VoiceCommands_VoiceCommandContentTileType = (
    TitleOnly = 0,
    TitleWithText = 1,
    TitleWith68x68Icon = 2,
    TitleWith68x68IconAndText = 3,
    TitleWith68x92Icon = 4,
    TitleWith68x92IconAndText = 5,
    TitleWith280x140Icon = 6,
    TitleWith280x140IconAndText = 7
  );
  PVoiceCommands_VoiceCommandContentTileType = ^VoiceCommands_VoiceCommandContentTileType;

  // Windows.ApplicationModel.Wallet.System.WalletItemAppAssociation
  Wallet_System_WalletItemAppAssociation = (
    None = 0,
    AppInstalled = 1,
    AppNotInstalled = 2
  );
  PWallet_System_WalletItemAppAssociation = ^Wallet_System_WalletItemAppAssociation;

  // Windows.ApplicationModel.Wallet.WalletActionKind
  Wallet_WalletActionKind = (
    OpenItem = 0,
    Transaction = 1,
    MoreTransactions = 2,
    &Message = 3,
    Verb = 4
  );
  PWallet_WalletActionKind = ^Wallet_WalletActionKind;

  // Windows.ApplicationModel.Wallet.WalletBarcodeSymbology
  Wallet_WalletBarcodeSymbology = (
    Invalid = 0,
    Upca = 1,
    Upce = 2,
    Ean13 = 3,
    Ean8 = 4,
    Itf = 5,
    Code39 = 6,
    Code128 = 7,
    Qr = 8,
    Pdf417 = 9,
    Aztec = 10,
    Custom = 100000
  );
  PWallet_WalletBarcodeSymbology = ^Wallet_WalletBarcodeSymbology;

  // Windows.ApplicationModel.Wallet.WalletDetailViewPosition
  Wallet_WalletDetailViewPosition = (
    Hidden = 0,
    HeaderField1 = 1,
    HeaderField2 = 2,
    PrimaryField1 = 3,
    PrimaryField2 = 4,
    SecondaryField1 = 5,
    SecondaryField2 = 6,
    SecondaryField3 = 7,
    SecondaryField4 = 8,
    SecondaryField5 = 9,
    CenterField1 = 10,
    FooterField1 = 11,
    FooterField2 = 12,
    FooterField3 = 13,
    FooterField4 = 14
  );
  PWallet_WalletDetailViewPosition = ^Wallet_WalletDetailViewPosition;

  // Windows.ApplicationModel.Wallet.WalletItemKind
  Wallet_WalletItemKind = (
    Invalid = 0,
    Deal = 1,
    General = 2,
    PaymentInstrument = 3,
    Ticket = 4,
    BoardingPass = 5,
    MembershipCard = 6
  );
  PWallet_WalletItemKind = ^Wallet_WalletItemKind;

  // Windows.ApplicationModel.Wallet.WalletSummaryViewPosition
  Wallet_WalletSummaryViewPosition = (
    Hidden = 0,
    Field1 = 1,
    Field2 = 2
  );
  PWallet_WalletSummaryViewPosition = ^Wallet_WalletSummaryViewPosition;

  // Windows.ApplicationModel Records

  // Windows.ApplicationModel.Activation.ActivatedEventsContract
  Activation_ActivatedEventsContract = record
  end;
  PActivation_ActivatedEventsContract = ^Activation_ActivatedEventsContract;

  // Windows.ApplicationModel.Activation.ActivationCameraSettingsContract
  Activation_ActivationCameraSettingsContract = record
  end;
  PActivation_ActivationCameraSettingsContract = ^Activation_ActivationCameraSettingsContract;

  // Windows.ApplicationModel.Activation.ContactActivatedEventsContract
  Activation_ContactActivatedEventsContract = record
  end;
  PActivation_ContactActivatedEventsContract = ^Activation_ContactActivatedEventsContract;

  // Windows.ApplicationModel.Activation.WebUISearchActivatedEventsContract
  Activation_WebUISearchActivatedEventsContract = record
  end;
  PActivation_WebUISearchActivatedEventsContract = ^Activation_WebUISearchActivatedEventsContract;

  // Windows.ApplicationModel.Calls.Background.CallsBackgroundContract
  Calls_Background_CallsBackgroundContract = record
  end;
  PCalls_Background_CallsBackgroundContract = ^Calls_Background_CallsBackgroundContract;

  // Windows.ApplicationModel.Calls.CallsPhoneContract
  Calls_CallsPhoneContract = record
  end;
  PCalls_CallsPhoneContract = ^Calls_CallsPhoneContract;

  // Windows.ApplicationModel.Calls.CallsVoipContract
  Calls_CallsVoipContract = record
  end;
  PCalls_CallsVoipContract = ^Calls_CallsVoipContract;

  // Windows.ApplicationModel.Calls.LockScreenCallContract
  Calls_LockScreenCallContract = record
  end;
  PCalls_LockScreenCallContract = ^Calls_LockScreenCallContract;

  // Windows.ApplicationModel.CommunicationBlocking.CommunicationBlockingContract
  CommunicationBlocking_CommunicationBlockingContract = record
  end;
  PCommunicationBlocking_CommunicationBlockingContract = ^CommunicationBlocking_CommunicationBlockingContract;

  // Windows.ApplicationModel.FullTrustAppContract
  FullTrustAppContract = record
  end;
  PFullTrustAppContract = ^FullTrustAppContract;

  // Windows.ApplicationModel.PackageInstallProgress
  PackageInstallProgress = record
    PercentComplete: Cardinal;
  end;
  PPackageInstallProgress = ^PackageInstallProgress;

  // Windows.ApplicationModel.PackageVersion
  PackageVersion = record
    Major: Word;
    Minor: Word;
    Build: Word;
    Revision: Word;
  end;
  PPackageVersion = ^PackageVersion;

  // Windows.ApplicationModel.Preview.InkWorkspace.PreviewInkWorkspaceContract
  Preview_InkWorkspace_PreviewInkWorkspaceContract = record
  end;
  PPreview_InkWorkspace_PreviewInkWorkspaceContract = ^Preview_InkWorkspace_PreviewInkWorkspaceContract;

  // Windows.ApplicationModel.Preview.Notes.PreviewNotesContract
  Preview_Notes_PreviewNotesContract = record
  end;
  PPreview_Notes_PreviewNotesContract = ^Preview_Notes_PreviewNotesContract;

  // Windows.ApplicationModel.Resources.Core.ResourceLayoutInfo
  Resources_Core_ResourceLayoutInfo = record
    MajorVersion: Cardinal;
    MinorVersion: Cardinal;
    ResourceSubtreeCount: Cardinal;
    NamedResourceCount: Cardinal;
    Checksum: Integer;
  end;
  PResources_Core_ResourceLayoutInfo = ^Resources_Core_ResourceLayoutInfo;

  // Windows.ApplicationModel.Resources.Management.ResourceIndexerContract
  Resources_Management_ResourceIndexerContract = record
  end;
  PResources_Management_ResourceIndexerContract = ^Resources_Management_ResourceIndexerContract;

  // Windows.ApplicationModel.Search.Core.SearchCoreContract
  Search_Core_SearchCoreContract = record
  end;
  PSearch_Core_SearchCoreContract = ^Search_Core_SearchCoreContract;

  // Windows.ApplicationModel.Search.SearchContract
  Search_SearchContract = record
  end;
  PSearch_SearchContract = ^Search_SearchContract;

  // Windows.ApplicationModel.SocialInfo.SocialInfoContract
  SocialInfo_SocialInfoContract = record
  end;
  PSocialInfo_SocialInfoContract = ^SocialInfo_SocialInfoContract;

  // Windows.ApplicationModel.StartupTaskContract
  StartupTaskContract = record
  end;
  PStartupTaskContract = ^StartupTaskContract;

  // Windows.ApplicationModel.Wallet.WalletContract
  Wallet_WalletContract = record
  end;
  PWallet_WalletContract = ^Wallet_WalletContract;

  // Windows.ApplicationModel Interfaces

  // UsedAPI Interface
  // Windows.ApplicationModel.IEnteredBackgroundEventArgs
  IEnteredBackgroundEventArgs = interface(IInspectable)
  ['{F722DCC2-9827-403D-AAED-ECCA9AC17398}']
    function GetDeferral: IDeferral; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.ILaunchActivatedEventArgs
  Activation_ILaunchActivatedEventArgs = interface(IInspectable)
  ['{FBC93E26-A14A-4B4F-82B0-33BED920AF52}']
    function get_Arguments: HSTRING; safecall;
    function get_TileId: HSTRING; safecall;
    property Arguments: HSTRING read get_Arguments;
    property TileId: HSTRING read get_TileId;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.ILeavingBackgroundEventArgs
  ILeavingBackgroundEventArgs = interface(IInspectable)
  ['{39C6EC9A-AE6E-46F9-A07A-CFC23F88733E}']
    function GetDeferral: IDeferral; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.ISuspendingDeferral
  ISuspendingDeferral = interface(IInspectable)
  ['{59140509-8BC9-4EB4-B636-DABDC4F46F66}']
    procedure Complete; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.ISuspendingOperation
  ISuspendingOperation = interface(IInspectable)
  ['{9DA4CA41-20E1-4E9B-9F65-A9F435340C3A}']
    function GetDeferral: ISuspendingDeferral; safecall;
    function get_Deadline: DateTime; safecall;
    property Deadline: DateTime read get_Deadline;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.ISuspendingEventArgs
  ISuspendingEventArgs = interface(IInspectable)
  ['{96061C05-2DBA-4D08-B0BD-2B30A131C6AA}']
    function get_SuspendingOperation: ISuspendingOperation; safecall;
    property SuspendingOperation: ISuspendingOperation read get_SuspendingOperation;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageId
  IPackageId = interface(IInspectable)
  ['{1ADB665E-37C7-4790-9980-DD7AE74E8BB2}']
    function get_Name: HSTRING; safecall;
    function get_Version: PackageVersion; safecall;
    function get_Architecture: ProcessorArchitecture; safecall;
    function get_ResourceId: HSTRING; safecall;
    function get_Publisher: HSTRING; safecall;
    function get_PublisherId: HSTRING; safecall;
    function get_FullName: HSTRING; safecall;
    function get_FamilyName: HSTRING; safecall;
    property Architecture: ProcessorArchitecture read get_Architecture;
    property FamilyName: HSTRING read get_FamilyName;
    property FullName: HSTRING read get_FullName;
    property Name: HSTRING read get_Name;
    property Publisher: HSTRING read get_Publisher;
    property PublisherId: HSTRING read get_PublisherId;
    property ResourceId: HSTRING read get_ResourceId;
    property Version: PackageVersion read get_Version;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Package>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IPackage>
  IIterator_1__IPackage = interface(IInspectable)
  ['{0217F069-025C-5EE6-A87F-E782E3B623AE}']
    function get_Current: IPackage; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIPackage): Cardinal; safecall;
    property Current: IPackage read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Package>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IPackage>
  IIterable_1__IPackage = interface(IInspectable)
  ['{69AD6AA7-0C49-5F27-A5EB-EF4D59467B6D}']
    function First: IIterator_1__IPackage; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IPackage>
  IVectorView_1__IPackage = interface(IInspectable)
  ['{77191FA5-6652-5BC7-82EB-CDDF0E2F7ECD}']
    function GetAt(index: Cardinal): IPackage; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IPackage; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPackage): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage
  [WinRTClassNameAttribute(SWindows_ApplicationModel_PackageRT)]
  IPackage = interface(IInspectable)
  ['{163C792F-BD75-413C-BF23-B1FE7B95D825}']
    function get_Id: IPackageId; safecall;
    function get_InstalledLocation: IStorageFolder; safecall;
    function get_IsFramework: Boolean; safecall;
    function get_Dependencies: IVectorView_1__IPackage; safecall;
    property Dependencies: IVectorView_1__IPackage read get_Dependencies;
    property Id: IPackageId read get_Id;
    property InstalledLocation: IStorageFolder read get_InstalledLocation;
    property IsFramework: Boolean read get_IsFramework;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.ICachedFileUpdaterActivatedEventArgs
  Activation_ICachedFileUpdaterActivatedEventArgs = interface(IInspectable)
  ['{D06EB1C7-3805-4ECB-B757-6CF15E26FEF3}']
    function get_CachedFileUpdaterUI: Provider_ICachedFileUpdaterUI; safecall;
    property CachedFileUpdaterUI: Provider_ICachedFileUpdaterUI read get_CachedFileUpdaterUI;
  end;

  // Windows.ApplicationModel.Activation.IContactsProviderActivatedEventArgs
  Activation_IContactsProviderActivatedEventArgs = interface(IInspectable)
  ['{4580DCA8-5750-4916-AA52-C0829521EB94}']
    function get_Verb: HSTRING; safecall;
    property Verb: HSTRING read get_Verb;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.IFileActivatedEventArgs
  Activation_IFileActivatedEventArgs = interface(IInspectable)
  ['{BB2AFC33-93B1-42ED-8B26-236DD9C78496}']
    function get_Files: IVectorView_1__IStorageItem; safecall;
    function get_Verb: HSTRING; safecall;
    property Files: IVectorView_1__IStorageItem read get_Files;
    property Verb: HSTRING read get_Verb;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.IFileOpenPickerActivatedEventArgs
  Activation_IFileOpenPickerActivatedEventArgs = interface(IInspectable)
  ['{72827082-5525-4BF2-BC09-1F5095D4964D}']
    function get_FileOpenPickerUI: Pickers_Provider_IFileOpenPickerUI; safecall;
    property FileOpenPickerUI: Pickers_Provider_IFileOpenPickerUI read get_FileOpenPickerUI;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.IFileSavePickerActivatedEventArgs
  Activation_IFileSavePickerActivatedEventArgs = interface(IInspectable)
  ['{81C19CF1-74E6-4387-82EB-BB8FD64B4346}']
    function get_FileSavePickerUI: Pickers_Provider_IFileSavePickerUI; safecall;
    property FileSavePickerUI: Pickers_Provider_IFileSavePickerUI read get_FileSavePickerUI;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.ISearchActivatedEventArgs
  Activation_ISearchActivatedEventArgs = interface(IInspectable)
  ['{8CB36951-58C8-43E3-94BC-41D33F8B630E}']
    function get_QueryText: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    property Language: HSTRING read get_Language;
    property QueryText: HSTRING read get_QueryText;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Activation.IShareTargetActivatedEventArgs
  Activation_IShareTargetActivatedEventArgs = interface(IInspectable)
  ['{4BDAF9C8-CDB2-4ACB-BFC3-6648563378EC}']
    function get_ShareOperation: ShareTarget_IShareOperation; safecall;
    property ShareOperation: ShareTarget_IShareOperation read get_ShareOperation;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtension
  AppExtensions_IAppExtension = interface(IInspectable)
  ['{8450902C-15ED-4FAF-93EA-2237BBF8CBD6}']
    function get_Id: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    function get_AppInfo: IAppInfo; safecall;
    function GetExtensionPropertiesAsync: IAsyncOperation_1__IPropertySet; safecall;
    function GetPublicFolderAsync: IAsyncOperation_1__IStorageFolder; safecall;
    property AppInfo: IAppInfo read get_AppInfo;
    property Description: HSTRING read get_Description;
    property DisplayName: HSTRING read get_DisplayName;
    property Id: HSTRING read get_Id;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtension2
  AppExtensions_IAppExtension2 = interface(IInspectable)
  ['{AB3B15F0-14F9-4B9F-9419-A349A242EF38}']
    function get_AppUserModelId: HSTRING; safecall;
    property AppUserModelId: HSTRING read get_AppUserModelId;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtension3
  AppExtensions_IAppExtension3 = interface(IInspectable)
  ['{5923C101-AA38-4009-84D9-5B54A0DF30AE}']
    function GetExtensionProperties: IPropertySet; safecall;
    function GetPublicPath: HSTRING; safecall;
    function GetPublicFolder: IStorageFolder; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.AppExtensions.AppExtension>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IIterator_1__AppExtensions_IAppExtension = interface(IInspectable)
  ['{8E80CA83-3CD3-5F9C-83E4-84347CA5498C}']
    function get_Current: AppExtensions_IAppExtension; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PAppExtensions_IAppExtension): Cardinal; safecall;
    property Current: AppExtensions_IAppExtension read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.AppExtensions.AppExtension>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IIterable_1__AppExtensions_IAppExtension = interface(IInspectable)
  ['{3B4FE356-1B13-59CB-AB1F-C4667A74756B}']
    function First: IIterator_1__AppExtensions_IAppExtension; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>
  IVectorView_1__AppExtensions_IAppExtension = interface(IInspectable)
  ['{5F917E50-6D70-56D4-BE5F-AFD72E2799D5}']
    function GetAt(index: Cardinal): AppExtensions_IAppExtension; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: AppExtensions_IAppExtension; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PAppExtensions_IAppExtension): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.AppExtension>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>>
  AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension = interface(IUnknown)
  ['{CBD3EA3B-1275-5688-8610-0AB1F83442FC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__AppExtensions_IAppExtension; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.AppExtension>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppExtensions.IAppExtension>>
  IAsyncOperation_1__IVectorView_1__AppExtensions_IAppExtension = interface(IInspectable)
  ['{83295BB9-10DF-530F-A0D7-BE05BA80CB18}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension; safecall;
    function GetResults: IVectorView_1__AppExtensions_IAppExtension; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__AppExtensions_IAppExtension read get_Completed write put_Completed;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageInstalledEventArgs
  AppExtensions_IAppExtensionPackageInstalledEventArgs = interface(IInspectable)
  ['{39E59234-3351-4A8D-9745-E7D3DD45BC48}']
    function get_AppExtensionName: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    function get_Extensions: IVectorView_1__AppExtensions_IAppExtension; safecall;
    property AppExtensionName: HSTRING read get_AppExtensionName;
    property Extensions: IVectorView_1__AppExtensions_IAppExtension read get_Extensions;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUpdatingEventArgs
  AppExtensions_IAppExtensionPackageUpdatingEventArgs = interface(IInspectable)
  ['{7ED59329-1A65-4800-A700-B321009E306A}']
    function get_AppExtensionName: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    property AppExtensionName: HSTRING read get_AppExtensionName;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUpdatedEventArgs
  AppExtensions_IAppExtensionPackageUpdatedEventArgs = interface(IInspectable)
  ['{3A83C43F-797E-44B5-BA24-A4C8B5A543D7}']
    function get_AppExtensionName: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    function get_Extensions: IVectorView_1__AppExtensions_IAppExtension; safecall;
    property AppExtensionName: HSTRING read get_AppExtensionName;
    property Extensions: IVectorView_1__AppExtensions_IAppExtension read get_Extensions;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageUninstallingEventArgs
  AppExtensions_IAppExtensionPackageUninstallingEventArgs = interface(IInspectable)
  ['{60F160C5-171E-40FF-AE98-AB2C20DD4D75}']
    function get_AppExtensionName: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    property AppExtensionName: HSTRING read get_AppExtensionName;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.AppExtensions.IAppExtensionPackageStatusChangedEventArgs
  AppExtensions_IAppExtensionPackageStatusChangedEventArgs = interface(IInspectable)
  ['{1CE17433-1153-44FD-87B1-8AE1050303DF}']
    function get_AppExtensionName: HSTRING; safecall;
    function get_Package: IPackage; safecall;
    property AppExtensionName: HSTRING read get_AppExtensionName;
    property Package: IPackage read get_Package;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.AppInfo>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IAppInfo>
  IIterator_1__IAppInfo = interface(IInspectable)
  ['{69CEC62C-41EB-5D69-A475-29EE22323DD8}']
    function get_Current: IAppInfo; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIAppInfo): Cardinal; safecall;
    property Current: IAppInfo read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.AppInfo>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IAppInfo>
  IIterable_1__IAppInfo = interface(IInspectable)
  ['{63D0BFFE-0E34-55B3-83D5-314CAFF2B137}']
    function First: IIterator_1__IAppInfo; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>
  IVectorView_1__IAppInfo = interface(IInspectable)
  ['{A7320DC1-90CE-5568-98B9-707AC47E5C33}']
    function GetAt(index: Cardinal): IAppInfo; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IAppInfo; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIAppInfo): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppInfo>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo = interface(IUnknown)
  ['{07F25B6F-F054-5649-A5CE-B348DDC618B6}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IAppInfo; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.AppInfo>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IAppInfo>>
  IAsyncOperation_1__IVectorView_1__IAppInfo = interface(IInspectable)
  ['{07543D91-8610-5152-B0E4-43D6E4CDD0CB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo; safecall;
    function GetResults: IVectorView_1__IAppInfo; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IAppInfo read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceClosedEventArgs
  AppService_IAppServiceClosedEventArgs = interface(IInspectable)
  ['{DE6016F6-CB03-4D35-AC8D-CC6303239731}']
    function get_Status: AppService_AppServiceClosedStatus; safecall;
    property Status: AppService_AppServiceClosedStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.AppServiceConnectionStatus>
  AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus = interface(IUnknown)
  ['{B6C6BBF2-72CA-5799-A651-D1990670097B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__AppService_AppServiceConnectionStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.AppServiceConnectionStatus>
  IAsyncOperation_1__AppService_AppServiceConnectionStatus = interface(IInspectable)
  ['{0D0E6663-2639-5A9A-9CBC-30D7D4CE533B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus; safecall;
    function GetResults: AppService_AppServiceConnectionStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__AppService_AppServiceConnectionStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceResponse
  AppService_IAppServiceResponse = interface(IInspectable)
  ['{8D503CEC-9AA3-4E68-9559-9DE63E372CE4}']
    function get_Message: IPropertySet; safecall;
    function get_Status: AppService_AppServiceResponseStatus; safecall;
    property &Message: IPropertySet read get_Message;
    property Status: AppService_AppServiceResponseStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.AppServiceResponse>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.IAppServiceResponse>
  AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse = interface(IUnknown)
  ['{7EA7D7EC-E164-52C3-8E32-BBA7126D9028}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__AppService_IAppServiceResponse; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.AppServiceResponse>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.IAppServiceResponse>
  IAsyncOperation_1__AppService_IAppServiceResponse = interface(IInspectable)
  ['{48755A7C-C88F-5EF0-9B4C-876FCC2610B4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse; safecall;
    function GetResults: AppService_IAppServiceResponse; safecall;
    property Completed: AsyncOperationCompletedHandler_1__AppService_IAppServiceResponse read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.AppServiceResponseStatus>
  AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus = interface(IUnknown)
  ['{B824383D-32E0-5579-8670-A06A61457F20}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__AppService_AppServiceResponseStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.AppServiceResponseStatus>
  IAsyncOperation_1__AppService_AppServiceResponseStatus = interface(IInspectable)
  ['{98FDB842-5A0B-539A-A35C-55AC5F228612}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus; safecall;
    function GetResults: AppService_AppServiceResponseStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__AppService_AppServiceResponseStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceRequest
  AppService_IAppServiceRequest = interface(IInspectable)
  ['{20E58D9D-18DE-4B01-80BA-90A76204E3C8}']
    function get_Message: IPropertySet; safecall;
    function SendResponseAsync(&message: IPropertySet): IAsyncOperation_1__AppService_AppServiceResponseStatus; safecall;
    property &Message: IPropertySet read get_Message;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceDeferral
  AppService_IAppServiceDeferral = interface(IInspectable)
  ['{7E1B5322-EAB0-4248-AE04-FDF93838E472}']
    procedure Complete; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceRequestReceivedEventArgs
  AppService_IAppServiceRequestReceivedEventArgs = interface(IInspectable)
  ['{6E122360-FF65-44AE-9E45-857FE4180681}']
    function get_Request: AppService_IAppServiceRequest; safecall;
    function GetDeferral: AppService_IAppServiceDeferral; safecall;
    property Request: AppService_IAppServiceRequest read get_Request;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.AppServiceConnection,Windows.ApplicationModel.AppService.AppServiceRequestReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.IAppServiceConnection,Windows.ApplicationModel.AppService.IAppServiceRequestReceivedEventArgs>
  TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceRequestReceivedEventArgs = interface(IUnknown)
  ['{18C67D61-4176-5553-B18D-D8F57FE79552}']
    procedure Invoke(sender: AppService_IAppServiceConnection; args: AppService_IAppServiceRequestReceivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.AppServiceConnection,Windows.ApplicationModel.AppService.AppServiceClosedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.AppService.IAppServiceConnection,Windows.ApplicationModel.AppService.IAppServiceClosedEventArgs>
  TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceClosedEventArgs = interface(IUnknown)
  ['{E4EFA98D-4BFC-5E61-A233-688F5F06521F}']
    procedure Invoke(sender: AppService_IAppServiceConnection; args: AppService_IAppServiceClosedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceConnection
  [WinRTClassNameAttribute(SWindows_ApplicationModel_AppService_AppServiceConnection)]
  AppService_IAppServiceConnection = interface(IInspectable)
  ['{9DD474A2-871F-4D52-89A9-9E090531BD27}']
    function get_AppServiceName: HSTRING; safecall;
    procedure put_AppServiceName(value: HSTRING); safecall;
    function get_PackageFamilyName: HSTRING; safecall;
    procedure put_PackageFamilyName(value: HSTRING); safecall;
    function OpenAsync: IAsyncOperation_1__AppService_AppServiceConnectionStatus; safecall;
    function SendMessageAsync(&message: IPropertySet): IAsyncOperation_1__AppService_IAppServiceResponse; safecall;
    function add_RequestReceived(handler: TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceRequestReceivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_RequestReceived(token: EventRegistrationToken); safecall;
    function add_ServiceClosed(handler: TypedEventHandler_2__AppService_IAppServiceConnection__AppService_IAppServiceClosedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ServiceClosed(token: EventRegistrationToken); safecall;
    property AppServiceName: HSTRING read get_AppServiceName write put_AppServiceName;
    property PackageFamilyName: HSTRING read get_PackageFamilyName write put_PackageFamilyName;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceConnection2
  AppService_IAppServiceConnection2 = interface(IInspectable)
  ['{8BDFCD5F-2302-4FBD-8061-52511C2F8BF9}']
    function OpenRemoteAsync(remoteSystemConnectionRequest: RemoteSystems_IRemoteSystemConnectionRequest): IAsyncOperation_1__AppService_AppServiceConnectionStatus; safecall;
    function get_User: IUser; safecall;
    procedure put_User(value: IUser); safecall;
    property User: IUser read get_User write put_User;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IStatelessAppServiceResponse
  AppService_IStatelessAppServiceResponse = interface(IInspectable)
  ['{43754AF7-A9EC-52FE-82E7-939B68DC9388}']
    function get_Message: IPropertySet; safecall;
    function get_Status: AppService_StatelessAppServiceResponseStatus; safecall;
    property &Message: IPropertySet read get_Message;
    property Status: AppService_StatelessAppServiceResponseStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.StatelessAppServiceResponse>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.AppService.IStatelessAppServiceResponse>
  AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse = interface(IUnknown)
  ['{4D1EE4ED-4D79-53FA-A9D7-C9C9354E4F55}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__AppService_IStatelessAppServiceResponse; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.StatelessAppServiceResponse>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.AppService.IStatelessAppServiceResponse>
  IAsyncOperation_1__AppService_IStatelessAppServiceResponse = interface(IInspectable)
  ['{B2A1524E-BEAB-5BEB-AAE9-B43501C3A488}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse; safecall;
    function GetResults: AppService_IStatelessAppServiceResponse; safecall;
    property Completed: AsyncOperationCompletedHandler_1__AppService_IStatelessAppServiceResponse read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.AppService.IAppServiceConnectionStatics
  [WinRTClassNameAttribute(SWindows_ApplicationModel_AppService_AppServiceConnection)]
  AppService_IAppServiceConnectionStatics = interface(IInspectable)
  ['{ADC56CE9-D408-5673-8637-827A4B274168}']
    function SendStatelessMessageAsync(connection: AppService_IAppServiceConnection; connectionRequest: RemoteSystems_IRemoteSystemConnectionRequest; &message: IPropertySet): IAsyncOperation_1__AppService_IStatelessAppServiceResponse; safecall;
  end;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails
  AppService_IAppServiceTriggerDetails = interface(IInspectable)
  ['{88A2DCAC-AD28-41B8-80BB-BDF1B2169E19}']
    function get_Name: HSTRING; safecall;
    function get_CallerPackageFamilyName: HSTRING; safecall;
    function get_AppServiceConnection: AppService_IAppServiceConnection; safecall;
    property AppServiceConnection: AppService_IAppServiceConnection read get_AppServiceConnection;
    property CallerPackageFamilyName: HSTRING read get_CallerPackageFamilyName;
    property Name: HSTRING read get_Name;
  end;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails2
  AppService_IAppServiceTriggerDetails2 = interface(IInspectable)
  ['{E83D54B2-28CC-43F2-B465-C0482E59E2DC}']
    function get_IsRemoteSystemConnection: Boolean; safecall;
    property IsRemoteSystemConnection: Boolean read get_IsRemoteSystemConnection;
  end;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails3
  AppService_IAppServiceTriggerDetails3 = interface(IInspectable)
  ['{FBD71E21-7939-4E68-9E3C-7780147AABB6}']
    function CheckCallerForCapabilityAsync(capabilityName: HSTRING): IAsyncOperation_1__Boolean; safecall;
  end;

  // Windows.ApplicationModel.AppService.IAppServiceTriggerDetails4
  AppService_IAppServiceTriggerDetails4 = interface(IInspectable)
  ['{1185B180-8861-5E30-AB55-1CF4D08BBF6D}']
    function get_CallerRemoteConnectionToken: HSTRING; safecall;
    property CallerRemoteConnectionToken: HSTRING read get_CallerRemoteConnectionToken;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Calls.PhoneCallOperationStatus>
  AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus = interface(IUnknown)
  ['{6E80AE96-2731-51F9-8375-53E6C5E2AD8A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Calls_PhoneCallOperationStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Calls.PhoneCallOperationStatus>
  IAsyncOperation_1__Calls_PhoneCallOperationStatus = interface(IInspectable)
  ['{286DF3A1-2F43-5B7A-984F-66B8A43B9876}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus; safecall;
    function GetResults: Calls_PhoneCallOperationStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Calls_PhoneCallOperationStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Calls.VoipPhoneCallResourceReservationStatus>
  AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus = interface(IUnknown)
  ['{7A27B20F-647A-53FC-80F0-A79D083CE531}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Calls_VoipPhoneCallResourceReservationStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Calls.VoipPhoneCallResourceReservationStatus>
  IAsyncOperation_1__Calls_VoipPhoneCallResourceReservationStatus = interface(IInspectable)
  ['{8528BE80-7CE9-5668-8E48-469AE5BA9EAD}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus; safecall;
    function GetResults: Calls_VoipPhoneCallResourceReservationStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Calls_VoipPhoneCallResourceReservationStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>
  IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface(IInspectable)
  ['{4F426A27-6D23-58B6-9F29-4F88ED274BCD}']
    function get_Key: HSTRING; safecall;
    function get_Value: Chat_ChatMessageStatus; safecall;
    property Key: HSTRING read get_Key;
    property Value: Chat_ChatMessageStatus read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>>
  IIterator_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface(IInspectable)
  ['{5B099E05-07E2-5346-B075-F4297B3E308B}']
    function get_Current: IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__Chat_ChatMessageStatus): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>>
  IIterable_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus = interface(IInspectable)
  ['{57D87C13-48E9-546F-9B4E-A3906E1E7C24}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__Chat_ChatMessageStatus; safecall;
  end;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.ApplicationModel.Chat.ChatMessageStatus>
  IMapView_2__HSTRING__Chat_ChatMessageStatus = interface(IInspectable)
  ['{6A44FF0F-A172-5285-9BA5-B9FDD699A0FE}']
    function Lookup(key: HSTRING): Chat_ChatMessageStatus; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__Chat_ChatMessageStatus; out second: IMapView_2__HSTRING__Chat_ChatMessageStatus); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationTrainingStatus>
  AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus = interface(IUnknown)
  ['{6C131B87-097F-5965-84D5-964C52B1787E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_DetectionConfigurationTrainingStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.DetectionConfigurationTrainingStatus>
  IAsyncOperation_1__ConversationalAgent_DetectionConfigurationTrainingStatus = interface(IInspectable)
  ['{7631A007-93A6-554E-BCDD-3BAEE7C8C2C6}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus; safecall;
    function GetResults: ConversationalAgent_DetectionConfigurationTrainingStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_DetectionConfigurationTrainingStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationSetModelDataResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = interface(IUnknown)
  ['{C3982503-9AE9-582E-9874-33EA36649A3C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationSetModelDataResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult = interface(IInspectable)
  ['{3738E73C-E4CD-55AD-B760-07AF8B4A29D3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult; safecall;
    function GetResults: ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationSetModelDataResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationStateChangeResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = interface(IUnknown)
  ['{4AA91BFB-908E-52BA-A23D-06F464B5B54A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationStateChangeResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult = interface(IInspectable)
  ['{BE03CC1F-0A8A-5878-A84E-AF4646DF3CC5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult; safecall;
    function GetResults: ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationStateChangeResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IIterator_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface(IInspectable)
  ['{1F6EF295-4D31-5874-A22D-29875EE8165C}']
    function get_Current: ConversationalAgent_ActivationSignalDetectionTrainingDataFormat; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PConversationalAgent_ActivationSignalDetectionTrainingDataFormat): Cardinal; safecall;
    property Current: ConversationalAgent_ActivationSignalDetectionTrainingDataFormat read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IIterable_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface(IInspectable)
  ['{88B67E2C-EC3F-520C-AE65-BFE63272FADD}']
    function First: IIterator_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionTrainingDataFormat>
  IVectorView_1__ConversationalAgent_ActivationSignalDetectionTrainingDataFormat = interface(IInspectable)
  ['{679189C6-73C4-5295-8B04-6CE05CAB4D17}']
    function GetAt(index: Cardinal): ConversationalAgent_ActivationSignalDetectionTrainingDataFormat; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ConversationalAgent_ActivationSignalDetectionTrainingDataFormat; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PConversationalAgent_ActivationSignalDetectionTrainingDataFormat): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IIterator_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface(IInspectable)
  ['{F5DAAC9C-92CF-5945-9C5B-1C0B8EAC8143}']
    function get_Current: ConversationalAgent_ActivationSignalDetectorPowerState; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PConversationalAgent_ActivationSignalDetectorPowerState): Cardinal; safecall;
    property Current: ConversationalAgent_ActivationSignalDetectorPowerState read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IIterable_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface(IInspectable)
  ['{B6860D48-CEC5-5A00-8653-4C924A991575}']
    function First: IIterator_1__ConversationalAgent_ActivationSignalDetectorPowerState; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectorPowerState>
  IVectorView_1__ConversationalAgent_ActivationSignalDetectorPowerState = interface(IInspectable)
  ['{C303FD7F-D073-54C3-8411-C118226323AC}']
    function GetAt(index: Cardinal): ConversationalAgent_ActivationSignalDetectorPowerState; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ConversationalAgent_ActivationSignalDetectorPowerState; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PConversationalAgent_ActivationSignalDetectorPowerState): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationRemovalResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = interface(IUnknown)
  ['{DF53D38D-347F-587D-B115-BE893A8D7C49}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ActivationSignalDetectionConfigurationRemovalResult>
  IAsyncOperation_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult = interface(IInspectable)
  ['{312794CB-0E43-5CBF-A148-58A9D7A65C14}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult; safecall;
    function GetResults: ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ActivationSignalDetectionConfigurationRemovalResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSessionUpdateResponse>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = interface(IUnknown)
  ['{6F43477A-01C5-59E2-96E2-1D9A00409159}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentSessionUpdateResponse>
  IAsyncOperation_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse = interface(IInspectable)
  ['{4B85887B-8070-5EF9-AAC8-92515257061E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse; safecall;
    function GetResults: ConversationalAgent_ConversationalAgentSessionUpdateResponse; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentSessionUpdateResponse read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationResult>
  AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult = interface(IUnknown)
  ['{41948CE0-5D83-5E12-A8BA-114C4A3A62E3}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ConversationalAgent_ConversationalAgentActivationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentActivationResult>
  IAsyncOperation_1__ConversationalAgent_ConversationalAgentActivationResult = interface(IInspectable)
  ['{D177B8F3-D984-5C78-A57F-F096E291B374}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult; safecall;
    function GetResults: ConversationalAgent_ConversationalAgentActivationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ConversationalAgent_ConversationalAgentActivationResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IIterator_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface(IInspectable)
  ['{89B54546-B694-5277-866B-7F2FC740C640}']
    function get_Current: ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind): Cardinal; safecall;
    property Current: ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IIterable_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface(IInspectable)
  ['{4E9BB4C0-65AB-5049-9336-918B6D359071}']
    function First: IIterator_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>
  IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface(IInspectable)
  ['{82216C11-1E7A-592C-9A3D-15D63E6FDD19}']
    function GetAt(index: Cardinal): ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>>
  AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface(IUnknown)
  ['{80BBBE11-F1C5-5A42-B20B-005A57F88011}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.ConversationalAgentVoiceActivationPrerequisiteKind>>
  IAsyncOperation_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind = interface(IInspectable)
  ['{C192099D-C28A-550A-8C2B-E31C8FABCB4B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; safecall;
    function GetResults: IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__ConversationalAgent_ConversationalAgentVoiceActivationPrerequisiteKind read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IIterator_1__ConversationalAgent_SignalDetectorResourceKind = interface(IInspectable)
  ['{A27176EC-AB9A-5A55-8E50-AD4DAB5B5D68}']
    function get_Current: ConversationalAgent_SignalDetectorResourceKind; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PConversationalAgent_SignalDetectorResourceKind): Cardinal; safecall;
    property Current: ConversationalAgent_SignalDetectorResourceKind read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IIterable_1__ConversationalAgent_SignalDetectorResourceKind = interface(IInspectable)
  ['{263E7B6E-5338-5871-9FDB-A27D9BC02E92}']
    function First: IIterator_1__ConversationalAgent_SignalDetectorResourceKind; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.ConversationalAgent.SignalDetectorResourceKind>
  IVectorView_1__ConversationalAgent_SignalDetectorResourceKind = interface(IInspectable)
  ['{A847AC9B-A9AE-55C5-811D-920122E361D6}']
    function GetAt(index: Cardinal): ConversationalAgent_SignalDetectorResourceKind; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ConversationalAgent_SignalDetectorResourceKind; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PConversationalAgent_SignalDetectorResourceKind): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.SuspendingEventArgs>
  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.ISuspendingEventArgs>
  EventHandler_1__ISuspendingEventArgs = interface(IUnknown)
  ['{338579BF-1A35-5CC4-A622-A6F384FD892C}']
    procedure Invoke(sender: IInspectable; args: ISuspendingEventArgs); safecall;
  end;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.Activation.BackgroundActivatedEventArgs>
  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.Activation.IBackgroundActivatedEventArgs>
  EventHandler_1__Activation_IBackgroundActivatedEventArgs = interface(IUnknown)
  ['{49A07732-E7B8-5C5B-9DE7-22E33CB97004}']
    procedure Invoke(sender: IInspectable; args: Activation_IBackgroundActivatedEventArgs); safecall;
  end;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.LeavingBackgroundEventArgs>
  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.ILeavingBackgroundEventArgs>
  EventHandler_1__ILeavingBackgroundEventArgs = interface(IUnknown)
  ['{9B6171C2-ABB2-5194-AFC0-CEF167C424EB}']
    procedure Invoke(sender: IInspectable; args: ILeavingBackgroundEventArgs); safecall;
  end;

  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.EnteredBackgroundEventArgs>
  // Windows.Foundation.EventHandler`1<Windows.ApplicationModel.IEnteredBackgroundEventArgs>
  EventHandler_1__IEnteredBackgroundEventArgs = interface(IUnknown)
  ['{E0739C32-FC14-5361-A8B3-0809699FBCBD}']
    procedure Invoke(sender: IInspectable; args: IEnteredBackgroundEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IIterator_1__Email_EmailCertificateValidationStatus = interface(IInspectable)
  ['{1CFE3D41-16A5-5026-A6FE-2CB0A303A605}']
    function get_Current: Email_EmailCertificateValidationStatus; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PEmail_EmailCertificateValidationStatus): Cardinal; safecall;
    property Current: Email_EmailCertificateValidationStatus read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IIterable_1__Email_EmailCertificateValidationStatus = interface(IInspectable)
  ['{7E326530-7449-51A7-B1BC-C43533A78E06}']
    function First: IIterator_1__Email_EmailCertificateValidationStatus; safecall;
  end;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.Email.EmailMailboxSmimeEncryptionAlgorithm>
  IReference_1__Email_EmailMailboxSmimeEncryptionAlgorithm = interface(IInspectable)
  ['{433B124D-60E6-5B7A-96BC-8681DE5F5E75}']
    function get_Value: Email_EmailMailboxSmimeEncryptionAlgorithm; safecall;
    property Value: Email_EmailMailboxSmimeEncryptionAlgorithm read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.Email.EmailMailboxSmimeSigningAlgorithm>
  IReference_1__Email_EmailMailboxSmimeSigningAlgorithm = interface(IInspectable)
  ['{E498A622-F168-5104-A53B-FAF996F51632}']
    function get_Value: Email_EmailMailboxSmimeSigningAlgorithm; safecall;
    property Value: Email_EmailMailboxSmimeSigningAlgorithm read get_Value;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>
  IVectorView_1__Email_EmailCertificateValidationStatus = interface(IInspectable)
  ['{A5665FF7-B44E-57E3-BD7A-EF191AA5519C}']
    function GetAt(index: Cardinal): Email_EmailCertificateValidationStatus; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Email_EmailCertificateValidationStatus; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PEmail_EmailCertificateValidationStatus): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus = interface(IUnknown)
  ['{7DB1B498-0944-5B7F-8653-45D0D35DDFF1}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Email_EmailCertificateValidationStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Email.EmailCertificateValidationStatus>>
  IAsyncOperation_1__IVectorView_1__Email_EmailCertificateValidationStatus = interface(IInspectable)
  ['{F3E7EF5B-8894-5488-97EF-029CA4913947}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus; safecall;
    function GetResults: IVectorView_1__Email_EmailCertificateValidationStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Email_EmailCertificateValidationStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Email.EmailMailboxEmptyFolderStatus>
  AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus = interface(IUnknown)
  ['{50333005-DAED-567E-BB88-B1BC4663B075}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Email_EmailMailboxEmptyFolderStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Email.EmailMailboxEmptyFolderStatus>
  IAsyncOperation_1__Email_EmailMailboxEmptyFolderStatus = interface(IInspectable)
  ['{0033A74E-9BAA-5F50-8D6E-238635E6FDD3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus; safecall;
    function GetResults: Email_EmailMailboxEmptyFolderStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Email_EmailMailboxEmptyFolderStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Email.EmailMailboxDeleteFolderStatus>
  AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus = interface(IUnknown)
  ['{52604DA6-485B-5445-8E6F-64CC13056045}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Email_EmailMailboxDeleteFolderStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Email.EmailMailboxDeleteFolderStatus>
  IAsyncOperation_1__Email_EmailMailboxDeleteFolderStatus = interface(IInspectable)
  ['{6860F87F-0297-5ADF-AA16-9F1F08E2D950}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus; safecall;
    function GetResults: Email_EmailMailboxDeleteFolderStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Email_EmailMailboxDeleteFolderStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundResult>
  AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = interface(IUnknown)
  ['{07E1DC01-18BA-596A-B745-79F9CDE44CCC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ExtendedExecution.Foreground.ExtendedExecutionForegroundResult>
  IAsyncOperation_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult = interface(IInspectable)
  ['{B18EA00F-8C20-5AC2-9246-3EF405271F1A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult; safecall;
    function GetResults: ExtendedExecution_Foreground_ExtendedExecutionForegroundResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ExtendedExecution_Foreground_ExtendedExecutionForegroundResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult>
  AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult = interface(IUnknown)
  ['{873C5C7A-C638-5A33-9B03-215C72471663}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ExtendedExecution_ExtendedExecutionResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.ExtendedExecution.ExtendedExecutionResult>
  IAsyncOperation_1__ExtendedExecution_ExtendedExecutionResult = interface(IInspectable)
  ['{1DBB1BC9-6CD7-5947-8CD1-29632B5AA950}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult; safecall;
    function GetResults: ExtendedExecution_ExtendedExecutionResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ExtendedExecution_ExtendedExecutionResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IAppInfo2
  IAppInfo2 = interface(IInspectable)
  ['{BE4B1F5A-2098-431B-BD25-B30878748D47}']
    function get_Package: IPackage; safecall;
    property Package: IPackage read get_Package;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IAppInfo3
  IAppInfo3 = interface(IInspectable)
  ['{09A78E46-93A4-46DE-9397-0843B57115EA}']
    function get_ExecutionContext: AppExecutionContext; safecall;
    property ExecutionContext: AppExecutionContext read get_ExecutionContext;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IAppInfo4
  IAppInfo4 = interface(IInspectable)
  ['{2F34BDEB-1609-4554-9F33-12E1E803E0D4}']
    function get_SupportedFileExtensions(resultSize: Cardinal; resultValue: PHSTRING): HRESULT; stdcall;
    // property SupportedFileExtensions: PHSTRING read get_SupportedFileExtensions;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IAppInfoStatics
  [WinRTClassNameAttribute(SWindows_ApplicationModel_AppInfo)]
  IAppInfoStatics = interface(IInspectable)
  ['{CF1F782A-E48B-4F0C-9B0B-79C3F8957DD7}']
    function get_Current: IAppInfo; safecall;
    function GetFromAppUserModelId(appUserModelId: HSTRING): IAppInfo; safecall;
    function GetFromAppUserModelIdForUser(user: IUser; appUserModelId: HSTRING): IAppInfo; safecall;
    property Current: IAppInfo read get_Current;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IAppInstallerInfo
  IAppInstallerInfo = interface(IInspectable)
  ['{29AB2AC0-D4F6-42A3-ADCD-D6583C659508}']
    function get_Uri: IUriRuntimeClass; safecall;
    property Uri: IUriRuntimeClass read get_Uri;
  end;

  // Windows.ApplicationModel.IAppInstallerInfo2
  IAppInstallerInfo2 = interface(IInspectable)
  ['{D20F1388-8256-597C-8511-C84EC50D5E2B}']
    function get_OnLaunch: Boolean; safecall;
    function get_HoursBetweenUpdateChecks: Cardinal; safecall;
    function get_ShowPrompt: Boolean; safecall;
    function get_UpdateBlocksActivation: Boolean; safecall;
    function get_AutomaticBackgroundTask: Boolean; safecall;
    function get_ForceUpdateFromAnyVersion: Boolean; safecall;
    function get_IsAutoRepairEnabled: Boolean; safecall;
    function get_Version: PackageVersion; safecall;
    function get_LastChecked: DateTime; safecall;
    function get_PausedUntil: IReference_1__DateTime; safecall;
    function get_UpdateUris: IVectorView_1__IUriRuntimeClass; safecall;
    function get_RepairUris: IVectorView_1__IUriRuntimeClass; safecall;
    function get_DependencyPackageUris: IVectorView_1__IUriRuntimeClass; safecall;
    function get_OptionalPackageUris: IVectorView_1__IUriRuntimeClass; safecall;
    function get_PolicySource: AppInstallerPolicySource; safecall;
    property AutomaticBackgroundTask: Boolean read get_AutomaticBackgroundTask;
    property DependencyPackageUris: IVectorView_1__IUriRuntimeClass read get_DependencyPackageUris;
    property ForceUpdateFromAnyVersion: Boolean read get_ForceUpdateFromAnyVersion;
    property HoursBetweenUpdateChecks: Cardinal read get_HoursBetweenUpdateChecks;
    property IsAutoRepairEnabled: Boolean read get_IsAutoRepairEnabled;
    property LastChecked: DateTime read get_LastChecked;
    property OnLaunch: Boolean read get_OnLaunch;
    property OptionalPackageUris: IVectorView_1__IUriRuntimeClass read get_OptionalPackageUris;
    property PausedUntil: IReference_1__DateTime read get_PausedUntil;
    property PolicySource: AppInstallerPolicySource read get_PolicySource;
    property RepairUris: IVectorView_1__IUriRuntimeClass read get_RepairUris;
    property ShowPrompt: Boolean read get_ShowPrompt;
    property UpdateBlocksActivation: Boolean read get_UpdateBlocksActivation;
    property UpdateUris: IVectorView_1__IUriRuntimeClass read get_UpdateUris;
    property Version: PackageVersion read get_Version;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IFindRelatedPackagesOptions
  IFindRelatedPackagesOptions = interface(IInspectable)
  ['{41DD7EEA-B335-521F-B96C-5EA07F5B7329}']
    function get_Relationship: PackageRelationship; safecall;
    procedure put_Relationship(value: PackageRelationship); safecall;
    function get_IncludeFrameworks: Boolean; safecall;
    procedure put_IncludeFrameworks(value: Boolean); safecall;
    function get_IncludeHostRuntimes: Boolean; safecall;
    procedure put_IncludeHostRuntimes(value: Boolean); safecall;
    function get_IncludeOptionals: Boolean; safecall;
    procedure put_IncludeOptionals(value: Boolean); safecall;
    function get_IncludeResources: Boolean; safecall;
    procedure put_IncludeResources(value: Boolean); safecall;
    property IncludeFrameworks: Boolean read get_IncludeFrameworks write put_IncludeFrameworks;
    property IncludeHostRuntimes: Boolean read get_IncludeHostRuntimes write put_IncludeHostRuntimes;
    property IncludeOptionals: Boolean read get_IncludeOptionals write put_IncludeOptionals;
    property IncludeResources: Boolean read get_IncludeResources write put_IncludeResources;
    property Relationship: PackageRelationship read get_Relationship write put_Relationship;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage2
  IPackage2 = interface(IInspectable)
  ['{A6612FB6-7688-4ACE-95FB-359538E7AA01}']
    function get_DisplayName: HSTRING; safecall;
    function get_PublisherDisplayName: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_Logo: IUriRuntimeClass; safecall;
    function get_IsResourcePackage: Boolean; safecall;
    function get_IsBundle: Boolean; safecall;
    function get_IsDevelopmentMode: Boolean; safecall;
    property Description: HSTRING read get_Description;
    property DisplayName: HSTRING read get_DisplayName;
    property IsBundle: Boolean read get_IsBundle;
    property IsDevelopmentMode: Boolean read get_IsDevelopmentMode;
    property IsResourcePackage: Boolean read get_IsResourcePackage;
    property Logo: IUriRuntimeClass read get_Logo;
    property PublisherDisplayName: HSTRING read get_PublisherDisplayName;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageStatus
  IPackageStatus = interface(IInspectable)
  ['{5FE74F71-A365-4C09-A02D-046D525EA1DA}']
    function VerifyIsOK: Boolean; safecall;
    function get_NotAvailable: Boolean; safecall;
    function get_PackageOffline: Boolean; safecall;
    function get_DataOffline: Boolean; safecall;
    function get_Disabled: Boolean; safecall;
    function get_NeedsRemediation: Boolean; safecall;
    function get_LicenseIssue: Boolean; safecall;
    function get_Modified: Boolean; safecall;
    function get_Tampered: Boolean; safecall;
    function get_DependencyIssue: Boolean; safecall;
    function get_Servicing: Boolean; safecall;
    function get_DeploymentInProgress: Boolean; safecall;
    property DataOffline: Boolean read get_DataOffline;
    property DependencyIssue: Boolean read get_DependencyIssue;
    property DeploymentInProgress: Boolean read get_DeploymentInProgress;
    property Disabled: Boolean read get_Disabled;
    property LicenseIssue: Boolean read get_LicenseIssue;
    property Modified: Boolean read get_Modified;
    property NeedsRemediation: Boolean read get_NeedsRemediation;
    property NotAvailable: Boolean read get_NotAvailable;
    property PackageOffline: Boolean read get_PackageOffline;
    property Servicing: Boolean read get_Servicing;
    property Tampered: Boolean read get_Tampered;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage3
  IPackage3 = interface(IInspectable)
  ['{5F738B61-F86A-4917-93D1-F1EE9D3B35D9}']
    function get_Status: IPackageStatus; safecall;
    function get_InstalledDate: DateTime; safecall;
    function GetAppListEntriesAsync: IAsyncOperation_1__IVectorView_1__IAppListEntry; safecall;
    property InstalledDate: DateTime read get_InstalledDate;
    property Status: IPackageStatus read get_Status;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage4
  IPackage4 = interface(IInspectable)
  ['{65AED1AE-B95B-450C-882B-6255187F397E}']
    function get_SignatureKind: PackageSignatureKind; safecall;
    function get_IsOptional: Boolean; safecall;
    function VerifyContentIntegrityAsync: IAsyncOperation_1__Boolean; safecall;
    property IsOptional: Boolean read get_IsOptional;
    property SignatureKind: PackageSignatureKind read get_SignatureKind;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageContentGroup
  IPackageContentGroup = interface(IInspectable)
  ['{8F62695D-120A-4798-B5E1-5800DDA8F2E1}']
    function get_Package: IPackage; safecall;
    function get_Name: HSTRING; safecall;
    function get_State: PackageContentGroupState; safecall;
    function get_IsRequired: Boolean; safecall;
    property IsRequired: Boolean read get_IsRequired;
    property Name: HSTRING read get_Name;
    property Package: IPackage read get_Package;
    property State: PackageContentGroupState read get_State;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.PackageContentGroup>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.IPackageContentGroup>
  IIterator_1__IPackageContentGroup = interface(IInspectable)
  ['{5F23D323-28F5-560F-A40E-6F3827F82E9F}']
    function get_Current: IPackageContentGroup; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIPackageContentGroup): Cardinal; safecall;
    property Current: IPackageContentGroup read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.PackageContentGroup>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.IPackageContentGroup>
  IIterable_1__IPackageContentGroup = interface(IInspectable)
  ['{D7DD1456-4805-5768-A25D-99641B096491}']
    function First: IIterator_1__IPackageContentGroup; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.IPackageContentGroup>
  IVectorView_1__IPackageContentGroup = interface(IInspectable)
  ['{B80F5A11-40E9-5694-998F-F8F16BBD6E78}']
    function GetAt(index: Cardinal): IPackageContentGroup; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IPackageContentGroup; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPackageContentGroup): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.PackageContentGroup>
  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>
  IVector_1__IPackageContentGroup = interface(IInspectable)
  ['{29ADC699-5848-5A98-A516-23FEB0FA2C4B}']
    function GetAt(index: Cardinal): IPackageContentGroup; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IPackageContentGroup; safecall;
    function IndexOf(value: IPackageContentGroup; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IPackageContentGroup); safecall;
    procedure InsertAt(index: Cardinal; value: IPackageContentGroup); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IPackageContentGroup); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPackageContentGroup): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIPackageContentGroup); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.PackageContentGroup>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>>
  AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup = interface(IUnknown)
  ['{52465BF3-3CA6-5681-A7B4-91847757B5FD}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVector_1__IPackageContentGroup; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.PackageContentGroup>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackageContentGroup>>
  IAsyncOperation_1__IVector_1__IPackageContentGroup = interface(IInspectable)
  ['{929E3C29-BF29-5594-BC63-67DB43A539EA}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup; safecall;
    function GetResults: IVector_1__IPackageContentGroup; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVector_1__IPackageContentGroup read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.PackageContentGroup>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageContentGroup>
  AsyncOperationCompletedHandler_1__IPackageContentGroup = interface(IUnknown)
  ['{2253DC38-9A1A-5364-9A3B-03A7DA615499}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IPackageContentGroup; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.PackageContentGroup>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageContentGroup>
  IAsyncOperation_1__IPackageContentGroup = interface(IInspectable)
  ['{BBD292E3-DB9F-5802-A488-40F156332C04}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IPackageContentGroup); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IPackageContentGroup; safecall;
    function GetResults: IPackageContentGroup; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IPackageContentGroup read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage5
  IPackage5 = interface(IInspectable)
  ['{0E842DD4-D9AC-45ED-9A1E-74CE056B2635}']
    function GetContentGroupsAsync: IAsyncOperation_1__IVector_1__IPackageContentGroup; safecall;
    function GetContentGroupAsync(name: HSTRING): IAsyncOperation_1__IPackageContentGroup; safecall;
    function StageContentGroupsAsync(names: IIterable_1__HSTRING): IAsyncOperation_1__IVector_1__IPackageContentGroup; overload; safecall;
    function StageContentGroupsAsync(names: IIterable_1__HSTRING; moveToHeadOfQueue: Boolean): IAsyncOperation_1__IVector_1__IPackageContentGroup; overload; safecall;
    function SetInUseAsync(inUse: Boolean): IAsyncOperation_1__Boolean; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageUpdateAvailabilityResult
  IPackageUpdateAvailabilityResult = interface(IInspectable)
  ['{114E5009-199A-48A1-A079-313C45634A71}']
    function get_Availability: PackageUpdateAvailability; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property Availability: PackageUpdateAvailability read get_Availability;
    property ExtendedError: HRESULT read get_ExtendedError;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.PackageUpdateAvailabilityResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageUpdateAvailabilityResult>
  AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult = interface(IUnknown)
  ['{4020C034-C762-5152-BEEF-F03471E885B9}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IPackageUpdateAvailabilityResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.PackageUpdateAvailabilityResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageUpdateAvailabilityResult>
  IAsyncOperation_1__IPackageUpdateAvailabilityResult = interface(IInspectable)
  ['{010BD015-43EF-576C-BE1E-BC38C5B6B66B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult; safecall;
    function GetResults: IPackageUpdateAvailabilityResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IPackageUpdateAvailabilityResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage6
  IPackage6 = interface(IInspectable)
  ['{8B1AD942-12D7-4754-AE4E-638CBC0E3A2E}']
    function GetAppInstallerInfo: IAppInstallerInfo; safecall;
    function CheckUpdateAvailabilityAsync: IAsyncOperation_1__IPackageUpdateAvailabilityResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage7
  IPackage7 = interface(IInspectable)
  ['{86FF8D31-A2E4-45E0-9732-283A6D88FDE1}']
    function get_MutableLocation: IStorageFolder; safecall;
    function get_EffectiveLocation: IStorageFolder; safecall;
    property EffectiveLocation: IStorageFolder read get_EffectiveLocation;
    property MutableLocation: IStorageFolder read get_MutableLocation;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage8
  IPackage8 = interface(IInspectable)
  ['{2C584F7B-CE2A-4BE6-A093-77CFBB2A7EA1}']
    function get_EffectiveExternalLocation: IStorageFolder; safecall;
    function get_MachineExternalLocation: IStorageFolder; safecall;
    function get_UserExternalLocation: IStorageFolder; safecall;
    function get_InstalledPath: HSTRING; safecall;
    function get_MutablePath: HSTRING; safecall;
    function get_EffectivePath: HSTRING; safecall;
    function get_EffectiveExternalPath: HSTRING; safecall;
    function get_MachineExternalPath: HSTRING; safecall;
    function get_UserExternalPath: HSTRING; safecall;
    function GetLogoAsRandomAccessStreamReference(size: TSizeF): IRandomAccessStreamReference; safecall;
    function GetAppListEntries: IVectorView_1__IAppListEntry; safecall;
    function get_IsStub: Boolean; safecall;
    property EffectiveExternalLocation: IStorageFolder read get_EffectiveExternalLocation;
    property EffectiveExternalPath: HSTRING read get_EffectiveExternalPath;
    property EffectivePath: HSTRING read get_EffectivePath;
    property InstalledPath: HSTRING read get_InstalledPath;
    property IsStub: Boolean read get_IsStub;
    property MachineExternalLocation: IStorageFolder read get_MachineExternalLocation;
    property MachineExternalPath: HSTRING read get_MachineExternalPath;
    property MutablePath: HSTRING read get_MutablePath;
    property UserExternalLocation: IStorageFolder read get_UserExternalLocation;
    property UserExternalPath: HSTRING read get_UserExternalPath;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.Package>
  // Windows.Foundation.Collections.IVector`1<Windows.ApplicationModel.IPackage>
  IVector_1__IPackage = interface(IInspectable)
  ['{D1BB509E-6989-5C69-B1FF-D1702FE8ACA3}']
    function GetAt(index: Cardinal): IPackage; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IPackage; safecall;
    function IndexOf(value: IPackage; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IPackage); safecall;
    procedure InsertAt(index: Cardinal; value: IPackage); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IPackage); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPackage): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIPackage); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackage9
  IPackage9 = interface(IInspectable)
  ['{D5AB224F-D7E1-49EC-90CE-720CDBD02E9C}']
    function FindRelatedPackages(options: IFindRelatedPackagesOptions): IVector_1__IPackage; safecall;
    function get_SourceUriSchemeName: HSTRING; safecall;
    property SourceUriSchemeName: HSTRING read get_SourceUriSchemeName;
  end;

  // Windows.ApplicationModel.IPackageStagingEventArgs
  IPackageStagingEventArgs = interface(IInspectable)
  ['{1041682D-54E2-4F51-B828-9EF7046C210F}']
    function get_ActivityId: TGuid; safecall;
    function get_Package: IPackage; safecall;
    function get_Progress: Double; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_ErrorCode: HRESULT; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ErrorCode: HRESULT read get_ErrorCode;
    property IsComplete: Boolean read get_IsComplete;
    property Package: IPackage read get_Package;
    property Progress: Double read get_Progress;
  end;

  // Windows.ApplicationModel.IPackageInstallingEventArgs
  IPackageInstallingEventArgs = interface(IInspectable)
  ['{97741EB7-AB7A-401A-8B61-EB0E7FAFF237}']
    function get_ActivityId: TGuid; safecall;
    function get_Package: IPackage; safecall;
    function get_Progress: Double; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_ErrorCode: HRESULT; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ErrorCode: HRESULT read get_ErrorCode;
    property IsComplete: Boolean read get_IsComplete;
    property Package: IPackage read get_Package;
    property Progress: Double read get_Progress;
  end;

  // Windows.ApplicationModel.IPackageUpdatingEventArgs
  IPackageUpdatingEventArgs = interface(IInspectable)
  ['{CD7B4228-FD74-443E-B114-23E677B0E86F}']
    function get_ActivityId: TGuid; safecall;
    function get_SourcePackage: IPackage; safecall;
    function get_TargetPackage: IPackage; safecall;
    function get_Progress: Double; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_ErrorCode: HRESULT; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ErrorCode: HRESULT read get_ErrorCode;
    property IsComplete: Boolean read get_IsComplete;
    property Progress: Double read get_Progress;
    property SourcePackage: IPackage read get_SourcePackage;
    property TargetPackage: IPackage read get_TargetPackage;
  end;

  // Windows.ApplicationModel.IPackageUninstallingEventArgs
  IPackageUninstallingEventArgs = interface(IInspectable)
  ['{4443AA52-AB22-44CD-82BB-4EC9B827367A}']
    function get_ActivityId: TGuid; safecall;
    function get_Package: IPackage; safecall;
    function get_Progress: Double; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_ErrorCode: HRESULT; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ErrorCode: HRESULT read get_ErrorCode;
    property IsComplete: Boolean read get_IsComplete;
    property Package: IPackage read get_Package;
    property Progress: Double read get_Progress;
  end;

  // Windows.ApplicationModel.IPackageStatusChangedEventArgs
  IPackageStatusChangedEventArgs = interface(IInspectable)
  ['{437D714D-BD80-4A70-BC50-F6E796509575}']
    function get_Package: IPackage; safecall;
    property Package: IPackage read get_Package;
  end;

  // Windows.ApplicationModel.IPackageContentGroupStagingEventArgs
  IPackageContentGroupStagingEventArgs = interface(IInspectable)
  ['{3D7BC27E-6F27-446C-986E-D4733D4D9113}']
    function get_ActivityId: TGuid; safecall;
    function get_Package: IPackage; safecall;
    function get_Progress: Double; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_ErrorCode: HRESULT; safecall;
    function get_ContentGroupName: HSTRING; safecall;
    function get_IsContentGroupRequired: Boolean; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ContentGroupName: HSTRING read get_ContentGroupName;
    property ErrorCode: HRESULT read get_ErrorCode;
    property IsComplete: Boolean read get_IsComplete;
    property IsContentGroupRequired: Boolean read get_IsContentGroupRequired;
    property Package: IPackage read get_Package;
    property Progress: Double read get_Progress;
  end;

  // Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult
  IPackageCatalogRemoveResourcePackagesResult = interface(IInspectable)
  ['{AE719709-1A52-4321-87B3-E5A1A17981A7}']
    function get_PackagesRemoved: IVectorView_1__IPackage; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property PackagesRemoved: IVectorView_1__IPackage read get_PackagesRemoved;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.PackageCatalogRemoveResourcePackagesResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult>
  AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult = interface(IUnknown)
  ['{142B78D7-5CC3-5B40-A58D-43A582CA83EA}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IPackageCatalogRemoveResourcePackagesResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.PackageCatalogRemoveResourcePackagesResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.IPackageCatalogRemoveResourcePackagesResult>
  IAsyncOperation_1__IPackageCatalogRemoveResourcePackagesResult = interface(IInspectable)
  ['{342EE07C-8D6E-53A4-B746-C5B74BB61F6D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult; safecall;
    function GetResults: IPackageCatalogRemoveResourcePackagesResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IPackageCatalogRemoveResourcePackagesResult read get_Completed write put_Completed;
  end;

  // Windows.ApplicationModel.IPackageIdWithMetadata
  IPackageIdWithMetadata = interface(IInspectable)
  ['{40577A7C-0C9E-443D-9074-855F5CE0A08D}']
    function get_ProductId: HSTRING; safecall;
    function get_Author: HSTRING; safecall;
    property Author: HSTRING read get_Author;
    property ProductId: HSTRING read get_ProductId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageStatics
  [WinRTClassNameAttribute(SWindows_ApplicationModel_PackageRT)]
  IPackageStatics = interface(IInspectable)
  ['{4E534BDF-2960-4878-97A4-9624DEB72F2D}']
    function get_Current: IPackage; safecall;
    property Current: IPackage read get_Current;
  end;

  // Windows.ApplicationModel.IPackageStatus2
  IPackageStatus2 = interface(IInspectable)
  ['{F428FA93-7C56-4862-ACFA-ABAEDCC0694D}']
    function get_IsPartiallyStaged: Boolean; safecall;
    property IsPartiallyStaged: Boolean read get_IsPartiallyStaged;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.IPackageWithMetadata
  IPackageWithMetadata = interface(IInspectable)
  ['{95949780-1DE9-40F2-B452-0DE9F1910012}']
    function get_InstallDate: DateTime; safecall;
    function GetThumbnailToken: HSTRING; safecall;
    procedure Launch(parameters: HSTRING); safecall;
    property InstallDate: DateTime read get_InstallDate;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.StartupTaskState>
  AsyncOperationCompletedHandler_1__StartupTaskState = interface(IUnknown)
  ['{70A0BF67-19E8-5A86-A32E-3C9863825A04}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__StartupTaskState; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.StartupTaskState>
  IAsyncOperation_1__StartupTaskState = interface(IInspectable)
  ['{5239A934-80E2-518F-B819-1F316F379A3F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__StartupTaskState); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__StartupTaskState; safecall;
    function GetResults: StartupTaskState; safecall;
    property Completed: AsyncOperationCompletedHandler_1__StartupTaskState read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.LockScreen.ILockScreenUnlockingDeferral
  LockScreen_ILockScreenUnlockingDeferral = interface(IInspectable)
  ['{7E7D1AD6-5203-43E7-9BD6-7C3947D1E3FE}']
    procedure Complete; safecall;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.LockScreen.ILockScreenUnlockingEventArgs
  LockScreen_ILockScreenUnlockingEventArgs = interface(IInspectable)
  ['{44E6C007-75FB-4ABB-9F8B-824748900C71}']
    function GetDeferral: LockScreen_ILockScreenUnlockingDeferral; safecall;
    function get_Deadline: DateTime; safecall;
    property Deadline: DateTime read get_Deadline;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.LockApplicationHost,Windows.ApplicationModel.LockScreen.LockScreenUnlockingEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.ILockApplicationHost,Windows.ApplicationModel.LockScreen.ILockScreenUnlockingEventArgs>
  TypedEventHandler_2__LockScreen_ILockApplicationHost__LockScreen_ILockScreenUnlockingEventArgs = interface(IUnknown)
  ['{002E5776-8A5B-5B93-8C6C-9C4C8788F5B4}']
    procedure Invoke(sender: LockScreen_ILockApplicationHost; args: LockScreen_ILockScreenUnlockingEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.LockScreen.ILockApplicationHost
  [WinRTClassNameAttribute(SWindows_ApplicationModel_LockScreen_LockApplicationHost)]
  LockScreen_ILockApplicationHost = interface(IInspectable)
  ['{38EE31AD-D94F-4E7C-81FA-4F4436506281}']
    procedure RequestUnlock; safecall;
    function add_Unlocking(handler: TypedEventHandler_2__LockScreen_ILockApplicationHost__LockScreen_ILockScreenUnlockingEventArgs): EventRegistrationToken; safecall;
    procedure remove_Unlocking(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.LockScreen.ILockApplicationHostStatics
  [WinRTClassNameAttribute(SWindows_ApplicationModel_LockScreen_LockApplicationHost)]
  LockScreen_ILockApplicationHostStatics = interface(IInspectable)
  ['{F48FAB8E-23D7-4E63-96A1-666FF52D3B2C}']
    function GetForCurrentView: LockScreen_ILockApplicationHost; safecall;
  end;

  // Windows.ApplicationModel.LockScreen.ILockScreenBadge
  LockScreen_ILockScreenBadge = interface(IInspectable)
  ['{E95105D9-2BFF-4DB0-9B4F-3824778B9C9A}']
    function get_Logo: IRandomAccessStream; safecall;
    function get_Glyph: IRandomAccessStream; safecall;
    function get_Number: IReference_1__Cardinal; safecall;
    function get_AutomationName: HSTRING; safecall;
    procedure LaunchApp; safecall;
    property AutomationName: HSTRING read get_AutomationName;
    property Glyph: IRandomAccessStream read get_Glyph;
    property Logo: IRandomAccessStream read get_Logo;
    property Number: IReference_1__Cardinal read get_Number;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.LockScreenInfo,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.ApplicationModel.LockScreen.ILockScreenInfo,Object>
  TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable = interface(IUnknown)
  ['{8BE9E6A3-F88A-5429-8DA3-676B7D4F1A5B}']
    procedure Invoke(sender: LockScreen_ILockScreenInfo; args: IInspectable); safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.LockScreen.LockScreenBadge>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IIterator_1__LockScreen_ILockScreenBadge = interface(IInspectable)
  ['{8D38F924-154D-5705-8F0B-ED61353F6CE2}']
    function get_Current: LockScreen_ILockScreenBadge; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PLockScreen_ILockScreenBadge): Cardinal; safecall;
    property Current: LockScreen_ILockScreenBadge read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.LockScreen.LockScreenBadge>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IIterable_1__LockScreen_ILockScreenBadge = interface(IInspectable)
  ['{6E82DEDC-B74E-503A-B00B-9C6F47F12A0F}']
    function First: IIterator_1__LockScreen_ILockScreenBadge; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.LockScreen.ILockScreenBadge>
  IVectorView_1__LockScreen_ILockScreenBadge = interface(IInspectable)
  ['{AEFD5B55-DB8D-5E08-93F9-8AD48C511F09}']
    function GetAt(index: Cardinal): LockScreen_ILockScreenBadge; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: LockScreen_ILockScreenBadge; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PLockScreen_ILockScreenBadge): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.ApplicationModel.LockScreen.ILockScreenInfo
  LockScreen_ILockScreenInfo = interface(IInspectable)
  ['{F59AA65C-9711-4DC9-A630-95B6CB8CDAD0}']
    function add_LockScreenImageChanged(handler: TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable): EventRegistrationToken; safecall;
    procedure remove_LockScreenImageChanged(token: EventRegistrationToken); safecall;
    function get_LockScreenImage: IRandomAccessStream; safecall;
    function add_BadgesChanged(handler: TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable): EventRegistrationToken; safecall;
    procedure remove_BadgesChanged(token: EventRegistrationToken); safecall;
    function get_Badges: IVectorView_1__LockScreen_ILockScreenBadge; safecall;
    function add_DetailTextChanged(handler: TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable): EventRegistrationToken; safecall;
    procedure remove_DetailTextChanged(token: EventRegistrationToken); safecall;
    function get_DetailText: IVectorView_1__HSTRING; safecall;
    function add_AlarmIconChanged(handler: TypedEventHandler_2__LockScreen_ILockScreenInfo__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AlarmIconChanged(token: EventRegistrationToken); safecall;
    function get_AlarmIcon: IRandomAccessStream; safecall;
    property AlarmIcon: IRandomAccessStream read get_AlarmIcon;
    property Badges: IVectorView_1__LockScreen_ILockScreenBadge read get_Badges;
    property DetailText: IVectorView_1__HSTRING read get_DetailText;
    property LockScreenImage: IRandomAccessStream read get_LockScreenImage;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentAddress
  Payments_IPaymentAddress = interface(IInspectable)
  ['{5F2264E9-6F3A-4166-A018-0A0B06BB32B5}']
    function get_Country: HSTRING; safecall;
    procedure put_Country(value: HSTRING); safecall;
    function get_AddressLines: IVectorView_1__HSTRING; safecall;
    procedure put_AddressLines(value: IVectorView_1__HSTRING); safecall;
    function get_Region: HSTRING; safecall;
    procedure put_Region(value: HSTRING); safecall;
    function get_City: HSTRING; safecall;
    procedure put_City(value: HSTRING); safecall;
    function get_DependentLocality: HSTRING; safecall;
    procedure put_DependentLocality(value: HSTRING); safecall;
    function get_PostalCode: HSTRING; safecall;
    procedure put_PostalCode(value: HSTRING); safecall;
    function get_SortingCode: HSTRING; safecall;
    procedure put_SortingCode(value: HSTRING); safecall;
    function get_LanguageCode: HSTRING; safecall;
    procedure put_LanguageCode(value: HSTRING); safecall;
    function get_Organization: HSTRING; safecall;
    procedure put_Organization(value: HSTRING); safecall;
    function get_Recipient: HSTRING; safecall;
    procedure put_Recipient(value: HSTRING); safecall;
    function get_PhoneNumber: HSTRING; safecall;
    procedure put_PhoneNumber(value: HSTRING); safecall;
    function get_Properties: IPropertySet; safecall;
    property AddressLines: IVectorView_1__HSTRING read get_AddressLines write put_AddressLines;
    property City: HSTRING read get_City write put_City;
    property Country: HSTRING read get_Country write put_Country;
    property DependentLocality: HSTRING read get_DependentLocality write put_DependentLocality;
    property LanguageCode: HSTRING read get_LanguageCode write put_LanguageCode;
    property Organization: HSTRING read get_Organization write put_Organization;
    property PhoneNumber: HSTRING read get_PhoneNumber write put_PhoneNumber;
    property PostalCode: HSTRING read get_PostalCode write put_PostalCode;
    property Properties: IPropertySet read get_Properties;
    property Recipient: HSTRING read get_Recipient write put_Recipient;
    property Region: HSTRING read get_Region write put_Region;
    property SortingCode: HSTRING read get_SortingCode write put_SortingCode;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult
  Payments_IPaymentCanMakePaymentResult = interface(IInspectable)
  ['{7696FE55-D5D3-4D3D-B345-45591759C510}']
    function get_Status: Payments_PaymentCanMakePaymentResultStatus; safecall;
    property Status: Payments_PaymentCanMakePaymentResultStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentCurrencyAmount
  Payments_IPaymentCurrencyAmount = interface(IInspectable)
  ['{E3A3E9E0-B41F-4987-BDCB-071331F2DAA4}']
    function get_Currency: HSTRING; safecall;
    procedure put_Currency(value: HSTRING); safecall;
    function get_CurrencySystem: HSTRING; safecall;
    procedure put_CurrencySystem(value: HSTRING); safecall;
    function get_Value: HSTRING; safecall;
    procedure put_Value(value: HSTRING); safecall;
    property Currency: HSTRING read get_Currency write put_Currency;
    property CurrencySystem: HSTRING read get_CurrencySystem write put_CurrencySystem;
    property Value: HSTRING read get_Value write put_Value;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentItem
  Payments_IPaymentItem = interface(IInspectable)
  ['{685AC88B-79B2-4B76-9E03-A876223DFE72}']
    function get_Label: HSTRING; safecall;
    procedure put_Label(value: HSTRING); safecall;
    function get_Amount: Payments_IPaymentCurrencyAmount; safecall;
    procedure put_Amount(value: Payments_IPaymentCurrencyAmount); safecall;
    function get_Pending: Boolean; safecall;
    procedure put_Pending(value: Boolean); safecall;
    property Amount: Payments_IPaymentCurrencyAmount read get_Amount write put_Amount;
    property &Label: HSTRING read get_Label write put_Label;
    property Pending: Boolean read get_Pending write put_Pending;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.PaymentItem>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IIterator_1__Payments_IPaymentItem = interface(IInspectable)
  ['{93C12CC3-6A0B-5F02-AC74-056007472731}']
    function get_Current: Payments_IPaymentItem; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPayments_IPaymentItem): Cardinal; safecall;
    property Current: Payments_IPaymentItem read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.PaymentItem>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IIterable_1__Payments_IPaymentItem = interface(IInspectable)
  ['{B61B704C-E5FA-5524-8B95-7D03F5D36AE9}']
    function First: IIterator_1__Payments_IPaymentItem; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentItem>
  IVectorView_1__Payments_IPaymentItem = interface(IInspectable)
  ['{DFCB5863-B26C-56CF-9DC7-9D811C215A21}']
    function GetAt(index: Cardinal): Payments_IPaymentItem; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Payments_IPaymentItem; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPayments_IPaymentItem): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentShippingOption
  Payments_IPaymentShippingOption = interface(IInspectable)
  ['{13372ADA-9753-4574-8966-93145A76C7F9}']
    function get_Label: HSTRING; safecall;
    procedure put_Label(value: HSTRING); safecall;
    function get_Amount: Payments_IPaymentCurrencyAmount; safecall;
    procedure put_Amount(value: Payments_IPaymentCurrencyAmount); safecall;
    function get_Tag: HSTRING; safecall;
    procedure put_Tag(value: HSTRING); safecall;
    function get_IsSelected: Boolean; safecall;
    procedure put_IsSelected(value: Boolean); safecall;
    property Amount: Payments_IPaymentCurrencyAmount read get_Amount write put_Amount;
    property IsSelected: Boolean read get_IsSelected write put_IsSelected;
    property &Label: HSTRING read get_Label write put_Label;
    property Tag: HSTRING read get_Tag write put_Tag;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.PaymentShippingOption>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IIterator_1__Payments_IPaymentShippingOption = interface(IInspectable)
  ['{49EDC9F4-2CE6-534C-B529-5CEEC705DEF5}']
    function get_Current: Payments_IPaymentShippingOption; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPayments_IPaymentShippingOption): Cardinal; safecall;
    property Current: Payments_IPaymentShippingOption read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.PaymentShippingOption>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IIterable_1__Payments_IPaymentShippingOption = interface(IInspectable)
  ['{DE881C69-6642-54DE-A8F7-D1A88B2404CF}']
    function First: IIterator_1__Payments_IPaymentShippingOption; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentShippingOption>
  IVectorView_1__Payments_IPaymentShippingOption = interface(IInspectable)
  ['{01ABA80A-C376-56F9-8191-79E5081F918B}']
    function GetAt(index: Cardinal): Payments_IPaymentShippingOption; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Payments_IPaymentShippingOption; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPayments_IPaymentShippingOption): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentDetailsModifier
  Payments_IPaymentDetailsModifier = interface(IInspectable)
  ['{BE1C7D65-4323-41D7-B305-DFCB765F69DE}']
    function get_JsonData: HSTRING; safecall;
    function get_SupportedMethodIds: IVectorView_1__HSTRING; safecall;
    function get_Total: Payments_IPaymentItem; safecall;
    function get_AdditionalDisplayItems: IVectorView_1__Payments_IPaymentItem; safecall;
    property AdditionalDisplayItems: IVectorView_1__Payments_IPaymentItem read get_AdditionalDisplayItems;
    property JsonData: HSTRING read get_JsonData;
    property SupportedMethodIds: IVectorView_1__HSTRING read get_SupportedMethodIds;
    property Total: Payments_IPaymentItem read get_Total;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.PaymentDetailsModifier>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IIterator_1__Payments_IPaymentDetailsModifier = interface(IInspectable)
  ['{FAFB6774-B665-5B8B-B1EF-95038C3AABE1}']
    function get_Current: Payments_IPaymentDetailsModifier; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPayments_IPaymentDetailsModifier): Cardinal; safecall;
    property Current: Payments_IPaymentDetailsModifier read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.PaymentDetailsModifier>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IIterable_1__Payments_IPaymentDetailsModifier = interface(IInspectable)
  ['{585D2B3D-CB34-58C4-81F4-1EA157996DEF}']
    function First: IIterator_1__Payments_IPaymentDetailsModifier; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentDetailsModifier>
  IVectorView_1__Payments_IPaymentDetailsModifier = interface(IInspectable)
  ['{205CEF2F-53D2-5A33-A7FF-5D8C8DA2AFC8}']
    function GetAt(index: Cardinal): Payments_IPaymentDetailsModifier; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Payments_IPaymentDetailsModifier; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPayments_IPaymentDetailsModifier): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentDetails
  Payments_IPaymentDetails = interface(IInspectable)
  ['{53BB2D7D-E0EB-4053-8EAE-CE7C48E02945}']
    function get_Total: Payments_IPaymentItem; safecall;
    procedure put_Total(value: Payments_IPaymentItem); safecall;
    function get_DisplayItems: IVectorView_1__Payments_IPaymentItem; safecall;
    procedure put_DisplayItems(value: IVectorView_1__Payments_IPaymentItem); safecall;
    function get_ShippingOptions: IVectorView_1__Payments_IPaymentShippingOption; safecall;
    procedure put_ShippingOptions(value: IVectorView_1__Payments_IPaymentShippingOption); safecall;
    function get_Modifiers: IVectorView_1__Payments_IPaymentDetailsModifier; safecall;
    procedure put_Modifiers(value: IVectorView_1__Payments_IPaymentDetailsModifier); safecall;
    property DisplayItems: IVectorView_1__Payments_IPaymentItem read get_DisplayItems write put_DisplayItems;
    property Modifiers: IVectorView_1__Payments_IPaymentDetailsModifier read get_Modifiers write put_Modifiers;
    property ShippingOptions: IVectorView_1__Payments_IPaymentShippingOption read get_ShippingOptions write put_ShippingOptions;
    property Total: Payments_IPaymentItem read get_Total write put_Total;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentToken
  Payments_IPaymentToken = interface(IInspectable)
  ['{BBCAC013-CCD0-41F2-B2A1-0A2E4B5DCE25}']
    function get_PaymentMethodId: HSTRING; safecall;
    function get_JsonDetails: HSTRING; safecall;
    property JsonDetails: HSTRING read get_JsonDetails;
    property PaymentMethodId: HSTRING read get_PaymentMethodId;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentResponse
  Payments_IPaymentResponse = interface(IInspectable)
  ['{E1389457-8BD2-4888-9FA8-97985545108E}']
    function get_PaymentToken: Payments_IPaymentToken; safecall;
    function get_ShippingOption: Payments_IPaymentShippingOption; safecall;
    function get_ShippingAddress: Payments_IPaymentAddress; safecall;
    function get_PayerEmail: HSTRING; safecall;
    function get_PayerName: HSTRING; safecall;
    function get_PayerPhoneNumber: HSTRING; safecall;
    function CompleteAsync(status: Payments_PaymentRequestCompletionStatus): IAsyncAction; safecall;
    property PayerEmail: HSTRING read get_PayerEmail;
    property PayerName: HSTRING read get_PayerName;
    property PayerPhoneNumber: HSTRING read get_PayerPhoneNumber;
    property PaymentToken: Payments_IPaymentToken read get_PaymentToken;
    property ShippingAddress: Payments_IPaymentAddress read get_ShippingAddress;
    property ShippingOption: Payments_IPaymentShippingOption read get_ShippingOption;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult
  Payments_IPaymentRequestSubmitResult = interface(IInspectable)
  ['{7B9C3912-30F2-4E90-B249-8CE7D78FFE56}']
    function get_Status: Payments_PaymentRequestStatus; safecall;
    function get_Response: Payments_IPaymentResponse; safecall;
    property Response: Payments_IPaymentResponse read get_Response;
    property Status: Payments_PaymentRequestStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.PaymentRequestSubmitResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult = interface(IUnknown)
  ['{CBCD07A6-AE2A-5A70-BC0B-9120560825D1}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Payments_IPaymentRequestSubmitResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.PaymentRequestSubmitResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentRequestSubmitResult>
  IAsyncOperation_1__Payments_IPaymentRequestSubmitResult = interface(IInspectable)
  ['{CF290DEB-5549-57C3-8ABD-53B76C643CCA}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult; safecall;
    function GetResults: Payments_IPaymentRequestSubmitResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestSubmitResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentMerchantInfo
  Payments_IPaymentMerchantInfo = interface(IInspectable)
  ['{63445050-0E94-4ED6-AACB-E6012BD327A7}']
    function get_PackageFullName: HSTRING; safecall;
    function get_Uri: IUriRuntimeClass; safecall;
    property PackageFullName: HSTRING read get_PackageFullName;
    property Uri: IUriRuntimeClass read get_Uri;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentMethodData
  Payments_IPaymentMethodData = interface(IInspectable)
  ['{D1D3CAF4-DE98-4129-B1B7-C3AD86237BF4}']
    function get_SupportedMethodIds: IVectorView_1__HSTRING; safecall;
    function get_JsonData: HSTRING; safecall;
    property JsonData: HSTRING read get_JsonData;
    property SupportedMethodIds: IVectorView_1__HSTRING read get_SupportedMethodIds;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.PaymentMethodData>
  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IIterator_1__Payments_IPaymentMethodData = interface(IInspectable)
  ['{9666522E-E5AC-5374-A5D9-5CF57C4BF689}']
    function get_Current: Payments_IPaymentMethodData; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPayments_IPaymentMethodData): Cardinal; safecall;
    property Current: Payments_IPaymentMethodData read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.PaymentMethodData>
  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IIterable_1__Payments_IPaymentMethodData = interface(IInspectable)
  ['{8C9ED87E-4ADD-58A8-AD9A-9DFA48CA250A}']
    function First: IIterator_1__Payments_IPaymentMethodData; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Payments.IPaymentMethodData>
  IVectorView_1__Payments_IPaymentMethodData = interface(IInspectable)
  ['{D4EB6D93-3C91-50AB-9E50-46FC93402229}']
    function GetAt(index: Cardinal): Payments_IPaymentMethodData; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Payments_IPaymentMethodData; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPayments_IPaymentMethodData): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentOptions
  Payments_IPaymentOptions = interface(IInspectable)
  ['{AAA30854-1F2B-4365-8251-01B58915A5BC}']
    function get_RequestPayerEmail: Payments_PaymentOptionPresence; safecall;
    procedure put_RequestPayerEmail(value: Payments_PaymentOptionPresence); safecall;
    function get_RequestPayerName: Payments_PaymentOptionPresence; safecall;
    procedure put_RequestPayerName(value: Payments_PaymentOptionPresence); safecall;
    function get_RequestPayerPhoneNumber: Payments_PaymentOptionPresence; safecall;
    procedure put_RequestPayerPhoneNumber(value: Payments_PaymentOptionPresence); safecall;
    function get_RequestShipping: Boolean; safecall;
    procedure put_RequestShipping(value: Boolean); safecall;
    function get_ShippingType: Payments_PaymentShippingType; safecall;
    procedure put_ShippingType(value: Payments_PaymentShippingType); safecall;
    property RequestPayerEmail: Payments_PaymentOptionPresence read get_RequestPayerEmail write put_RequestPayerEmail;
    property RequestPayerName: Payments_PaymentOptionPresence read get_RequestPayerName write put_RequestPayerName;
    property RequestPayerPhoneNumber: Payments_PaymentOptionPresence read get_RequestPayerPhoneNumber write put_RequestPayerPhoneNumber;
    property RequestShipping: Boolean read get_RequestShipping write put_RequestShipping;
    property ShippingType: Payments_PaymentShippingType read get_ShippingType write put_ShippingType;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentRequest
  Payments_IPaymentRequest = interface(IInspectable)
  ['{B74942E1-ED7B-47EB-BC08-78CC5D6896B6}']
    function get_MerchantInfo: Payments_IPaymentMerchantInfo; safecall;
    function get_Details: Payments_IPaymentDetails; safecall;
    function get_MethodData: IVectorView_1__Payments_IPaymentMethodData; safecall;
    function get_Options: Payments_IPaymentOptions; safecall;
    property Details: Payments_IPaymentDetails read get_Details;
    property MerchantInfo: Payments_IPaymentMerchantInfo read get_MerchantInfo;
    property MethodData: IVectorView_1__Payments_IPaymentMethodData read get_MethodData;
    property Options: Payments_IPaymentOptions read get_Options;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentRequestChangedResult
  Payments_IPaymentRequestChangedResult = interface(IInspectable)
  ['{DF699E5C-16C4-47AD-9401-8440EC0757DB}']
    function get_ChangeAcceptedByMerchant: Boolean; safecall;
    procedure put_ChangeAcceptedByMerchant(value: Boolean); safecall;
    function get_Message: HSTRING; safecall;
    procedure put_Message(value: HSTRING); safecall;
    function get_UpdatedPaymentDetails: Payments_IPaymentDetails; safecall;
    procedure put_UpdatedPaymentDetails(value: Payments_IPaymentDetails); safecall;
    property ChangeAcceptedByMerchant: Boolean read get_ChangeAcceptedByMerchant write put_ChangeAcceptedByMerchant;
    property &Message: HSTRING read get_Message write put_Message;
    property UpdatedPaymentDetails: Payments_IPaymentDetails read get_UpdatedPaymentDetails write put_UpdatedPaymentDetails;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentRequestChangedArgs
  Payments_IPaymentRequestChangedArgs = interface(IInspectable)
  ['{C6145E44-CD8B-4BE4-B555-27C99194C0C5}']
    function get_ChangeKind: Payments_PaymentRequestChangeKind; safecall;
    function get_ShippingAddress: Payments_IPaymentAddress; safecall;
    function get_SelectedShippingOption: Payments_IPaymentShippingOption; safecall;
    procedure Acknowledge(changeResult: Payments_IPaymentRequestChangedResult); safecall;
    property ChangeKind: Payments_PaymentRequestChangeKind read get_ChangeKind;
    property SelectedShippingOption: Payments_IPaymentShippingOption read get_SelectedShippingOption;
    property ShippingAddress: Payments_IPaymentAddress read get_ShippingAddress;
  end;

  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.PaymentRequestChangedHandler
  Payments_PaymentRequestChangedHandler = interface(IUnknown)
  ['{5078B9E1-F398-4F2C-A27E-94D371CF6C7D}']
    procedure Invoke(paymentRequest: Payments_IPaymentRequest; args: Payments_IPaymentRequestChangedArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentMediator
  [WinRTClassNameAttribute(SWindows_ApplicationModel_Payments_PaymentMediator)]
  Payments_IPaymentMediator = interface(IInspectable)
  ['{FB0EE829-EC0C-449A-83DA-7AE3073365A2}']
    function GetSupportedMethodIdsAsync: IAsyncOperation_1__IVectorView_1__HSTRING; safecall;
    function SubmitPaymentRequestAsync(paymentRequest: Payments_IPaymentRequest): IAsyncOperation_1__Payments_IPaymentRequestSubmitResult; overload; safecall;
    function SubmitPaymentRequestAsync(paymentRequest: Payments_IPaymentRequest; changeHandler: Payments_PaymentRequestChangedHandler): IAsyncOperation_1__Payments_IPaymentRequestSubmitResult; overload; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.PaymentCanMakePaymentResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult = interface(IUnknown)
  ['{89AE5B89-6D05-5842-9CDF-F4CBF706DC5E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Payments_IPaymentCanMakePaymentResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.PaymentCanMakePaymentResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentCanMakePaymentResult>
  IAsyncOperation_1__Payments_IPaymentCanMakePaymentResult = interface(IInspectable)
  ['{A467410A-11DE-5090-B905-96A562D85DE5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult; safecall;
    function GetResults: Payments_IPaymentCanMakePaymentResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentCanMakePaymentResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.ApplicationModel.Payments.IPaymentMediator2
  Payments_IPaymentMediator2 = interface(IInspectable)
  ['{CEEF98F1-E407-4128-8E73-D93D5F822786}']
    function CanMakePaymentAsync(paymentRequest: Payments_IPaymentRequest): IAsyncOperation_1__Payments_IPaymentCanMakePaymentResult; safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.PaymentRequestChangedResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Payments.IPaymentRequestChangedResult>
  AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult = interface(IUnknown)
  ['{BEC8B726-9056-5E47-B22A-0DA09AA84AFE}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Payments_IPaymentRequestChangedResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.PaymentRequestChangedResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Payments.IPaymentRequestChangedResult>
  IAsyncOperation_1__Payments_IPaymentRequestChangedResult = interface(IInspectable)
  ['{0CC32025-AC67-57E2-A0F6-3A8E116CEF4C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult; safecall;
    function GetResults: Payments_IPaymentRequestChangedResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Payments_IPaymentRequestChangedResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.ApplicationModel.Search.Core.SearchSuggestion>
  // Windows.Foundation.Collections.VectorChangedEventHandler`1<Windows.ApplicationModel.Search.Core.ISearchSuggestion>
  VectorChangedEventHandler_1__Search_Core_ISearchSuggestion = interface(IUnknown)
  ['{CB7B988B-468A-5EAE-AFE4-DF8B005F80AF}']
    procedure Invoke(sender: IObservableVector_1__Search_Core_ISearchSuggestion; event: IVectorChangedEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IObservableVector`1<Windows.ApplicationModel.Search.Core.ISearchSuggestion>
  IObservableVector_1__Search_Core_ISearchSuggestion = interface(IInspectable)
  ['{944A3DA2-8D2E-5EAE-8E5A-99D6B12F6043}']
    function add_VectorChanged(vhnd: VectorChangedEventHandler_1__Search_Core_ISearchSuggestion): EventRegistrationToken; safecall;
    procedure remove_VectorChanged(token: EventRegistrationToken); safecall;
  end;

  // Windows.ApplicationModel.Store.LicenseChangedEventHandler
  Store_LicenseChangedEventHandler = interface(IUnknown)
  ['{D4A50255-1369-4C36-832F-6F2D88E3659B}']
    procedure Invoke; safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Store.FulfillmentResult>
  AsyncOperationCompletedHandler_1__Store_FulfillmentResult = interface(IUnknown)
  ['{8775ACC9-B9AE-5CCE-895C-971BF9270892}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Store_FulfillmentResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Store.FulfillmentResult>
  IAsyncOperation_1__Store_FulfillmentResult = interface(IInspectable)
  ['{5C8531AC-5D8D-5E07-B6EE-7CAB96930E8A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Store_FulfillmentResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Store_FulfillmentResult; safecall;
    function GetResults: Store_FulfillmentResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Store_FulfillmentResult read get_Completed write put_Completed;
  end;

  // Windows.ApplicationModel.Store.IProductListingWithConsumables
  Store_IProductListingWithConsumables = interface(IInspectable)
  ['{EB9E9790-8F6B-481F-93A7-5C3A63068149}']
    function get_ProductType: Store_ProductType; safecall;
    property ProductType: Store_ProductType read get_ProductType;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IIterator_1__Store_Preview_StoreSystemFeature = interface(IInspectable)
  ['{D0455B2D-D8AA-557E-89A3-63C33E8CEE99}']
    function get_Current: Store_Preview_StoreSystemFeature; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PStore_Preview_StoreSystemFeature): Cardinal; safecall;
    property Current: Store_Preview_StoreSystemFeature read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IIterable_1__Store_Preview_StoreSystemFeature = interface(IInspectable)
  ['{98A8577A-B128-5400-8D3D-58654EAAF957}']
    function First: IIterator_1__Store_Preview_StoreSystemFeature; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>
  IVectorView_1__Store_Preview_StoreSystemFeature = interface(IInspectable)
  ['{C8F90757-EBCF-5F2C-B918-6487105B0CA1}']
    function GetAt(index: Cardinal): Store_Preview_StoreSystemFeature; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Store_Preview_StoreSystemFeature; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PStore_Preview_StoreSystemFeature): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature = interface(IUnknown)
  ['{7E7946EF-F8F0-53FD-9613-7261CB35DAF4}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Store_Preview_StoreSystemFeature; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.ApplicationModel.Store.Preview.StoreSystemFeature>>
  IAsyncOperation_1__IVectorView_1__Store_Preview_StoreSystemFeature = interface(IInspectable)
  ['{B1713163-EE1B-5290-8316-F7EBB9D53163}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature; safecall;
    function GetResults: IVectorView_1__Store_Preview_StoreSystemFeature; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Store_Preview_StoreSystemFeature read get_Completed write put_Completed;
  end;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.UserDataTasks.UserDataTaskDaysOfWeek>
  IReference_1__UserDataTasks_UserDataTaskDaysOfWeek = interface(IInspectable)
  ['{27017BBF-3EDD-503D-97A6-FC75060EA804}']
    function get_Value: UserDataTasks_UserDataTaskDaysOfWeek; safecall;
    property Value: UserDataTasks_UserDataTaskDaysOfWeek read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.ApplicationModel.UserDataTasks.UserDataTaskWeekOfMonth>
  IReference_1__UserDataTasks_UserDataTaskWeekOfMonth = interface(IInspectable)
  ['{5246FA7F-F9E9-5574-80F7-4AA359B0023D}']
    function get_Value: UserDataTasks_UserDataTaskWeekOfMonth; safecall;
    property Value: UserDataTasks_UserDataTaskWeekOfMonth read get_Value;
  end;

  // Windows.ApplicationModel.AppInfo
  // DualAPI
  // Implements: Windows.ApplicationModel.IAppInfo
  // Implements: Windows.ApplicationModel.IAppInfo2
  // Implements: Windows.ApplicationModel.IAppInfo3
  // Implements: Windows.ApplicationModel.IAppInfo4
  // Statics: "Windows.ApplicationModel.IAppInfoStatics"
  TAppInfo = class(TWinRTGenericImportS<IAppInfoStatics>)
  public
    {$REGION 'IAppInfoStatics'}
    class function get_Current: IAppInfo; static; inline;
    class function GetFromAppUserModelId(appUserModelId: HSTRING): IAppInfo; static; inline;
    class function GetFromAppUserModelIdForUser(user: IUser; appUserModelId: HSTRING): IAppInfo; static; inline;
    class property Current: IAppInfo read get_Current;
    {$ENDREGION}
 end;

  // Windows.ApplicationModel.AppService.AppServiceConnection
  // DualAPI
  // Implements: Windows.ApplicationModel.AppService.IAppServiceConnection
  // Implements: Windows.ApplicationModel.AppService.IAppServiceConnection2
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.ApplicationModel.AppService.IAppServiceConnectionStatics"
  // Instantiable: "AppService_IAppServiceConnection"
  TAppService_AppServiceConnection = class(TWinRTGenericImportSI<AppService_IAppServiceConnectionStatics, AppService_IAppServiceConnection>)
  public
    {$REGION 'AppService_IAppServiceConnectionStatics'}
    class function SendStatelessMessageAsync(connection: AppService_IAppServiceConnection; connectionRequest: RemoteSystems_IRemoteSystemConnectionRequest; &message: IPropertySet): IAsyncOperation_1__AppService_IStatelessAppServiceResponse; static; inline;
    {$ENDREGION}
 end;

  // Windows.ApplicationModel.LockScreen.LockApplicationHost
  // DualAPI
  // Implements: Windows.ApplicationModel.LockScreen.ILockApplicationHost
  // Statics: "Windows.ApplicationModel.LockScreen.ILockApplicationHostStatics"
  TLockScreen_LockApplicationHost = class(TWinRTGenericImportS<LockScreen_ILockApplicationHostStatics>)
  public
    {$REGION 'LockScreen_ILockApplicationHostStatics'}
    class function GetForCurrentView: LockScreen_ILockApplicationHost; static; inline;
    {$ENDREGION}
 end;

  // Windows.ApplicationModel.Package
  // DualAPI
  // Implements: Windows.ApplicationModel.IPackage
  // Implements: Windows.ApplicationModel.IPackage2
  // Implements: Windows.ApplicationModel.IPackage3
  // Implements: Windows.ApplicationModel.IPackageWithMetadata
  // Implements: Windows.ApplicationModel.IPackage4
  // Implements: Windows.ApplicationModel.IPackage5
  // Implements: Windows.ApplicationModel.IPackage6
  // Implements: Windows.ApplicationModel.IPackage7
  // Implements: Windows.ApplicationModel.IPackage8
  // Implements: Windows.ApplicationModel.IPackage9
  // Statics: "Windows.ApplicationModel.IPackageStatics"
  TPackageRT = class(TWinRTGenericImportS<IPackageStatics>)
  public
    {$REGION 'IPackageStatics'}
    class function get_Current: IPackage; static; inline;
    class property Current: IPackage read get_Current;
    {$ENDREGION}
 end;

  // Windows.ApplicationModel.Payments.PaymentMediator
  // DualAPI
  // Implements: Windows.ApplicationModel.Payments.IPaymentMediator
  // Implements: Windows.ApplicationModel.Payments.IPaymentMediator2
  // Instantiable: "Payments_IPaymentMediator"
  TPayments_PaymentMediator = class(TWinRTGenericImportI<Payments_IPaymentMediator>) end;

implementation

{ TAppInfo }

{$REGION 'Windows.ApplicationModel.IAppInfoStatics'}
class function TAppInfo.get_Current: IAppInfo;
begin
  Result := Statics.get_Current;
end;

class function TAppInfo.GetFromAppUserModelId(appUserModelId: HSTRING): IAppInfo;
begin
  Result := Statics.GetFromAppUserModelId(appUserModelId);
end;

class function TAppInfo.GetFromAppUserModelIdForUser(user: IUser; appUserModelId: HSTRING): IAppInfo;
begin
  Result := Statics.GetFromAppUserModelIdForUser(user, appUserModelId);
end;
{$ENDREGION}

{ TAppService_AppServiceConnection }

{$REGION 'Windows.ApplicationModel.AppService.IAppServiceConnectionStatics'}
class function TAppService_AppServiceConnection.SendStatelessMessageAsync(connection: AppService_IAppServiceConnection; connectionRequest: RemoteSystems_IRemoteSystemConnectionRequest; &message: IPropertySet): IAsyncOperation_1__AppService_IStatelessAppServiceResponse;
begin
  Result := Statics.SendStatelessMessageAsync(connection, connectionRequest, &message);
end;
{$ENDREGION}

{ TLockScreen_LockApplicationHost }

{$REGION 'Windows.ApplicationModel.LockScreen.ILockApplicationHostStatics'}
class function TLockScreen_LockApplicationHost.GetForCurrentView: LockScreen_ILockApplicationHost;
begin
  Result := Statics.GetForCurrentView;
end;
{$ENDREGION}

{ TPackageRT }

{$REGION 'Windows.ApplicationModel.IPackageStatics'}
class function TPackageRT.get_Current: IPackage;
begin
  Result := Statics.get_Current;
end;
{$ENDREGION}

{ TPayments_PaymentMediator }

end.
