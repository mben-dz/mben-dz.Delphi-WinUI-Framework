{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Perception;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Foundation,
  Winapi.GraphicsRT,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Perception.Spatial.ISpatialCoordinateSystem
  Spatial_ISpatialCoordinateSystem = interface;
  PSpatial_ISpatialCoordinateSystem = ^Spatial_ISpatialCoordinateSystem;

  // Windows.Perception.IPerceptionTimestamp
  IPerceptionTimestamp = interface;
  PIPerceptionTimestamp = ^IPerceptionTimestamp;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingFrustum>
  IReference_1__Spatial_SpatialBoundingFrustum = interface;
  PIReference_1__Spatial_SpatialBoundingFrustum = ^IReference_1__Spatial_SpatialBoundingFrustum;

  // Windows.Perception.Automation.Core.ICorePerceptionAutomationStatics
  Automation_Core_ICorePerceptionAutomationStatics = interface;
  PAutomation_Core_ICorePerceptionAutomationStatics = ^Automation_Core_ICorePerceptionAutomationStatics;

  // Windows.Perception.IPerceptionTimestampHelperStatics
  IPerceptionTimestampHelperStatics = interface;
  PIPerceptionTimestampHelperStatics = ^IPerceptionTimestampHelperStatics;

  // Windows.Perception.IPerceptionTimestampHelperStatics2
  IPerceptionTimestampHelperStatics2 = interface;
  PIPerceptionTimestampHelperStatics2 = ^IPerceptionTimestampHelperStatics2;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialRay>
  IReference_1__Spatial_SpatialRay = interface;
  PIReference_1__Spatial_SpatialRay = ^IReference_1__Spatial_SpatialRay;

  // Windows.Perception.People.IHeadPose
  People_IHeadPose = interface;
  PPeople_IHeadPose = ^People_IHeadPose;

  // Windows.Perception.Spatial.ISpatialAnchorRawCoordinateSystemAdjustedEventArgs
  Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = interface;
  PSpatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = ^Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.ISpatialAnchor,Windows.Perception.Spatial.ISpatialAnchorRawCoordinateSystemAdjustedEventArgs>
  TypedEventHandler_2__Spatial_ISpatialAnchor__Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = interface;
  PTypedEventHandler_2__Spatial_ISpatialAnchor__Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = ^TypedEventHandler_2__Spatial_ISpatialAnchor__Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs;

  // Windows.Perception.Spatial.ISpatialAnchor
  Spatial_ISpatialAnchor = interface;
  PSpatial_ISpatialAnchor = ^Spatial_ISpatialAnchor;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.SpatialPerceptionAccessStatus>
  AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus = ^AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.SpatialPerceptionAccessStatus>
  IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus = interface;
  PIAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus = ^IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>
  IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PIKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = ^IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IIterator_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = ^IIterator_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IIterable_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = ^IIterable_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>
  IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PIMapView_2__HSTRING__Spatial_ISpatialAnchor = ^IMapView_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Perception.Spatial.ISpatialAnchorStore
  Spatial_ISpatialAnchorStore = interface;
  PSpatial_ISpatialAnchorStore = ^Spatial_ISpatialAnchorStore;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.ISpatialAnchorStore>
  AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore = interface;
  PAsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore = ^AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore;

  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.ISpatialAnchorStore>
  IAsyncOperation_1__Spatial_ISpatialAnchorStore = interface;
  PIAsyncOperation_1__Spatial_ISpatialAnchorStore = ^IAsyncOperation_1__Spatial_ISpatialAnchorStore;

  // Windows.Perception.Spatial.ISpatialAnchorManagerStatics
  Spatial_ISpatialAnchorManagerStatics = interface;
  PSpatial_ISpatialAnchorManagerStatics = ^Spatial_ISpatialAnchorManagerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PAsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = ^AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IAsyncOperation_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface;
  PIAsyncOperation_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = ^IAsyncOperation_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor;

  // Windows.Perception.Spatial.ISpatialBoundingVolume
  Spatial_ISpatialBoundingVolume = interface;
  PSpatial_ISpatialBoundingVolume = ^Spatial_ISpatialBoundingVolume;

  // Windows.Perception.Spatial.ISpatialEntity
  Spatial_ISpatialEntity = interface;
  PSpatial_ISpatialEntity = ^Spatial_ISpatialEntity;

  // Windows.Perception.Spatial.ISpatialEntityFactory
  Spatial_ISpatialEntityFactory = interface;
  PSpatial_ISpatialEntityFactory = ^Spatial_ISpatialEntityFactory;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingOrientedBox>
  IReference_1__Spatial_SpatialBoundingOrientedBox = interface;
  PIReference_1__Spatial_SpatialBoundingOrientedBox = ^IReference_1__Spatial_SpatialBoundingOrientedBox;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshBuffer
  Spatial_Surfaces_ISpatialSurfaceMeshBuffer = interface;
  PSpatial_Surfaces_ISpatialSurfaceMeshBuffer = ^Spatial_Surfaces_ISpatialSurfaceMeshBuffer;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh
  Spatial_Surfaces_ISpatialSurfaceMesh = interface;
  PSpatial_Surfaces_ISpatialSurfaceMesh = ^Spatial_Surfaces_ISpatialSurfaceMesh;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh>
  AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh = interface;
  PAsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh = ^AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh;

  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh>
  IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh = interface;
  PIAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh = ^IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptions
  Spatial_Surfaces_ISpatialSurfaceMeshOptions = interface;
  PSpatial_Surfaces_ISpatialSurfaceMeshOptions = ^Spatial_Surfaces_ISpatialSurfaceMeshOptions;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo
  Spatial_Surfaces_ISpatialSurfaceInfo = interface;
  PSpatial_Surfaces_ISpatialSurfaceInfo = ^Spatial_Surfaces_ISpatialSurfaceInfo;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptionsStatics
  Spatial_Surfaces_ISpatialSurfaceMeshOptionsStatics = interface;
  PSpatial_Surfaces_ISpatialSurfaceMeshOptionsStatics = ^Spatial_Surfaces_ISpatialSurfaceMeshOptionsStatics;

  // Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>
  IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface;
  PIKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = ^IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>>
  IIterator_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface;
  PIIterator_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = ^IIterator_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>>
  IIterable_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface;
  PIIterable_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = ^IIterable_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo;

  // Windows.Foundation.Collections.IMapView`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>
  IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface;
  PIMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = ^IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo;

  // Windows.Foundation.Collections.IIterator`1<Windows.Perception.Spatial.ISpatialBoundingVolume>
  IIterator_1__Spatial_ISpatialBoundingVolume = interface;
  PIIterator_1__Spatial_ISpatialBoundingVolume = ^IIterator_1__Spatial_ISpatialBoundingVolume;

  // Windows.Foundation.Collections.IIterable`1<Windows.Perception.Spatial.ISpatialBoundingVolume>
  IIterable_1__Spatial_ISpatialBoundingVolume = interface;
  PIIterable_1__Spatial_ISpatialBoundingVolume = ^IIterable_1__Spatial_ISpatialBoundingVolume;

  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserver,Object>
  TypedEventHandler_2__Spatial_Surfaces_ISpatialSurfaceObserver__IInspectable = interface;
  PTypedEventHandler_2__Spatial_Surfaces_ISpatialSurfaceObserver__IInspectable = ^TypedEventHandler_2__Spatial_Surfaces_ISpatialSurfaceObserver__IInspectable;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserver
  Spatial_Surfaces_ISpatialSurfaceObserver = interface;
  PSpatial_Surfaces_ISpatialSurfaceObserver = ^Spatial_Surfaces_ISpatialSurfaceObserver;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics
  Spatial_Surfaces_ISpatialSurfaceObserverStatics = interface;
  PSpatial_Surfaces_ISpatialSurfaceObserverStatics = ^Spatial_Surfaces_ISpatialSurfaceObserverStatics;

  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics2
  Spatial_Surfaces_ISpatialSurfaceObserverStatics2 = interface;
  PSpatial_Surfaces_ISpatialSurfaceObserverStatics2 = ^Spatial_Surfaces_ISpatialSurfaceObserverStatics2;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingBox>
  IReference_1__Spatial_SpatialBoundingBox = interface;
  PIReference_1__Spatial_SpatialBoundingBox = ^IReference_1__Spatial_SpatialBoundingBox;

  // Windows.Perception Enums

  // Windows.Perception.People.HandJointKind
  People_HandJointKind = (
    Palm = 0,
    Wrist = 1,
    ThumbMetacarpal = 2,
    ThumbProximal = 3,
    ThumbDistal = 4,
    ThumbTip = 5,
    IndexMetacarpal = 6,
    IndexProximal = 7,
    IndexIntermediate = 8,
    IndexDistal = 9,
    IndexTip = 10,
    MiddleMetacarpal = 11,
    MiddleProximal = 12,
    MiddleIntermediate = 13,
    MiddleDistal = 14,
    MiddleTip = 15,
    RingMetacarpal = 16,
    RingProximal = 17,
    RingIntermediate = 18,
    RingDistal = 19,
    RingTip = 20,
    LittleMetacarpal = 21,
    LittleProximal = 22,
    LittleIntermediate = 23,
    LittleDistal = 24,
    LittleTip = 25
  );
  PPeople_HandJointKind = ^People_HandJointKind;

  // Windows.Perception.People.JointPoseAccuracy
  People_JointPoseAccuracy = (
    High = 0,
    Approximate = 1
  );
  PPeople_JointPoseAccuracy = ^People_JointPoseAccuracy;

  // Windows.Perception.Spatial.SpatialAnchorExportPurpose
  Spatial_SpatialAnchorExportPurpose = (
    Relocalization = 0,
    Sharing = 1
  );
  PSpatial_SpatialAnchorExportPurpose = ^Spatial_SpatialAnchorExportPurpose;

  // Windows.Perception.Spatial.SpatialEntityWatcherStatus
  Spatial_SpatialEntityWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopping = 3,
    Stopped = 4,
    Aborted = 5
  );
  PSpatial_SpatialEntityWatcherStatus = ^Spatial_SpatialEntityWatcherStatus;

  // Windows.Perception.Spatial.SpatialLocatability
  Spatial_SpatialLocatability = (
    Unavailable = 0,
    OrientationOnly = 1,
    PositionalTrackingActivating = 2,
    PositionalTrackingActive = 3,
    PositionalTrackingInhibited = 4
  );
  PSpatial_SpatialLocatability = ^Spatial_SpatialLocatability;

  // Windows.Perception.Spatial.SpatialLookDirectionRange
  Spatial_SpatialLookDirectionRange = (
    ForwardOnly = 0,
    Omnidirectional = 1
  );
  PSpatial_SpatialLookDirectionRange = ^Spatial_SpatialLookDirectionRange;

  // Windows.Perception.Spatial.SpatialMovementRange
  Spatial_SpatialMovementRange = (
    NoMovement = 0,
    Bounded = 1
  );
  PSpatial_SpatialMovementRange = ^Spatial_SpatialMovementRange;

  // Windows.Perception.Spatial.SpatialPerceptionAccessStatus
  Spatial_SpatialPerceptionAccessStatus = (
    Unspecified = 0,
    Allowed = 1,
    DeniedByUser = 2,
    DeniedBySystem = 3
  );
  PSpatial_SpatialPerceptionAccessStatus = ^Spatial_SpatialPerceptionAccessStatus;

  // Windows.Perception Records

  // Windows.Perception.Automation.Core.PerceptionAutomationCoreContract
  Automation_Core_PerceptionAutomationCoreContract = record
  end;
  PAutomation_Core_PerceptionAutomationCoreContract = ^Automation_Core_PerceptionAutomationCoreContract;

  // Windows.Perception.People.HandMeshVertex
  People_HandMeshVertex = record
    Position: Numerics_Vector3;
    Normal: Numerics_Vector3;
  end;
  PPeople_HandMeshVertex = ^People_HandMeshVertex;

  // Windows.Perception.People.JointPose
  People_JointPose = record
    Orientation: Numerics_Quaternion;
    Position: Numerics_Vector3;
    Radius: Single;
    Accuracy: People_JointPoseAccuracy;
  end;
  PPeople_JointPose = ^People_JointPose;

  // Windows.Perception.Spatial.SpatialBoundingBox
  Spatial_SpatialBoundingBox = record
    Center: Numerics_Vector3;
    Extents: Numerics_Vector3;
  end;
  PSpatial_SpatialBoundingBox = ^Spatial_SpatialBoundingBox;

  // Windows.Perception.Spatial.SpatialBoundingFrustum
  Spatial_SpatialBoundingFrustum = record
    &Near: Numerics_Plane;
    &Far: Numerics_Plane;
    Right: Numerics_Plane;
    Left: Numerics_Plane;
    Top: Numerics_Plane;
    Bottom: Numerics_Plane;
  end;
  PSpatial_SpatialBoundingFrustum = ^Spatial_SpatialBoundingFrustum;

  // Windows.Perception.Spatial.SpatialBoundingOrientedBox
  Spatial_SpatialBoundingOrientedBox = record
    Center: Numerics_Vector3;
    Extents: Numerics_Vector3;
    Orientation: Numerics_Quaternion;
  end;
  PSpatial_SpatialBoundingOrientedBox = ^Spatial_SpatialBoundingOrientedBox;

  // Windows.Perception.Spatial.SpatialBoundingSphere
  Spatial_SpatialBoundingSphere = record
    Center: Numerics_Vector3;
    Radius: Single;
  end;
  PSpatial_SpatialBoundingSphere = ^Spatial_SpatialBoundingSphere;

  // Windows.Perception.Spatial.SpatialRay
  Spatial_SpatialRay = record
    Origin: Numerics_Vector3;
    Direction: Numerics_Vector3;
  end;
  PSpatial_SpatialRay = ^Spatial_SpatialRay;

  // Windows.Perception Interfaces

  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialCoordinateSystem
  Spatial_ISpatialCoordinateSystem = interface(IInspectable)
  ['{69EBCA4B-60A3-3586-A653-59A7BD676D07}']
    function TryGetTransformTo(target: Spatial_ISpatialCoordinateSystem): IReference_1__Numerics_Matrix4x4; safecall;
  end;

  // UsedAPI Interface
  // Windows.Perception.IPerceptionTimestamp
  IPerceptionTimestamp = interface(IInspectable)
  ['{87C24804-A22E-4ADB-BA26-D78EF639BCF4}']
    function get_TargetTime: DateTime; safecall;
    function get_PredictionAmount: TimeSpan; safecall;
    property PredictionAmount: TimeSpan read get_PredictionAmount;
    property TargetTime: DateTime read get_TargetTime;
  end;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingFrustum>
  IReference_1__Spatial_SpatialBoundingFrustum = interface(IInspectable)
  ['{F434FACE-0C36-5749-A8A0-0BB6CE78A614}']
    function get_Value: Spatial_SpatialBoundingFrustum; safecall;
    property Value: Spatial_SpatialBoundingFrustum read get_Value;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Automation.Core.ICorePerceptionAutomationStatics
  [WinRTClassNameAttribute(SWindows_Perception_Automation_Core_CorePerceptionAutomation)]
  Automation_Core_ICorePerceptionAutomationStatics = interface(IInspectable)
  ['{0BB04541-4CE2-4923-9A76-8187ECC59112}']
    procedure SetActivationFactoryProvider(provider: IGetActivationFactory); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.IPerceptionTimestampHelperStatics
  [WinRTClassNameAttribute(SWindows_Perception_PerceptionTimestampHelper)]
  IPerceptionTimestampHelperStatics = interface(IInspectable)
  ['{47A611D4-A9DF-4EDC-855D-F4D339D967AC}']
    function FromHistoricalTargetTime(targetTime: DateTime): IPerceptionTimestamp; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.IPerceptionTimestampHelperStatics2
  [WinRTClassNameAttribute(SWindows_Perception_PerceptionTimestampHelper)]
  IPerceptionTimestampHelperStatics2 = interface(IInspectable)
  ['{73D1A7FE-3FB9-4571-87D4-3C920A5E86EB}']
    function FromSystemRelativeTargetTime(targetTime: TimeSpan): IPerceptionTimestamp; safecall;
  end;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialRay>
  IReference_1__Spatial_SpatialRay = interface(IInspectable)
  ['{44DD686B-C7D8-582C-91C2-D98E604DCFD4}']
    function get_Value: Spatial_SpatialRay; safecall;
    property Value: Spatial_SpatialRay read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Perception.People.IHeadPose
  People_IHeadPose = interface(IInspectable)
  ['{7F5AC5A5-49DB-379F-9429-32A2FAF34FA6}']
    function get_Position: Numerics_Vector3; safecall;
    function get_ForwardDirection: Numerics_Vector3; safecall;
    function get_UpDirection: Numerics_Vector3; safecall;
    property ForwardDirection: Numerics_Vector3 read get_ForwardDirection;
    property Position: Numerics_Vector3 read get_Position;
    property UpDirection: Numerics_Vector3 read get_UpDirection;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialAnchorRawCoordinateSystemAdjustedEventArgs
  Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = interface(IInspectable)
  ['{A1E81EB8-56C7-3117-A2E4-81E0FCF28E00}']
    function get_OldRawCoordinateSystemToNewRawCoordinateSystemTransform: Numerics_Matrix4x4; safecall;
    property OldRawCoordinateSystemToNewRawCoordinateSystemTransform: Numerics_Matrix4x4 read get_OldRawCoordinateSystemToNewRawCoordinateSystemTransform;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.SpatialAnchor,Windows.Perception.Spatial.SpatialAnchorRawCoordinateSystemAdjustedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.ISpatialAnchor,Windows.Perception.Spatial.ISpatialAnchorRawCoordinateSystemAdjustedEventArgs>
  TypedEventHandler_2__Spatial_ISpatialAnchor__Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs = interface(IUnknown)
  ['{FA43F9E4-3558-59C8-9A77-6E8B765ADCC8}']
    procedure Invoke(sender: Spatial_ISpatialAnchor; args: Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialAnchor
  Spatial_ISpatialAnchor = interface(IInspectable)
  ['{0529E5CE-1D34-3702-BCEC-EABFF578A869}']
    function get_CoordinateSystem: Spatial_ISpatialCoordinateSystem; safecall;
    function get_RawCoordinateSystem: Spatial_ISpatialCoordinateSystem; safecall;
    function add_RawCoordinateSystemAdjusted(handler: TypedEventHandler_2__Spatial_ISpatialAnchor__Spatial_ISpatialAnchorRawCoordinateSystemAdjustedEventArgs): EventRegistrationToken; safecall;
    procedure remove_RawCoordinateSystemAdjusted(cookie: EventRegistrationToken); safecall;
    property CoordinateSystem: Spatial_ISpatialCoordinateSystem read get_CoordinateSystem;
    property RawCoordinateSystem: Spatial_ISpatialCoordinateSystem read get_RawCoordinateSystem;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.SpatialPerceptionAccessStatus>
  AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus = interface(IUnknown)
  ['{6CED54C8-7689-525A-80E1-956A9D85CD83}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.SpatialPerceptionAccessStatus>
  IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus = interface(IInspectable)
  ['{B425D126-1069-563F-A863-44A30A8F071D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus; safecall;
    function GetResults: Spatial_SpatialPerceptionAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Spatial_SpatialPerceptionAccessStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>
  IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface(IInspectable)
  ['{547791A5-EF39-5BD8-A5C3-33DE743A759A}']
    function get_Key: HSTRING; safecall;
    function get_Value: Spatial_ISpatialAnchor; safecall;
    property Key: HSTRING read get_Key;
    property Value: Spatial_ISpatialAnchor read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.SpatialAnchor>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IIterator_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface(IInspectable)
  ['{67A5F318-0232-5900-AC7E-5C647D731CBC}']
    function get_Current: IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.SpatialAnchor>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IIterable_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor = interface(IInspectable)
  ['{55F0FA8A-AFD4-5541-A1C3-36F12147D606}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__Spatial_ISpatialAnchor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.SpatialAnchor>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>
  IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface(IInspectable)
  ['{2D344564-21B1-5470-B013-488CDDE45C48}']
    function Lookup(key: HSTRING): Spatial_ISpatialAnchor; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__Spatial_ISpatialAnchor; out second: IMapView_2__HSTRING__Spatial_ISpatialAnchor); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialAnchorStore
  Spatial_ISpatialAnchorStore = interface(IInspectable)
  ['{B0BC3636-486A-3CB0-9E6F-1245165C4DB6}']
    function GetAllSavedAnchors: IMapView_2__HSTRING__Spatial_ISpatialAnchor; safecall;
    function TrySave(id: HSTRING; anchor: Spatial_ISpatialAnchor): Boolean; safecall;
    procedure Remove(id: HSTRING); safecall;
    procedure Clear; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.SpatialAnchorStore>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.ISpatialAnchorStore>
  AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore = interface(IUnknown)
  ['{84C21A3A-037A-503F-8006-AB577B7F6F66}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Spatial_ISpatialAnchorStore; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.SpatialAnchorStore>
  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.ISpatialAnchorStore>
  IAsyncOperation_1__Spatial_ISpatialAnchorStore = interface(IInspectable)
  ['{1CD05E51-1457-5023-8F5D-FE5E5A953423}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore; safecall;
    function GetResults: Spatial_ISpatialAnchorStore; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Spatial_ISpatialAnchorStore read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialAnchorManagerStatics
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_SpatialAnchorManager)]
  Spatial_ISpatialAnchorManagerStatics = interface(IInspectable)
  ['{88E30EAB-F3B7-420B-B086-8A80C07D910D}']
    function RequestStoreAsync: IAsyncOperation_1__Spatial_ISpatialAnchorStore; safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.SpatialAnchor>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface(IUnknown)
  ['{3A950AA3-9C65-586E-AF75-1ACF07190E90}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.SpatialAnchor>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Windows.Perception.Spatial.ISpatialAnchor>>
  IAsyncOperation_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor = interface(IInspectable)
  ['{BBE07728-DA33-52C5-AAE0-A5E74CDF0471}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor; safecall;
    function GetResults: IMapView_2__HSTRING__Spatial_ISpatialAnchor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__Spatial_ISpatialAnchor read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialBoundingVolume
  Spatial_ISpatialBoundingVolume = interface(IInspectable)
  ['{FB2065DA-68C3-33DF-B7AF-4C787207999C}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialEntity
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_SpatialEntity)]
  Spatial_ISpatialEntity = interface(IInspectable)
  ['{166DE955-E1EB-454C-BA08-E6C0668DDC65}']
    function get_Id: HSTRING; safecall;
    function get_Anchor: Spatial_ISpatialAnchor; safecall;
    function get_Properties: IPropertySet; safecall;
    property Anchor: Spatial_ISpatialAnchor read get_Anchor;
    property Id: HSTRING read get_Id;
    property Properties: IPropertySet read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.ISpatialEntityFactory
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_SpatialEntity)]
  Spatial_ISpatialEntityFactory = interface(IInspectable)
  ['{E1F1E325-349F-4225-A2F3-4B01C15FE056}']
    function CreateWithSpatialAnchor(spatialAnchor: Spatial_ISpatialAnchor): Spatial_ISpatialEntity; safecall;
    function CreateWithSpatialAnchorAndProperties(spatialAnchor: Spatial_ISpatialAnchor; propertySet: IPropertySet): Spatial_ISpatialEntity; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingOrientedBox>
  IReference_1__Spatial_SpatialBoundingOrientedBox = interface(IInspectable)
  ['{09F88309-9F81-5207-BDB2-ABEF926DB18F}']
    function get_Value: Spatial_SpatialBoundingOrientedBox; safecall;
    property Value: Spatial_SpatialBoundingOrientedBox read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshBuffer
  Spatial_Surfaces_ISpatialSurfaceMeshBuffer = interface(IInspectable)
  ['{93CF59E0-871F-33F8-98B2-03D101458F6F}']
    function get_Format: DirectX_DirectXPixelFormat; safecall;
    function get_Stride: Cardinal; safecall;
    function get_ElementCount: Cardinal; safecall;
    function get_Data: IBuffer; safecall;
    property Data: IBuffer read get_Data;
    property ElementCount: Cardinal read get_ElementCount;
    property Format: DirectX_DirectXPixelFormat read get_Format;
    property Stride: Cardinal read get_Stride;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh
  Spatial_Surfaces_ISpatialSurfaceMesh = interface(IInspectable)
  ['{108F57D9-DF0D-3950-A0FD-F972C77C27B4}']
    function get_SurfaceInfo: Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
    function get_CoordinateSystem: Spatial_ISpatialCoordinateSystem; safecall;
    function get_TriangleIndices: Spatial_Surfaces_ISpatialSurfaceMeshBuffer; safecall;
    function get_VertexPositions: Spatial_Surfaces_ISpatialSurfaceMeshBuffer; safecall;
    function get_VertexPositionScale: Numerics_Vector3; safecall;
    function get_VertexNormals: Spatial_Surfaces_ISpatialSurfaceMeshBuffer; safecall;
    property CoordinateSystem: Spatial_ISpatialCoordinateSystem read get_CoordinateSystem;
    property SurfaceInfo: Spatial_Surfaces_ISpatialSurfaceInfo read get_SurfaceInfo;
    property TriangleIndices: Spatial_Surfaces_ISpatialSurfaceMeshBuffer read get_TriangleIndices;
    property VertexNormals: Spatial_Surfaces_ISpatialSurfaceMeshBuffer read get_VertexNormals;
    property VertexPositionScale: Numerics_Vector3 read get_VertexPositionScale;
    property VertexPositions: Spatial_Surfaces_ISpatialSurfaceMeshBuffer read get_VertexPositions;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.Surfaces.SpatialSurfaceMesh>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh>
  AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh = interface(IUnknown)
  ['{4680F7F6-44C5-5FC6-8D51-D6962915FA23}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.Surfaces.SpatialSurfaceMesh>
  // Windows.Foundation.IAsyncOperation`1<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMesh>
  IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh = interface(IInspectable)
  ['{F5938FAD-A8A1-5F7E-9440-BDB781AD26B6}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh; safecall;
    function GetResults: Spatial_Surfaces_ISpatialSurfaceMesh; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Spatial_Surfaces_ISpatialSurfaceMesh read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptions
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_Surfaces_SpatialSurfaceMeshOptions)]
  Spatial_Surfaces_ISpatialSurfaceMeshOptions = interface(IInspectable)
  ['{D2759F89-3572-3D2D-A10D-5FEE9394AA37}']
    function get_VertexPositionFormat: DirectX_DirectXPixelFormat; safecall;
    procedure put_VertexPositionFormat(value: DirectX_DirectXPixelFormat); safecall;
    function get_TriangleIndexFormat: DirectX_DirectXPixelFormat; safecall;
    procedure put_TriangleIndexFormat(value: DirectX_DirectXPixelFormat); safecall;
    function get_VertexNormalFormat: DirectX_DirectXPixelFormat; safecall;
    procedure put_VertexNormalFormat(value: DirectX_DirectXPixelFormat); safecall;
    function get_IncludeVertexNormals: Boolean; safecall;
    procedure put_IncludeVertexNormals(value: Boolean); safecall;
    property IncludeVertexNormals: Boolean read get_IncludeVertexNormals write put_IncludeVertexNormals;
    property TriangleIndexFormat: DirectX_DirectXPixelFormat read get_TriangleIndexFormat write put_TriangleIndexFormat;
    property VertexNormalFormat: DirectX_DirectXPixelFormat read get_VertexNormalFormat write put_VertexNormalFormat;
    property VertexPositionFormat: DirectX_DirectXPixelFormat read get_VertexPositionFormat write put_VertexPositionFormat;
  end;

  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo
  Spatial_Surfaces_ISpatialSurfaceInfo = interface(IInspectable)
  ['{F8E9EBE7-39B7-3962-BB03-57F56E1FB0A1}']
    function get_Id: TGuid; safecall;
    function get_UpdateTime: DateTime; safecall;
    function TryGetBounds(coordinateSystem: Spatial_ISpatialCoordinateSystem): IReference_1__Spatial_SpatialBoundingOrientedBox; safecall;
    function TryComputeLatestMeshAsync(maxTrianglesPerCubicMeter: Double): IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh; overload; safecall;
    function TryComputeLatestMeshAsync(maxTrianglesPerCubicMeter: Double; options: Spatial_Surfaces_ISpatialSurfaceMeshOptions): IAsyncOperation_1__Spatial_Surfaces_ISpatialSurfaceMesh; overload; safecall;
    property Id: TGuid read get_Id;
    property UpdateTime: DateTime read get_UpdateTime;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptionsStatics
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_Surfaces_SpatialSurfaceMeshOptions)]
  Spatial_Surfaces_ISpatialSurfaceMeshOptionsStatics = interface(IInspectable)
  ['{9B340ABF-9781-4505-8935-013575CAAE5E}']
    function get_SupportedVertexPositionFormats: IVectorView_1__DirectX_DirectXPixelFormat; safecall;
    function get_SupportedTriangleIndexFormats: IVectorView_1__DirectX_DirectXPixelFormat; safecall;
    function get_SupportedVertexNormalFormats: IVectorView_1__DirectX_DirectXPixelFormat; safecall;
    property SupportedTriangleIndexFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedTriangleIndexFormats;
    property SupportedVertexNormalFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedVertexNormalFormats;
    property SupportedVertexPositionFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedVertexPositionFormats;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>
  IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface(IInspectable)
  ['{6C8FA36F-82E6-5DDC-8F0E-7646469A4C4B}']
    function get_Key: TGuid; safecall;
    function get_Value: Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
    property Key: TGuid read get_Key;
    property Value: Spatial_Surfaces_ISpatialSurfaceInfo read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.SpatialSurfaceInfo>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>>
  IIterator_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface(IInspectable)
  ['{6D328390-F279-5F39-9682-BBA0CD81489B}']
    function get_Current: IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo): Cardinal; safecall;
    property Current: IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.SpatialSurfaceInfo>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>>
  IIterable_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface(IInspectable)
  ['{868757D1-BE21-51D9-8DEE-A958B9DEEC71}']
    function First: IIterator_1__IKeyValuePair_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<Guid,Windows.Perception.Spatial.Surfaces.SpatialSurfaceInfo>
  // Windows.Foundation.Collections.IMapView`2<Guid,Windows.Perception.Spatial.Surfaces.ISpatialSurfaceInfo>
  IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo = interface(IInspectable)
  ['{EAA722B9-2859-593D-BB66-0C538E415E71}']
    function Lookup(key: TGuid): Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: TGuid): Boolean; safecall;
    procedure Split(out first: IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo; out second: IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Perception.Spatial.SpatialBoundingVolume>
  // Windows.Foundation.Collections.IIterator`1<Windows.Perception.Spatial.ISpatialBoundingVolume>
  IIterator_1__Spatial_ISpatialBoundingVolume = interface(IInspectable)
  ['{EB8385C5-0775-5415-8F76-327E6E388AC5}']
    function get_Current: Spatial_ISpatialBoundingVolume; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSpatial_ISpatialBoundingVolume): Cardinal; safecall;
    property Current: Spatial_ISpatialBoundingVolume read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Perception.Spatial.SpatialBoundingVolume>
  // Windows.Foundation.Collections.IIterable`1<Windows.Perception.Spatial.ISpatialBoundingVolume>
  IIterable_1__Spatial_ISpatialBoundingVolume = interface(IInspectable)
  ['{89E8F1EE-3A2A-5B69-A786-CDDCF7456A3A}']
    function First: IIterator_1__Spatial_ISpatialBoundingVolume; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.Surfaces.SpatialSurfaceObserver,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserver,Object>
  TypedEventHandler_2__Spatial_Surfaces_ISpatialSurfaceObserver__IInspectable = interface(IUnknown)
  ['{8B31274A-7693-52BE-9014-B0F5F65A3539}']
    procedure Invoke(sender: Spatial_Surfaces_ISpatialSurfaceObserver; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserver
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_Surfaces_SpatialSurfaceObserver)]
  Spatial_Surfaces_ISpatialSurfaceObserver = interface(IInspectable)
  ['{10B69819-DDCA-3483-AC3A-748FE8C86DF5}']
    function GetObservedSurfaces: IMapView_2__TGuid__Spatial_Surfaces_ISpatialSurfaceInfo; safecall;
    procedure SetBoundingVolume(bounds: Spatial_ISpatialBoundingVolume); safecall;
    procedure SetBoundingVolumes(bounds: IIterable_1__Spatial_ISpatialBoundingVolume); safecall;
    function add_ObservedSurfacesChanged(handler: TypedEventHandler_2__Spatial_Surfaces_ISpatialSurfaceObserver__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ObservedSurfacesChanged(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_Surfaces_SpatialSurfaceObserver)]
  Spatial_Surfaces_ISpatialSurfaceObserverStatics = interface(IInspectable)
  ['{165951ED-2108-4168-9175-87E027BC9285}']
    function RequestAccessAsync: IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics2
  [WinRTClassNameAttribute(SWindows_Perception_Spatial_Surfaces_SpatialSurfaceObserver)]
  Spatial_Surfaces_ISpatialSurfaceObserverStatics2 = interface(IInspectable)
  ['{0F534261-C55D-4E6B-A895-A19DE69A42E3}']
    function IsSupported: Boolean; safecall;
  end;

  // Windows.Foundation.IReference`1<Windows.Perception.Spatial.SpatialBoundingBox>
  IReference_1__Spatial_SpatialBoundingBox = interface(IInspectable)
  ['{AB3274D9-9B82-5396-BB00-D70C539796B3}']
    function get_Value: Spatial_SpatialBoundingBox; safecall;
    property Value: Spatial_SpatialBoundingBox read get_Value;
  end;

  // Windows.Perception.Automation.Core.CorePerceptionAutomation
  // DualAPI
  // Statics: "Windows.Perception.Automation.Core.ICorePerceptionAutomationStatics"
  TAutomation_Core_CorePerceptionAutomation = class(TWinRTGenericImportS<Automation_Core_ICorePerceptionAutomationStatics>)
  public
    {$REGION 'Automation_Core_ICorePerceptionAutomationStatics'}
    class procedure SetActivationFactoryProvider(provider: IGetActivationFactory); static; inline;
    {$ENDREGION}
 end;

  // Windows.Perception.PerceptionTimestampHelper
  // DualAPI
  // Statics: "Windows.Perception.IPerceptionTimestampHelperStatics"
  // Statics: "Windows.Perception.IPerceptionTimestampHelperStatics2"
  TPerceptionTimestampHelper = class(TWinRTGenericImportS2<IPerceptionTimestampHelperStatics, IPerceptionTimestampHelperStatics2>)
  public
    {$REGION 'IPerceptionTimestampHelperStatics'}
    class function FromHistoricalTargetTime(targetTime: DateTime): IPerceptionTimestamp; static; inline;
    {$ENDREGION}
    {$REGION 'IPerceptionTimestampHelperStatics2'}
    class function FromSystemRelativeTargetTime(targetTime: TimeSpan): IPerceptionTimestamp; static; inline;
    {$ENDREGION}
 end;

  // Windows.Perception.Spatial.SpatialAnchorManager
  // DualAPI
  // Statics: "Windows.Perception.Spatial.ISpatialAnchorManagerStatics"
  TSpatial_SpatialAnchorManager = class(TWinRTGenericImportS<Spatial_ISpatialAnchorManagerStatics>)
  public
    {$REGION 'Spatial_ISpatialAnchorManagerStatics'}
    class function RequestStoreAsync: IAsyncOperation_1__Spatial_ISpatialAnchorStore; static; inline;
    {$ENDREGION}
 end;

  // Windows.Perception.Spatial.SpatialEntity
  // DualAPI
  // Implements: Windows.Perception.Spatial.ISpatialEntity
  // Factory: "Windows.Perception.Spatial.ISpatialEntityFactory"
  TSpatial_SpatialEntity = class(TWinRTGenericImportF<Spatial_ISpatialEntityFactory>)
  public
    {$REGION 'Spatial_ISpatialEntityFactory'}
    class function CreateWithSpatialAnchor(spatialAnchor: Spatial_ISpatialAnchor): Spatial_ISpatialEntity; static; inline;
    class function CreateWithSpatialAnchorAndProperties(spatialAnchor: Spatial_ISpatialAnchor; propertySet: IPropertySet): Spatial_ISpatialEntity; static; inline;
    {$ENDREGION}
 end;

  // Windows.Perception.Spatial.Surfaces.SpatialSurfaceMeshOptions
  // DualAPI
  // Implements: Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptions
  // Statics: "Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptionsStatics"
  // Instantiable: "Spatial_Surfaces_ISpatialSurfaceMeshOptions"
  TSpatial_Surfaces_SpatialSurfaceMeshOptions = class(TWinRTGenericImportSI<Spatial_Surfaces_ISpatialSurfaceMeshOptionsStatics, Spatial_Surfaces_ISpatialSurfaceMeshOptions>)
  public
    {$REGION 'Spatial_Surfaces_ISpatialSurfaceMeshOptionsStatics'}
    class function get_SupportedVertexPositionFormats: IVectorView_1__DirectX_DirectXPixelFormat; static; inline;
    class function get_SupportedTriangleIndexFormats: IVectorView_1__DirectX_DirectXPixelFormat; static; inline;
    class function get_SupportedVertexNormalFormats: IVectorView_1__DirectX_DirectXPixelFormat; static; inline;
    class property SupportedTriangleIndexFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedTriangleIndexFormats;
    class property SupportedVertexNormalFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedVertexNormalFormats;
    class property SupportedVertexPositionFormats: IVectorView_1__DirectX_DirectXPixelFormat read get_SupportedVertexPositionFormats;
    {$ENDREGION}
 end;

  // Windows.Perception.Spatial.Surfaces.SpatialSurfaceObserver
  // DualAPI
  // Implements: Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserver
  // Statics: "Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics"
  // Statics: "Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics2"
  // Instantiable: "Spatial_Surfaces_ISpatialSurfaceObserver"
  TSpatial_Surfaces_SpatialSurfaceObserver = class(TWinRTGenericImportS2I<Spatial_Surfaces_ISpatialSurfaceObserverStatics, Spatial_Surfaces_ISpatialSurfaceObserverStatics2, Spatial_Surfaces_ISpatialSurfaceObserver>)
  public
    {$REGION 'Spatial_Surfaces_ISpatialSurfaceObserverStatics'}
    class function RequestAccessAsync: IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus; static; inline;
    {$ENDREGION}
    {$REGION 'Spatial_Surfaces_ISpatialSurfaceObserverStatics2'}
    class function IsSupported: Boolean; static; inline;
    {$ENDREGION}
 end;

implementation

{ TAutomation_Core_CorePerceptionAutomation }

{$REGION 'Windows.Perception.Automation.Core.ICorePerceptionAutomationStatics'}
class procedure TAutomation_Core_CorePerceptionAutomation.SetActivationFactoryProvider(provider: IGetActivationFactory);
begin
  Statics.SetActivationFactoryProvider(provider);
end;
{$ENDREGION}

{ TPerceptionTimestampHelper }

{$REGION 'Windows.Perception.IPerceptionTimestampHelperStatics'}
class function TPerceptionTimestampHelper.FromHistoricalTargetTime(targetTime: DateTime): IPerceptionTimestamp;
begin
  Result := Statics.FromHistoricalTargetTime(targetTime);
end;

{$ENDREGION}

{$REGION 'Windows.Perception.IPerceptionTimestampHelperStatics2'}
class function TPerceptionTimestampHelper.FromSystemRelativeTargetTime(targetTime: TimeSpan): IPerceptionTimestamp;
begin
  Result := Statics2.FromSystemRelativeTargetTime(targetTime);
end;
{$ENDREGION}

{ TSpatial_SpatialAnchorManager }

{$REGION 'Windows.Perception.Spatial.ISpatialAnchorManagerStatics'}
class function TSpatial_SpatialAnchorManager.RequestStoreAsync: IAsyncOperation_1__Spatial_ISpatialAnchorStore;
begin
  Result := Statics.RequestStoreAsync;
end;
{$ENDREGION}

{ TSpatial_SpatialEntity }

{$REGION 'Windows.Perception.Spatial.ISpatialEntityFactory'}
// Factory: "Windows.Perception.Spatial.ISpatialEntityFactory"
// -> Spatial_ISpatialEntityFactory

class function TSpatial_SpatialEntity.CreateWithSpatialAnchor(spatialAnchor: Spatial_ISpatialAnchor): Spatial_ISpatialEntity;
begin
  Result := Factory.CreateWithSpatialAnchor(spatialAnchor);
end;

class function TSpatial_SpatialEntity.CreateWithSpatialAnchorAndProperties(spatialAnchor: Spatial_ISpatialAnchor; propertySet: IPropertySet): Spatial_ISpatialEntity;
begin
  Result := Factory.CreateWithSpatialAnchorAndProperties(spatialAnchor, propertySet);
end;
{$ENDREGION}

{ TSpatial_Surfaces_SpatialSurfaceMeshOptions }

{$REGION 'Windows.Perception.Spatial.Surfaces.ISpatialSurfaceMeshOptionsStatics'}
class function TSpatial_Surfaces_SpatialSurfaceMeshOptions.get_SupportedVertexPositionFormats: IVectorView_1__DirectX_DirectXPixelFormat;
begin
  Result := Statics.get_SupportedVertexPositionFormats;
end;

class function TSpatial_Surfaces_SpatialSurfaceMeshOptions.get_SupportedTriangleIndexFormats: IVectorView_1__DirectX_DirectXPixelFormat;
begin
  Result := Statics.get_SupportedTriangleIndexFormats;
end;

class function TSpatial_Surfaces_SpatialSurfaceMeshOptions.get_SupportedVertexNormalFormats: IVectorView_1__DirectX_DirectXPixelFormat;
begin
  Result := Statics.get_SupportedVertexNormalFormats;
end;
{$ENDREGION}

{ TSpatial_Surfaces_SpatialSurfaceObserver }

{$REGION 'Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics'}
class function TSpatial_Surfaces_SpatialSurfaceObserver.RequestAccessAsync: IAsyncOperation_1__Spatial_SpatialPerceptionAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;

{$ENDREGION}

{$REGION 'Windows.Perception.Spatial.Surfaces.ISpatialSurfaceObserverStatics2'}
class function TSpatial_Surfaces_SpatialSurfaceObserver.IsSupported: Boolean;
begin
  Result := Statics2.IsSupported;
end;
{$ENDREGION}

end.
