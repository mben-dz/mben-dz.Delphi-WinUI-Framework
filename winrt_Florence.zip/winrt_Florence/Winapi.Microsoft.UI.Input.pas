{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Microsoft.UI.Input;

{$WEAKPACKAGEUNIT ON}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Microsoft.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  HoldingState = Winapi.Microsoft.CommonTypes.HoldingState;
  PHoldingState = Winapi.Microsoft.CommonTypes.PHoldingState;
  IPointerPoint = Winapi.Microsoft.CommonTypes.IPointerPoint;
  PIPointerPoint = Winapi.Microsoft.CommonTypes.PIPointerPoint;
  IPointerPointProperties = Winapi.Microsoft.CommonTypes.IPointerPointProperties;
  PIPointerPointProperties = Winapi.Microsoft.CommonTypes.PIPointerPointProperties;
  IPointerPointTransform = Winapi.Microsoft.CommonTypes.IPointerPointTransform;
  PIPointerPointTransform = Winapi.Microsoft.CommonTypes.PIPointerPointTransform;
  IVector_1__IPointerPoint = Winapi.Microsoft.CommonTypes.IVector_1__IPointerPoint;
  IVectorView_1__IPointerPoint = Winapi.Microsoft.CommonTypes.IVectorView_1__IPointerPoint;
  PIVectorView_1__IPointerPoint = Winapi.Microsoft.CommonTypes.PIVectorView_1__IPointerPoint;
  ManipulationDelta = Winapi.Microsoft.CommonTypes.ManipulationDelta;
  PManipulationDelta = Winapi.Microsoft.CommonTypes.PManipulationDelta;
  ManipulationVelocities = Winapi.Microsoft.CommonTypes.ManipulationVelocities;
  PManipulationVelocities = Winapi.Microsoft.CommonTypes.PManipulationVelocities;
  PointerDeviceType = Winapi.Microsoft.CommonTypes.PointerDeviceType;
  PPointerDeviceType = Winapi.Microsoft.CommonTypes.PPointerDeviceType;
  PointerUpdateKind = Winapi.Microsoft.CommonTypes.PointerUpdateKind;
  PPointerUpdateKind = Winapi.Microsoft.CommonTypes.PPointerUpdateKind;

  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Input.IPointerPoint>
  IIterator_1__IPointerPoint = interface;
  PIIterator_1__IPointerPoint = ^IIterator_1__IPointerPoint;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Input.IPointerPoint>
  IIterable_1__IPointerPoint = interface;
  PIIterable_1__IPointerPoint = ^IIterable_1__IPointerPoint;

  // Microsoft.UI.Input.IInputCursor
  IInputCursor = interface;
  PIInputCursor = ^IInputCursor;

  // Microsoft.UI.Input.IPointerEventArgs
  IPointerEventArgs = interface;
  PIPointerEventArgs = ^IPointerEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Input.IInputPointerSource,Microsoft.UI.Input.IPointerEventArgs>
  TypedEventHandler_2__IInputPointerSource__IPointerEventArgs = interface;
  PTypedEventHandler_2__IInputPointerSource__IPointerEventArgs = ^TypedEventHandler_2__IInputPointerSource__IPointerEventArgs;

  // Microsoft.UI.Input.IInputPointerSource
  IInputPointerSource = interface;
  PIInputPointerSource = ^IInputPointerSource;

  // Microsoft.UI.Input.IInputCursorFactory
  IInputCursorFactory = interface;
  PIInputCursorFactory = ^IInputCursorFactory;

  // Microsoft.UI.Input.IInputCustomCursorFactory
  IInputCustomCursorFactory = interface;
  PIInputCustomCursorFactory = ^IInputCustomCursorFactory;

  // Microsoft.UI.Input.IInputObjectFactory
  IInputObjectFactory = interface;
  PIInputObjectFactory = ^IInputObjectFactory;

  // Microsoft.UI.Input Enums

  // Microsoft.UI.Input.CrossSlidingState
  CrossSlidingState = (
    Started = 0,
    Dragging = 1,
    Selecting = 2,
    SelectSpeedBumping = 3,
    SpeedBumping = 4,
    Rearranging = 5,
    Completed = 6
  );
  PCrossSlidingState = ^CrossSlidingState;

  // Microsoft.UI.Input.DragDrop.DragDropModifiers
  DragDrop_DragDropModifiers = (
    None = 0,
    Shift = 1,
    Control = 2,
    Alt = 4,
    LeftButton = 8,
    MiddleButton = 16,
    RightButton = 32
  );
  PDragDrop_DragDropModifiers = ^DragDrop_DragDropModifiers;

  // Microsoft.UI.Input.DragDrop.DragUIContentMode
  DragDrop_DragUIContentMode = (
    Auto = 0,
    Deferred = 1
  );
  PDragDrop_DragUIContentMode = ^DragDrop_DragUIContentMode;

  // Microsoft.UI.Input.DraggingState
  DraggingState = (
    Started = 0,
    Continuing = 1,
    Completed = 2
  );
  PDraggingState = ^DraggingState;

  // Microsoft.UI.Input.FocusNavigationReason
  FocusNavigationReason = (
    Programmatic = 0,
    Restore = 1,
    First = 2,
    Last = 3,
    Left = 4,
    Up = 5,
    Right = 6,
    Down = 7
  );
  PFocusNavigationReason = ^FocusNavigationReason;

  // Microsoft.UI.Input.FocusNavigationResult
  FocusNavigationResult = (
    NotMoved = 0,
    Moved = 1,
    NoFocusableElements = 2
  );
  PFocusNavigationResult = ^FocusNavigationResult;

  // Microsoft.UI.Input.GestureSettings
  GestureSettings = (
    None = 0,
    Tap = 1,
    DoubleTap = 2,
    Hold = 4,
    HoldWithMouse = 8,
    RightTap = 16,
    Drag = 32,
    ManipulationTranslateX = 64,
    ManipulationTranslateY = 128,
    ManipulationTranslateRailsX = 256,
    ManipulationTranslateRailsY = 512,
    ManipulationRotate = 1024,
    ManipulationScale = 2048,
    ManipulationTranslateInertia = 4096,
    ManipulationRotateInertia = 8192,
    ManipulationScaleInertia = 16384,
    CrossSlide = 32768,
    ManipulationMultipleFingerPanning = 65536
  );
  PGestureSettings = ^GestureSettings;

  // Microsoft.UI.Input.InputActivationState
  InputActivationState = (
    None = 0,
    Deactivated = 1,
    Activated = 2
  );
  PInputActivationState = ^InputActivationState;

  // Microsoft.UI.Input.InputPointerSourceDeviceKinds
  InputPointerSourceDeviceKinds = (
    None = 0,
    Touch = 1,
    Pen = 2,
    Mouse = 4
  );
  PInputPointerSourceDeviceKinds = ^InputPointerSourceDeviceKinds;

  // Microsoft.UI.Input.InputSystemCursorShape
  InputSystemCursorShape = (
    Arrow = 0,
    Cross = 1,
    Hand = 3,
    Help = 4,
    IBeam = 5,
    SizeAll = 6,
    SizeNortheastSouthwest = 7,
    SizeNorthSouth = 8,
    SizeNorthwestSoutheast = 9,
    SizeWestEast = 10,
    UniversalNo = 11,
    UpArrow = 12,
    Wait = 13,
    Pin = 14,
    Person = 15,
    AppStarting = 16
  );
  PInputSystemCursorShape = ^InputSystemCursorShape;

  // Microsoft.UI.Input.MoveSizeOperation
  MoveSizeOperation = (
    Move = 0,
    SizeBottom = 1,
    SizeBottomLeft = 2,
    SizeBottomRight = 3,
    SizeLeft = 4,
    SizeRight = 5,
    SizeTop = 6,
    SizeTopLeft = 7,
    SizeTopRight = 8
  );
  PMoveSizeOperation = ^MoveSizeOperation;

  // Microsoft.UI.Input.NonClientRegionKind
  NonClientRegionKind = (
    Close = 0,
    Maximize = 1,
    Minimize = 2,
    Icon = 3,
    Caption = 4,
    TopBorder = 5,
    LeftBorder = 6,
    BottomBorder = 7,
    RightBorder = 8,
    Passthrough = 9
  );
  PNonClientRegionKind = ^NonClientRegionKind;

  // Microsoft.UI.Input.VirtualKeyStates
  VirtualKeyStates = (
    None = 0,
    Down = 1,
    Locked = 2
  );
  PVirtualKeyStates = ^VirtualKeyStates;

  // Microsoft.UI.Input Records

  // Microsoft.UI.Input.CrossSlideThresholds
  CrossSlideThresholds = record
    SelectionStart: Single;
    SpeedBumpStart: Single;
    SpeedBumpEnd: Single;
    RearrangeStart: Single;
  end;
  PCrossSlideThresholds = ^CrossSlideThresholds;

  // Microsoft.UI.Input.PhysicalKeyStatus
  PhysicalKeyStatus = record
    RepeatCount: Cardinal;
    ScanCode: Cardinal;
    IsExtendedKey: Boolean;
    IsMenuKeyDown: Boolean;
    WasKeyDown: Boolean;
    IsKeyReleased: Boolean;
  end;
  PPhysicalKeyStatus = ^PhysicalKeyStatus;

  // Microsoft.UI.Input Interfaces

  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Input.PointerPoint>
  // Windows.Foundation.Collections.IIterator`1<Microsoft.UI.Input.IPointerPoint>
  IIterator_1__IPointerPoint = interface(IInspectable)
  ['{5B63939D-11CF-56C4-B0D0-11DF9DC487D1}']
    function get_Current: IPointerPoint; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIPointerPoint): Cardinal; safecall;
    property Current: IPointerPoint read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Input.PointerPoint>
  // Windows.Foundation.Collections.IIterable`1<Microsoft.UI.Input.IPointerPoint>
  IIterable_1__IPointerPoint = interface(IInspectable)
  ['{645ACC33-FFCE-5AD3-BE2B-C49B9C27C35D}']
    function First: IIterator_1__IPointerPoint; safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Input.IInputCursor
  IInputCursor = interface(IInspectable)
  ['{359B15F9-19C2-5714-8432-75176826406B}']
  end;

  // UsedAPI Interface
  // Microsoft.UI.Input.IPointerEventArgs
  IPointerEventArgs = interface(IInspectable)
  ['{865B188C-2ED5-5DF8-829F-AC0701D5C51A}']
    function get_CurrentPoint: IPointerPoint; safecall;
    function get_Handled: Boolean; safecall;
    procedure put_Handled(value: Boolean); safecall;
    function get_KeyModifiers: VirtualKeyModifiers; safecall;
    function GetIntermediatePoints: IVector_1__IPointerPoint; safecall;
    function GetIntermediateTransformedPoints(transform: IPointerPointTransform): IVector_1__IPointerPoint; safecall;
    property CurrentPoint: IPointerPoint read get_CurrentPoint;
    property Handled: Boolean read get_Handled write put_Handled;
    property KeyModifiers: VirtualKeyModifiers read get_KeyModifiers;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Input.InputPointerSource,Microsoft.UI.Input.PointerEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.UI.Input.IInputPointerSource,Microsoft.UI.Input.IPointerEventArgs>
  TypedEventHandler_2__IInputPointerSource__IPointerEventArgs = interface(IUnknown)
  ['{040480BE-4741-587D-9888-8694414A2650}']
    procedure Invoke(sender: IInputPointerSource; args: IPointerEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.UI.Input.IInputPointerSource
  IInputPointerSource = interface(IInspectable)
  ['{6A6C2764-C3F4-5BE5-8447-C9A98766C240}']
    function get_Cursor: IInputCursor; safecall;
    procedure put_Cursor(value: IInputCursor); safecall;
    function get_DeviceKinds: InputPointerSourceDeviceKinds; safecall;
    function add_PointerCaptureLost(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerCaptureLost(token: EventRegistrationToken); safecall;
    function add_PointerEntered(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerEntered(token: EventRegistrationToken); safecall;
    function add_PointerExited(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerExited(token: EventRegistrationToken); safecall;
    function add_PointerMoved(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerMoved(token: EventRegistrationToken); safecall;
    function add_PointerPressed(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerPressed(token: EventRegistrationToken); safecall;
    function add_PointerReleased(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerReleased(token: EventRegistrationToken); safecall;
    function add_PointerRoutedAway(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerRoutedAway(token: EventRegistrationToken); safecall;
    function add_PointerRoutedReleased(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerRoutedReleased(token: EventRegistrationToken); safecall;
    function add_PointerRoutedTo(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerRoutedTo(token: EventRegistrationToken); safecall;
    function add_PointerWheelChanged(handler: TypedEventHandler_2__IInputPointerSource__IPointerEventArgs): EventRegistrationToken; safecall;
    procedure remove_PointerWheelChanged(token: EventRegistrationToken); safecall;
    property Cursor: IInputCursor read get_Cursor write put_Cursor;
    property DeviceKinds: InputPointerSourceDeviceKinds read get_DeviceKinds;
  end;

  // Microsoft.UI.Input.IInputCursorFactory
  IInputCursorFactory = interface(IInspectable)
  ['{2F47647B-4BE0-53E9-BE7E-C38D5459DB6B}']
  end;

  // Microsoft.UI.Input.IInputCustomCursorFactory
  IInputCustomCursorFactory = interface(IInspectable)
  ['{6F402882-66E0-57D3-89D0-AA5E2FF917BC}']
  end;

  // Microsoft.UI.Input.IInputObjectFactory
  IInputObjectFactory = interface(IInspectable)
  ['{F7786BC2-B0B8-5961-9A57-AE199D452106}']
  end;

implementation

end.
