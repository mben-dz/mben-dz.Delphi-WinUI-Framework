{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Microsoft.Web.WebView2;

{$WEAKPACKAGEUNIT ON}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Microsoft.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  CoreWebView2FrameKind = Winapi.Microsoft.CommonTypes.CoreWebView2FrameKind;
  PCoreWebView2FrameKind = Winapi.Microsoft.CommonTypes.PCoreWebView2FrameKind;
  CoreWebView2ProcessFailedReason = Winapi.Microsoft.CommonTypes.CoreWebView2ProcessFailedReason;
  PCoreWebView2ProcessFailedReason = Winapi.Microsoft.CommonTypes.PCoreWebView2ProcessFailedReason;
  ICoreWebView2FrameInfo2 = Winapi.Microsoft.CommonTypes.ICoreWebView2FrameInfo2;
  PICoreWebView2FrameInfo2 = Winapi.Microsoft.CommonTypes.PICoreWebView2FrameInfo2;
  ICoreWebView2NavigationCompletedEventArgs2 = Winapi.Microsoft.CommonTypes.ICoreWebView2NavigationCompletedEventArgs2;
  PICoreWebView2NavigationCompletedEventArgs2 = Winapi.Microsoft.CommonTypes.PICoreWebView2NavigationCompletedEventArgs2;
  ICoreWebView2NavigationStartingEventArgs2 = Winapi.Microsoft.CommonTypes.ICoreWebView2NavigationStartingEventArgs2;
  PICoreWebView2NavigationStartingEventArgs2 = Winapi.Microsoft.CommonTypes.PICoreWebView2NavigationStartingEventArgs2;
  ICoreWebView2PrivatePartial = Winapi.Microsoft.CommonTypes.ICoreWebView2PrivatePartial;
  PICoreWebView2PrivatePartial = Winapi.Microsoft.CommonTypes.PICoreWebView2PrivatePartial;
  ICoreWebView2ProcessFailedEventArgs2 = Winapi.Microsoft.CommonTypes.ICoreWebView2ProcessFailedEventArgs2;
  PICoreWebView2ProcessFailedEventArgs2 = Winapi.Microsoft.CommonTypes.PICoreWebView2ProcessFailedEventArgs2;
  ICoreWebView2WebMessageReceivedEventArgs2 = Winapi.Microsoft.CommonTypes.ICoreWebView2WebMessageReceivedEventArgs2;
  PICoreWebView2WebMessageReceivedEventArgs2 = Winapi.Microsoft.CommonTypes.PICoreWebView2WebMessageReceivedEventArgs2;
  IVectorView_1__ICoreWebView2FrameInfo2 = Winapi.Microsoft.CommonTypes.IVectorView_1__ICoreWebView2FrameInfo2;
  PIVectorView_1__ICoreWebView2FrameInfo2 = Winapi.Microsoft.CommonTypes.PIVectorView_1__ICoreWebView2FrameInfo2;
  TypedEventHandler_2__IWebView2__ICoreWebView2NavigationCompletedEventArgs2 = Winapi.Microsoft.CommonTypes.TypedEventHandler_2__IWebView2__ICoreWebView2NavigationCompletedEventArgs2;
  TypedEventHandler_2__IWebView2__ICoreWebView2NavigationStartingEventArgs2 = Winapi.Microsoft.CommonTypes.TypedEventHandler_2__IWebView2__ICoreWebView2NavigationStartingEventArgs2;
  TypedEventHandler_2__IWebView2__ICoreWebView2ProcessFailedEventArgs2 = Winapi.Microsoft.CommonTypes.TypedEventHandler_2__IWebView2__ICoreWebView2ProcessFailedEventArgs2;
  TypedEventHandler_2__IWebView2__ICoreWebView2WebMessageReceivedEventArgs2 = Winapi.Microsoft.CommonTypes.TypedEventHandler_2__IWebView2__ICoreWebView2WebMessageReceivedEventArgs2;

  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IIterator`1<Microsoft.Web.WebView2.Core.ICoreWebView2FrameInfo2>
  IIterator_1__ICoreWebView2FrameInfo2 = interface;
  PIIterator_1__ICoreWebView2FrameInfo2 = ^IIterator_1__ICoreWebView2FrameInfo2;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.Web.WebView2.Core.ICoreWebView2FrameInfo2>
  IIterable_1__ICoreWebView2FrameInfo2 = interface;
  PIIterable_1__ICoreWebView2FrameInfo2 = ^IIterable_1__ICoreWebView2FrameInfo2;

  // Microsoft.Web.WebView2.Core.ICoreWebView2ControllerOptions2
  ICoreWebView2ControllerOptions2 = interface;
  PICoreWebView2ControllerOptions2 = ^ICoreWebView2ControllerOptions2;

  // Microsoft.Web.WebView2.Core.ICoreWebView2Environment10
  ICoreWebView2Environment10 = interface;
  PICoreWebView2Environment10 = ^ICoreWebView2Environment10;

  // Microsoft.Web.WebView2.Core.ICoreWebView2DispatchAdapter
  ICoreWebView2DispatchAdapter = interface;
  PICoreWebView2DispatchAdapter = ^ICoreWebView2DispatchAdapter;

  // Microsoft.Web.WebView2.Core.ICoreWebView2ControllerFactory
  ICoreWebView2ControllerFactory = interface;
  PICoreWebView2ControllerFactory = ^ICoreWebView2ControllerFactory;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Object>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__IInspectable = interface;
  PTypedEventHandler_2__ICoreWebView2PrivatePartial__IInspectable = ^TypedEventHandler_2__ICoreWebView2PrivatePartial__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.CoreWebView2PrintStatus>
  AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus = interface;
  PAsyncOperationCompletedHandler_1__CoreWebView2PrintStatus = ^AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.CoreWebView2PrintStatus>
  IAsyncOperation_1__CoreWebView2PrintStatus = interface;
  PIAsyncOperation_1__CoreWebView2PrintStatus = ^IAsyncOperation_1__CoreWebView2PrintStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.CoreWebView2SaveAsUIResult>
  AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult = interface;
  PAsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult = ^AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.CoreWebView2SaveAsUIResult>
  IAsyncOperation_1__CoreWebView2SaveAsUIResult = interface;
  PIAsyncOperation_1__CoreWebView2SaveAsUIResult = ^IAsyncOperation_1__CoreWebView2SaveAsUIResult;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2NavigationStartingEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationStartingEventArgs2 = interface;
  PTypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationStartingEventArgs2 = ^TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationStartingEventArgs2;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2NavigationCompletedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationCompletedEventArgs2 = interface;
  PTypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationCompletedEventArgs2 = ^TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationCompletedEventArgs2;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2ProcessFailedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2ProcessFailedEventArgs2 = interface;
  PTypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2ProcessFailedEventArgs2 = ^TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2ProcessFailedEventArgs2;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2WebMessageReceivedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2WebMessageReceivedEventArgs2 = interface;
  PTypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2WebMessageReceivedEventArgs2 = ^TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2WebMessageReceivedEventArgs2;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10,Object>
  TypedEventHandler_2__ICoreWebView2Environment10__IInspectable = interface;
  PTypedEventHandler_2__ICoreWebView2Environment10__IInspectable = ^TypedEventHandler_2__ICoreWebView2Environment10__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10>
  AsyncOperationCompletedHandler_1__ICoreWebView2Environment10 = interface;
  PAsyncOperationCompletedHandler_1__ICoreWebView2Environment10 = ^AsyncOperationCompletedHandler_1__ICoreWebView2Environment10;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10>
  IAsyncOperation_1__ICoreWebView2Environment10 = interface;
  PIAsyncOperation_1__ICoreWebView2Environment10 = ^IAsyncOperation_1__ICoreWebView2Environment10;

  // Microsoft.Web.WebView2.Core Enums

  // Microsoft.Web.WebView2.Core.CoreWebView2WebResourceRequestSourceKinds
  CoreWebView2WebResourceRequestSourceKinds = (
    None = 0,
    Document = 1,
    SharedWorker = 2,
    ServiceWorker = 4,
    All = -1
  );
  PCoreWebView2WebResourceRequestSourceKinds = ^CoreWebView2WebResourceRequestSourceKinds;

  // Microsoft.Web.WebView2.Core.CoreWebView2WebResourceContext
  CoreWebView2WebResourceContext = (
    All = 0,
    Document = 1,
    Stylesheet = 2,
    Image = 3,
    Media = 4,
    Font = 5,
    Script = 6,
    XmlHttpRequest = 7,
    Fetch = 8,
    TextTrack = 9,
    EventSource = 10,
    Websocket = 11,
    Manifest = 12,
    SignedExchange = 13,
    Ping = 14,
    CspViolationReport = 15,
    Other = 16
  );
  PCoreWebView2WebResourceContext = ^CoreWebView2WebResourceContext;

  // Microsoft.Web.WebView2.Core.CoreWebView2WebErrorStatus
  CoreWebView2WebErrorStatus = (
    Unknown = 0,
    CertificateCommonNameIsIncorrect = 1,
    CertificateExpired = 2,
    ClientCertificateContainsErrors = 3,
    CertificateRevoked = 4,
    CertificateIsInvalid = 5,
    ServerUnreachable = 6,
    Timeout = 7,
    ErrorHttpInvalidServerResponse = 8,
    ConnectionAborted = 9,
    ConnectionReset = 10,
    Disconnected = 11,
    CannotConnect = 12,
    HostNameNotResolved = 13,
    OperationCanceled = 14,
    RedirectFailed = 15,
    UnexpectedError = 16,
    ValidAuthenticationCredentialsRequired = 17,
    ValidProxyAuthenticationRequired = 18
  );
  PCoreWebView2WebErrorStatus = ^CoreWebView2WebErrorStatus;

  // Microsoft.Web.WebView2.Core.CoreWebView2TrackingPreventionLevel
  CoreWebView2TrackingPreventionLevel = (
    None = 0,
    Basic = 1,
    Balanced = 2,
    Strict = 3
  );
  PCoreWebView2TrackingPreventionLevel = ^CoreWebView2TrackingPreventionLevel;

  // Microsoft.Web.WebView2.Core.CoreWebView2TextDirectionKind
  CoreWebView2TextDirectionKind = (
    Default = 0,
    LeftToRight = 1,
    RightToLeft = 2
  );
  PCoreWebView2TextDirectionKind = ^CoreWebView2TextDirectionKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2SharedBufferAccess
  CoreWebView2SharedBufferAccess = (
    ReadOnly = 0,
    ReadWrite = 1
  );
  PCoreWebView2SharedBufferAccess = ^CoreWebView2SharedBufferAccess;

  // Microsoft.Web.WebView2.Core.CoreWebView2ServerCertificateErrorAction
  CoreWebView2ServerCertificateErrorAction = (
    AlwaysAllow = 0,
    Cancel = 1,
    Default = 2
  );
  PCoreWebView2ServerCertificateErrorAction = ^CoreWebView2ServerCertificateErrorAction;

  // Microsoft.Web.WebView2.Core.CoreWebView2ScrollbarStyle
  CoreWebView2ScrollbarStyle = (
    Default = 0,
    FluentOverlay = 1
  );
  PCoreWebView2ScrollbarStyle = ^CoreWebView2ScrollbarStyle;

  // Microsoft.Web.WebView2.Core.CoreWebView2ScriptDialogKind
  CoreWebView2ScriptDialogKind = (
    Alert = 0,
    Confirm = 1,
    Prompt = 2,
    Beforeunload = 3
  );
  PCoreWebView2ScriptDialogKind = ^CoreWebView2ScriptDialogKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2SaveAsUIResult
  CoreWebView2SaveAsUIResult = (
    Success = 0,
    InvalidPath = 1,
    FileAlreadyExists = 2,
    KindNotSupported = 3,
    Cancelled = 4
  );
  PCoreWebView2SaveAsUIResult = ^CoreWebView2SaveAsUIResult;

  // Microsoft.Web.WebView2.Core.CoreWebView2SaveAsKind
  CoreWebView2SaveAsKind = (
    Default = 0,
    HtmlOnly = 1,
    SingleFile = 2,
    Complete = 3
  );
  PCoreWebView2SaveAsKind = ^CoreWebView2SaveAsKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ReleaseChannels
  CoreWebView2ReleaseChannels = (
    None = 0,
    Stable = 1,
    Beta = 2,
    Dev = 4,
    Canary = 8
  );
  PCoreWebView2ReleaseChannels = ^CoreWebView2ReleaseChannels;

  // Microsoft.Web.WebView2.Core.CoreWebView2ProcessKind
  CoreWebView2ProcessKind = (
    Browser = 0,
    Renderer = 1,
    Utility = 2,
    SandboxHelper = 3,
    Gpu = 4,
    PpapiPlugin = 5,
    PpapiBroker = 6
  );
  PCoreWebView2ProcessKind = ^CoreWebView2ProcessKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ProcessFailedKind
  CoreWebView2ProcessFailedKind = (
    BrowserProcessExited = 0,
    RenderProcessExited = 1,
    RenderProcessUnresponsive = 2,
    FrameRenderProcessExited = 3,
    UtilityProcessExited = 4,
    SandboxHelperProcessExited = 5,
    GpuProcessExited = 6,
    PpapiPluginProcessExited = 7,
    PpapiBrokerProcessExited = 8,
    UnknownProcessExited = 9
  );
  PCoreWebView2ProcessFailedKind = ^CoreWebView2ProcessFailedKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintStatus
  CoreWebView2PrintStatus = (
    Succeeded = 0,
    PrinterUnavailable = 1,
    OtherError = 2
  );
  PCoreWebView2PrintStatus = ^CoreWebView2PrintStatus;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintOrientation
  CoreWebView2PrintOrientation = (
    Portrait = 0,
    Landscape = 1
  );
  PCoreWebView2PrintOrientation = ^CoreWebView2PrintOrientation;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintMediaSize
  CoreWebView2PrintMediaSize = (
    Default = 0,
    Custom = 1
  );
  PCoreWebView2PrintMediaSize = ^CoreWebView2PrintMediaSize;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintDuplex
  CoreWebView2PrintDuplex = (
    Default = 0,
    OneSided = 1,
    TwoSidedLongEdge = 2,
    TwoSidedShortEdge = 3
  );
  PCoreWebView2PrintDuplex = ^CoreWebView2PrintDuplex;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintDialogKind
  CoreWebView2PrintDialogKind = (
    Browser = 0,
    System = 1
  );
  PCoreWebView2PrintDialogKind = ^CoreWebView2PrintDialogKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintColorMode
  CoreWebView2PrintColorMode = (
    Default = 0,
    Color = 1,
    Grayscale = 2
  );
  PCoreWebView2PrintColorMode = ^CoreWebView2PrintColorMode;

  // Microsoft.Web.WebView2.Core.CoreWebView2PrintCollation
  CoreWebView2PrintCollation = (
    Default = 0,
    Collated = 1,
    Uncollated = 2
  );
  PCoreWebView2PrintCollation = ^CoreWebView2PrintCollation;

  // Microsoft.Web.WebView2.Core.CoreWebView2PreferredColorScheme
  CoreWebView2PreferredColorScheme = (
    Auto = 0,
    Light = 1,
    Dark = 2
  );
  PCoreWebView2PreferredColorScheme = ^CoreWebView2PreferredColorScheme;

  // Microsoft.Web.WebView2.Core.CoreWebView2PointerEventKind
  CoreWebView2PointerEventKind = (
    Activate = 587,
    Down = 582,
    Enter = 585,
    Leave = 586,
    Up = 583,
    Update = 581
  );
  PCoreWebView2PointerEventKind = ^CoreWebView2PointerEventKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2PermissionState
  CoreWebView2PermissionState = (
    Default = 0,
    Allow = 1,
    Deny = 2
  );
  PCoreWebView2PermissionState = ^CoreWebView2PermissionState;

  // Microsoft.Web.WebView2.Core.CoreWebView2PermissionKind
  CoreWebView2PermissionKind = (
    UnknownPermission = 0,
    Microphone = 1,
    Camera = 2,
    Geolocation = 3,
    Notifications = 4,
    OtherSensors = 5,
    ClipboardRead = 6,
    MultipleAutomaticDownloads = 7,
    FileReadWrite = 8,
    Autoplay = 9,
    LocalFonts = 10,
    MidiSystemExclusiveMessages = 11,
    WindowManagement = 12
  );
  PCoreWebView2PermissionKind = ^CoreWebView2PermissionKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2PdfToolbarItems
  CoreWebView2PdfToolbarItems = (
    None = 0,
    Save = 1,
    Print = 2,
    SaveAs = 4,
    ZoomIn = 8,
    ZoomOut = 16,
    Rotate = 32,
    FitPage = 64,
    PageLayout = 128,
    Bookmarks = 256,
    PageSelector = 512,
    Search = 1024,
    FullScreen = 2048,
    MoreSettings = 4096
  );
  PCoreWebView2PdfToolbarItems = ^CoreWebView2PdfToolbarItems;

  // Microsoft.Web.WebView2.Core.CoreWebView2NonClientRegionKind
  CoreWebView2NonClientRegionKind = (
    Nowhere = 0,
    Client = 1,
    Caption = 2,
    Minimize = 8,
    Maximize = 9,
    Close = 20
  );
  PCoreWebView2NonClientRegionKind = ^CoreWebView2NonClientRegionKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2NavigationKind
  CoreWebView2NavigationKind = (
    Reload = 0,
    BackOrForward = 1,
    NewDocument = 2
  );
  PCoreWebView2NavigationKind = ^CoreWebView2NavigationKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2MoveFocusReason
  CoreWebView2MoveFocusReason = (
    Programmatic = 0,
    Next = 1,
    Previous = 2
  );
  PCoreWebView2MoveFocusReason = ^CoreWebView2MoveFocusReason;

  // Microsoft.Web.WebView2.Core.CoreWebView2MouseEventVirtualKeys
  CoreWebView2MouseEventVirtualKeys = (
    None = 0,
    LeftButton = 1,
    RightButton = 2,
    Shift = 4,
    Control = 8,
    MiddleButton = 16,
    XButton1 = 32,
    XButton2 = 64
  );
  PCoreWebView2MouseEventVirtualKeys = ^CoreWebView2MouseEventVirtualKeys;

  // Microsoft.Web.WebView2.Core.CoreWebView2MouseEventKind
  CoreWebView2MouseEventKind = (
    HorizontalWheel = 526,
    LeftButtonDoubleClick = 515,
    LeftButtonDown = 513,
    LeftButtonUp = 514,
    Leave = 675,
    MiddleButtonDoubleClick = 521,
    MiddleButtonDown = 519,
    MiddleButtonUp = 520,
    Move = 512,
    RightButtonDoubleClick = 518,
    RightButtonDown = 516,
    RightButtonUp = 517,
    Wheel = 522,
    XButtonDoubleClick = 525,
    XButtonDown = 523,
    XButtonUp = 524,
    NonClientRightButtonDown = 164,
    NonClientRightButtonUp = 165
  );
  PCoreWebView2MouseEventKind = ^CoreWebView2MouseEventKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2MemoryUsageTargetLevel
  CoreWebView2MemoryUsageTargetLevel = (
    Normal = 0,
    Low = 1
  );
  PCoreWebView2MemoryUsageTargetLevel = ^CoreWebView2MemoryUsageTargetLevel;

  // Microsoft.Web.WebView2.Core.CoreWebView2KeyEventKind
  CoreWebView2KeyEventKind = (
    KeyDown = 0,
    KeyUp = 1,
    SystemKeyDown = 2,
    SystemKeyUp = 3
  );
  PCoreWebView2KeyEventKind = ^CoreWebView2KeyEventKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2HostResourceAccessKind
  CoreWebView2HostResourceAccessKind = (
    Deny = 0,
    Allow = 1,
    DenyCors = 2
  );
  PCoreWebView2HostResourceAccessKind = ^CoreWebView2HostResourceAccessKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2FileSystemHandlePermission
  CoreWebView2FileSystemHandlePermission = (
    ReadOnly = 0,
    ReadWrite = 1
  );
  PCoreWebView2FileSystemHandlePermission = ^CoreWebView2FileSystemHandlePermission;

  // Microsoft.Web.WebView2.Core.CoreWebView2FileSystemHandleKind
  CoreWebView2FileSystemHandleKind = (
    &File = 0,
    Directory = 1
  );
  PCoreWebView2FileSystemHandleKind = ^CoreWebView2FileSystemHandleKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2FaviconImageFormat
  CoreWebView2FaviconImageFormat = (
    Png = 0,
    Jpeg = 1
  );
  PCoreWebView2FaviconImageFormat = ^CoreWebView2FaviconImageFormat;

  // Microsoft.Web.WebView2.Core.CoreWebView2DownloadState
  CoreWebView2DownloadState = (
    InProgress = 0,
    Interrupted = 1,
    Completed = 2
  );
  PCoreWebView2DownloadState = ^CoreWebView2DownloadState;

  // Microsoft.Web.WebView2.Core.CoreWebView2DownloadInterruptReason
  CoreWebView2DownloadInterruptReason = (
    None = 0,
    FileFailed = 1,
    FileAccessDenied = 2,
    FileNoSpace = 3,
    FileNameTooLong = 4,
    FileTooLarge = 5,
    FileMalicious = 6,
    FileTransientError = 7,
    FileBlockedByPolicy = 8,
    FileSecurityCheckFailed = 9,
    FileTooShort = 10,
    FileHashMismatch = 11,
    NetworkFailed = 12,
    NetworkTimeout = 13,
    NetworkDisconnected = 14,
    NetworkServerDown = 15,
    NetworkInvalidRequest = 16,
    ServerFailed = 17,
    ServerNoRange = 18,
    ServerBadContent = 19,
    ServerUnauthorized = 20,
    ServerCertificateProblem = 21,
    ServerForbidden = 22,
    ServerUnexpectedResponse = 23,
    ServerContentLengthMismatch = 24,
    ServerCrossOriginRedirect = 25,
    UserCanceled = 26,
    UserShutdown = 27,
    UserPaused = 28,
    DownloadProcessCrashed = 29
  );
  PCoreWebView2DownloadInterruptReason = ^CoreWebView2DownloadInterruptReason;

  // Microsoft.Web.WebView2.Core.CoreWebView2DefaultDownloadDialogCornerAlignment
  CoreWebView2DefaultDownloadDialogCornerAlignment = (
    TopLeft = 0,
    TopRight = 1,
    BottomLeft = 2,
    BottomRight = 3
  );
  PCoreWebView2DefaultDownloadDialogCornerAlignment = ^CoreWebView2DefaultDownloadDialogCornerAlignment;

  // Microsoft.Web.WebView2.Core.CoreWebView2CookieSameSiteKind
  CoreWebView2CookieSameSiteKind = (
    None = 0,
    Lax = 1,
    Strict = 2
  );
  PCoreWebView2CookieSameSiteKind = ^CoreWebView2CookieSameSiteKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ContextMenuTargetKind
  CoreWebView2ContextMenuTargetKind = (
    Page = 0,
    Image = 1,
    SelectedText = 2,
    Audio = 3,
    Video = 4
  );
  PCoreWebView2ContextMenuTargetKind = ^CoreWebView2ContextMenuTargetKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ContextMenuItemKind
  CoreWebView2ContextMenuItemKind = (
    Command = 0,
    CheckBox = 1,
    Radio = 2,
    Separator = 3,
    Submenu = 4
  );
  PCoreWebView2ContextMenuItemKind = ^CoreWebView2ContextMenuItemKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ClientCertificateKind
  CoreWebView2ClientCertificateKind = (
    SmartCard = 0,
    Pin = 1,
    Other = 2
  );
  PCoreWebView2ClientCertificateKind = ^CoreWebView2ClientCertificateKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2ChannelSearchKind
  CoreWebView2ChannelSearchKind = (
    MostStable = 0,
    LeastStable = 1
  );
  PCoreWebView2ChannelSearchKind = ^CoreWebView2ChannelSearchKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2CapturePreviewImageFormat
  CoreWebView2CapturePreviewImageFormat = (
    Png = 0,
    Jpeg = 1
  );
  PCoreWebView2CapturePreviewImageFormat = ^CoreWebView2CapturePreviewImageFormat;

  // Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds
  CoreWebView2BrowsingDataKinds = (
    FileSystems = 1,
    IndexedDb = 2,
    LocalStorage = 4,
    WebSql = 8,
    CacheStorage = 16,
    AllDomStorage = 32,
    Cookies = 64,
    AllSite = 128,
    DiskCache = 256,
    DownloadHistory = 512,
    GeneralAutofill = 1024,
    PasswordAutosave = 2048,
    BrowsingHistory = 4096,
    Settings = 8192,
    AllProfile = 16384,
    ServiceWorkers = 32768
  );
  PCoreWebView2BrowsingDataKinds = ^CoreWebView2BrowsingDataKinds;

  // Microsoft.Web.WebView2.Core.CoreWebView2BrowserProcessExitKind
  CoreWebView2BrowserProcessExitKind = (
    Normal = 0,
    Failed = 1
  );
  PCoreWebView2BrowserProcessExitKind = ^CoreWebView2BrowserProcessExitKind;

  // Microsoft.Web.WebView2.Core.CoreWebView2BoundsMode
  CoreWebView2BoundsMode = (
    UseRawPixels = 0,
    UseRasterizationScale = 1
  );
  PCoreWebView2BoundsMode = ^CoreWebView2BoundsMode;

  // Microsoft.Web.WebView2.Core Records

  // Microsoft.Web.WebView2.Core.CoreWebView2PhysicalKeyStatus
  CoreWebView2PhysicalKeyStatus = record
    RepeatCount: Cardinal;
    ScanCode: Cardinal;
    IsExtendedKey: Integer;
    IsMenuKeyDown: Integer;
    WasKeyDown: Integer;
    IsKeyReleased: Integer;
  end;
  PCoreWebView2PhysicalKeyStatus = ^CoreWebView2PhysicalKeyStatus;

  // Microsoft.Web.WebView2.Core Interfaces

  // Windows.Foundation.Collections.IIterator`1<Microsoft.Web.WebView2.Core.CoreWebView2FrameInfo>
  // Windows.Foundation.Collections.IIterator`1<Microsoft.Web.WebView2.Core.ICoreWebView2FrameInfo2>
  IIterator_1__ICoreWebView2FrameInfo2 = interface(IInspectable)
  ['{316A2228-6F7A-55BE-97C4-503A849D0615}']
    function get_Current: ICoreWebView2FrameInfo2; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PICoreWebView2FrameInfo2): Cardinal; safecall;
    property Current: ICoreWebView2FrameInfo2 read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Microsoft.Web.WebView2.Core.CoreWebView2FrameInfo>
  // Windows.Foundation.Collections.IIterable`1<Microsoft.Web.WebView2.Core.ICoreWebView2FrameInfo2>
  IIterable_1__ICoreWebView2FrameInfo2 = interface(IInspectable)
  ['{45C39BE3-2253-5D53-A5EA-ECBBE0BD740E}']
    function First: IIterator_1__ICoreWebView2FrameInfo2; safecall;
  end;

  // UsedAPI Interface
  // Microsoft.Web.WebView2.Core.ICoreWebView2ControllerOptions2
  ICoreWebView2ControllerOptions2 = interface(IInspectable)
  ['{41B69E93-CC17-5C7D-A0C8-FA21C27AADB6}']
    function get_ScriptLocale: HSTRING; safecall;
    procedure put_ScriptLocale(value: HSTRING); safecall;
    property ScriptLocale: HSTRING read get_ScriptLocale write put_ScriptLocale;
  end;

  // UsedAPI Interface
  // Microsoft.Web.WebView2.Core.ICoreWebView2Environment10
  ICoreWebView2Environment10 = interface(IInspectable)
  ['{C224E69C-1EFD-5ECC-ADC8-2B52E7B97CE5}']
    function CreateCoreWebView2ControllerOptions: ICoreWebView2ControllerOptions2; safecall;
  end;

  // Microsoft.Web.WebView2.Core.ICoreWebView2DispatchAdapter
  ICoreWebView2DispatchAdapter = interface(IInspectable)
  ['{7888A42D-18F3-5966-80CB-8CC25351BD0A}']
    function WrapNamedObject(name: HSTRING; adapter: ICoreWebView2DispatchAdapter): IInspectable; safecall;
    function WrapObject(unwrapped: IInspectable; adapter: ICoreWebView2DispatchAdapter): IInspectable; safecall;
    function UnwrapObject(wrapped: IInspectable): IInspectable; safecall;
    procedure Clean; safecall;
  end;

  // Microsoft.Web.WebView2.Core.ICoreWebView2ControllerFactory
  ICoreWebView2ControllerFactory = interface(IInspectable)
  ['{270B2C5B-C3A9-53D8-A5CA-262EA9EA62E8}']
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2,Object>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Object>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__IInspectable = interface(IUnknown)
  ['{141750E7-397F-57AD-BA25-FC15A2B22C3D}']
    procedure Invoke(sender: ICoreWebView2PrivatePartial; args: IInspectable); safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.CoreWebView2PrintStatus>
  AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus = interface(IUnknown)
  ['{D38D6C62-3272-54CE-BE54-E78AB2BEFE2F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__CoreWebView2PrintStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.CoreWebView2PrintStatus>
  IAsyncOperation_1__CoreWebView2PrintStatus = interface(IInspectable)
  ['{D896D604-6E00-5486-A8A9-EE599544DD16}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus; safecall;
    function GetResults: CoreWebView2PrintStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__CoreWebView2PrintStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.CoreWebView2SaveAsUIResult>
  AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult = interface(IUnknown)
  ['{CF10FA2F-B213-5B6C-B58B-2D533A876D3E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__CoreWebView2SaveAsUIResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.CoreWebView2SaveAsUIResult>
  IAsyncOperation_1__CoreWebView2SaveAsUIResult = interface(IInspectable)
  ['{E46E064D-1D9E-56A5-9BC7-05AFE991076C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult; safecall;
    function GetResults: CoreWebView2SaveAsUIResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__CoreWebView2SaveAsUIResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2,Microsoft.Web.WebView2.Core.CoreWebView2NavigationStartingEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2NavigationStartingEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationStartingEventArgs2 = interface(IUnknown)
  ['{F3F0BAA0-8862-5E4C-A51C-27C43AB4BC57}']
    procedure Invoke(sender: ICoreWebView2PrivatePartial; args: ICoreWebView2NavigationStartingEventArgs2); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2,Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2NavigationCompletedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2NavigationCompletedEventArgs2 = interface(IUnknown)
  ['{58DA20F8-B824-507D-991D-01F877607CCF}']
    procedure Invoke(sender: ICoreWebView2PrivatePartial; args: ICoreWebView2NavigationCompletedEventArgs2); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2,Microsoft.Web.WebView2.Core.CoreWebView2ProcessFailedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2ProcessFailedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2ProcessFailedEventArgs2 = interface(IUnknown)
  ['{B6A7D449-BACE-5E6E-B95E-D3B9698FB2A0}']
    procedure Invoke(sender: ICoreWebView2PrivatePartial; args: ICoreWebView2ProcessFailedEventArgs2); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2,Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2PrivatePartial,Microsoft.Web.WebView2.Core.ICoreWebView2WebMessageReceivedEventArgs2>
  TypedEventHandler_2__ICoreWebView2PrivatePartial__ICoreWebView2WebMessageReceivedEventArgs2 = interface(IUnknown)
  ['{8A6A3F9D-83C7-54B3-82DE-C5372D5B82B2}']
    procedure Invoke(sender: ICoreWebView2PrivatePartial; args: ICoreWebView2WebMessageReceivedEventArgs2); safecall;
  end;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.CoreWebView2Environment,Object>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10,Object>
  TypedEventHandler_2__ICoreWebView2Environment10__IInspectable = interface(IUnknown)
  ['{3D97E38A-5F72-5B93-8CAF-F768489CCECA}']
    procedure Invoke(sender: ICoreWebView2Environment10; args: IInspectable); safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.CoreWebView2Environment>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10>
  AsyncOperationCompletedHandler_1__ICoreWebView2Environment10 = interface(IUnknown)
  ['{4C9490CB-A410-5221-B637-695C9E4FBF71}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ICoreWebView2Environment10; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.CoreWebView2Environment>
  // Windows.Foundation.IAsyncOperation`1<Microsoft.Web.WebView2.Core.ICoreWebView2Environment10>
  IAsyncOperation_1__ICoreWebView2Environment10 = interface(IInspectable)
  ['{CFAD313C-C5BB-50A5-A37C-69A3F6119991}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ICoreWebView2Environment10); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ICoreWebView2Environment10; safecall;
    function GetResults: ICoreWebView2Environment10; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ICoreWebView2Environment10 read get_Completed write put_Completed;
  end;

implementation

end.
