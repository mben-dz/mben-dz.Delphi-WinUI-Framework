{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.ServicesRT;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Devices.Geolocation,
  Winapi.Foundation,
  Winapi.Foundation.Collections,
  Winapi.Storage.Streams,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Cortana.CortanaPermission>
  IIterator_1__Cortana_CortanaPermission = interface;
  PIIterator_1__Cortana_CortanaPermission = ^IIterator_1__Cortana_CortanaPermission;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Cortana.CortanaPermission>
  IIterable_1__Cortana_CortanaPermission = interface;
  PIIterable_1__Cortana_CortanaPermission = ^IIterable_1__Cortana_CortanaPermission;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Cortana.CortanaPermissionsChangeResult>
  AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult = interface;
  PAsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult = ^AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Cortana.CortanaPermissionsChangeResult>
  IAsyncOperation_1__Cortana_CortanaPermissionsChangeResult = interface;
  PIAsyncOperation_1__Cortana_CortanaPermissionsChangeResult = ^IAsyncOperation_1__Cortana_CortanaPermissionsChangeResult;

  // Windows.Services.Cortana.ICortanaSettings
  Cortana_ICortanaSettings = interface;
  PCortana_ICortanaSettings = ^Cortana_ICortanaSettings;

  // Windows.Services.Cortana.ICortanaSettingsStatics
  Cortana_ICortanaSettingsStatics = interface;
  PCortana_ICortanaSettingsStatics = ^Cortana_ICortanaSettingsStatics;

  // Windows.Services.Maps.IMapRouteManeuver
  Maps_IMapRouteManeuver = interface;
  PMaps_IMapRouteManeuver = ^Maps_IMapRouteManeuver;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRouteManeuver>
  IIterator_1__Maps_IMapRouteManeuver = interface;
  PIIterator_1__Maps_IMapRouteManeuver = ^IIterator_1__Maps_IMapRouteManeuver;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRouteManeuver>
  IIterable_1__Maps_IMapRouteManeuver = interface;
  PIIterable_1__Maps_IMapRouteManeuver = ^IIterable_1__Maps_IMapRouteManeuver;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRouteManeuver>
  IVectorView_1__Maps_IMapRouteManeuver = interface;
  PIVectorView_1__Maps_IMapRouteManeuver = ^IVectorView_1__Maps_IMapRouteManeuver;

  // Windows.Services.Maps.IMapRouteLeg
  Maps_IMapRouteLeg = interface;
  PMaps_IMapRouteLeg = ^Maps_IMapRouteLeg;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRouteLeg>
  IIterator_1__Maps_IMapRouteLeg = interface;
  PIIterator_1__Maps_IMapRouteLeg = ^IIterator_1__Maps_IMapRouteLeg;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRouteLeg>
  IIterable_1__Maps_IMapRouteLeg = interface;
  PIIterable_1__Maps_IMapRouteLeg = ^IIterable_1__Maps_IMapRouteLeg;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRouteLeg>
  IVectorView_1__Maps_IMapRouteLeg = interface;
  PIVectorView_1__Maps_IMapRouteLeg = ^IVectorView_1__Maps_IMapRouteLeg;

  // Windows.Services.Maps.IMapRoute
  Maps_IMapRoute = interface;
  PMaps_IMapRoute = ^Maps_IMapRoute;

  // Windows.Services.Maps.IMapAddress
  Maps_IMapAddress = interface;
  PMaps_IMapAddress = ^Maps_IMapAddress;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRoute>
  IIterator_1__Maps_IMapRoute = interface;
  PIIterator_1__Maps_IMapRoute = ^IIterator_1__Maps_IMapRoute;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRoute>
  IIterable_1__Maps_IMapRoute = interface;
  PIIterable_1__Maps_IMapRoute = ^IIterable_1__Maps_IMapRoute;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRoute>
  IVectorView_1__Maps_IMapRoute = interface;
  PIVectorView_1__Maps_IMapRoute = ^IVectorView_1__Maps_IMapRoute;

  // Windows.Services.Maps.LocalSearch.ILocalLocation
  Maps_LocalSearch_ILocalLocation = interface;
  PMaps_LocalSearch_ILocalLocation = ^Maps_LocalSearch_ILocalLocation;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IIterator_1__Maps_LocalSearch_ILocalLocation = interface;
  PIIterator_1__Maps_LocalSearch_ILocalLocation = ^IIterator_1__Maps_LocalSearch_ILocalLocation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IIterable_1__Maps_LocalSearch_ILocalLocation = interface;
  PIIterable_1__Maps_LocalSearch_ILocalLocation = ^IIterable_1__Maps_LocalSearch_ILocalLocation;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IVectorView_1__Maps_LocalSearch_ILocalLocation = interface;
  PIVectorView_1__Maps_LocalSearch_ILocalLocation = ^IVectorView_1__Maps_LocalSearch_ILocalLocation;

  // Windows.Services.TargetedContent.ITargetedContentAction
  TargetedContent_ITargetedContentAction = interface;
  PTargetedContent_ITargetedContentAction = ^TargetedContent_ITargetedContentAction;

  // Windows.Services.TargetedContent.ITargetedContentAvailabilityChangedEventArgs
  TargetedContent_ITargetedContentAvailabilityChangedEventArgs = interface;
  PTargetedContent_ITargetedContentAvailabilityChangedEventArgs = ^TargetedContent_ITargetedContentAvailabilityChangedEventArgs;

  // Windows.Services.TargetedContent.ITargetedContentChangedEventArgs
  TargetedContent_ITargetedContentChangedEventArgs = interface;
  PTargetedContent_ITargetedContentChangedEventArgs = ^TargetedContent_ITargetedContentChangedEventArgs;

  // Windows.Services.TargetedContent.ITargetedContentImage
  TargetedContent_ITargetedContentImage = interface;
  PTargetedContent_ITargetedContentImage = ^TargetedContent_ITargetedContentImage;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IIterator_1__TargetedContent_ITargetedContentImage = interface;
  PIIterator_1__TargetedContent_ITargetedContentImage = ^IIterator_1__TargetedContent_ITargetedContentImage;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IIterable_1__TargetedContent_ITargetedContentImage = interface;
  PIIterable_1__TargetedContent_ITargetedContentImage = ^IIterable_1__TargetedContent_ITargetedContentImage;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IVectorView_1__TargetedContent_ITargetedContentImage = interface;
  PIVectorView_1__TargetedContent_ITargetedContentImage = ^IVectorView_1__TargetedContent_ITargetedContentImage;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IIterator_1__TargetedContent_ITargetedContentAction = interface;
  PIIterator_1__TargetedContent_ITargetedContentAction = ^IIterator_1__TargetedContent_ITargetedContentAction;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IIterable_1__TargetedContent_ITargetedContentAction = interface;
  PIIterable_1__TargetedContent_ITargetedContentAction = ^IIterable_1__TargetedContent_ITargetedContentAction;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IVectorView_1__TargetedContent_ITargetedContentAction = interface;
  PIVectorView_1__TargetedContent_ITargetedContentAction = ^IVectorView_1__TargetedContent_ITargetedContentAction;

  // Windows.Services.TargetedContent.ITargetedContentValue
  TargetedContent_ITargetedContentValue = interface;
  PTargetedContent_ITargetedContentValue = ^TargetedContent_ITargetedContentValue;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>
  IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface;
  PIKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = ^IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>>
  IIterator_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = ^IIterator_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>>
  IIterable_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = ^IIterable_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.ITargetedContentValue>
  IMapView_2__HSTRING__TargetedContent_ITargetedContentValue = interface;
  PIMapView_2__HSTRING__TargetedContent_ITargetedContentValue = ^IMapView_2__HSTRING__TargetedContent_ITargetedContentValue;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IIterator_1__TargetedContent_ITargetedContentCollection = interface;
  PIIterator_1__TargetedContent_ITargetedContentCollection = ^IIterator_1__TargetedContent_ITargetedContentCollection;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IIterable_1__TargetedContent_ITargetedContentCollection = interface;
  PIIterable_1__TargetedContent_ITargetedContentCollection = ^IIterable_1__TargetedContent_ITargetedContentCollection;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IVectorView_1__TargetedContent_ITargetedContentCollection = interface;
  PIVectorView_1__TargetedContent_ITargetedContentCollection = ^IVectorView_1__TargetedContent_ITargetedContentCollection;

  // Windows.Services.TargetedContent.ITargetedContentItemState
  TargetedContent_ITargetedContentItemState = interface;
  PTargetedContent_ITargetedContentItemState = ^TargetedContent_ITargetedContentItemState;

  // Windows.Services.TargetedContent.ITargetedContentItem
  TargetedContent_ITargetedContentItem = interface;
  PTargetedContent_ITargetedContentItem = ^TargetedContent_ITargetedContentItem;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IIterator_1__TargetedContent_ITargetedContentItem = interface;
  PIIterator_1__TargetedContent_ITargetedContentItem = ^IIterator_1__TargetedContent_ITargetedContentItem;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IIterable_1__TargetedContent_ITargetedContentItem = interface;
  PIIterable_1__TargetedContent_ITargetedContentItem = ^IIterable_1__TargetedContent_ITargetedContentItem;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IVectorView_1__TargetedContent_ITargetedContentItem = interface;
  PIVectorView_1__TargetedContent_ITargetedContentItem = ^IVectorView_1__TargetedContent_ITargetedContentItem;

  // Windows.Services.TargetedContent.ITargetedContentCollection
  TargetedContent_ITargetedContentCollection = interface;
  PTargetedContent_ITargetedContentCollection = ^TargetedContent_ITargetedContentCollection;

  // Windows.Services.TargetedContent.ITargetedContentObject
  TargetedContent_ITargetedContentObject = interface;
  PTargetedContent_ITargetedContentObject = ^TargetedContent_ITargetedContentObject;

  // Windows.Services.TargetedContent.ITargetedContentContainer
  TargetedContent_ITargetedContentContainer = interface;
  PTargetedContent_ITargetedContentContainer = ^TargetedContent_ITargetedContentContainer;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.ITargetedContentContainer>
  AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer = interface;
  PAsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer = ^AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.ITargetedContentContainer>
  IAsyncOperation_1__TargetedContent_ITargetedContentContainer = interface;
  PIAsyncOperation_1__TargetedContent_ITargetedContentContainer = ^IAsyncOperation_1__TargetedContent_ITargetedContentContainer;

  // Windows.Services.TargetedContent.ITargetedContentContainerStatics
  TargetedContent_ITargetedContentContainerStatics = interface;
  PTargetedContent_ITargetedContentContainerStatics = ^TargetedContent_ITargetedContentContainerStatics;

  // Windows.Services.TargetedContent.ITargetedContentStateChangedEventArgs
  TargetedContent_ITargetedContentStateChangedEventArgs = interface;
  PTargetedContent_ITargetedContentStateChangedEventArgs = ^TargetedContent_ITargetedContentStateChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentChangedEventArgs = interface;
  PTypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentChangedEventArgs = ^TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentAvailabilityChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentAvailabilityChangedEventArgs = interface;
  PTypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentAvailabilityChangedEventArgs = ^TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentAvailabilityChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentStateChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentStateChangedEventArgs = interface;
  PTypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentStateChangedEventArgs = ^TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentStateChangedEventArgs;

  // Windows.Services.TargetedContent.ITargetedContentSubscription
  TargetedContent_ITargetedContentSubscription = interface;
  PTargetedContent_ITargetedContentSubscription = ^TargetedContent_ITargetedContentSubscription;

  // Windows.Services.TargetedContent.ITargetedContentSubscriptionOptions
  TargetedContent_ITargetedContentSubscriptionOptions = interface;
  PTargetedContent_ITargetedContentSubscriptionOptions = ^TargetedContent_ITargetedContentSubscriptionOptions;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.ITargetedContentSubscription>
  AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription = interface;
  PAsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription = ^AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.ITargetedContentSubscription>
  IAsyncOperation_1__TargetedContent_ITargetedContentSubscription = interface;
  PIAsyncOperation_1__TargetedContent_ITargetedContentSubscription = ^IAsyncOperation_1__TargetedContent_ITargetedContentSubscription;

  // Windows.Services.TargetedContent.ITargetedContentSubscriptionStatics
  TargetedContent_ITargetedContentSubscriptionStatics = interface;
  PTargetedContent_ITargetedContentSubscriptionStatics = ^TargetedContent_ITargetedContentSubscriptionStatics;

  // Windows.Services Enums

  // Windows.Services.Cortana.CortanaPermission
  Cortana_CortanaPermission = (
    BrowsingHistory = 0,
    Calendar = 1,
    CallHistory = 2,
    Contacts = 3,
    Email = 4,
    InputPersonalization = 5,
    Location = 6,
    Messaging = 7,
    Microphone = 8,
    Personalization = 9,
    PhoneCall = 10
  );
  PCortana_CortanaPermission = ^Cortana_CortanaPermission;

  // Windows.Services.Cortana.CortanaPermissionsChangeResult
  Cortana_CortanaPermissionsChangeResult = (
    Success = 0,
    Unavailable = 1,
    DisabledByPolicy = 2
  );
  PCortana_CortanaPermissionsChangeResult = ^Cortana_CortanaPermissionsChangeResult;

  // Windows.Services.Maps.Guidance.GuidanceAudioMeasurementSystem
  Maps_Guidance_GuidanceAudioMeasurementSystem = (
    Meters = 0,
    MilesAndYards = 1,
    MilesAndFeet = 2
  );
  PMaps_Guidance_GuidanceAudioMeasurementSystem = ^Maps_Guidance_GuidanceAudioMeasurementSystem;

  // Windows.Services.Maps.Guidance.GuidanceAudioNotificationKind
  Maps_Guidance_GuidanceAudioNotificationKind = (
    Maneuver = 0,
    Route = 1,
    Gps = 2,
    SpeedLimit = 3,
    Traffic = 4,
    TrafficCamera = 5
  );
  PMaps_Guidance_GuidanceAudioNotificationKind = ^Maps_Guidance_GuidanceAudioNotificationKind;

  // Windows.Services.Maps.Guidance.GuidanceAudioNotifications
  Maps_Guidance_GuidanceAudioNotifications = (
    None = 0,
    Maneuver = 1,
    Route = 2,
    Gps = 4,
    SpeedLimit = 8,
    Traffic = 16,
    TrafficCamera = 32
  );
  PMaps_Guidance_GuidanceAudioNotifications = ^Maps_Guidance_GuidanceAudioNotifications;

  // Windows.Services.Maps.Guidance.GuidanceLaneMarkers
  Maps_Guidance_GuidanceLaneMarkers = (
    None = 0,
    LightRight = 1,
    Right = 2,
    HardRight = 4,
    Straight = 8,
    UTurnLeft = 16,
    HardLeft = 32,
    Left = 64,
    LightLeft = 128,
    UTurnRight = 256,
    Unknown = -1
  );
  PMaps_Guidance_GuidanceLaneMarkers = ^Maps_Guidance_GuidanceLaneMarkers;

  // Windows.Services.Maps.Guidance.GuidanceManeuverKind
  Maps_Guidance_GuidanceManeuverKind = (
    None = 0,
    GoStraight = 1,
    UTurnRight = 2,
    UTurnLeft = 3,
    TurnKeepRight = 4,
    TurnLightRight = 5,
    TurnRight = 6,
    TurnHardRight = 7,
    KeepMiddle = 8,
    TurnKeepLeft = 9,
    TurnLightLeft = 10,
    TurnLeft = 11,
    TurnHardLeft = 12,
    FreewayEnterRight = 13,
    FreewayEnterLeft = 14,
    FreewayLeaveRight = 15,
    FreewayLeaveLeft = 16,
    FreewayKeepRight = 17,
    FreewayKeepLeft = 18,
    TrafficCircleRight1 = 19,
    TrafficCircleRight2 = 20,
    TrafficCircleRight3 = 21,
    TrafficCircleRight4 = 22,
    TrafficCircleRight5 = 23,
    TrafficCircleRight6 = 24,
    TrafficCircleRight7 = 25,
    TrafficCircleRight8 = 26,
    TrafficCircleRight9 = 27,
    TrafficCircleRight10 = 28,
    TrafficCircleRight11 = 29,
    TrafficCircleRight12 = 30,
    TrafficCircleLeft1 = 31,
    TrafficCircleLeft2 = 32,
    TrafficCircleLeft3 = 33,
    TrafficCircleLeft4 = 34,
    TrafficCircleLeft5 = 35,
    TrafficCircleLeft6 = 36,
    TrafficCircleLeft7 = 37,
    TrafficCircleLeft8 = 38,
    TrafficCircleLeft9 = 39,
    TrafficCircleLeft10 = 40,
    TrafficCircleLeft11 = 41,
    TrafficCircleLeft12 = 42,
    Start = 43,
    &End = 44,
    TakeFerry = 45,
    PassTransitStation = 46,
    LeaveTransitStation = 47
  );
  PMaps_Guidance_GuidanceManeuverKind = ^Maps_Guidance_GuidanceManeuverKind;

  // Windows.Services.Maps.Guidance.GuidanceMode
  Maps_Guidance_GuidanceMode = (
    None = 0,
    Simulation = 1,
    Navigation = 2,
    Tracking = 3
  );
  PMaps_Guidance_GuidanceMode = ^Maps_Guidance_GuidanceMode;

  // Windows.Services.Maps.LocalSearch.LocalLocationFinderStatus
  Maps_LocalSearch_LocalLocationFinderStatus = (
    Success = 0,
    UnknownError = 1,
    InvalidCredentials = 2,
    InvalidCategory = 3,
    InvalidSearchTerm = 4,
    InvalidSearchArea = 5,
    NetworkFailure = 6,
    NotSupported = 7
  );
  PMaps_LocalSearch_LocalLocationFinderStatus = ^Maps_LocalSearch_LocalLocationFinderStatus;

  // Windows.Services.Maps.ManeuverWarningKind
  Maps_ManeuverWarningKind = (
    None = 0,
    Accident = 1,
    AdministrativeDivisionChange = 2,
    Alert = 3,
    BlockedRoad = 4,
    CheckTimetable = 5,
    Congestion = 6,
    Construction = 7,
    CountryChange = 8,
    DisabledVehicle = 9,
    GateAccess = 10,
    GetOffTransit = 11,
    GetOnTransit = 12,
    IllegalUTurn = 13,
    MassTransit = 14,
    Miscellaneous = 15,
    NoIncident = 16,
    Other = 17,
    OtherNews = 18,
    OtherTrafficIncidents = 19,
    PlannedEvent = 20,
    PrivateRoad = 21,
    RestrictedTurn = 22,
    RoadClosures = 23,
    RoadHazard = 24,
    ScheduledConstruction = 25,
    SeasonalClosures = 26,
    Tollbooth = 27,
    TollRoad = 28,
    TollZoneEnter = 29,
    TollZoneExit = 30,
    TrafficFlow = 31,
    TransitLineChange = 32,
    UnpavedRoad = 33,
    UnscheduledConstruction = 34,
    Weather = 35
  );
  PMaps_ManeuverWarningKind = ^Maps_ManeuverWarningKind;

  // Windows.Services.Maps.ManeuverWarningSeverity
  Maps_ManeuverWarningSeverity = (
    None = 0,
    LowImpact = 1,
    Minor = 2,
    Moderate = 3,
    Serious = 4
  );
  PMaps_ManeuverWarningSeverity = ^Maps_ManeuverWarningSeverity;

  // Windows.Services.Maps.MapLocationDesiredAccuracy
  Maps_MapLocationDesiredAccuracy = (
    High = 0,
    Low = 1
  );
  PMaps_MapLocationDesiredAccuracy = ^Maps_MapLocationDesiredAccuracy;

  // Windows.Services.Maps.MapLocationFinderStatus
  Maps_MapLocationFinderStatus = (
    Success = 0,
    UnknownError = 1,
    InvalidCredentials = 2,
    BadLocation = 3,
    IndexFailure = 4,
    NetworkFailure = 5,
    NotSupported = 6
  );
  PMaps_MapLocationFinderStatus = ^Maps_MapLocationFinderStatus;

  // Windows.Services.Maps.MapManeuverNotices
  Maps_MapManeuverNotices = (
    None = 0,
    Toll = 1,
    Unpaved = 2
  );
  PMaps_MapManeuverNotices = ^Maps_MapManeuverNotices;

  // Windows.Services.Maps.MapRouteFinderStatus
  Maps_MapRouteFinderStatus = (
    Success = 0,
    UnknownError = 1,
    InvalidCredentials = 2,
    NoRouteFound = 3,
    NoRouteFoundWithGivenOptions = 4,
    StartPointNotFound = 5,
    EndPointNotFound = 6,
    NoPedestrianRouteFound = 7,
    NetworkFailure = 8,
    NotSupported = 9
  );
  PMaps_MapRouteFinderStatus = ^Maps_MapRouteFinderStatus;

  // Windows.Services.Maps.MapRouteManeuverKind
  Maps_MapRouteManeuverKind = (
    None = 0,
    Start = 1,
    Stopover = 2,
    StopoverResume = 3,
    &End = 4,
    GoStraight = 5,
    UTurnLeft = 6,
    UTurnRight = 7,
    TurnKeepLeft = 8,
    TurnKeepRight = 9,
    TurnLightLeft = 10,
    TurnLightRight = 11,
    TurnLeft = 12,
    TurnRight = 13,
    TurnHardLeft = 14,
    TurnHardRight = 15,
    FreewayEnterLeft = 16,
    FreewayEnterRight = 17,
    FreewayLeaveLeft = 18,
    FreewayLeaveRight = 19,
    FreewayContinueLeft = 20,
    FreewayContinueRight = 21,
    TrafficCircleLeft = 22,
    TrafficCircleRight = 23,
    TakeFerry = 24
  );
  PMaps_MapRouteManeuverKind = ^Maps_MapRouteManeuverKind;

  // Windows.Services.Maps.MapRouteOptimization
  Maps_MapRouteOptimization = (
    Time = 0,
    Distance = 1,
    TimeWithTraffic = 2,
    Scenic = 3
  );
  PMaps_MapRouteOptimization = ^Maps_MapRouteOptimization;

  // Windows.Services.Maps.MapRouteRestrictions
  Maps_MapRouteRestrictions = (
    None = 0,
    Highways = 1,
    TollRoads = 2,
    Ferries = 4,
    Tunnels = 8,
    DirtRoads = 16,
    Motorail = 32
  );
  PMaps_MapRouteRestrictions = ^Maps_MapRouteRestrictions;

  // Windows.Services.Maps.MapServiceDataUsagePreference
  Maps_MapServiceDataUsagePreference = (
    Default = 0,
    OfflineMapDataOnly = 1
  );
  PMaps_MapServiceDataUsagePreference = ^Maps_MapServiceDataUsagePreference;

  // Windows.Services.Maps.OfflineMaps.OfflineMapPackageQueryStatus
  Maps_OfflineMaps_OfflineMapPackageQueryStatus = (
    Success = 0,
    UnknownError = 1,
    InvalidCredentials = 2,
    NetworkFailure = 3
  );
  PMaps_OfflineMaps_OfflineMapPackageQueryStatus = ^Maps_OfflineMaps_OfflineMapPackageQueryStatus;

  // Windows.Services.Maps.OfflineMaps.OfflineMapPackageStartDownloadStatus
  Maps_OfflineMaps_OfflineMapPackageStartDownloadStatus = (
    Success = 0,
    UnknownError = 1,
    InvalidCredentials = 2,
    DeniedWithoutCapability = 3
  );
  PMaps_OfflineMaps_OfflineMapPackageStartDownloadStatus = ^Maps_OfflineMaps_OfflineMapPackageStartDownloadStatus;

  // Windows.Services.Maps.OfflineMaps.OfflineMapPackageStatus
  Maps_OfflineMaps_OfflineMapPackageStatus = (
    NotDownloaded = 0,
    Downloading = 1,
    Downloaded = 2,
    Deleting = 3
  );
  PMaps_OfflineMaps_OfflineMapPackageStatus = ^Maps_OfflineMaps_OfflineMapPackageStatus;

  // Windows.Services.Maps.TrafficCongestion
  Maps_TrafficCongestion = (
    Unknown = 0,
    Light = 1,
    Mild = 2,
    Medium = 3,
    Heavy = 4
  );
  PMaps_TrafficCongestion = ^Maps_TrafficCongestion;

  // Windows.Services.Maps.WaypointKind
  Maps_WaypointKind = (
    Stop = 0,
    Via = 1
  );
  PMaps_WaypointKind = ^Maps_WaypointKind;

  // Windows.Services.TargetedContent.TargetedContentAppInstallationState
  TargetedContent_TargetedContentAppInstallationState = (
    NotApplicable = 0,
    NotInstalled = 1,
    Installed = 2
  );
  PTargetedContent_TargetedContentAppInstallationState = ^TargetedContent_TargetedContentAppInstallationState;

  // Windows.Services.TargetedContent.TargetedContentAvailability
  TargetedContent_TargetedContentAvailability = (
    None = 0,
    Partial = 1,
    All = 2
  );
  PTargetedContent_TargetedContentAvailability = ^TargetedContent_TargetedContentAvailability;

  // Windows.Services.TargetedContent.TargetedContentInteraction
  TargetedContent_TargetedContentInteraction = (
    Impression = 0,
    ClickThrough = 1,
    Hover = 2,
    Like = 3,
    Dislike = 4,
    Dismiss = 5,
    Ineligible = 6,
    Accept = 7,
    Decline = 8,
    Defer = 9,
    Canceled = 10,
    Conversion = 11,
    Opportunity = 12
  );
  PTargetedContent_TargetedContentInteraction = ^TargetedContent_TargetedContentInteraction;

  // Windows.Services.TargetedContent.TargetedContentObjectKind
  TargetedContent_TargetedContentObjectKind = (
    Collection = 0,
    Item = 1,
    Value = 2
  );
  PTargetedContent_TargetedContentObjectKind = ^TargetedContent_TargetedContentObjectKind;

  // Windows.Services.TargetedContent.TargetedContentValueKind
  TargetedContent_TargetedContentValueKind = (
    &String = 0,
    Uri = 1,
    Number = 2,
    Boolean = 3,
    &File = 4,
    ImageFile = 5,
    Action = 6,
    Strings = 7,
    Uris = 8,
    Numbers = 9,
    Booleans = 10,
    Files = 11,
    ImageFiles = 12,
    Actions = 13
  );
  PTargetedContent_TargetedContentValueKind = ^TargetedContent_TargetedContentValueKind;

  // Windows.Services Records

  // Windows.Services.Maps.GuidanceContract
  Maps_GuidanceContract = record
  end;
  PMaps_GuidanceContract = ^Maps_GuidanceContract;

  // Windows.Services.Maps.LocalSearchContract
  Maps_LocalSearchContract = record
  end;
  PMaps_LocalSearchContract = ^Maps_LocalSearchContract;

  // Windows.Services.TargetedContent.TargetedContentContract
  TargetedContent_TargetedContentContract = record
  end;
  PTargetedContent_TargetedContentContract = ^TargetedContent_TargetedContentContract;

  // Windows.Services Interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Cortana.CortanaPermission>
  IIterator_1__Cortana_CortanaPermission = interface(IInspectable)
  ['{0F1AC33C-511A-52E8-AF09-D89F7004E8C5}']
    function get_Current: Cortana_CortanaPermission; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PCortana_CortanaPermission): Cardinal; safecall;
    property Current: Cortana_CortanaPermission read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Cortana.CortanaPermission>
  IIterable_1__Cortana_CortanaPermission = interface(IInspectable)
  ['{36A12EAE-2E24-5E07-BFD0-344A92990916}']
    function First: IIterator_1__Cortana_CortanaPermission; safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Cortana.CortanaPermissionsChangeResult>
  AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult = interface(IUnknown)
  ['{EC1C6586-5E0D-5BC0-B84F-20052C5AC7A9}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Cortana_CortanaPermissionsChangeResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Cortana.CortanaPermissionsChangeResult>
  IAsyncOperation_1__Cortana_CortanaPermissionsChangeResult = interface(IInspectable)
  ['{838A3DD0-F0A3-508F-846A-D3C19E4FE7A0}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult; safecall;
    function GetResults: Cortana_CortanaPermissionsChangeResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Cortana_CortanaPermissionsChangeResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Cortana.ICortanaSettings
  [WinRTClassNameAttribute(SWindows_Services_Cortana_CortanaSettings)]
  Cortana_ICortanaSettings = interface(IInspectable)
  ['{54D571A7-8062-40F4-ABE7-DEDFD697B019}']
    function get_HasUserConsentToVoiceActivation: Boolean; safecall;
    function get_IsVoiceActivationEnabled: Boolean; safecall;
    procedure put_IsVoiceActivationEnabled(value: Boolean); safecall;
    property HasUserConsentToVoiceActivation: Boolean read get_HasUserConsentToVoiceActivation;
    property IsVoiceActivationEnabled: Boolean read get_IsVoiceActivationEnabled write put_IsVoiceActivationEnabled;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Cortana.ICortanaSettingsStatics
  [WinRTClassNameAttribute(SWindows_Services_Cortana_CortanaSettings)]
  Cortana_ICortanaSettingsStatics = interface(IInspectable)
  ['{8B2CCD7E-2EC0-446D-9285-33F07CE8AC04}']
    function IsSupported: Boolean; safecall;
    function GetDefault: Cortana_ICortanaSettings; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Services.Maps.IMapRouteManeuver
  Maps_IMapRouteManeuver = interface(IInspectable)
  ['{ED5C17F0-A6AB-4D65-A086-FA8A7E340DF2}']
    function get_StartingPoint: IGeopoint; safecall;
    function get_LengthInMeters: Double; safecall;
    function get_InstructionText: HSTRING; safecall;
    function get_Kind: Maps_MapRouteManeuverKind; safecall;
    function get_ExitNumber: HSTRING; safecall;
    function get_ManeuverNotices: Maps_MapManeuverNotices; safecall;
    property ExitNumber: HSTRING read get_ExitNumber;
    property InstructionText: HSTRING read get_InstructionText;
    property Kind: Maps_MapRouteManeuverKind read get_Kind;
    property LengthInMeters: Double read get_LengthInMeters;
    property ManeuverNotices: Maps_MapManeuverNotices read get_ManeuverNotices;
    property StartingPoint: IGeopoint read get_StartingPoint;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.MapRouteManeuver>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRouteManeuver>
  IIterator_1__Maps_IMapRouteManeuver = interface(IInspectable)
  ['{A7AB048B-A6DC-5E4C-9321-71B0E465DFE8}']
    function get_Current: Maps_IMapRouteManeuver; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMaps_IMapRouteManeuver): Cardinal; safecall;
    property Current: Maps_IMapRouteManeuver read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.MapRouteManeuver>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRouteManeuver>
  IIterable_1__Maps_IMapRouteManeuver = interface(IInspectable)
  ['{DE9015FB-91D7-556E-BB4D-200B6F58FAD4}']
    function First: IIterator_1__Maps_IMapRouteManeuver; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRouteManeuver>
  IVectorView_1__Maps_IMapRouteManeuver = interface(IInspectable)
  ['{9DA15A6F-DDEA-5945-9863-77745321D47D}']
    function GetAt(index: Cardinal): Maps_IMapRouteManeuver; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Maps_IMapRouteManeuver; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMaps_IMapRouteManeuver): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Maps.IMapRouteLeg
  Maps_IMapRouteLeg = interface(IInspectable)
  ['{96F8B2F6-5BBA-4D17-9DB6-1A263FEC7471}']
    function get_BoundingBox: IGeoboundingBox; safecall;
    function get_Path: IGeopath; safecall;
    function get_LengthInMeters: Double; safecall;
    function get_EstimatedDuration: TimeSpan; safecall;
    function get_Maneuvers: IVectorView_1__Maps_IMapRouteManeuver; safecall;
    property BoundingBox: IGeoboundingBox read get_BoundingBox;
    property EstimatedDuration: TimeSpan read get_EstimatedDuration;
    property LengthInMeters: Double read get_LengthInMeters;
    property Maneuvers: IVectorView_1__Maps_IMapRouteManeuver read get_Maneuvers;
    property Path: IGeopath read get_Path;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.MapRouteLeg>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRouteLeg>
  IIterator_1__Maps_IMapRouteLeg = interface(IInspectable)
  ['{DD1BE7D2-DE62-5752-B2E0-A2B08723B787}']
    function get_Current: Maps_IMapRouteLeg; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMaps_IMapRouteLeg): Cardinal; safecall;
    property Current: Maps_IMapRouteLeg read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.MapRouteLeg>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRouteLeg>
  IIterable_1__Maps_IMapRouteLeg = interface(IInspectable)
  ['{8FF98759-78CD-56E8-877B-83CE846D6F8B}']
    function First: IIterator_1__Maps_IMapRouteLeg; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRouteLeg>
  IVectorView_1__Maps_IMapRouteLeg = interface(IInspectable)
  ['{AAFAE329-57EE-5FD2-B0B9-C971A3E143EB}']
    function GetAt(index: Cardinal): Maps_IMapRouteLeg; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Maps_IMapRouteLeg; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMaps_IMapRouteLeg): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Maps.IMapRoute
  Maps_IMapRoute = interface(IInspectable)
  ['{FB07B732-584D-4583-9C60-641FEA274349}']
    function get_BoundingBox: IGeoboundingBox; safecall;
    function get_LengthInMeters: Double; safecall;
    function get_EstimatedDuration: TimeSpan; safecall;
    function get_Path: IGeopath; safecall;
    function get_Legs: IVectorView_1__Maps_IMapRouteLeg; safecall;
    function get_IsTrafficBased: Boolean; safecall;
    property BoundingBox: IGeoboundingBox read get_BoundingBox;
    property EstimatedDuration: TimeSpan read get_EstimatedDuration;
    property IsTrafficBased: Boolean read get_IsTrafficBased;
    property Legs: IVectorView_1__Maps_IMapRouteLeg read get_Legs;
    property LengthInMeters: Double read get_LengthInMeters;
    property Path: IGeopath read get_Path;
  end;

  // UsedAPI Interface
  // Windows.Services.Maps.IMapAddress
  Maps_IMapAddress = interface(IInspectable)
  ['{CFA7A973-A3B4-4494-B3FF-CBA94DB69699}']
    function get_BuildingName: HSTRING; safecall;
    function get_BuildingFloor: HSTRING; safecall;
    function get_BuildingRoom: HSTRING; safecall;
    function get_BuildingWing: HSTRING; safecall;
    function get_StreetNumber: HSTRING; safecall;
    function get_Street: HSTRING; safecall;
    function get_Neighborhood: HSTRING; safecall;
    function get_District: HSTRING; safecall;
    function get_Town: HSTRING; safecall;
    function get_Region: HSTRING; safecall;
    function get_RegionCode: HSTRING; safecall;
    function get_Country: HSTRING; safecall;
    function get_CountryCode: HSTRING; safecall;
    function get_PostCode: HSTRING; safecall;
    function get_Continent: HSTRING; safecall;
    property BuildingFloor: HSTRING read get_BuildingFloor;
    property BuildingName: HSTRING read get_BuildingName;
    property BuildingRoom: HSTRING read get_BuildingRoom;
    property BuildingWing: HSTRING read get_BuildingWing;
    property Continent: HSTRING read get_Continent;
    property Country: HSTRING read get_Country;
    property CountryCode: HSTRING read get_CountryCode;
    property District: HSTRING read get_District;
    property Neighborhood: HSTRING read get_Neighborhood;
    property PostCode: HSTRING read get_PostCode;
    property Region: HSTRING read get_Region;
    property RegionCode: HSTRING read get_RegionCode;
    property Street: HSTRING read get_Street;
    property StreetNumber: HSTRING read get_StreetNumber;
    property Town: HSTRING read get_Town;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.MapRoute>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.IMapRoute>
  IIterator_1__Maps_IMapRoute = interface(IInspectable)
  ['{97E8485A-79C0-5343-93D1-47CDFB55246B}']
    function get_Current: Maps_IMapRoute; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMaps_IMapRoute): Cardinal; safecall;
    property Current: Maps_IMapRoute read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.MapRoute>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.IMapRoute>
  IIterable_1__Maps_IMapRoute = interface(IInspectable)
  ['{D88A62A2-0EDF-5312-97A8-10AEAEA80B99}']
    function First: IIterator_1__Maps_IMapRoute; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.IMapRoute>
  IVectorView_1__Maps_IMapRoute = interface(IInspectable)
  ['{1E6FCAD9-EA40-524D-ACF1-5E394278E1BC}']
    function GetAt(index: Cardinal): Maps_IMapRoute; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Maps_IMapRoute; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMaps_IMapRoute): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Maps.LocalSearch.ILocalLocation
  Maps_LocalSearch_ILocalLocation = interface(IInspectable)
  ['{BB0FE9AB-4502-4F2C-94A9-0D60DE0E2163}']
    function get_Address: Maps_IMapAddress; safecall;
    function get_Identifier: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_Point: IGeopoint; safecall;
    function get_PhoneNumber: HSTRING; safecall;
    function get_DataAttribution: HSTRING; safecall;
    property Address: Maps_IMapAddress read get_Address;
    property DataAttribution: HSTRING read get_DataAttribution;
    property Description: HSTRING read get_Description;
    property DisplayName: HSTRING read get_DisplayName;
    property Identifier: HSTRING read get_Identifier;
    property PhoneNumber: HSTRING read get_PhoneNumber;
    property Point: IGeopoint read get_Point;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.LocalSearch.LocalLocation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IIterator_1__Maps_LocalSearch_ILocalLocation = interface(IInspectable)
  ['{A23C2E87-A8E7-568F-96A1-69E98F86B9D3}']
    function get_Current: Maps_LocalSearch_ILocalLocation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMaps_LocalSearch_ILocalLocation): Cardinal; safecall;
    property Current: Maps_LocalSearch_ILocalLocation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.LocalSearch.LocalLocation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IIterable_1__Maps_LocalSearch_ILocalLocation = interface(IInspectable)
  ['{5474EEFB-60F4-58AC-89E2-6E83F79FA76C}']
    function First: IIterator_1__Maps_LocalSearch_ILocalLocation; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Maps.LocalSearch.ILocalLocation>
  IVectorView_1__Maps_LocalSearch_ILocalLocation = interface(IInspectable)
  ['{4E62950D-5A21-5B97-BB8E-D41C7C051DC7}']
    function GetAt(index: Cardinal): Maps_LocalSearch_ILocalLocation; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Maps_LocalSearch_ILocalLocation; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMaps_LocalSearch_ILocalLocation): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentAction
  TargetedContent_ITargetedContentAction = interface(IInspectable)
  ['{D75B691E-6CD6-4CA0-9D8F-4728B0B7E6B6}']
    function InvokeAsync: IAsyncAction; safecall;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentAvailabilityChangedEventArgs
  TargetedContent_ITargetedContentAvailabilityChangedEventArgs = interface(IInspectable)
  ['{E0F59D26-5927-4450-965C-1CEB7BECDE65}']
    function GetDeferral: IDeferral; safecall;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentChangedEventArgs
  TargetedContent_ITargetedContentChangedEventArgs = interface(IInspectable)
  ['{99D488C9-587E-4586-8EF7-B54CA9453A16}']
    function GetDeferral: IDeferral; safecall;
    function get_HasPreviousContentExpired: Boolean; safecall;
    property HasPreviousContentExpired: Boolean read get_HasPreviousContentExpired;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentImage
  TargetedContent_ITargetedContentImage = interface(IInspectable)
  ['{A7A585D9-779F-4B1E-BBB1-8EAF53FBEAB2}']
    function get_Height: Cardinal; safecall;
    function get_Width: Cardinal; safecall;
    property Height: Cardinal read get_Height;
    property Width: Cardinal read get_Width;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.TargetedContentImage>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IIterator_1__TargetedContent_ITargetedContentImage = interface(IInspectable)
  ['{A807B298-9E2F-5673-BCF6-1E35FEBA0647}']
    function get_Current: TargetedContent_ITargetedContentImage; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PTargetedContent_ITargetedContentImage): Cardinal; safecall;
    property Current: TargetedContent_ITargetedContentImage read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.TargetedContentImage>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IIterable_1__TargetedContent_ITargetedContentImage = interface(IInspectable)
  ['{EFADB6BF-AF18-5AF9-A509-19881BC586F5}']
    function First: IIterator_1__TargetedContent_ITargetedContentImage; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentImage>
  IVectorView_1__TargetedContent_ITargetedContentImage = interface(IInspectable)
  ['{0D42E297-EAB2-5574-B73F-C81C029C4FC7}']
    function GetAt(index: Cardinal): TargetedContent_ITargetedContentImage; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TargetedContent_ITargetedContentImage; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PTargetedContent_ITargetedContentImage): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.TargetedContentAction>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IIterator_1__TargetedContent_ITargetedContentAction = interface(IInspectable)
  ['{79656935-5813-5AA6-8E69-627A0D85088F}']
    function get_Current: TargetedContent_ITargetedContentAction; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PTargetedContent_ITargetedContentAction): Cardinal; safecall;
    property Current: TargetedContent_ITargetedContentAction read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.TargetedContentAction>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IIterable_1__TargetedContent_ITargetedContentAction = interface(IInspectable)
  ['{CF05B497-3AFD-5D00-859E-9FBD1A36D576}']
    function First: IIterator_1__TargetedContent_ITargetedContentAction; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentAction>
  IVectorView_1__TargetedContent_ITargetedContentAction = interface(IInspectable)
  ['{C3C1FD9C-D409-5CAD-9DBB-F8E6D4663D36}']
    function GetAt(index: Cardinal): TargetedContent_ITargetedContentAction; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TargetedContent_ITargetedContentAction; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PTargetedContent_ITargetedContentAction): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentValue
  TargetedContent_ITargetedContentValue = interface(IInspectable)
  ['{AAFDE4B3-4215-4BF8-867F-43F04865F9BF}']
    function get_ValueKind: TargetedContent_TargetedContentValueKind; safecall;
    function get_Path: HSTRING; safecall;
    function get_String: HSTRING; safecall;
    function get_Uri: IUriRuntimeClass; safecall;
    function get_Number: Double; safecall;
    function get_Boolean: Boolean; safecall;
    function get_File: IRandomAccessStreamReference; safecall;
    function get_ImageFile: TargetedContent_ITargetedContentImage; safecall;
    function get_Action: TargetedContent_ITargetedContentAction; safecall;
    function get_Strings: IVectorView_1__HSTRING; safecall;
    function get_Uris: IVectorView_1__IUriRuntimeClass; safecall;
    function get_Numbers: IVectorView_1__Double; safecall;
    function get_Booleans: IVectorView_1__Boolean; safecall;
    function get_Files: IVectorView_1__IRandomAccessStreamReference; safecall;
    function get_ImageFiles: IVectorView_1__TargetedContent_ITargetedContentImage; safecall;
    function get_Actions: IVectorView_1__TargetedContent_ITargetedContentAction; safecall;
    property Action: TargetedContent_ITargetedContentAction read get_Action;
    property Actions: IVectorView_1__TargetedContent_ITargetedContentAction read get_Actions;
    property Boolean_: Boolean read get_Boolean;
    property Booleans: IVectorView_1__Boolean read get_Booleans;
    property &File: IRandomAccessStreamReference read get_File;
    property Files: IVectorView_1__IRandomAccessStreamReference read get_Files;
    property ImageFile: TargetedContent_ITargetedContentImage read get_ImageFile;
    property ImageFiles: IVectorView_1__TargetedContent_ITargetedContentImage read get_ImageFiles;
    property Number: Double read get_Number;
    property Numbers: IVectorView_1__Double read get_Numbers;
    property Path: HSTRING read get_Path;
    property &String: HSTRING read get_String;
    property Strings: IVectorView_1__HSTRING read get_Strings;
    property Uri: IUriRuntimeClass read get_Uri;
    property Uris: IVectorView_1__IUriRuntimeClass read get_Uris;
    property ValueKind: TargetedContent_TargetedContentValueKind read get_ValueKind;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>
  IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface(IInspectable)
  ['{5EE8132B-C17A-5E9C-A5B8-50046EFA47B2}']
    function get_Key: HSTRING; safecall;
    function get_Value: TargetedContent_ITargetedContentValue; safecall;
    property Key: HSTRING read get_Key;
    property Value: TargetedContent_ITargetedContentValue read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.TargetedContentValue>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>>
  IIterator_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface(IInspectable)
  ['{B97E682B-6E0A-5EEA-B70B-25795B28E937}']
    function get_Current: IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.TargetedContentValue>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.ITargetedContentValue>>
  IIterable_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue = interface(IInspectable)
  ['{45A020D8-FE49-5720-950B-3CCEAB655531}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__TargetedContent_ITargetedContentValue; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.TargetedContentValue>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.TargetedContent.ITargetedContentValue>
  IMapView_2__HSTRING__TargetedContent_ITargetedContentValue = interface(IInspectable)
  ['{19A87E94-AB75-574F-A226-8726A0D8EB3E}']
    function Lookup(key: HSTRING): TargetedContent_ITargetedContentValue; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue; out second: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.TargetedContentCollection>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IIterator_1__TargetedContent_ITargetedContentCollection = interface(IInspectable)
  ['{6093B8FD-6D5D-53CD-B497-7B4540F10857}']
    function get_Current: TargetedContent_ITargetedContentCollection; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PTargetedContent_ITargetedContentCollection): Cardinal; safecall;
    property Current: TargetedContent_ITargetedContentCollection read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.TargetedContentCollection>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IIterable_1__TargetedContent_ITargetedContentCollection = interface(IInspectable)
  ['{2049F813-37EE-5158-9996-709859F0CE49}']
    function First: IIterator_1__TargetedContent_ITargetedContentCollection; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentCollection>
  IVectorView_1__TargetedContent_ITargetedContentCollection = interface(IInspectable)
  ['{95C4EE43-C628-5A3B-94FD-7A1E33C25E7B}']
    function GetAt(index: Cardinal): TargetedContent_ITargetedContentCollection; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TargetedContent_ITargetedContentCollection; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PTargetedContent_ITargetedContentCollection): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentItemState
  TargetedContent_ITargetedContentItemState = interface(IInspectable)
  ['{73935454-4C65-4B47-A441-472DE53C79B6}']
    function get_ShouldDisplay: Boolean; safecall;
    function get_AppInstallationState: TargetedContent_TargetedContentAppInstallationState; safecall;
    property AppInstallationState: TargetedContent_TargetedContentAppInstallationState read get_AppInstallationState;
    property ShouldDisplay: Boolean read get_ShouldDisplay;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentItem
  TargetedContent_ITargetedContentItem = interface(IInspectable)
  ['{38168DC4-276C-4C32-96BA-565C6E406E74}']
    function get_Path: HSTRING; safecall;
    procedure ReportInteraction(interaction: TargetedContent_TargetedContentInteraction); safecall;
    procedure ReportCustomInteraction(customInteractionName: HSTRING); safecall;
    function get_State: TargetedContent_ITargetedContentItemState; safecall;
    function get_Properties: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue; safecall;
    function get_Collections: IVectorView_1__TargetedContent_ITargetedContentCollection; safecall;
    property Collections: IVectorView_1__TargetedContent_ITargetedContentCollection read get_Collections;
    property Path: HSTRING read get_Path;
    property Properties: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue read get_Properties;
    property State: TargetedContent_ITargetedContentItemState read get_State;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.TargetedContentItem>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IIterator_1__TargetedContent_ITargetedContentItem = interface(IInspectable)
  ['{50109D8E-F711-5076-8309-E4E230EF7E85}']
    function get_Current: TargetedContent_ITargetedContentItem; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PTargetedContent_ITargetedContentItem): Cardinal; safecall;
    property Current: TargetedContent_ITargetedContentItem read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.TargetedContentItem>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IIterable_1__TargetedContent_ITargetedContentItem = interface(IInspectable)
  ['{03F38FB6-54E6-5BF1-913B-9510FEC8BE1F}']
    function First: IIterator_1__TargetedContent_ITargetedContentItem; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.TargetedContent.ITargetedContentItem>
  IVectorView_1__TargetedContent_ITargetedContentItem = interface(IInspectable)
  ['{7D1E349F-F3DB-52DD-8648-0F95A9E2ADBC}']
    function GetAt(index: Cardinal): TargetedContent_ITargetedContentItem; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TargetedContent_ITargetedContentItem; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PTargetedContent_ITargetedContentItem): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentCollection
  TargetedContent_ITargetedContentCollection = interface(IInspectable)
  ['{2D4B66C5-F163-44BA-9F6E-E1A4C2BB559D}']
    function get_Id: HSTRING; safecall;
    procedure ReportInteraction(interaction: TargetedContent_TargetedContentInteraction); safecall;
    procedure ReportCustomInteraction(customInteractionName: HSTRING); safecall;
    function get_Path: HSTRING; safecall;
    function get_Properties: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue; safecall;
    function get_Collections: IVectorView_1__TargetedContent_ITargetedContentCollection; safecall;
    function get_Items: IVectorView_1__TargetedContent_ITargetedContentItem; safecall;
    property Collections: IVectorView_1__TargetedContent_ITargetedContentCollection read get_Collections;
    property Id: HSTRING read get_Id;
    property Items: IVectorView_1__TargetedContent_ITargetedContentItem read get_Items;
    property Path: HSTRING read get_Path;
    property Properties: IMapView_2__HSTRING__TargetedContent_ITargetedContentValue read get_Properties;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentObject
  TargetedContent_ITargetedContentObject = interface(IInspectable)
  ['{041D7969-2212-42D1-9DFA-88A8E3033AA3}']
    function get_ObjectKind: TargetedContent_TargetedContentObjectKind; safecall;
    function get_Collection: TargetedContent_ITargetedContentCollection; safecall;
    function get_Item: TargetedContent_ITargetedContentItem; safecall;
    function get_Value: TargetedContent_ITargetedContentValue; safecall;
    property Collection: TargetedContent_ITargetedContentCollection read get_Collection;
    property Item: TargetedContent_ITargetedContentItem read get_Item;
    property ObjectKind: TargetedContent_TargetedContentObjectKind read get_ObjectKind;
    property Value: TargetedContent_ITargetedContentValue read get_Value;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentContainer
  [WinRTClassNameAttribute(SWindows_Services_TargetedContent_TargetedContentContainer)]
  TargetedContent_ITargetedContentContainer = interface(IInspectable)
  ['{BC2494C9-8837-47C2-850F-D79D64595926}']
    function get_Id: HSTRING; safecall;
    function get_Timestamp: DateTime; safecall;
    function get_Availability: TargetedContent_TargetedContentAvailability; safecall;
    function get_Content: TargetedContent_ITargetedContentCollection; safecall;
    function SelectSingleObject(path: HSTRING): TargetedContent_ITargetedContentObject; safecall;
    property Availability: TargetedContent_TargetedContentAvailability read get_Availability;
    property Content: TargetedContent_ITargetedContentCollection read get_Content;
    property Id: HSTRING read get_Id;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.TargetedContentContainer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.ITargetedContentContainer>
  AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer = interface(IUnknown)
  ['{8FC6BC2A-26CE-50B5-97BB-FCC80CA0871D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__TargetedContent_ITargetedContentContainer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.TargetedContentContainer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.ITargetedContentContainer>
  IAsyncOperation_1__TargetedContent_ITargetedContentContainer = interface(IInspectable)
  ['{E757E0FC-0136-5F63-97B8-6A96B8D0601E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer; safecall;
    function GetResults: TargetedContent_ITargetedContentContainer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentContainer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentContainerStatics
  [WinRTClassNameAttribute(SWindows_Services_TargetedContent_TargetedContentContainer)]
  TargetedContent_ITargetedContentContainerStatics = interface(IInspectable)
  ['{5B47E7FB-2140-4C1F-A736-C59583F227D8}']
    function GetAsync(contentId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentContainer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentStateChangedEventArgs
  TargetedContent_ITargetedContentStateChangedEventArgs = interface(IInspectable)
  ['{9A1CEF3D-8073-4416-8DF2-546835A6414F}']
    function GetDeferral: IDeferral; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.TargetedContentSubscription,Windows.Services.TargetedContent.TargetedContentChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentChangedEventArgs = interface(IUnknown)
  ['{EF11D751-9D56-580D-8A9F-51AE7E8036E3}']
    procedure Invoke(sender: TargetedContent_ITargetedContentSubscription; args: TargetedContent_ITargetedContentChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.TargetedContentSubscription,Windows.Services.TargetedContent.TargetedContentAvailabilityChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentAvailabilityChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentAvailabilityChangedEventArgs = interface(IUnknown)
  ['{99929904-138A-59AC-A11A-FE0042F0FD50}']
    procedure Invoke(sender: TargetedContent_ITargetedContentSubscription; args: TargetedContent_ITargetedContentAvailabilityChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.TargetedContentSubscription,Windows.Services.TargetedContent.TargetedContentStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.TargetedContent.ITargetedContentSubscription,Windows.Services.TargetedContent.ITargetedContentStateChangedEventArgs>
  TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentStateChangedEventArgs = interface(IUnknown)
  ['{C4D5ACBE-F65B-5FA4-9242-D2860DE85D52}']
    procedure Invoke(sender: TargetedContent_ITargetedContentSubscription; args: TargetedContent_ITargetedContentStateChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentSubscription
  [WinRTClassNameAttribute(SWindows_Services_TargetedContent_TargetedContentSubscription)]
  TargetedContent_ITargetedContentSubscription = interface(IInspectable)
  ['{882C2C49-C652-4C7A-ACAD-1F7FA2986C73}']
    function get_Id: HSTRING; safecall;
    function GetContentContainerAsync: IAsyncOperation_1__TargetedContent_ITargetedContentContainer; safecall;
    function add_ContentChanged(handler: TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ContentChanged(cookie: EventRegistrationToken); safecall;
    function add_AvailabilityChanged(handler: TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentAvailabilityChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AvailabilityChanged(cookie: EventRegistrationToken); safecall;
    function add_StateChanged(handler: TypedEventHandler_2__TargetedContent_ITargetedContentSubscription__TargetedContent_ITargetedContentStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(cookie: EventRegistrationToken); safecall;
    property Id: HSTRING read get_Id;
  end;

  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentSubscriptionOptions
  TargetedContent_ITargetedContentSubscriptionOptions = interface(IInspectable)
  ['{61EE6AD0-2C83-421B-8467-413EAF1AEB97}']
    function get_SubscriptionId: HSTRING; safecall;
    function get_AllowPartialContentAvailability: Boolean; safecall;
    procedure put_AllowPartialContentAvailability(value: Boolean); safecall;
    function get_CloudQueryParameters: IMap_2__HSTRING__HSTRING; safecall;
    function get_LocalFilters: IVector_1__HSTRING; safecall;
    procedure Update; safecall;
    property AllowPartialContentAvailability: Boolean read get_AllowPartialContentAvailability write put_AllowPartialContentAvailability;
    property CloudQueryParameters: IMap_2__HSTRING__HSTRING read get_CloudQueryParameters;
    property LocalFilters: IVector_1__HSTRING read get_LocalFilters;
    property SubscriptionId: HSTRING read get_SubscriptionId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.TargetedContentSubscription>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.TargetedContent.ITargetedContentSubscription>
  AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription = interface(IUnknown)
  ['{E4188C71-5A8E-57EC-B0DE-1D314FB3E2CF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__TargetedContent_ITargetedContentSubscription; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.TargetedContentSubscription>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.TargetedContent.ITargetedContentSubscription>
  IAsyncOperation_1__TargetedContent_ITargetedContentSubscription = interface(IInspectable)
  ['{46F16F4B-8EC1-5C4F-B1F5-A7E7ACD63366}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription; safecall;
    function GetResults: TargetedContent_ITargetedContentSubscription; safecall;
    property Completed: AsyncOperationCompletedHandler_1__TargetedContent_ITargetedContentSubscription read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.TargetedContent.ITargetedContentSubscriptionStatics
  [WinRTClassNameAttribute(SWindows_Services_TargetedContent_TargetedContentSubscription)]
  TargetedContent_ITargetedContentSubscriptionStatics = interface(IInspectable)
  ['{FADDFE80-360D-4916-B53C-7EA27090D02A}']
    function GetAsync(subscriptionId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentSubscription; safecall;
    function GetOptions(subscriptionId: HSTRING): TargetedContent_ITargetedContentSubscriptionOptions; safecall;
  end;

  // Windows.Services.Cortana.CortanaSettings
  // DualAPI
  // Implements: Windows.Services.Cortana.ICortanaSettings
  // Statics: "Windows.Services.Cortana.ICortanaSettingsStatics"
  TCortana_CortanaSettings = class(TWinRTGenericImportS<Cortana_ICortanaSettingsStatics>)
  public
    {$REGION 'Cortana_ICortanaSettingsStatics'}
    class function IsSupported: Boolean; static; inline;
    class function GetDefault: Cortana_ICortanaSettings; static; inline;
    {$ENDREGION}
 end;

  // Windows.Services.TargetedContent.TargetedContentContainer
  // DualAPI
  // Implements: Windows.Services.TargetedContent.ITargetedContentContainer
  // Statics: "Windows.Services.TargetedContent.ITargetedContentContainerStatics"
  TTargetedContent_TargetedContentContainer = class(TWinRTGenericImportS<TargetedContent_ITargetedContentContainerStatics>)
  public
    {$REGION 'TargetedContent_ITargetedContentContainerStatics'}
    class function GetAsync(contentId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentContainer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Services.TargetedContent.TargetedContentSubscription
  // DualAPI
  // Implements: Windows.Services.TargetedContent.ITargetedContentSubscription
  // Statics: "Windows.Services.TargetedContent.ITargetedContentSubscriptionStatics"
  TTargetedContent_TargetedContentSubscription = class(TWinRTGenericImportS<TargetedContent_ITargetedContentSubscriptionStatics>)
  public
    {$REGION 'TargetedContent_ITargetedContentSubscriptionStatics'}
    class function GetAsync(subscriptionId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentSubscription; static; inline;
    class function GetOptions(subscriptionId: HSTRING): TargetedContent_ITargetedContentSubscriptionOptions; static; inline;
    {$ENDREGION}
 end;

implementation

{ TCortana_CortanaSettings }

{$REGION 'Windows.Services.Cortana.ICortanaSettingsStatics'}
class function TCortana_CortanaSettings.IsSupported: Boolean;
begin
  Result := Statics.IsSupported;
end;

class function TCortana_CortanaSettings.GetDefault: Cortana_ICortanaSettings;
begin
  Result := Statics.GetDefault;
end;
{$ENDREGION}

{ TTargetedContent_TargetedContentContainer }

{$REGION 'Windows.Services.TargetedContent.ITargetedContentContainerStatics'}
class function TTargetedContent_TargetedContentContainer.GetAsync(contentId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentContainer;
begin
  Result := Statics.GetAsync(contentId);
end;
{$ENDREGION}

{ TTargetedContent_TargetedContentSubscription }

{$REGION 'Windows.Services.TargetedContent.ITargetedContentSubscriptionStatics'}
class function TTargetedContent_TargetedContentSubscription.GetAsync(subscriptionId: HSTRING): IAsyncOperation_1__TargetedContent_ITargetedContentSubscription;
begin
  Result := Statics.GetAsync(subscriptionId);
end;

class function TTargetedContent_TargetedContentSubscription.GetOptions(subscriptionId: HSTRING): TargetedContent_ITargetedContentSubscriptionOptions;
begin
  Result := Statics.GetOptions(subscriptionId);
end;
{$ENDREGION}

end.
