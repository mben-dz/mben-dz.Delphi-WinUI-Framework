{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Management;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.ApplicationModel,
  Winapi.Foundation,
  Winapi.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Management.Deployment.IPackageVolume
  Deployment_IPackageVolume = interface;
  PDeployment_IPackageVolume = ^Deployment_IPackageVolume;

  // Windows.Management.Deployment.IAddPackageOptions
  Deployment_IAddPackageOptions = interface;
  PDeployment_IAddPackageOptions = ^Deployment_IAddPackageOptions;

  // Windows.Management.Deployment.IAddPackageOptions2
  Deployment_IAddPackageOptions2 = interface;
  PDeployment_IAddPackageOptions2 = ^Deployment_IAddPackageOptions2;

  // Windows.Management.Deployment.IDeploymentResult
  Deployment_IDeploymentResult = interface;
  PDeployment_IDeploymentResult = ^Deployment_IDeploymentResult;

  // Windows.Management.Deployment.IDeploymentResult2
  Deployment_IDeploymentResult2 = interface;
  PDeployment_IDeploymentResult2 = ^Deployment_IDeploymentResult2;

  // Windows.Management.Deployment.IPackageAllUserProvisioningOptions
  Deployment_IPackageAllUserProvisioningOptions = interface;
  PDeployment_IPackageAllUserProvisioningOptions = ^Deployment_IPackageAllUserProvisioningOptions;

  // Windows.Management.Deployment.IPackageAllUserProvisioningOptions2
  Deployment_IPackageAllUserProvisioningOptions2 = interface;
  PDeployment_IPackageAllUserProvisioningOptions2 = ^Deployment_IPackageAllUserProvisioningOptions2;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface;
  PAsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = ^AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface;
  PAsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = ^AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface;
  PIAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = ^IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress;

  // Windows.Management.Deployment.IPackageUserInformation
  Deployment_IPackageUserInformation = interface;
  PDeployment_IPackageUserInformation = ^Deployment_IPackageUserInformation;

  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.IPackageUserInformation>
  IIterator_1__Deployment_IPackageUserInformation = interface;
  PIIterator_1__Deployment_IPackageUserInformation = ^IIterator_1__Deployment_IPackageUserInformation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.IPackageUserInformation>
  IIterable_1__Deployment_IPackageUserInformation = interface;
  PIIterable_1__Deployment_IPackageUserInformation = ^IIterable_1__Deployment_IPackageUserInformation;

  // Windows.Management.Deployment.IPackageManager
  Deployment_IPackageManager = interface;
  PDeployment_IPackageManager = ^Deployment_IPackageManager;

  // Windows.Management.Deployment.IPackageManager10
  Deployment_IPackageManager10 = interface;
  PDeployment_IPackageManager10 = ^Deployment_IPackageManager10;

  // Windows.Management.Deployment.IRemovePackageOptions
  Deployment_IRemovePackageOptions = interface;
  PDeployment_IRemovePackageOptions = ^Deployment_IRemovePackageOptions;

  // Windows.Management.Deployment.IPackageManager11
  Deployment_IPackageManager11 = interface;
  PDeployment_IPackageManager11 = ^Deployment_IPackageManager11;

  // Windows.Management.Deployment.IPackageManager12
  Deployment_IPackageManager12 = interface;
  PDeployment_IPackageManager12 = ^Deployment_IPackageManager12;

  // Windows.Management.Deployment.IPackageManager2
  Deployment_IPackageManager2 = interface;
  PDeployment_IPackageManager2 = ^Deployment_IPackageManager2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Management.Deployment.IPackageVolume>
  AsyncOperationCompletedHandler_1__Deployment_IPackageVolume = interface;
  PAsyncOperationCompletedHandler_1__Deployment_IPackageVolume = ^AsyncOperationCompletedHandler_1__Deployment_IPackageVolume;

  // Windows.Foundation.IAsyncOperation`1<Windows.Management.Deployment.IPackageVolume>
  IAsyncOperation_1__Deployment_IPackageVolume = interface;
  PIAsyncOperation_1__Deployment_IPackageVolume = ^IAsyncOperation_1__Deployment_IPackageVolume;

  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.IPackageVolume>
  IIterator_1__Deployment_IPackageVolume = interface;
  PIIterator_1__Deployment_IPackageVolume = ^IIterator_1__Deployment_IPackageVolume;

  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.IPackageVolume>
  IIterable_1__Deployment_IPackageVolume = interface;
  PIIterable_1__Deployment_IPackageVolume = ^IIterable_1__Deployment_IPackageVolume;

  // Windows.Management.Deployment.IPackageManager3
  Deployment_IPackageManager3 = interface;
  PDeployment_IPackageManager3 = ^Deployment_IPackageManager3;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>
  IVectorView_1__Deployment_IPackageVolume = interface;
  PIVectorView_1__Deployment_IPackageVolume = ^IVectorView_1__Deployment_IPackageVolume;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume = ^AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>>
  IAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume = interface;
  PIAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume = ^IAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume;

  // Windows.Management.Deployment.IPackageManager4
  Deployment_IPackageManager4 = interface;
  PDeployment_IPackageManager4 = ^Deployment_IPackageManager4;

  // Windows.Management.Deployment.IPackageManagerDebugSettings
  Deployment_IPackageManagerDebugSettings = interface;
  PDeployment_IPackageManagerDebugSettings = ^Deployment_IPackageManagerDebugSettings;

  // Windows.Management.Deployment.IPackageManager5
  Deployment_IPackageManager5 = interface;
  PDeployment_IPackageManager5 = ^Deployment_IPackageManager5;

  // Windows.Management.Deployment.IPackageManager6
  Deployment_IPackageManager6 = interface;
  PDeployment_IPackageManager6 = ^Deployment_IPackageManager6;

  // Windows.Management.Deployment.IPackageManager7
  Deployment_IPackageManager7 = interface;
  PDeployment_IPackageManager7 = ^Deployment_IPackageManager7;

  // Windows.Management.Deployment.IPackageManager8
  Deployment_IPackageManager8 = interface;
  PDeployment_IPackageManager8 = ^Deployment_IPackageManager8;

  // Windows.Management.Deployment.IStagePackageOptions
  Deployment_IStagePackageOptions = interface;
  PDeployment_IStagePackageOptions = ^Deployment_IStagePackageOptions;

  // Windows.Management.Deployment.IRegisterPackageOptions
  Deployment_IRegisterPackageOptions = interface;
  PDeployment_IRegisterPackageOptions = ^Deployment_IRegisterPackageOptions;

  // Windows.Management.Deployment.IPackageManager9
  Deployment_IPackageManager9 = interface;
  PDeployment_IPackageManager9 = ^Deployment_IPackageManager9;

  // Windows.Management.Deployment.IPackageVolume2
  Deployment_IPackageVolume2 = interface;
  PDeployment_IPackageVolume2 = ^Deployment_IPackageVolume2;

  // Windows.Management.Deployment.IRegisterPackageOptions2
  Deployment_IRegisterPackageOptions2 = interface;
  PDeployment_IRegisterPackageOptions2 = ^Deployment_IRegisterPackageOptions2;

  // Windows.Management.Deployment.IRemovePackageOptions2
  Deployment_IRemovePackageOptions2 = interface;
  PDeployment_IRemovePackageOptions2 = ^Deployment_IRemovePackageOptions2;

  // Windows.Management.Deployment.IStagePackageOptions2
  Deployment_IStagePackageOptions2 = interface;
  PDeployment_IStagePackageOptions2 = ^Deployment_IStagePackageOptions2;

  // Windows.Management.Deployment.Preview.IInstalledClassicAppInfo
  Deployment_Preview_IInstalledClassicAppInfo = interface;
  PDeployment_Preview_IInstalledClassicAppInfo = ^Deployment_Preview_IInstalledClassicAppInfo;

  // Windows.Management.Deployment.Preview.IClassicAppManagerStatics
  Deployment_Preview_IClassicAppManagerStatics = interface;
  PDeployment_Preview_IClassicAppManagerStatics = ^Deployment_Preview_IClassicAppManagerStatics;

  // Windows.Management.IMdmAlert
  IMdmAlert = interface;
  PIMdmAlert = ^IMdmAlert;

  // Windows.Foundation.Collections.IIterator`1<Windows.Management.IMdmAlert>
  IIterator_1__IMdmAlert = interface;
  PIIterator_1__IMdmAlert = ^IIterator_1__IMdmAlert;

  // Windows.Foundation.Collections.IIterable`1<Windows.Management.IMdmAlert>
  IIterable_1__IMdmAlert = interface;
  PIIterable_1__IMdmAlert = ^IIterable_1__IMdmAlert;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Management.IMdmAlert>
  IVectorView_1__IMdmAlert = interface;
  PIVectorView_1__IMdmAlert = ^IVectorView_1__IMdmAlert;

  // Windows.Management.IMdmSession
  IMdmSession = interface;
  PIMdmSession = ^IMdmSession;

  // Windows.Management.IMdmSessionManagerStatics
  IMdmSessionManagerStatics = interface;
  PIMdmSessionManagerStatics = ^IMdmSessionManagerStatics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Management.Policies.INamedPolicyData,Object>
  TypedEventHandler_2__Policies_INamedPolicyData__IInspectable = interface;
  PTypedEventHandler_2__Policies_INamedPolicyData__IInspectable = ^TypedEventHandler_2__Policies_INamedPolicyData__IInspectable;

  // Windows.Management.Policies.INamedPolicyData
  Policies_INamedPolicyData = interface;
  PPolicies_INamedPolicyData = ^Policies_INamedPolicyData;

  // Windows.Management.Policies.INamedPolicyStatics
  Policies_INamedPolicyStatics = interface;
  PPolicies_INamedPolicyStatics = ^Policies_INamedPolicyStatics;

  // Windows.Management.Workplace.IMdmAllowPolicyStatics
  Workplace_IMdmAllowPolicyStatics = interface;
  PWorkplace_IMdmAllowPolicyStatics = ^Workplace_IMdmAllowPolicyStatics;

  // Windows.Management.Workplace.IMdmPolicyStatics2
  Workplace_IMdmPolicyStatics2 = interface;
  PWorkplace_IMdmPolicyStatics2 = ^Workplace_IMdmPolicyStatics2;

  // Windows.Management Enums

  // Windows.Management.Deployment.AddPackageByAppInstallerOptions
  Deployment_AddPackageByAppInstallerOptions = (
    None = 0,
    InstallAllResources = 32,
    ForceTargetAppShutdown = 64,
    RequiredContentGroupOnly = 256,
    LimitToExistingPackages = 512
  );
  PDeployment_AddPackageByAppInstallerOptions = ^Deployment_AddPackageByAppInstallerOptions;

  // Windows.Management.Deployment.DeploymentOptions
  Deployment_DeploymentOptions = (
    None = 0,
    ForceApplicationShutdown = 1,
    DevelopmentMode = 2,
    InstallAllResources = 32,
    ForceTargetApplicationShutdown = 64,
    RequiredContentGroupOnly = 256,
    ForceUpdateFromAnyVersion = 262144,
    RetainFilesOnFailure = 2097152,
    StageInPlace = 4194304
  );
  PDeployment_DeploymentOptions = ^Deployment_DeploymentOptions;

  // Windows.Management.Deployment.DeploymentProgressState
  Deployment_DeploymentProgressState = (
    Queued = 0,
    Processing = 1
  );
  PDeployment_DeploymentProgressState = ^Deployment_DeploymentProgressState;

  // Windows.Management.Deployment.PackageInstallState
  Deployment_PackageInstallState = (
    NotInstalled = 0,
    Staged = 1,
    Installed = 2,
    Paused = 6
  );
  PDeployment_PackageInstallState = ^Deployment_PackageInstallState;

  // Windows.Management.Deployment.PackageState
  Deployment_PackageState = (
    Normal = 0,
    LicenseInvalid = 1,
    Modified = 2,
    Tampered = 3
  );
  PDeployment_PackageState = ^Deployment_PackageState;

  // Windows.Management.Deployment.PackageStatus
  Deployment_PackageStatus = (
    OK = 0,
    LicenseIssue = 1,
    Modified = 2,
    Tampered = 4,
    Disabled = 8
  );
  PDeployment_PackageStatus = ^Deployment_PackageStatus;

  // Windows.Management.Deployment.PackageStubPreference
  Deployment_PackageStubPreference = (
    Full = 0,
    Stub = 1
  );
  PDeployment_PackageStubPreference = ^Deployment_PackageStubPreference;

  // Windows.Management.Deployment.PackageTypes
  Deployment_PackageTypes = (
    None = 0,
    Main = 1,
    Framework = 2,
    Resource = 4,
    Bundle = 8,
    Xap = 16,
    Optional = 32,
    All = -1
  );
  PDeployment_PackageTypes = ^Deployment_PackageTypes;

  // Windows.Management.Deployment.RemovalOptions
  Deployment_RemovalOptions = (
    None = 0,
    PreserveApplicationData = 4096,
    PreserveRoamableApplicationData = 128,
    DeferRemovalWhenPackagesAreInUse = 8192,
    RemoveForAllUsers = 524288
  );
  PDeployment_RemovalOptions = ^Deployment_RemovalOptions;

  // Windows.Management.Deployment.SharedPackageContainerCreationCollisionOptions
  Deployment_SharedPackageContainerCreationCollisionOptions = (
    FailIfExists = 0,
    MergeWithExisting = 1,
    ReplaceExisting = 2
  );
  PDeployment_SharedPackageContainerCreationCollisionOptions = ^Deployment_SharedPackageContainerCreationCollisionOptions;

  // Windows.Management.Deployment.SharedPackageContainerOperationStatus
  Deployment_SharedPackageContainerOperationStatus = (
    Success = 0,
    BlockedByPolicy = 1,
    AlreadyExists = 2,
    PackageFamilyExistsInAnotherContainer = 3,
    NotFound = 4,
    UnknownFailure = 5
  );
  PDeployment_SharedPackageContainerOperationStatus = ^Deployment_SharedPackageContainerOperationStatus;

  // Windows.Management.Deployment.StubPackageOption
  Deployment_StubPackageOption = (
    Default = 0,
    InstallFull = 1,
    InstallStub = 2,
    UsePreference = 3
  );
  PDeployment_StubPackageOption = ^Deployment_StubPackageOption;

  // Windows.Management.MdmAlertDataType
  MdmAlertDataType = (
    &String = 0,
    Base64 = 1,
    Boolean = 2,
    Integer = 3
  );
  PMdmAlertDataType = ^MdmAlertDataType;

  // Windows.Management.MdmAlertMark
  MdmAlertMark = (
    None = 0,
    Fatal = 1,
    Critical = 2,
    Warning = 3,
    Informational = 4
  );
  PMdmAlertMark = ^MdmAlertMark;

  // Windows.Management.MdmSessionState
  MdmSessionState = (
    NotStarted = 0,
    Starting = 1,
    Connecting = 2,
    Communicating = 3,
    AlertStatusAvailable = 4,
    Retrying = 5,
    Completed = 6
  );
  PMdmSessionState = ^MdmSessionState;

  // Windows.Management.Policies.NamedPolicyKind
  Policies_NamedPolicyKind = (
    Invalid = 0,
    Binary = 1,
    Boolean = 2,
    Int32 = 3,
    Int64 = 4,
    &String = 5
  );
  PPolicies_NamedPolicyKind = ^Policies_NamedPolicyKind;

  // Windows.Management.Update.WindowsUpdateAdministratorOptions
  Update_WindowsUpdateAdministratorOptions = (
    None = 0,
    RequireAdministratorApprovalForScans = 1,
    RequireAdministratorApprovalForUpdates = 2,
    RequireAdministratorApprovalForActions = 4
  );
  PUpdate_WindowsUpdateAdministratorOptions = ^Update_WindowsUpdateAdministratorOptions;

  // Windows.Management.Update.WindowsUpdateAdministratorStatus
  Update_WindowsUpdateAdministratorStatus = (
    Succeeded = 0,
    NoAdministratorRegistered = 1,
    OtherAdministratorIsRegistered = 2
  );
  PUpdate_WindowsUpdateAdministratorStatus = ^Update_WindowsUpdateAdministratorStatus;

  // Windows.Management.Update.WindowsUpdateAttentionRequiredReason
  Update_WindowsUpdateAttentionRequiredReason = (
    None = 0,
    SeekerUpdate = 1,
    ReadyToReboot = 2,
    NeedNonMeteredNetwork = 3,
    NeedUserAgreementForMeteredNetwork = 4,
    NeedNetwork = 5,
    NeedMoreSpace = 6,
    BatterySaverEnabled = 7,
    NeedUserInteraction = 8,
    NeedUserAgreementForPolicy = 9,
    CompatibilityError = 10,
    NeedUserInteractionForEula = 11,
    NeedUserInteractionForCta = 12,
    Regulated = 13,
    ExternalReboot = 14,
    OtherUpdate = 15,
    BlockedByProvider = 16,
    BlockedByPostRebootFailure = 17,
    UserEngaged = 18,
    BlockedByBattery = 19,
    Exclusivity = 20,
    BlockedBySerialization = 21,
    ConflictClass = 22,
    BlockedByAdminApproval = 23,
    BlockedByTooManyAttempts = 24,
    BlockedByFailure = 25,
    Demotion = 26,
    BlockedByActiveHours = 27,
    ScheduledForMaintenance = 28,
    PolicyScheduledInstallTime = 29,
    BlockedByOobe = 30,
    DeferredDuringOobe = 31,
    DeferredForSustainableTime = 32
  );
  PUpdate_WindowsUpdateAttentionRequiredReason = ^Update_WindowsUpdateAttentionRequiredReason;

  // Windows.Management.Workplace.MessagingSyncPolicy
  Workplace_MessagingSyncPolicy = (
    Disallowed = 0,
    Allowed = 1,
    Required = 2
  );
  PWorkplace_MessagingSyncPolicy = ^Workplace_MessagingSyncPolicy;

  // Windows.Management Records

  // Windows.Management.Deployment.DeploymentProgress
  Deployment_DeploymentProgress = record
    state: Deployment_DeploymentProgressState;
    percentage: Cardinal;
  end;
  PDeployment_DeploymentProgress = ^Deployment_DeploymentProgress;

  // Windows.Management.Deployment.Preview.DeploymentPreviewContract
  Deployment_Preview_DeploymentPreviewContract = record
  end;
  PDeployment_Preview_DeploymentPreviewContract = ^Deployment_Preview_DeploymentPreviewContract;

  // Windows.Management.Deployment.SharedPackageContainerContract
  Deployment_SharedPackageContainerContract = record
  end;
  PDeployment_SharedPackageContainerContract = ^Deployment_SharedPackageContainerContract;

  // Windows.Management.Update.WindowsUpdateContract
  Update_WindowsUpdateContract = record
  end;
  PUpdate_WindowsUpdateContract = ^Update_WindowsUpdateContract;

  // Windows.Management.Workplace.WorkplaceSettingsContract
  Workplace_WorkplaceSettingsContract = record
  end;
  PWorkplace_WorkplaceSettingsContract = ^Workplace_WorkplaceSettingsContract;

  // Windows.Management Interfaces

  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageVolume
  Deployment_IPackageVolume = interface(IInspectable)
  ['{CF2672C3-1A40-4450-9739-2ACE2E898853}']
    function get_IsOffline: Boolean; safecall;
    function get_IsSystemVolume: Boolean; safecall;
    function get_MountPoint: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_PackageStorePath: HSTRING; safecall;
    function get_SupportsHardLinks: Boolean; safecall;
    function FindPackages: IVector_1__IPackage; overload; safecall;
    function FindPackages(packageName: HSTRING; packagePublisher: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackages(packageFamilyName: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesWithPackageTypes(packageTypes: Deployment_PackageTypes): IVector_1__IPackage; overload; safecall;
    function FindPackagesWithPackageTypes(packageTypes: Deployment_PackageTypes; packageName: HSTRING; packagePublisher: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesWithPackageTypes(packageTypes: Deployment_PackageTypes; packageFamilyName: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackage(packageFullName: HSTRING): IVector_1__IPackage; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING; packageName: HSTRING; packagePublisher: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING; packageFamilyName: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageTypes: Deployment_PackageTypes): IVector_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageTypes: Deployment_PackageTypes; packageName: HSTRING; packagePublisher: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageTypes: Deployment_PackageTypes; packageFamilyName: HSTRING): IVector_1__IPackage; overload; safecall;
    function FindPackageForUser(userSecurityId: HSTRING; packageFullName: HSTRING): IVector_1__IPackage; safecall;
    property IsOffline: Boolean read get_IsOffline;
    property IsSystemVolume: Boolean read get_IsSystemVolume;
    property MountPoint: HSTRING read get_MountPoint;
    property Name: HSTRING read get_Name;
    property PackageStorePath: HSTRING read get_PackageStorePath;
    property SupportsHardLinks: Boolean read get_SupportsHardLinks;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IAddPackageOptions
  [WinRTClassNameAttribute(SWindows_Management_Deployment_AddPackageOptions)]
  Deployment_IAddPackageOptions = interface(IInspectable)
  ['{05CEE018-F68F-422B-95A4-66679EC77FC0}']
    function get_DependencyPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_TargetVolume: Deployment_IPackageVolume; safecall;
    procedure put_TargetVolume(value: Deployment_IPackageVolume); safecall;
    function get_OptionalPackageFamilyNames: IVector_1__HSTRING; safecall;
    function get_OptionalPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_RelatedPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_ExternalLocationUri: IUriRuntimeClass; safecall;
    procedure put_ExternalLocationUri(value: IUriRuntimeClass); safecall;
    function get_StubPackageOption: Deployment_StubPackageOption; safecall;
    procedure put_StubPackageOption(value: Deployment_StubPackageOption); safecall;
    function get_DeveloperMode: Boolean; safecall;
    procedure put_DeveloperMode(value: Boolean); safecall;
    function get_ForceAppShutdown: Boolean; safecall;
    procedure put_ForceAppShutdown(value: Boolean); safecall;
    function get_ForceTargetAppShutdown: Boolean; safecall;
    procedure put_ForceTargetAppShutdown(value: Boolean); safecall;
    function get_ForceUpdateFromAnyVersion: Boolean; safecall;
    procedure put_ForceUpdateFromAnyVersion(value: Boolean); safecall;
    function get_InstallAllResources: Boolean; safecall;
    procedure put_InstallAllResources(value: Boolean); safecall;
    function get_RequiredContentGroupOnly: Boolean; safecall;
    procedure put_RequiredContentGroupOnly(value: Boolean); safecall;
    function get_RetainFilesOnFailure: Boolean; safecall;
    procedure put_RetainFilesOnFailure(value: Boolean); safecall;
    function get_StageInPlace: Boolean; safecall;
    procedure put_StageInPlace(value: Boolean); safecall;
    function get_AllowUnsigned: Boolean; safecall;
    procedure put_AllowUnsigned(value: Boolean); safecall;
    function get_DeferRegistrationWhenPackagesAreInUse: Boolean; safecall;
    procedure put_DeferRegistrationWhenPackagesAreInUse(value: Boolean); safecall;
    property AllowUnsigned: Boolean read get_AllowUnsigned write put_AllowUnsigned;
    property DeferRegistrationWhenPackagesAreInUse: Boolean read get_DeferRegistrationWhenPackagesAreInUse write put_DeferRegistrationWhenPackagesAreInUse;
    property DependencyPackageUris: IVector_1__IUriRuntimeClass read get_DependencyPackageUris;
    property DeveloperMode: Boolean read get_DeveloperMode write put_DeveloperMode;
    property ExternalLocationUri: IUriRuntimeClass read get_ExternalLocationUri write put_ExternalLocationUri;
    property ForceAppShutdown: Boolean read get_ForceAppShutdown write put_ForceAppShutdown;
    property ForceTargetAppShutdown: Boolean read get_ForceTargetAppShutdown write put_ForceTargetAppShutdown;
    property ForceUpdateFromAnyVersion: Boolean read get_ForceUpdateFromAnyVersion write put_ForceUpdateFromAnyVersion;
    property InstallAllResources: Boolean read get_InstallAllResources write put_InstallAllResources;
    property OptionalPackageFamilyNames: IVector_1__HSTRING read get_OptionalPackageFamilyNames;
    property OptionalPackageUris: IVector_1__IUriRuntimeClass read get_OptionalPackageUris;
    property RelatedPackageUris: IVector_1__IUriRuntimeClass read get_RelatedPackageUris;
    property RequiredContentGroupOnly: Boolean read get_RequiredContentGroupOnly write put_RequiredContentGroupOnly;
    property RetainFilesOnFailure: Boolean read get_RetainFilesOnFailure write put_RetainFilesOnFailure;
    property StageInPlace: Boolean read get_StageInPlace write put_StageInPlace;
    property StubPackageOption: Deployment_StubPackageOption read get_StubPackageOption write put_StubPackageOption;
    property TargetVolume: Deployment_IPackageVolume read get_TargetVolume write put_TargetVolume;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IAddPackageOptions2
  Deployment_IAddPackageOptions2 = interface(IInspectable)
  ['{EE515828-BF33-40F7-84AF-1B6FAD2919D7}']
    function get_ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING; safecall;
    function get_LimitToExistingPackages: Boolean; safecall;
    procedure put_LimitToExistingPackages(value: Boolean); safecall;
    property ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING read get_ExpectedDigests;
    property LimitToExistingPackages: Boolean read get_LimitToExistingPackages write put_LimitToExistingPackages;
  end;

  // UsedAPI Interface
  // Windows.Management.Deployment.IDeploymentResult
  Deployment_IDeploymentResult = interface(IInspectable)
  ['{2563B9AE-B77D-4C1F-8A7B-20E6AD515EF3}']
    function get_ErrorText: HSTRING; safecall;
    function get_ActivityId: TGuid; safecall;
    function get_ExtendedErrorCode: HRESULT; safecall;
    property ActivityId: TGuid read get_ActivityId;
    property ErrorText: HSTRING read get_ErrorText;
    property ExtendedErrorCode: HRESULT read get_ExtendedErrorCode;
  end;

  // Windows.Management.Deployment.IDeploymentResult2
  Deployment_IDeploymentResult2 = interface(IInspectable)
  ['{FC0E715C-5A01-4BD7-BCF1-381C8C82E04A}']
    function get_IsRegistered: Boolean; safecall;
    property IsRegistered: Boolean read get_IsRegistered;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageAllUserProvisioningOptions
  [WinRTClassNameAttribute(SWindows_Management_Deployment_PackageAllUserProvisioningOptions)]
  Deployment_IPackageAllUserProvisioningOptions = interface(IInspectable)
  ['{DA35AA22-1DE0-5D3E-99FF-D24F3118BF5E}']
    function get_OptionalPackageFamilyNames: IVector_1__HSTRING; safecall;
    function get_ProjectionOrderPackageFamilyNames: IVector_1__HSTRING; safecall;
    property OptionalPackageFamilyNames: IVector_1__HSTRING read get_OptionalPackageFamilyNames;
    property ProjectionOrderPackageFamilyNames: IVector_1__HSTRING read get_ProjectionOrderPackageFamilyNames;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageAllUserProvisioningOptions2
  Deployment_IPackageAllUserProvisioningOptions2 = interface(IInspectable)
  ['{B9E3CAB5-2D97-579F-9368-D10BB4D4542B}']
    function get_DeferAutomaticRegistration: Boolean; safecall;
    procedure put_DeferAutomaticRegistration(value: Boolean); safecall;
    property DeferAutomaticRegistration: Boolean read get_DeferAutomaticRegistration write put_DeferAutomaticRegistration;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Management.Deployment.DeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface(IUnknown)
  ['{F1B926D1-1796-597A-9BEA-6C6449D03EEF}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; progressInfo: Deployment_DeploymentProgress); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Management.Deployment.DeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface(IUnknown)
  ['{6E1C7129-61E0-5D88-9FD4-F3CE65A05719}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Management.Deployment.DeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Management.Deployment.IDeploymentResult,Windows.Management.Deployment.DeploymentProgress>
  IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress = interface(IInspectable)
  ['{5A97AAB7-B6EA-55AC-A5DC-D5B164D94E94}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function GetResults: Deployment_IDeploymentResult; safecall;
    property Progress: AsyncOperationProgressHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageUserInformation
  Deployment_IPackageUserInformation = interface(IInspectable)
  ['{F6383423-FA09-4CBC-9055-15CA275E2E7E}']
    function get_UserSecurityId: HSTRING; safecall;
    function get_InstallState: Deployment_PackageInstallState; safecall;
    property InstallState: Deployment_PackageInstallState read get_InstallState;
    property UserSecurityId: HSTRING read get_UserSecurityId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.PackageUserInformation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.IPackageUserInformation>
  IIterator_1__Deployment_IPackageUserInformation = interface(IInspectable)
  ['{75660566-AE43-5858-ADA6-D57DDAE90277}']
    function get_Current: Deployment_IPackageUserInformation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDeployment_IPackageUserInformation): Cardinal; safecall;
    property Current: Deployment_IPackageUserInformation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.PackageUserInformation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.IPackageUserInformation>
  IIterable_1__Deployment_IPackageUserInformation = interface(IInspectable)
  ['{341348B9-52C8-5B57-9E91-F19F2A05B188}']
    function First: IIterator_1__Deployment_IPackageUserInformation; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager
  [WinRTClassNameAttribute(SWindows_Management_Deployment_PackageManager)]
  Deployment_IPackageManager = interface(IInspectable)
  ['{9A7D4B65-5E8F-4FC7-A2E5-7F6925CB8B53}']
    function AddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function UpdatePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RemovePackageAsync(packageFullName: HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RegisterPackageAsync(manifestUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function FindPackages: IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING): IIterable_1__IPackage; overload; safecall;
    function FindPackages(packageName: HSTRING; packagePublisher: HSTRING): IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING; packageName: HSTRING; packagePublisher: HSTRING): IIterable_1__IPackage; overload; safecall;
    function FindUsers(packageFullName: HSTRING): IIterable_1__Deployment_IPackageUserInformation; safecall;
    procedure SetPackageState(packageFullName: HSTRING; packageState: Deployment_PackageState); safecall;
    function FindPackage(packageFullName: HSTRING): IPackage; safecall;
    function CleanupPackageForUserAsync(packageName: HSTRING; userSecurityId: HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function FindPackages(packageFamilyName: HSTRING): IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUser(userSecurityId: HSTRING; packageFamilyName: HSTRING): IIterable_1__IPackage; overload; safecall;
    function FindPackageForUser(userSecurityId: HSTRING; packageFullName: HSTRING): IPackage; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager10
  Deployment_IPackageManager10 = interface(IInspectable)
  ['{A7D7D07E-2E66-4093-AED5-E093ED87B3BB}']
    function ProvisionPackageForAllUsersAsync(mainPackageFamilyName: HSTRING; options: Deployment_IPackageAllUserProvisioningOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IRemovePackageOptions
  [WinRTClassNameAttribute(SWindows_Management_Deployment_RemovePackageOptions)]
  Deployment_IRemovePackageOptions = interface(IInspectable)
  ['{13CF01F3-C450-4F7C-A5A3-5E3C631B7462}']
    function get_PreserveApplicationData: Boolean; safecall;
    procedure put_PreserveApplicationData(value: Boolean); safecall;
    function get_PreserveRoamableApplicationData: Boolean; safecall;
    procedure put_PreserveRoamableApplicationData(value: Boolean); safecall;
    function get_RemoveForAllUsers: Boolean; safecall;
    procedure put_RemoveForAllUsers(value: Boolean); safecall;
    property PreserveApplicationData: Boolean read get_PreserveApplicationData write put_PreserveApplicationData;
    property PreserveRoamableApplicationData: Boolean read get_PreserveRoamableApplicationData write put_PreserveRoamableApplicationData;
    property RemoveForAllUsers: Boolean read get_RemoveForAllUsers write put_RemoveForAllUsers;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager11
  Deployment_IPackageManager11 = interface(IInspectable)
  ['{12950B24-C77E-4EA7-8859-325318074E15}']
    function RemovePackageByUriAsync(packageUri: IUriRuntimeClass; options: Deployment_IRemovePackageOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager12
  Deployment_IPackageManager12 = interface(IInspectable)
  ['{5D233ADF-F9E3-4D96-B40D-96788E39539F}']
    function IsPackageRemovalPending(packageFullName: HSTRING): Boolean; safecall;
    function IsPackageRemovalPendingForUser(packageFullName: HSTRING; userSecurityId: HSTRING): Boolean; safecall;
    function IsPackageRemovalPendingByUri(packageUri: IUriRuntimeClass): Boolean; safecall;
    function IsPackageRemovalPendingByUriForUser(packageUri: IUriRuntimeClass; userSecurityId: HSTRING): Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager2
  Deployment_IPackageManager2 = interface(IInspectable)
  ['{F7AAD08D-0840-46F2-B5D8-CAD47693A095}']
    function RemovePackageAsync(packageFullName: HSTRING; removalOptions: Deployment_RemovalOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RegisterPackageByFullNameAsync(mainPackageFullName: HSTRING; dependencyPackageFullNames: IIterable_1__HSTRING; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function FindPackagesWithPackageTypes(packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function FindPackagesWithPackageTypes(packageName: HSTRING; packagePublisher: HSTRING; packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageName: HSTRING; packagePublisher: HSTRING; packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function FindPackagesWithPackageTypes(packageFamilyName: HSTRING; packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function FindPackagesForUserWithPackageTypes(userSecurityId: HSTRING; packageFamilyName: HSTRING; packageTypes: Deployment_PackageTypes): IIterable_1__IPackage; overload; safecall;
    function StageUserDataAsync(packageFullName: HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Management.Deployment.PackageVolume>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Management.Deployment.IPackageVolume>
  AsyncOperationCompletedHandler_1__Deployment_IPackageVolume = interface(IUnknown)
  ['{35FEE361-6CEA-5E5C-8EDA-34B3F22DF4E7}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Deployment_IPackageVolume; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Management.Deployment.PackageVolume>
  // Windows.Foundation.IAsyncOperation`1<Windows.Management.Deployment.IPackageVolume>
  IAsyncOperation_1__Deployment_IPackageVolume = interface(IInspectable)
  ['{0315EDB6-DC58-51CC-A519-44901AD2CF15}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Deployment_IPackageVolume); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Deployment_IPackageVolume; safecall;
    function GetResults: Deployment_IPackageVolume; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Deployment_IPackageVolume read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.PackageVolume>
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.Deployment.IPackageVolume>
  IIterator_1__Deployment_IPackageVolume = interface(IInspectable)
  ['{A8D5B736-4E68-5EF1-9F07-F06837988C73}']
    function get_Current: Deployment_IPackageVolume; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDeployment_IPackageVolume): Cardinal; safecall;
    property Current: Deployment_IPackageVolume read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.PackageVolume>
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.Deployment.IPackageVolume>
  IIterable_1__Deployment_IPackageVolume = interface(IInspectable)
  ['{A6199162-B163-56A1-9980-DB0C3F4E9284}']
    function First: IIterator_1__Deployment_IPackageVolume; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager3
  Deployment_IPackageManager3 = interface(IInspectable)
  ['{DAAD9948-36F1-41A7-9188-BC263E0DCB72}']
    function AddPackageVolumeAsync(packageStorePath: HSTRING): IAsyncOperation_1__Deployment_IPackageVolume; safecall;
    function AddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    procedure ClearPackageStatus(packageFullName: HSTRING; status: Deployment_PackageStatus); safecall;
    function RegisterPackageAsync(manifestUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; appDataVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function FindPackageVolume(volumeName: HSTRING): Deployment_IPackageVolume; safecall;
    function FindPackageVolumes: IIterable_1__Deployment_IPackageVolume; safecall;
    function GetDefaultPackageVolume: Deployment_IPackageVolume; safecall;
    function MovePackageToVolumeAsync(packageFullName: HSTRING; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RemovePackageVolumeAsync(volume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    procedure SetDefaultPackageVolume(volume: Deployment_IPackageVolume); safecall;
    procedure SetPackageStatus(packageFullName: HSTRING; status: Deployment_PackageStatus); safecall;
    function SetPackageVolumeOfflineAsync(packageVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function SetPackageVolumeOnlineAsync(packageVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StageUserDataAsync(packageFullName: HSTRING; deploymentOptions: Deployment_DeploymentOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>
  IVectorView_1__Deployment_IPackageVolume = interface(IInspectable)
  ['{3A73E178-6A1B-565F-9E4D-5FA259CA687E}']
    function GetAt(index: Cardinal): Deployment_IPackageVolume; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Deployment_IPackageVolume; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDeployment_IPackageVolume): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.PackageVolume>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume = interface(IUnknown)
  ['{721241C2-0B83-594A-9B61-CE7F1492C415}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.PackageVolume>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Management.Deployment.IPackageVolume>>
  IAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume = interface(IInspectable)
  ['{1E357E07-D337-5C07-AE06-900C1B9A77C1}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume; safecall;
    function GetResults: IVectorView_1__Deployment_IPackageVolume; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Deployment_IPackageVolume read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager4
  Deployment_IPackageManager4 = interface(IInspectable)
  ['{3C719963-BAB6-46BF-8FF7-DA4719230AE6}']
    function GetPackageVolumesAsync: IAsyncOperation_1__IVectorView_1__Deployment_IPackageVolume; safecall;
  end;

  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManagerDebugSettings
  Deployment_IPackageManagerDebugSettings = interface(IInspectable)
  ['{1A611683-A988-4FCF-8F0F-CE175898E8EB}']
    function SetContentGroupStateAsync(package: IPackage; contentGroupName: HSTRING; state: PackageContentGroupState): IAsyncAction; overload; safecall;
    function SetContentGroupStateAsync(package: IPackage; contentGroupName: HSTRING; state: PackageContentGroupState; completionPercentage: Double): IAsyncAction; overload; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager5
  Deployment_IPackageManager5 = interface(IInspectable)
  ['{711F3117-1AFD-4313-978C-9BB6E1B864A7}']
    function AddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; externalPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; externalPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RegisterPackageByFamilyNameAsync(mainPackageFamilyName: HSTRING; dependencyPackageFamilyNames: IIterable_1__HSTRING; deploymentOptions: Deployment_DeploymentOptions; appDataVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function get_DebugSettings: Deployment_IPackageManagerDebugSettings; safecall;
    property DebugSettings: Deployment_IPackageManagerDebugSettings read get_DebugSettings;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager6
  Deployment_IPackageManager6 = interface(IInspectable)
  ['{0847E909-53CD-4E4F-832E-57D180F6E447}']
    function ProvisionPackageForAllUsersAsync(packageFamilyName: HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function AddPackageByAppInstallerFileAsync(appInstallerFileUri: IUriRuntimeClass; options: Deployment_AddPackageByAppInstallerOptions; targetVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RequestAddPackageByAppInstallerFileAsync(appInstallerFileUri: IUriRuntimeClass; options: Deployment_AddPackageByAppInstallerOptions; targetVolume: Deployment_IPackageVolume): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function AddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; options: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; packageUrisToInstall: IIterable_1__IUriRuntimeClass; relatedPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; options: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; packageUrisToInstall: IIterable_1__IUriRuntimeClass; relatedPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RequestAddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; relatedPackageUris: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager7
  Deployment_IPackageManager7 = interface(IInspectable)
  ['{F28654F4-2BA7-4B80-88D6-BE15F9A23FBA}']
    function RequestAddPackageAsync(packageUri: IUriRuntimeClass; dependencyPackageUris: IIterable_1__IUriRuntimeClass; deploymentOptions: Deployment_DeploymentOptions; targetVolume: Deployment_IPackageVolume; optionalPackageFamilyNames: IIterable_1__HSTRING; relatedPackageUris: IIterable_1__IUriRuntimeClass; packageUrisToInstall: IIterable_1__IUriRuntimeClass): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager8
  Deployment_IPackageManager8 = interface(IInspectable)
  ['{B8575330-1298-4EE2-80EE-7F659C5D2782}']
    function DeprovisionPackageForAllUsersAsync(packageFamilyName: HSTRING): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IStagePackageOptions
  [WinRTClassNameAttribute(SWindows_Management_Deployment_StagePackageOptions)]
  Deployment_IStagePackageOptions = interface(IInspectable)
  ['{0B110C9C-B95D-4C56-BD36-6D656800D06B}']
    function get_DependencyPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_TargetVolume: Deployment_IPackageVolume; safecall;
    procedure put_TargetVolume(value: Deployment_IPackageVolume); safecall;
    function get_OptionalPackageFamilyNames: IVector_1__HSTRING; safecall;
    function get_OptionalPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_RelatedPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_ExternalLocationUri: IUriRuntimeClass; safecall;
    procedure put_ExternalLocationUri(value: IUriRuntimeClass); safecall;
    function get_StubPackageOption: Deployment_StubPackageOption; safecall;
    procedure put_StubPackageOption(value: Deployment_StubPackageOption); safecall;
    function get_DeveloperMode: Boolean; safecall;
    procedure put_DeveloperMode(value: Boolean); safecall;
    function get_ForceUpdateFromAnyVersion: Boolean; safecall;
    procedure put_ForceUpdateFromAnyVersion(value: Boolean); safecall;
    function get_InstallAllResources: Boolean; safecall;
    procedure put_InstallAllResources(value: Boolean); safecall;
    function get_RequiredContentGroupOnly: Boolean; safecall;
    procedure put_RequiredContentGroupOnly(value: Boolean); safecall;
    function get_StageInPlace: Boolean; safecall;
    procedure put_StageInPlace(value: Boolean); safecall;
    function get_AllowUnsigned: Boolean; safecall;
    procedure put_AllowUnsigned(value: Boolean); safecall;
    property AllowUnsigned: Boolean read get_AllowUnsigned write put_AllowUnsigned;
    property DependencyPackageUris: IVector_1__IUriRuntimeClass read get_DependencyPackageUris;
    property DeveloperMode: Boolean read get_DeveloperMode write put_DeveloperMode;
    property ExternalLocationUri: IUriRuntimeClass read get_ExternalLocationUri write put_ExternalLocationUri;
    property ForceUpdateFromAnyVersion: Boolean read get_ForceUpdateFromAnyVersion write put_ForceUpdateFromAnyVersion;
    property InstallAllResources: Boolean read get_InstallAllResources write put_InstallAllResources;
    property OptionalPackageFamilyNames: IVector_1__HSTRING read get_OptionalPackageFamilyNames;
    property OptionalPackageUris: IVector_1__IUriRuntimeClass read get_OptionalPackageUris;
    property RelatedPackageUris: IVector_1__IUriRuntimeClass read get_RelatedPackageUris;
    property RequiredContentGroupOnly: Boolean read get_RequiredContentGroupOnly write put_RequiredContentGroupOnly;
    property StageInPlace: Boolean read get_StageInPlace write put_StageInPlace;
    property StubPackageOption: Deployment_StubPackageOption read get_StubPackageOption write put_StubPackageOption;
    property TargetVolume: Deployment_IPackageVolume read get_TargetVolume write put_TargetVolume;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IRegisterPackageOptions
  [WinRTClassNameAttribute(SWindows_Management_Deployment_RegisterPackageOptions)]
  Deployment_IRegisterPackageOptions = interface(IInspectable)
  ['{677112A7-50D4-496C-8415-0602B4C6D3BF}']
    function get_DependencyPackageUris: IVector_1__IUriRuntimeClass; safecall;
    function get_AppDataVolume: Deployment_IPackageVolume; safecall;
    procedure put_AppDataVolume(value: Deployment_IPackageVolume); safecall;
    function get_OptionalPackageFamilyNames: IVector_1__HSTRING; safecall;
    function get_ExternalLocationUri: IUriRuntimeClass; safecall;
    procedure put_ExternalLocationUri(value: IUriRuntimeClass); safecall;
    function get_DeveloperMode: Boolean; safecall;
    procedure put_DeveloperMode(value: Boolean); safecall;
    function get_ForceAppShutdown: Boolean; safecall;
    procedure put_ForceAppShutdown(value: Boolean); safecall;
    function get_ForceTargetAppShutdown: Boolean; safecall;
    procedure put_ForceTargetAppShutdown(value: Boolean); safecall;
    function get_ForceUpdateFromAnyVersion: Boolean; safecall;
    procedure put_ForceUpdateFromAnyVersion(value: Boolean); safecall;
    function get_InstallAllResources: Boolean; safecall;
    procedure put_InstallAllResources(value: Boolean); safecall;
    function get_StageInPlace: Boolean; safecall;
    procedure put_StageInPlace(value: Boolean); safecall;
    function get_AllowUnsigned: Boolean; safecall;
    procedure put_AllowUnsigned(value: Boolean); safecall;
    function get_DeferRegistrationWhenPackagesAreInUse: Boolean; safecall;
    procedure put_DeferRegistrationWhenPackagesAreInUse(value: Boolean); safecall;
    property AllowUnsigned: Boolean read get_AllowUnsigned write put_AllowUnsigned;
    property AppDataVolume: Deployment_IPackageVolume read get_AppDataVolume write put_AppDataVolume;
    property DeferRegistrationWhenPackagesAreInUse: Boolean read get_DeferRegistrationWhenPackagesAreInUse write put_DeferRegistrationWhenPackagesAreInUse;
    property DependencyPackageUris: IVector_1__IUriRuntimeClass read get_DependencyPackageUris;
    property DeveloperMode: Boolean read get_DeveloperMode write put_DeveloperMode;
    property ExternalLocationUri: IUriRuntimeClass read get_ExternalLocationUri write put_ExternalLocationUri;
    property ForceAppShutdown: Boolean read get_ForceAppShutdown write put_ForceAppShutdown;
    property ForceTargetAppShutdown: Boolean read get_ForceTargetAppShutdown write put_ForceTargetAppShutdown;
    property ForceUpdateFromAnyVersion: Boolean read get_ForceUpdateFromAnyVersion write put_ForceUpdateFromAnyVersion;
    property InstallAllResources: Boolean read get_InstallAllResources write put_InstallAllResources;
    property OptionalPackageFamilyNames: IVector_1__HSTRING read get_OptionalPackageFamilyNames;
    property StageInPlace: Boolean read get_StageInPlace write put_StageInPlace;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IPackageManager9
  Deployment_IPackageManager9 = interface(IInspectable)
  ['{1AA79035-CC71-4B2E-80A6-C7041D8579A7}']
    function FindProvisionedPackages: IVector_1__IPackage; safecall;
    function AddPackageByUriAsync(packageUri: IUriRuntimeClass; options: Deployment_IAddPackageOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function StagePackageByUriAsync(packageUri: IUriRuntimeClass; options: Deployment_IStagePackageOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RegisterPackageByUriAsync(manifestUri: IUriRuntimeClass; options: Deployment_IRegisterPackageOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    function RegisterPackagesByFullNameAsync(packageFullNames: IIterable_1__HSTRING; options: Deployment_IRegisterPackageOptions): IAsyncOperationWithProgress_2__Deployment_IDeploymentResult__Deployment_DeploymentProgress; safecall;
    procedure SetPackageStubPreference(packageFamilyName: HSTRING; useStub: Deployment_PackageStubPreference); safecall;
    function GetPackageStubPreference(packageFamilyName: HSTRING): Deployment_PackageStubPreference; safecall;
  end;

  // Windows.Management.Deployment.IPackageVolume2
  Deployment_IPackageVolume2 = interface(IInspectable)
  ['{46ABCF2E-9DD4-47A2-AB8C-C6408349BCD8}']
    function get_IsFullTrustPackageSupported: Boolean; safecall;
    function get_IsAppxInstallSupported: Boolean; safecall;
    function GetAvailableSpaceAsync: IAsyncOperation_1__UInt64; safecall;
    property IsAppxInstallSupported: Boolean read get_IsAppxInstallSupported;
    property IsFullTrustPackageSupported: Boolean read get_IsFullTrustPackageSupported;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IRegisterPackageOptions2
  Deployment_IRegisterPackageOptions2 = interface(IInspectable)
  ['{3DFA9743-86FF-4A11-BC93-434EB6BE3A0B}']
    function get_ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING; safecall;
    property ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING read get_ExpectedDigests;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IRemovePackageOptions2
  Deployment_IRemovePackageOptions2 = interface(IInspectable)
  ['{3FCC61E5-22C5-423B-B4B4-CF10BB50830C}']
    function get_DeferRemovalWhenPackagesAreInUse: Boolean; safecall;
    procedure put_DeferRemovalWhenPackagesAreInUse(value: Boolean); safecall;
    property DeferRemovalWhenPackagesAreInUse: Boolean read get_DeferRemovalWhenPackagesAreInUse write put_DeferRemovalWhenPackagesAreInUse;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.IStagePackageOptions2
  Deployment_IStagePackageOptions2 = interface(IInspectable)
  ['{990C4CCC-6226-4192-BA92-79875FCE0D9C}']
    function get_ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING; safecall;
    property ExpectedDigests: IMap_2__IUriRuntimeClass__HSTRING read get_ExpectedDigests;
  end;

  // UsedAPI Interface
  // Windows.Management.Deployment.Preview.IInstalledClassicAppInfo
  Deployment_Preview_IInstalledClassicAppInfo = interface(IInspectable)
  ['{0A7D3DA3-65D0-4086-80D6-0610D760207D}']
    function get_DisplayName: HSTRING; safecall;
    function get_DisplayVersion: HSTRING; safecall;
    property DisplayName: HSTRING read get_DisplayName;
    property DisplayVersion: HSTRING read get_DisplayVersion;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Deployment.Preview.IClassicAppManagerStatics
  [WinRTClassNameAttribute(SWindows_Management_Deployment_Preview_ClassicAppManager)]
  Deployment_Preview_IClassicAppManagerStatics = interface(IInspectable)
  ['{E2FAD668-882C-4F33-B035-0DF7B90D67E6}']
    function FindInstalledApp(appUninstallKey: HSTRING): Deployment_Preview_IInstalledClassicAppInfo; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.IMdmAlert
  [WinRTClassNameAttribute(SWindows_Management_MdmAlert)]
  IMdmAlert = interface(IInspectable)
  ['{B0FBC327-28C1-4B52-A548-C5807CAF70B6}']
    function get_Data: HSTRING; safecall;
    procedure put_Data(value: HSTRING); safecall;
    function get_Format: MdmAlertDataType; safecall;
    procedure put_Format(value: MdmAlertDataType); safecall;
    function get_Mark: MdmAlertMark; safecall;
    procedure put_Mark(value: MdmAlertMark); safecall;
    function get_Source: HSTRING; safecall;
    procedure put_Source(value: HSTRING); safecall;
    function get_Status: Cardinal; safecall;
    function get_Target: HSTRING; safecall;
    procedure put_Target(value: HSTRING); safecall;
    function get_Type: HSTRING; safecall;
    procedure put_Type(value: HSTRING); safecall;
    property Data: HSTRING read get_Data write put_Data;
    property Format: MdmAlertDataType read get_Format write put_Format;
    property Mark: MdmAlertMark read get_Mark write put_Mark;
    property Source: HSTRING read get_Source write put_Source;
    property Status: Cardinal read get_Status;
    property Target: HSTRING read get_Target write put_Target;
    property &Type: HSTRING read get_Type write put_Type;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.MdmAlert>
  // Windows.Foundation.Collections.IIterator`1<Windows.Management.IMdmAlert>
  IIterator_1__IMdmAlert = interface(IInspectable)
  ['{B4A6EBEA-B19F-5DA5-B3D1-E859F1F4DF17}']
    function get_Current: IMdmAlert; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMdmAlert): Cardinal; safecall;
    property Current: IMdmAlert read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.MdmAlert>
  // Windows.Foundation.Collections.IIterable`1<Windows.Management.IMdmAlert>
  IIterable_1__IMdmAlert = interface(IInspectable)
  ['{A0A617DC-210C-529F-B5E9-29AECEEBB5A8}']
    function First: IIterator_1__IMdmAlert; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Management.IMdmAlert>
  IVectorView_1__IMdmAlert = interface(IInspectable)
  ['{C964A942-1FBC-5E8F-96E7-8E00139EBD74}']
    function GetAt(index: Cardinal): IMdmAlert; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMdmAlert; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMdmAlert): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Management.IMdmSession
  IMdmSession = interface(IInspectable)
  ['{FE89314C-8F64-4797-A9D7-9D88F86AE166}']
    function get_Alerts: IVectorView_1__IMdmAlert; safecall;
    function get_ExtendedError: HRESULT; safecall;
    function get_Id: HSTRING; safecall;
    function get_State: MdmSessionState; safecall;
    function AttachAsync: IAsyncAction; safecall;
    procedure Delete; safecall;
    function StartAsync: IAsyncAction; overload; safecall;
    function StartAsync(alerts: IIterable_1__IMdmAlert): IAsyncAction; overload; safecall;
    property Alerts: IVectorView_1__IMdmAlert read get_Alerts;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Id: HSTRING read get_Id;
    property State: MdmSessionState read get_State;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.IMdmSessionManagerStatics
  [WinRTClassNameAttribute(SWindows_Management_MdmSessionManager)]
  IMdmSessionManagerStatics = interface(IInspectable)
  ['{CF4AD959-F745-4B79-9B5C-DE0BF8EFE44B}']
    function get_SessionIds: IVectorView_1__HSTRING; safecall;
    function TryCreateSession: IMdmSession; safecall;
    procedure DeleteSessionById(sessionId: HSTRING); safecall;
    function GetSessionById(sessionId: HSTRING): IMdmSession; safecall;
    property SessionIds: IVectorView_1__HSTRING read get_SessionIds;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Management.Policies.NamedPolicyData,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Management.Policies.INamedPolicyData,Object>
  TypedEventHandler_2__Policies_INamedPolicyData__IInspectable = interface(IUnknown)
  ['{791A3C00-5AA2-5F0E-BB17-3480BC2D96CC}']
    procedure Invoke(sender: Policies_INamedPolicyData; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Management.Policies.INamedPolicyData
  Policies_INamedPolicyData = interface(IInspectable)
  ['{38DCB198-95AC-4077-A643-8078CAE26400}']
    function get_Area: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_Kind: Policies_NamedPolicyKind; safecall;
    function get_IsManaged: Boolean; safecall;
    function get_IsUserPolicy: Boolean; safecall;
    function get_User: IUser; safecall;
    function GetBoolean: Boolean; safecall;
    function GetBinary: IBuffer; safecall;
    function GetInt32: Integer; safecall;
    function GetInt64: Int64; safecall;
    function GetString: HSTRING; safecall;
    function add_Changed(changedHandler: TypedEventHandler_2__Policies_INamedPolicyData__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Changed(cookie: EventRegistrationToken); safecall;
    property Area: HSTRING read get_Area;
    property IsManaged: Boolean read get_IsManaged;
    property IsUserPolicy: Boolean read get_IsUserPolicy;
    property Kind: Policies_NamedPolicyKind read get_Kind;
    property Name: HSTRING read get_Name;
    property User: IUser read get_User;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Policies.INamedPolicyStatics
  [WinRTClassNameAttribute(SWindows_Management_Policies_NamedPolicy)]
  Policies_INamedPolicyStatics = interface(IInspectable)
  ['{7F793BE7-76C4-4058-8CAD-67662CD05F0D}']
    function GetPolicyFromPath(area: HSTRING; name: HSTRING): Policies_INamedPolicyData; safecall;
    function GetPolicyFromPathForUser(user: IUser; area: HSTRING; name: HSTRING): Policies_INamedPolicyData; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Workplace.IMdmAllowPolicyStatics
  [WinRTClassNameAttribute(SWindows_Management_Workplace_MdmPolicy)]
  Workplace_IMdmAllowPolicyStatics = interface(IInspectable)
  ['{C39709E7-741C-41F2-A4B6-314C31502586}']
    function IsBrowserAllowed: Boolean; safecall;
    function IsCameraAllowed: Boolean; safecall;
    function IsMicrosoftAccountAllowed: Boolean; safecall;
    function IsStoreAllowed: Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Management.Workplace.IMdmPolicyStatics2
  [WinRTClassNameAttribute(SWindows_Management_Workplace_MdmPolicy)]
  Workplace_IMdmPolicyStatics2 = interface(IInspectable)
  ['{C99C7526-03D4-49F9-A993-43EFCCD265C4}']
    function GetMessagingSyncPolicy: Workplace_MessagingSyncPolicy; safecall;
  end;

  // Windows.Management.Deployment.AddPackageOptions
  // DualAPI
  // Implements: Windows.Management.Deployment.IAddPackageOptions
  // Implements: Windows.Management.Deployment.IAddPackageOptions2
  // Instantiable: "Deployment_IAddPackageOptions"
  TDeployment_AddPackageOptions = class(TWinRTGenericImportI<Deployment_IAddPackageOptions>) end;

  // Windows.Management.Deployment.PackageAllUserProvisioningOptions
  // DualAPI
  // Implements: Windows.Management.Deployment.IPackageAllUserProvisioningOptions
  // Implements: Windows.Management.Deployment.IPackageAllUserProvisioningOptions2
  // Instantiable: "Deployment_IPackageAllUserProvisioningOptions"
  TDeployment_PackageAllUserProvisioningOptions = class(TWinRTGenericImportI<Deployment_IPackageAllUserProvisioningOptions>) end;

  // Windows.Management.Deployment.PackageManager
  // DualAPI
  // Explicitly imported
  // Implements: Windows.Management.Deployment.IPackageManager
  // Implements: Windows.Management.Deployment.IPackageManager2
  // Implements: Windows.Management.Deployment.IPackageManager3
  // Implements: Windows.Management.Deployment.IPackageManager4
  // Implements: Windows.Management.Deployment.IPackageManager5
  // Implements: Windows.Management.Deployment.IPackageManager6
  // Implements: Windows.Management.Deployment.IPackageManager7
  // Implements: Windows.Management.Deployment.IPackageManager8
  // Implements: Windows.Management.Deployment.IPackageManager9
  // Implements: Windows.Management.Deployment.IPackageManager10
  // Implements: Windows.Management.Deployment.IPackageManager11
  // Implements: Windows.Management.Deployment.IPackageManager12
  // Instantiable: "Deployment_IPackageManager"
  TDeployment_PackageManager = class(TWinRTGenericImportI<Deployment_IPackageManager>) end;

  // Windows.Management.Deployment.Preview.ClassicAppManager
  // DualAPI
  // Statics: "Windows.Management.Deployment.Preview.IClassicAppManagerStatics"
  TDeployment_Preview_ClassicAppManager = class(TWinRTGenericImportS<Deployment_Preview_IClassicAppManagerStatics>)
  public
    {$REGION 'Deployment_Preview_IClassicAppManagerStatics'}
    class function FindInstalledApp(appUninstallKey: HSTRING): Deployment_Preview_IInstalledClassicAppInfo; static; inline;
    {$ENDREGION}
 end;

  // Windows.Management.Deployment.RegisterPackageOptions
  // DualAPI
  // Implements: Windows.Management.Deployment.IRegisterPackageOptions
  // Implements: Windows.Management.Deployment.IRegisterPackageOptions2
  // Instantiable: "Deployment_IRegisterPackageOptions"
  TDeployment_RegisterPackageOptions = class(TWinRTGenericImportI<Deployment_IRegisterPackageOptions>) end;

  // Windows.Management.Deployment.RemovePackageOptions
  // DualAPI
  // Implements: Windows.Management.Deployment.IRemovePackageOptions
  // Implements: Windows.Management.Deployment.IRemovePackageOptions2
  // Instantiable: "Deployment_IRemovePackageOptions"
  TDeployment_RemovePackageOptions = class(TWinRTGenericImportI<Deployment_IRemovePackageOptions>) end;

  // Windows.Management.Deployment.StagePackageOptions
  // DualAPI
  // Implements: Windows.Management.Deployment.IStagePackageOptions
  // Implements: Windows.Management.Deployment.IStagePackageOptions2
  // Instantiable: "Deployment_IStagePackageOptions"
  TDeployment_StagePackageOptions = class(TWinRTGenericImportI<Deployment_IStagePackageOptions>) end;

  // Windows.Management.MdmAlert
  // DualAPI
  // Implements: Windows.Management.IMdmAlert
  // Instantiable: "IMdmAlert"
  TMdmAlert = class(TWinRTGenericImportI<IMdmAlert>) end;

  // Windows.Management.MdmSessionManager
  // DualAPI
  // Statics: "Windows.Management.IMdmSessionManagerStatics"
  TMdmSessionManager = class(TWinRTGenericImportS<IMdmSessionManagerStatics>)
  public
    {$REGION 'IMdmSessionManagerStatics'}
    class function get_SessionIds: IVectorView_1__HSTRING; static; inline;
    class function TryCreateSession: IMdmSession; static; inline;
    class procedure DeleteSessionById(sessionId: HSTRING); static; inline;
    class function GetSessionById(sessionId: HSTRING): IMdmSession; static; inline;
    class property SessionIds: IVectorView_1__HSTRING read get_SessionIds;
    {$ENDREGION}
 end;

  // Windows.Management.Policies.NamedPolicy
  // DualAPI
  // Statics: "Windows.Management.Policies.INamedPolicyStatics"
  TPolicies_NamedPolicy = class(TWinRTGenericImportS<Policies_INamedPolicyStatics>)
  public
    {$REGION 'Policies_INamedPolicyStatics'}
    class function GetPolicyFromPath(area: HSTRING; name: HSTRING): Policies_INamedPolicyData; static; inline;
    class function GetPolicyFromPathForUser(user: IUser; area: HSTRING; name: HSTRING): Policies_INamedPolicyData; static; inline;
    {$ENDREGION}
 end;

  // Windows.Management.Workplace.MdmPolicy
  // DualAPI
  // Statics: "Windows.Management.Workplace.IMdmAllowPolicyStatics"
  // Statics: "Windows.Management.Workplace.IMdmPolicyStatics2"
  TWorkplace_MdmPolicy = class(TWinRTGenericImportS2<Workplace_IMdmAllowPolicyStatics, Workplace_IMdmPolicyStatics2>)
  public
    {$REGION 'Workplace_IMdmAllowPolicyStatics'}
    class function IsBrowserAllowed: Boolean; static; inline;
    class function IsCameraAllowed: Boolean; static; inline;
    class function IsMicrosoftAccountAllowed: Boolean; static; inline;
    class function IsStoreAllowed: Boolean; static; inline;
    {$ENDREGION}
    {$REGION 'Workplace_IMdmPolicyStatics2'}
    class function GetMessagingSyncPolicy: Workplace_MessagingSyncPolicy; static; inline;
    {$ENDREGION}
 end;

implementation

{ TDeployment_AddPackageOptions }

{ TDeployment_PackageAllUserProvisioningOptions }

{ TDeployment_PackageManager }

{ TDeployment_Preview_ClassicAppManager }

{$REGION 'Windows.Management.Deployment.Preview.IClassicAppManagerStatics'}
class function TDeployment_Preview_ClassicAppManager.FindInstalledApp(appUninstallKey: HSTRING): Deployment_Preview_IInstalledClassicAppInfo;
begin
  Result := Statics.FindInstalledApp(appUninstallKey);
end;
{$ENDREGION}

{ TDeployment_RegisterPackageOptions }

{ TDeployment_RemovePackageOptions }

{ TDeployment_StagePackageOptions }

{ TMdmAlert }

{ TMdmSessionManager }

{$REGION 'Windows.Management.IMdmSessionManagerStatics'}
class function TMdmSessionManager.get_SessionIds: IVectorView_1__HSTRING;
begin
  Result := Statics.get_SessionIds;
end;

class function TMdmSessionManager.TryCreateSession: IMdmSession;
begin
  Result := Statics.TryCreateSession;
end;

class procedure TMdmSessionManager.DeleteSessionById(sessionId: HSTRING);
begin
  Statics.DeleteSessionById(sessionId);
end;

class function TMdmSessionManager.GetSessionById(sessionId: HSTRING): IMdmSession;
begin
  Result := Statics.GetSessionById(sessionId);
end;
{$ENDREGION}

{ TPolicies_NamedPolicy }

{$REGION 'Windows.Management.Policies.INamedPolicyStatics'}
class function TPolicies_NamedPolicy.GetPolicyFromPath(area: HSTRING; name: HSTRING): Policies_INamedPolicyData;
begin
  Result := Statics.GetPolicyFromPath(area, name);
end;

class function TPolicies_NamedPolicy.GetPolicyFromPathForUser(user: IUser; area: HSTRING; name: HSTRING): Policies_INamedPolicyData;
begin
  Result := Statics.GetPolicyFromPathForUser(user, area, name);
end;
{$ENDREGION}

{ TWorkplace_MdmPolicy }

{$REGION 'Windows.Management.Workplace.IMdmAllowPolicyStatics'}
class function TWorkplace_MdmPolicy.IsBrowserAllowed: Boolean;
begin
  Result := Statics.IsBrowserAllowed;
end;

class function TWorkplace_MdmPolicy.IsCameraAllowed: Boolean;
begin
  Result := Statics.IsCameraAllowed;
end;

class function TWorkplace_MdmPolicy.IsMicrosoftAccountAllowed: Boolean;
begin
  Result := Statics.IsMicrosoftAccountAllowed;
end;

class function TWorkplace_MdmPolicy.IsStoreAllowed: Boolean;
begin
  Result := Statics.IsStoreAllowed;
end;

{$ENDREGION}

{$REGION 'Windows.Management.Workplace.IMdmPolicyStatics2'}
class function TWorkplace_MdmPolicy.GetMessagingSyncPolicy: Workplace_MessagingSyncPolicy;
begin
  Result := Statics2.GetMessagingSyncPolicy;
end;
{$ENDREGION}

end.
