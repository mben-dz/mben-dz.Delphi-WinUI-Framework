{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.ServicesRT.Store;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.ApplicationModel,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStorePackageLicense,Object>
  TypedEventHandler_2__IStorePackageLicense__IInspectable = interface;
  PTypedEventHandler_2__IStorePackageLicense__IInspectable = ^TypedEventHandler_2__IStorePackageLicense__IInspectable;

  // Windows.Services.Store.IStorePackageLicense
  IStorePackageLicense = interface;
  PIStorePackageLicense = ^IStorePackageLicense;

  // Windows.Services.Store.IStoreAcquireLicenseResult
  IStoreAcquireLicenseResult = interface;
  PIStoreAcquireLicenseResult = ^IStoreAcquireLicenseResult;

  // Windows.Services.Store.IStoreLicense
  IStoreLicense = interface;
  PIStoreLicense = ^IStoreLicense;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>
  IKeyValuePair_2__HSTRING__IStoreLicense = interface;
  PIKeyValuePair_2__HSTRING__IStoreLicense = ^IKeyValuePair_2__HSTRING__IStoreLicense;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>>
  IIterator_1__IKeyValuePair_2__HSTRING__IStoreLicense = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IStoreLicense = ^IIterator_1__IKeyValuePair_2__HSTRING__IStoreLicense;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>>
  IIterable_1__IKeyValuePair_2__HSTRING__IStoreLicense = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IStoreLicense = ^IIterable_1__IKeyValuePair_2__HSTRING__IStoreLicense;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.IStoreLicense>
  IMapView_2__HSTRING__IStoreLicense = interface;
  PIMapView_2__HSTRING__IStoreLicense = ^IMapView_2__HSTRING__IStoreLicense;

  // Windows.Services.Store.IStoreAppLicense
  IStoreAppLicense = interface;
  PIStoreAppLicense = ^IStoreAppLicense;

  // Windows.Services.Store.IStorePrice
  IStorePrice = interface;
  PIStorePrice = ^IStorePrice;

  // Windows.Services.Store.IStorePurchaseResult
  IStorePurchaseResult = interface;
  PIStorePurchaseResult = ^IStorePurchaseResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStorePurchaseResult>
  AsyncOperationCompletedHandler_1__IStorePurchaseResult = interface;
  PAsyncOperationCompletedHandler_1__IStorePurchaseResult = ^AsyncOperationCompletedHandler_1__IStorePurchaseResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStorePurchaseResult>
  IAsyncOperation_1__IStorePurchaseResult = interface;
  PIAsyncOperation_1__IStorePurchaseResult = ^IAsyncOperation_1__IStorePurchaseResult;

  // Windows.Services.Store.IStorePurchaseProperties
  IStorePurchaseProperties = interface;
  PIStorePurchaseProperties = ^IStorePurchaseProperties;

  // Windows.Services.Store.IStoreAvailability
  IStoreAvailability = interface;
  PIStoreAvailability = ^IStoreAvailability;

  // Windows.Services.Store.IStoreCanAcquireLicenseResult
  IStoreCanAcquireLicenseResult = interface;
  PIStoreCanAcquireLicenseResult = ^IStoreCanAcquireLicenseResult;

  // Windows.Services.Store.IStoreCollectionData
  IStoreCollectionData = interface;
  PIStoreCollectionData = ^IStoreCollectionData;

  // Windows.Services.Store.IStoreConsumableResult
  IStoreConsumableResult = interface;
  PIStoreConsumableResult = ^IStoreConsumableResult;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreContext,Object>
  TypedEventHandler_2__IStoreContext__IInspectable = interface;
  PTypedEventHandler_2__IStoreContext__IInspectable = ^TypedEventHandler_2__IStoreContext__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreAppLicense>
  AsyncOperationCompletedHandler_1__IStoreAppLicense = interface;
  PAsyncOperationCompletedHandler_1__IStoreAppLicense = ^AsyncOperationCompletedHandler_1__IStoreAppLicense;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreAppLicense>
  IAsyncOperation_1__IStoreAppLicense = interface;
  PIAsyncOperation_1__IStoreAppLicense = ^IAsyncOperation_1__IStoreAppLicense;

  // Windows.Services.Store.IStoreImage
  IStoreImage = interface;
  PIStoreImage = ^IStoreImage;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreImage>
  IIterator_1__IStoreImage = interface;
  PIIterator_1__IStoreImage = ^IIterator_1__IStoreImage;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreImage>
  IIterable_1__IStoreImage = interface;
  PIIterable_1__IStoreImage = ^IIterable_1__IStoreImage;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreImage>
  IVectorView_1__IStoreImage = interface;
  PIVectorView_1__IStoreImage = ^IVectorView_1__IStoreImage;

  // Windows.Services.Store.IStoreVideo
  IStoreVideo = interface;
  PIStoreVideo = ^IStoreVideo;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreVideo>
  IIterator_1__IStoreVideo = interface;
  PIIterator_1__IStoreVideo = ^IIterator_1__IStoreVideo;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreVideo>
  IIterable_1__IStoreVideo = interface;
  PIIterable_1__IStoreVideo = ^IIterable_1__IStoreVideo;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreVideo>
  IVectorView_1__IStoreVideo = interface;
  PIVectorView_1__IStoreVideo = ^IVectorView_1__IStoreVideo;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreAvailability>
  IIterator_1__IStoreAvailability = interface;
  PIIterator_1__IStoreAvailability = ^IIterator_1__IStoreAvailability;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreAvailability>
  IIterable_1__IStoreAvailability = interface;
  PIIterable_1__IStoreAvailability = ^IIterable_1__IStoreAvailability;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreAvailability>
  IVectorView_1__IStoreAvailability = interface;
  PIVectorView_1__IStoreAvailability = ^IVectorView_1__IStoreAvailability;

  // Windows.Services.Store.IStoreSubscriptionInfo
  IStoreSubscriptionInfo = interface;
  PIStoreSubscriptionInfo = ^IStoreSubscriptionInfo;

  // Windows.Services.Store.IStoreSku
  IStoreSku = interface;
  PIStoreSku = ^IStoreSku;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreSku>
  IIterator_1__IStoreSku = interface;
  PIIterator_1__IStoreSku = ^IIterator_1__IStoreSku;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreSku>
  IIterable_1__IStoreSku = interface;
  PIIterable_1__IStoreSku = ^IIterable_1__IStoreSku;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreSku>
  IVectorView_1__IStoreSku = interface;
  PIVectorView_1__IStoreSku = ^IVectorView_1__IStoreSku;

  // Windows.Services.Store.IStoreProduct
  IStoreProduct = interface;
  PIStoreProduct = ^IStoreProduct;

  // Windows.Services.Store.IStoreProductResult
  IStoreProductResult = interface;
  PIStoreProductResult = ^IStoreProductResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductResult>
  AsyncOperationCompletedHandler_1__IStoreProductResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreProductResult = ^AsyncOperationCompletedHandler_1__IStoreProductResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductResult>
  IAsyncOperation_1__IStoreProductResult = interface;
  PIAsyncOperation_1__IStoreProductResult = ^IAsyncOperation_1__IStoreProductResult;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>
  IKeyValuePair_2__HSTRING__IStoreProduct = interface;
  PIKeyValuePair_2__HSTRING__IStoreProduct = ^IKeyValuePair_2__HSTRING__IStoreProduct;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>>
  IIterator_1__IKeyValuePair_2__HSTRING__IStoreProduct = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IStoreProduct = ^IIterator_1__IKeyValuePair_2__HSTRING__IStoreProduct;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>>
  IIterable_1__IKeyValuePair_2__HSTRING__IStoreProduct = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IStoreProduct = ^IIterable_1__IKeyValuePair_2__HSTRING__IStoreProduct;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.IStoreProduct>
  IMapView_2__HSTRING__IStoreProduct = interface;
  PIMapView_2__HSTRING__IStoreProduct = ^IMapView_2__HSTRING__IStoreProduct;

  // Windows.Services.Store.IStoreProductQueryResult
  IStoreProductQueryResult = interface;
  PIStoreProductQueryResult = ^IStoreProductQueryResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductQueryResult>
  AsyncOperationCompletedHandler_1__IStoreProductQueryResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreProductQueryResult = ^AsyncOperationCompletedHandler_1__IStoreProductQueryResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductQueryResult>
  IAsyncOperation_1__IStoreProductQueryResult = interface;
  PIAsyncOperation_1__IStoreProductQueryResult = ^IAsyncOperation_1__IStoreProductQueryResult;

  // Windows.Services.Store.IStoreProductPagedQueryResult
  IStoreProductPagedQueryResult = interface;
  PIStoreProductPagedQueryResult = ^IStoreProductPagedQueryResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductPagedQueryResult>
  AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult = ^AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductPagedQueryResult>
  IAsyncOperation_1__IStoreProductPagedQueryResult = interface;
  PIAsyncOperation_1__IStoreProductPagedQueryResult = ^IAsyncOperation_1__IStoreProductPagedQueryResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreConsumableResult>
  AsyncOperationCompletedHandler_1__IStoreConsumableResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreConsumableResult = ^AsyncOperationCompletedHandler_1__IStoreConsumableResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreConsumableResult>
  IAsyncOperation_1__IStoreConsumableResult = interface;
  PIAsyncOperation_1__IStoreConsumableResult = ^IAsyncOperation_1__IStoreConsumableResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreAcquireLicenseResult>
  AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult = ^AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreAcquireLicenseResult>
  IAsyncOperation_1__IStoreAcquireLicenseResult = interface;
  PIAsyncOperation_1__IStoreAcquireLicenseResult = ^IAsyncOperation_1__IStoreAcquireLicenseResult;

  // Windows.Services.Store.IStorePackageUpdate
  IStorePackageUpdate = interface;
  PIStorePackageUpdate = ^IStorePackageUpdate;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStorePackageUpdate>
  IIterator_1__IStorePackageUpdate = interface;
  PIIterator_1__IStorePackageUpdate = ^IIterator_1__IStorePackageUpdate;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStorePackageUpdate>
  IIterable_1__IStorePackageUpdate = interface;
  PIIterable_1__IStorePackageUpdate = ^IIterable_1__IStorePackageUpdate;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>
  IVectorView_1__IStorePackageUpdate = interface;
  PIVectorView_1__IStorePackageUpdate = ^IVectorView_1__IStorePackageUpdate;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate = ^AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>>
  IAsyncOperation_1__IVectorView_1__IStorePackageUpdate = interface;
  PIAsyncOperation_1__IVectorView_1__IStorePackageUpdate = ^IAsyncOperation_1__IVectorView_1__IStorePackageUpdate;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StorePackageUpdateStatus>
  IIterator_1__StorePackageUpdateStatus = interface;
  PIIterator_1__StorePackageUpdateStatus = ^IIterator_1__StorePackageUpdateStatus;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StorePackageUpdateStatus>
  IIterable_1__StorePackageUpdateStatus = interface;
  PIIterable_1__StorePackageUpdateStatus = ^IIterable_1__StorePackageUpdateStatus;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StorePackageUpdateStatus>
  IVectorView_1__StorePackageUpdateStatus = interface;
  PIVectorView_1__StorePackageUpdateStatus = ^IVectorView_1__StorePackageUpdateStatus;

  // Windows.Services.Store.IStorePackageUpdateResult
  IStorePackageUpdateResult = interface;
  PIStorePackageUpdateResult = ^IStorePackageUpdateResult;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface;
  PAsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = ^AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface;
  PAsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = ^AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface;
  PIAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus = ^IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus;

  // Windows.Services.Store.IStoreContext
  IStoreContext = interface;
  PIStoreContext = ^IStoreContext;

  // Windows.Services.Store.IStoreContext2
  IStoreContext2 = interface;
  PIStoreContext2 = ^IStoreContext2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreCanAcquireLicenseResult>
  AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult = ^AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreCanAcquireLicenseResult>
  IAsyncOperation_1__IStoreCanAcquireLicenseResult = interface;
  PIAsyncOperation_1__IStoreCanAcquireLicenseResult = ^IAsyncOperation_1__IStoreCanAcquireLicenseResult;

  // Windows.Services.Store.IStoreProductOptions
  IStoreProductOptions = interface;
  PIStoreProductOptions = ^IStoreProductOptions;

  // Windows.Services.Store.IStoreQueueItemStatus
  IStoreQueueItemStatus = interface;
  PIStoreQueueItemStatus = ^IStoreQueueItemStatus;

  // Windows.Services.Store.IStoreQueueItemCompletedEventArgs
  IStoreQueueItemCompletedEventArgs = interface;
  PIStoreQueueItemCompletedEventArgs = ^IStoreQueueItemCompletedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreQueueItem,Windows.Services.Store.IStoreQueueItemCompletedEventArgs>
  TypedEventHandler_2__IStoreQueueItem__IStoreQueueItemCompletedEventArgs = interface;
  PTypedEventHandler_2__IStoreQueueItem__IStoreQueueItemCompletedEventArgs = ^TypedEventHandler_2__IStoreQueueItem__IStoreQueueItemCompletedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreQueueItem,Object>
  TypedEventHandler_2__IStoreQueueItem__IInspectable = interface;
  PTypedEventHandler_2__IStoreQueueItem__IInspectable = ^TypedEventHandler_2__IStoreQueueItem__IInspectable;

  // Windows.Services.Store.IStoreQueueItem
  IStoreQueueItem = interface;
  PIStoreQueueItem = ^IStoreQueueItem;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreQueueItem>
  IIterator_1__IStoreQueueItem = interface;
  PIIterator_1__IStoreQueueItem = ^IIterator_1__IStoreQueueItem;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreQueueItem>
  IIterable_1__IStoreQueueItem = interface;
  PIIterable_1__IStoreQueueItem = ^IIterable_1__IStoreQueueItem;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>
  IVectorView_1__IStoreQueueItem = interface;
  PIVectorView_1__IStoreQueueItem = ^IVectorView_1__IStoreQueueItem;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem = ^AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>>
  IAsyncOperation_1__IVectorView_1__IStoreQueueItem = interface;
  PIAsyncOperation_1__IVectorView_1__IStoreQueueItem = ^IAsyncOperation_1__IVectorView_1__IStoreQueueItem;

  // Windows.Services.Store.IStorePackageInstallOptions
  IStorePackageInstallOptions = interface;
  PIStorePackageInstallOptions = ^IStorePackageInstallOptions;

  // Windows.Services.Store.IStoreUninstallStorePackageResult
  IStoreUninstallStorePackageResult = interface;
  PIStoreUninstallStorePackageResult = ^IStoreUninstallStorePackageResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreUninstallStorePackageResult>
  AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult = ^AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreUninstallStorePackageResult>
  IAsyncOperation_1__IStoreUninstallStorePackageResult = interface;
  PIAsyncOperation_1__IStoreUninstallStorePackageResult = ^IAsyncOperation_1__IStoreUninstallStorePackageResult;

  // Windows.Services.Store.IStoreContext3
  IStoreContext3 = interface;
  PIStoreContext3 = ^IStoreContext3;

  // Windows.Services.Store.IStoreRateAndReviewResult
  IStoreRateAndReviewResult = interface;
  PIStoreRateAndReviewResult = ^IStoreRateAndReviewResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreRateAndReviewResult>
  AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult = interface;
  PAsyncOperationCompletedHandler_1__IStoreRateAndReviewResult = ^AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreRateAndReviewResult>
  IAsyncOperation_1__IStoreRateAndReviewResult = interface;
  PIAsyncOperation_1__IStoreRateAndReviewResult = ^IAsyncOperation_1__IStoreRateAndReviewResult;

  // Windows.Services.Store.IStoreContext4
  IStoreContext4 = interface;
  PIStoreContext4 = ^IStoreContext4;

  // Windows.Services.Store.IStoreContext5
  IStoreContext5 = interface;
  PIStoreContext5 = ^IStoreContext5;

  // Windows.Services.Store.IStoreContextStatics
  IStoreContextStatics = interface;
  PIStoreContextStatics = ^IStoreContextStatics;

  // Windows.Services.Store Enums

  // Windows.Services.Store.StoreCanLicenseStatus
  StoreCanLicenseStatus = (
    NotLicensableToUser = 0,
    Licensable = 1,
    LicenseActionNotApplicableToProduct = 2,
    NetworkError = 3,
    ServerError = 4
  );
  PStoreCanLicenseStatus = ^StoreCanLicenseStatus;

  // Windows.Services.Store.StoreConsumableStatus
  StoreConsumableStatus = (
    Succeeded = 0,
    InsufficentQuantity = 1,
    NetworkError = 2,
    ServerError = 3
  );
  PStoreConsumableStatus = ^StoreConsumableStatus;

  // Windows.Services.Store.StoreDurationUnit
  StoreDurationUnit = (
    Minute = 0,
    Hour = 1,
    Day = 2,
    Week = 3,
    Month = 4,
    Year = 5
  );
  PStoreDurationUnit = ^StoreDurationUnit;

  // Windows.Services.Store.StorePackageUpdateState
  StorePackageUpdateState = (
    Pending = 0,
    Downloading = 1,
    Deploying = 2,
    Completed = 3,
    Canceled = 4,
    OtherError = 5,
    ErrorLowBattery = 6,
    ErrorWiFiRecommended = 7,
    ErrorWiFiRequired = 8
  );
  PStorePackageUpdateState = ^StorePackageUpdateState;

  // Windows.Services.Store.StorePurchaseStatus
  StorePurchaseStatus = (
    Succeeded = 0,
    AlreadyPurchased = 1,
    NotPurchased = 2,
    NetworkError = 3,
    ServerError = 4
  );
  PStorePurchaseStatus = ^StorePurchaseStatus;

  // Windows.Services.Store.StoreQueueItemExtendedState
  StoreQueueItemExtendedState = (
    ActivePending = 0,
    ActiveStarting = 1,
    ActiveAcquiringLicense = 2,
    ActiveDownloading = 3,
    ActiveRestoringData = 4,
    ActiveInstalling = 5,
    Completed = 6,
    Canceled = 7,
    Paused = 8,
    Error = 9,
    PausedPackagesInUse = 10,
    PausedLowBattery = 11,
    PausedWiFiRecommended = 12,
    PausedWiFiRequired = 13,
    PausedReadyToInstall = 14
  );
  PStoreQueueItemExtendedState = ^StoreQueueItemExtendedState;

  // Windows.Services.Store.StoreQueueItemKind
  StoreQueueItemKind = (
    Install = 0,
    Update = 1,
    Repair = 2
  );
  PStoreQueueItemKind = ^StoreQueueItemKind;

  // Windows.Services.Store.StoreQueueItemState
  StoreQueueItemState = (
    Active = 0,
    Completed = 1,
    Canceled = 2,
    Error = 3,
    Paused = 4
  );
  PStoreQueueItemState = ^StoreQueueItemState;

  // Windows.Services.Store.StoreRateAndReviewStatus
  StoreRateAndReviewStatus = (
    Succeeded = 0,
    CanceledByUser = 1,
    NetworkError = 2,
    Error = 3
  );
  PStoreRateAndReviewStatus = ^StoreRateAndReviewStatus;

  // Windows.Services.Store.StoreUninstallStorePackageStatus
  StoreUninstallStorePackageStatus = (
    Succeeded = 0,
    CanceledByUser = 1,
    NetworkError = 2,
    UninstallNotApplicable = 3,
    Error = 4
  );
  PStoreUninstallStorePackageStatus = ^StoreUninstallStorePackageStatus;

  // Windows.Services.Store Records

  // Windows.Services.Store.StoreContract
  StoreContract = record
  end;
  PStoreContract = ^StoreContract;

  // Windows.Services.Store.StorePackageUpdateStatus
  StorePackageUpdateStatus = record
    PackageFamilyName: HSTRING;
    PackageDownloadSizeInBytes: UInt64;
    PackageBytesDownloaded: UInt64;
    PackageDownloadProgress: Double;
    TotalDownloadProgress: Double;
    PackageUpdateState: StorePackageUpdateState;
  end;
  PStorePackageUpdateStatus = ^StorePackageUpdateStatus;

  // Windows.Services.Store Interfaces

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.StorePackageLicense,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStorePackageLicense,Object>
  TypedEventHandler_2__IStorePackageLicense__IInspectable = interface(IUnknown)
  ['{6C59D637-2970-5F64-9511-D39AC245BC94}']
    procedure Invoke(sender: IStorePackageLicense; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePackageLicense
  IStorePackageLicense = interface(IInspectable)
  ['{0C465714-14E1-4973-BD14-F77724271E99}']
    function add_LicenseLost(handler: TypedEventHandler_2__IStorePackageLicense__IInspectable): EventRegistrationToken; safecall;
    procedure remove_LicenseLost(token: EventRegistrationToken); safecall;
    function get_Package: IPackage; safecall;
    function get_IsValid: Boolean; safecall;
    procedure ReleaseLicense; safecall;
    property IsValid: Boolean read get_IsValid;
    property Package: IPackage read get_Package;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreAcquireLicenseResult
  IStoreAcquireLicenseResult = interface(IInspectable)
  ['{FBD7946D-F040-4CB3-9A39-29BCECDBE22D}']
    function get_StorePackageLicense: IStorePackageLicense; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property StorePackageLicense: IStorePackageLicense read get_StorePackageLicense;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreLicense
  IStoreLicense = interface(IInspectable)
  ['{26DC9579-4C4F-4F30-BC89-649F60E36055}']
    function get_SkuStoreId: HSTRING; safecall;
    function get_IsActive: Boolean; safecall;
    function get_ExpirationDate: DateTime; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function get_InAppOfferToken: HSTRING; safecall;
    property ExpirationDate: DateTime read get_ExpirationDate;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property InAppOfferToken: HSTRING read get_InAppOfferToken;
    property IsActive: Boolean read get_IsActive;
    property SkuStoreId: HSTRING read get_SkuStoreId;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>
  IKeyValuePair_2__HSTRING__IStoreLicense = interface(IInspectable)
  ['{CEB25B50-83EF-5774-B16E-4BB96C6E4C65}']
    function get_Key: HSTRING; safecall;
    function get_Value: IStoreLicense; safecall;
    property Key: HSTRING read get_Key;
    property Value: IStoreLicense read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.StoreLicense>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>>
  IIterator_1__IKeyValuePair_2__HSTRING__IStoreLicense = interface(IInspectable)
  ['{A1509348-6522-5062-AE86-CF595475926D}']
    function get_Current: IKeyValuePair_2__HSTRING__IStoreLicense; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IStoreLicense): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IStoreLicense read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.StoreLicense>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreLicense>>
  IIterable_1__IKeyValuePair_2__HSTRING__IStoreLicense = interface(IInspectable)
  ['{CA8BA445-6F4D-5DA9-95EE-42CF118DEF63}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IStoreLicense; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.StoreLicense>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.IStoreLicense>
  IMapView_2__HSTRING__IStoreLicense = interface(IInspectable)
  ['{7D0D74F5-4020-54AA-9F3D-0F17127ACDDF}']
    function Lookup(key: HSTRING): IStoreLicense; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IStoreLicense; out second: IMapView_2__HSTRING__IStoreLicense); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreAppLicense
  IStoreAppLicense = interface(IInspectable)
  ['{F389F9DE-73C0-45CE-9BAB-B2FE3E5EAFD3}']
    function get_SkuStoreId: HSTRING; safecall;
    function get_IsActive: Boolean; safecall;
    function get_IsTrial: Boolean; safecall;
    function get_ExpirationDate: DateTime; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function get_AddOnLicenses: IMapView_2__HSTRING__IStoreLicense; safecall;
    function get_TrialTimeRemaining: TimeSpan; safecall;
    function get_IsTrialOwnedByThisUser: Boolean; safecall;
    function get_TrialUniqueId: HSTRING; safecall;
    property AddOnLicenses: IMapView_2__HSTRING__IStoreLicense read get_AddOnLicenses;
    property ExpirationDate: DateTime read get_ExpirationDate;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property IsActive: Boolean read get_IsActive;
    property IsTrial: Boolean read get_IsTrial;
    property IsTrialOwnedByThisUser: Boolean read get_IsTrialOwnedByThisUser;
    property SkuStoreId: HSTRING read get_SkuStoreId;
    property TrialTimeRemaining: TimeSpan read get_TrialTimeRemaining;
    property TrialUniqueId: HSTRING read get_TrialUniqueId;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePrice
  IStorePrice = interface(IInspectable)
  ['{55BA94C4-15F1-407C-8F06-006380F4DF0B}']
    function get_FormattedBasePrice: HSTRING; safecall;
    function get_FormattedPrice: HSTRING; safecall;
    function get_IsOnSale: Boolean; safecall;
    function get_SaleEndDate: DateTime; safecall;
    function get_CurrencyCode: HSTRING; safecall;
    function get_FormattedRecurrencePrice: HSTRING; safecall;
    property CurrencyCode: HSTRING read get_CurrencyCode;
    property FormattedBasePrice: HSTRING read get_FormattedBasePrice;
    property FormattedPrice: HSTRING read get_FormattedPrice;
    property FormattedRecurrencePrice: HSTRING read get_FormattedRecurrencePrice;
    property IsOnSale: Boolean read get_IsOnSale;
    property SaleEndDate: DateTime read get_SaleEndDate;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePurchaseResult
  IStorePurchaseResult = interface(IInspectable)
  ['{ADD28552-F96A-463D-A7BB-C20B4FCA6952}']
    function get_Status: StorePurchaseStatus; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Status: StorePurchaseStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StorePurchaseResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStorePurchaseResult>
  AsyncOperationCompletedHandler_1__IStorePurchaseResult = interface(IUnknown)
  ['{1D9F89EE-2FCE-54E6-A0A9-52D00C52CC3A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStorePurchaseResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StorePurchaseResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStorePurchaseResult>
  IAsyncOperation_1__IStorePurchaseResult = interface(IInspectable)
  ['{33D8CC30-78F5-5F81-AA2D-A4FA2A3B1C68}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStorePurchaseResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStorePurchaseResult; safecall;
    function GetResults: IStorePurchaseResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStorePurchaseResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePurchaseProperties
  IStorePurchaseProperties = interface(IInspectable)
  ['{836278F3-FF87-4364-A5B4-FD2153EBE43B}']
    function get_Name: HSTRING; safecall;
    procedure put_Name(value: HSTRING); safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    procedure put_ExtendedJsonData(value: HSTRING); safecall;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData write put_ExtendedJsonData;
    property Name: HSTRING read get_Name write put_Name;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreAvailability
  IStoreAvailability = interface(IInspectable)
  ['{FA060325-0FFD-4493-AD43-F1F9918F69FA}']
    function get_StoreId: HSTRING; safecall;
    function get_EndDate: DateTime; safecall;
    function get_Price: IStorePrice; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function RequestPurchaseAsync: IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function RequestPurchaseAsync(storePurchaseProperties: IStorePurchaseProperties): IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    property EndDate: DateTime read get_EndDate;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property Price: IStorePrice read get_Price;
    property StoreId: HSTRING read get_StoreId;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreCanAcquireLicenseResult
  IStoreCanAcquireLicenseResult = interface(IInspectable)
  ['{3A693DB3-0088-482F-86D5-BD46522663AD}']
    function get_ExtendedError: HRESULT; safecall;
    function get_LicensableSku: HSTRING; safecall;
    function get_Status: StoreCanLicenseStatus; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property LicensableSku: HSTRING read get_LicensableSku;
    property Status: StoreCanLicenseStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreCollectionData
  IStoreCollectionData = interface(IInspectable)
  ['{8AA4C3B3-5BB3-441A-2AB4-4DAB73D5CE67}']
    function get_IsTrial: Boolean; safecall;
    function get_CampaignId: HSTRING; safecall;
    function get_DeveloperOfferId: HSTRING; safecall;
    function get_AcquiredDate: DateTime; safecall;
    function get_StartDate: DateTime; safecall;
    function get_EndDate: DateTime; safecall;
    function get_TrialTimeRemaining: TimeSpan; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    property AcquiredDate: DateTime read get_AcquiredDate;
    property CampaignId: HSTRING read get_CampaignId;
    property DeveloperOfferId: HSTRING read get_DeveloperOfferId;
    property EndDate: DateTime read get_EndDate;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property IsTrial: Boolean read get_IsTrial;
    property StartDate: DateTime read get_StartDate;
    property TrialTimeRemaining: TimeSpan read get_TrialTimeRemaining;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreConsumableResult
  IStoreConsumableResult = interface(IInspectable)
  ['{EA5DAB72-6A00-4052-BE5B-BFDAB4433352}']
    function get_Status: StoreConsumableStatus; safecall;
    function get_TrackingId: TGuid; safecall;
    function get_BalanceRemaining: Cardinal; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property BalanceRemaining: Cardinal read get_BalanceRemaining;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Status: StoreConsumableStatus read get_Status;
    property TrackingId: TGuid read get_TrackingId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.StoreContext,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreContext,Object>
  TypedEventHandler_2__IStoreContext__IInspectable = interface(IUnknown)
  ['{D5A00AC7-082D-547C-A04B-2540C1CDE97A}']
    procedure Invoke(sender: IStoreContext; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreAppLicense>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreAppLicense>
  AsyncOperationCompletedHandler_1__IStoreAppLicense = interface(IUnknown)
  ['{CEFF1E09-E506-50AD-A908-52038C256552}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreAppLicense; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreAppLicense>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreAppLicense>
  IAsyncOperation_1__IStoreAppLicense = interface(IInspectable)
  ['{3866370B-AFC6-5D01-84C2-4574628DE539}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreAppLicense); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreAppLicense; safecall;
    function GetResults: IStoreAppLicense; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreAppLicense read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreImage
  IStoreImage = interface(IInspectable)
  ['{081FD248-ADB4-4B64-A993-784789926ED5}']
    function get_Uri: IUriRuntimeClass; safecall;
    function get_ImagePurposeTag: HSTRING; safecall;
    function get_Width: Cardinal; safecall;
    function get_Height: Cardinal; safecall;
    function get_Caption: HSTRING; safecall;
    property Caption: HSTRING read get_Caption;
    property Height: Cardinal read get_Height;
    property ImagePurposeTag: HSTRING read get_ImagePurposeTag;
    property Uri: IUriRuntimeClass read get_Uri;
    property Width: Cardinal read get_Width;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StoreImage>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreImage>
  IIterator_1__IStoreImage = interface(IInspectable)
  ['{FBE076F6-C3D2-5DF7-839F-012AC0F951C5}']
    function get_Current: IStoreImage; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStoreImage): Cardinal; safecall;
    property Current: IStoreImage read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StoreImage>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreImage>
  IIterable_1__IStoreImage = interface(IInspectable)
  ['{B2DA6DE8-AD55-56CE-8754-2C96F4FE1C2E}']
    function First: IIterator_1__IStoreImage; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreImage>
  IVectorView_1__IStoreImage = interface(IInspectable)
  ['{641B279E-E8BE-5755-BF5F-058F31ED3A9C}']
    function GetAt(index: Cardinal): IStoreImage; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStoreImage; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStoreImage): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreVideo
  IStoreVideo = interface(IInspectable)
  ['{F26CB184-6F5E-4DC2-886C-3C63083C2F94}']
    function get_Uri: IUriRuntimeClass; safecall;
    function get_VideoPurposeTag: HSTRING; safecall;
    function get_Width: Cardinal; safecall;
    function get_Height: Cardinal; safecall;
    function get_Caption: HSTRING; safecall;
    function get_PreviewImage: IStoreImage; safecall;
    property Caption: HSTRING read get_Caption;
    property Height: Cardinal read get_Height;
    property PreviewImage: IStoreImage read get_PreviewImage;
    property Uri: IUriRuntimeClass read get_Uri;
    property VideoPurposeTag: HSTRING read get_VideoPurposeTag;
    property Width: Cardinal read get_Width;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StoreVideo>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreVideo>
  IIterator_1__IStoreVideo = interface(IInspectable)
  ['{91B0B554-A537-5E22-B39F-6A935D0BEF45}']
    function get_Current: IStoreVideo; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStoreVideo): Cardinal; safecall;
    property Current: IStoreVideo read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StoreVideo>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreVideo>
  IIterable_1__IStoreVideo = interface(IInspectable)
  ['{46BE61E4-7173-565E-AED5-4A2152F1CE69}']
    function First: IIterator_1__IStoreVideo; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreVideo>
  IVectorView_1__IStoreVideo = interface(IInspectable)
  ['{B240054D-573B-589D-9037-E5EC156D3F2C}']
    function GetAt(index: Cardinal): IStoreVideo; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStoreVideo; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStoreVideo): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StoreAvailability>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreAvailability>
  IIterator_1__IStoreAvailability = interface(IInspectable)
  ['{50511CCB-089E-5B73-BB4A-4D1EF77B8F0F}']
    function get_Current: IStoreAvailability; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStoreAvailability): Cardinal; safecall;
    property Current: IStoreAvailability read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StoreAvailability>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreAvailability>
  IIterable_1__IStoreAvailability = interface(IInspectable)
  ['{C58DE1A0-25DE-578B-BB69-E0A26D67B203}']
    function First: IIterator_1__IStoreAvailability; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreAvailability>
  IVectorView_1__IStoreAvailability = interface(IInspectable)
  ['{831B70EA-807A-5FFD-9C1F-FD60E46387D5}']
    function GetAt(index: Cardinal): IStoreAvailability; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStoreAvailability; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStoreAvailability): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreSubscriptionInfo
  IStoreSubscriptionInfo = interface(IInspectable)
  ['{4189776A-0559-43AC-A9C6-3AB0011FB8EB}']
    function get_BillingPeriod: Cardinal; safecall;
    function get_BillingPeriodUnit: StoreDurationUnit; safecall;
    function get_HasTrialPeriod: Boolean; safecall;
    function get_TrialPeriod: Cardinal; safecall;
    function get_TrialPeriodUnit: StoreDurationUnit; safecall;
    property BillingPeriod: Cardinal read get_BillingPeriod;
    property BillingPeriodUnit: StoreDurationUnit read get_BillingPeriodUnit;
    property HasTrialPeriod: Boolean read get_HasTrialPeriod;
    property TrialPeriod: Cardinal read get_TrialPeriod;
    property TrialPeriodUnit: StoreDurationUnit read get_TrialPeriodUnit;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreSku
  IStoreSku = interface(IInspectable)
  ['{397E6F55-4440-4F03-863C-91F3FEC83D79}']
    function get_StoreId: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_Title: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_IsTrial: Boolean; safecall;
    function get_CustomDeveloperData: HSTRING; safecall;
    function get_Images: IVectorView_1__IStoreImage; safecall;
    function get_Videos: IVectorView_1__IStoreVideo; safecall;
    function get_Availabilities: IVectorView_1__IStoreAvailability; safecall;
    function get_Price: IStorePrice; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function get_IsInUserCollection: Boolean; safecall;
    function get_BundledSkus: IVectorView_1__HSTRING; safecall;
    function get_CollectionData: IStoreCollectionData; safecall;
    function GetIsInstalledAsync: IAsyncOperation_1__Boolean; safecall;
    function RequestPurchaseAsync: IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function RequestPurchaseAsync(storePurchaseProperties: IStorePurchaseProperties): IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function get_IsSubscription: Boolean; safecall;
    function get_SubscriptionInfo: IStoreSubscriptionInfo; safecall;
    property Availabilities: IVectorView_1__IStoreAvailability read get_Availabilities;
    property BundledSkus: IVectorView_1__HSTRING read get_BundledSkus;
    property CollectionData: IStoreCollectionData read get_CollectionData;
    property CustomDeveloperData: HSTRING read get_CustomDeveloperData;
    property Description: HSTRING read get_Description;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property Images: IVectorView_1__IStoreImage read get_Images;
    property IsInUserCollection: Boolean read get_IsInUserCollection;
    property IsSubscription: Boolean read get_IsSubscription;
    property IsTrial: Boolean read get_IsTrial;
    property Language: HSTRING read get_Language;
    property Price: IStorePrice read get_Price;
    property StoreId: HSTRING read get_StoreId;
    property SubscriptionInfo: IStoreSubscriptionInfo read get_SubscriptionInfo;
    property Title: HSTRING read get_Title;
    property Videos: IVectorView_1__IStoreVideo read get_Videos;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StoreSku>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreSku>
  IIterator_1__IStoreSku = interface(IInspectable)
  ['{365CDE92-7FE3-59D5-B8F8-8F05ACF50947}']
    function get_Current: IStoreSku; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStoreSku): Cardinal; safecall;
    property Current: IStoreSku read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StoreSku>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreSku>
  IIterable_1__IStoreSku = interface(IInspectable)
  ['{522D34EF-4B5A-5B44-A046-7A16051D011E}']
    function First: IIterator_1__IStoreSku; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreSku>
  IVectorView_1__IStoreSku = interface(IInspectable)
  ['{C66AA27F-F6F7-53FB-A2A2-1C7CB2E12F78}']
    function GetAt(index: Cardinal): IStoreSku; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStoreSku; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStoreSku): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreProduct
  IStoreProduct = interface(IInspectable)
  ['{320E2C52-D760-450A-A42B-67D1E901AC90}']
    function get_StoreId: HSTRING; safecall;
    function get_Language: HSTRING; safecall;
    function get_Title: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_ProductKind: HSTRING; safecall;
    function get_HasDigitalDownload: Boolean; safecall;
    function get_Keywords: IVectorView_1__HSTRING; safecall;
    function get_Images: IVectorView_1__IStoreImage; safecall;
    function get_Videos: IVectorView_1__IStoreVideo; safecall;
    function get_Skus: IVectorView_1__IStoreSku; safecall;
    function get_IsInUserCollection: Boolean; safecall;
    function get_Price: IStorePrice; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function get_LinkUri: IUriRuntimeClass; safecall;
    function GetIsAnySkuInstalledAsync: IAsyncOperation_1__Boolean; safecall;
    function RequestPurchaseAsync: IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function RequestPurchaseAsync(storePurchaseProperties: IStorePurchaseProperties): IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function get_InAppOfferToken: HSTRING; safecall;
    property Description: HSTRING read get_Description;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property HasDigitalDownload: Boolean read get_HasDigitalDownload;
    property Images: IVectorView_1__IStoreImage read get_Images;
    property InAppOfferToken: HSTRING read get_InAppOfferToken;
    property IsInUserCollection: Boolean read get_IsInUserCollection;
    property Keywords: IVectorView_1__HSTRING read get_Keywords;
    property Language: HSTRING read get_Language;
    property LinkUri: IUriRuntimeClass read get_LinkUri;
    property Price: IStorePrice read get_Price;
    property ProductKind: HSTRING read get_ProductKind;
    property Skus: IVectorView_1__IStoreSku read get_Skus;
    property StoreId: HSTRING read get_StoreId;
    property Title: HSTRING read get_Title;
    property Videos: IVectorView_1__IStoreVideo read get_Videos;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreProductResult
  IStoreProductResult = interface(IInspectable)
  ['{B7674F73-3C87-4EE1-8201-F428359BD3AF}']
    function get_Product: IStoreProduct; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Product: IStoreProduct read get_Product;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreProductResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductResult>
  AsyncOperationCompletedHandler_1__IStoreProductResult = interface(IUnknown)
  ['{EB93E936-D515-5414-9D15-F050C0B8F521}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreProductResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreProductResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductResult>
  IAsyncOperation_1__IStoreProductResult = interface(IInspectable)
  ['{9E61E86B-6AFB-50AE-AFC1-C59F545108DD}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreProductResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreProductResult; safecall;
    function GetResults: IStoreProductResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreProductResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>
  IKeyValuePair_2__HSTRING__IStoreProduct = interface(IInspectable)
  ['{7649AE79-029E-51E4-AE99-7E3AB8D9EC53}']
    function get_Key: HSTRING; safecall;
    function get_Value: IStoreProduct; safecall;
    property Key: HSTRING read get_Key;
    property Value: IStoreProduct read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.StoreProduct>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>>
  IIterator_1__IKeyValuePair_2__HSTRING__IStoreProduct = interface(IInspectable)
  ['{0EDB142C-9D04-532B-81E9-4C84AB09B34B}']
    function get_Current: IKeyValuePair_2__HSTRING__IStoreProduct; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IStoreProduct): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IStoreProduct read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.StoreProduct>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.Store.IStoreProduct>>
  IIterable_1__IKeyValuePair_2__HSTRING__IStoreProduct = interface(IInspectable)
  ['{78A33722-ABFB-57C0-853F-5616A3AB8D57}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IStoreProduct; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.StoreProduct>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Services.Store.IStoreProduct>
  IMapView_2__HSTRING__IStoreProduct = interface(IInspectable)
  ['{DBAAC6E5-61A4-5C88-B5D8-3A3E161C3E4A}']
    function Lookup(key: HSTRING): IStoreProduct; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IStoreProduct; out second: IMapView_2__HSTRING__IStoreProduct); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreProductQueryResult
  IStoreProductQueryResult = interface(IInspectable)
  ['{D805E6C5-D456-4FF6-8049-9076D5165F73}']
    function get_Products: IMapView_2__HSTRING__IStoreProduct; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Products: IMapView_2__HSTRING__IStoreProduct read get_Products;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreProductQueryResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductQueryResult>
  AsyncOperationCompletedHandler_1__IStoreProductQueryResult = interface(IUnknown)
  ['{02F4A42C-0458-58D6-923C-B44BA8EF2222}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreProductQueryResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreProductQueryResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductQueryResult>
  IAsyncOperation_1__IStoreProductQueryResult = interface(IInspectable)
  ['{9699E7BB-EA1F-5E03-9439-C80E6977B711}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreProductQueryResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreProductQueryResult; safecall;
    function GetResults: IStoreProductQueryResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreProductQueryResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreProductPagedQueryResult
  IStoreProductPagedQueryResult = interface(IInspectable)
  ['{C92718C5-4DD5-4869-A462-ECC6872E43C5}']
    function get_Products: IMapView_2__HSTRING__IStoreProduct; safecall;
    function get_HasMoreResults: Boolean; safecall;
    function get_ExtendedError: HRESULT; safecall;
    function GetNextAsync: IAsyncOperation_1__IStoreProductPagedQueryResult; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property HasMoreResults: Boolean read get_HasMoreResults;
    property Products: IMapView_2__HSTRING__IStoreProduct read get_Products;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreProductPagedQueryResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreProductPagedQueryResult>
  AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult = interface(IUnknown)
  ['{E786321F-B791-5E38-8BC4-98CB287D1085}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreProductPagedQueryResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreProductPagedQueryResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreProductPagedQueryResult>
  IAsyncOperation_1__IStoreProductPagedQueryResult = interface(IInspectable)
  ['{3079E7DB-1BA4-5B9E-856A-6576BF7F9C8A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult; safecall;
    function GetResults: IStoreProductPagedQueryResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreProductPagedQueryResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreConsumableResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreConsumableResult>
  AsyncOperationCompletedHandler_1__IStoreConsumableResult = interface(IUnknown)
  ['{3F2BB178-3C4E-56ED-86A5-AD13797CFBFD}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreConsumableResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreConsumableResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreConsumableResult>
  IAsyncOperation_1__IStoreConsumableResult = interface(IInspectable)
  ['{873C497B-C3F7-5657-B921-3E58CE48EE50}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreConsumableResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreConsumableResult; safecall;
    function GetResults: IStoreConsumableResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreConsumableResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreAcquireLicenseResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreAcquireLicenseResult>
  AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult = interface(IUnknown)
  ['{6987C97C-2C19-5F44-B5AC-37393F3C1A4A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreAcquireLicenseResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreAcquireLicenseResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreAcquireLicenseResult>
  IAsyncOperation_1__IStoreAcquireLicenseResult = interface(IInspectable)
  ['{DD6C4705-A76C-528E-99A5-CDD13197D4CF}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult; safecall;
    function GetResults: IStoreAcquireLicenseResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreAcquireLicenseResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePackageUpdate
  IStorePackageUpdate = interface(IInspectable)
  ['{140FA150-3CBF-4A35-B91F-48271C31B072}']
    function get_Package: IPackage; safecall;
    function get_Mandatory: Boolean; safecall;
    property Mandatory: Boolean read get_Mandatory;
    property Package: IPackage read get_Package;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StorePackageUpdate>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStorePackageUpdate>
  IIterator_1__IStorePackageUpdate = interface(IInspectable)
  ['{B75DD77B-87CA-5956-8902-84E9FFC97D83}']
    function get_Current: IStorePackageUpdate; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStorePackageUpdate): Cardinal; safecall;
    property Current: IStorePackageUpdate read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StorePackageUpdate>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStorePackageUpdate>
  IIterable_1__IStorePackageUpdate = interface(IInspectable)
  ['{6B076C51-849E-5EC5-AED5-9B0585591902}']
    function First: IIterator_1__IStorePackageUpdate; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>
  IVectorView_1__IStorePackageUpdate = interface(IInspectable)
  ['{8E067DA9-4FAA-560F-BCE3-D974664BC4AC}']
    function GetAt(index: Cardinal): IStorePackageUpdate; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStorePackageUpdate; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStorePackageUpdate): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StorePackageUpdate>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate = interface(IUnknown)
  ['{F8491BCD-2DB5-58E0-8C47-44E6EB10C12D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IStorePackageUpdate; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StorePackageUpdate>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStorePackageUpdate>>
  IAsyncOperation_1__IVectorView_1__IStorePackageUpdate = interface(IInspectable)
  ['{0AC66C33-45B8-546B-AAAF-D58D62A4C5C5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate; safecall;
    function GetResults: IVectorView_1__IStorePackageUpdate; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStorePackageUpdate read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StorePackageUpdateStatus>
  IIterator_1__StorePackageUpdateStatus = interface(IInspectable)
  ['{6181D84F-F731-57B8-9A6B-8A12FCD58D04}']
    function get_Current: StorePackageUpdateStatus; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PStorePackageUpdateStatus): Cardinal; safecall;
    property Current: StorePackageUpdateStatus read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StorePackageUpdateStatus>
  IIterable_1__StorePackageUpdateStatus = interface(IInspectable)
  ['{60832223-7EB4-5CD7-8340-F5077173D364}']
    function First: IIterator_1__StorePackageUpdateStatus; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StorePackageUpdateStatus>
  IVectorView_1__StorePackageUpdateStatus = interface(IInspectable)
  ['{68E2F036-4982-55E3-8C0F-9BF4E69AA45A}']
    function GetAt(index: Cardinal): StorePackageUpdateStatus; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: StorePackageUpdateStatus; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PStorePackageUpdateStatus): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePackageUpdateResult
  IStorePackageUpdateResult = interface(IInspectable)
  ['{E79142ED-61F9-4893-B4FE-CF191603AF7B}']
    function get_OverallState: StorePackageUpdateState; safecall;
    function get_StorePackageUpdateStatuses: IVectorView_1__StorePackageUpdateStatus; safecall;
    property OverallState: StorePackageUpdateState read get_OverallState;
    property StorePackageUpdateStatuses: IVectorView_1__StorePackageUpdateStatus read get_StorePackageUpdateStatuses;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Services.Store.StorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface(IUnknown)
  ['{961260F1-7352-5EDF-9666-1F9A0A8EE477}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; progressInfo: StorePackageUpdateStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Services.Store.StorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface(IUnknown)
  ['{B3BE0C8B-EF1D-56DC-8547-4DA06EA563DF}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Services.Store.StorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Services.Store.IStorePackageUpdateResult,Windows.Services.Store.StorePackageUpdateStatus>
  IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus = interface(IInspectable)
  ['{42C436CA-51F7-50B2-8FE4-7B754062E6EB}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function GetResults: IStorePackageUpdateResult; safecall;
    property Progress: AsyncOperationProgressHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__IStorePackageUpdateResult__StorePackageUpdateStatus read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContext
  [WinRTClassNameAttribute(SWindows_Services_Store_StoreContext)]
  IStoreContext = interface(IInspectable)
  ['{AC98B6BE-F4FD-4912-BABD-5035E5E8BCAB}']
    function get_User: IUser; safecall;
    function add_OfflineLicensesChanged(handler: TypedEventHandler_2__IStoreContext__IInspectable): EventRegistrationToken; safecall;
    procedure remove_OfflineLicensesChanged(token: EventRegistrationToken); safecall;
    function GetCustomerPurchaseIdAsync(serviceTicket: HSTRING; publisherUserId: HSTRING): IAsyncOperation_1__HSTRING; safecall;
    function GetCustomerCollectionsIdAsync(serviceTicket: HSTRING; publisherUserId: HSTRING): IAsyncOperation_1__HSTRING; safecall;
    function GetAppLicenseAsync: IAsyncOperation_1__IStoreAppLicense; safecall;
    function GetStoreProductForCurrentAppAsync: IAsyncOperation_1__IStoreProductResult; safecall;
    function GetStoreProductsAsync(productKinds: IIterable_1__HSTRING; storeIds: IIterable_1__HSTRING): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function GetAssociatedStoreProductsAsync(productKinds: IIterable_1__HSTRING): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function GetAssociatedStoreProductsWithPagingAsync(productKinds: IIterable_1__HSTRING; maxItemsToRetrievePerPage: Cardinal): IAsyncOperation_1__IStoreProductPagedQueryResult; safecall;
    function GetUserCollectionAsync(productKinds: IIterable_1__HSTRING): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function GetUserCollectionWithPagingAsync(productKinds: IIterable_1__HSTRING; maxItemsToRetrievePerPage: Cardinal): IAsyncOperation_1__IStoreProductPagedQueryResult; safecall;
    function ReportConsumableFulfillmentAsync(productStoreId: HSTRING; quantity: Cardinal; trackingId: TGuid): IAsyncOperation_1__IStoreConsumableResult; safecall;
    function GetConsumableBalanceRemainingAsync(productStoreId: HSTRING): IAsyncOperation_1__IStoreConsumableResult; safecall;
    function AcquireStoreLicenseForOptionalPackageAsync(optionalPackage: IPackage): IAsyncOperation_1__IStoreAcquireLicenseResult; safecall;
    function RequestPurchaseAsync(storeId: HSTRING): IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function RequestPurchaseAsync(storeId: HSTRING; storePurchaseProperties: IStorePurchaseProperties): IAsyncOperation_1__IStorePurchaseResult; overload; safecall;
    function GetAppAndOptionalStorePackageUpdatesAsync: IAsyncOperation_1__IVectorView_1__IStorePackageUpdate; safecall;
    function RequestDownloadStorePackageUpdatesAsync(storePackageUpdates: IIterable_1__IStorePackageUpdate): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function RequestDownloadAndInstallStorePackageUpdatesAsync(storePackageUpdates: IIterable_1__IStorePackageUpdate): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function RequestDownloadAndInstallStorePackagesAsync(storeIds: IIterable_1__HSTRING): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    property User: IUser read get_User;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContext2
  IStoreContext2 = interface(IInspectable)
  ['{18BC54DA-7BD9-452C-9116-3BBD06FFC63A}']
    function FindStoreProductForPackageAsync(productKinds: IIterable_1__HSTRING; package: IPackage): IAsyncOperation_1__IStoreProductResult; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreCanAcquireLicenseResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreCanAcquireLicenseResult>
  AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult = interface(IUnknown)
  ['{572A21D0-7150-50BA-A558-D91DFFEC1A24}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreCanAcquireLicenseResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreCanAcquireLicenseResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreCanAcquireLicenseResult>
  IAsyncOperation_1__IStoreCanAcquireLicenseResult = interface(IInspectable)
  ['{71AE9F6E-0D10-5BDB-B441-9312E3D2EFC2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult; safecall;
    function GetResults: IStoreCanAcquireLicenseResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreCanAcquireLicenseResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreProductOptions
  IStoreProductOptions = interface(IInspectable)
  ['{5B34A0F9-A113-4811-8326-16199C927F31}']
    function get_ActionFilters: IVector_1__HSTRING; safecall;
    property ActionFilters: IVector_1__HSTRING read get_ActionFilters;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreQueueItemStatus
  IStoreQueueItemStatus = interface(IInspectable)
  ['{9BD6796F-9CC3-4EC3-B2EF-7BE433B30174}']
    function get_PackageInstallState: StoreQueueItemState; safecall;
    function get_PackageInstallExtendedState: StoreQueueItemExtendedState; safecall;
    function get_UpdateStatus: StorePackageUpdateStatus; safecall;
    function get_ExtendedError: HRESULT; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property PackageInstallExtendedState: StoreQueueItemExtendedState read get_PackageInstallExtendedState;
    property PackageInstallState: StoreQueueItemState read get_PackageInstallState;
    property UpdateStatus: StorePackageUpdateStatus read get_UpdateStatus;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreQueueItemCompletedEventArgs
  IStoreQueueItemCompletedEventArgs = interface(IInspectable)
  ['{1247DF6C-B44A-439B-BB07-1D3003D005C2}']
    function get_Status: IStoreQueueItemStatus; safecall;
    property Status: IStoreQueueItemStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.StoreQueueItem,Windows.Services.Store.StoreQueueItemCompletedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreQueueItem,Windows.Services.Store.IStoreQueueItemCompletedEventArgs>
  TypedEventHandler_2__IStoreQueueItem__IStoreQueueItemCompletedEventArgs = interface(IUnknown)
  ['{2BAC2880-78FD-5CBE-8271-7D583E4EC2C4}']
    procedure Invoke(sender: IStoreQueueItem; args: IStoreQueueItemCompletedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.StoreQueueItem,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Services.Store.IStoreQueueItem,Object>
  TypedEventHandler_2__IStoreQueueItem__IInspectable = interface(IUnknown)
  ['{F8AE3690-F9DB-57E8-843E-244C0A6A13E0}']
    procedure Invoke(sender: IStoreQueueItem; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreQueueItem
  IStoreQueueItem = interface(IInspectable)
  ['{56D5C32B-F830-4293-9188-CAD2DCDE7357}']
    function get_ProductId: HSTRING; safecall;
    function get_PackageFamilyName: HSTRING; safecall;
    function get_InstallKind: StoreQueueItemKind; safecall;
    function GetCurrentStatus: IStoreQueueItemStatus; safecall;
    function add_Completed(handler: TypedEventHandler_2__IStoreQueueItem__IStoreQueueItemCompletedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Completed(token: EventRegistrationToken); safecall;
    function add_StatusChanged(handler: TypedEventHandler_2__IStoreQueueItem__IInspectable): EventRegistrationToken; safecall;
    procedure remove_StatusChanged(token: EventRegistrationToken); safecall;
    property InstallKind: StoreQueueItemKind read get_InstallKind;
    property PackageFamilyName: HSTRING read get_PackageFamilyName;
    property ProductId: HSTRING read get_ProductId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.StoreQueueItem>
  // Windows.Foundation.Collections.IIterator`1<Windows.Services.Store.IStoreQueueItem>
  IIterator_1__IStoreQueueItem = interface(IInspectable)
  ['{907DD469-85B9-52E7-B52F-7310A44745EF}']
    function get_Current: IStoreQueueItem; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIStoreQueueItem): Cardinal; safecall;
    property Current: IStoreQueueItem read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.StoreQueueItem>
  // Windows.Foundation.Collections.IIterable`1<Windows.Services.Store.IStoreQueueItem>
  IIterable_1__IStoreQueueItem = interface(IInspectable)
  ['{68EB92E6-3CC6-5259-9A05-BD7F8D9FB8DA}']
    function First: IIterator_1__IStoreQueueItem; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>
  IVectorView_1__IStoreQueueItem = interface(IInspectable)
  ['{C5D060F0-58CE-51DB-98C4-C9B6608CE6AB}']
    function GetAt(index: Cardinal): IStoreQueueItem; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IStoreQueueItem; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIStoreQueueItem): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StoreQueueItem>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem = interface(IUnknown)
  ['{776B0864-B93D-5669-A75D-70A29325E919}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IStoreQueueItem; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.StoreQueueItem>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Services.Store.IStoreQueueItem>>
  IAsyncOperation_1__IVectorView_1__IStoreQueueItem = interface(IInspectable)
  ['{1346377D-4D6F-5999-9A6E-9C8FBF6F38A2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem; safecall;
    function GetResults: IVectorView_1__IStoreQueueItem; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IStoreQueueItem read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStorePackageInstallOptions
  IStorePackageInstallOptions = interface(IInspectable)
  ['{1D3D630C-0CCD-44DD-8C59-80810A729973}']
    function get_AllowForcedAppRestart: Boolean; safecall;
    procedure put_AllowForcedAppRestart(value: Boolean); safecall;
    property AllowForcedAppRestart: Boolean read get_AllowForcedAppRestart write put_AllowForcedAppRestart;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreUninstallStorePackageResult
  IStoreUninstallStorePackageResult = interface(IInspectable)
  ['{9FCA39FD-126F-4CDA-B801-1346B8D0A260}']
    function get_ExtendedError: HRESULT; safecall;
    function get_Status: StoreUninstallStorePackageStatus; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property Status: StoreUninstallStorePackageStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreUninstallStorePackageResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreUninstallStorePackageResult>
  AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult = interface(IUnknown)
  ['{C4DE9FB6-1FD9-5229-8818-BA65751DB046}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreUninstallStorePackageResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreUninstallStorePackageResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreUninstallStorePackageResult>
  IAsyncOperation_1__IStoreUninstallStorePackageResult = interface(IInspectable)
  ['{55AA82FD-CE55-550A-95EC-0554B1915208}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult; safecall;
    function GetResults: IStoreUninstallStorePackageResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreUninstallStorePackageResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContext3
  IStoreContext3 = interface(IInspectable)
  ['{E26226CA-1A01-4730-85A6-ECC896E4AE38}']
    function get_CanSilentlyDownloadStorePackageUpdates: Boolean; safecall;
    function TrySilentDownloadStorePackageUpdatesAsync(storePackageUpdates: IIterable_1__IStorePackageUpdate): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function TrySilentDownloadAndInstallStorePackageUpdatesAsync(storePackageUpdates: IIterable_1__IStorePackageUpdate): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function CanAcquireStoreLicenseForOptionalPackageAsync(optionalPackage: IPackage): IAsyncOperation_1__IStoreCanAcquireLicenseResult; safecall;
    function CanAcquireStoreLicenseAsync(productStoreId: HSTRING): IAsyncOperation_1__IStoreCanAcquireLicenseResult; safecall;
    function GetStoreProductsAsync(productKinds: IIterable_1__HSTRING; storeIds: IIterable_1__HSTRING; storeProductOptions: IStoreProductOptions): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function GetAssociatedStoreQueueItemsAsync: IAsyncOperation_1__IVectorView_1__IStoreQueueItem; safecall;
    function GetStoreQueueItemsAsync(storeIds: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__IStoreQueueItem; safecall;
    function RequestDownloadAndInstallStorePackagesAsync(storeIds: IIterable_1__HSTRING; storePackageInstallOptions: IStorePackageInstallOptions): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function DownloadAndInstallStorePackagesAsync(storeIds: IIterable_1__HSTRING): IAsyncOperationWithProgress_2__IStorePackageUpdateResult__StorePackageUpdateStatus; safecall;
    function RequestUninstallStorePackageAsync(package: IPackage): IAsyncOperation_1__IStoreUninstallStorePackageResult; safecall;
    function RequestUninstallStorePackageByStoreIdAsync(storeId: HSTRING): IAsyncOperation_1__IStoreUninstallStorePackageResult; safecall;
    function UninstallStorePackageAsync(package: IPackage): IAsyncOperation_1__IStoreUninstallStorePackageResult; safecall;
    function UninstallStorePackageByStoreIdAsync(storeId: HSTRING): IAsyncOperation_1__IStoreUninstallStorePackageResult; safecall;
    property CanSilentlyDownloadStorePackageUpdates: Boolean read get_CanSilentlyDownloadStorePackageUpdates;
  end;

  // UsedAPI Interface
  // Windows.Services.Store.IStoreRateAndReviewResult
  IStoreRateAndReviewResult = interface(IInspectable)
  ['{9D209D56-A6B5-4121-9B61-EE6D0FBDBDBB}']
    function get_ExtendedError: HRESULT; safecall;
    function get_ExtendedJsonData: HSTRING; safecall;
    function get_WasUpdated: Boolean; safecall;
    function get_Status: StoreRateAndReviewStatus; safecall;
    property ExtendedError: HRESULT read get_ExtendedError;
    property ExtendedJsonData: HSTRING read get_ExtendedJsonData;
    property Status: StoreRateAndReviewStatus read get_Status;
    property WasUpdated: Boolean read get_WasUpdated;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.StoreRateAndReviewResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Services.Store.IStoreRateAndReviewResult>
  AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult = interface(IUnknown)
  ['{EE12D599-9DBD-5E46-A46F-0223B8492761}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IStoreRateAndReviewResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.StoreRateAndReviewResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Services.Store.IStoreRateAndReviewResult>
  IAsyncOperation_1__IStoreRateAndReviewResult = interface(IInspectable)
  ['{844673EC-3402-5A20-BECF-E92C3F9681EA}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult; safecall;
    function GetResults: IStoreRateAndReviewResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IStoreRateAndReviewResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContext4
  IStoreContext4 = interface(IInspectable)
  ['{AF9C6F69-BEA1-4BF4-8E74-AE03E206C6B0}']
    function RequestRateAndReviewAppAsync: IAsyncOperation_1__IStoreRateAndReviewResult; safecall;
    function SetInstallOrderForAssociatedStoreQueueItemsAsync(items: IIterable_1__IStoreQueueItem): IAsyncOperation_1__IVectorView_1__IStoreQueueItem; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContext5
  IStoreContext5 = interface(IInspectable)
  ['{6DE6C52B-C43A-5953-B39A-71643C57D96E}']
    function GetUserPurchaseHistoryAsync(productKinds: IIterable_1__HSTRING): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function GetAssociatedStoreProductsByInAppOfferTokenAsync(inAppOfferTokens: IIterable_1__HSTRING): IAsyncOperation_1__IStoreProductQueryResult; safecall;
    function RequestPurchaseByInAppOfferTokenAsync(inAppOfferToken: HSTRING): IAsyncOperation_1__IStorePurchaseResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Services.Store.IStoreContextStatics
  [WinRTClassNameAttribute(SWindows_Services_Store_StoreContext)]
  IStoreContextStatics = interface(IInspectable)
  ['{9C06EE5F-15C0-4E72-9330-D6191CEBD19C}']
    function GetDefault: IStoreContext; safecall;
    function GetForUser(user: IUser): IStoreContext; safecall;
  end;

  // Windows.Services.Store.StoreContext
  // Explicitly imported
  // Implements: Windows.Services.Store.IStoreContext
  // Implements: Windows.Services.Store.IStoreContext2
  // Implements: Windows.Services.Store.IStoreContext3
  // Implements: Windows.Services.Store.IStoreContext4
  // Implements: Windows.Services.Store.IStoreContext5
  // Statics: "Windows.Services.Store.IStoreContextStatics"
  TStoreContext = class(TWinRTGenericImportS<IStoreContextStatics>)
  public
    {$REGION 'IStoreContextStatics'}
    class function GetDefault: IStoreContext; static; inline;
    class function GetForUser(user: IUser): IStoreContext; static; inline;
    {$ENDREGION}
 end;

implementation

{ TStoreContext }

{$REGION 'Windows.Services.Store.IStoreContextStatics'}
class function TStoreContext.GetDefault: IStoreContext;
begin
  Result := Statics.GetDefault;
end;

class function TStoreContext.GetForUser(user: IUser): IStoreContext;
begin
  Result := Statics.GetForUser(user);
end;
{$ENDREGION}

end.
