{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Networking;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  DomainNameType = Winapi.CommonTypes.DomainNameType;
  PDomainNameType = Winapi.CommonTypes.PDomainNameType;
  HostNameSortOptions = Winapi.CommonTypes.HostNameSortOptions;
  PHostNameSortOptions = Winapi.CommonTypes.PHostNameSortOptions;
  HostNameType = Winapi.CommonTypes.HostNameType;
  PHostNameType = Winapi.CommonTypes.PHostNameType;
  IEndpointPair = Winapi.CommonTypes.IEndpointPair;
  PIEndpointPair = Winapi.CommonTypes.PIEndpointPair;
  IHostName = Winapi.CommonTypes.IHostName;
  PIHostName = Winapi.CommonTypes.PIHostName;
  IIterable_1__IEndpointPair = Winapi.CommonTypes.IIterable_1__IEndpointPair;
  IIterator_1__IEndpointPair = Winapi.CommonTypes.IIterator_1__IEndpointPair;
  IVectorView_1__IEndpointPair = Winapi.CommonTypes.IVectorView_1__IEndpointPair;
  PIVectorView_1__IEndpointPair = Winapi.CommonTypes.PIVectorView_1__IEndpointPair;
  IVectorView_1__IHostName = Winapi.CommonTypes.IVectorView_1__IHostName;
  PIVectorView_1__IHostName = Winapi.CommonTypes.PIVectorView_1__IHostName;

  // Forward declarations for interfaces

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface;
  PAsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = ^AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface;
  PAsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = ^AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface;
  PIAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = ^IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation;

  // Windows.Networking.BackgroundTransfer.IDownloadOperation
  BackgroundTransfer_IDownloadOperation = interface;
  PBackgroundTransfer_IDownloadOperation = ^BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation = interface;
  PAsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation = ^AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IAsyncOperation_1__BackgroundTransfer_IDownloadOperation = interface;
  PIAsyncOperation_1__BackgroundTransfer_IDownloadOperation = ^IAsyncOperation_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IIterator_1__BackgroundTransfer_IDownloadOperation = interface;
  PIIterator_1__BackgroundTransfer_IDownloadOperation = ^IIterator_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IIterable_1__BackgroundTransfer_IDownloadOperation = interface;
  PIIterable_1__BackgroundTransfer_IDownloadOperation = ^IIterable_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IVectorView_1__BackgroundTransfer_IDownloadOperation = interface;
  PIVectorView_1__BackgroundTransfer_IDownloadOperation = ^IVectorView_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>>
  AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = ^AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>>
  IAsyncOperation_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = interface;
  PIAsyncOperation_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = ^IAsyncOperation_1__IVectorView_1__BackgroundTransfer_IDownloadOperation;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IIterator_1__BackgroundTransfer_BackgroundTransferFileRange = interface;
  PIIterator_1__BackgroundTransfer_BackgroundTransferFileRange = ^IIterator_1__BackgroundTransfer_BackgroundTransferFileRange;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IIterable_1__BackgroundTransfer_BackgroundTransferFileRange = interface;
  PIIterable_1__BackgroundTransfer_BackgroundTransferFileRange = ^IIterable_1__BackgroundTransfer_BackgroundTransferFileRange;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IVectorView_1__BackgroundTransfer_BackgroundTransferFileRange = interface;
  PIVectorView_1__BackgroundTransfer_BackgroundTransferFileRange = ^IVectorView_1__BackgroundTransfer_BackgroundTransferFileRange;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IVector_1__BackgroundTransfer_BackgroundTransferFileRange = interface;
  PIVector_1__BackgroundTransfer_BackgroundTransferFileRange = ^IVector_1__BackgroundTransfer_BackgroundTransferFileRange;

  // Windows.Networking.BackgroundTransfer.IBackgroundTransferRangesDownloadedEventArgs
  BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = interface;
  PBackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = ^BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IBackgroundTransferRangesDownloadedEventArgs>
  TypedEventHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = interface;
  PTypedEventHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = ^TypedEventHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.IHostName>
  IIterator_1__IHostName = interface;
  PIIterator_1__IHostName = ^IIterator_1__IHostName;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.IHostName>
  IIterable_1__IHostName = interface;
  PIIterable_1__IHostName = ^IIterable_1__IHostName;

  // Windows.Networking.IEndpointPairFactory
  IEndpointPairFactory = interface;
  PIEndpointPairFactory = ^IEndpointPairFactory;

  // Windows.Networking.IHostNameFactory
  IHostNameFactory = interface;
  PIHostNameFactory = ^IHostNameFactory;

  // Windows.Networking.IHostNameStatics
  IHostNameStatics = interface;
  PIHostNameStatics = ^IHostNameStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair = ^AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>>
  IAsyncOperation_1__IVectorView_1__IEndpointPair = interface;
  PIAsyncOperation_1__IVectorView_1__IEndpointPair = ^IAsyncOperation_1__IVectorView_1__IEndpointPair;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.IHostName>
  IVector_1__IHostName = interface;
  PIVector_1__IHostName = ^IVector_1__IHostName;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveDeviceAddress,Object>
  TypedEventHandler_2__XboxLive_IXboxLiveDeviceAddress__IInspectable = interface;
  PTypedEventHandler_2__XboxLive_IXboxLiveDeviceAddress__IInspectable = ^TypedEventHandler_2__XboxLive_IXboxLiveDeviceAddress__IInspectable;

  // Windows.Networking.XboxLive.IXboxLiveDeviceAddress
  XboxLive_IXboxLiveDeviceAddress = interface;
  PXboxLive_IXboxLiveDeviceAddress = ^XboxLive_IXboxLiveDeviceAddress;

  // Windows.Networking.XboxLive.IXboxLiveDeviceAddressStatics
  XboxLive_IXboxLiveDeviceAddressStatics = interface;
  PXboxLive_IXboxLiveDeviceAddressStatics = ^XboxLive_IXboxLiveDeviceAddressStatics;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPairStateChangedEventArgs
  XboxLive_IXboxLiveEndpointPairStateChangedEventArgs = interface;
  PXboxLive_IXboxLiveEndpointPairStateChangedEventArgs = ^XboxLive_IXboxLiveEndpointPairStateChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveEndpointPair,Windows.Networking.XboxLive.IXboxLiveEndpointPairStateChangedEventArgs>
  TypedEventHandler_2__XboxLive_IXboxLiveEndpointPair__XboxLive_IXboxLiveEndpointPairStateChangedEventArgs = interface;
  PTypedEventHandler_2__XboxLive_IXboxLiveEndpointPair__XboxLive_IXboxLiveEndpointPairStateChangedEventArgs = ^TypedEventHandler_2__XboxLive_IXboxLiveEndpointPair__XboxLive_IXboxLiveEndpointPairStateChangedEventArgs;

  // Windows.Networking.XboxLive.IXboxLiveInboundEndpointPairCreatedEventArgs
  XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = interface;
  PXboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = ^XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate,Windows.Networking.XboxLive.IXboxLiveInboundEndpointPairCreatedEventArgs>
  TypedEventHandler_2__XboxLive_IXboxLiveEndpointPairTemplate__XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = interface;
  PTypedEventHandler_2__XboxLive_IXboxLiveEndpointPairTemplate__XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = ^TypedEventHandler_2__XboxLive_IXboxLiveEndpointPairTemplate__XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult
  XboxLive_IXboxLiveEndpointPairCreationResult = interface;
  PXboxLive_IXboxLiveEndpointPairCreationResult = ^XboxLive_IXboxLiveEndpointPairCreationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult>
  AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult = interface;
  PAsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult = ^AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult>
  IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult = interface;
  PIAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult = ^IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IIterator_1__XboxLive_IXboxLiveEndpointPair = interface;
  PIIterator_1__XboxLive_IXboxLiveEndpointPair = ^IIterator_1__XboxLive_IXboxLiveEndpointPair;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IIterable_1__XboxLive_IXboxLiveEndpointPair = interface;
  PIIterable_1__XboxLive_IXboxLiveEndpointPair = ^IIterable_1__XboxLive_IXboxLiveEndpointPair;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IVectorView_1__XboxLive_IXboxLiveEndpointPair = interface;
  PIVectorView_1__XboxLive_IXboxLiveEndpointPair = ^IVectorView_1__XboxLive_IXboxLiveEndpointPair;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate
  XboxLive_IXboxLiveEndpointPairTemplate = interface;
  PXboxLive_IXboxLiveEndpointPairTemplate = ^XboxLive_IXboxLiveEndpointPairTemplate;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPair
  XboxLive_IXboxLiveEndpointPair = interface;
  PXboxLive_IXboxLiveEndpointPair = ^XboxLive_IXboxLiveEndpointPair;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPairStatics
  XboxLive_IXboxLiveEndpointPairStatics = interface;
  PXboxLive_IXboxLiveEndpointPairStatics = ^XboxLive_IXboxLiveEndpointPairStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IIterator_1__XboxLive_IXboxLiveEndpointPairTemplate = interface;
  PIIterator_1__XboxLive_IXboxLiveEndpointPairTemplate = ^IIterator_1__XboxLive_IXboxLiveEndpointPairTemplate;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IIterable_1__XboxLive_IXboxLiveEndpointPairTemplate = interface;
  PIIterable_1__XboxLive_IXboxLiveEndpointPairTemplate = ^IIterable_1__XboxLive_IXboxLiveEndpointPairTemplate;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate = interface;
  PIVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate = ^IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate;

  // Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplateStatics
  XboxLive_IXboxLiveEndpointPairTemplateStatics = interface;
  PXboxLive_IXboxLiveEndpointPairTemplateStatics = ^XboxLive_IXboxLiveEndpointPairTemplateStatics;

  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult
  XboxLive_IXboxLiveQualityOfServiceMetricResult = interface;
  PXboxLive_IXboxLiveQualityOfServiceMetricResult = ^XboxLive_IXboxLiveQualityOfServiceMetricResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IIterator_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface;
  PIIterator_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = ^IIterator_1__XboxLive_IXboxLiveQualityOfServiceMetricResult;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IIterable_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface;
  PIIterable_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = ^IIterable_1__XboxLive_IXboxLiveQualityOfServiceMetricResult;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface;
  PIVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = ^IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult;

  // Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult
  XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface;
  PXboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = ^XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IIterator_1__XboxLive_XboxLiveQualityOfServiceMetric = interface;
  PIIterator_1__XboxLive_XboxLiveQualityOfServiceMetric = ^IIterator_1__XboxLive_XboxLiveQualityOfServiceMetric;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IIterable_1__XboxLive_XboxLiveQualityOfServiceMetric = interface;
  PIIterable_1__XboxLive_XboxLiveQualityOfServiceMetric = ^IIterable_1__XboxLive_XboxLiveQualityOfServiceMetric;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IVectorView_1__XboxLive_XboxLiveQualityOfServiceMetric = interface;
  PIVectorView_1__XboxLive_XboxLiveQualityOfServiceMetric = ^IVectorView_1__XboxLive_XboxLiveQualityOfServiceMetric;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IVector_1__XboxLive_XboxLiveQualityOfServiceMetric = interface;
  PIVector_1__XboxLive_XboxLiveQualityOfServiceMetric = ^IVector_1__XboxLive_XboxLiveQualityOfServiceMetric;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IIterator_1__XboxLive_IXboxLiveDeviceAddress = interface;
  PIIterator_1__XboxLive_IXboxLiveDeviceAddress = ^IIterator_1__XboxLive_IXboxLiveDeviceAddress;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IIterable_1__XboxLive_IXboxLiveDeviceAddress = interface;
  PIIterable_1__XboxLive_IXboxLiveDeviceAddress = ^IIterable_1__XboxLive_IXboxLiveDeviceAddress;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IVectorView_1__XboxLive_IXboxLiveDeviceAddress = interface;
  PIVectorView_1__XboxLive_IXboxLiveDeviceAddress = ^IVectorView_1__XboxLive_IXboxLiveDeviceAddress;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IVector_1__XboxLive_IXboxLiveDeviceAddress = interface;
  PIVector_1__XboxLive_IXboxLiveDeviceAddress = ^IVector_1__XboxLive_IXboxLiveDeviceAddress;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IIterator_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface;
  PIIterator_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = ^IIterator_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IIterable_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface;
  PIIterable_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = ^IIterable_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface;
  PIVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = ^IVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult;

  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurement
  XboxLive_IXboxLiveQualityOfServiceMeasurement = interface;
  PXboxLive_IXboxLiveQualityOfServiceMeasurement = ^XboxLive_IXboxLiveQualityOfServiceMeasurement;

  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurementStatics
  XboxLive_IXboxLiveQualityOfServiceMeasurementStatics = interface;
  PXboxLive_IXboxLiveQualityOfServiceMeasurementStatics = ^XboxLive_IXboxLiveQualityOfServiceMeasurementStatics;

  // Windows.Networking Enums

  // Windows.Networking.BackgroundTransfer.BackgroundTransferBehavior
  BackgroundTransfer_BackgroundTransferBehavior = (
    Parallel = 0,
    Serialized = 1
  );
  PBackgroundTransfer_BackgroundTransferBehavior = ^BackgroundTransfer_BackgroundTransferBehavior;

  // Windows.Networking.BackgroundTransfer.BackgroundTransferCostPolicy
  BackgroundTransfer_BackgroundTransferCostPolicy = (
    Default = 0,
    UnrestrictedOnly = 1,
    Always = 2
  );
  PBackgroundTransfer_BackgroundTransferCostPolicy = ^BackgroundTransfer_BackgroundTransferCostPolicy;

  // Windows.Networking.BackgroundTransfer.BackgroundTransferPriority
  BackgroundTransfer_BackgroundTransferPriority = (
    Default = 0,
    High = 1,
    Low = 2
  );
  PBackgroundTransfer_BackgroundTransferPriority = ^BackgroundTransfer_BackgroundTransferPriority;

  // Windows.Networking.BackgroundTransfer.BackgroundTransferStatus
  BackgroundTransfer_BackgroundTransferStatus = (
    Idle = 0,
    Running = 1,
    PausedByApplication = 2,
    PausedCostedNetwork = 3,
    PausedNoNetwork = 4,
    Completed = 5,
    Canceled = 6,
    Error = 7,
    PausedRecoverableWebErrorStatus = 8,
    PausedSystemPolicy = 32
  );
  PBackgroundTransfer_BackgroundTransferStatus = ^BackgroundTransfer_BackgroundTransferStatus;

  // Windows.Networking.ServiceDiscovery.Dnssd.DnssdRegistrationStatus
  ServiceDiscovery_Dnssd_DnssdRegistrationStatus = (
    Success = 0,
    InvalidServiceName = 1,
    ServerError = 2,
    SecurityError = 3
  );
  PServiceDiscovery_Dnssd_DnssdRegistrationStatus = ^ServiceDiscovery_Dnssd_DnssdRegistrationStatus;

  // Windows.Networking.ServiceDiscovery.Dnssd.DnssdServiceWatcherStatus
  ServiceDiscovery_Dnssd_DnssdServiceWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopping = 3,
    Stopped = 4,
    Aborted = 5
  );
  PServiceDiscovery_Dnssd_DnssdServiceWatcherStatus = ^ServiceDiscovery_Dnssd_DnssdServiceWatcherStatus;

  // Windows.Networking.XboxLive.XboxLiveEndpointPairCreationBehaviors
  XboxLive_XboxLiveEndpointPairCreationBehaviors = (
    None = 0,
    ReevaluatePath = 1
  );
  PXboxLive_XboxLiveEndpointPairCreationBehaviors = ^XboxLive_XboxLiveEndpointPairCreationBehaviors;

  // Windows.Networking.XboxLive.XboxLiveEndpointPairCreationStatus
  XboxLive_XboxLiveEndpointPairCreationStatus = (
    Succeeded = 0,
    NoLocalNetworks = 1,
    NoCompatibleNetworkPaths = 2,
    LocalSystemNotAuthorized = 3,
    Canceled = 4,
    TimedOut = 5,
    RemoteSystemNotAuthorized = 6,
    RefusedDueToConfiguration = 7,
    UnexpectedInternalError = 8
  );
  PXboxLive_XboxLiveEndpointPairCreationStatus = ^XboxLive_XboxLiveEndpointPairCreationStatus;

  // Windows.Networking.XboxLive.XboxLiveEndpointPairState
  XboxLive_XboxLiveEndpointPairState = (
    Invalid = 0,
    CreatingOutbound = 1,
    CreatingInbound = 2,
    Ready = 3,
    DeletingLocally = 4,
    RemoteEndpointTerminating = 5,
    Deleted = 6
  );
  PXboxLive_XboxLiveEndpointPairState = ^XboxLive_XboxLiveEndpointPairState;

  // Windows.Networking.XboxLive.XboxLiveNetworkAccessKind
  XboxLive_XboxLiveNetworkAccessKind = (
    Open = 0,
    Moderate = 1,
    Strict = 2
  );
  PXboxLive_XboxLiveNetworkAccessKind = ^XboxLive_XboxLiveNetworkAccessKind;

  // Windows.Networking.XboxLive.XboxLiveQualityOfServiceMeasurementStatus
  XboxLive_XboxLiveQualityOfServiceMeasurementStatus = (
    NotStarted = 0,
    InProgress = 1,
    InProgressWithProvisionalResults = 2,
    Succeeded = 3,
    NoLocalNetworks = 4,
    NoCompatibleNetworkPaths = 5,
    LocalSystemNotAuthorized = 6,
    Canceled = 7,
    TimedOut = 8,
    RemoteSystemNotAuthorized = 9,
    RefusedDueToConfiguration = 10,
    UnexpectedInternalError = 11
  );
  PXboxLive_XboxLiveQualityOfServiceMeasurementStatus = ^XboxLive_XboxLiveQualityOfServiceMeasurementStatus;

  // Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric
  XboxLive_XboxLiveQualityOfServiceMetric = (
    AverageLatencyInMilliseconds = 0,
    MinLatencyInMilliseconds = 1,
    MaxLatencyInMilliseconds = 2,
    AverageOutboundBitsPerSecond = 3,
    MinOutboundBitsPerSecond = 4,
    MaxOutboundBitsPerSecond = 5,
    AverageInboundBitsPerSecond = 6,
    MinInboundBitsPerSecond = 7,
    MaxInboundBitsPerSecond = 8
  );
  PXboxLive_XboxLiveQualityOfServiceMetric = ^XboxLive_XboxLiveQualityOfServiceMetric;

  // Windows.Networking.XboxLive.XboxLiveSocketKind
  XboxLive_XboxLiveSocketKind = (
    None = 0,
    Datagram = 1,
    Stream = 2
  );
  PXboxLive_XboxLiveSocketKind = ^XboxLive_XboxLiveSocketKind;

  // Windows.Networking Records

  // Windows.Networking.BackgroundTransfer.BackgroundDownloadProgress
  BackgroundTransfer_BackgroundDownloadProgress = record
    BytesReceived: UInt64;
    TotalBytesToReceive: UInt64;
    Status: BackgroundTransfer_BackgroundTransferStatus;
    HasResponseChanged: Boolean;
    HasRestarted: Boolean;
  end;
  PBackgroundTransfer_BackgroundDownloadProgress = ^BackgroundTransfer_BackgroundDownloadProgress;

  // Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange
  BackgroundTransfer_BackgroundTransferFileRange = record
    Offset: UInt64;
    Length: UInt64;
  end;
  PBackgroundTransfer_BackgroundTransferFileRange = ^BackgroundTransfer_BackgroundTransferFileRange;

  // Windows.Networking.BackgroundTransfer.BackgroundUploadProgress
  BackgroundTransfer_BackgroundUploadProgress = record
    BytesReceived: UInt64;
    BytesSent: UInt64;
    TotalBytesToReceive: UInt64;
    TotalBytesToSend: UInt64;
    Status: BackgroundTransfer_BackgroundTransferStatus;
    HasResponseChanged: Boolean;
    HasRestarted: Boolean;
  end;
  PBackgroundTransfer_BackgroundUploadProgress = ^BackgroundTransfer_BackgroundUploadProgress;

  // Windows.Networking.XboxLive.XboxLiveSecureSocketsContract
  XboxLive_XboxLiveSecureSocketsContract = record
  end;
  PXboxLive_XboxLiveSecureSocketsContract = ^XboxLive_XboxLiveSecureSocketsContract;

  // Windows.Networking Interfaces

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Networking.BackgroundTransfer.DownloadOperation,Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface(IUnknown)
  ['{B2FF13F1-C743-54F4-BCCC-F08E16A87890}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; progressInfo: BackgroundTransfer_IDownloadOperation); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Networking.BackgroundTransfer.DownloadOperation,Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface(IUnknown)
  ['{781B479C-0207-5D15-A4E5-7837D13BF93D}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Networking.BackgroundTransfer.DownloadOperation,Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{E86A4F5D-743A-5F18-9D4C-BC8ED5942659}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; safecall;
    function GetResults: BackgroundTransfer_IDownloadOperation; safecall;
    property Progress: AsyncOperationProgressHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.BackgroundTransfer.IDownloadOperation
  BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{BD87EBB0-5714-4E09-BA68-BEF73903B0D7}']
    function get_ResultFile: IStorageFile; safecall;
    function get_Progress: BackgroundTransfer_BackgroundDownloadProgress; safecall;
    function StartAsync: IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; safecall;
    function AttachAsync: IAsyncOperationWithProgress_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IDownloadOperation; safecall;
    procedure Pause; safecall;
    procedure Resume; safecall;
    property Progress: BackgroundTransfer_BackgroundDownloadProgress read get_Progress;
    property ResultFile: IStorageFile read get_ResultFile;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation = interface(IUnknown)
  ['{2AA63857-FFAF-5CF6-9B2C-0DC597B60A60}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__BackgroundTransfer_IDownloadOperation; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IAsyncOperation_1__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{43EF3A5F-CC7D-566D-A92A-4CAA76B92A1F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation; safecall;
    function GetResults: BackgroundTransfer_IDownloadOperation; safecall;
    property Completed: AsyncOperationCompletedHandler_1__BackgroundTransfer_IDownloadOperation read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IIterator_1__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{2AB61055-2D0A-59CB-8CBD-056F2D7FB454}']
    function get_Current: BackgroundTransfer_IDownloadOperation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PBackgroundTransfer_IDownloadOperation): Cardinal; safecall;
    property Current: BackgroundTransfer_IDownloadOperation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.BackgroundTransfer.DownloadOperation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IIterable_1__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{F6FD69CB-E6E7-56D5-9BE6-E0DC4683FA80}']
    function First: IIterator_1__BackgroundTransfer_IDownloadOperation; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>
  IVectorView_1__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{C5326734-B624-513B-A93C-70709AF0753A}']
    function GetAt(index: Cardinal): BackgroundTransfer_IDownloadOperation; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: BackgroundTransfer_IDownloadOperation; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PBackgroundTransfer_IDownloadOperation): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.DownloadOperation>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>>
  AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = interface(IUnknown)
  ['{1986B372-0DDB-520C-B72D-FB2577E99FF5}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__BackgroundTransfer_IDownloadOperation; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.DownloadOperation>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.IDownloadOperation>>
  IAsyncOperation_1__IVectorView_1__BackgroundTransfer_IDownloadOperation = interface(IInspectable)
  ['{AE42CDDF-3042-5D92-A01E-643C252B8050}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation; safecall;
    function GetResults: IVectorView_1__BackgroundTransfer_IDownloadOperation; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__BackgroundTransfer_IDownloadOperation read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IIterator_1__BackgroundTransfer_BackgroundTransferFileRange = interface(IInspectable)
  ['{A753D778-8CBB-524A-B8C4-70C515A42782}']
    function get_Current: BackgroundTransfer_BackgroundTransferFileRange; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PBackgroundTransfer_BackgroundTransferFileRange): Cardinal; safecall;
    property Current: BackgroundTransfer_BackgroundTransferFileRange read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IIterable_1__BackgroundTransfer_BackgroundTransferFileRange = interface(IInspectable)
  ['{2CC2D499-974C-5078-89AE-2D4EE1139721}']
    function First: IIterator_1__BackgroundTransfer_BackgroundTransferFileRange; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IVectorView_1__BackgroundTransfer_BackgroundTransferFileRange = interface(IInspectable)
  ['{5BE7934B-D9FC-540A-8FFE-5FB9C88C6558}']
    function GetAt(index: Cardinal): BackgroundTransfer_BackgroundTransferFileRange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: BackgroundTransfer_BackgroundTransferFileRange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PBackgroundTransfer_BackgroundTransferFileRange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.BackgroundTransfer.BackgroundTransferFileRange>
  IVector_1__BackgroundTransfer_BackgroundTransferFileRange = interface(IInspectable)
  ['{C73CEEF0-854A-5947-9E7C-527E3915D335}']
    function GetAt(index: Cardinal): BackgroundTransfer_BackgroundTransferFileRange; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__BackgroundTransfer_BackgroundTransferFileRange; safecall;
    function IndexOf(value: BackgroundTransfer_BackgroundTransferFileRange; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: BackgroundTransfer_BackgroundTransferFileRange); safecall;
    procedure InsertAt(index: Cardinal; value: BackgroundTransfer_BackgroundTransferFileRange); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: BackgroundTransfer_BackgroundTransferFileRange); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PBackgroundTransfer_BackgroundTransferFileRange): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PBackgroundTransfer_BackgroundTransferFileRange); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Networking.BackgroundTransfer.IBackgroundTransferRangesDownloadedEventArgs
  BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = interface(IInspectable)
  ['{3EBC7453-BF48-4A88-9248-B0C165184F5C}']
    function get_WasDownloadRestarted: Boolean; safecall;
    function get_AddedRanges: IVector_1__BackgroundTransfer_BackgroundTransferFileRange; safecall;
    function GetDeferral: IDeferral; safecall;
    property AddedRanges: IVector_1__BackgroundTransfer_BackgroundTransferFileRange read get_AddedRanges;
    property WasDownloadRestarted: Boolean read get_WasDownloadRestarted;
  end;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.BackgroundTransfer.DownloadOperation,Windows.Networking.BackgroundTransfer.BackgroundTransferRangesDownloadedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.BackgroundTransfer.IDownloadOperation,Windows.Networking.BackgroundTransfer.IBackgroundTransferRangesDownloadedEventArgs>
  TypedEventHandler_2__BackgroundTransfer_IDownloadOperation__BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs = interface(IUnknown)
  ['{93A20D85-BDFC-5195-90D9-8CB56CBCB3D8}']
    procedure Invoke(sender: BackgroundTransfer_IDownloadOperation; args: BackgroundTransfer_IBackgroundTransferRangesDownloadedEventArgs); safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.HostName>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.IHostName>
  IIterator_1__IHostName = interface(IInspectable)
  ['{557BF83C-A428-5DBD-A0FE-05F6EE543D45}']
    function get_Current: IHostName; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIHostName): Cardinal; safecall;
    property Current: IHostName read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.HostName>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.IHostName>
  IIterable_1__IHostName = interface(IInspectable)
  ['{9E5F3ED0-CF1C-5D38-832C-ACEA6164BF5C}']
    function First: IIterator_1__IHostName; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.IEndpointPairFactory
  [WinRTClassNameAttribute(SWindows_Networking_EndpointPair)]
  IEndpointPairFactory = interface(IInspectable)
  ['{B609D971-64E0-442B-AA6F-CC8C8F181F78}']
    function CreateEndpointPair(localHostName: IHostName; localServiceName: HSTRING; remoteHostName: IHostName; remoteServiceName: HSTRING): IEndpointPair; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.IHostNameFactory
  [WinRTClassNameAttribute(SWindows_Networking_HostName)]
  IHostNameFactory = interface(IInspectable)
  ['{458C23ED-712F-4576-ADF1-C20B2C643558}']
    function CreateHostName(hostName: HSTRING): IHostName; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.IHostNameStatics
  [WinRTClassNameAttribute(SWindows_Networking_HostName)]
  IHostNameStatics = interface(IInspectable)
  ['{F68CD4BF-A388-4E8B-91EA-54DD6DD901C0}']
    function Compare(value1: HSTRING; value2: HSTRING): Integer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.EndpointPair>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair = interface(IUnknown)
  ['{20D6FAAB-3B8E-5A1F-8397-B01CB219A18D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IEndpointPair; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.EndpointPair>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Networking.IEndpointPair>>
  IAsyncOperation_1__IVectorView_1__IEndpointPair = interface(IInspectable)
  ['{AFC2FF8E-E393-566A-89C4-D043E940050D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair; safecall;
    function GetResults: IVectorView_1__IEndpointPair; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IEndpointPair read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Networking.HostName>
  // Windows.Foundation.Collections.IVector`1<Windows.Networking.IHostName>
  IVector_1__IHostName = interface(IInspectable)
  ['{90C71C29-A9B5-5267-A5AD-8B756736317C}']
    function GetAt(index: Cardinal): IHostName; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IHostName; safecall;
    function IndexOf(value: IHostName; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IHostName); safecall;
    procedure InsertAt(index: Cardinal; value: IHostName); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IHostName); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIHostName): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIHostName); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.XboxLiveDeviceAddress,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveDeviceAddress,Object>
  TypedEventHandler_2__XboxLive_IXboxLiveDeviceAddress__IInspectable = interface(IUnknown)
  ['{7FA76199-D1B8-5494-A042-7002A416ADC3}']
    procedure Invoke(sender: XboxLive_IXboxLiveDeviceAddress; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveDeviceAddress
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveDeviceAddress)]
  XboxLive_IXboxLiveDeviceAddress = interface(IInspectable)
  ['{F5BBD279-3C86-4B57-A31A-B9462408FD01}']
    function add_SnapshotChanged(handler: TypedEventHandler_2__XboxLive_IXboxLiveDeviceAddress__IInspectable): EventRegistrationToken; safecall;
    procedure remove_SnapshotChanged(token: EventRegistrationToken); safecall;
    function GetSnapshotAsBase64: HSTRING; safecall;
    function GetSnapshotAsBuffer: IBuffer; safecall;
    procedure GetSnapshotAsBytes(bufferSize: Cardinal; buffer: PByte; out bytesWritten: Cardinal); safecall;
    function Compare(otherDeviceAddress: XboxLive_IXboxLiveDeviceAddress): Integer; safecall;
    function get_IsValid: Boolean; safecall;
    function get_IsLocal: Boolean; safecall;
    function get_NetworkAccessKind: XboxLive_XboxLiveNetworkAccessKind; safecall;
    property IsLocal: Boolean read get_IsLocal;
    property IsValid: Boolean read get_IsValid;
    property NetworkAccessKind: XboxLive_XboxLiveNetworkAccessKind read get_NetworkAccessKind;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveDeviceAddressStatics
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveDeviceAddress)]
  XboxLive_IXboxLiveDeviceAddressStatics = interface(IInspectable)
  ['{5954A819-4A79-4931-827C-7F503E963263}']
    function CreateFromSnapshotBase64(base64: HSTRING): XboxLive_IXboxLiveDeviceAddress; safecall;
    function CreateFromSnapshotBuffer(buffer: IBuffer): XboxLive_IXboxLiveDeviceAddress; safecall;
    function CreateFromSnapshotBytes(bufferSize: Cardinal; buffer: PByte): XboxLive_IXboxLiveDeviceAddress; safecall;
    function GetLocal: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_MaxSnapshotBytesSize: Cardinal; safecall;
    property MaxSnapshotBytesSize: Cardinal read get_MaxSnapshotBytesSize;
  end;

  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPairStateChangedEventArgs
  XboxLive_IXboxLiveEndpointPairStateChangedEventArgs = interface(IInspectable)
  ['{592E3B55-DE08-44E7-AC3B-B9B9A169583A}']
    function get_OldState: XboxLive_XboxLiveEndpointPairState; safecall;
    function get_NewState: XboxLive_XboxLiveEndpointPairState; safecall;
    property NewState: XboxLive_XboxLiveEndpointPairState read get_NewState;
    property OldState: XboxLive_XboxLiveEndpointPairState read get_OldState;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.XboxLiveEndpointPair,Windows.Networking.XboxLive.XboxLiveEndpointPairStateChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveEndpointPair,Windows.Networking.XboxLive.IXboxLiveEndpointPairStateChangedEventArgs>
  TypedEventHandler_2__XboxLive_IXboxLiveEndpointPair__XboxLive_IXboxLiveEndpointPairStateChangedEventArgs = interface(IUnknown)
  ['{51037260-4609-58C1-ADB3-0618B89B9975}']
    procedure Invoke(sender: XboxLive_IXboxLiveEndpointPair; args: XboxLive_IXboxLiveEndpointPairStateChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveInboundEndpointPairCreatedEventArgs
  XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = interface(IInspectable)
  ['{DC183B62-22BA-48D2-80DE-C23968BD198B}']
    function get_EndpointPair: XboxLive_IXboxLiveEndpointPair; safecall;
    property EndpointPair: XboxLive_IXboxLiveEndpointPair read get_EndpointPair;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.XboxLiveEndpointPairTemplate,Windows.Networking.XboxLive.XboxLiveInboundEndpointPairCreatedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate,Windows.Networking.XboxLive.IXboxLiveInboundEndpointPairCreatedEventArgs>
  TypedEventHandler_2__XboxLive_IXboxLiveEndpointPairTemplate__XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs = interface(IUnknown)
  ['{2AEF5136-6E7A-51F8-8853-CC0CE466FEF9}']
    procedure Invoke(sender: XboxLive_IXboxLiveEndpointPairTemplate; args: XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult
  XboxLive_IXboxLiveEndpointPairCreationResult = interface(IInspectable)
  ['{D9A8BB95-2AAB-4D1E-9794-33ECC0DCF0FE}']
    function get_DeviceAddress: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_Status: XboxLive_XboxLiveEndpointPairCreationStatus; safecall;
    function get_IsExistingPathEvaluation: Boolean; safecall;
    function get_EndpointPair: XboxLive_IXboxLiveEndpointPair; safecall;
    property DeviceAddress: XboxLive_IXboxLiveDeviceAddress read get_DeviceAddress;
    property EndpointPair: XboxLive_IXboxLiveEndpointPair read get_EndpointPair;
    property IsExistingPathEvaluation: Boolean read get_IsExistingPathEvaluation;
    property Status: XboxLive_XboxLiveEndpointPairCreationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.XboxLive.XboxLiveEndpointPairCreationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult>
  AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult = interface(IUnknown)
  ['{AD57FA1D-DB1B-5DF5-9694-F71B9BD5625B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.XboxLive.XboxLiveEndpointPairCreationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairCreationResult>
  IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult = interface(IInspectable)
  ['{A4B9D41E-4B2C-5BF9-A19D-ED395B23823C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult; safecall;
    function GetResults: XboxLive_IXboxLiveEndpointPairCreationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__XboxLive_IXboxLiveEndpointPairCreationResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveEndpointPair>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IIterator_1__XboxLive_IXboxLiveEndpointPair = interface(IInspectable)
  ['{E796A96B-98A0-52A2-BB54-9DBA5BB64FC4}']
    function get_Current: XboxLive_IXboxLiveEndpointPair; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_IXboxLiveEndpointPair): Cardinal; safecall;
    property Current: XboxLive_IXboxLiveEndpointPair read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveEndpointPair>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IIterable_1__XboxLive_IXboxLiveEndpointPair = interface(IInspectable)
  ['{7FCAF666-DDC0-50DC-A76F-9BB6058BE3C9}']
    function First: IIterator_1__XboxLive_IXboxLiveEndpointPair; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveEndpointPair>
  IVectorView_1__XboxLive_IXboxLiveEndpointPair = interface(IInspectable)
  ['{76EE6AB6-3DB4-5C04-9548-46CA05FA4E3A}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveEndpointPair; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_IXboxLiveEndpointPair; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveEndpointPair): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveEndpointPairTemplate)]
  XboxLive_IXboxLiveEndpointPairTemplate = interface(IInspectable)
  ['{6B286ECF-3457-40CE-B9A1-C0CFE0213EA7}']
    function add_InboundEndpointPairCreated(handler: TypedEventHandler_2__XboxLive_IXboxLiveEndpointPairTemplate__XboxLive_IXboxLiveInboundEndpointPairCreatedEventArgs): EventRegistrationToken; safecall;
    procedure remove_InboundEndpointPairCreated(token: EventRegistrationToken); safecall;
    function CreateEndpointPairAsync(deviceAddress: XboxLive_IXboxLiveDeviceAddress): IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult; overload; safecall;
    function CreateEndpointPairAsync(deviceAddress: XboxLive_IXboxLiveDeviceAddress; behaviors: XboxLive_XboxLiveEndpointPairCreationBehaviors): IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult; overload; safecall;
    function CreateEndpointPairForPortsAsync(deviceAddress: XboxLive_IXboxLiveDeviceAddress; initiatorPort: HSTRING; acceptorPort: HSTRING): IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult; overload; safecall;
    function CreateEndpointPairForPortsAsync(deviceAddress: XboxLive_IXboxLiveDeviceAddress; initiatorPort: HSTRING; acceptorPort: HSTRING; behaviors: XboxLive_XboxLiveEndpointPairCreationBehaviors): IAsyncOperation_1__XboxLive_IXboxLiveEndpointPairCreationResult; overload; safecall;
    function get_Name: HSTRING; safecall;
    function get_SocketKind: XboxLive_XboxLiveSocketKind; safecall;
    function get_InitiatorBoundPortRangeLower: Word; safecall;
    function get_InitiatorBoundPortRangeUpper: Word; safecall;
    function get_AcceptorBoundPortRangeLower: Word; safecall;
    function get_AcceptorBoundPortRangeUpper: Word; safecall;
    function get_EndpointPairs: IVectorView_1__XboxLive_IXboxLiveEndpointPair; safecall;
    property AcceptorBoundPortRangeLower: Word read get_AcceptorBoundPortRangeLower;
    property AcceptorBoundPortRangeUpper: Word read get_AcceptorBoundPortRangeUpper;
    property EndpointPairs: IVectorView_1__XboxLive_IXboxLiveEndpointPair read get_EndpointPairs;
    property InitiatorBoundPortRangeLower: Word read get_InitiatorBoundPortRangeLower;
    property InitiatorBoundPortRangeUpper: Word read get_InitiatorBoundPortRangeUpper;
    property Name: HSTRING read get_Name;
    property SocketKind: XboxLive_XboxLiveSocketKind read get_SocketKind;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPair
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveEndpointPair)]
  XboxLive_IXboxLiveEndpointPair = interface(IInspectable)
  ['{1E9A839B-813E-44E0-B87F-C87A093475E4}']
    function add_StateChanged(handler: TypedEventHandler_2__XboxLive_IXboxLiveEndpointPair__XboxLive_IXboxLiveEndpointPairStateChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StateChanged(token: EventRegistrationToken); safecall;
    function DeleteAsync: IAsyncAction; safecall;
    procedure GetRemoteSocketAddressBytes(socketAddressSize: Cardinal; socketAddress: PByte); safecall;
    procedure GetLocalSocketAddressBytes(socketAddressSize: Cardinal; socketAddress: PByte); safecall;
    function get_State: XboxLive_XboxLiveEndpointPairState; safecall;
    function get_Template: XboxLive_IXboxLiveEndpointPairTemplate; safecall;
    function get_RemoteDeviceAddress: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_RemoteHostName: IHostName; safecall;
    function get_RemotePort: HSTRING; safecall;
    function get_LocalHostName: IHostName; safecall;
    function get_LocalPort: HSTRING; safecall;
    property LocalHostName: IHostName read get_LocalHostName;
    property LocalPort: HSTRING read get_LocalPort;
    property RemoteDeviceAddress: XboxLive_IXboxLiveDeviceAddress read get_RemoteDeviceAddress;
    property RemoteHostName: IHostName read get_RemoteHostName;
    property RemotePort: HSTRING read get_RemotePort;
    property State: XboxLive_XboxLiveEndpointPairState read get_State;
    property Template: XboxLive_IXboxLiveEndpointPairTemplate read get_Template;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPairStatics
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveEndpointPair)]
  XboxLive_IXboxLiveEndpointPairStatics = interface(IInspectable)
  ['{64316B30-217A-4243-8EE1-6729281D27DB}']
    function FindEndpointPairBySocketAddressBytes(localSocketAddressSize: Cardinal; localSocketAddress: PByte; remoteSocketAddressSize: Cardinal; remoteSocketAddress: PByte): XboxLive_IXboxLiveEndpointPair; safecall;
    function FindEndpointPairByHostNamesAndPorts(localHostName: IHostName; localPort: HSTRING; remoteHostName: IHostName; remotePort: HSTRING): XboxLive_IXboxLiveEndpointPair; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveEndpointPairTemplate>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IIterator_1__XboxLive_IXboxLiveEndpointPairTemplate = interface(IInspectable)
  ['{515331C6-39E1-5CC7-8454-7F1C8BCBA18E}']
    function get_Current: XboxLive_IXboxLiveEndpointPairTemplate; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_IXboxLiveEndpointPairTemplate): Cardinal; safecall;
    property Current: XboxLive_IXboxLiveEndpointPairTemplate read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveEndpointPairTemplate>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IIterable_1__XboxLive_IXboxLiveEndpointPairTemplate = interface(IInspectable)
  ['{9FCE55C3-5580-581A-85B5-88DD5E9D4FF7}']
    function First: IIterator_1__XboxLive_IXboxLiveEndpointPairTemplate; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate>
  IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate = interface(IInspectable)
  ['{E83B97D1-36E3-5AD7-9919-7D25D4A44E7A}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveEndpointPairTemplate; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_IXboxLiveEndpointPairTemplate; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveEndpointPairTemplate): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplateStatics
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveEndpointPairTemplate)]
  XboxLive_IXboxLiveEndpointPairTemplateStatics = interface(IInspectable)
  ['{1E13137B-737B-4A23-BC64-0870F75655BA}']
    function GetTemplateByName(name: HSTRING): XboxLive_IXboxLiveEndpointPairTemplate; safecall;
    function get_Templates: IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate; safecall;
    property Templates: IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate read get_Templates;
  end;

  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult
  XboxLive_IXboxLiveQualityOfServiceMetricResult = interface(IInspectable)
  ['{AEEC53D1-3561-4782-B0CF-D3AE29D9FA87}']
    function get_Status: XboxLive_XboxLiveQualityOfServiceMeasurementStatus; safecall;
    function get_DeviceAddress: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_Metric: XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function get_Value: UInt64; safecall;
    property DeviceAddress: XboxLive_IXboxLiveDeviceAddress read get_DeviceAddress;
    property Metric: XboxLive_XboxLiveQualityOfServiceMetric read get_Metric;
    property Status: XboxLive_XboxLiveQualityOfServiceMeasurementStatus read get_Status;
    property Value: UInt64 read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetricResult>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IIterator_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface(IInspectable)
  ['{E0696826-0069-57D6-9AD8-D0B368629E2E}']
    function get_Current: XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_IXboxLiveQualityOfServiceMetricResult): Cardinal; safecall;
    property Current: XboxLive_IXboxLiveQualityOfServiceMetricResult read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetricResult>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IIterable_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface(IInspectable)
  ['{65CC99EC-9779-568A-8982-AEE439FA24CE}']
    function First: IIterator_1__XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMetricResult>
  IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult = interface(IInspectable)
  ['{2280991F-95D7-5E86-80F1-AD73F0B8D66D}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_IXboxLiveQualityOfServiceMetricResult; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveQualityOfServiceMetricResult): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult
  XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface(IInspectable)
  ['{5A6302AE-6F38-41C0-9FCC-EA6CB978CAFC}']
    function get_Status: XboxLive_XboxLiveQualityOfServiceMeasurementStatus; safecall;
    function get_DeviceAddress: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_Value: IBuffer; safecall;
    property DeviceAddress: XboxLive_IXboxLiveDeviceAddress read get_DeviceAddress;
    property Status: XboxLive_XboxLiveQualityOfServiceMeasurementStatus read get_Status;
    property Value: IBuffer read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IIterator_1__XboxLive_XboxLiveQualityOfServiceMetric = interface(IInspectable)
  ['{B281EF1A-56BC-5DAA-BBE2-65E617B49925}']
    function get_Current: XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_XboxLiveQualityOfServiceMetric): Cardinal; safecall;
    property Current: XboxLive_XboxLiveQualityOfServiceMetric read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IIterable_1__XboxLive_XboxLiveQualityOfServiceMetric = interface(IInspectable)
  ['{E202EEF6-93BD-5FA2-91FC-7CA6A4EDC38A}']
    function First: IIterator_1__XboxLive_XboxLiveQualityOfServiceMetric; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IVectorView_1__XboxLive_XboxLiveQualityOfServiceMetric = interface(IInspectable)
  ['{05B168DF-9678-509D-9057-A79FD84B54BF}']
    function GetAt(index: Cardinal): XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_XboxLiveQualityOfServiceMetric; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_XboxLiveQualityOfServiceMetric): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Networking.XboxLive.XboxLiveQualityOfServiceMetric>
  IVector_1__XboxLive_XboxLiveQualityOfServiceMetric = interface(IInspectable)
  ['{8F3109D5-DC6B-58D1-9F70-60CC47BF1CED}']
    function GetAt(index: Cardinal): XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function IndexOf(value: XboxLive_XboxLiveQualityOfServiceMetric; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: XboxLive_XboxLiveQualityOfServiceMetric); safecall;
    procedure InsertAt(index: Cardinal; value: XboxLive_XboxLiveQualityOfServiceMetric); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: XboxLive_XboxLiveQualityOfServiceMetric); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_XboxLiveQualityOfServiceMetric): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PXboxLive_XboxLiveQualityOfServiceMetric); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveDeviceAddress>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IIterator_1__XboxLive_IXboxLiveDeviceAddress = interface(IInspectable)
  ['{85FB7103-EF5E-5746-9341-1DFBB21D720D}']
    function get_Current: XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_IXboxLiveDeviceAddress): Cardinal; safecall;
    property Current: XboxLive_IXboxLiveDeviceAddress read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveDeviceAddress>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IIterable_1__XboxLive_IXboxLiveDeviceAddress = interface(IInspectable)
  ['{44DF817C-B475-5FDB-862A-4A96ED1DAD5C}']
    function First: IIterator_1__XboxLive_IXboxLiveDeviceAddress; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IVectorView_1__XboxLive_IXboxLiveDeviceAddress = interface(IInspectable)
  ['{B231854B-6A72-57A1-AB6A-5ABDBEE96096}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_IXboxLiveDeviceAddress; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveDeviceAddress): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Networking.XboxLive.XboxLiveDeviceAddress>
  // Windows.Foundation.Collections.IVector`1<Windows.Networking.XboxLive.IXboxLiveDeviceAddress>
  IVector_1__XboxLive_IXboxLiveDeviceAddress = interface(IInspectable)
  ['{8AACB2DA-C37E-5BE0-AB46-BA445910B9CB}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__XboxLive_IXboxLiveDeviceAddress; safecall;
    function IndexOf(value: XboxLive_IXboxLiveDeviceAddress; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: XboxLive_IXboxLiveDeviceAddress); safecall;
    procedure InsertAt(index: Cardinal; value: XboxLive_IXboxLiveDeviceAddress); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: XboxLive_IXboxLiveDeviceAddress); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveDeviceAddress): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PXboxLive_IXboxLiveDeviceAddress); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.XboxLiveQualityOfServicePrivatePayloadResult>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IIterator_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface(IInspectable)
  ['{EB5BFDF4-7897-5CBF-AAA5-3582FAFB4D78}']
    function get_Current: XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PXboxLive_IXboxLiveQualityOfServicePrivatePayloadResult): Cardinal; safecall;
    property Current: XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.XboxLiveQualityOfServicePrivatePayloadResult>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IIterable_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface(IInspectable)
  ['{3A061DD4-03DD-52FB-9A83-067DE27C2BB1}']
    function First: IIterator_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.XboxLive.IXboxLiveQualityOfServicePrivatePayloadResult>
  IVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult = interface(IInspectable)
  ['{45013733-5353-518D-8658-21A4961795A4}']
    function GetAt(index: Cardinal): XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PXboxLive_IXboxLiveQualityOfServicePrivatePayloadResult): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurement
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveQualityOfServiceMeasurement)]
  XboxLive_IXboxLiveQualityOfServiceMeasurement = interface(IInspectable)
  ['{4D682BCE-A5D6-47E6-A236-CFDE5FBDF2ED}']
    function MeasureAsync: IAsyncAction; safecall;
    function GetMetricResultsForDevice(deviceAddress: XboxLive_IXboxLiveDeviceAddress): IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function GetMetricResultsForMetric(metric: XboxLive_XboxLiveQualityOfServiceMetric): IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function GetMetricResult(deviceAddress: XboxLive_IXboxLiveDeviceAddress; metric: XboxLive_XboxLiveQualityOfServiceMetric): XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function GetPrivatePayloadResult(deviceAddress: XboxLive_IXboxLiveDeviceAddress): XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; safecall;
    function get_Metrics: IVector_1__XboxLive_XboxLiveQualityOfServiceMetric; safecall;
    function get_DeviceAddresses: IVector_1__XboxLive_IXboxLiveDeviceAddress; safecall;
    function get_ShouldRequestPrivatePayloads: Boolean; safecall;
    procedure put_ShouldRequestPrivatePayloads(value: Boolean); safecall;
    function get_TimeoutInMilliseconds: Cardinal; safecall;
    procedure put_TimeoutInMilliseconds(value: Cardinal); safecall;
    function get_NumberOfProbesToAttempt: Cardinal; safecall;
    procedure put_NumberOfProbesToAttempt(value: Cardinal); safecall;
    function get_NumberOfResultsPending: Cardinal; safecall;
    function get_MetricResults: IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult; safecall;
    function get_PrivatePayloadResults: IVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult; safecall;
    property DeviceAddresses: IVector_1__XboxLive_IXboxLiveDeviceAddress read get_DeviceAddresses;
    property MetricResults: IVectorView_1__XboxLive_IXboxLiveQualityOfServiceMetricResult read get_MetricResults;
    property Metrics: IVector_1__XboxLive_XboxLiveQualityOfServiceMetric read get_Metrics;
    property NumberOfProbesToAttempt: Cardinal read get_NumberOfProbesToAttempt write put_NumberOfProbesToAttempt;
    property NumberOfResultsPending: Cardinal read get_NumberOfResultsPending;
    property PrivatePayloadResults: IVectorView_1__XboxLive_IXboxLiveQualityOfServicePrivatePayloadResult read get_PrivatePayloadResults;
    property ShouldRequestPrivatePayloads: Boolean read get_ShouldRequestPrivatePayloads write put_ShouldRequestPrivatePayloads;
    property TimeoutInMilliseconds: Cardinal read get_TimeoutInMilliseconds write put_TimeoutInMilliseconds;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurementStatics
  [WinRTClassNameAttribute(SWindows_Networking_XboxLive_XboxLiveQualityOfServiceMeasurement)]
  XboxLive_IXboxLiveQualityOfServiceMeasurementStatics = interface(IInspectable)
  ['{6E352DCA-23CF-440A-B077-5E30857A8234}']
    procedure PublishPrivatePayloadBytes(payloadSize: Cardinal; payload: PByte); safecall;
    procedure ClearPrivatePayload; safecall;
    function get_MaxSimultaneousProbeConnections: Cardinal; safecall;
    procedure put_MaxSimultaneousProbeConnections(value: Cardinal); safecall;
    function get_IsSystemOutboundBandwidthConstrained: Boolean; safecall;
    procedure put_IsSystemOutboundBandwidthConstrained(value: Boolean); safecall;
    function get_IsSystemInboundBandwidthConstrained: Boolean; safecall;
    procedure put_IsSystemInboundBandwidthConstrained(value: Boolean); safecall;
    function get_PublishedPrivatePayload: IBuffer; safecall;
    procedure put_PublishedPrivatePayload(value: IBuffer); safecall;
    function get_MaxPrivatePayloadSize: Cardinal; safecall;
    property IsSystemInboundBandwidthConstrained: Boolean read get_IsSystemInboundBandwidthConstrained write put_IsSystemInboundBandwidthConstrained;
    property IsSystemOutboundBandwidthConstrained: Boolean read get_IsSystemOutboundBandwidthConstrained write put_IsSystemOutboundBandwidthConstrained;
    property MaxPrivatePayloadSize: Cardinal read get_MaxPrivatePayloadSize;
    property MaxSimultaneousProbeConnections: Cardinal read get_MaxSimultaneousProbeConnections write put_MaxSimultaneousProbeConnections;
    property PublishedPrivatePayload: IBuffer read get_PublishedPrivatePayload write put_PublishedPrivatePayload;
  end;

  // Windows.Networking.EndpointPair
  // DualAPI
  // Implements: Windows.Networking.IEndpointPair
  // Factory: "Windows.Networking.IEndpointPairFactory"
  TEndpointPair = class(TWinRTGenericImportF<IEndpointPairFactory>)
  public
    {$REGION 'IEndpointPairFactory'}
    class function CreateEndpointPair(localHostName: IHostName; localServiceName: HSTRING; remoteHostName: IHostName; remoteServiceName: HSTRING): IEndpointPair; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.HostName
  // DualAPI
  // Implements: Windows.Networking.IHostName
  // Implements: Windows.Foundation.IStringable
  // Statics: "Windows.Networking.IHostNameStatics"
  // Factory: "Windows.Networking.IHostNameFactory"
  THostName = class(TWinRTGenericImportFS<IHostNameFactory, IHostNameStatics>)
  public
    {$REGION 'IHostNameStatics'}
    class function Compare(value1: HSTRING; value2: HSTRING): Integer; static; inline;
    {$ENDREGION}
    {$REGION 'IHostNameFactory'}
    class function CreateHostName(hostName: HSTRING): IHostName; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.XboxLive.XboxLiveDeviceAddress
  // DualAPI
  // Implements: Windows.Networking.XboxLive.IXboxLiveDeviceAddress
  // Statics: "Windows.Networking.XboxLive.IXboxLiveDeviceAddressStatics"
  TXboxLive_XboxLiveDeviceAddress = class(TWinRTGenericImportS<XboxLive_IXboxLiveDeviceAddressStatics>)
  public
    {$REGION 'XboxLive_IXboxLiveDeviceAddressStatics'}
    class function CreateFromSnapshotBase64(base64: HSTRING): XboxLive_IXboxLiveDeviceAddress; static; inline;
    class function CreateFromSnapshotBuffer(buffer: IBuffer): XboxLive_IXboxLiveDeviceAddress; static; inline;
    class function CreateFromSnapshotBytes(bufferSize: Cardinal; buffer: PByte): XboxLive_IXboxLiveDeviceAddress; static; inline;
    class function GetLocal: XboxLive_IXboxLiveDeviceAddress; static; inline;
    class function get_MaxSnapshotBytesSize: Cardinal; static; inline;
    class property MaxSnapshotBytesSize: Cardinal read get_MaxSnapshotBytesSize;
    {$ENDREGION}
 end;

  // Windows.Networking.XboxLive.XboxLiveEndpointPair
  // DualAPI
  // Implements: Windows.Networking.XboxLive.IXboxLiveEndpointPair
  // Statics: "Windows.Networking.XboxLive.IXboxLiveEndpointPairStatics"
  TXboxLive_XboxLiveEndpointPair = class(TWinRTGenericImportS<XboxLive_IXboxLiveEndpointPairStatics>)
  public
    {$REGION 'XboxLive_IXboxLiveEndpointPairStatics'}
    class function FindEndpointPairBySocketAddressBytes(localSocketAddressSize: Cardinal; localSocketAddress: PByte; remoteSocketAddressSize: Cardinal; remoteSocketAddress: PByte): XboxLive_IXboxLiveEndpointPair; static; inline;
    class function FindEndpointPairByHostNamesAndPorts(localHostName: IHostName; localPort: HSTRING; remoteHostName: IHostName; remotePort: HSTRING): XboxLive_IXboxLiveEndpointPair; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.XboxLive.XboxLiveEndpointPairTemplate
  // DualAPI
  // Implements: Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplate
  // Statics: "Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplateStatics"
  TXboxLive_XboxLiveEndpointPairTemplate = class(TWinRTGenericImportS<XboxLive_IXboxLiveEndpointPairTemplateStatics>)
  public
    {$REGION 'XboxLive_IXboxLiveEndpointPairTemplateStatics'}
    class function GetTemplateByName(name: HSTRING): XboxLive_IXboxLiveEndpointPairTemplate; static; inline;
    class function get_Templates: IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate; static; inline;
    class property Templates: IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate read get_Templates;
    {$ENDREGION}
 end;

  // Windows.Networking.XboxLive.XboxLiveQualityOfServiceMeasurement
  // DualAPI
  // Implements: Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurement
  // Statics: "Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurementStatics"
  // Instantiable: "XboxLive_IXboxLiveQualityOfServiceMeasurement"
  TXboxLive_XboxLiveQualityOfServiceMeasurement = class(TWinRTGenericImportSI<XboxLive_IXboxLiveQualityOfServiceMeasurementStatics, XboxLive_IXboxLiveQualityOfServiceMeasurement>)
  public
    {$REGION 'XboxLive_IXboxLiveQualityOfServiceMeasurementStatics'}
    class procedure PublishPrivatePayloadBytes(payloadSize: Cardinal; payload: PByte); static; inline;
    class procedure ClearPrivatePayload; static; inline;
    class function get_MaxSimultaneousProbeConnections: Cardinal; static; inline;
    class procedure put_MaxSimultaneousProbeConnections(value: Cardinal); static; inline;
    class function get_IsSystemOutboundBandwidthConstrained: Boolean; static; inline;
    class procedure put_IsSystemOutboundBandwidthConstrained(value: Boolean); static; inline;
    class function get_IsSystemInboundBandwidthConstrained: Boolean; static; inline;
    class procedure put_IsSystemInboundBandwidthConstrained(value: Boolean); static; inline;
    class function get_PublishedPrivatePayload: IBuffer; static; inline;
    class procedure put_PublishedPrivatePayload(value: IBuffer); static; inline;
    class function get_MaxPrivatePayloadSize: Cardinal; static; inline;
    class property IsSystemInboundBandwidthConstrained: Boolean read get_IsSystemInboundBandwidthConstrained write put_IsSystemInboundBandwidthConstrained;
    class property IsSystemOutboundBandwidthConstrained: Boolean read get_IsSystemOutboundBandwidthConstrained write put_IsSystemOutboundBandwidthConstrained;
    class property MaxPrivatePayloadSize: Cardinal read get_MaxPrivatePayloadSize;
    class property MaxSimultaneousProbeConnections: Cardinal read get_MaxSimultaneousProbeConnections write put_MaxSimultaneousProbeConnections;
    class property PublishedPrivatePayload: IBuffer read get_PublishedPrivatePayload write put_PublishedPrivatePayload;
    {$ENDREGION}
 end;

implementation

{ TEndpointPair }

{$REGION 'Windows.Networking.IEndpointPairFactory'}
// Factory: "Windows.Networking.IEndpointPairFactory"
// -> IEndpointPairFactory

class function TEndpointPair.CreateEndpointPair(localHostName: IHostName; localServiceName: HSTRING; remoteHostName: IHostName; remoteServiceName: HSTRING): IEndpointPair;
begin
  Result := Factory.CreateEndpointPair(localHostName, localServiceName, remoteHostName, remoteServiceName);
end;
{$ENDREGION}

{ THostName }

{$REGION 'Windows.Networking.IHostNameStatics'}
class function THostName.Compare(value1: HSTRING; value2: HSTRING): Integer;
begin
  Result := Statics.Compare(value1, value2);
end;
{$ENDREGION}

{$REGION 'Windows.Networking.IHostNameFactory'}
// Factory: "Windows.Networking.IHostNameFactory"
// -> IHostNameFactory

class function THostName.CreateHostName(hostName: HSTRING): IHostName;
begin
  Result := Factory.CreateHostName(hostName);
end;
{$ENDREGION}

{ TXboxLive_XboxLiveDeviceAddress }

{$REGION 'Windows.Networking.XboxLive.IXboxLiveDeviceAddressStatics'}
class function TXboxLive_XboxLiveDeviceAddress.CreateFromSnapshotBase64(base64: HSTRING): XboxLive_IXboxLiveDeviceAddress;
begin
  Result := Statics.CreateFromSnapshotBase64(base64);
end;

class function TXboxLive_XboxLiveDeviceAddress.CreateFromSnapshotBuffer(buffer: IBuffer): XboxLive_IXboxLiveDeviceAddress;
begin
  Result := Statics.CreateFromSnapshotBuffer(buffer);
end;

class function TXboxLive_XboxLiveDeviceAddress.CreateFromSnapshotBytes(bufferSize: Cardinal; buffer: PByte): XboxLive_IXboxLiveDeviceAddress;
begin
  Result := Statics.CreateFromSnapshotBytes(bufferSize, buffer);
end;

class function TXboxLive_XboxLiveDeviceAddress.GetLocal: XboxLive_IXboxLiveDeviceAddress;
begin
  Result := Statics.GetLocal;
end;

class function TXboxLive_XboxLiveDeviceAddress.get_MaxSnapshotBytesSize: Cardinal;
begin
  Result := Statics.get_MaxSnapshotBytesSize;
end;
{$ENDREGION}

{ TXboxLive_XboxLiveEndpointPair }

{$REGION 'Windows.Networking.XboxLive.IXboxLiveEndpointPairStatics'}
class function TXboxLive_XboxLiveEndpointPair.FindEndpointPairBySocketAddressBytes(localSocketAddressSize: Cardinal; localSocketAddress: PByte; remoteSocketAddressSize: Cardinal; remoteSocketAddress: PByte): XboxLive_IXboxLiveEndpointPair;
begin
  Result := Statics.FindEndpointPairBySocketAddressBytes(localSocketAddressSize, localSocketAddress, remoteSocketAddressSize, remoteSocketAddress);
end;

class function TXboxLive_XboxLiveEndpointPair.FindEndpointPairByHostNamesAndPorts(localHostName: IHostName; localPort: HSTRING; remoteHostName: IHostName; remotePort: HSTRING): XboxLive_IXboxLiveEndpointPair;
begin
  Result := Statics.FindEndpointPairByHostNamesAndPorts(localHostName, localPort, remoteHostName, remotePort);
end;
{$ENDREGION}

{ TXboxLive_XboxLiveEndpointPairTemplate }

{$REGION 'Windows.Networking.XboxLive.IXboxLiveEndpointPairTemplateStatics'}
class function TXboxLive_XboxLiveEndpointPairTemplate.GetTemplateByName(name: HSTRING): XboxLive_IXboxLiveEndpointPairTemplate;
begin
  Result := Statics.GetTemplateByName(name);
end;

class function TXboxLive_XboxLiveEndpointPairTemplate.get_Templates: IVectorView_1__XboxLive_IXboxLiveEndpointPairTemplate;
begin
  Result := Statics.get_Templates;
end;
{$ENDREGION}

{ TXboxLive_XboxLiveQualityOfServiceMeasurement }

{$REGION 'Windows.Networking.XboxLive.IXboxLiveQualityOfServiceMeasurementStatics'}
class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.PublishPrivatePayloadBytes(payloadSize: Cardinal; payload: PByte);
begin
  Statics.PublishPrivatePayloadBytes(payloadSize, payload);
end;

class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.ClearPrivatePayload;
begin
  Statics.ClearPrivatePayload;
end;

class function TXboxLive_XboxLiveQualityOfServiceMeasurement.get_MaxSimultaneousProbeConnections: Cardinal;
begin
  Result := Statics.get_MaxSimultaneousProbeConnections;
end;

class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.put_MaxSimultaneousProbeConnections(value: Cardinal);
begin
  Statics.put_MaxSimultaneousProbeConnections(value);
end;

class function TXboxLive_XboxLiveQualityOfServiceMeasurement.get_IsSystemOutboundBandwidthConstrained: Boolean;
begin
  Result := Statics.get_IsSystemOutboundBandwidthConstrained;
end;

class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.put_IsSystemOutboundBandwidthConstrained(value: Boolean);
begin
  Statics.put_IsSystemOutboundBandwidthConstrained(value);
end;

class function TXboxLive_XboxLiveQualityOfServiceMeasurement.get_IsSystemInboundBandwidthConstrained: Boolean;
begin
  Result := Statics.get_IsSystemInboundBandwidthConstrained;
end;

class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.put_IsSystemInboundBandwidthConstrained(value: Boolean);
begin
  Statics.put_IsSystemInboundBandwidthConstrained(value);
end;

class function TXboxLive_XboxLiveQualityOfServiceMeasurement.get_PublishedPrivatePayload: IBuffer;
begin
  Result := Statics.get_PublishedPrivatePayload;
end;

class procedure TXboxLive_XboxLiveQualityOfServiceMeasurement.put_PublishedPrivatePayload(value: IBuffer);
begin
  Statics.put_PublishedPrivatePayload(value);
end;

class function TXboxLive_XboxLiveQualityOfServiceMeasurement.get_MaxPrivatePayloadSize: Cardinal;
begin
  Result := Statics.get_MaxPrivatePayloadSize;
end;
{$ENDREGION}

end.
