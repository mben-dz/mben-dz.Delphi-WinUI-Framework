{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Devices.Sensors;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.GraphicsRT,
  Winapi.Foundation,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ActivityType>
  IIterator_1__ActivityType = interface;
  PIIterator_1__ActivityType = ^IIterator_1__ActivityType;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ActivityType>
  IIterable_1__ActivityType = interface;
  PIIterable_1__ActivityType = ^IIterable_1__ActivityType;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.ActivityType>
  IVectorView_1__ActivityType = interface;
  PIVectorView_1__ActivityType = ^IVectorView_1__ActivityType;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Sensors.ActivityType>
  IVector_1__ActivityType = interface;
  PIVector_1__ActivityType = ^IVector_1__ActivityType;

  // Windows.Devices.Sensors.Custom.ICustomSensorReading
  Custom_ICustomSensorReading = interface;
  PCustom_ICustomSensorReading = ^Custom_ICustomSensorReading;

  // Windows.Devices.Sensors.Custom.ICustomSensorReadingChangedEventArgs
  Custom_ICustomSensorReadingChangedEventArgs = interface;
  PCustom_ICustomSensorReadingChangedEventArgs = ^Custom_ICustomSensorReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Custom.ICustomSensor,Windows.Devices.Sensors.Custom.ICustomSensorReadingChangedEventArgs>
  TypedEventHandler_2__Custom_ICustomSensor__Custom_ICustomSensorReadingChangedEventArgs = interface;
  PTypedEventHandler_2__Custom_ICustomSensor__Custom_ICustomSensorReadingChangedEventArgs = ^TypedEventHandler_2__Custom_ICustomSensor__Custom_ICustomSensorReadingChangedEventArgs;

  // Windows.Devices.Sensors.Custom.ICustomSensor
  Custom_ICustomSensor = interface;
  PCustom_ICustomSensor = ^Custom_ICustomSensor;

  // Windows.Devices.Sensors.Custom.ICustomSensor2
  Custom_ICustomSensor2 = interface;
  PCustom_ICustomSensor2 = ^Custom_ICustomSensor2;

  // Windows.Devices.Sensors.Custom.ICustomSensorReading2
  Custom_ICustomSensorReading2 = interface;
  PCustom_ICustomSensorReading2 = ^Custom_ICustomSensorReading2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Custom.ICustomSensor>
  AsyncOperationCompletedHandler_1__Custom_ICustomSensor = interface;
  PAsyncOperationCompletedHandler_1__Custom_ICustomSensor = ^AsyncOperationCompletedHandler_1__Custom_ICustomSensor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Custom.ICustomSensor>
  IAsyncOperation_1__Custom_ICustomSensor = interface;
  PIAsyncOperation_1__Custom_ICustomSensor = ^IAsyncOperation_1__Custom_ICustomSensor;

  // Windows.Devices.Sensors.Custom.ICustomSensorStatics
  Custom_ICustomSensorStatics = interface;
  PCustom_ICustomSensorStatics = ^Custom_ICustomSensorStatics;

  // Windows.Devices.Sensors.IAccelerometerReading
  IAccelerometerReading = interface;
  PIAccelerometerReading = ^IAccelerometerReading;

  // Windows.Devices.Sensors.IAccelerometerReadingChangedEventArgs
  IAccelerometerReadingChangedEventArgs = interface;
  PIAccelerometerReadingChangedEventArgs = ^IAccelerometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAccelerometer,Windows.Devices.Sensors.IAccelerometerReadingChangedEventArgs>
  TypedEventHandler_2__IAccelerometer__IAccelerometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IAccelerometer__IAccelerometerReadingChangedEventArgs = ^TypedEventHandler_2__IAccelerometer__IAccelerometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IAccelerometerShakenEventArgs
  IAccelerometerShakenEventArgs = interface;
  PIAccelerometerShakenEventArgs = ^IAccelerometerShakenEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAccelerometer,Windows.Devices.Sensors.IAccelerometerShakenEventArgs>
  TypedEventHandler_2__IAccelerometer__IAccelerometerShakenEventArgs = interface;
  PTypedEventHandler_2__IAccelerometer__IAccelerometerShakenEventArgs = ^TypedEventHandler_2__IAccelerometer__IAccelerometerShakenEventArgs;

  // Windows.Devices.Sensors.IAccelerometer
  IAccelerometer = interface;
  PIAccelerometer = ^IAccelerometer;

  // Windows.Devices.Sensors.IAccelerometer2
  IAccelerometer2 = interface;
  PIAccelerometer2 = ^IAccelerometer2;

  // Windows.Devices.Sensors.IAccelerometer3
  IAccelerometer3 = interface;
  PIAccelerometer3 = ^IAccelerometer3;

  // Windows.Devices.Sensors.IAccelerometer4
  IAccelerometer4 = interface;
  PIAccelerometer4 = ^IAccelerometer4;

  // Windows.Devices.Sensors.IAccelerometerDataThreshold
  IAccelerometerDataThreshold = interface;
  PIAccelerometerDataThreshold = ^IAccelerometerDataThreshold;

  // Windows.Devices.Sensors.IAccelerometer5
  IAccelerometer5 = interface;
  PIAccelerometer5 = ^IAccelerometer5;

  // Windows.Devices.Sensors.IAccelerometerDeviceId
  IAccelerometerDeviceId = interface;
  PIAccelerometerDeviceId = ^IAccelerometerDeviceId;

  // Windows.Devices.Sensors.IAccelerometerReading2
  IAccelerometerReading2 = interface;
  PIAccelerometerReading2 = ^IAccelerometerReading2;

  // Windows.Devices.Sensors.IAccelerometerStatics
  IAccelerometerStatics = interface;
  PIAccelerometerStatics = ^IAccelerometerStatics;

  // Windows.Devices.Sensors.IAccelerometerStatics2
  IAccelerometerStatics2 = interface;
  PIAccelerometerStatics2 = ^IAccelerometerStatics2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IAccelerometer>
  AsyncOperationCompletedHandler_1__IAccelerometer = interface;
  PAsyncOperationCompletedHandler_1__IAccelerometer = ^AsyncOperationCompletedHandler_1__IAccelerometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IAccelerometer>
  IAsyncOperation_1__IAccelerometer = interface;
  PIAsyncOperation_1__IAccelerometer = ^IAsyncOperation_1__IAccelerometer;

  // Windows.Devices.Sensors.IAccelerometerStatics3
  IAccelerometerStatics3 = interface;
  PIAccelerometerStatics3 = ^IAccelerometerStatics3;

  // Windows.Devices.Sensors.IActivitySensorReading
  IActivitySensorReading = interface;
  PIActivitySensorReading = ^IActivitySensorReading;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IActivitySensorReading>
  AsyncOperationCompletedHandler_1__IActivitySensorReading = interface;
  PAsyncOperationCompletedHandler_1__IActivitySensorReading = ^AsyncOperationCompletedHandler_1__IActivitySensorReading;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IActivitySensorReading>
  IAsyncOperation_1__IActivitySensorReading = interface;
  PIAsyncOperation_1__IActivitySensorReading = ^IAsyncOperation_1__IActivitySensorReading;

  // Windows.Devices.Sensors.IActivitySensorReadingChangedEventArgs
  IActivitySensorReadingChangedEventArgs = interface;
  PIActivitySensorReadingChangedEventArgs = ^IActivitySensorReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IActivitySensor,Windows.Devices.Sensors.IActivitySensorReadingChangedEventArgs>
  TypedEventHandler_2__IActivitySensor__IActivitySensorReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IActivitySensor__IActivitySensorReadingChangedEventArgs = ^TypedEventHandler_2__IActivitySensor__IActivitySensorReadingChangedEventArgs;

  // Windows.Devices.Sensors.IActivitySensor
  IActivitySensor = interface;
  PIActivitySensor = ^IActivitySensor;

  // Windows.Devices.Sensors.IActivitySensorReadingChangeReport
  IActivitySensorReadingChangeReport = interface;
  PIActivitySensorReadingChangeReport = ^IActivitySensorReadingChangeReport;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IActivitySensor>
  AsyncOperationCompletedHandler_1__IActivitySensor = interface;
  PAsyncOperationCompletedHandler_1__IActivitySensor = ^AsyncOperationCompletedHandler_1__IActivitySensor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IActivitySensor>
  IAsyncOperation_1__IActivitySensor = interface;
  PIAsyncOperation_1__IActivitySensor = ^IAsyncOperation_1__IActivitySensor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IActivitySensorReading>
  IIterator_1__IActivitySensorReading = interface;
  PIIterator_1__IActivitySensorReading = ^IIterator_1__IActivitySensorReading;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IActivitySensorReading>
  IIterable_1__IActivitySensorReading = interface;
  PIIterable_1__IActivitySensorReading = ^IIterable_1__IActivitySensorReading;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>
  IVectorView_1__IActivitySensorReading = interface;
  PIVectorView_1__IActivitySensorReading = ^IVectorView_1__IActivitySensorReading;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading = ^AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>>
  IAsyncOperation_1__IVectorView_1__IActivitySensorReading = interface;
  PIAsyncOperation_1__IVectorView_1__IActivitySensorReading = ^IAsyncOperation_1__IVectorView_1__IActivitySensorReading;

  // Windows.Devices.Sensors.IActivitySensorStatics
  IActivitySensorStatics = interface;
  PIActivitySensorStatics = ^IActivitySensorStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IIterator_1__IActivitySensorReadingChangeReport = interface;
  PIIterator_1__IActivitySensorReadingChangeReport = ^IIterator_1__IActivitySensorReadingChangeReport;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IIterable_1__IActivitySensorReadingChangeReport = interface;
  PIIterable_1__IActivitySensorReadingChangeReport = ^IIterable_1__IActivitySensorReadingChangeReport;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IVectorView_1__IActivitySensorReadingChangeReport = interface;
  PIVectorView_1__IActivitySensorReadingChangeReport = ^IVectorView_1__IActivitySensorReadingChangeReport;

  // Windows.Devices.Sensors.IAltimeterReading
  IAltimeterReading = interface;
  PIAltimeterReading = ^IAltimeterReading;

  // Windows.Devices.Sensors.IAltimeterReadingChangedEventArgs
  IAltimeterReadingChangedEventArgs = interface;
  PIAltimeterReadingChangedEventArgs = ^IAltimeterReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAltimeter,Windows.Devices.Sensors.IAltimeterReadingChangedEventArgs>
  TypedEventHandler_2__IAltimeter__IAltimeterReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IAltimeter__IAltimeterReadingChangedEventArgs = ^TypedEventHandler_2__IAltimeter__IAltimeterReadingChangedEventArgs;

  // Windows.Devices.Sensors.IAltimeter
  IAltimeter = interface;
  PIAltimeter = ^IAltimeter;

  // Windows.Devices.Sensors.IAltimeter2
  IAltimeter2 = interface;
  PIAltimeter2 = ^IAltimeter2;

  // Windows.Devices.Sensors.IAltimeterReading2
  IAltimeterReading2 = interface;
  PIAltimeterReading2 = ^IAltimeterReading2;

  // Windows.Devices.Sensors.IAltimeterStatics
  IAltimeterStatics = interface;
  PIAltimeterStatics = ^IAltimeterStatics;

  // Windows.Devices.Sensors.IBarometerReading
  IBarometerReading = interface;
  PIBarometerReading = ^IBarometerReading;

  // Windows.Devices.Sensors.IBarometerReadingChangedEventArgs
  IBarometerReadingChangedEventArgs = interface;
  PIBarometerReadingChangedEventArgs = ^IBarometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IBarometer,Windows.Devices.Sensors.IBarometerReadingChangedEventArgs>
  TypedEventHandler_2__IBarometer__IBarometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IBarometer__IBarometerReadingChangedEventArgs = ^TypedEventHandler_2__IBarometer__IBarometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IBarometer
  IBarometer = interface;
  PIBarometer = ^IBarometer;

  // Windows.Devices.Sensors.IBarometer2
  IBarometer2 = interface;
  PIBarometer2 = ^IBarometer2;

  // Windows.Devices.Sensors.IBarometerDataThreshold
  IBarometerDataThreshold = interface;
  PIBarometerDataThreshold = ^IBarometerDataThreshold;

  // Windows.Devices.Sensors.IBarometer3
  IBarometer3 = interface;
  PIBarometer3 = ^IBarometer3;

  // Windows.Devices.Sensors.IBarometerReading2
  IBarometerReading2 = interface;
  PIBarometerReading2 = ^IBarometerReading2;

  // Windows.Devices.Sensors.IBarometerStatics
  IBarometerStatics = interface;
  PIBarometerStatics = ^IBarometerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IBarometer>
  AsyncOperationCompletedHandler_1__IBarometer = interface;
  PAsyncOperationCompletedHandler_1__IBarometer = ^AsyncOperationCompletedHandler_1__IBarometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IBarometer>
  IAsyncOperation_1__IBarometer = interface;
  PIAsyncOperation_1__IBarometer = ^IAsyncOperation_1__IBarometer;

  // Windows.Devices.Sensors.IBarometerStatics2
  IBarometerStatics2 = interface;
  PIBarometerStatics2 = ^IBarometerStatics2;

  // Windows.Devices.Sensors.ICompassReading
  ICompassReading = interface;
  PICompassReading = ^ICompassReading;

  // Windows.Devices.Sensors.ICompassReadingChangedEventArgs
  ICompassReadingChangedEventArgs = interface;
  PICompassReadingChangedEventArgs = ^ICompassReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ICompass,Windows.Devices.Sensors.ICompassReadingChangedEventArgs>
  TypedEventHandler_2__ICompass__ICompassReadingChangedEventArgs = interface;
  PTypedEventHandler_2__ICompass__ICompassReadingChangedEventArgs = ^TypedEventHandler_2__ICompass__ICompassReadingChangedEventArgs;

  // Windows.Devices.Sensors.ICompass
  ICompass = interface;
  PICompass = ^ICompass;

  // Windows.Devices.Sensors.ICompass2
  ICompass2 = interface;
  PICompass2 = ^ICompass2;

  // Windows.Devices.Sensors.ICompass3
  ICompass3 = interface;
  PICompass3 = ^ICompass3;

  // Windows.Devices.Sensors.ICompassDataThreshold
  ICompassDataThreshold = interface;
  PICompassDataThreshold = ^ICompassDataThreshold;

  // Windows.Devices.Sensors.ICompass4
  ICompass4 = interface;
  PICompass4 = ^ICompass4;

  // Windows.Devices.Sensors.ICompassDeviceId
  ICompassDeviceId = interface;
  PICompassDeviceId = ^ICompassDeviceId;

  // Windows.Devices.Sensors.ICompassReading2
  ICompassReading2 = interface;
  PICompassReading2 = ^ICompassReading2;

  // Windows.Devices.Sensors.ICompassReadingHeadingAccuracy
  ICompassReadingHeadingAccuracy = interface;
  PICompassReadingHeadingAccuracy = ^ICompassReadingHeadingAccuracy;

  // Windows.Devices.Sensors.ICompassStatics
  ICompassStatics = interface;
  PICompassStatics = ^ICompassStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ICompass>
  AsyncOperationCompletedHandler_1__ICompass = interface;
  PAsyncOperationCompletedHandler_1__ICompass = ^AsyncOperationCompletedHandler_1__ICompass;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ICompass>
  IAsyncOperation_1__ICompass = interface;
  PIAsyncOperation_1__ICompass = ^IAsyncOperation_1__ICompass;

  // Windows.Devices.Sensors.ICompassStatics2
  ICompassStatics2 = interface;
  PICompassStatics2 = ^ICompassStatics2;

  // Windows.Devices.Sensors.IGyrometerReading
  IGyrometerReading = interface;
  PIGyrometerReading = ^IGyrometerReading;

  // Windows.Devices.Sensors.IGyrometerReadingChangedEventArgs
  IGyrometerReadingChangedEventArgs = interface;
  PIGyrometerReadingChangedEventArgs = ^IGyrometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IGyrometer,Windows.Devices.Sensors.IGyrometerReadingChangedEventArgs>
  TypedEventHandler_2__IGyrometer__IGyrometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IGyrometer__IGyrometerReadingChangedEventArgs = ^TypedEventHandler_2__IGyrometer__IGyrometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IGyrometer
  IGyrometer = interface;
  PIGyrometer = ^IGyrometer;

  // Windows.Devices.Sensors.IGyrometer2
  IGyrometer2 = interface;
  PIGyrometer2 = ^IGyrometer2;

  // Windows.Devices.Sensors.IGyrometer3
  IGyrometer3 = interface;
  PIGyrometer3 = ^IGyrometer3;

  // Windows.Devices.Sensors.IGyrometerDataThreshold
  IGyrometerDataThreshold = interface;
  PIGyrometerDataThreshold = ^IGyrometerDataThreshold;

  // Windows.Devices.Sensors.IGyrometer4
  IGyrometer4 = interface;
  PIGyrometer4 = ^IGyrometer4;

  // Windows.Devices.Sensors.IGyrometerDeviceId
  IGyrometerDeviceId = interface;
  PIGyrometerDeviceId = ^IGyrometerDeviceId;

  // Windows.Devices.Sensors.IGyrometerReading2
  IGyrometerReading2 = interface;
  PIGyrometerReading2 = ^IGyrometerReading2;

  // Windows.Devices.Sensors.IGyrometerStatics
  IGyrometerStatics = interface;
  PIGyrometerStatics = ^IGyrometerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IGyrometer>
  AsyncOperationCompletedHandler_1__IGyrometer = interface;
  PAsyncOperationCompletedHandler_1__IGyrometer = ^AsyncOperationCompletedHandler_1__IGyrometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IGyrometer>
  IAsyncOperation_1__IGyrometer = interface;
  PIAsyncOperation_1__IGyrometer = ^IAsyncOperation_1__IGyrometer;

  // Windows.Devices.Sensors.IGyrometerStatics2
  IGyrometerStatics2 = interface;
  PIGyrometerStatics2 = ^IGyrometerStatics2;

  // Windows.Foundation.IReference`1<Windows.Devices.Sensors.HumanPresence>
  IReference_1__HumanPresence = interface;
  PIReference_1__HumanPresence = ^IReference_1__HumanPresence;

  // Windows.Foundation.IReference`1<Windows.Devices.Sensors.HumanEngagement>
  IReference_1__HumanEngagement = interface;
  PIReference_1__HumanEngagement = ^IReference_1__HumanEngagement;

  // Windows.Devices.Sensors.IInclinometerReading
  IInclinometerReading = interface;
  PIInclinometerReading = ^IInclinometerReading;

  // Windows.Devices.Sensors.IInclinometerReadingChangedEventArgs
  IInclinometerReadingChangedEventArgs = interface;
  PIInclinometerReadingChangedEventArgs = ^IInclinometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IInclinometer,Windows.Devices.Sensors.IInclinometerReadingChangedEventArgs>
  TypedEventHandler_2__IInclinometer__IInclinometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IInclinometer__IInclinometerReadingChangedEventArgs = ^TypedEventHandler_2__IInclinometer__IInclinometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IInclinometer
  IInclinometer = interface;
  PIInclinometer = ^IInclinometer;

  // Windows.Devices.Sensors.IInclinometer2
  IInclinometer2 = interface;
  PIInclinometer2 = ^IInclinometer2;

  // Windows.Devices.Sensors.IInclinometer3
  IInclinometer3 = interface;
  PIInclinometer3 = ^IInclinometer3;

  // Windows.Devices.Sensors.IInclinometerDataThreshold
  IInclinometerDataThreshold = interface;
  PIInclinometerDataThreshold = ^IInclinometerDataThreshold;

  // Windows.Devices.Sensors.IInclinometer4
  IInclinometer4 = interface;
  PIInclinometer4 = ^IInclinometer4;

  // Windows.Devices.Sensors.IInclinometerDeviceId
  IInclinometerDeviceId = interface;
  PIInclinometerDeviceId = ^IInclinometerDeviceId;

  // Windows.Devices.Sensors.IInclinometerReading2
  IInclinometerReading2 = interface;
  PIInclinometerReading2 = ^IInclinometerReading2;

  // Windows.Devices.Sensors.IInclinometerReadingYawAccuracy
  IInclinometerReadingYawAccuracy = interface;
  PIInclinometerReadingYawAccuracy = ^IInclinometerReadingYawAccuracy;

  // Windows.Devices.Sensors.IInclinometerStatics
  IInclinometerStatics = interface;
  PIInclinometerStatics = ^IInclinometerStatics;

  // Windows.Devices.Sensors.IInclinometerStatics2
  IInclinometerStatics2 = interface;
  PIInclinometerStatics2 = ^IInclinometerStatics2;

  // Windows.Devices.Sensors.IInclinometerStatics3
  IInclinometerStatics3 = interface;
  PIInclinometerStatics3 = ^IInclinometerStatics3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IInclinometer>
  AsyncOperationCompletedHandler_1__IInclinometer = interface;
  PAsyncOperationCompletedHandler_1__IInclinometer = ^AsyncOperationCompletedHandler_1__IInclinometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IInclinometer>
  IAsyncOperation_1__IInclinometer = interface;
  PIAsyncOperation_1__IInclinometer = ^IAsyncOperation_1__IInclinometer;

  // Windows.Devices.Sensors.IInclinometerStatics4
  IInclinometerStatics4 = interface;
  PIInclinometerStatics4 = ^IInclinometerStatics4;

  // Windows.Devices.Sensors.ILightSensorReading
  ILightSensorReading = interface;
  PILightSensorReading = ^ILightSensorReading;

  // Windows.Devices.Sensors.ILightSensorReadingChangedEventArgs
  ILightSensorReadingChangedEventArgs = interface;
  PILightSensorReadingChangedEventArgs = ^ILightSensorReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ILightSensor,Windows.Devices.Sensors.ILightSensorReadingChangedEventArgs>
  TypedEventHandler_2__ILightSensor__ILightSensorReadingChangedEventArgs = interface;
  PTypedEventHandler_2__ILightSensor__ILightSensorReadingChangedEventArgs = ^TypedEventHandler_2__ILightSensor__ILightSensorReadingChangedEventArgs;

  // Windows.Devices.Sensors.ILightSensor
  ILightSensor = interface;
  PILightSensor = ^ILightSensor;

  // Windows.Devices.Sensors.ILightSensor2
  ILightSensor2 = interface;
  PILightSensor2 = ^ILightSensor2;

  // Windows.Devices.Sensors.ILightSensorDataThreshold
  ILightSensorDataThreshold = interface;
  PILightSensorDataThreshold = ^ILightSensorDataThreshold;

  // Windows.Devices.Sensors.ILightSensor3
  ILightSensor3 = interface;
  PILightSensor3 = ^ILightSensor3;

  // Windows.Devices.Sensors.ILightSensor4
  ILightSensor4 = interface;
  PILightSensor4 = ^ILightSensor4;

  // Windows.Devices.Sensors.ILightSensorDeviceId
  ILightSensorDeviceId = interface;
  PILightSensorDeviceId = ^ILightSensorDeviceId;

  // Windows.Devices.Sensors.ILightSensorReading2
  ILightSensorReading2 = interface;
  PILightSensorReading2 = ^ILightSensorReading2;

  // Windows.Devices.Sensors.ILightSensorReading3
  ILightSensorReading3 = interface;
  PILightSensorReading3 = ^ILightSensorReading3;

  // Windows.Devices.Sensors.ILightSensorStatics
  ILightSensorStatics = interface;
  PILightSensorStatics = ^ILightSensorStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ILightSensor>
  AsyncOperationCompletedHandler_1__ILightSensor = interface;
  PAsyncOperationCompletedHandler_1__ILightSensor = ^AsyncOperationCompletedHandler_1__ILightSensor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ILightSensor>
  IAsyncOperation_1__ILightSensor = interface;
  PIAsyncOperation_1__ILightSensor = ^IAsyncOperation_1__ILightSensor;

  // Windows.Devices.Sensors.ILightSensorStatics2
  ILightSensorStatics2 = interface;
  PILightSensorStatics2 = ^ILightSensorStatics2;

  // Windows.Devices.Sensors.IMagnetometerReading
  IMagnetometerReading = interface;
  PIMagnetometerReading = ^IMagnetometerReading;

  // Windows.Devices.Sensors.IMagnetometerReadingChangedEventArgs
  IMagnetometerReadingChangedEventArgs = interface;
  PIMagnetometerReadingChangedEventArgs = ^IMagnetometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IMagnetometer,Windows.Devices.Sensors.IMagnetometerReadingChangedEventArgs>
  TypedEventHandler_2__IMagnetometer__IMagnetometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IMagnetometer__IMagnetometerReadingChangedEventArgs = ^TypedEventHandler_2__IMagnetometer__IMagnetometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IMagnetometer
  IMagnetometer = interface;
  PIMagnetometer = ^IMagnetometer;

  // Windows.Devices.Sensors.IMagnetometer2
  IMagnetometer2 = interface;
  PIMagnetometer2 = ^IMagnetometer2;

  // Windows.Devices.Sensors.IMagnetometer3
  IMagnetometer3 = interface;
  PIMagnetometer3 = ^IMagnetometer3;

  // Windows.Devices.Sensors.IMagnetometerDataThreshold
  IMagnetometerDataThreshold = interface;
  PIMagnetometerDataThreshold = ^IMagnetometerDataThreshold;

  // Windows.Devices.Sensors.IMagnetometer4
  IMagnetometer4 = interface;
  PIMagnetometer4 = ^IMagnetometer4;

  // Windows.Devices.Sensors.IMagnetometerDeviceId
  IMagnetometerDeviceId = interface;
  PIMagnetometerDeviceId = ^IMagnetometerDeviceId;

  // Windows.Devices.Sensors.IMagnetometerReading2
  IMagnetometerReading2 = interface;
  PIMagnetometerReading2 = ^IMagnetometerReading2;

  // Windows.Devices.Sensors.IMagnetometerStatics
  IMagnetometerStatics = interface;
  PIMagnetometerStatics = ^IMagnetometerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IMagnetometer>
  AsyncOperationCompletedHandler_1__IMagnetometer = interface;
  PAsyncOperationCompletedHandler_1__IMagnetometer = ^AsyncOperationCompletedHandler_1__IMagnetometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IMagnetometer>
  IAsyncOperation_1__IMagnetometer = interface;
  PIAsyncOperation_1__IMagnetometer = ^IAsyncOperation_1__IMagnetometer;

  // Windows.Devices.Sensors.IMagnetometerStatics2
  IMagnetometerStatics2 = interface;
  PIMagnetometerStatics2 = ^IMagnetometerStatics2;

  // Windows.Devices.Sensors.ISensorRotationMatrix
  ISensorRotationMatrix = interface;
  PISensorRotationMatrix = ^ISensorRotationMatrix;

  // Windows.Devices.Sensors.ISensorQuaternion
  ISensorQuaternion = interface;
  PISensorQuaternion = ^ISensorQuaternion;

  // Windows.Devices.Sensors.IOrientationSensorReading
  IOrientationSensorReading = interface;
  PIOrientationSensorReading = ^IOrientationSensorReading;

  // Windows.Devices.Sensors.IOrientationSensorReadingChangedEventArgs
  IOrientationSensorReadingChangedEventArgs = interface;
  PIOrientationSensorReadingChangedEventArgs = ^IOrientationSensorReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IOrientationSensor,Windows.Devices.Sensors.IOrientationSensorReadingChangedEventArgs>
  TypedEventHandler_2__IOrientationSensor__IOrientationSensorReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IOrientationSensor__IOrientationSensorReadingChangedEventArgs = ^TypedEventHandler_2__IOrientationSensor__IOrientationSensorReadingChangedEventArgs;

  // Windows.Devices.Sensors.IOrientationSensor
  IOrientationSensor = interface;
  PIOrientationSensor = ^IOrientationSensor;

  // Windows.Devices.Sensors.IOrientationSensor2
  IOrientationSensor2 = interface;
  PIOrientationSensor2 = ^IOrientationSensor2;

  // Windows.Devices.Sensors.IOrientationSensor3
  IOrientationSensor3 = interface;
  PIOrientationSensor3 = ^IOrientationSensor3;

  // Windows.Devices.Sensors.IOrientationSensorDeviceId
  IOrientationSensorDeviceId = interface;
  PIOrientationSensorDeviceId = ^IOrientationSensorDeviceId;

  // Windows.Devices.Sensors.IOrientationSensorReading2
  IOrientationSensorReading2 = interface;
  PIOrientationSensorReading2 = ^IOrientationSensorReading2;

  // Windows.Devices.Sensors.IOrientationSensorReadingYawAccuracy
  IOrientationSensorReadingYawAccuracy = interface;
  PIOrientationSensorReadingYawAccuracy = ^IOrientationSensorReadingYawAccuracy;

  // Windows.Devices.Sensors.IOrientationSensorStatics
  IOrientationSensorStatics = interface;
  PIOrientationSensorStatics = ^IOrientationSensorStatics;

  // Windows.Devices.Sensors.IOrientationSensorStatics2
  IOrientationSensorStatics2 = interface;
  PIOrientationSensorStatics2 = ^IOrientationSensorStatics2;

  // Windows.Devices.Sensors.IOrientationSensorStatics3
  IOrientationSensorStatics3 = interface;
  PIOrientationSensorStatics3 = ^IOrientationSensorStatics3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IOrientationSensor>
  AsyncOperationCompletedHandler_1__IOrientationSensor = interface;
  PAsyncOperationCompletedHandler_1__IOrientationSensor = ^AsyncOperationCompletedHandler_1__IOrientationSensor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IOrientationSensor>
  IAsyncOperation_1__IOrientationSensor = interface;
  PIAsyncOperation_1__IOrientationSensor = ^IAsyncOperation_1__IOrientationSensor;

  // Windows.Devices.Sensors.IOrientationSensorStatics4
  IOrientationSensorStatics4 = interface;
  PIOrientationSensorStatics4 = ^IOrientationSensorStatics4;

  // Windows.Devices.Sensors.IPedometerReading
  IPedometerReading = interface;
  PIPedometerReading = ^IPedometerReading;

  // Windows.Devices.Sensors.IPedometerReadingChangedEventArgs
  IPedometerReadingChangedEventArgs = interface;
  PIPedometerReadingChangedEventArgs = ^IPedometerReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IPedometer,Windows.Devices.Sensors.IPedometerReadingChangedEventArgs>
  TypedEventHandler_2__IPedometer__IPedometerReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IPedometer__IPedometerReadingChangedEventArgs = ^TypedEventHandler_2__IPedometer__IPedometerReadingChangedEventArgs;

  // Windows.Devices.Sensors.IPedometer
  IPedometer = interface;
  PIPedometer = ^IPedometer;

  // Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>
  IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface;
  PIKeyValuePair_2__PedometerStepKind__IPedometerReading = ^IKeyValuePair_2__PedometerStepKind__IPedometerReading;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>>
  IIterator_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface;
  PIIterator_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = ^IIterator_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>>
  IIterable_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface;
  PIIterable_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = ^IIterable_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading;

  // Windows.Foundation.Collections.IMapView`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>
  IMapView_2__PedometerStepKind__IPedometerReading = interface;
  PIMapView_2__PedometerStepKind__IPedometerReading = ^IMapView_2__PedometerStepKind__IPedometerReading;

  // Windows.Devices.Sensors.IPedometer2
  IPedometer2 = interface;
  PIPedometer2 = ^IPedometer2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IPedometer>
  AsyncOperationCompletedHandler_1__IPedometer = interface;
  PAsyncOperationCompletedHandler_1__IPedometer = ^AsyncOperationCompletedHandler_1__IPedometer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IPedometer>
  IAsyncOperation_1__IPedometer = interface;
  PIAsyncOperation_1__IPedometer = ^IAsyncOperation_1__IPedometer;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IPedometerReading>
  IIterator_1__IPedometerReading = interface;
  PIIterator_1__IPedometerReading = ^IIterator_1__IPedometerReading;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IPedometerReading>
  IIterable_1__IPedometerReading = interface;
  PIIterable_1__IPedometerReading = ^IIterable_1__IPedometerReading;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>
  IVectorView_1__IPedometerReading = interface;
  PIVectorView_1__IPedometerReading = ^IVectorView_1__IPedometerReading;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading = ^AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>>
  IAsyncOperation_1__IVectorView_1__IPedometerReading = interface;
  PIAsyncOperation_1__IVectorView_1__IPedometerReading = ^IAsyncOperation_1__IVectorView_1__IPedometerReading;

  // Windows.Devices.Sensors.IPedometerStatics
  IPedometerStatics = interface;
  PIPedometerStatics = ^IPedometerStatics;

  // Windows.Devices.Sensors.ISensorDataThresholdTriggerDetails
  ISensorDataThresholdTriggerDetails = interface;
  PISensorDataThresholdTriggerDetails = ^ISensorDataThresholdTriggerDetails;

  // Windows.Devices.Sensors.IPedometerStatics2
  IPedometerStatics2 = interface;
  PIPedometerStatics2 = ^IPedometerStatics2;

  // Windows.Devices.Sensors.IProximitySensorReading
  IProximitySensorReading = interface;
  PIProximitySensorReading = ^IProximitySensorReading;

  // Windows.Devices.Sensors.IProximitySensorReadingChangedEventArgs
  IProximitySensorReadingChangedEventArgs = interface;
  PIProximitySensorReadingChangedEventArgs = ^IProximitySensorReadingChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IProximitySensor,Windows.Devices.Sensors.IProximitySensorReadingChangedEventArgs>
  TypedEventHandler_2__IProximitySensor__IProximitySensorReadingChangedEventArgs = interface;
  PTypedEventHandler_2__IProximitySensor__IProximitySensorReadingChangedEventArgs = ^TypedEventHandler_2__IProximitySensor__IProximitySensorReadingChangedEventArgs;

  // Windows.Devices.Sensors.IProximitySensor
  IProximitySensor = interface;
  PIProximitySensor = ^IProximitySensor;

  // Windows.Devices.Sensors.IProximitySensorStatics
  IProximitySensorStatics = interface;
  PIProximitySensorStatics = ^IProximitySensorStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IProximitySensorReading>
  IIterator_1__IProximitySensorReading = interface;
  PIIterator_1__IProximitySensorReading = ^IIterator_1__IProximitySensorReading;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IProximitySensorReading>
  IIterable_1__IProximitySensorReading = interface;
  PIIterable_1__IProximitySensorReading = ^IIterable_1__IProximitySensorReading;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IProximitySensorReading>
  IVectorView_1__IProximitySensorReading = interface;
  PIVectorView_1__IProximitySensorReading = ^IVectorView_1__IProximitySensorReading;

  // Windows.Devices.Sensors.IProximitySensorStatics2
  IProximitySensorStatics2 = interface;
  PIProximitySensorStatics2 = ^IProximitySensorStatics2;

  // Windows.Devices.Sensors.ISimpleOrientationSensorOrientationChangedEventArgs
  ISimpleOrientationSensorOrientationChangedEventArgs = interface;
  PISimpleOrientationSensorOrientationChangedEventArgs = ^ISimpleOrientationSensorOrientationChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ISimpleOrientationSensor,Windows.Devices.Sensors.ISimpleOrientationSensorOrientationChangedEventArgs>
  TypedEventHandler_2__ISimpleOrientationSensor__ISimpleOrientationSensorOrientationChangedEventArgs = interface;
  PTypedEventHandler_2__ISimpleOrientationSensor__ISimpleOrientationSensorOrientationChangedEventArgs = ^TypedEventHandler_2__ISimpleOrientationSensor__ISimpleOrientationSensorOrientationChangedEventArgs;

  // Windows.Devices.Sensors.ISimpleOrientationSensor
  ISimpleOrientationSensor = interface;
  PISimpleOrientationSensor = ^ISimpleOrientationSensor;

  // Windows.Devices.Sensors.ISimpleOrientationSensor2
  ISimpleOrientationSensor2 = interface;
  PISimpleOrientationSensor2 = ^ISimpleOrientationSensor2;

  // Windows.Devices.Sensors.ISimpleOrientationSensorDeviceId
  ISimpleOrientationSensorDeviceId = interface;
  PISimpleOrientationSensorDeviceId = ^ISimpleOrientationSensorDeviceId;

  // Windows.Devices.Sensors.ISimpleOrientationSensorStatics
  ISimpleOrientationSensorStatics = interface;
  PISimpleOrientationSensorStatics = ^ISimpleOrientationSensorStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ISimpleOrientationSensor>
  AsyncOperationCompletedHandler_1__ISimpleOrientationSensor = interface;
  PAsyncOperationCompletedHandler_1__ISimpleOrientationSensor = ^AsyncOperationCompletedHandler_1__ISimpleOrientationSensor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ISimpleOrientationSensor>
  IAsyncOperation_1__ISimpleOrientationSensor = interface;
  PIAsyncOperation_1__ISimpleOrientationSensor = ^IAsyncOperation_1__ISimpleOrientationSensor;

  // Windows.Devices.Sensors.ISimpleOrientationSensorStatics2
  ISimpleOrientationSensorStatics2 = interface;
  PISimpleOrientationSensorStatics2 = ^ISimpleOrientationSensorStatics2;

  // Windows.Devices.Sensors Enums

  // Windows.Devices.Sensors.AccelerometerReadingType
  AccelerometerReadingType = (
    Standard = 0,
    Linear = 1,
    Gravity = 2
  );
  PAccelerometerReadingType = ^AccelerometerReadingType;

  // Windows.Devices.Sensors.ActivitySensorReadingConfidence
  ActivitySensorReadingConfidence = (
    High = 0,
    Low = 1
  );
  PActivitySensorReadingConfidence = ^ActivitySensorReadingConfidence;

  // Windows.Devices.Sensors.ActivityType
  ActivityType = (
    Unknown = 0,
    Idle = 1,
    Stationary = 2,
    Fidgeting = 3,
    Walking = 4,
    Running = 5,
    InVehicle = 6,
    Biking = 7
  );
  PActivityType = ^ActivityType;

  // Windows.Devices.Sensors.HumanEngagement
  HumanEngagement = (
    Unknown = 0,
    Engaged = 1,
    Unengaged = 2
  );
  PHumanEngagement = ^HumanEngagement;

  // Windows.Devices.Sensors.HumanPresence
  HumanPresence = (
    Unknown = 0,
    Present = 1,
    NotPresent = 2
  );
  PHumanPresence = ^HumanPresence;

  // Windows.Devices.Sensors.MagnetometerAccuracy
  MagnetometerAccuracy = (
    Unknown = 0,
    Unreliable = 1,
    Approximate = 2,
    High = 3
  );
  PMagnetometerAccuracy = ^MagnetometerAccuracy;

  // Windows.Devices.Sensors.OnlookerDetectionAction
  OnlookerDetectionAction = (
    Dim = 0,
    Notify = 1,
    DimAndNotify = 2
  );
  POnlookerDetectionAction = ^OnlookerDetectionAction;

  // Windows.Devices.Sensors.OnlookerDetectionBackOnMode
  OnlookerDetectionBackOnMode = (
    Manually = 0,
    OneHour = 1,
    FourHours = 2,
    OneDay = 3
  );
  POnlookerDetectionBackOnMode = ^OnlookerDetectionBackOnMode;

  // Windows.Devices.Sensors.PedometerStepKind
  PedometerStepKind = (
    Unknown = 0,
    Walking = 1,
    Running = 2
  );
  PPedometerStepKind = ^PedometerStepKind;

  // Windows.Devices.Sensors.SensorOptimizationGoal
  SensorOptimizationGoal = (
    Precision = 0,
    PowerEfficiency = 1
  );
  PSensorOptimizationGoal = ^SensorOptimizationGoal;

  // Windows.Devices.Sensors.SensorReadingType
  SensorReadingType = (
    Absolute = 0,
    Relative = 1
  );
  PSensorReadingType = ^SensorReadingType;

  // Windows.Devices.Sensors.SensorType
  SensorType = (
    Accelerometer = 0,
    ActivitySensor = 1,
    Barometer = 2,
    Compass = 3,
    CustomSensor = 4,
    Gyroscope = 5,
    ProximitySensor = 6,
    Inclinometer = 7,
    LightSensor = 8,
    OrientationSensor = 9,
    Pedometer = 10,
    RelativeInclinometer = 11,
    RelativeOrientationSensor = 12,
    SimpleOrientationSensor = 13
  );
  PSensorType = ^SensorType;

  // Windows.Devices.Sensors.SimpleOrientation
  SimpleOrientation = (
    NotRotated = 0,
    Rotated90DegreesCounterclockwise = 1,
    Rotated180DegreesCounterclockwise = 2,
    Rotated270DegreesCounterclockwise = 3,
    Faceup = 4,
    Facedown = 5
  );
  PSimpleOrientation = ^SimpleOrientation;

  // Windows.Devices.Sensors Records

  // Windows.Devices.Sensors.LightSensorChromaticity
  LightSensorChromaticity = record
    X: Double;
    Y: Double;
  end;
  PLightSensorChromaticity = ^LightSensorChromaticity;

  // Windows.Devices.Sensors Interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ActivityType>
  IIterator_1__ActivityType = interface(IInspectable)
  ['{40524281-A7C6-50B1-B6F5-0BAA95D902C2}']
    function get_Current: ActivityType; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PActivityType): Cardinal; safecall;
    property Current: ActivityType read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ActivityType>
  IIterable_1__ActivityType = interface(IInspectable)
  ['{2A04CDFA-5DFD-5178-8731-ADE998E4A7F6}']
    function First: IIterator_1__ActivityType; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.ActivityType>
  IVectorView_1__ActivityType = interface(IInspectable)
  ['{FC7A0488-2803-505C-9E62-9200AFE416C6}']
    function GetAt(index: Cardinal): ActivityType; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: ActivityType; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PActivityType): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Sensors.ActivityType>
  IVector_1__ActivityType = interface(IInspectable)
  ['{E3E660D6-D041-5ECD-B18B-FA254E4A860F}']
    function GetAt(index: Cardinal): ActivityType; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__ActivityType; safecall;
    function IndexOf(value: ActivityType; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: ActivityType); safecall;
    procedure InsertAt(index: Cardinal; value: ActivityType); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: ActivityType); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PActivityType): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PActivityType); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.Custom.ICustomSensorReading
  Custom_ICustomSensorReading = interface(IInspectable)
  ['{64004F4D-446A-4366-A87A-5F963268EC53}']
    function get_Timestamp: DateTime; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.Custom.ICustomSensorReadingChangedEventArgs
  Custom_ICustomSensorReadingChangedEventArgs = interface(IInspectable)
  ['{6B202023-CFFD-4CC1-8FF0-E21823D76FCC}']
    function get_Reading: Custom_ICustomSensorReading; safecall;
    property Reading: Custom_ICustomSensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Custom.CustomSensor,Windows.Devices.Sensors.Custom.CustomSensorReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Custom.ICustomSensor,Windows.Devices.Sensors.Custom.ICustomSensorReadingChangedEventArgs>
  TypedEventHandler_2__Custom_ICustomSensor__Custom_ICustomSensorReadingChangedEventArgs = interface(IUnknown)
  ['{AA9460CB-F08C-5963-B232-CC4075E984E7}']
    procedure Invoke(sender: Custom_ICustomSensor; args: Custom_ICustomSensorReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.Custom.ICustomSensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Custom_CustomSensor)]
  Custom_ICustomSensor = interface(IInspectable)
  ['{A136F9AD-4034-4B4D-99DD-531AAC649C09}']
    function GetCurrentReading: Custom_ICustomSensorReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function get_DeviceId: HSTRING; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__Custom_ICustomSensor__Custom_ICustomSensorReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.Custom.ICustomSensor2
  Custom_ICustomSensor2 = interface(IInspectable)
  ['{20DB3111-EC58-4D9F-BFBD-E77825088510}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // Windows.Devices.Sensors.Custom.ICustomSensorReading2
  Custom_ICustomSensorReading2 = interface(IInspectable)
  ['{223C98EA-BF73-4992-9A48-D3C897594CCB}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Custom.CustomSensor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Custom.ICustomSensor>
  AsyncOperationCompletedHandler_1__Custom_ICustomSensor = interface(IUnknown)
  ['{808B62D7-6E02-5680-A59E-118A98A4E70F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Custom_ICustomSensor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Custom.CustomSensor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Custom.ICustomSensor>
  IAsyncOperation_1__Custom_ICustomSensor = interface(IInspectable)
  ['{7FBFBE55-9674-54E3-A269-9CAA820ED23C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Custom_ICustomSensor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Custom_ICustomSensor; safecall;
    function GetResults: Custom_ICustomSensor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Custom_ICustomSensor read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.Custom.ICustomSensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Custom_CustomSensor)]
  Custom_ICustomSensorStatics = interface(IInspectable)
  ['{992052CF-F422-4C7D-836B-E7DC74A7124B}']
    function GetDeviceSelector(interfaceId: TGuid): HSTRING; safecall;
    function FromIdAsync(sensorId: HSTRING): IAsyncOperation_1__Custom_ICustomSensor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerReading
  IAccelerometerReading = interface(IInspectable)
  ['{B9FE7ACB-D351-40AF-8BB6-7AA9AE641FB7}']
    function get_Timestamp: DateTime; safecall;
    function get_AccelerationX: Double; safecall;
    function get_AccelerationY: Double; safecall;
    function get_AccelerationZ: Double; safecall;
    property AccelerationX: Double read get_AccelerationX;
    property AccelerationY: Double read get_AccelerationY;
    property AccelerationZ: Double read get_AccelerationZ;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerReadingChangedEventArgs
  IAccelerometerReadingChangedEventArgs = interface(IInspectable)
  ['{0095C65B-B6AC-475A-9F44-8B32D35A3F25}']
    function get_Reading: IAccelerometerReading; safecall;
    property Reading: IAccelerometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Accelerometer,Windows.Devices.Sensors.AccelerometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAccelerometer,Windows.Devices.Sensors.IAccelerometerReadingChangedEventArgs>
  TypedEventHandler_2__IAccelerometer__IAccelerometerReadingChangedEventArgs = interface(IUnknown)
  ['{A5E83E40-B597-5B83-92F5-5BED3926CA80}']
    procedure Invoke(sender: IAccelerometer; args: IAccelerometerReadingChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerShakenEventArgs
  IAccelerometerShakenEventArgs = interface(IInspectable)
  ['{95FF01D1-4A28-4F35-98E8-8178AAE4084A}']
    function get_Timestamp: DateTime; safecall;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Accelerometer,Windows.Devices.Sensors.AccelerometerShakenEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAccelerometer,Windows.Devices.Sensors.IAccelerometerShakenEventArgs>
  TypedEventHandler_2__IAccelerometer__IAccelerometerShakenEventArgs = interface(IUnknown)
  ['{3E5D6EAF-F169-5D60-92B0-98CD6BD8F808}']
    procedure Invoke(sender: IAccelerometer; args: IAccelerometerShakenEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Accelerometer)]
  IAccelerometer = interface(IInspectable)
  ['{DF184548-2711-4DA7-8098-4B82205D3C7D}']
    function GetCurrentReading: IAccelerometerReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IAccelerometer__IAccelerometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    function add_Shaken(handler: TypedEventHandler_2__IAccelerometer__IAccelerometerShakenEventArgs): EventRegistrationToken; safecall;
    procedure remove_Shaken(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometer2
  IAccelerometer2 = interface(IInspectable)
  ['{E8F092EE-4964-401A-B602-220D7153C60A}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometer3
  IAccelerometer3 = interface(IInspectable)
  ['{87E0022A-ED80-49EB-BF8A-A4EA31E5CD84}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometer4
  IAccelerometer4 = interface(IInspectable)
  ['{1D373C4F-42D3-45B2-8144-AB7FB665EB59}']
    function get_ReadingType: AccelerometerReadingType; safecall;
    property ReadingType: AccelerometerReadingType read get_ReadingType;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerDataThreshold
  IAccelerometerDataThreshold = interface(IInspectable)
  ['{F92C1B68-6320-5577-879E-9942621C3DD9}']
    function get_XAxisInGForce: Double; safecall;
    procedure put_XAxisInGForce(value: Double); safecall;
    function get_YAxisInGForce: Double; safecall;
    procedure put_YAxisInGForce(value: Double); safecall;
    function get_ZAxisInGForce: Double; safecall;
    procedure put_ZAxisInGForce(value: Double); safecall;
    property XAxisInGForce: Double read get_XAxisInGForce write put_XAxisInGForce;
    property YAxisInGForce: Double read get_YAxisInGForce write put_YAxisInGForce;
    property ZAxisInGForce: Double read get_ZAxisInGForce write put_ZAxisInGForce;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometer5
  IAccelerometer5 = interface(IInspectable)
  ['{7E7E7021-DEF4-53A6-AF43-806FD538EDF6}']
    function get_ReportThreshold: IAccelerometerDataThreshold; safecall;
    property ReportThreshold: IAccelerometerDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerDeviceId
  IAccelerometerDeviceId = interface(IInspectable)
  ['{7EAC64A9-97D5-446D-AB5A-917DF9B96A2C}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.IAccelerometerReading2
  IAccelerometerReading2 = interface(IInspectable)
  ['{0A864AA2-15AE-4A40-BE55-DB58D7DE7389}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Accelerometer)]
  IAccelerometerStatics = interface(IInspectable)
  ['{A5E28B74-5A87-4A2D-BECC-0F906EA061DD}']
    function GetDefault: IAccelerometer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Accelerometer)]
  IAccelerometerStatics2 = interface(IInspectable)
  ['{C4C4842F-D86B-4685-B2D7-3396F798D57B}']
    function GetDefault(readingType: AccelerometerReadingType): IAccelerometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Accelerometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IAccelerometer>
  AsyncOperationCompletedHandler_1__IAccelerometer = interface(IUnknown)
  ['{C7C339B6-7527-502A-8A4C-CB9BEFE15840}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IAccelerometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Accelerometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IAccelerometer>
  IAsyncOperation_1__IAccelerometer = interface(IInspectable)
  ['{FC761D3B-5E4D-5148-A618-7B677059D0B8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IAccelerometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IAccelerometer; safecall;
    function GetResults: IAccelerometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IAccelerometer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAccelerometerStatics3
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Accelerometer)]
  IAccelerometerStatics3 = interface(IInspectable)
  ['{9DE218CF-455D-4CF3-8200-70E1410340F8}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IAccelerometer; safecall;
    function GetDeviceSelector(readingType: AccelerometerReadingType): HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IActivitySensorReading
  IActivitySensorReading = interface(IInspectable)
  ['{85125A96-1472-40A2-B2AE-E1EF29226C78}']
    function get_Timestamp: DateTime; safecall;
    function get_Activity: ActivityType; safecall;
    function get_Confidence: ActivitySensorReadingConfidence; safecall;
    property Activity: ActivityType read get_Activity;
    property Confidence: ActivitySensorReadingConfidence read get_Confidence;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ActivitySensorReading>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IActivitySensorReading>
  AsyncOperationCompletedHandler_1__IActivitySensorReading = interface(IUnknown)
  ['{ADC48D5D-B343-5A58-8454-6E2BC2E0475C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IActivitySensorReading; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ActivitySensorReading>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IActivitySensorReading>
  IAsyncOperation_1__IActivitySensorReading = interface(IInspectable)
  ['{79A87969-327F-5B7A-A0D3-73EAB16DE21C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IActivitySensorReading); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IActivitySensorReading; safecall;
    function GetResults: IActivitySensorReading; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IActivitySensorReading read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IActivitySensorReadingChangedEventArgs
  IActivitySensorReadingChangedEventArgs = interface(IInspectable)
  ['{DE386717-AEB6-4EC7-946A-D9CC19B951EC}']
    function get_Reading: IActivitySensorReading; safecall;
    property Reading: IActivitySensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ActivitySensor,Windows.Devices.Sensors.ActivitySensorReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IActivitySensor,Windows.Devices.Sensors.IActivitySensorReadingChangedEventArgs>
  TypedEventHandler_2__IActivitySensor__IActivitySensorReadingChangedEventArgs = interface(IUnknown)
  ['{A5B72E01-546C-5FBB-B847-49200AAAAAC5}']
    procedure Invoke(sender: IActivitySensor; args: IActivitySensorReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IActivitySensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_ActivitySensor)]
  IActivitySensor = interface(IInspectable)
  ['{CD7A630C-FB5F-48EB-B09B-A2708D1C61EF}']
    function GetCurrentReadingAsync: IAsyncOperation_1__IActivitySensorReading; safecall;
    function get_SubscribedActivities: IVector_1__ActivityType; safecall;
    function get_PowerInMilliwatts: Double; safecall;
    function get_DeviceId: HSTRING; safecall;
    function get_SupportedActivities: IVectorView_1__ActivityType; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IActivitySensor__IActivitySensorReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property PowerInMilliwatts: Double read get_PowerInMilliwatts;
    property SubscribedActivities: IVector_1__ActivityType read get_SubscribedActivities;
    property SupportedActivities: IVectorView_1__ActivityType read get_SupportedActivities;
  end;

  // Windows.Devices.Sensors.IActivitySensorReadingChangeReport
  IActivitySensorReadingChangeReport = interface(IInspectable)
  ['{4F3C2915-D93B-47BD-960A-F20FB2F322B9}']
    function get_Reading: IActivitySensorReading; safecall;
    property Reading: IActivitySensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ActivitySensor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IActivitySensor>
  AsyncOperationCompletedHandler_1__IActivitySensor = interface(IUnknown)
  ['{FB0594F4-93D9-5C2F-B8EB-90F1E9258FDC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IActivitySensor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ActivitySensor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IActivitySensor>
  IAsyncOperation_1__IActivitySensor = interface(IInspectable)
  ['{C33003AE-E7AE-572B-8D55-7DB197356C30}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IActivitySensor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IActivitySensor; safecall;
    function GetResults: IActivitySensor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IActivitySensor read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ActivitySensorReading>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IActivitySensorReading>
  IIterator_1__IActivitySensorReading = interface(IInspectable)
  ['{D2DAB535-0C94-547E-AFE3-5527BCBEB9CC}']
    function get_Current: IActivitySensorReading; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIActivitySensorReading): Cardinal; safecall;
    property Current: IActivitySensorReading read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ActivitySensorReading>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IActivitySensorReading>
  IIterable_1__IActivitySensorReading = interface(IInspectable)
  ['{9A34CE03-8C6D-5994-907F-D5C2D19148CB}']
    function First: IIterator_1__IActivitySensorReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>
  IVectorView_1__IActivitySensorReading = interface(IInspectable)
  ['{780FDF9E-4215-50AA-B2FC-9643492B7E6C}']
    function GetAt(index: Cardinal): IActivitySensorReading; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IActivitySensorReading; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIActivitySensorReading): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.ActivitySensorReading>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading = interface(IUnknown)
  ['{179FB953-2D58-5991-8F5B-AC64219A1101}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IActivitySensorReading; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.ActivitySensorReading>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReading>>
  IAsyncOperation_1__IVectorView_1__IActivitySensorReading = interface(IInspectable)
  ['{CD781B82-7900-51A3-80CE-903E2E0A4F0E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading; safecall;
    function GetResults: IVectorView_1__IActivitySensorReading; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IActivitySensorReading read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IActivitySensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_ActivitySensor)]
  IActivitySensorStatics = interface(IInspectable)
  ['{A71E0E9D-EE8B-45D1-B25B-08CC0DF92AB6}']
    function GetDefaultAsync: IAsyncOperation_1__IActivitySensor; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IActivitySensor; safecall;
    function GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IActivitySensorReading; overload; safecall;
    function GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IActivitySensorReading; overload; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ActivitySensorReadingChangeReport>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IIterator_1__IActivitySensorReadingChangeReport = interface(IInspectable)
  ['{9C07034E-8333-59D5-8D60-0E3F0438AC12}']
    function get_Current: IActivitySensorReadingChangeReport; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIActivitySensorReadingChangeReport): Cardinal; safecall;
    property Current: IActivitySensorReadingChangeReport read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ActivitySensorReadingChangeReport>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IIterable_1__IActivitySensorReadingChangeReport = interface(IInspectable)
  ['{551A4962-9E96-5E6B-8B8A-65EE3D0046F3}']
    function First: IIterator_1__IActivitySensorReadingChangeReport; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IActivitySensorReadingChangeReport>
  IVectorView_1__IActivitySensorReadingChangeReport = interface(IInspectable)
  ['{50767C75-433E-5527-8CE5-7D61ED23BC9E}']
    function GetAt(index: Cardinal): IActivitySensorReadingChangeReport; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IActivitySensorReadingChangeReport; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIActivitySensorReadingChangeReport): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAltimeterReading
  IAltimeterReading = interface(IInspectable)
  ['{FBE8EF73-7F5E-48C8-AA1A-F1F3BEFC1144}']
    function get_Timestamp: DateTime; safecall;
    function get_AltitudeChangeInMeters: Double; safecall;
    property AltitudeChangeInMeters: Double read get_AltitudeChangeInMeters;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IAltimeterReadingChangedEventArgs
  IAltimeterReadingChangedEventArgs = interface(IInspectable)
  ['{7069D077-446D-47F7-998C-EBC23B45E4A2}']
    function get_Reading: IAltimeterReading; safecall;
    property Reading: IAltimeterReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Altimeter,Windows.Devices.Sensors.AltimeterReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IAltimeter,Windows.Devices.Sensors.IAltimeterReadingChangedEventArgs>
  TypedEventHandler_2__IAltimeter__IAltimeterReadingChangedEventArgs = interface(IUnknown)
  ['{D775D699-9D74-5473-9C1B-D51A89DB6642}']
    procedure Invoke(sender: IAltimeter; args: IAltimeterReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAltimeter
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Altimeter)]
  IAltimeter = interface(IInspectable)
  ['{72F057FD-8F04-49F1-B4A7-F4E363B701A2}']
    function GetCurrentReading: IAltimeterReading; safecall;
    function get_DeviceId: HSTRING; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IAltimeter__IAltimeterReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAltimeter2
  IAltimeter2 = interface(IInspectable)
  ['{C9471BF9-2ADD-48F5-9F08-3D0C7660D938}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // Windows.Devices.Sensors.IAltimeterReading2
  IAltimeterReading2 = interface(IInspectable)
  ['{543A1BD9-6D0B-42B2-BD69-BC8FAE0F782C}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IAltimeterStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Altimeter)]
  IAltimeterStatics = interface(IInspectable)
  ['{9EB4D7C3-E5AC-47CE-8EEF-D3718168C01F}']
    function GetDefault: IAltimeter; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometerReading
  IBarometerReading = interface(IInspectable)
  ['{F5B9D2E6-1DF6-4A1A-A7AD-321D4F5DB247}']
    function get_Timestamp: DateTime; safecall;
    function get_StationPressureInHectopascals: Double; safecall;
    property StationPressureInHectopascals: Double read get_StationPressureInHectopascals;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometerReadingChangedEventArgs
  IBarometerReadingChangedEventArgs = interface(IInspectable)
  ['{3D84945F-037B-404F-9BBB-6232D69543C3}']
    function get_Reading: IBarometerReading; safecall;
    property Reading: IBarometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Barometer,Windows.Devices.Sensors.BarometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IBarometer,Windows.Devices.Sensors.IBarometerReadingChangedEventArgs>
  TypedEventHandler_2__IBarometer__IBarometerReadingChangedEventArgs = interface(IUnknown)
  ['{E4CAF459-D101-5CA5-A4EA-DEB0917AE27E}']
    procedure Invoke(sender: IBarometer; args: IBarometerReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Barometer)]
  IBarometer = interface(IInspectable)
  ['{934475A8-78BF-452F-B017-F0209CE6DAB4}']
    function GetCurrentReading: IBarometerReading; safecall;
    function get_DeviceId: HSTRING; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IBarometer__IBarometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometer2
  IBarometer2 = interface(IInspectable)
  ['{32BCC418-3EEB-4D04-9574-7633A8781F9F}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometerDataThreshold
  IBarometerDataThreshold = interface(IInspectable)
  ['{076B952C-CB62-5A90-A0D1-F85E4A936394}']
    function get_Hectopascals: Double; safecall;
    procedure put_Hectopascals(value: Double); safecall;
    property Hectopascals: Double read get_Hectopascals write put_Hectopascals;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometer3
  IBarometer3 = interface(IInspectable)
  ['{0E35F0EA-02B5-5A04-B03D-822084863A54}']
    function get_ReportThreshold: IBarometerDataThreshold; safecall;
    property ReportThreshold: IBarometerDataThreshold read get_ReportThreshold;
  end;

  // Windows.Devices.Sensors.IBarometerReading2
  IBarometerReading2 = interface(IInspectable)
  ['{85A244EB-90C5-4875-891C-3865B4C357E7}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Barometer)]
  IBarometerStatics = interface(IInspectable)
  ['{286B270A-02E3-4F86-84FC-FDD892B5940F}']
    function GetDefault: IBarometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Barometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IBarometer>
  AsyncOperationCompletedHandler_1__IBarometer = interface(IUnknown)
  ['{A15E21D6-5467-590C-AFE1-9C8132DCD8A4}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IBarometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Barometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IBarometer>
  IAsyncOperation_1__IBarometer = interface(IInspectable)
  ['{51876037-9F36-5C86-855D-3DDD251DF9A8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IBarometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IBarometer; safecall;
    function GetResults: IBarometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IBarometer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IBarometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Barometer)]
  IBarometerStatics2 = interface(IInspectable)
  ['{8FC6B1E7-95FF-44AC-878E-D65C8308C34C}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBarometer; safecall;
    function GetDeviceSelector: HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassReading
  ICompassReading = interface(IInspectable)
  ['{82911128-513D-4DC9-B781-5EEDFBF02D0C}']
    function get_Timestamp: DateTime; safecall;
    function get_HeadingMagneticNorth: Double; safecall;
    function get_HeadingTrueNorth: IReference_1__Double; safecall;
    property HeadingMagneticNorth: Double read get_HeadingMagneticNorth;
    property HeadingTrueNorth: IReference_1__Double read get_HeadingTrueNorth;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassReadingChangedEventArgs
  ICompassReadingChangedEventArgs = interface(IInspectable)
  ['{8F1549B0-E8BC-4C7E-B009-4E41DF137072}']
    function get_Reading: ICompassReading; safecall;
    property Reading: ICompassReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Compass,Windows.Devices.Sensors.CompassReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ICompass,Windows.Devices.Sensors.ICompassReadingChangedEventArgs>
  TypedEventHandler_2__ICompass__ICompassReadingChangedEventArgs = interface(IUnknown)
  ['{E787D73D-A121-5AE6-B497-AB934837E57F}']
    procedure Invoke(sender: ICompass; args: ICompassReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompass
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Compass)]
  ICompass = interface(IInspectable)
  ['{292FFA94-1B45-403C-BA06-B106DBA69A64}']
    function GetCurrentReading: ICompassReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__ICompass__ICompassReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompass2
  ICompass2 = interface(IInspectable)
  ['{36F26D09-C7D7-434F-B461-979DDFC2322F}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompass3
  ICompass3 = interface(IInspectable)
  ['{A424801B-C5EA-4D45-A0EC-4B791F041A89}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassDataThreshold
  ICompassDataThreshold = interface(IInspectable)
  ['{D15B52B3-D39D-5EC8-B2E4-F193E6AB34ED}']
    function get_Degrees: Double; safecall;
    procedure put_Degrees(value: Double); safecall;
    property Degrees: Double read get_Degrees write put_Degrees;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompass4
  ICompass4 = interface(IInspectable)
  ['{291E7F11-EC32-5DCC-BFCB-0BB39EBA5774}']
    function get_ReportThreshold: ICompassDataThreshold; safecall;
    property ReportThreshold: ICompassDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassDeviceId
  ICompassDeviceId = interface(IInspectable)
  ['{D181CA29-B085-4B1D-870A-4FF57BA74FD4}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.ICompassReading2
  ICompassReading2 = interface(IInspectable)
  ['{B13A661E-51BB-4A12-BEDD-AD47FF87D2E8}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Devices.Sensors.ICompassReadingHeadingAccuracy
  ICompassReadingHeadingAccuracy = interface(IInspectable)
  ['{E761354E-8911-40F7-9E16-6ECC7DAEC5DE}']
    function get_HeadingAccuracy: MagnetometerAccuracy; safecall;
    property HeadingAccuracy: MagnetometerAccuracy read get_HeadingAccuracy;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Compass)]
  ICompassStatics = interface(IInspectable)
  ['{9ABC97DF-56EC-4C25-B54D-40A68BB5B269}']
    function GetDefault: ICompass; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Compass>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ICompass>
  AsyncOperationCompletedHandler_1__ICompass = interface(IUnknown)
  ['{0CF1E460-BC2C-587C-9822-420BA04D0551}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ICompass; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Compass>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ICompass>
  IAsyncOperation_1__ICompass = interface(IInspectable)
  ['{5297C24C-A6FB-5E03-A4F8-EE143C435DF8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ICompass); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ICompass; safecall;
    function GetResults: ICompass; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ICompass read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ICompassStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Compass)]
  ICompassStatics2 = interface(IInspectable)
  ['{0ACE0EAD-3BAA-4990-9CE4-BE0913754ED2}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ICompass; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerReading
  IGyrometerReading = interface(IInspectable)
  ['{B3D6DE5C-1EE4-456F-9DE7-E2493B5C8E03}']
    function get_Timestamp: DateTime; safecall;
    function get_AngularVelocityX: Double; safecall;
    function get_AngularVelocityY: Double; safecall;
    function get_AngularVelocityZ: Double; safecall;
    property AngularVelocityX: Double read get_AngularVelocityX;
    property AngularVelocityY: Double read get_AngularVelocityY;
    property AngularVelocityZ: Double read get_AngularVelocityZ;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerReadingChangedEventArgs
  IGyrometerReadingChangedEventArgs = interface(IInspectable)
  ['{0FDF1895-6F9E-42CE-8D58-388C0AB8356D}']
    function get_Reading: IGyrometerReading; safecall;
    property Reading: IGyrometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Gyrometer,Windows.Devices.Sensors.GyrometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IGyrometer,Windows.Devices.Sensors.IGyrometerReadingChangedEventArgs>
  TypedEventHandler_2__IGyrometer__IGyrometerReadingChangedEventArgs = interface(IUnknown)
  ['{15171524-5786-59A5-AF5B-A01245726C44}']
    procedure Invoke(sender: IGyrometer; args: IGyrometerReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Gyrometer)]
  IGyrometer = interface(IInspectable)
  ['{FDB9A9C4-84B1-4CA2-9763-9B589506C70C}']
    function GetCurrentReading: IGyrometerReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IGyrometer__IGyrometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometer2
  IGyrometer2 = interface(IInspectable)
  ['{63DF2443-8CE8-41C3-AC44-8698810B557F}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometer3
  IGyrometer3 = interface(IInspectable)
  ['{5D6F88D5-8FBC-4484-914B-528ADFD947B1}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerDataThreshold
  IGyrometerDataThreshold = interface(IInspectable)
  ['{8648B31E-6E52-5259-BBAD-242A69DC38C8}']
    function get_XAxisInDegreesPerSecond: Double; safecall;
    procedure put_XAxisInDegreesPerSecond(value: Double); safecall;
    function get_YAxisInDegreesPerSecond: Double; safecall;
    procedure put_YAxisInDegreesPerSecond(value: Double); safecall;
    function get_ZAxisInDegreesPerSecond: Double; safecall;
    procedure put_ZAxisInDegreesPerSecond(value: Double); safecall;
    property XAxisInDegreesPerSecond: Double read get_XAxisInDegreesPerSecond write put_XAxisInDegreesPerSecond;
    property YAxisInDegreesPerSecond: Double read get_YAxisInDegreesPerSecond write put_YAxisInDegreesPerSecond;
    property ZAxisInDegreesPerSecond: Double read get_ZAxisInDegreesPerSecond write put_ZAxisInDegreesPerSecond;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometer4
  IGyrometer4 = interface(IInspectable)
  ['{0628A60C-4C4B-5096-94E6-C356DF68BEF7}']
    function get_ReportThreshold: IGyrometerDataThreshold; safecall;
    property ReportThreshold: IGyrometerDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerDeviceId
  IGyrometerDeviceId = interface(IInspectable)
  ['{1EE5E978-89A2-4275-9E95-7126F4708760}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.IGyrometerReading2
  IGyrometerReading2 = interface(IInspectable)
  ['{16AFE13C-2B89-44BB-822B-D1E1556FF09B}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Gyrometer)]
  IGyrometerStatics = interface(IInspectable)
  ['{83B6E7C9-E49D-4B39-86E6-CD554BE4C5C1}']
    function GetDefault: IGyrometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Gyrometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IGyrometer>
  AsyncOperationCompletedHandler_1__IGyrometer = interface(IUnknown)
  ['{15799501-958E-5315-A24A-0D7D7ACBC79C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IGyrometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Gyrometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IGyrometer>
  IAsyncOperation_1__IGyrometer = interface(IInspectable)
  ['{FCEE7ABF-1DCF-50CC-B91B-7A1F59E0C28B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IGyrometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IGyrometer; safecall;
    function GetResults: IGyrometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IGyrometer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IGyrometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Gyrometer)]
  IGyrometerStatics2 = interface(IInspectable)
  ['{EF83F7A1-D700-4204-9613-79C6B161DF4E}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IGyrometer; safecall;
  end;

  // Windows.Foundation.IReference`1<Windows.Devices.Sensors.HumanPresence>
  IReference_1__HumanPresence = interface(IInspectable)
  ['{BACD473D-348F-54D0-95C0-FFD5379F8B7F}']
    function get_Value: HumanPresence; safecall;
    property Value: HumanPresence read get_Value;
  end;

  // Windows.Foundation.IReference`1<Windows.Devices.Sensors.HumanEngagement>
  IReference_1__HumanEngagement = interface(IInspectable)
  ['{148ADF95-EB2C-5912-9C40-6DCEC31357BD}']
    function get_Value: HumanEngagement; safecall;
    property Value: HumanEngagement read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerReading
  IInclinometerReading = interface(IInspectable)
  ['{9F44F055-B6F6-497F-B127-1A775E501458}']
    function get_Timestamp: DateTime; safecall;
    function get_PitchDegrees: Single; safecall;
    function get_RollDegrees: Single; safecall;
    function get_YawDegrees: Single; safecall;
    property PitchDegrees: Single read get_PitchDegrees;
    property RollDegrees: Single read get_RollDegrees;
    property Timestamp: DateTime read get_Timestamp;
    property YawDegrees: Single read get_YawDegrees;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerReadingChangedEventArgs
  IInclinometerReadingChangedEventArgs = interface(IInspectable)
  ['{4AE91DC1-E7EB-4938-8511-AE0D6B440438}']
    function get_Reading: IInclinometerReading; safecall;
    property Reading: IInclinometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Inclinometer,Windows.Devices.Sensors.InclinometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IInclinometer,Windows.Devices.Sensors.IInclinometerReadingChangedEventArgs>
  TypedEventHandler_2__IInclinometer__IInclinometerReadingChangedEventArgs = interface(IUnknown)
  ['{6F3B411F-D147-59F1-BBE4-7BEC396C7B6E}']
    procedure Invoke(sender: IInclinometer; args: IInclinometerReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Inclinometer)]
  IInclinometer = interface(IInspectable)
  ['{2648CA6F-2286-406F-9161-F0C4BD806EBF}']
    function GetCurrentReading: IInclinometerReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IInclinometer__IInclinometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometer2
  IInclinometer2 = interface(IInspectable)
  ['{029F3393-28B2-45F8-BB16-61E86A7FAE6E}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    function get_ReadingType: SensorReadingType; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
    property ReadingType: SensorReadingType read get_ReadingType;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometer3
  IInclinometer3 = interface(IInspectable)
  ['{3A095004-D765-4384-A3D7-0283F3ABE6AE}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerDataThreshold
  IInclinometerDataThreshold = interface(IInspectable)
  ['{F80A4783-7BFE-545E-BB60-A0EBC47BD2FB}']
    function get_PitchInDegrees: Single; safecall;
    procedure put_PitchInDegrees(value: Single); safecall;
    function get_RollInDegrees: Single; safecall;
    procedure put_RollInDegrees(value: Single); safecall;
    function get_YawInDegrees: Single; safecall;
    procedure put_YawInDegrees(value: Single); safecall;
    property PitchInDegrees: Single read get_PitchInDegrees write put_PitchInDegrees;
    property RollInDegrees: Single read get_RollInDegrees write put_RollInDegrees;
    property YawInDegrees: Single read get_YawInDegrees write put_YawInDegrees;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometer4
  IInclinometer4 = interface(IInspectable)
  ['{43852618-8FCA-548E-BBF5-5C50412B6AA4}']
    function get_ReportThreshold: IInclinometerDataThreshold; safecall;
    property ReportThreshold: IInclinometerDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerDeviceId
  IInclinometerDeviceId = interface(IInspectable)
  ['{01E91982-41FF-4406-AE83-62210FF16FE3}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.IInclinometerReading2
  IInclinometerReading2 = interface(IInspectable)
  ['{4F164781-E90B-4658-8915-0103E08A805A}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Devices.Sensors.IInclinometerReadingYawAccuracy
  IInclinometerReadingYawAccuracy = interface(IInspectable)
  ['{B453E880-1FE3-4986-A257-E6ECE2723949}']
    function get_YawAccuracy: MagnetometerAccuracy; safecall;
    property YawAccuracy: MagnetometerAccuracy read get_YawAccuracy;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Inclinometer)]
  IInclinometerStatics = interface(IInspectable)
  ['{F22EC551-9C30-453A-8B49-3C3EEB33CB61}']
    function GetDefault: IInclinometer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Inclinometer)]
  IInclinometerStatics2 = interface(IInspectable)
  ['{043F9775-6A1E-499C-86E0-638C1A864B00}']
    function GetDefaultForRelativeReadings: IInclinometer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerStatics3
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Inclinometer)]
  IInclinometerStatics3 = interface(IInspectable)
  ['{BD9A4280-B91A-4829-9392-ABC0B6BDF2B4}']
    function GetDefault(sensorReadingtype: SensorReadingType): IInclinometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Inclinometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IInclinometer>
  AsyncOperationCompletedHandler_1__IInclinometer = interface(IUnknown)
  ['{8F0EDE2A-2D0F-55F6-9566-3C21385FAE64}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IInclinometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Inclinometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IInclinometer>
  IAsyncOperation_1__IInclinometer = interface(IInspectable)
  ['{84EBB496-B69A-53CD-B690-A46189822B01}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IInclinometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IInclinometer; safecall;
    function GetResults: IInclinometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IInclinometer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IInclinometerStatics4
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Inclinometer)]
  IInclinometerStatics4 = interface(IInspectable)
  ['{E8BA96F9-6E85-4A83-AED0-D7CDCC9856C8}']
    function GetDeviceSelector(readingType: SensorReadingType): HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IInclinometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorReading
  ILightSensorReading = interface(IInspectable)
  ['{FFDF6300-227C-4D2B-B302-FC0142485C68}']
    function get_Timestamp: DateTime; safecall;
    function get_IlluminanceInLux: Single; safecall;
    property IlluminanceInLux: Single read get_IlluminanceInLux;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorReadingChangedEventArgs
  ILightSensorReadingChangedEventArgs = interface(IInspectable)
  ['{A3A2F4CF-258B-420C-B8AB-8EDD601ECF50}']
    function get_Reading: ILightSensorReading; safecall;
    property Reading: ILightSensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.LightSensor,Windows.Devices.Sensors.LightSensorReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ILightSensor,Windows.Devices.Sensors.ILightSensorReadingChangedEventArgs>
  TypedEventHandler_2__ILightSensor__ILightSensorReadingChangedEventArgs = interface(IUnknown)
  ['{1ECF183A-9F0A-5F73-9225-5A33EAB5594F}']
    procedure Invoke(sender: ILightSensor; args: ILightSensorReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_LightSensor)]
  ILightSensor = interface(IInspectable)
  ['{F84C0718-0C54-47AE-922E-789F57FB03A0}']
    function GetCurrentReading: ILightSensorReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__ILightSensor__ILightSensorReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensor2
  ILightSensor2 = interface(IInspectable)
  ['{486B24E8-A94C-4090-8F48-09F782A9F7D5}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorDataThreshold
  ILightSensorDataThreshold = interface(IInspectable)
  ['{B160AFD1-878F-5492-9F2C-33DC3AE584A3}']
    function get_LuxPercentage: Single; safecall;
    procedure put_LuxPercentage(value: Single); safecall;
    function get_AbsoluteLux: Single; safecall;
    procedure put_AbsoluteLux(value: Single); safecall;
    property AbsoluteLux: Single read get_AbsoluteLux write put_AbsoluteLux;
    property LuxPercentage: Single read get_LuxPercentage write put_LuxPercentage;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensor3
  ILightSensor3 = interface(IInspectable)
  ['{4876D0FF-9F4C-5F72-ADBD-A3471B063C00}']
    function get_ReportThreshold: ILightSensorDataThreshold; safecall;
    property ReportThreshold: ILightSensorDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensor4
  ILightSensor4 = interface(IInspectable)
  ['{6167BE97-6390-404C-9C19-445311C6A1D3}']
    function IsChromaticitySupported: Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorDeviceId
  ILightSensorDeviceId = interface(IInspectable)
  ['{7FEE49F8-0AFB-4F51-87F0-6C26375CE94F}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.ILightSensorReading2
  ILightSensorReading2 = interface(IInspectable)
  ['{B7512185-44A3-44C9-8190-9EF6DE0A8A74}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Devices.Sensors.ILightSensorReading3
  ILightSensorReading3 = interface(IInspectable)
  ['{F338EE06-96AF-4029-B530-61ACC05B7CFE}']
    function get_Chromaticity: LightSensorChromaticity; safecall;
    property Chromaticity: LightSensorChromaticity read get_Chromaticity;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_LightSensor)]
  ILightSensorStatics = interface(IInspectable)
  ['{45DB8C84-C3A8-471E-9A53-6457FAD87C0E}']
    function GetDefault: ILightSensor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.LightSensor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ILightSensor>
  AsyncOperationCompletedHandler_1__ILightSensor = interface(IUnknown)
  ['{5D04E2BF-5163-5238-8F23-CE470B30340D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ILightSensor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.LightSensor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ILightSensor>
  IAsyncOperation_1__ILightSensor = interface(IInspectable)
  ['{380E592C-47A0-5DF4-8DE2-B2EEFA9DB8AD}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ILightSensor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ILightSensor; safecall;
    function GetResults: ILightSensor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ILightSensor read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ILightSensorStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_LightSensor)]
  ILightSensorStatics2 = interface(IInspectable)
  ['{0EC0A650-DDC6-40AB-ACE3-EC3359D42C51}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ILightSensor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerReading
  IMagnetometerReading = interface(IInspectable)
  ['{0C2CC40D-EBFD-4E5C-BB11-AFC29B3CAE61}']
    function get_Timestamp: DateTime; safecall;
    function get_MagneticFieldX: Single; safecall;
    function get_MagneticFieldY: Single; safecall;
    function get_MagneticFieldZ: Single; safecall;
    function get_DirectionalAccuracy: MagnetometerAccuracy; safecall;
    property DirectionalAccuracy: MagnetometerAccuracy read get_DirectionalAccuracy;
    property MagneticFieldX: Single read get_MagneticFieldX;
    property MagneticFieldY: Single read get_MagneticFieldY;
    property MagneticFieldZ: Single read get_MagneticFieldZ;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerReadingChangedEventArgs
  IMagnetometerReadingChangedEventArgs = interface(IInspectable)
  ['{17EAE872-2EB9-4EE7-8AD0-3127537D949B}']
    function get_Reading: IMagnetometerReading; safecall;
    property Reading: IMagnetometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Magnetometer,Windows.Devices.Sensors.MagnetometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IMagnetometer,Windows.Devices.Sensors.IMagnetometerReadingChangedEventArgs>
  TypedEventHandler_2__IMagnetometer__IMagnetometerReadingChangedEventArgs = interface(IUnknown)
  ['{F9A0DA76-C4FD-50AB-98B6-BFD26D6D3D82}']
    procedure Invoke(sender: IMagnetometer; args: IMagnetometerReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Magnetometer)]
  IMagnetometer = interface(IInspectable)
  ['{484F626E-D3C9-4111-B3F6-2CF1FAA418D5}']
    function GetCurrentReading: IMagnetometerReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IMagnetometer__IMagnetometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometer2
  IMagnetometer2 = interface(IInspectable)
  ['{B4656C85-26F6-444B-A9E2-A23F966CD368}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometer3
  IMagnetometer3 = interface(IInspectable)
  ['{BE93DB7C-A625-48EF-ACF7-FAC104832671}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerDataThreshold
  IMagnetometerDataThreshold = interface(IInspectable)
  ['{D177CB01-9063-5FA5-B596-B445E9DC3401}']
    function get_XAxisMicroteslas: Single; safecall;
    procedure put_XAxisMicroteslas(value: Single); safecall;
    function get_YAxisMicroteslas: Single; safecall;
    procedure put_YAxisMicroteslas(value: Single); safecall;
    function get_ZAxisMicroteslas: Single; safecall;
    procedure put_ZAxisMicroteslas(value: Single); safecall;
    property XAxisMicroteslas: Single read get_XAxisMicroteslas write put_XAxisMicroteslas;
    property YAxisMicroteslas: Single read get_YAxisMicroteslas write put_YAxisMicroteslas;
    property ZAxisMicroteslas: Single read get_ZAxisMicroteslas write put_ZAxisMicroteslas;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometer4
  IMagnetometer4 = interface(IInspectable)
  ['{DFB17901-3E0F-508F-B24B-F2BB75015F40}']
    function get_ReportThreshold: IMagnetometerDataThreshold; safecall;
    property ReportThreshold: IMagnetometerDataThreshold read get_ReportThreshold;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerDeviceId
  IMagnetometerDeviceId = interface(IInspectable)
  ['{58B498C2-7E4B-404C-9FC5-5DE8B40EBAE3}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.IMagnetometerReading2
  IMagnetometerReading2 = interface(IInspectable)
  ['{D4C95C61-61D9-404B-A328-066F177A1409}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Magnetometer)]
  IMagnetometerStatics = interface(IInspectable)
  ['{853C64CC-0698-4DDA-A6DF-9CB9CC4AB40A}']
    function GetDefault: IMagnetometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Magnetometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IMagnetometer>
  AsyncOperationCompletedHandler_1__IMagnetometer = interface(IUnknown)
  ['{46E0A768-9645-51A6-B6A7-1E5F4B40E1F3}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMagnetometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Magnetometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IMagnetometer>
  IAsyncOperation_1__IMagnetometer = interface(IInspectable)
  ['{B0455443-E790-5AA3-8767-4932032274EE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMagnetometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMagnetometer; safecall;
    function GetResults: IMagnetometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMagnetometer read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IMagnetometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Magnetometer)]
  IMagnetometerStatics2 = interface(IInspectable)
  ['{2C0819F0-FFC6-4F89-A06F-18FA10792933}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IMagnetometer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ISensorRotationMatrix
  ISensorRotationMatrix = interface(IInspectable)
  ['{0A3D5A67-22F4-4392-9538-65D0BD064AA6}']
    function get_M11: Single; safecall;
    function get_M12: Single; safecall;
    function get_M13: Single; safecall;
    function get_M21: Single; safecall;
    function get_M22: Single; safecall;
    function get_M23: Single; safecall;
    function get_M31: Single; safecall;
    function get_M32: Single; safecall;
    function get_M33: Single; safecall;
    property M11: Single read get_M11;
    property M12: Single read get_M12;
    property M13: Single read get_M13;
    property M21: Single read get_M21;
    property M22: Single read get_M22;
    property M23: Single read get_M23;
    property M31: Single read get_M31;
    property M32: Single read get_M32;
    property M33: Single read get_M33;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ISensorQuaternion
  ISensorQuaternion = interface(IInspectable)
  ['{C9C5C827-C71C-46E7-9DA3-36A193B232BC}']
    function get_W: Single; safecall;
    function get_X: Single; safecall;
    function get_Y: Single; safecall;
    function get_Z: Single; safecall;
    property W: Single read get_W;
    property X: Single read get_X;
    property Y: Single read get_Y;
    property Z: Single read get_Z;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorReading
  IOrientationSensorReading = interface(IInspectable)
  ['{4756C993-6595-4897-BCC6-D537EE757564}']
    function get_Timestamp: DateTime; safecall;
    function get_RotationMatrix: ISensorRotationMatrix; safecall;
    function get_Quaternion: ISensorQuaternion; safecall;
    property Quaternion: ISensorQuaternion read get_Quaternion;
    property RotationMatrix: ISensorRotationMatrix read get_RotationMatrix;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorReadingChangedEventArgs
  IOrientationSensorReadingChangedEventArgs = interface(IInspectable)
  ['{012C1186-C3BA-46BC-AE65-7A98996CBFB8}']
    function get_Reading: IOrientationSensorReading; safecall;
    property Reading: IOrientationSensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.OrientationSensor,Windows.Devices.Sensors.OrientationSensorReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IOrientationSensor,Windows.Devices.Sensors.IOrientationSensorReadingChangedEventArgs>
  TypedEventHandler_2__IOrientationSensor__IOrientationSensorReadingChangedEventArgs = interface(IUnknown)
  ['{91AE0C43-E1F7-577D-A161-8AAF275EB927}']
    procedure Invoke(sender: IOrientationSensor; args: IOrientationSensorReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_OrientationSensor)]
  IOrientationSensor = interface(IInspectable)
  ['{5E354635-CF6B-4C63-ABD8-10252B0BF6EC}']
    function GetCurrentReading: IOrientationSensorReading; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IOrientationSensor__IOrientationSensorReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensor2
  IOrientationSensor2 = interface(IInspectable)
  ['{0D924CF9-2F1F-49C9-8042-4A1813D67760}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    function get_ReadingType: SensorReadingType; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
    property ReadingType: SensorReadingType read get_ReadingType;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensor3
  IOrientationSensor3 = interface(IInspectable)
  ['{2CCE578D-646B-48C5-B7EE-44FDC4C6AAFD}']
    procedure put_ReportLatency(value: Cardinal); safecall;
    function get_ReportLatency: Cardinal; safecall;
    function get_MaxBatchSize: Cardinal; safecall;
    property MaxBatchSize: Cardinal read get_MaxBatchSize;
    property ReportLatency: Cardinal read get_ReportLatency write put_ReportLatency;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorDeviceId
  IOrientationSensorDeviceId = interface(IInspectable)
  ['{5A69B648-4C29-49EC-B28F-EA1D117B66F0}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // Windows.Devices.Sensors.IOrientationSensorReading2
  IOrientationSensorReading2 = interface(IInspectable)
  ['{00576E5F-49F8-4C05-9E07-24FAC79408C3}']
    function get_PerformanceCount: IReference_1__TimeSpan; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property PerformanceCount: IReference_1__TimeSpan read get_PerformanceCount;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
  end;

  // Windows.Devices.Sensors.IOrientationSensorReadingYawAccuracy
  IOrientationSensorReadingYawAccuracy = interface(IInspectable)
  ['{D1AC9824-3F5A-49A2-BC7B-1180BC38CD2B}']
    function get_YawAccuracy: MagnetometerAccuracy; safecall;
    property YawAccuracy: MagnetometerAccuracy read get_YawAccuracy;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_OrientationSensor)]
  IOrientationSensorStatics = interface(IInspectable)
  ['{10EF8712-FB4C-428A-898B-2765E409E669}']
    function GetDefault: IOrientationSensor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_OrientationSensor)]
  IOrientationSensorStatics2 = interface(IInspectable)
  ['{59DA0D0B-D40A-4C71-9276-8A272A0A6619}']
    function GetDefaultForRelativeReadings: IOrientationSensor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorStatics3
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_OrientationSensor)]
  IOrientationSensorStatics3 = interface(IInspectable)
  ['{D82CE920-2777-40FF-9F59-D654B085F12F}']
    function GetDefault(sensorReadingtype: SensorReadingType): IOrientationSensor; overload; safecall;
    function GetDefault(sensorReadingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): IOrientationSensor; overload; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.OrientationSensor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IOrientationSensor>
  AsyncOperationCompletedHandler_1__IOrientationSensor = interface(IUnknown)
  ['{8330B323-6695-53D4-ACD7-B60C24C1B879}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IOrientationSensor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.OrientationSensor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IOrientationSensor>
  IAsyncOperation_1__IOrientationSensor = interface(IInspectable)
  ['{8EF36AA8-6F6D-538B-A42B-37AF7369049E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IOrientationSensor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IOrientationSensor; safecall;
    function GetResults: IOrientationSensor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IOrientationSensor read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IOrientationSensorStatics4
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_OrientationSensor)]
  IOrientationSensorStatics4 = interface(IInspectable)
  ['{A67FEB55-2C85-4B28-A0FE-58C4B20495F5}']
    function GetDeviceSelector(readingType: SensorReadingType): HSTRING; overload; safecall;
    function GetDeviceSelector(readingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): HSTRING; overload; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IOrientationSensor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometerReading
  IPedometerReading = interface(IInspectable)
  ['{2245DCF4-A8E1-432F-896A-BE0DD9B02D24}']
    function get_StepKind: PedometerStepKind; safecall;
    function get_CumulativeSteps: Integer; safecall;
    function get_Timestamp: DateTime; safecall;
    function get_CumulativeStepsDuration: TimeSpan; safecall;
    property CumulativeSteps: Integer read get_CumulativeSteps;
    property CumulativeStepsDuration: TimeSpan read get_CumulativeStepsDuration;
    property StepKind: PedometerStepKind read get_StepKind;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometerReadingChangedEventArgs
  IPedometerReadingChangedEventArgs = interface(IInspectable)
  ['{F855E47E-ABBC-4456-86A8-25CF2B333742}']
    function get_Reading: IPedometerReading; safecall;
    property Reading: IPedometerReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.Pedometer,Windows.Devices.Sensors.PedometerReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IPedometer,Windows.Devices.Sensors.IPedometerReadingChangedEventArgs>
  TypedEventHandler_2__IPedometer__IPedometerReadingChangedEventArgs = interface(IUnknown)
  ['{DCD47693-AAD5-5B3C-9C8D-140B8BC2122B}']
    procedure Invoke(sender: IPedometer; args: IPedometerReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometer
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Pedometer)]
  IPedometer = interface(IInspectable)
  ['{9A1E013D-3D98-45F8-8920-8E4ECACA5F97}']
    function get_DeviceId: HSTRING; safecall;
    function get_PowerInMilliwatts: Double; safecall;
    function get_MinimumReportInterval: Cardinal; safecall;
    procedure put_ReportInterval(value: Cardinal); safecall;
    function get_ReportInterval: Cardinal; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IPedometer__IPedometerReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MinimumReportInterval: Cardinal read get_MinimumReportInterval;
    property PowerInMilliwatts: Double read get_PowerInMilliwatts;
    property ReportInterval: Cardinal read get_ReportInterval write put_ReportInterval;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>
  IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface(IInspectable)
  ['{72A1E31B-91B2-5CE6-AB2C-BF77B78BA1B1}']
    function get_Key: PedometerStepKind; safecall;
    function get_Value: IPedometerReading; safecall;
    property Key: PedometerStepKind read get_Key;
    property Value: IPedometerReading read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.PedometerReading>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>>
  IIterator_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface(IInspectable)
  ['{3E88FE66-D4A7-5658-B5CF-1A39E1FC4165}']
    function get_Current: IKeyValuePair_2__PedometerStepKind__IPedometerReading; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__PedometerStepKind__IPedometerReading): Cardinal; safecall;
    property Current: IKeyValuePair_2__PedometerStepKind__IPedometerReading read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.PedometerReading>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>>
  IIterable_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading = interface(IInspectable)
  ['{098F29CB-BC91-5639-A541-D5A4811EC35B}']
    function First: IIterator_1__IKeyValuePair_2__PedometerStepKind__IPedometerReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.PedometerReading>
  // Windows.Foundation.Collections.IMapView`2<Windows.Devices.Sensors.PedometerStepKind,Windows.Devices.Sensors.IPedometerReading>
  IMapView_2__PedometerStepKind__IPedometerReading = interface(IInspectable)
  ['{64F0C54C-4865-56BD-AC98-64A98451E362}']
    function Lookup(key: PedometerStepKind): IPedometerReading; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: PedometerStepKind): Boolean; safecall;
    procedure Split(out first: IMapView_2__PedometerStepKind__IPedometerReading; out second: IMapView_2__PedometerStepKind__IPedometerReading); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometer2
  IPedometer2 = interface(IInspectable)
  ['{E5A406DF-2B81-4ADD-B2FF-77AB6C98BA19}']
    function GetCurrentReadings: IMapView_2__PedometerStepKind__IPedometerReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.Pedometer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.IPedometer>
  AsyncOperationCompletedHandler_1__IPedometer = interface(IUnknown)
  ['{A62DBE4E-51DE-5A13-BA21-E76DF3BC1396}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IPedometer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.Pedometer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.IPedometer>
  IAsyncOperation_1__IPedometer = interface(IInspectable)
  ['{9414388F-1B3E-55F5-819B-AB3833646055}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IPedometer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IPedometer; safecall;
    function GetResults: IPedometer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IPedometer read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.PedometerReading>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IPedometerReading>
  IIterator_1__IPedometerReading = interface(IInspectable)
  ['{0AC70ED3-8553-5EF3-92F8-438609623087}']
    function get_Current: IPedometerReading; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIPedometerReading): Cardinal; safecall;
    property Current: IPedometerReading read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.PedometerReading>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IPedometerReading>
  IIterable_1__IPedometerReading = interface(IInspectable)
  ['{BBB61A5C-98C3-5718-88FE-5392A7451E2D}']
    function First: IIterator_1__IPedometerReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>
  IVectorView_1__IPedometerReading = interface(IInspectable)
  ['{44BEB693-AA66-5003-886B-1BF273FA5750}']
    function GetAt(index: Cardinal): IPedometerReading; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IPedometerReading; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIPedometerReading): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.PedometerReading>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading = interface(IUnknown)
  ['{5BBFF840-59F2-5108-9205-A0BBF8F9BA68}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IPedometerReading; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.PedometerReading>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IPedometerReading>>
  IAsyncOperation_1__IVectorView_1__IPedometerReading = interface(IInspectable)
  ['{2AEAC503-A3A8-57B3-A8A9-E16B0CD4C0A4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading; safecall;
    function GetResults: IVectorView_1__IPedometerReading; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IPedometerReading read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Pedometer)]
  IPedometerStatics = interface(IInspectable)
  ['{82980A2F-4083-4DFB-B411-938EA0F4B946}']
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IPedometer; safecall;
    function GetDefaultAsync: IAsyncOperation_1__IPedometer; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    function GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IPedometerReading; overload; safecall;
    function GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IPedometerReading; overload; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ISensorDataThresholdTriggerDetails
  ISensorDataThresholdTriggerDetails = interface(IInspectable)
  ['{9106F1B7-E88D-48B1-BC90-619C7B349391}']
    function get_DeviceId: HSTRING; safecall;
    function get_SensorType: SensorType; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property SensorType_: SensorType read get_SensorType;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IPedometerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_Pedometer)]
  IPedometerStatics2 = interface(IInspectable)
  ['{79F5C6BB-CE0E-4133-B47E-8627EA72F677}']
    function GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IPedometerReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IProximitySensorReading
  IProximitySensorReading = interface(IInspectable)
  ['{71228D59-132D-4D5F-8FF9-2F0DB8751CED}']
    function get_Timestamp: DateTime; safecall;
    function get_IsDetected: Boolean; safecall;
    function get_DistanceInMillimeters: IReference_1__Cardinal; safecall;
    property DistanceInMillimeters: IReference_1__Cardinal read get_DistanceInMillimeters;
    property IsDetected: Boolean read get_IsDetected;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.IProximitySensorReadingChangedEventArgs
  IProximitySensorReadingChangedEventArgs = interface(IInspectable)
  ['{CFC2F366-C3E8-40FD-8CC3-67E289004938}']
    function get_Reading: IProximitySensorReading; safecall;
    property Reading: IProximitySensorReading read get_Reading;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ProximitySensor,Windows.Devices.Sensors.ProximitySensorReadingChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.IProximitySensor,Windows.Devices.Sensors.IProximitySensorReadingChangedEventArgs>
  TypedEventHandler_2__IProximitySensor__IProximitySensorReadingChangedEventArgs = interface(IUnknown)
  ['{9F7E222B-892A-5E68-B08A-10384B5F92B9}']
    procedure Invoke(sender: IProximitySensor; args: IProximitySensorReadingChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IProximitySensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_ProximitySensor)]
  IProximitySensor = interface(IInspectable)
  ['{54C076B8-ECFB-4944-B928-74FC504D47EE}']
    function get_DeviceId: HSTRING; safecall;
    function get_MaxDistanceInMillimeters: IReference_1__Cardinal; safecall;
    function get_MinDistanceInMillimeters: IReference_1__Cardinal; safecall;
    function GetCurrentReading: IProximitySensorReading; safecall;
    function add_ReadingChanged(handler: TypedEventHandler_2__IProximitySensor__IProximitySensorReadingChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ReadingChanged(token: EventRegistrationToken); safecall;
    function CreateDisplayOnOffController: IClosable; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property MaxDistanceInMillimeters: IReference_1__Cardinal read get_MaxDistanceInMillimeters;
    property MinDistanceInMillimeters: IReference_1__Cardinal read get_MinDistanceInMillimeters;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IProximitySensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_ProximitySensor)]
  IProximitySensorStatics = interface(IInspectable)
  ['{29186649-6269-4E57-A5AD-82BE80813392}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromId(sensorId: HSTRING): IProximitySensor; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.ProximitySensorReading>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Sensors.IProximitySensorReading>
  IIterator_1__IProximitySensorReading = interface(IInspectable)
  ['{1D4F08DF-7F49-573B-936A-6D4D4E610930}']
    function get_Current: IProximitySensorReading; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIProximitySensorReading): Cardinal; safecall;
    property Current: IProximitySensorReading read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.ProximitySensorReading>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Sensors.IProximitySensorReading>
  IIterable_1__IProximitySensorReading = interface(IInspectable)
  ['{301EBCCF-11AB-5E90-98EE-BD99C0E3BB76}']
    function First: IIterator_1__IProximitySensorReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Sensors.IProximitySensorReading>
  IVectorView_1__IProximitySensorReading = interface(IInspectable)
  ['{E94032E2-CD06-511E-BC3C-5C4750E39FC9}']
    function GetAt(index: Cardinal): IProximitySensorReading; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IProximitySensorReading; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIProximitySensorReading): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.IProximitySensorStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_ProximitySensor)]
  IProximitySensorStatics2 = interface(IInspectable)
  ['{CBF473AE-E9CA-422F-AD67-4C3D25DF350C}']
    function GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IProximitySensorReading; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensorOrientationChangedEventArgs
  ISimpleOrientationSensorOrientationChangedEventArgs = interface(IInspectable)
  ['{BCD5C660-23D4-4B4C-A22E-BA81ADE0C601}']
    function get_Timestamp: DateTime; safecall;
    function get_Orientation: SimpleOrientation; safecall;
    property Orientation: SimpleOrientation read get_Orientation;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.SimpleOrientationSensor,Windows.Devices.Sensors.SimpleOrientationSensorOrientationChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Sensors.ISimpleOrientationSensor,Windows.Devices.Sensors.ISimpleOrientationSensorOrientationChangedEventArgs>
  TypedEventHandler_2__ISimpleOrientationSensor__ISimpleOrientationSensorOrientationChangedEventArgs = interface(IUnknown)
  ['{92437FA7-EA7B-5FC5-8ECF-1B911BEA2BFC}']
    procedure Invoke(sender: ISimpleOrientationSensor; args: ISimpleOrientationSensorOrientationChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensor
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_SimpleOrientationSensor)]
  ISimpleOrientationSensor = interface(IInspectable)
  ['{5FF53856-214A-4DEE-A3F9-616F1AB06FFD}']
    function GetCurrentOrientation: SimpleOrientation; safecall;
    function add_OrientationChanged(handler: TypedEventHandler_2__ISimpleOrientationSensor__ISimpleOrientationSensorOrientationChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_OrientationChanged(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensor2
  ISimpleOrientationSensor2 = interface(IInspectable)
  ['{A277A798-8870-453E-8BD6-B8F5D8D7941B}']
    procedure put_ReadingTransform(value: Display_DisplayOrientations); safecall;
    function get_ReadingTransform: Display_DisplayOrientations; safecall;
    property ReadingTransform: Display_DisplayOrientations read get_ReadingTransform write put_ReadingTransform;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensorDeviceId
  ISimpleOrientationSensorDeviceId = interface(IInspectable)
  ['{FBC00ACB-3B76-41F6-8091-30EFE646D3CF}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_SimpleOrientationSensor)]
  ISimpleOrientationSensorStatics = interface(IInspectable)
  ['{72ED066F-70AA-40C6-9B1B-3433F7459B4E}']
    function GetDefault: ISimpleOrientationSensor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.SimpleOrientationSensor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Sensors.ISimpleOrientationSensor>
  AsyncOperationCompletedHandler_1__ISimpleOrientationSensor = interface(IUnknown)
  ['{69BE8A44-2CCB-5375-A8F8-F894EFBA33EB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__ISimpleOrientationSensor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.SimpleOrientationSensor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Sensors.ISimpleOrientationSensor>
  IAsyncOperation_1__ISimpleOrientationSensor = interface(IInspectable)
  ['{6B77C9F9-DCF7-5647-ADC7-F70CF9927044}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__ISimpleOrientationSensor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__ISimpleOrientationSensor; safecall;
    function GetResults: ISimpleOrientationSensor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__ISimpleOrientationSensor read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Sensors.ISimpleOrientationSensorStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Sensors_SimpleOrientationSensor)]
  ISimpleOrientationSensorStatics2 = interface(IInspectable)
  ['{848F9C7F-B138-4E11-8910-A2A2A3B56D83}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ISimpleOrientationSensor; safecall;
  end;

  // Windows.Devices.Sensors.Accelerometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IAccelerometer
  // Implements: Windows.Devices.Sensors.IAccelerometerDeviceId
  // Implements: Windows.Devices.Sensors.IAccelerometer2
  // Implements: Windows.Devices.Sensors.IAccelerometer3
  // Implements: Windows.Devices.Sensors.IAccelerometer4
  // Implements: Windows.Devices.Sensors.IAccelerometer5
  // Statics: "Windows.Devices.Sensors.IAccelerometerStatics"
  // Statics: "Windows.Devices.Sensors.IAccelerometerStatics2"
  // Statics: "Windows.Devices.Sensors.IAccelerometerStatics3"
  TAccelerometer = class(TWinRTGenericImportS3<IAccelerometerStatics, IAccelerometerStatics2, IAccelerometerStatics3>)
  public
    {$REGION 'IAccelerometerStatics'}
    class function GetDefault: IAccelerometer; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IAccelerometerStatics2'}
    class function GetDefault(readingType: AccelerometerReadingType): IAccelerometer; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IAccelerometerStatics3'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IAccelerometer; static; inline;
    class function GetDeviceSelector(readingType: AccelerometerReadingType): HSTRING; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.ActivitySensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.IActivitySensor
  // Statics: "Windows.Devices.Sensors.IActivitySensorStatics"
  TActivitySensor = class(TWinRTGenericImportS<IActivitySensorStatics>)
  public
    {$REGION 'IActivitySensorStatics'}
    class function GetDefaultAsync: IAsyncOperation_1__IActivitySensor; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IActivitySensor; static; inline;
    class function GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IActivitySensorReading; overload; static; inline;
    class function GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IActivitySensorReading; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Altimeter
  // DualAPI
  // Implements: Windows.Devices.Sensors.IAltimeter
  // Implements: Windows.Devices.Sensors.IAltimeter2
  // Statics: "Windows.Devices.Sensors.IAltimeterStatics"
  TAltimeter = class(TWinRTGenericImportS<IAltimeterStatics>)
  public
    {$REGION 'IAltimeterStatics'}
    class function GetDefault: IAltimeter; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Barometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IBarometer
  // Implements: Windows.Devices.Sensors.IBarometer2
  // Implements: Windows.Devices.Sensors.IBarometer3
  // Statics: "Windows.Devices.Sensors.IBarometerStatics"
  // Statics: "Windows.Devices.Sensors.IBarometerStatics2"
  TBarometer = class(TWinRTGenericImportS2<IBarometerStatics, IBarometerStatics2>)
  public
    {$REGION 'IBarometerStatics'}
    class function GetDefault: IBarometer; static; inline;
    {$ENDREGION}
    {$REGION 'IBarometerStatics2'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBarometer; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Compass
  // DualAPI
  // Implements: Windows.Devices.Sensors.ICompass
  // Implements: Windows.Devices.Sensors.ICompassDeviceId
  // Implements: Windows.Devices.Sensors.ICompass2
  // Implements: Windows.Devices.Sensors.ICompass3
  // Implements: Windows.Devices.Sensors.ICompass4
  // Statics: "Windows.Devices.Sensors.ICompassStatics"
  // Statics: "Windows.Devices.Sensors.ICompassStatics2"
  TCompass = class(TWinRTGenericImportS2<ICompassStatics, ICompassStatics2>)
  public
    {$REGION 'ICompassStatics'}
    class function GetDefault: ICompass; static; inline;
    {$ENDREGION}
    {$REGION 'ICompassStatics2'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ICompass; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Custom.CustomSensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.Custom.ICustomSensor
  // Implements: Windows.Devices.Sensors.Custom.ICustomSensor2
  // Statics: "Windows.Devices.Sensors.Custom.ICustomSensorStatics"
  TCustom_CustomSensor = class(TWinRTGenericImportS<Custom_ICustomSensorStatics>)
  public
    {$REGION 'Custom_ICustomSensorStatics'}
    class function GetDeviceSelector(interfaceId: TGuid): HSTRING; static; inline;
    class function FromIdAsync(sensorId: HSTRING): IAsyncOperation_1__Custom_ICustomSensor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Gyrometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IGyrometer
  // Implements: Windows.Devices.Sensors.IGyrometerDeviceId
  // Implements: Windows.Devices.Sensors.IGyrometer2
  // Implements: Windows.Devices.Sensors.IGyrometer3
  // Implements: Windows.Devices.Sensors.IGyrometer4
  // Statics: "Windows.Devices.Sensors.IGyrometerStatics"
  // Statics: "Windows.Devices.Sensors.IGyrometerStatics2"
  TGyrometer = class(TWinRTGenericImportS2<IGyrometerStatics, IGyrometerStatics2>)
  public
    {$REGION 'IGyrometerStatics'}
    class function GetDefault: IGyrometer; static; inline;
    {$ENDREGION}
    {$REGION 'IGyrometerStatics2'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IGyrometer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Inclinometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IInclinometer
  // Implements: Windows.Devices.Sensors.IInclinometerDeviceId
  // Implements: Windows.Devices.Sensors.IInclinometer2
  // Implements: Windows.Devices.Sensors.IInclinometer3
  // Implements: Windows.Devices.Sensors.IInclinometer4
  // Statics: "Windows.Devices.Sensors.IInclinometerStatics"
  // Statics: "Windows.Devices.Sensors.IInclinometerStatics2"
  // Statics: "Windows.Devices.Sensors.IInclinometerStatics3"
  // Statics: "Windows.Devices.Sensors.IInclinometerStatics4"
  TInclinometer = class(TWinRTGenericImportS4<IInclinometerStatics, IInclinometerStatics2, IInclinometerStatics3, IInclinometerStatics4>)
  public
    {$REGION 'IInclinometerStatics'}
    class function GetDefault: IInclinometer; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IInclinometerStatics2'}
    class function GetDefaultForRelativeReadings: IInclinometer; static; inline;
    {$ENDREGION}
    {$REGION 'IInclinometerStatics3'}
    class function GetDefault(sensorReadingtype: SensorReadingType): IInclinometer; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IInclinometerStatics4'}
    class function GetDeviceSelector(readingType: SensorReadingType): HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IInclinometer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.LightSensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.ILightSensor
  // Implements: Windows.Devices.Sensors.ILightSensorDeviceId
  // Implements: Windows.Devices.Sensors.ILightSensor2
  // Implements: Windows.Devices.Sensors.ILightSensor3
  // Implements: Windows.Devices.Sensors.ILightSensor4
  // Statics: "Windows.Devices.Sensors.ILightSensorStatics"
  // Statics: "Windows.Devices.Sensors.ILightSensorStatics2"
  TLightSensor = class(TWinRTGenericImportS2<ILightSensorStatics, ILightSensorStatics2>)
  public
    {$REGION 'ILightSensorStatics'}
    class function GetDefault: ILightSensor; static; inline;
    {$ENDREGION}
    {$REGION 'ILightSensorStatics2'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ILightSensor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Magnetometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IMagnetometer
  // Implements: Windows.Devices.Sensors.IMagnetometerDeviceId
  // Implements: Windows.Devices.Sensors.IMagnetometer2
  // Implements: Windows.Devices.Sensors.IMagnetometer3
  // Implements: Windows.Devices.Sensors.IMagnetometer4
  // Statics: "Windows.Devices.Sensors.IMagnetometerStatics"
  // Statics: "Windows.Devices.Sensors.IMagnetometerStatics2"
  TMagnetometer = class(TWinRTGenericImportS2<IMagnetometerStatics, IMagnetometerStatics2>)
  public
    {$REGION 'IMagnetometerStatics'}
    class function GetDefault: IMagnetometer; static; inline;
    {$ENDREGION}
    {$REGION 'IMagnetometerStatics2'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IMagnetometer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.OrientationSensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.IOrientationSensor
  // Implements: Windows.Devices.Sensors.IOrientationSensorDeviceId
  // Implements: Windows.Devices.Sensors.IOrientationSensor2
  // Implements: Windows.Devices.Sensors.IOrientationSensor3
  // Statics: "Windows.Devices.Sensors.IOrientationSensorStatics"
  // Statics: "Windows.Devices.Sensors.IOrientationSensorStatics2"
  // Statics: "Windows.Devices.Sensors.IOrientationSensorStatics3"
  // Statics: "Windows.Devices.Sensors.IOrientationSensorStatics4"
  TOrientationSensor = class(TWinRTGenericImportS4<IOrientationSensorStatics, IOrientationSensorStatics2, IOrientationSensorStatics3, IOrientationSensorStatics4>)
  public
    {$REGION 'IOrientationSensorStatics'}
    class function GetDefault: IOrientationSensor; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IOrientationSensorStatics2'}
    class function GetDefaultForRelativeReadings: IOrientationSensor; static; inline;
    {$ENDREGION}
    {$REGION 'IOrientationSensorStatics3'}
    class function GetDefault(sensorReadingtype: SensorReadingType): IOrientationSensor; overload; static; inline;
    class function GetDefault(sensorReadingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): IOrientationSensor; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IOrientationSensorStatics4'}
    class function GetDeviceSelector(readingType: SensorReadingType): HSTRING; overload; static; inline;
    class function GetDeviceSelector(readingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IOrientationSensor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.Pedometer
  // DualAPI
  // Implements: Windows.Devices.Sensors.IPedometer
  // Implements: Windows.Devices.Sensors.IPedometer2
  // Statics: "Windows.Devices.Sensors.IPedometerStatics"
  // Statics: "Windows.Devices.Sensors.IPedometerStatics2"
  TPedometer = class(TWinRTGenericImportS2<IPedometerStatics, IPedometerStatics2>)
  public
    {$REGION 'IPedometerStatics'}
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IPedometer; static; inline;
    class function GetDefaultAsync: IAsyncOperation_1__IPedometer; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class function GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IPedometerReading; overload; static; inline;
    class function GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IPedometerReading; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IPedometerStatics2'}
    class function GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IPedometerReading; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.ProximitySensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.IProximitySensor
  // Statics: "Windows.Devices.Sensors.IProximitySensorStatics"
  // Statics: "Windows.Devices.Sensors.IProximitySensorStatics2"
  TProximitySensor = class(TWinRTGenericImportS2<IProximitySensorStatics, IProximitySensorStatics2>)
  public
    {$REGION 'IProximitySensorStatics'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromId(sensorId: HSTRING): IProximitySensor; static; inline;
    {$ENDREGION}
    {$REGION 'IProximitySensorStatics2'}
    class function GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IProximitySensorReading; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Sensors.SimpleOrientationSensor
  // DualAPI
  // Implements: Windows.Devices.Sensors.ISimpleOrientationSensor
  // Implements: Windows.Devices.Sensors.ISimpleOrientationSensorDeviceId
  // Implements: Windows.Devices.Sensors.ISimpleOrientationSensor2
  // Statics: "Windows.Devices.Sensors.ISimpleOrientationSensorStatics"
  // Statics: "Windows.Devices.Sensors.ISimpleOrientationSensorStatics2"
  TSimpleOrientationSensor = class(TWinRTGenericImportS2<ISimpleOrientationSensorStatics, ISimpleOrientationSensorStatics2>)
  public
    {$REGION 'ISimpleOrientationSensorStatics'}
    class function GetDefault: ISimpleOrientationSensor; static; inline;
    {$ENDREGION}
    {$REGION 'ISimpleOrientationSensorStatics2'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ISimpleOrientationSensor; static; inline;
    {$ENDREGION}
 end;

implementation

{ TAccelerometer }

{$REGION 'Windows.Devices.Sensors.IAccelerometerStatics'}
class function TAccelerometer.GetDefault: IAccelerometer;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IAccelerometerStatics2'}
class function TAccelerometer.GetDefault(readingType: AccelerometerReadingType): IAccelerometer;
begin
  Result := Statics2.GetDefault(readingType);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IAccelerometerStatics3'}
class function TAccelerometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IAccelerometer;
begin
  Result := Statics3.FromIdAsync(deviceId);
end;

class function TAccelerometer.GetDeviceSelector(readingType: AccelerometerReadingType): HSTRING;
begin
  Result := Statics3.GetDeviceSelector(readingType);
end;
{$ENDREGION}

{ TActivitySensor }

{$REGION 'Windows.Devices.Sensors.IActivitySensorStatics'}
class function TActivitySensor.GetDefaultAsync: IAsyncOperation_1__IActivitySensor;
begin
  Result := Statics.GetDefaultAsync;
end;

class function TActivitySensor.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TActivitySensor.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IActivitySensor;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TActivitySensor.GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IActivitySensorReading;
begin
  Result := Statics.GetSystemHistoryAsync(fromTime);
end;

class function TActivitySensor.GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IActivitySensorReading;
begin
  Result := Statics.GetSystemHistoryAsync(fromTime, duration);
end;
{$ENDREGION}

{ TAltimeter }

{$REGION 'Windows.Devices.Sensors.IAltimeterStatics'}
class function TAltimeter.GetDefault: IAltimeter;
begin
  Result := Statics.GetDefault;
end;
{$ENDREGION}

{ TBarometer }

{$REGION 'Windows.Devices.Sensors.IBarometerStatics'}
class function TBarometer.GetDefault: IBarometer;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IBarometerStatics2'}
class function TBarometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IBarometer;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;

class function TBarometer.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;
{$ENDREGION}

{ TCompass }

{$REGION 'Windows.Devices.Sensors.ICompassStatics'}
class function TCompass.GetDefault: ICompass;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.ICompassStatics2'}
class function TCompass.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;

class function TCompass.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ICompass;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TCustom_CustomSensor }

{$REGION 'Windows.Devices.Sensors.Custom.ICustomSensorStatics'}
class function TCustom_CustomSensor.GetDeviceSelector(interfaceId: TGuid): HSTRING;
begin
  Result := Statics.GetDeviceSelector(interfaceId);
end;

class function TCustom_CustomSensor.FromIdAsync(sensorId: HSTRING): IAsyncOperation_1__Custom_ICustomSensor;
begin
  Result := Statics.FromIdAsync(sensorId);
end;
{$ENDREGION}

{ TGyrometer }

{$REGION 'Windows.Devices.Sensors.IGyrometerStatics'}
class function TGyrometer.GetDefault: IGyrometer;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IGyrometerStatics2'}
class function TGyrometer.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;

class function TGyrometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IGyrometer;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TInclinometer }

{$REGION 'Windows.Devices.Sensors.IInclinometerStatics'}
class function TInclinometer.GetDefault: IInclinometer;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IInclinometerStatics2'}
class function TInclinometer.GetDefaultForRelativeReadings: IInclinometer;
begin
  Result := Statics2.GetDefaultForRelativeReadings;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IInclinometerStatics3'}
class function TInclinometer.GetDefault(sensorReadingtype: SensorReadingType): IInclinometer;
begin
  Result := Statics3.GetDefault(sensorReadingtype);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IInclinometerStatics4'}
class function TInclinometer.GetDeviceSelector(readingType: SensorReadingType): HSTRING;
begin
  Result := Statics4.GetDeviceSelector(readingType);
end;

class function TInclinometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IInclinometer;
begin
  Result := Statics4.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TLightSensor }

{$REGION 'Windows.Devices.Sensors.ILightSensorStatics'}
class function TLightSensor.GetDefault: ILightSensor;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.ILightSensorStatics2'}
class function TLightSensor.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;

class function TLightSensor.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ILightSensor;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TMagnetometer }

{$REGION 'Windows.Devices.Sensors.IMagnetometerStatics'}
class function TMagnetometer.GetDefault: IMagnetometer;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IMagnetometerStatics2'}
class function TMagnetometer.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;

class function TMagnetometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IMagnetometer;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TOrientationSensor }

{$REGION 'Windows.Devices.Sensors.IOrientationSensorStatics'}
class function TOrientationSensor.GetDefault: IOrientationSensor;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IOrientationSensorStatics2'}
class function TOrientationSensor.GetDefaultForRelativeReadings: IOrientationSensor;
begin
  Result := Statics2.GetDefaultForRelativeReadings;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IOrientationSensorStatics3'}
class function TOrientationSensor.GetDefault(sensorReadingtype: SensorReadingType): IOrientationSensor;
begin
  Result := Statics3.GetDefault(sensorReadingtype);
end;

class function TOrientationSensor.GetDefault(sensorReadingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): IOrientationSensor;
begin
  Result := Statics3.GetDefault(sensorReadingType, optimizationGoal);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IOrientationSensorStatics4'}
class function TOrientationSensor.GetDeviceSelector(readingType: SensorReadingType): HSTRING;
begin
  Result := Statics4.GetDeviceSelector(readingType);
end;

class function TOrientationSensor.GetDeviceSelector(readingType: SensorReadingType; optimizationGoal: SensorOptimizationGoal): HSTRING;
begin
  Result := Statics4.GetDeviceSelector(readingType, optimizationGoal);
end;

class function TOrientationSensor.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IOrientationSensor;
begin
  Result := Statics4.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TPedometer }

{$REGION 'Windows.Devices.Sensors.IPedometerStatics'}
class function TPedometer.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IPedometer;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TPedometer.GetDefaultAsync: IAsyncOperation_1__IPedometer;
begin
  Result := Statics.GetDefaultAsync;
end;

class function TPedometer.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TPedometer.GetSystemHistoryAsync(fromTime: DateTime): IAsyncOperation_1__IVectorView_1__IPedometerReading;
begin
  Result := Statics.GetSystemHistoryAsync(fromTime);
end;

class function TPedometer.GetSystemHistoryAsync(fromTime: DateTime; duration: TimeSpan): IAsyncOperation_1__IVectorView_1__IPedometerReading;
begin
  Result := Statics.GetSystemHistoryAsync(fromTime, duration);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IPedometerStatics2'}
class function TPedometer.GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IPedometerReading;
begin
  Result := Statics2.GetReadingsFromTriggerDetails(triggerDetails);
end;
{$ENDREGION}

{ TProximitySensor }

{$REGION 'Windows.Devices.Sensors.IProximitySensorStatics'}
class function TProximitySensor.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TProximitySensor.FromId(sensorId: HSTRING): IProximitySensor;
begin
  Result := Statics.FromId(sensorId);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.IProximitySensorStatics2'}
class function TProximitySensor.GetReadingsFromTriggerDetails(triggerDetails: ISensorDataThresholdTriggerDetails): IVectorView_1__IProximitySensorReading;
begin
  Result := Statics2.GetReadingsFromTriggerDetails(triggerDetails);
end;
{$ENDREGION}

{ TSimpleOrientationSensor }

{$REGION 'Windows.Devices.Sensors.ISimpleOrientationSensorStatics'}
class function TSimpleOrientationSensor.GetDefault: ISimpleOrientationSensor;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Sensors.ISimpleOrientationSensorStatics2'}
class function TSimpleOrientationSensor.GetDeviceSelector: HSTRING;
begin
  Result := Statics2.GetDeviceSelector;
end;

class function TSimpleOrientationSensor.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__ISimpleOrientationSensor;
begin
  Result := Statics2.FromIdAsync(deviceId);
end;
{$ENDREGION}

end.
