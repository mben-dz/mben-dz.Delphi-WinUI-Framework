{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.AI;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Media,
  Winapi.GraphicsRT,
  Winapi.Foundation.Collections,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.AI.Actions.IActionEntityFactory
  Actions_IActionEntityFactory = interface;
  PActions_IActionEntityFactory = ^Actions_IActionEntityFactory;

  // Windows.AI.Actions.IActionEntityFactoryFactory
  Actions_IActionEntityFactoryFactory = interface;
  PActions_IActionEntityFactoryFactory = ^Actions_IActionEntityFactoryFactory;

  // Windows.AI.Actions.IActionRuntimeFactory
  Actions_IActionRuntimeFactory = interface;
  PActions_IActionRuntimeFactory = ^Actions_IActionRuntimeFactory;

  // Windows.AI.MachineLearning.IImageFeatureDescriptor
  MachineLearning_IImageFeatureDescriptor = interface;
  PMachineLearning_IImageFeatureDescriptor = ^MachineLearning_IImageFeatureDescriptor;

  // Windows.AI.MachineLearning.IImageFeatureDescriptor2
  MachineLearning_IImageFeatureDescriptor2 = interface;
  PMachineLearning_IImageFeatureDescriptor2 = ^MachineLearning_IImageFeatureDescriptor2;

  // Windows.AI.MachineLearning.IImageFeatureValue
  MachineLearning_IImageFeatureValue = interface;
  PMachineLearning_IImageFeatureValue = ^MachineLearning_IImageFeatureValue;

  // Windows.AI.MachineLearning.IImageFeatureValueStatics
  MachineLearning_IImageFeatureValueStatics = interface;
  PMachineLearning_IImageFeatureValueStatics = ^MachineLearning_IImageFeatureValueStatics;

  // Windows.AI.MachineLearning.ILearningModelFeatureDescriptor
  MachineLearning_ILearningModelFeatureDescriptor = interface;
  PMachineLearning_ILearningModelFeatureDescriptor = ^MachineLearning_ILearningModelFeatureDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IIterator_1__MachineLearning_ILearningModelFeatureDescriptor = interface;
  PIIterator_1__MachineLearning_ILearningModelFeatureDescriptor = ^IIterator_1__MachineLearning_ILearningModelFeatureDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IIterable_1__MachineLearning_ILearningModelFeatureDescriptor = interface;
  PIIterable_1__MachineLearning_ILearningModelFeatureDescriptor = ^IIterable_1__MachineLearning_ILearningModelFeatureDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor = interface;
  PIVectorView_1__MachineLearning_ILearningModelFeatureDescriptor = ^IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor;

  // Windows.AI.MachineLearning.ILearningModel
  MachineLearning_ILearningModel = interface;
  PMachineLearning_ILearningModel = ^MachineLearning_ILearningModel;

  // Windows.AI.MachineLearning.ILearningModelBinding
  MachineLearning_ILearningModelBinding = interface;
  PMachineLearning_ILearningModelBinding = ^MachineLearning_ILearningModelBinding;

  // Windows.AI.MachineLearning.ILearningModelDevice
  MachineLearning_ILearningModelDevice = interface;
  PMachineLearning_ILearningModelDevice = ^MachineLearning_ILearningModelDevice;

  // Windows.AI.MachineLearning.ILearningModelEvaluationResult
  MachineLearning_ILearningModelEvaluationResult = interface;
  PMachineLearning_ILearningModelEvaluationResult = ^MachineLearning_ILearningModelEvaluationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.ILearningModelEvaluationResult>
  AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult = interface;
  PAsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult = ^AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.ILearningModelEvaluationResult>
  IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult = interface;
  PIAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult = ^IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult;

  // Windows.AI.MachineLearning.ILearningModelSession
  MachineLearning_ILearningModelSession = interface;
  PMachineLearning_ILearningModelSession = ^MachineLearning_ILearningModelSession;

  // Windows.AI.MachineLearning.ILearningModelBindingFactory
  MachineLearning_ILearningModelBindingFactory = interface;
  PMachineLearning_ILearningModelBindingFactory = ^MachineLearning_ILearningModelBindingFactory;

  // Windows.AI.MachineLearning.ILearningModelDeviceFactory
  MachineLearning_ILearningModelDeviceFactory = interface;
  PMachineLearning_ILearningModelDeviceFactory = ^MachineLearning_ILearningModelDeviceFactory;

  // Windows.AI.MachineLearning.ILearningModelDeviceStatics
  MachineLearning_ILearningModelDeviceStatics = interface;
  PMachineLearning_ILearningModelDeviceStatics = ^MachineLearning_ILearningModelDeviceStatics;

  // Windows.AI.MachineLearning.ILearningModelFeatureValue
  MachineLearning_ILearningModelFeatureValue = interface;
  PMachineLearning_ILearningModelFeatureValue = ^MachineLearning_ILearningModelFeatureValue;

  // Windows.AI.MachineLearning.ILearningModelOperatorProvider
  MachineLearning_ILearningModelOperatorProvider = interface;
  PMachineLearning_ILearningModelOperatorProvider = ^MachineLearning_ILearningModelOperatorProvider;

  // Windows.AI.MachineLearning.ILearningModelSessionFactory
  MachineLearning_ILearningModelSessionFactory = interface;
  PMachineLearning_ILearningModelSessionFactory = ^MachineLearning_ILearningModelSessionFactory;

  // Windows.AI.MachineLearning.ILearningModelSessionOptions
  MachineLearning_ILearningModelSessionOptions = interface;
  PMachineLearning_ILearningModelSessionOptions = ^MachineLearning_ILearningModelSessionOptions;

  // Windows.AI.MachineLearning.ILearningModelSessionFactory2
  MachineLearning_ILearningModelSessionFactory2 = interface;
  PMachineLearning_ILearningModelSessionFactory2 = ^MachineLearning_ILearningModelSessionFactory2;

  // Windows.AI.MachineLearning.ILearningModelSessionOptions2
  MachineLearning_ILearningModelSessionOptions2 = interface;
  PMachineLearning_ILearningModelSessionOptions2 = ^MachineLearning_ILearningModelSessionOptions2;

  // Windows.AI.MachineLearning.ILearningModelSessionOptions3
  MachineLearning_ILearningModelSessionOptions3 = interface;
  PMachineLearning_ILearningModelSessionOptions3 = ^MachineLearning_ILearningModelSessionOptions3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.ILearningModel>
  AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel = interface;
  PAsyncOperationCompletedHandler_1__MachineLearning_ILearningModel = ^AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel;

  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.ILearningModel>
  IAsyncOperation_1__MachineLearning_ILearningModel = interface;
  PIAsyncOperation_1__MachineLearning_ILearningModel = ^IAsyncOperation_1__MachineLearning_ILearningModel;

  // Windows.AI.MachineLearning.ILearningModelStatics
  MachineLearning_ILearningModelStatics = interface;
  PMachineLearning_ILearningModelStatics = ^MachineLearning_ILearningModelStatics;

  // Windows.AI.MachineLearning.IMapFeatureDescriptor
  MachineLearning_IMapFeatureDescriptor = interface;
  PMachineLearning_IMapFeatureDescriptor = ^MachineLearning_IMapFeatureDescriptor;

  // Windows.AI.MachineLearning.ISequenceFeatureDescriptor
  MachineLearning_ISequenceFeatureDescriptor = interface;
  PMachineLearning_ISequenceFeatureDescriptor = ^MachineLearning_ISequenceFeatureDescriptor;

  // Windows.AI.MachineLearning.ITensor
  MachineLearning_ITensor = interface;
  PMachineLearning_ITensor = ^MachineLearning_ITensor;

  // Windows.AI.MachineLearning.ITensorBoolean
  MachineLearning_ITensorBoolean = interface;
  PMachineLearning_ITensorBoolean = ^MachineLearning_ITensorBoolean;

  // Windows.AI.MachineLearning.ITensorBooleanStatics
  MachineLearning_ITensorBooleanStatics = interface;
  PMachineLearning_ITensorBooleanStatics = ^MachineLearning_ITensorBooleanStatics;

  // Windows.AI.MachineLearning.ITensorBooleanStatics2
  MachineLearning_ITensorBooleanStatics2 = interface;
  PMachineLearning_ITensorBooleanStatics2 = ^MachineLearning_ITensorBooleanStatics2;

  // Windows.AI.MachineLearning.ITensorDouble
  MachineLearning_ITensorDouble = interface;
  PMachineLearning_ITensorDouble = ^MachineLearning_ITensorDouble;

  // Windows.AI.MachineLearning.ITensorDoubleStatics
  MachineLearning_ITensorDoubleStatics = interface;
  PMachineLearning_ITensorDoubleStatics = ^MachineLearning_ITensorDoubleStatics;

  // Windows.AI.MachineLearning.ITensorDoubleStatics2
  MachineLearning_ITensorDoubleStatics2 = interface;
  PMachineLearning_ITensorDoubleStatics2 = ^MachineLearning_ITensorDoubleStatics2;

  // Windows.AI.MachineLearning.ITensorFeatureDescriptor
  MachineLearning_ITensorFeatureDescriptor = interface;
  PMachineLearning_ITensorFeatureDescriptor = ^MachineLearning_ITensorFeatureDescriptor;

  // Windows.AI.MachineLearning.ITensorFloat
  MachineLearning_ITensorFloat = interface;
  PMachineLearning_ITensorFloat = ^MachineLearning_ITensorFloat;

  // Windows.AI.MachineLearning.ITensorFloat16Bit
  MachineLearning_ITensorFloat16Bit = interface;
  PMachineLearning_ITensorFloat16Bit = ^MachineLearning_ITensorFloat16Bit;

  // Windows.AI.MachineLearning.ITensorFloat16BitStatics
  MachineLearning_ITensorFloat16BitStatics = interface;
  PMachineLearning_ITensorFloat16BitStatics = ^MachineLearning_ITensorFloat16BitStatics;

  // Windows.AI.MachineLearning.ITensorFloat16BitStatics2
  MachineLearning_ITensorFloat16BitStatics2 = interface;
  PMachineLearning_ITensorFloat16BitStatics2 = ^MachineLearning_ITensorFloat16BitStatics2;

  // Windows.AI.MachineLearning.ITensorFloatStatics
  MachineLearning_ITensorFloatStatics = interface;
  PMachineLearning_ITensorFloatStatics = ^MachineLearning_ITensorFloatStatics;

  // Windows.AI.MachineLearning.ITensorFloatStatics2
  MachineLearning_ITensorFloatStatics2 = interface;
  PMachineLearning_ITensorFloatStatics2 = ^MachineLearning_ITensorFloatStatics2;

  // Windows.AI.MachineLearning.ITensorInt16Bit
  MachineLearning_ITensorInt16Bit = interface;
  PMachineLearning_ITensorInt16Bit = ^MachineLearning_ITensorInt16Bit;

  // Windows.AI.MachineLearning.ITensorInt16BitStatics
  MachineLearning_ITensorInt16BitStatics = interface;
  PMachineLearning_ITensorInt16BitStatics = ^MachineLearning_ITensorInt16BitStatics;

  // Windows.AI.MachineLearning.ITensorInt16BitStatics2
  MachineLearning_ITensorInt16BitStatics2 = interface;
  PMachineLearning_ITensorInt16BitStatics2 = ^MachineLearning_ITensorInt16BitStatics2;

  // Windows.AI.MachineLearning.ITensorInt32Bit
  MachineLearning_ITensorInt32Bit = interface;
  PMachineLearning_ITensorInt32Bit = ^MachineLearning_ITensorInt32Bit;

  // Windows.AI.MachineLearning.ITensorInt32BitStatics
  MachineLearning_ITensorInt32BitStatics = interface;
  PMachineLearning_ITensorInt32BitStatics = ^MachineLearning_ITensorInt32BitStatics;

  // Windows.AI.MachineLearning.ITensorInt32BitStatics2
  MachineLearning_ITensorInt32BitStatics2 = interface;
  PMachineLearning_ITensorInt32BitStatics2 = ^MachineLearning_ITensorInt32BitStatics2;

  // Windows.AI.MachineLearning.ITensorInt64Bit
  MachineLearning_ITensorInt64Bit = interface;
  PMachineLearning_ITensorInt64Bit = ^MachineLearning_ITensorInt64Bit;

  // Windows.AI.MachineLearning.ITensorInt64BitStatics
  MachineLearning_ITensorInt64BitStatics = interface;
  PMachineLearning_ITensorInt64BitStatics = ^MachineLearning_ITensorInt64BitStatics;

  // Windows.AI.MachineLearning.ITensorInt64BitStatics2
  MachineLearning_ITensorInt64BitStatics2 = interface;
  PMachineLearning_ITensorInt64BitStatics2 = ^MachineLearning_ITensorInt64BitStatics2;

  // Windows.AI.MachineLearning.ITensorInt8Bit
  MachineLearning_ITensorInt8Bit = interface;
  PMachineLearning_ITensorInt8Bit = ^MachineLearning_ITensorInt8Bit;

  // Windows.AI.MachineLearning.ITensorInt8BitStatics
  MachineLearning_ITensorInt8BitStatics = interface;
  PMachineLearning_ITensorInt8BitStatics = ^MachineLearning_ITensorInt8BitStatics;

  // Windows.AI.MachineLearning.ITensorInt8BitStatics2
  MachineLearning_ITensorInt8BitStatics2 = interface;
  PMachineLearning_ITensorInt8BitStatics2 = ^MachineLearning_ITensorInt8BitStatics2;

  // Windows.AI.MachineLearning.ITensorString
  MachineLearning_ITensorString = interface;
  PMachineLearning_ITensorString = ^MachineLearning_ITensorString;

  // Windows.AI.MachineLearning.ITensorStringStatics
  MachineLearning_ITensorStringStatics = interface;
  PMachineLearning_ITensorStringStatics = ^MachineLearning_ITensorStringStatics;

  // Windows.AI.MachineLearning.ITensorStringStatics2
  MachineLearning_ITensorStringStatics2 = interface;
  PMachineLearning_ITensorStringStatics2 = ^MachineLearning_ITensorStringStatics2;

  // Windows.AI.MachineLearning.ITensorUInt16Bit
  MachineLearning_ITensorUInt16Bit = interface;
  PMachineLearning_ITensorUInt16Bit = ^MachineLearning_ITensorUInt16Bit;

  // Windows.AI.MachineLearning.ITensorUInt16BitStatics
  MachineLearning_ITensorUInt16BitStatics = interface;
  PMachineLearning_ITensorUInt16BitStatics = ^MachineLearning_ITensorUInt16BitStatics;

  // Windows.AI.MachineLearning.ITensorUInt16BitStatics2
  MachineLearning_ITensorUInt16BitStatics2 = interface;
  PMachineLearning_ITensorUInt16BitStatics2 = ^MachineLearning_ITensorUInt16BitStatics2;

  // Windows.AI.MachineLearning.ITensorUInt32Bit
  MachineLearning_ITensorUInt32Bit = interface;
  PMachineLearning_ITensorUInt32Bit = ^MachineLearning_ITensorUInt32Bit;

  // Windows.AI.MachineLearning.ITensorUInt32BitStatics
  MachineLearning_ITensorUInt32BitStatics = interface;
  PMachineLearning_ITensorUInt32BitStatics = ^MachineLearning_ITensorUInt32BitStatics;

  // Windows.AI.MachineLearning.ITensorUInt32BitStatics2
  MachineLearning_ITensorUInt32BitStatics2 = interface;
  PMachineLearning_ITensorUInt32BitStatics2 = ^MachineLearning_ITensorUInt32BitStatics2;

  // Windows.AI.MachineLearning.ITensorUInt64Bit
  MachineLearning_ITensorUInt64Bit = interface;
  PMachineLearning_ITensorUInt64Bit = ^MachineLearning_ITensorUInt64Bit;

  // Windows.AI.MachineLearning.ITensorUInt64BitStatics
  MachineLearning_ITensorUInt64BitStatics = interface;
  PMachineLearning_ITensorUInt64BitStatics = ^MachineLearning_ITensorUInt64BitStatics;

  // Windows.AI.MachineLearning.ITensorUInt64BitStatics2
  MachineLearning_ITensorUInt64BitStatics2 = interface;
  PMachineLearning_ITensorUInt64BitStatics2 = ^MachineLearning_ITensorUInt64BitStatics2;

  // Windows.AI.MachineLearning.ITensorUInt8Bit
  MachineLearning_ITensorUInt8Bit = interface;
  PMachineLearning_ITensorUInt8Bit = ^MachineLearning_ITensorUInt8Bit;

  // Windows.AI.MachineLearning.ITensorUInt8BitStatics
  MachineLearning_ITensorUInt8BitStatics = interface;
  PMachineLearning_ITensorUInt8BitStatics = ^MachineLearning_ITensorUInt8BitStatics;

  // Windows.AI.MachineLearning.ITensorUInt8BitStatics2
  MachineLearning_ITensorUInt8BitStatics2 = interface;
  PMachineLearning_ITensorUInt8BitStatics2 = ^MachineLearning_ITensorUInt8BitStatics2;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolClientContextFactory
  ModelContextProtocol_IModelContextProtocolClientContextFactory = interface;
  PModelContextProtocol_IModelContextProtocolClientContextFactory = ^ModelContextProtocol_IModelContextProtocolClientContextFactory;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolServerCatalogFactory
  ModelContextProtocol_IModelContextProtocolServerCatalogFactory = interface;
  PModelContextProtocol_IModelContextProtocolServerCatalogFactory = ^ModelContextProtocol_IModelContextProtocolServerCatalogFactory;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolServerInfoFactory
  ModelContextProtocol_IModelContextProtocolServerInfoFactory = interface;
  PModelContextProtocol_IModelContextProtocolServerInfoFactory = ^ModelContextProtocol_IModelContextProtocolServerInfoFactory;

  // Windows.AI Enums

  // Windows.AI.Actions.ActionEntityKind
  Actions_ActionEntityKind = (
    None = 0,
    Document = 1,
    &File = 2,
    Photo = 3,
    Text = 4,
    StreamingText = 5,
    RemoteFile = 6,
    Table = 7,
    Contact = 8
  );
  PActions_ActionEntityKind = ^Actions_ActionEntityKind;

  // Windows.AI.Actions.ActionEntityTextFormat
  Actions_ActionEntityTextFormat = (
    Plain = 0,
    Markdown = 1
  );
  PActions_ActionEntityTextFormat = ^Actions_ActionEntityTextFormat;

  // Windows.AI.Actions.ActionFeedbackKind
  Actions_ActionFeedbackKind = (
    Positive = 0,
    Negative = 1
  );
  PActions_ActionFeedbackKind = ^Actions_ActionFeedbackKind;

  // Windows.AI.Actions.ActionInvocationHelpKind
  Actions_ActionInvocationHelpKind = (
    None = 0,
    Error = 1,
    Warning = 2
  );
  PActions_ActionInvocationHelpKind = ^Actions_ActionInvocationHelpKind;

  // Windows.AI.Actions.ActionInvocationResult
  Actions_ActionInvocationResult = (
    Success = 0,
    UserCanceled = 1,
    Unsupported = 2,
    Unavailable = 3
  );
  PActions_ActionInvocationResult = ^Actions_ActionInvocationResult;

  // Windows.AI.Actions.RemoteFileKind
  Actions_RemoteFileKind = (
    Document = 0,
    Photo = 1,
    &File = 2
  );
  PActions_RemoteFileKind = ^Actions_RemoteFileKind;

  // Windows.AI.MachineLearning.LearningModelDeviceKind
  MachineLearning_LearningModelDeviceKind = (
    Default = 0,
    Cpu = 1,
    DirectX = 2,
    DirectXHighPerformance = 3,
    DirectXMinPower = 4
  );
  PMachineLearning_LearningModelDeviceKind = ^MachineLearning_LearningModelDeviceKind;

  // Windows.AI.MachineLearning.LearningModelFeatureKind
  MachineLearning_LearningModelFeatureKind = (
    Tensor = 0,
    Sequence = 1,
    Map = 2,
    Image = 3
  );
  PMachineLearning_LearningModelFeatureKind = ^MachineLearning_LearningModelFeatureKind;

  // Windows.AI.MachineLearning.LearningModelPixelRange
  MachineLearning_LearningModelPixelRange = (
    ZeroTo255 = 0,
    ZeroToOne = 1,
    MinusOneToOne = 2
  );
  PMachineLearning_LearningModelPixelRange = ^MachineLearning_LearningModelPixelRange;

  // Windows.AI.MachineLearning.Preview.FeatureElementKindPreview
  MachineLearning_Preview_FeatureElementKindPreview = (
    Undefined = 0,
    Float = 1,
    UInt8 = 2,
    Int8 = 3,
    UInt16 = 4,
    Int16 = 5,
    Int32 = 6,
    Int64 = 7,
    &String = 8,
    Boolean = 9,
    Float16 = 10,
    Double = 11,
    UInt32 = 12,
    UInt64 = 13,
    Complex64 = 14,
    Complex128 = 15
  );
  PMachineLearning_Preview_FeatureElementKindPreview = ^MachineLearning_Preview_FeatureElementKindPreview;

  // Windows.AI.MachineLearning.Preview.LearningModelDeviceKindPreview
  MachineLearning_Preview_LearningModelDeviceKindPreview = (
    LearningDeviceAny = 0,
    LearningDeviceCpu = 1,
    LearningDeviceGpu = 2,
    LearningDeviceNpu = 3,
    LearningDeviceDsp = 4,
    LearningDeviceFpga = 5
  );
  PMachineLearning_Preview_LearningModelDeviceKindPreview = ^MachineLearning_Preview_LearningModelDeviceKindPreview;

  // Windows.AI.MachineLearning.Preview.LearningModelFeatureKindPreview
  MachineLearning_Preview_LearningModelFeatureKindPreview = (
    Undefined = 0,
    Tensor = 1,
    Sequence = 2,
    Map = 3,
    Image = 4
  );
  PMachineLearning_Preview_LearningModelFeatureKindPreview = ^MachineLearning_Preview_LearningModelFeatureKindPreview;

  // Windows.AI.MachineLearning.TensorKind
  MachineLearning_TensorKind = (
    Undefined = 0,
    Float = 1,
    UInt8 = 2,
    Int8 = 3,
    UInt16 = 4,
    Int16 = 5,
    Int32 = 6,
    Int64 = 7,
    &String = 8,
    Boolean = 9,
    Float16 = 10,
    Double = 11,
    UInt32 = 12,
    UInt64 = 13,
    Complex64 = 14,
    Complex128 = 15
  );
  PMachineLearning_TensorKind = ^MachineLearning_TensorKind;

  // Windows.AI Records

  // Windows.AI.Actions.ActionsContract
  Actions_ActionsContract = record
  end;
  PActions_ActionsContract = ^Actions_ActionsContract;

  // Windows.AI.MachineLearning.MachineLearningContract
  MachineLearning_MachineLearningContract = record
  end;
  PMachineLearning_MachineLearningContract = ^MachineLearning_MachineLearningContract;

  // Windows.AI.MachineLearning.Preview.MachineLearningPreviewContract
  MachineLearning_Preview_MachineLearningPreviewContract = record
  end;
  PMachineLearning_Preview_MachineLearningPreviewContract = ^MachineLearning_Preview_MachineLearningPreviewContract;

  // Windows.AI.ModelContextProtocol.ModelContextProtocolContract
  ModelContextProtocol_ModelContextProtocolContract = record
  end;
  PModelContextProtocol_ModelContextProtocolContract = ^ModelContextProtocol_ModelContextProtocolContract;

  // Windows.AI Interfaces

  // Windows.AI.Actions.IActionEntityFactory
  Actions_IActionEntityFactory = interface(IInspectable)
  ['{9CB752A0-5BF8-5BE2-916E-B00EFF80088D}']
  end;

  // Windows.AI.Actions.IActionEntityFactoryFactory
  Actions_IActionEntityFactoryFactory = interface(IInspectable)
  ['{C9147D8F-88A0-5EC0-A564-47E2A1081412}']
  end;

  // Windows.AI.Actions.IActionRuntimeFactory
  Actions_IActionRuntimeFactory = interface(IInspectable)
  ['{D3F366E9-8DC9-50A0-8040-E5C14FA609D6}']
  end;

  // Windows.AI.MachineLearning.IImageFeatureDescriptor
  MachineLearning_IImageFeatureDescriptor = interface(IInspectable)
  ['{365585A5-171A-4A2A-985F-265159D3895A}']
    function get_BitmapPixelFormat: Imaging_BitmapPixelFormat; safecall;
    function get_BitmapAlphaMode: Imaging_BitmapAlphaMode; safecall;
    function get_Width: Cardinal; safecall;
    function get_Height: Cardinal; safecall;
    property BitmapAlphaMode: Imaging_BitmapAlphaMode read get_BitmapAlphaMode;
    property BitmapPixelFormat: Imaging_BitmapPixelFormat read get_BitmapPixelFormat;
    property Height: Cardinal read get_Height;
    property Width: Cardinal read get_Width;
  end;

  // Windows.AI.MachineLearning.IImageFeatureDescriptor2
  MachineLearning_IImageFeatureDescriptor2 = interface(IInspectable)
  ['{2B27CCA7-D533-5862-BB98-1611B155B0E1}']
    function get_PixelRange: MachineLearning_LearningModelPixelRange; safecall;
    property PixelRange: MachineLearning_LearningModelPixelRange read get_PixelRange;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.IImageFeatureValue
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_ImageFeatureValue)]
  MachineLearning_IImageFeatureValue = interface(IInspectable)
  ['{F0414FD9-C9AA-4405-B7FB-94F87C8A3037}']
    function get_VideoFrame: IVideoFrame; safecall;
    property VideoFrame: IVideoFrame read get_VideoFrame;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.IImageFeatureValueStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_ImageFeatureValue)]
  MachineLearning_IImageFeatureValueStatics = interface(IInspectable)
  ['{1BC317FD-23CB-4610-B085-C8E1C87EBAA0}']
    function CreateFromVideoFrame(image: IVideoFrame): MachineLearning_IImageFeatureValue; safecall;
  end;

  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelFeatureDescriptor
  MachineLearning_ILearningModelFeatureDescriptor = interface(IInspectable)
  ['{BC08CF7C-6ED0-4004-97BA-B9A2EECD2B4F}']
    function get_Name: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_Kind: MachineLearning_LearningModelFeatureKind; safecall;
    function get_IsRequired: Boolean; safecall;
    property Description: HSTRING read get_Description;
    property IsRequired: Boolean read get_IsRequired;
    property Kind: MachineLearning_LearningModelFeatureKind read get_Kind;
    property Name: HSTRING read get_Name;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IIterator_1__MachineLearning_ILearningModelFeatureDescriptor = interface(IInspectable)
  ['{0EF412A8-A1E6-593A-97F2-0D699CA6A567}']
    function get_Current: MachineLearning_ILearningModelFeatureDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMachineLearning_ILearningModelFeatureDescriptor): Cardinal; safecall;
    property Current: MachineLearning_ILearningModelFeatureDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IIterable_1__MachineLearning_ILearningModelFeatureDescriptor = interface(IInspectable)
  ['{0FA50877-6792-56B7-AF46-430A8901894A}']
    function First: IIterator_1__MachineLearning_ILearningModelFeatureDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.AI.MachineLearning.ILearningModelFeatureDescriptor>
  IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor = interface(IInspectable)
  ['{53E53120-A6E1-527F-AF8A-C812902E175E}']
    function GetAt(index: Cardinal): MachineLearning_ILearningModelFeatureDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: MachineLearning_ILearningModelFeatureDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMachineLearning_ILearningModelFeatureDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModel
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModel)]
  MachineLearning_ILearningModel = interface(IInspectable)
  ['{5B8E4920-489F-4E86-9128-265A327B78FA}']
    function get_Author: HSTRING; safecall;
    function get_Name: HSTRING; safecall;
    function get_Domain: HSTRING; safecall;
    function get_Description: HSTRING; safecall;
    function get_Version: Int64; safecall;
    function get_Metadata: IMapView_2__HSTRING__HSTRING; safecall;
    function get_InputFeatures: IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor; safecall;
    function get_OutputFeatures: IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor; safecall;
    property Author: HSTRING read get_Author;
    property Description: HSTRING read get_Description;
    property Domain: HSTRING read get_Domain;
    property InputFeatures: IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor read get_InputFeatures;
    property Metadata: IMapView_2__HSTRING__HSTRING read get_Metadata;
    property Name: HSTRING read get_Name;
    property OutputFeatures: IVectorView_1__MachineLearning_ILearningModelFeatureDescriptor read get_OutputFeatures;
    property Version: Int64 read get_Version;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelBinding
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelBinding)]
  MachineLearning_ILearningModelBinding = interface(IInspectable)
  ['{EA312F20-168F-4F8C-94FE-2E7AC31B4AA8}']
    procedure Bind(name: HSTRING; value: IInspectable); overload; safecall;
    procedure Bind(name: HSTRING; value: IInspectable; props: IPropertySet); overload; safecall;
    procedure Clear; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelDevice
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelDevice)]
  MachineLearning_ILearningModelDevice = interface(IInspectable)
  ['{F5C2C8FE-3F56-4A8C-AC5F-FDB92D8B8252}']
    function get_AdapterId: DisplayAdapterId; safecall;
    function get_Direct3D11Device: DirectX_Direct3D11_IDirect3DDevice; safecall;
    property AdapterId: DisplayAdapterId read get_AdapterId;
    property Direct3D11Device: DirectX_Direct3D11_IDirect3DDevice read get_Direct3D11Device;
  end;

  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelEvaluationResult
  MachineLearning_ILearningModelEvaluationResult = interface(IInspectable)
  ['{B2F9BFCD-960E-49C0-8593-EB190AE3EEE2}']
    function get_CorrelationId: HSTRING; safecall;
    function get_ErrorStatus: Integer; safecall;
    function get_Succeeded: Boolean; safecall;
    function get_Outputs: IMapView_2__HSTRING__IInspectable; safecall;
    property CorrelationId: HSTRING read get_CorrelationId;
    property ErrorStatus: Integer read get_ErrorStatus;
    property Outputs: IMapView_2__HSTRING__IInspectable read get_Outputs;
    property Succeeded: Boolean read get_Succeeded;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.LearningModelEvaluationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.ILearningModelEvaluationResult>
  AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult = interface(IUnknown)
  ['{B8776114-9ADF-50E8-B67F-22E0F1372F45}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.LearningModelEvaluationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.ILearningModelEvaluationResult>
  IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult = interface(IInspectable)
  ['{28050590-1422-5A18-8C8B-847F2D2CF69A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult; safecall;
    function GetResults: MachineLearning_ILearningModelEvaluationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModelEvaluationResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSession
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelSession)]
  MachineLearning_ILearningModelSession = interface(IInspectable)
  ['{8E58F8F6-B787-4C11-90F0-7129AECA74A9}']
    function get_Model: MachineLearning_ILearningModel; safecall;
    function get_Device: MachineLearning_ILearningModelDevice; safecall;
    function get_EvaluationProperties: IPropertySet; safecall;
    function EvaluateAsync(bindings: MachineLearning_ILearningModelBinding; correlationId: HSTRING): IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult; safecall;
    function EvaluateFeaturesAsync(features: IMap_2__HSTRING__IInspectable; correlationId: HSTRING): IAsyncOperation_1__MachineLearning_ILearningModelEvaluationResult; safecall;
    function Evaluate(bindings: MachineLearning_ILearningModelBinding; correlationId: HSTRING): MachineLearning_ILearningModelEvaluationResult; safecall;
    function EvaluateFeatures(features: IMap_2__HSTRING__IInspectable; correlationId: HSTRING): MachineLearning_ILearningModelEvaluationResult; safecall;
    property Device: MachineLearning_ILearningModelDevice read get_Device;
    property EvaluationProperties: IPropertySet read get_EvaluationProperties;
    property Model: MachineLearning_ILearningModel read get_Model;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelBindingFactory
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelBinding)]
  MachineLearning_ILearningModelBindingFactory = interface(IInspectable)
  ['{C95F7A7A-E788-475E-8917-23AA381FAF0B}']
    function CreateFromSession(session: MachineLearning_ILearningModelSession): MachineLearning_ILearningModelBinding; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelDeviceFactory
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelDevice)]
  MachineLearning_ILearningModelDeviceFactory = interface(IInspectable)
  ['{9CFFD74D-B1E5-4F20-80AD-0A56690DB06B}']
    function Create(deviceKind: MachineLearning_LearningModelDeviceKind): MachineLearning_ILearningModelDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelDeviceStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelDevice)]
  MachineLearning_ILearningModelDeviceStatics = interface(IInspectable)
  ['{49F32107-A8BF-42BB-92C7-10B12DC5D21F}']
    function CreateFromDirect3D11Device(device: DirectX_Direct3D11_IDirect3DDevice): MachineLearning_ILearningModelDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelFeatureValue
  MachineLearning_ILearningModelFeatureValue = interface(IInspectable)
  ['{F51005DB-4085-4DFE-9FED-95EB0C0CF75C}']
    function get_Kind: MachineLearning_LearningModelFeatureKind; safecall;
    property Kind: MachineLearning_LearningModelFeatureKind read get_Kind;
  end;

  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelOperatorProvider
  MachineLearning_ILearningModelOperatorProvider = interface(IInspectable)
  ['{2A222E5D-AFB1-47ED-BFAD-B5B3A459EC04}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSessionFactory
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelSession)]
  MachineLearning_ILearningModelSessionFactory = interface(IInspectable)
  ['{0F6B881D-1C9B-47B6-BFE0-F1CF62A67579}']
    function CreateFromModel(model: MachineLearning_ILearningModel): MachineLearning_ILearningModelSession; safecall;
    function CreateFromModelOnDevice(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice): MachineLearning_ILearningModelSession; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSessionOptions
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelSessionOptions)]
  MachineLearning_ILearningModelSessionOptions = interface(IInspectable)
  ['{B8F63FA1-134D-5133-8CFF-3A5C3C263BEB}']
    function get_BatchSizeOverride: Cardinal; safecall;
    procedure put_BatchSizeOverride(value: Cardinal); safecall;
    property BatchSizeOverride: Cardinal read get_BatchSizeOverride write put_BatchSizeOverride;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSessionFactory2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModelSession)]
  MachineLearning_ILearningModelSessionFactory2 = interface(IInspectable)
  ['{4E5C88BF-0A1F-5FEC-ADE0-2FD91E4EF29B}']
    function CreateFromModelOnDeviceWithSessionOptions(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice; learningModelSessionOptions: MachineLearning_ILearningModelSessionOptions): MachineLearning_ILearningModelSession; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSessionOptions2
  MachineLearning_ILearningModelSessionOptions2 = interface(IInspectable)
  ['{6FCD1DC4-175F-5BD2-8DE5-2F2006A25ADF}']
    function get_CloseModelOnSessionCreation: Boolean; safecall;
    procedure put_CloseModelOnSessionCreation(value: Boolean); safecall;
    property CloseModelOnSessionCreation: Boolean read get_CloseModelOnSessionCreation write put_CloseModelOnSessionCreation;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelSessionOptions3
  MachineLearning_ILearningModelSessionOptions3 = interface(IInspectable)
  ['{58E15CEE-D8C2-56FC-92E8-76D751081086}']
    procedure OverrideNamedDimension(name: HSTRING; dimension: Cardinal); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.LearningModel>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.AI.MachineLearning.ILearningModel>
  AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel = interface(IUnknown)
  ['{755DA6DF-ED55-5AAA-B542-C665F010F50C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__MachineLearning_ILearningModel; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.LearningModel>
  // Windows.Foundation.IAsyncOperation`1<Windows.AI.MachineLearning.ILearningModel>
  IAsyncOperation_1__MachineLearning_ILearningModel = interface(IInspectable)
  ['{634AB3CB-406C-5EDE-8A89-A7F9CA370326}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel; safecall;
    function GetResults: MachineLearning_ILearningModel; safecall;
    property Completed: AsyncOperationCompletedHandler_1__MachineLearning_ILearningModel read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ILearningModelStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_LearningModel)]
  MachineLearning_ILearningModelStatics = interface(IInspectable)
  ['{E3B977E8-6952-4E47-8EF4-1F7F07897C6D}']
    function LoadFromStorageFileAsync(modelFile: IStorageFile): IAsyncOperation_1__MachineLearning_ILearningModel; overload; safecall;
    function LoadFromStreamAsync(modelStream: IRandomAccessStreamReference): IAsyncOperation_1__MachineLearning_ILearningModel; overload; safecall;
    function LoadFromFilePath(filePath: HSTRING): MachineLearning_ILearningModel; overload; safecall;
    function LoadFromStream(modelStream: IRandomAccessStreamReference): MachineLearning_ILearningModel; overload; safecall;
    function LoadFromStorageFileAsync(modelFile: IStorageFile; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel; overload; safecall;
    function LoadFromStreamAsync(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel; overload; safecall;
    function LoadFromFilePath(filePath: HSTRING; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel; overload; safecall;
    function LoadFromStream(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel; overload; safecall;
  end;

  // Windows.AI.MachineLearning.IMapFeatureDescriptor
  MachineLearning_IMapFeatureDescriptor = interface(IInspectable)
  ['{530424BD-A257-436D-9E60-C2981F7CC5C4}']
    function get_KeyKind: MachineLearning_TensorKind; safecall;
    function get_ValueDescriptor: MachineLearning_ILearningModelFeatureDescriptor; safecall;
    property KeyKind: MachineLearning_TensorKind read get_KeyKind;
    property ValueDescriptor: MachineLearning_ILearningModelFeatureDescriptor read get_ValueDescriptor;
  end;

  // Windows.AI.MachineLearning.ISequenceFeatureDescriptor
  MachineLearning_ISequenceFeatureDescriptor = interface(IInspectable)
  ['{84F6945A-562B-4D62-A851-739ACED96668}']
    function get_ElementDescriptor: MachineLearning_ILearningModelFeatureDescriptor; safecall;
    property ElementDescriptor: MachineLearning_ILearningModelFeatureDescriptor read get_ElementDescriptor;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensor
  MachineLearning_ITensor = interface(IInspectable)
  ['{05489593-A305-4A25-AD09-440119B4B7F6}']
    function get_TensorKind: MachineLearning_TensorKind; safecall;
    function get_Shape: IVectorView_1__Int64; safecall;
    property Shape: IVectorView_1__Int64 read get_Shape;
    property TensorKind: MachineLearning_TensorKind read get_TensorKind;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorBoolean
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorBoolean)]
  MachineLearning_ITensorBoolean = interface(IInspectable)
  ['{50F311ED-29E9-4A5C-A44D-8FC512584EED}']
    function GetAsVectorView: IVectorView_1__Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorBooleanStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorBoolean)]
  MachineLearning_ITensorBooleanStatics = interface(IInspectable)
  ['{2796862C-2357-49A7-B476-D0AA3DFE6866}']
    function Create: MachineLearning_ITensorBoolean; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorBoolean; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Boolean): MachineLearning_ITensorBoolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorBooleanStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorBoolean)]
  MachineLearning_ITensorBooleanStatics2 = interface(IInspectable)
  ['{A3A4A501-6A2D-52D7-B04B-C435BAEE0115}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorBoolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorDouble
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorDouble)]
  MachineLearning_ITensorDouble = interface(IInspectable)
  ['{91E41252-7A8F-4F0E-A28F-9637FFC8A3D0}']
    function GetAsVectorView: IVectorView_1__Double; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorDoubleStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorDouble)]
  MachineLearning_ITensorDoubleStatics = interface(IInspectable)
  ['{A86693C5-9538-44E7-A3CA-5DF374A5A70C}']
    function Create: MachineLearning_ITensorDouble; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorDouble; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Double): MachineLearning_ITensorDouble; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorDoubleStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorDouble)]
  MachineLearning_ITensorDoubleStatics2 = interface(IInspectable)
  ['{93A570DE-5E9A-5094-85C8-592C655E68AC}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorDouble; safecall;
  end;

  // Windows.AI.MachineLearning.ITensorFeatureDescriptor
  MachineLearning_ITensorFeatureDescriptor = interface(IInspectable)
  ['{74455C80-946A-4310-A19C-EE0AF028FCE4}']
    function get_TensorKind: MachineLearning_TensorKind; safecall;
    function get_Shape: IVectorView_1__Int64; safecall;
    property Shape: IVectorView_1__Int64 read get_Shape;
    property TensorKind: MachineLearning_TensorKind read get_TensorKind;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloat
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat)]
  MachineLearning_ITensorFloat = interface(IInspectable)
  ['{F2282D82-AA02-42C8-A0C8-DF1EFC9676E1}']
    function GetAsVectorView: IVectorView_1__Single; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloat16Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat16Bit)]
  MachineLearning_ITensorFloat16Bit = interface(IInspectable)
  ['{0AB994FC-5B89-4C3C-B5E4-5282A5316C0A}']
    function GetAsVectorView: IVectorView_1__Single; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloat16BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat16Bit)]
  MachineLearning_ITensorFloat16BitStatics = interface(IInspectable)
  ['{A52DB6F5-318A-44D4-820B-0CDC7054A84A}']
    function Create: MachineLearning_ITensorFloat16Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat16Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloat16BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat16Bit)]
  MachineLearning_ITensorFloat16BitStatics2 = interface(IInspectable)
  ['{68545726-2DC7-51BF-B470-0B344CC2A1BC}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloatStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat)]
  MachineLearning_ITensorFloatStatics = interface(IInspectable)
  ['{DBCD395B-3BA3-452F-B10D-3C135E573FA9}']
    function Create: MachineLearning_ITensorFloat; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorFloatStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorFloat)]
  MachineLearning_ITensorFloatStatics2 = interface(IInspectable)
  ['{24610BC1-5E44-5713-B281-8F4AD4D555E8}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt16Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt16Bit)]
  MachineLearning_ITensorInt16Bit = interface(IInspectable)
  ['{98A32D39-E6D6-44AF-8AFA-BAEBC44DC020}']
    function GetAsVectorView: IVectorView_1__SmallInt; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt16BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt16Bit)]
  MachineLearning_ITensorInt16BitStatics = interface(IInspectable)
  ['{98646293-266E-4B1A-821F-E60D70898B91}']
    function Create: MachineLearning_ITensorInt16Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt16Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__SmallInt): MachineLearning_ITensorInt16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt16BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt16Bit)]
  MachineLearning_ITensorInt16BitStatics2 = interface(IInspectable)
  ['{0CD70CF4-696C-5E5F-95D8-5EBF9670148B}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt32Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt32Bit)]
  MachineLearning_ITensorInt32Bit = interface(IInspectable)
  ['{2C0C28D3-207C-4486-A7D2-884522C5E589}']
    function GetAsVectorView: IVectorView_1__Integer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt32BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt32Bit)]
  MachineLearning_ITensorInt32BitStatics = interface(IInspectable)
  ['{6539864B-52FA-4E35-907C-834CAC417B50}']
    function Create: MachineLearning_ITensorInt32Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt32Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Integer): MachineLearning_ITensorInt32Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt32BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt32Bit)]
  MachineLearning_ITensorInt32BitStatics2 = interface(IInspectable)
  ['{7C4B079A-E956-5CE0-A3BD-157D9D79B5EC}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt32Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt64Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt64Bit)]
  MachineLearning_ITensorInt64Bit = interface(IInspectable)
  ['{499665BA-1FA2-45AD-AF25-A0BD9BDA4C87}']
    function GetAsVectorView: IVectorView_1__Int64; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt64BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt64Bit)]
  MachineLearning_ITensorInt64BitStatics = interface(IInspectable)
  ['{9648AD9D-1198-4D74-9517-783AB62B9CC2}']
    function Create: MachineLearning_ITensorInt64Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt64Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Int64): MachineLearning_ITensorInt64Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt64BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt64Bit)]
  MachineLearning_ITensorInt64BitStatics2 = interface(IInspectable)
  ['{6D3D9DCB-FF40-5EC2-89FE-084E2B6BC6DB}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt64Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt8Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt8Bit)]
  MachineLearning_ITensorInt8Bit = interface(IInspectable)
  ['{CDDD97C5-FFD8-4FEF-AEFB-30E1A485B2EE}']
    function GetAsVectorView: IVectorView_1__Byte; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt8BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt8Bit)]
  MachineLearning_ITensorInt8BitStatics = interface(IInspectable)
  ['{B1A12284-095C-4C76-A661-AC4CEE1F3E8B}']
    function Create: MachineLearning_ITensorInt8Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt8Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorInt8Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorInt8BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorInt8Bit)]
  MachineLearning_ITensorInt8BitStatics2 = interface(IInspectable)
  ['{C0D59637-C468-56FB-9535-C052BDB93DC0}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt8Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorString
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorString)]
  MachineLearning_ITensorString = interface(IInspectable)
  ['{582335C8-BDB1-4610-BC75-35E9CBF009B7}']
    function GetAsVectorView: IVectorView_1__HSTRING; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorStringStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorString)]
  MachineLearning_ITensorStringStatics = interface(IInspectable)
  ['{83623324-CF26-4F17-A2D4-20EF8D097D53}']
    function Create: MachineLearning_ITensorString; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorString; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__HSTRING): MachineLearning_ITensorString; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorStringStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorString)]
  MachineLearning_ITensorStringStatics2 = interface(IInspectable)
  ['{9E355ED0-C8E2-5254-9137-0193A3668FD8}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt16Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt16Bit)]
  MachineLearning_ITensorUInt16Bit = interface(IInspectable)
  ['{68140F4B-23C0-42F3-81F6-A891C011BC3F}']
    function GetAsVectorView: IVectorView_1__Word; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt16BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt16Bit)]
  MachineLearning_ITensorUInt16BitStatics = interface(IInspectable)
  ['{5DF745DD-028A-481A-A27C-C7E6435E52DD}']
    function Create: MachineLearning_ITensorUInt16Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt16Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Word): MachineLearning_ITensorUInt16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt16BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt16Bit)]
  MachineLearning_ITensorUInt16BitStatics2 = interface(IInspectable)
  ['{8AF40C64-D69F-5315-9348-490877BBD642}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt16Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt32Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt32Bit)]
  MachineLearning_ITensorUInt32Bit = interface(IInspectable)
  ['{D8C9C2FF-7511-45A3-BFAC-C38F370D2237}']
    function GetAsVectorView: IVectorView_1__Cardinal; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt32BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt32Bit)]
  MachineLearning_ITensorUInt32BitStatics = interface(IInspectable)
  ['{417C3837-E773-4378-8E7F-0CC33DBEA697}']
    function Create: MachineLearning_ITensorUInt32Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt32Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Cardinal): MachineLearning_ITensorUInt32Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt32BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt32Bit)]
  MachineLearning_ITensorUInt32BitStatics2 = interface(IInspectable)
  ['{EF1A1F1C-314E-569D-B496-5C8447D20CD2}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt32Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt64Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt64Bit)]
  MachineLearning_ITensorUInt64Bit = interface(IInspectable)
  ['{2E70FFAD-04BF-4825-839A-82BAEF8C7886}']
    function GetAsVectorView: IVectorView_1__UInt64; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt64BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt64Bit)]
  MachineLearning_ITensorUInt64BitStatics = interface(IInspectable)
  ['{7A7E20EB-242F-47CB-A9C6-F602ECFBFEE4}']
    function Create: MachineLearning_ITensorUInt64Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt64Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__UInt64): MachineLearning_ITensorUInt64Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt64BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt64Bit)]
  MachineLearning_ITensorUInt64BitStatics2 = interface(IInspectable)
  ['{085A687D-67E1-5B1E-B232-4FABE9CA20B3}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt64Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt8Bit
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt8Bit)]
  MachineLearning_ITensorUInt8Bit = interface(IInspectable)
  ['{58E1AE27-622B-48E3-BE22-D867AED1DAAC}']
    function GetAsVectorView: IVectorView_1__Byte; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt8BitStatics
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt8Bit)]
  MachineLearning_ITensorUInt8BitStatics = interface(IInspectable)
  ['{05F67583-BC24-4220-8A41-2DCD8C5ED33C}']
    function Create: MachineLearning_ITensorUInt8Bit; overload; safecall;
    function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt8Bit; overload; safecall;
    function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit; safecall;
    function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorUInt8Bit; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.AI.MachineLearning.ITensorUInt8BitStatics2
  [WinRTClassNameAttribute(SWindows_AI_MachineLearning_TensorUInt8Bit)]
  MachineLearning_ITensorUInt8BitStatics2 = interface(IInspectable)
  ['{2BA042D6-373E-5A3A-A2FC-A6C41BD52789}']
    function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit; safecall;
    function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt8Bit; safecall;
  end;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolClientContextFactory
  ModelContextProtocol_IModelContextProtocolClientContextFactory = interface(IInspectable)
  ['{EFB2BA31-148C-5AD7-AB8F-4F0E6154FEDB}']
  end;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolServerCatalogFactory
  ModelContextProtocol_IModelContextProtocolServerCatalogFactory = interface(IInspectable)
  ['{6E5D0E8F-77E1-5A9D-B980-0779B3B128BA}']
  end;

  // Windows.AI.ModelContextProtocol.IModelContextProtocolServerInfoFactory
  ModelContextProtocol_IModelContextProtocolServerInfoFactory = interface(IInspectable)
  ['{C93EE14E-E477-5A65-BD80-2A7860DE7EAD}']
  end;

  // Windows.AI.MachineLearning.ImageFeatureValue
  // DualAPI
  // Implements: Windows.AI.MachineLearning.IImageFeatureValue
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Statics: "Windows.AI.MachineLearning.IImageFeatureValueStatics"
  TMachineLearning_ImageFeatureValue = class(TWinRTGenericImportS<MachineLearning_IImageFeatureValueStatics>)
  public
    {$REGION 'MachineLearning_IImageFeatureValueStatics'}
    class function CreateFromVideoFrame(image: IVideoFrame): MachineLearning_IImageFeatureValue; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.LearningModel
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ILearningModel
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ILearningModelStatics"
  TMachineLearning_LearningModel = class(TWinRTGenericImportS<MachineLearning_ILearningModelStatics>)
  public
    {$REGION 'MachineLearning_ILearningModelStatics'}
    class function LoadFromStorageFileAsync(modelFile: IStorageFile): IAsyncOperation_1__MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromStreamAsync(modelStream: IRandomAccessStreamReference): IAsyncOperation_1__MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromFilePath(filePath: HSTRING): MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromStream(modelStream: IRandomAccessStreamReference): MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromStorageFileAsync(modelFile: IStorageFile; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromStreamAsync(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromFilePath(filePath: HSTRING; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel; overload; static; inline;
    class function LoadFromStream(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.LearningModelBinding
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ILearningModelBinding
  // Implements: Windows.Foundation.Collections.IMapView`2<String,Object>
  // Implements: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  // Factory: "Windows.AI.MachineLearning.ILearningModelBindingFactory"
  TMachineLearning_LearningModelBinding = class(TWinRTGenericImportF<MachineLearning_ILearningModelBindingFactory>)
  public
    {$REGION 'MachineLearning_ILearningModelBindingFactory'}
    class function CreateFromSession(session: MachineLearning_ILearningModelSession): MachineLearning_ILearningModelBinding; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.LearningModelDevice
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ILearningModelDevice
  // Statics: "Windows.AI.MachineLearning.ILearningModelDeviceStatics"
  // Factory: "Windows.AI.MachineLearning.ILearningModelDeviceFactory"
  TMachineLearning_LearningModelDevice = class(TWinRTGenericImportFS<MachineLearning_ILearningModelDeviceFactory, MachineLearning_ILearningModelDeviceStatics>)
  public
    {$REGION 'MachineLearning_ILearningModelDeviceStatics'}
    class function CreateFromDirect3D11Device(device: DirectX_Direct3D11_IDirect3DDevice): MachineLearning_ILearningModelDevice; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ILearningModelDeviceFactory'}
    class function Create(deviceKind: MachineLearning_LearningModelDeviceKind): MachineLearning_ILearningModelDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.LearningModelSession
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ILearningModelSession
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.AI.MachineLearning.ILearningModelSessionFactory"
  // Factory: "Windows.AI.MachineLearning.ILearningModelSessionFactory2"
  TMachineLearning_LearningModelSession = class(TWinRTGenericImportF2<MachineLearning_ILearningModelSessionFactory, MachineLearning_ILearningModelSessionFactory2>)
  public
    {$REGION 'MachineLearning_ILearningModelSessionFactory'}
    class function CreateFromModel(model: MachineLearning_ILearningModel): MachineLearning_ILearningModelSession; static; inline;
    class function CreateFromModelOnDevice(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice): MachineLearning_ILearningModelSession; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ILearningModelSessionFactory2'}
    class function CreateFromModelOnDeviceWithSessionOptions(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice; learningModelSessionOptions: MachineLearning_ILearningModelSessionOptions): MachineLearning_ILearningModelSession; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.LearningModelSessionOptions
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ILearningModelSessionOptions
  // Implements: Windows.AI.MachineLearning.ILearningModelSessionOptions2
  // Implements: Windows.AI.MachineLearning.ILearningModelSessionOptions3
  // Instantiable: "MachineLearning_ILearningModelSessionOptions"
  TMachineLearning_LearningModelSessionOptions = class(TWinRTGenericImportI<MachineLearning_ILearningModelSessionOptions>) end;

  // Windows.AI.MachineLearning.TensorBoolean
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorBoolean
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorBooleanStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorBooleanStatics2"
  TMachineLearning_TensorBoolean = class(TWinRTGenericImportS2<MachineLearning_ITensorBooleanStatics, MachineLearning_ITensorBooleanStatics2>)
  public
    {$REGION 'MachineLearning_ITensorBooleanStatics'}
    class function Create: MachineLearning_ITensorBoolean; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorBoolean; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Boolean): MachineLearning_ITensorBoolean; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorBooleanStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorBoolean; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorDouble
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorDouble
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorDoubleStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorDoubleStatics2"
  TMachineLearning_TensorDouble = class(TWinRTGenericImportS2<MachineLearning_ITensorDoubleStatics, MachineLearning_ITensorDoubleStatics2>)
  public
    {$REGION 'MachineLearning_ITensorDoubleStatics'}
    class function Create: MachineLearning_ITensorDouble; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorDouble; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Double): MachineLearning_ITensorDouble; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorDoubleStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorDouble; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorFloat
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorFloat
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorFloatStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorFloatStatics2"
  TMachineLearning_TensorFloat = class(TWinRTGenericImportS2<MachineLearning_ITensorFloatStatics, MachineLearning_ITensorFloatStatics2>)
  public
    {$REGION 'MachineLearning_ITensorFloatStatics'}
    class function Create: MachineLearning_ITensorFloat; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorFloatStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorFloat16Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorFloat16Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorFloat16BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorFloat16BitStatics2"
  TMachineLearning_TensorFloat16Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorFloat16BitStatics, MachineLearning_ITensorFloat16BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorFloat16BitStatics'}
    class function Create: MachineLearning_ITensorFloat16Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat16Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat16Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorFloat16BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat16Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorInt16Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorInt16Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorInt16BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorInt16BitStatics2"
  TMachineLearning_TensorInt16Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorInt16BitStatics, MachineLearning_ITensorInt16BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorInt16BitStatics'}
    class function Create: MachineLearning_ITensorInt16Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt16Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__SmallInt): MachineLearning_ITensorInt16Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorInt16BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt16Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorInt32Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorInt32Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorInt32BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorInt32BitStatics2"
  TMachineLearning_TensorInt32Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorInt32BitStatics, MachineLearning_ITensorInt32BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorInt32BitStatics'}
    class function Create: MachineLearning_ITensorInt32Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt32Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Integer): MachineLearning_ITensorInt32Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorInt32BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt32Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorInt64Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorInt64Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorInt64BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorInt64BitStatics2"
  TMachineLearning_TensorInt64Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorInt64BitStatics, MachineLearning_ITensorInt64BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorInt64BitStatics'}
    class function Create: MachineLearning_ITensorInt64Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt64Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Int64): MachineLearning_ITensorInt64Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorInt64BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt64Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorInt8Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorInt8Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorInt8BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorInt8BitStatics2"
  TMachineLearning_TensorInt8Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorInt8BitStatics, MachineLearning_ITensorInt8BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorInt8BitStatics'}
    class function Create: MachineLearning_ITensorInt8Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt8Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorInt8Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorInt8BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt8Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorString
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorString
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorStringStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorStringStatics2"
  TMachineLearning_TensorString = class(TWinRTGenericImportS2<MachineLearning_ITensorStringStatics, MachineLearning_ITensorStringStatics2>)
  public
    {$REGION 'MachineLearning_ITensorStringStatics'}
    class function Create: MachineLearning_ITensorString; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorString; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__HSTRING): MachineLearning_ITensorString; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorStringStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorUInt16Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorUInt16Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorUInt16BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorUInt16BitStatics2"
  TMachineLearning_TensorUInt16Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorUInt16BitStatics, MachineLearning_ITensorUInt16BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorUInt16BitStatics'}
    class function Create: MachineLearning_ITensorUInt16Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt16Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Word): MachineLearning_ITensorUInt16Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorUInt16BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt16Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorUInt32Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorUInt32Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorUInt32BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorUInt32BitStatics2"
  TMachineLearning_TensorUInt32Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorUInt32BitStatics, MachineLearning_ITensorUInt32BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorUInt32BitStatics'}
    class function Create: MachineLearning_ITensorUInt32Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt32Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Cardinal): MachineLearning_ITensorUInt32Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorUInt32BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt32Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorUInt64Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorUInt64Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorUInt64BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorUInt64BitStatics2"
  TMachineLearning_TensorUInt64Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorUInt64BitStatics, MachineLearning_ITensorUInt64BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorUInt64BitStatics'}
    class function Create: MachineLearning_ITensorUInt64Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt64Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__UInt64): MachineLearning_ITensorUInt64Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorUInt64BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt64Bit; static; inline;
    {$ENDREGION}
 end;

  // Windows.AI.MachineLearning.TensorUInt8Bit
  // DualAPI
  // Implements: Windows.AI.MachineLearning.ITensorUInt8Bit
  // Implements: Windows.AI.MachineLearning.ITensor
  // Implements: Windows.AI.MachineLearning.ILearningModelFeatureValue
  // Implements: Windows.Foundation.IMemoryBuffer
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.AI.MachineLearning.ITensorUInt8BitStatics"
  // Statics: "Windows.AI.MachineLearning.ITensorUInt8BitStatics2"
  TMachineLearning_TensorUInt8Bit = class(TWinRTGenericImportS2<MachineLearning_ITensorUInt8BitStatics, MachineLearning_ITensorUInt8BitStatics2>)
  public
    {$REGION 'MachineLearning_ITensorUInt8BitStatics'}
    class function Create: MachineLearning_ITensorUInt8Bit; overload; static; inline;
    class function Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt8Bit; overload; static; inline;
    class function CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit; static; inline;
    class function CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorUInt8Bit; static; inline;
    {$ENDREGION}
    {$REGION 'MachineLearning_ITensorUInt8BitStatics2'}
    class function CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit; static; inline;
    class function CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt8Bit; static; inline;
    {$ENDREGION}
 end;

implementation

{ TMachineLearning_ImageFeatureValue }

{$REGION 'Windows.AI.MachineLearning.IImageFeatureValueStatics'}
class function TMachineLearning_ImageFeatureValue.CreateFromVideoFrame(image: IVideoFrame): MachineLearning_IImageFeatureValue;
begin
  Result := Statics.CreateFromVideoFrame(image);
end;
{$ENDREGION}

{ TMachineLearning_LearningModel }

{$REGION 'Windows.AI.MachineLearning.ILearningModelStatics'}
class function TMachineLearning_LearningModel.LoadFromStorageFileAsync(modelFile: IStorageFile): IAsyncOperation_1__MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStorageFileAsync(modelFile);
end;

class function TMachineLearning_LearningModel.LoadFromStreamAsync(modelStream: IRandomAccessStreamReference): IAsyncOperation_1__MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStreamAsync(modelStream);
end;

class function TMachineLearning_LearningModel.LoadFromFilePath(filePath: HSTRING): MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromFilePath(filePath);
end;

class function TMachineLearning_LearningModel.LoadFromStream(modelStream: IRandomAccessStreamReference): MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStream(modelStream);
end;

class function TMachineLearning_LearningModel.LoadFromStorageFileAsync(modelFile: IStorageFile; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStorageFileAsync(modelFile, operatorProvider);
end;

class function TMachineLearning_LearningModel.LoadFromStreamAsync(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): IAsyncOperation_1__MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStreamAsync(modelStream, operatorProvider);
end;

class function TMachineLearning_LearningModel.LoadFromFilePath(filePath: HSTRING; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromFilePath(filePath, operatorProvider);
end;

class function TMachineLearning_LearningModel.LoadFromStream(modelStream: IRandomAccessStreamReference; operatorProvider: MachineLearning_ILearningModelOperatorProvider): MachineLearning_ILearningModel;
begin
  Result := Statics.LoadFromStream(modelStream, operatorProvider);
end;
{$ENDREGION}

{ TMachineLearning_LearningModelBinding }

{$REGION 'Windows.AI.MachineLearning.ILearningModelBindingFactory'}
// Factory: "Windows.AI.MachineLearning.ILearningModelBindingFactory"
// -> MachineLearning_ILearningModelBindingFactory

class function TMachineLearning_LearningModelBinding.CreateFromSession(session: MachineLearning_ILearningModelSession): MachineLearning_ILearningModelBinding;
begin
  Result := Factory.CreateFromSession(session);
end;
{$ENDREGION}

{ TMachineLearning_LearningModelDevice }

{$REGION 'Windows.AI.MachineLearning.ILearningModelDeviceStatics'}
class function TMachineLearning_LearningModelDevice.CreateFromDirect3D11Device(device: DirectX_Direct3D11_IDirect3DDevice): MachineLearning_ILearningModelDevice;
begin
  Result := Statics.CreateFromDirect3D11Device(device);
end;
{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ILearningModelDeviceFactory'}
// Factory: "Windows.AI.MachineLearning.ILearningModelDeviceFactory"
// -> MachineLearning_ILearningModelDeviceFactory

class function TMachineLearning_LearningModelDevice.Create(deviceKind: MachineLearning_LearningModelDeviceKind): MachineLearning_ILearningModelDevice;
begin
  Result := Factory.Create(deviceKind);
end;
{$ENDREGION}

{ TMachineLearning_LearningModelSession }

{$REGION 'Windows.AI.MachineLearning.ILearningModelSessionFactory'}
// Factory: "Windows.AI.MachineLearning.ILearningModelSessionFactory"
// -> MachineLearning_ILearningModelSessionFactory

class function TMachineLearning_LearningModelSession.CreateFromModel(model: MachineLearning_ILearningModel): MachineLearning_ILearningModelSession;
begin
  Result := Factory.CreateFromModel(model);
end;

class function TMachineLearning_LearningModelSession.CreateFromModelOnDevice(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice): MachineLearning_ILearningModelSession;
begin
  Result := Factory.CreateFromModelOnDevice(model, deviceToRunOn);
end;
{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ILearningModelSessionFactory2'}
// Factory: "Windows.AI.MachineLearning.ILearningModelSessionFactory2"
// -> MachineLearning_ILearningModelSessionFactory2

class function TMachineLearning_LearningModelSession.CreateFromModelOnDeviceWithSessionOptions(model: MachineLearning_ILearningModel; deviceToRunOn: MachineLearning_ILearningModelDevice; learningModelSessionOptions: MachineLearning_ILearningModelSessionOptions): MachineLearning_ILearningModelSession;
begin
  Result := Factory2.CreateFromModelOnDeviceWithSessionOptions(model, deviceToRunOn, learningModelSessionOptions);
end;
{$ENDREGION}

{ TMachineLearning_LearningModelSessionOptions }

{ TMachineLearning_TensorBoolean }

{$REGION 'Windows.AI.MachineLearning.ITensorBooleanStatics'}
class function TMachineLearning_TensorBoolean.Create: MachineLearning_ITensorBoolean;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorBoolean.Create(shape: IIterable_1__Int64): MachineLearning_ITensorBoolean;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorBoolean.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorBoolean.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Boolean): MachineLearning_ITensorBoolean;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorBooleanStatics2'}
class function TMachineLearning_TensorBoolean.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PBoolean): MachineLearning_ITensorBoolean;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorBoolean.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorBoolean;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorDouble }

{$REGION 'Windows.AI.MachineLearning.ITensorDoubleStatics'}
class function TMachineLearning_TensorDouble.Create: MachineLearning_ITensorDouble;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorDouble.Create(shape: IIterable_1__Int64): MachineLearning_ITensorDouble;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorDouble.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorDouble.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Double): MachineLearning_ITensorDouble;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorDoubleStatics2'}
class function TMachineLearning_TensorDouble.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PDouble): MachineLearning_ITensorDouble;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorDouble.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorDouble;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorFloat }

{$REGION 'Windows.AI.MachineLearning.ITensorFloatStatics'}
class function TMachineLearning_TensorFloat.Create: MachineLearning_ITensorFloat;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorFloat.Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorFloat.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorFloat.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorFloatStatics2'}
class function TMachineLearning_TensorFloat.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorFloat.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorFloat16Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorFloat16BitStatics'}
class function TMachineLearning_TensorFloat16Bit.Create: MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorFloat16Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorFloat16Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorFloat16Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Single): MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorFloat16BitStatics2'}
class function TMachineLearning_TensorFloat16Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSingle): MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorFloat16Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorFloat16Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorInt16Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorInt16BitStatics'}
class function TMachineLearning_TensorInt16Bit.Create: MachineLearning_ITensorInt16Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorInt16Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt16Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorInt16Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorInt16Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__SmallInt): MachineLearning_ITensorInt16Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorInt16BitStatics2'}
class function TMachineLearning_TensorInt16Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PSmallInt): MachineLearning_ITensorInt16Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorInt16Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt16Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorInt32Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorInt32BitStatics'}
class function TMachineLearning_TensorInt32Bit.Create: MachineLearning_ITensorInt32Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorInt32Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt32Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorInt32Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorInt32Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Integer): MachineLearning_ITensorInt32Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorInt32BitStatics2'}
class function TMachineLearning_TensorInt32Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInteger): MachineLearning_ITensorInt32Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorInt32Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt32Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorInt64Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorInt64BitStatics'}
class function TMachineLearning_TensorInt64Bit.Create: MachineLearning_ITensorInt64Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorInt64Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt64Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorInt64Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorInt64Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Int64): MachineLearning_ITensorInt64Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorInt64BitStatics2'}
class function TMachineLearning_TensorInt64Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PInt64): MachineLearning_ITensorInt64Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorInt64Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt64Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorInt8Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorInt8BitStatics'}
class function TMachineLearning_TensorInt8Bit.Create: MachineLearning_ITensorInt8Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorInt8Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorInt8Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorInt8Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorInt8Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorInt8Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorInt8BitStatics2'}
class function TMachineLearning_TensorInt8Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorInt8Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorInt8Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorInt8Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorString }

{$REGION 'Windows.AI.MachineLearning.ITensorStringStatics'}
class function TMachineLearning_TensorString.Create: MachineLearning_ITensorString;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorString.Create(shape: IIterable_1__Int64): MachineLearning_ITensorString;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorString.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorString.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__HSTRING): MachineLearning_ITensorString;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorStringStatics2'}
class function TMachineLearning_TensorString.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PHSTRING): MachineLearning_ITensorString;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;
{$ENDREGION}

{ TMachineLearning_TensorUInt16Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorUInt16BitStatics'}
class function TMachineLearning_TensorUInt16Bit.Create: MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorUInt16Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorUInt16Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt16Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Word): MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorUInt16BitStatics2'}
class function TMachineLearning_TensorUInt16Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PWord): MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt16Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt16Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorUInt32Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorUInt32BitStatics'}
class function TMachineLearning_TensorUInt32Bit.Create: MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorUInt32Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorUInt32Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt32Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Cardinal): MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorUInt32BitStatics2'}
class function TMachineLearning_TensorUInt32Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PCardinal): MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt32Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt32Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorUInt64Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorUInt64BitStatics'}
class function TMachineLearning_TensorUInt64Bit.Create: MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorUInt64Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorUInt64Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt64Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__UInt64): MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorUInt64BitStatics2'}
class function TMachineLearning_TensorUInt64Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PUInt64): MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt64Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt64Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

{ TMachineLearning_TensorUInt8Bit }

{$REGION 'Windows.AI.MachineLearning.ITensorUInt8BitStatics'}
class function TMachineLearning_TensorUInt8Bit.Create: MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics.Create;
end;

class function TMachineLearning_TensorUInt8Bit.Create(shape: IIterable_1__Int64): MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics.Create(shape);
end;

class function TMachineLearning_TensorUInt8Bit.CreateFromArray(shape: IIterable_1__Int64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics.CreateFromArray(shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt8Bit.CreateFromIterable(shape: IIterable_1__Int64; data: IIterable_1__Byte): MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics.CreateFromIterable(shape, data);
end;

{$ENDREGION}

{$REGION 'Windows.AI.MachineLearning.ITensorUInt8BitStatics2'}
class function TMachineLearning_TensorUInt8Bit.CreateFromShapeArrayAndDataArray(shapeSize: Cardinal; shape: PInt64; dataSize: Cardinal; data: PByte): MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics2.CreateFromShapeArrayAndDataArray(shapeSize, shape, dataSize, data);
end;

class function TMachineLearning_TensorUInt8Bit.CreateFromBuffer(shapeSize: Cardinal; shape: PInt64; buffer: IBuffer): MachineLearning_ITensorUInt8Bit;
begin
  Result := Statics2.CreateFromBuffer(shapeSize, shape, buffer);
end;
{$ENDREGION}

end.
