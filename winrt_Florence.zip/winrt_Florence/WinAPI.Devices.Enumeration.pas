{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Devices.Enumeration;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.UI,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  IDeviceInformation = Winapi.CommonTypes.IDeviceInformation;
  PIDeviceInformation = Winapi.CommonTypes.PIDeviceInformation;
  IDeviceInformationUpdate = Winapi.CommonTypes.IDeviceInformationUpdate;
  PIDeviceInformationUpdate = Winapi.CommonTypes.PIDeviceInformationUpdate;
  IDevicePickerAppearance = Winapi.CommonTypes.IDevicePickerAppearance;
  PIDevicePickerAppearance = Winapi.CommonTypes.PIDevicePickerAppearance;
  IEnclosureLocation = Winapi.CommonTypes.IEnclosureLocation;
  PIEnclosureLocation = Winapi.CommonTypes.PIEnclosureLocation;
  Panel = Winapi.CommonTypes.Panel;
  PPanel = Winapi.CommonTypes.PPanel;

  // Forward declarations for interfaces

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.DeviceAccessStatus>
  AsyncOperationCompletedHandler_1__DeviceAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__DeviceAccessStatus = ^AsyncOperationCompletedHandler_1__DeviceAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.DeviceAccessStatus>
  IAsyncOperation_1__DeviceAccessStatus = interface;
  PIAsyncOperation_1__DeviceAccessStatus = ^IAsyncOperation_1__DeviceAccessStatus;

  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs
  IDeviceAccessChangedEventArgs = interface;
  PIDeviceAccessChangedEventArgs = ^IDeviceAccessChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceAccessInformation,Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs>
  TypedEventHandler_2__IDeviceAccessInformation__IDeviceAccessChangedEventArgs = interface;
  PTypedEventHandler_2__IDeviceAccessInformation__IDeviceAccessChangedEventArgs = ^TypedEventHandler_2__IDeviceAccessInformation__IDeviceAccessChangedEventArgs;

  // Windows.Devices.Enumeration.IDeviceAccessInformation
  IDeviceAccessInformation = interface;
  PIDeviceAccessInformation = ^IDeviceAccessInformation;

  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs2
  IDeviceAccessChangedEventArgs2 = interface;
  PIDeviceAccessChangedEventArgs2 = ^IDeviceAccessChangedEventArgs2;

  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs3
  IDeviceAccessChangedEventArgs3 = interface;
  PIDeviceAccessChangedEventArgs3 = ^IDeviceAccessChangedEventArgs3;

  // Windows.Devices.Enumeration.IDeviceDisconnectButtonClickedEventArgs
  IDeviceDisconnectButtonClickedEventArgs = interface;
  PIDeviceDisconnectButtonClickedEventArgs = ^IDeviceDisconnectButtonClickedEventArgs;

  // Windows.Devices.Enumeration.IDeviceEnumerationSettings
  IDeviceEnumerationSettings = interface;
  PIDeviceEnumerationSettings = ^IDeviceEnumerationSettings;

  // Windows.Devices.Enumeration.IDevicePairingResult
  IDevicePairingResult = interface;
  PIDevicePairingResult = ^IDevicePairingResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDevicePairingResult>
  AsyncOperationCompletedHandler_1__IDevicePairingResult = interface;
  PAsyncOperationCompletedHandler_1__IDevicePairingResult = ^AsyncOperationCompletedHandler_1__IDevicePairingResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDevicePairingResult>
  IAsyncOperation_1__IDevicePairingResult = interface;
  PIAsyncOperation_1__IDevicePairingResult = ^IAsyncOperation_1__IDevicePairingResult;

  // Windows.Devices.Enumeration.IDeviceInformationPairing
  IDeviceInformationPairing = interface;
  PIDeviceInformationPairing = ^IDeviceInformationPairing;

  // Windows.Devices.Enumeration.IDeviceInformation2
  IDeviceInformation2 = interface;
  PIDeviceInformation2 = ^IDeviceInformation2;

  // Windows.Devices.Enumeration.IDevicePairingSettings
  IDevicePairingSettings = interface;
  PIDevicePairingSettings = ^IDevicePairingSettings;

  // Windows.Devices.Enumeration.IDevicePairingRequestedEventArgs
  IDevicePairingRequestedEventArgs = interface;
  PIDevicePairingRequestedEventArgs = ^IDevicePairingRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceInformationCustomPairing,Windows.Devices.Enumeration.IDevicePairingRequestedEventArgs>
  TypedEventHandler_2__IDeviceInformationCustomPairing__IDevicePairingRequestedEventArgs = interface;
  PTypedEventHandler_2__IDeviceInformationCustomPairing__IDevicePairingRequestedEventArgs = ^TypedEventHandler_2__IDeviceInformationCustomPairing__IDevicePairingRequestedEventArgs;

  // Windows.Devices.Enumeration.IDeviceInformationCustomPairing
  IDeviceInformationCustomPairing = interface;
  PIDeviceInformationCustomPairing = ^IDeviceInformationCustomPairing;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.IDeviceInformation>
  IIterator_1__IDeviceInformation = interface;
  PIIterator_1__IDeviceInformation = ^IIterator_1__IDeviceInformation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.IDeviceInformation>
  IIterable_1__IDeviceInformation = interface;
  PIIterable_1__IDeviceInformation = ^IIterable_1__IDeviceInformation;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>
  IVectorView_1__IDeviceInformation = interface;
  PIVectorView_1__IDeviceInformation = ^IVectorView_1__IDeviceInformation;

  // Windows.Devices.Enumeration.IDeviceUnpairingResult
  IDeviceUnpairingResult = interface;
  PIDeviceUnpairingResult = ^IDeviceUnpairingResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDeviceUnpairingResult>
  AsyncOperationCompletedHandler_1__IDeviceUnpairingResult = interface;
  PAsyncOperationCompletedHandler_1__IDeviceUnpairingResult = ^AsyncOperationCompletedHandler_1__IDeviceUnpairingResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDeviceUnpairingResult>
  IAsyncOperation_1__IDeviceUnpairingResult = interface;
  PIAsyncOperation_1__IDeviceUnpairingResult = ^IAsyncOperation_1__IDeviceUnpairingResult;

  // Windows.Devices.Enumeration.IDeviceInformationPairing2
  IDeviceInformationPairing2 = interface;
  PIDeviceInformationPairing2 = ^IDeviceInformationPairing2;

  // Windows.Devices.Enumeration.IDeviceInformationPairingStatics
  IDeviceInformationPairingStatics = interface;
  PIDeviceInformationPairingStatics = ^IDeviceInformationPairingStatics;

  // Windows.Devices.Enumeration.IDeviceInformationPairingStatics2
  IDeviceInformationPairingStatics2 = interface;
  PIDeviceInformationPairingStatics2 = ^IDeviceInformationPairingStatics2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDeviceInformation>
  AsyncOperationCompletedHandler_1__IDeviceInformation = interface;
  PAsyncOperationCompletedHandler_1__IDeviceInformation = ^AsyncOperationCompletedHandler_1__IDeviceInformation;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDeviceInformation>
  IAsyncOperation_1__IDeviceInformation = interface;
  PIAsyncOperation_1__IDeviceInformation = ^IAsyncOperation_1__IDeviceInformation;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation = ^AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>>
  IAsyncOperation_1__IVectorView_1__IDeviceInformation = interface;
  PIAsyncOperation_1__IVectorView_1__IDeviceInformation = ^IAsyncOperation_1__IVectorView_1__IDeviceInformation;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Windows.Devices.Enumeration.IDeviceInformation>
  TypedEventHandler_2__IDeviceWatcher__IDeviceInformation = interface;
  PTypedEventHandler_2__IDeviceWatcher__IDeviceInformation = ^TypedEventHandler_2__IDeviceWatcher__IDeviceInformation;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Windows.Devices.Enumeration.IDeviceInformationUpdate>
  TypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate = interface;
  PTypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate = ^TypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Object>
  TypedEventHandler_2__IDeviceWatcher__IInspectable = interface;
  PTypedEventHandler_2__IDeviceWatcher__IInspectable = ^TypedEventHandler_2__IDeviceWatcher__IInspectable;

  // Windows.Devices.Enumeration.IDeviceWatcher
  IDeviceWatcher = interface;
  PIDeviceWatcher = ^IDeviceWatcher;

  // Windows.Devices.Enumeration.IDeviceInformationStatics
  IDeviceInformationStatics = interface;
  PIDeviceInformationStatics = ^IDeviceInformationStatics;

  // Windows.Devices.Enumeration.IDeviceInformationStatics2
  IDeviceInformationStatics2 = interface;
  PIDeviceInformationStatics2 = ^IDeviceInformationStatics2;

  // Windows.Devices.Enumeration.IDeviceInformationStatics3
  IDeviceInformationStatics3 = interface;
  PIDeviceInformationStatics3 = ^IDeviceInformationStatics3;

  // Windows.Devices.Enumeration.IDeviceInformationUpdate2
  IDeviceInformationUpdate2 = interface;
  PIDeviceInformationUpdate2 = ^IDeviceInformationUpdate2;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.DeviceClass>
  IIterator_1__DeviceClass = interface;
  PIIterator_1__DeviceClass = ^IIterator_1__DeviceClass;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.DeviceClass>
  IIterable_1__DeviceClass = interface;
  PIIterable_1__DeviceClass = ^IIterable_1__DeviceClass;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.DeviceClass>
  IVectorView_1__DeviceClass = interface;
  PIVectorView_1__DeviceClass = ^IVectorView_1__DeviceClass;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Enumeration.DeviceClass>
  IVector_1__DeviceClass = interface;
  PIVector_1__DeviceClass = ^IVector_1__DeviceClass;

  // Windows.Devices.Enumeration.IDevicePickerFilter
  IDevicePickerFilter = interface;
  PIDevicePickerFilter = ^IDevicePickerFilter;

  // Windows.Devices.Enumeration.IDeviceSelectedEventArgs
  IDeviceSelectedEventArgs = interface;
  PIDeviceSelectedEventArgs = ^IDeviceSelectedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Windows.Devices.Enumeration.IDeviceSelectedEventArgs>
  TypedEventHandler_2__IDevicePicker__IDeviceSelectedEventArgs = interface;
  PTypedEventHandler_2__IDevicePicker__IDeviceSelectedEventArgs = ^TypedEventHandler_2__IDevicePicker__IDeviceSelectedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Windows.Devices.Enumeration.IDeviceDisconnectButtonClickedEventArgs>
  TypedEventHandler_2__IDevicePicker__IDeviceDisconnectButtonClickedEventArgs = interface;
  PTypedEventHandler_2__IDevicePicker__IDeviceDisconnectButtonClickedEventArgs = ^TypedEventHandler_2__IDevicePicker__IDeviceDisconnectButtonClickedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Object>
  TypedEventHandler_2__IDevicePicker__IInspectable = interface;
  PTypedEventHandler_2__IDevicePicker__IInspectable = ^TypedEventHandler_2__IDevicePicker__IInspectable;

  // Windows.Devices.Enumeration.IDevicePicker
  IDevicePicker = interface;
  PIDevicePicker = ^IDevicePicker;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.DeviceWatcherEventKind>
  IIterator_1__DeviceWatcherEventKind = interface;
  PIIterator_1__DeviceWatcherEventKind = ^IIterator_1__DeviceWatcherEventKind;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.DeviceWatcherEventKind>
  IIterable_1__DeviceWatcherEventKind = interface;
  PIIterable_1__DeviceWatcherEventKind = ^IIterable_1__DeviceWatcherEventKind;

  // Windows.Devices.Enumeration.IEnclosureLocation2
  IEnclosureLocation2 = interface;
  PIEnclosureLocation2 = ^IEnclosureLocation2;

  // Windows.Devices.Enumeration.Pnp.IPnpObjectUpdate
  Pnp_IPnpObjectUpdate = interface;
  PPnp_IPnpObjectUpdate = ^Pnp_IPnpObjectUpdate;

  // Windows.Devices.Enumeration.Pnp.IPnpObject
  Pnp_IPnpObject = interface;
  PPnp_IPnpObject = ^Pnp_IPnpObject;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  AsyncOperationCompletedHandler_1__Pnp_IPnpObject = interface;
  PAsyncOperationCompletedHandler_1__Pnp_IPnpObject = ^AsyncOperationCompletedHandler_1__Pnp_IPnpObject;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IAsyncOperation_1__Pnp_IPnpObject = interface;
  PIAsyncOperation_1__Pnp_IPnpObject = ^IAsyncOperation_1__Pnp_IPnpObject;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IIterator_1__Pnp_IPnpObject = interface;
  PIIterator_1__Pnp_IPnpObject = ^IIterator_1__Pnp_IPnpObject;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IIterable_1__Pnp_IPnpObject = interface;
  PIIterable_1__Pnp_IPnpObject = ^IIterable_1__Pnp_IPnpObject;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IVectorView_1__Pnp_IPnpObject = interface;
  PIVectorView_1__Pnp_IPnpObject = ^IVectorView_1__Pnp_IPnpObject;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject = ^AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>>
  IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject = interface;
  PIAsyncOperation_1__IVectorView_1__Pnp_IPnpObject = ^IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Windows.Devices.Enumeration.Pnp.IPnpObject>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObject = interface;
  PTypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObject = ^TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObject;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Windows.Devices.Enumeration.Pnp.IPnpObjectUpdate>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate = interface;
  PTypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate = ^TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Object>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable = interface;
  PTypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable = ^TypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable;

  // Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher
  Pnp_IPnpObjectWatcher = interface;
  PPnp_IPnpObjectWatcher = ^Pnp_IPnpObjectWatcher;

  // Windows.Devices.Enumeration.Pnp.IPnpObjectStatics
  Pnp_IPnpObjectStatics = interface;
  PPnp_IPnpObjectStatics = ^Pnp_IPnpObjectStatics;

  // Windows.Devices.Enumeration Enums

  // Windows.Devices.Enumeration.DeviceAccessStatus
  DeviceAccessStatus = (
    Unspecified = 0,
    Allowed = 1,
    DeniedByUser = 2,
    DeniedBySystem = 3
  );
  PDeviceAccessStatus = ^DeviceAccessStatus;

  // Windows.Devices.Enumeration.DeviceClass
  DeviceClass = (
    All = 0,
    AudioCapture = 1,
    AudioRender = 2,
    PortableStorageDevice = 3,
    VideoCapture = 4,
    ImageScanner = 5,
    Location = 6
  );
  PDeviceClass = ^DeviceClass;

  // Windows.Devices.Enumeration.DeviceInformationKind
  DeviceInformationKind = (
    Unknown = 0,
    DeviceInterface = 1,
    DeviceContainer = 2,
    Device = 3,
    DeviceInterfaceClass = 4,
    AssociationEndpoint = 5,
    AssociationEndpointContainer = 6,
    AssociationEndpointService = 7,
    DevicePanel = 8,
    AssociationEndpointProtocol = 9
  );
  PDeviceInformationKind = ^DeviceInformationKind;

  // Windows.Devices.Enumeration.DevicePairingAddPairingSetMemberStatus
  DevicePairingAddPairingSetMemberStatus = (
    AddedToSet = 0,
    CouldNotBeAddedToSet = 1,
    SetDiscoveryNotAttemptedByProtocol = 2,
    SetDiscoveryCompletedByProtocol = 3,
    SetDiscoveryPartiallyCompletedByProtocol = 4,
    Failed = 5
  );
  PDevicePairingAddPairingSetMemberStatus = ^DevicePairingAddPairingSetMemberStatus;

  // Windows.Devices.Enumeration.DevicePairingKinds
  DevicePairingKinds = (
    None = 0,
    ConfirmOnly = 1,
    DisplayPin = 2,
    ProvidePin = 4,
    ConfirmPinMatch = 8,
    ProvidePasswordCredential = 16,
    ProvideAddress = 32
  );
  PDevicePairingKinds = ^DevicePairingKinds;

  // Windows.Devices.Enumeration.DevicePairingProtectionLevel
  DevicePairingProtectionLevel = (
    Default = 0,
    None = 1,
    Encryption = 2,
    EncryptionAndAuthentication = 3
  );
  PDevicePairingProtectionLevel = ^DevicePairingProtectionLevel;

  // Windows.Devices.Enumeration.DevicePairingResultStatus
  DevicePairingResultStatus = (
    Paired = 0,
    NotReadyToPair = 1,
    NotPaired = 2,
    AlreadyPaired = 3,
    ConnectionRejected = 4,
    TooManyConnections = 5,
    HardwareFailure = 6,
    AuthenticationTimeout = 7,
    AuthenticationNotAllowed = 8,
    AuthenticationFailure = 9,
    NoSupportedProfiles = 10,
    ProtectionLevelCouldNotBeMet = 11,
    AccessDenied = 12,
    InvalidCeremonyData = 13,
    PairingCanceled = 14,
    OperationAlreadyInProgress = 15,
    RequiredHandlerNotRegistered = 16,
    RejectedByHandler = 17,
    RemoteDeviceHasAssociation = 18,
    Failed = 19
  );
  PDevicePairingResultStatus = ^DevicePairingResultStatus;

  // Windows.Devices.Enumeration.DevicePickerDisplayStatusOptions
  DevicePickerDisplayStatusOptions = (
    None = 0,
    ShowProgress = 1,
    ShowDisconnectButton = 2,
    ShowRetryButton = 4
  );
  PDevicePickerDisplayStatusOptions = ^DevicePickerDisplayStatusOptions;

  // Windows.Devices.Enumeration.DeviceUnpairingResultStatus
  DeviceUnpairingResultStatus = (
    Unpaired = 0,
    AlreadyUnpaired = 1,
    OperationAlreadyInProgress = 2,
    AccessDenied = 3,
    Failed = 4
  );
  PDeviceUnpairingResultStatus = ^DeviceUnpairingResultStatus;

  // Windows.Devices.Enumeration.DeviceWatcherEventKind
  DeviceWatcherEventKind = (
    Add = 0,
    Update = 1,
    Remove = 2
  );
  PDeviceWatcherEventKind = ^DeviceWatcherEventKind;

  // Windows.Devices.Enumeration.DeviceWatcherStatus
  DeviceWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopping = 3,
    Stopped = 4,
    Aborted = 5
  );
  PDeviceWatcherStatus = ^DeviceWatcherStatus;

  // Windows.Devices.Enumeration.Pnp.PnpObjectType
  Pnp_PnpObjectType = (
    Unknown = 0,
    DeviceInterface = 1,
    DeviceContainer = 2,
    Device = 3,
    DeviceInterfaceClass = 4,
    AssociationEndpoint = 5,
    AssociationEndpointContainer = 6,
    AssociationEndpointService = 7,
    DevicePanel = 8,
    AssociationEndpointProtocol = 9
  );
  PPnp_PnpObjectType = ^Pnp_PnpObjectType;

  // Windows.Devices.Enumeration Interfaces

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.DeviceAccessStatus>
  AsyncOperationCompletedHandler_1__DeviceAccessStatus = interface(IUnknown)
  ['{EE154D83-805B-53E8-8469-90715036D013}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__DeviceAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.DeviceAccessStatus>
  IAsyncOperation_1__DeviceAccessStatus = interface(IInspectable)
  ['{C00BC2F2-A7F8-5F3F-80D1-2808EF6BCA10}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__DeviceAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__DeviceAccessStatus; safecall;
    function GetResults: DeviceAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__DeviceAccessStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs
  IDeviceAccessChangedEventArgs = interface(IInspectable)
  ['{DEDA0BCC-4F9D-4F58-9DBA-A9BC800408D5}']
    function get_Status: DeviceAccessStatus; safecall;
    property Status: DeviceAccessStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DeviceAccessInformation,Windows.Devices.Enumeration.DeviceAccessChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceAccessInformation,Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs>
  TypedEventHandler_2__IDeviceAccessInformation__IDeviceAccessChangedEventArgs = interface(IUnknown)
  ['{4C71D028-B793-5BCE-AE59-FA77F45A40D8}']
    procedure Invoke(sender: IDeviceAccessInformation; args: IDeviceAccessChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceAccessInformation
  IDeviceAccessInformation = interface(IInspectable)
  ['{0BAA9A73-6DE5-4915-8DDD-9A0554A6F545}']
    function add_AccessChanged(handler: TypedEventHandler_2__IDeviceAccessInformation__IDeviceAccessChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AccessChanged(cookie: EventRegistrationToken); safecall;
    function get_CurrentStatus: DeviceAccessStatus; safecall;
    property CurrentStatus: DeviceAccessStatus read get_CurrentStatus;
  end;

  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs2
  IDeviceAccessChangedEventArgs2 = interface(IInspectable)
  ['{82523262-934B-4B30-A178-ADC39F2F2BE3}']
    function get_Id: HSTRING; safecall;
    property Id: HSTRING read get_Id;
  end;

  // Windows.Devices.Enumeration.IDeviceAccessChangedEventArgs3
  IDeviceAccessChangedEventArgs3 = interface(IInspectable)
  ['{7580A878-7FD9-5CD7-8560-3C644B9B10DB}']
    function get_UserPromptRequired: Boolean; safecall;
    property UserPromptRequired: Boolean read get_UserPromptRequired;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceDisconnectButtonClickedEventArgs
  IDeviceDisconnectButtonClickedEventArgs = interface(IInspectable)
  ['{8E44B56D-F902-4A00-B536-F37992E6A2A7}']
    function get_Device: IDeviceInformation; safecall;
    property Device: IDeviceInformation read get_Device;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceEnumerationSettings
  IDeviceEnumerationSettings = interface(IInspectable)
  ['{F7710F66-9FF3-41C8-85EB-87F81148A30F}']
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDevicePairingResult
  IDevicePairingResult = interface(IInspectable)
  ['{072B02BF-DD95-4025-9B37-DE51ADBA37B7}']
    function get_Status: DevicePairingResultStatus; safecall;
    function get_ProtectionLevelUsed: DevicePairingProtectionLevel; safecall;
    property ProtectionLevelUsed: DevicePairingProtectionLevel read get_ProtectionLevelUsed;
    property Status: DevicePairingResultStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.DevicePairingResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDevicePairingResult>
  AsyncOperationCompletedHandler_1__IDevicePairingResult = interface(IUnknown)
  ['{7EE0247F-5F57-5CB2-B40E-18B5A211D6C3}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IDevicePairingResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.DevicePairingResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDevicePairingResult>
  IAsyncOperation_1__IDevicePairingResult = interface(IInspectable)
  ['{1002DB74-8948-591E-815D-E40B667599A3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IDevicePairingResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IDevicePairingResult; safecall;
    function GetResults: IDevicePairingResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IDevicePairingResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationPairing
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformationPairing)]
  IDeviceInformationPairing = interface(IInspectable)
  ['{2C4769F5-F684-40D5-8469-E8DBAAB70485}']
    function get_IsPaired: Boolean; safecall;
    function get_CanPair: Boolean; safecall;
    function PairAsync: IAsyncOperation_1__IDevicePairingResult; overload; safecall;
    function PairAsync(minProtectionLevel: DevicePairingProtectionLevel): IAsyncOperation_1__IDevicePairingResult; overload; safecall;
    property CanPair: Boolean read get_CanPair;
    property IsPaired: Boolean read get_IsPaired;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformation2
  IDeviceInformation2 = interface(IInspectable)
  ['{F156A638-7997-48D9-A10C-269D46533F48}']
    function get_Kind: DeviceInformationKind; safecall;
    function get_Pairing: IDeviceInformationPairing; safecall;
    property Kind: DeviceInformationKind read get_Kind;
    property Pairing: IDeviceInformationPairing read get_Pairing;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDevicePairingSettings
  IDevicePairingSettings = interface(IInspectable)
  ['{482CB27C-83BB-420E-BE51-6602B222DE54}']
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDevicePairingRequestedEventArgs
  IDevicePairingRequestedEventArgs = interface(IInspectable)
  ['{F717FC56-DE6B-487F-8376-0180ACA69963}']
    function get_DeviceInformation: IDeviceInformation; safecall;
    function get_PairingKind: DevicePairingKinds; safecall;
    function get_Pin: HSTRING; safecall;
    procedure Accept; overload; safecall;
    procedure Accept(pin: HSTRING); overload; safecall;
    function GetDeferral: IDeferral; safecall;
    property DeviceInformation: IDeviceInformation read get_DeviceInformation;
    property PairingKind: DevicePairingKinds read get_PairingKind;
    property Pin: HSTRING read get_Pin;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DeviceInformationCustomPairing,Windows.Devices.Enumeration.DevicePairingRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceInformationCustomPairing,Windows.Devices.Enumeration.IDevicePairingRequestedEventArgs>
  TypedEventHandler_2__IDeviceInformationCustomPairing__IDevicePairingRequestedEventArgs = interface(IUnknown)
  ['{FA65231F-4178-5DE1-B2CC-03E22D7702B4}']
    procedure Invoke(sender: IDeviceInformationCustomPairing; args: IDevicePairingRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationCustomPairing
  IDeviceInformationCustomPairing = interface(IInspectable)
  ['{85138C02-4EE6-4914-8370-107A39144C0E}']
    function PairAsync(pairingKindsSupported: DevicePairingKinds): IAsyncOperation_1__IDevicePairingResult; overload; safecall;
    function PairAsync(pairingKindsSupported: DevicePairingKinds; minProtectionLevel: DevicePairingProtectionLevel): IAsyncOperation_1__IDevicePairingResult; overload; safecall;
    function PairAsync(pairingKindsSupported: DevicePairingKinds; minProtectionLevel: DevicePairingProtectionLevel; devicePairingSettings: IDevicePairingSettings): IAsyncOperation_1__IDevicePairingResult; overload; safecall;
    function add_PairingRequested(handler: TypedEventHandler_2__IDeviceInformationCustomPairing__IDevicePairingRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PairingRequested(token: EventRegistrationToken); safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.DeviceInformation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.IDeviceInformation>
  IIterator_1__IDeviceInformation = interface(IInspectable)
  ['{6F85D843-E8AB-5B46-85D7-327C58D18712}']
    function get_Current: IDeviceInformation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIDeviceInformation): Cardinal; safecall;
    property Current: IDeviceInformation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.DeviceInformation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.IDeviceInformation>
  IIterable_1__IDeviceInformation = interface(IInspectable)
  ['{DD9F8A5D-EC98-5F4B-A3EA-9C8B5AD53C4B}']
    function First: IIterator_1__IDeviceInformation; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>
  IVectorView_1__IDeviceInformation = interface(IInspectable)
  ['{717AA701-AB02-5C8D-AD35-EE564CF8BB0E}']
    function GetAt(index: Cardinal): IDeviceInformation; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IDeviceInformation; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIDeviceInformation): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceUnpairingResult
  IDeviceUnpairingResult = interface(IInspectable)
  ['{66F44AD3-79D9-444B-92CF-A92EF72571C7}']
    function get_Status: DeviceUnpairingResultStatus; safecall;
    property Status: DeviceUnpairingResultStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.DeviceUnpairingResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDeviceUnpairingResult>
  AsyncOperationCompletedHandler_1__IDeviceUnpairingResult = interface(IUnknown)
  ['{9BBE6EB9-DB2D-5160-A20C-F0C265F20D8E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IDeviceUnpairingResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.DeviceUnpairingResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDeviceUnpairingResult>
  IAsyncOperation_1__IDeviceUnpairingResult = interface(IInspectable)
  ['{2BB4DF3D-BD7E-5FE0-9020-56DC0D30B935}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IDeviceUnpairingResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IDeviceUnpairingResult; safecall;
    function GetResults: IDeviceUnpairingResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IDeviceUnpairingResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationPairing2
  IDeviceInformationPairing2 = interface(IInspectable)
  ['{F68612FD-0AEE-4328-85CC-1C742BB1790D}']
    function get_ProtectionLevel: DevicePairingProtectionLevel; safecall;
    function get_Custom: IDeviceInformationCustomPairing; safecall;
    function PairAsync(minProtectionLevel: DevicePairingProtectionLevel; devicePairingSettings: IDevicePairingSettings): IAsyncOperation_1__IDevicePairingResult; safecall;
    function UnpairAsync: IAsyncOperation_1__IDeviceUnpairingResult; safecall;
    property Custom: IDeviceInformationCustomPairing read get_Custom;
    property ProtectionLevel: DevicePairingProtectionLevel read get_ProtectionLevel;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationPairingStatics
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformationPairing)]
  IDeviceInformationPairingStatics = interface(IInspectable)
  ['{E915C408-36D4-49A1-BF13-514173799B6B}']
    function TryRegisterForAllInboundPairingRequests(pairingKindsSupported: DevicePairingKinds): Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationPairingStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformationPairing)]
  IDeviceInformationPairingStatics2 = interface(IInspectable)
  ['{04DE5372-B7B7-476B-A74F-C5836A704D98}']
    function TryRegisterForAllInboundPairingRequestsWithProtectionLevel(pairingKindsSupported: DevicePairingKinds; minProtectionLevel: DevicePairingProtectionLevel): Boolean; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.DeviceInformation>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.IDeviceInformation>
  AsyncOperationCompletedHandler_1__IDeviceInformation = interface(IUnknown)
  ['{BB483DF2-7BB6-5923-A28D-8342EC30046B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IDeviceInformation; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.DeviceInformation>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.IDeviceInformation>
  IAsyncOperation_1__IDeviceInformation = interface(IInspectable)
  ['{07FAA053-EB2F-5CBA-B25B-D9D57BE6715F}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IDeviceInformation); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IDeviceInformation; safecall;
    function GetResults: IDeviceInformation; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IDeviceInformation read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.DeviceInformation>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation = interface(IUnknown)
  ['{703344C1-78B6-5DC8-BF48-DBF667102E2A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IDeviceInformation; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.DeviceInformation>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.IDeviceInformation>>
  IAsyncOperation_1__IVectorView_1__IDeviceInformation = interface(IInspectable)
  ['{F02F08F2-F30F-5B83-ACC5-57E1F9DAA0DD}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation; safecall;
    function GetResults: IVectorView_1__IDeviceInformation; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IDeviceInformation read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DeviceWatcher,Windows.Devices.Enumeration.DeviceInformation>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Windows.Devices.Enumeration.IDeviceInformation>
  TypedEventHandler_2__IDeviceWatcher__IDeviceInformation = interface(IUnknown)
  ['{03C5A07B-990C-5D09-B0B8-5734EAA38222}']
    procedure Invoke(sender: IDeviceWatcher; args: IDeviceInformation); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DeviceWatcher,Windows.Devices.Enumeration.DeviceInformationUpdate>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Windows.Devices.Enumeration.IDeviceInformationUpdate>
  TypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate = interface(IUnknown)
  ['{906F1254-79AD-54FC-93C4-CDB99B437899}']
    procedure Invoke(sender: IDeviceWatcher; args: IDeviceInformationUpdate); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DeviceWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDeviceWatcher,Object>
  TypedEventHandler_2__IDeviceWatcher__IInspectable = interface(IUnknown)
  ['{9234630F-1FF4-54F6-9E3F-AC20369B7725}']
    procedure Invoke(sender: IDeviceWatcher; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceWatcher
  IDeviceWatcher = interface(IInspectable)
  ['{C9EAB97D-8F6B-4F96-A9F4-ABC814E22271}']
    function add_Added(handler: TypedEventHandler_2__IDeviceWatcher__IDeviceInformation): EventRegistrationToken; safecall;
    procedure remove_Added(token: EventRegistrationToken); safecall;
    function add_Updated(handler: TypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate): EventRegistrationToken; safecall;
    procedure remove_Updated(token: EventRegistrationToken); safecall;
    function add_Removed(handler: TypedEventHandler_2__IDeviceWatcher__IDeviceInformationUpdate): EventRegistrationToken; safecall;
    procedure remove_Removed(token: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__IDeviceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(token: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__IDeviceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(token: EventRegistrationToken); safecall;
    function get_Status: DeviceWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: DeviceWatcherStatus read get_Status;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationStatics
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformation)]
  IDeviceInformationStatics = interface(IInspectable)
  ['{C17F100E-3A46-4A78-8013-769DC9B97390}']
    function CreateFromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IDeviceInformation; overload; safecall;
    function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IDeviceInformation; overload; safecall;
    function FindAllAsync: IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; safecall;
    function FindAllAsync(deviceClass: DeviceClass): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; safecall;
    function FindAllAsync(aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; safecall;
    function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; safecall;
    function CreateWatcher: IDeviceWatcher; overload; safecall;
    function CreateWatcher(deviceClass: DeviceClass): IDeviceWatcher; overload; safecall;
    function CreateWatcher(aqsFilter: HSTRING): IDeviceWatcher; overload; safecall;
    function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IDeviceWatcher; overload; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformation)]
  IDeviceInformationStatics2 = interface(IInspectable)
  ['{493B4F34-A84F-45FD-9167-15D1CB1BD1F9}']
    function GetAqsFilterFromDeviceClass(deviceClass: DeviceClass): HSTRING; safecall;
    function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IDeviceInformation; safecall;
    function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IVectorView_1__IDeviceInformation; safecall;
    function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IDeviceWatcher; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceInformationStatics3
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DeviceInformation)]
  IDeviceInformationStatics3 = interface(IInspectable)
  ['{25F06279-9364-5A6C-8A54-5D4A6D3D922A}']
    function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IDeviceInformation; safecall;
    function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IVectorView_1__IDeviceInformation; safecall;
    function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IDeviceWatcher; safecall;
  end;

  // Windows.Devices.Enumeration.IDeviceInformationUpdate2
  IDeviceInformationUpdate2 = interface(IInspectable)
  ['{5D9D148C-A873-485E-BAA6-AA620788E3CC}']
    function get_Kind: DeviceInformationKind; safecall;
    property Kind: DeviceInformationKind read get_Kind;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.DeviceClass>
  IIterator_1__DeviceClass = interface(IInspectable)
  ['{C3807283-1416-593C-955C-0B4A286FF7BB}']
    function get_Current: DeviceClass; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDeviceClass): Cardinal; safecall;
    property Current: DeviceClass read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.DeviceClass>
  IIterable_1__DeviceClass = interface(IInspectable)
  ['{47D4BE05-58F1-522E-81C6-975EB4131BB9}']
    function First: IIterator_1__DeviceClass; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.DeviceClass>
  IVectorView_1__DeviceClass = interface(IInspectable)
  ['{01A80A97-BD87-5C8A-97FD-D449C98BDAC6}']
    function GetAt(index: Cardinal): DeviceClass; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: DeviceClass; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDeviceClass): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Enumeration.DeviceClass>
  IVector_1__DeviceClass = interface(IInspectable)
  ['{EE662D37-B0EB-5729-9832-156FD2889D48}']
    function GetAt(index: Cardinal): DeviceClass; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__DeviceClass; safecall;
    function IndexOf(value: DeviceClass; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: DeviceClass); safecall;
    procedure InsertAt(index: Cardinal; value: DeviceClass); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: DeviceClass); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDeviceClass): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDeviceClass); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDevicePickerFilter
  IDevicePickerFilter = interface(IInspectable)
  ['{91DB92A2-57CB-48F1-9B59-A59B7A1F02A2}']
    function get_SupportedDeviceClasses: IVector_1__DeviceClass; safecall;
    function get_SupportedDeviceSelectors: IVector_1__HSTRING; safecall;
    property SupportedDeviceClasses: IVector_1__DeviceClass read get_SupportedDeviceClasses;
    property SupportedDeviceSelectors: IVector_1__HSTRING read get_SupportedDeviceSelectors;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDeviceSelectedEventArgs
  IDeviceSelectedEventArgs = interface(IInspectable)
  ['{269EDADE-1D2F-4940-8402-4156B81D3C77}']
    function get_SelectedDevice: IDeviceInformation; safecall;
    property SelectedDevice: IDeviceInformation read get_SelectedDevice;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DevicePicker,Windows.Devices.Enumeration.DeviceSelectedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Windows.Devices.Enumeration.IDeviceSelectedEventArgs>
  TypedEventHandler_2__IDevicePicker__IDeviceSelectedEventArgs = interface(IUnknown)
  ['{47E48C88-1C56-5B58-96A2-8E813D25077A}']
    procedure Invoke(sender: IDevicePicker; args: IDeviceSelectedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DevicePicker,Windows.Devices.Enumeration.DeviceDisconnectButtonClickedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Windows.Devices.Enumeration.IDeviceDisconnectButtonClickedEventArgs>
  TypedEventHandler_2__IDevicePicker__IDeviceDisconnectButtonClickedEventArgs = interface(IUnknown)
  ['{35DD0319-5723-506C-8896-1A28B82BE798}']
    procedure Invoke(sender: IDevicePicker; args: IDeviceDisconnectButtonClickedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.DevicePicker,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.IDevicePicker,Object>
  TypedEventHandler_2__IDevicePicker__IInspectable = interface(IUnknown)
  ['{62C6D98C-57EE-5BB8-A41C-958D20C3F3E8}']
    procedure Invoke(sender: IDevicePicker; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.IDevicePicker
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_DevicePicker)]
  IDevicePicker = interface(IInspectable)
  ['{84997AA2-034A-4440-8813-7D0BD479BF5A}']
    function get_Filter: IDevicePickerFilter; safecall;
    function get_Appearance: IDevicePickerAppearance; safecall;
    function get_RequestedProperties: IVector_1__HSTRING; safecall;
    function add_DeviceSelected(handler: TypedEventHandler_2__IDevicePicker__IDeviceSelectedEventArgs): EventRegistrationToken; safecall;
    procedure remove_DeviceSelected(token: EventRegistrationToken); safecall;
    function add_DisconnectButtonClicked(handler: TypedEventHandler_2__IDevicePicker__IDeviceDisconnectButtonClickedEventArgs): EventRegistrationToken; safecall;
    procedure remove_DisconnectButtonClicked(token: EventRegistrationToken); safecall;
    function add_DevicePickerDismissed(handler: TypedEventHandler_2__IDevicePicker__IInspectable): EventRegistrationToken; safecall;
    procedure remove_DevicePickerDismissed(token: EventRegistrationToken); safecall;
    procedure Show(selection: TRectF); overload; safecall;
    procedure Show(selection: TRectF; placement: Popups_Placement); overload; safecall;
    function PickSingleDeviceAsync(selection: TRectF): IAsyncOperation_1__IDeviceInformation; overload; safecall;
    function PickSingleDeviceAsync(selection: TRectF; placement: Popups_Placement): IAsyncOperation_1__IDeviceInformation; overload; safecall;
    procedure Hide; safecall;
    procedure SetDisplayStatus(device: IDeviceInformation; status: HSTRING; options: DevicePickerDisplayStatusOptions); safecall;
    property Appearance: IDevicePickerAppearance read get_Appearance;
    property Filter: IDevicePickerFilter read get_Filter;
    property RequestedProperties: IVector_1__HSTRING read get_RequestedProperties;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.DeviceWatcherEventKind>
  IIterator_1__DeviceWatcherEventKind = interface(IInspectable)
  ['{CB5CA9DB-CCD6-5103-A93D-C925C908838D}']
    function get_Current: DeviceWatcherEventKind; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDeviceWatcherEventKind): Cardinal; safecall;
    property Current: DeviceWatcherEventKind read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.DeviceWatcherEventKind>
  IIterable_1__DeviceWatcherEventKind = interface(IInspectable)
  ['{F04365AB-D3F3-5F85-A7DA-DC19CFF73D86}']
    function First: IIterator_1__DeviceWatcherEventKind; safecall;
  end;

  // Windows.Devices.Enumeration.IEnclosureLocation2
  IEnclosureLocation2 = interface(IInspectable)
  ['{2885995B-E07D-485D-8A9E-BDF29AEF4F66}']
    function get_RotationAngleInDegreesClockwise: Cardinal; safecall;
    property RotationAngleInDegreesClockwise: Cardinal read get_RotationAngleInDegreesClockwise;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.Pnp.IPnpObjectUpdate
  Pnp_IPnpObjectUpdate = interface(IInspectable)
  ['{6F59E812-001E-4844-BCC6-432886856A17}']
    function get_Type: Pnp_PnpObjectType; safecall;
    function get_Id: HSTRING; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    property Id: HSTRING read get_Id;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property &Type: Pnp_PnpObjectType read get_Type;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.Pnp.IPnpObject
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_Pnp_PnpObject)]
  Pnp_IPnpObject = interface(IInspectable)
  ['{95C66258-733B-4A8F-93A3-DB078AC870C1}']
    function get_Type: Pnp_PnpObjectType; safecall;
    function get_Id: HSTRING; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    procedure Update(updateInfo: Pnp_IPnpObjectUpdate); safecall;
    property Id: HSTRING read get_Id;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property &Type: Pnp_PnpObjectType read get_Type;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.Pnp.PnpObject>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  AsyncOperationCompletedHandler_1__Pnp_IPnpObject = interface(IUnknown)
  ['{9D615463-6879-521F-8E97-E66D3DDBC95E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Pnp_IPnpObject; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.Pnp.PnpObject>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IAsyncOperation_1__Pnp_IPnpObject = interface(IInspectable)
  ['{22B0FB93-30E6-501A-BD3B-9FA3063E9C16}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Pnp_IPnpObject); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Pnp_IPnpObject; safecall;
    function GetResults: Pnp_IPnpObject; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Pnp_IPnpObject read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.Pnp.PnpObject>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IIterator_1__Pnp_IPnpObject = interface(IInspectable)
  ['{6BB6D2F1-B5FB-57F0-8251-F20CDE5A6871}']
    function get_Current: Pnp_IPnpObject; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPnp_IPnpObject): Cardinal; safecall;
    property Current: Pnp_IPnpObject read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.Pnp.PnpObject>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IIterable_1__Pnp_IPnpObject = interface(IInspectable)
  ['{30B50092-36EE-53FF-9450-029004436C60}']
    function First: IIterator_1__Pnp_IPnpObject; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>
  IVectorView_1__Pnp_IPnpObject = interface(IInspectable)
  ['{5B091106-8910-5FE6-8C50-A27C65BD860C}']
    function GetAt(index: Cardinal): Pnp_IPnpObject; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Pnp_IPnpObject; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPnp_IPnpObject): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.PnpObject>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject = interface(IUnknown)
  ['{475B6D9E-7ABD-57D7-AA40-F180CF911EE8}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.PnpObject>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Enumeration.Pnp.IPnpObject>>
  IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject = interface(IInspectable)
  ['{0659EAB6-97A1-54FC-9356-FF15E3B0A8A8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject; safecall;
    function GetResults: IVectorView_1__Pnp_IPnpObject; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Pnp_IPnpObject read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.PnpObjectWatcher,Windows.Devices.Enumeration.Pnp.PnpObject>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Windows.Devices.Enumeration.Pnp.IPnpObject>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObject = interface(IUnknown)
  ['{D578EED2-58E5-5825-8AF2-12F89387B656}']
    procedure Invoke(sender: Pnp_IPnpObjectWatcher; args: Pnp_IPnpObject); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.PnpObjectWatcher,Windows.Devices.Enumeration.Pnp.PnpObjectUpdate>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Windows.Devices.Enumeration.Pnp.IPnpObjectUpdate>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate = interface(IUnknown)
  ['{AF8F929D-8058-5C38-A3D8-30AA7A08B588}']
    procedure Invoke(sender: Pnp_IPnpObjectWatcher; args: Pnp_IPnpObjectUpdate); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.PnpObjectWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher,Object>
  TypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable = interface(IUnknown)
  ['{2EE2B4C9-B696-5ECC-B29B-F1E0EF5FE1F7}']
    procedure Invoke(sender: Pnp_IPnpObjectWatcher; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Enumeration.Pnp.IPnpObjectWatcher
  Pnp_IPnpObjectWatcher = interface(IInspectable)
  ['{83C95CA8-4772-4A7A-ACA8-E48C42A89C44}']
    function add_Added(handler: TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObject): EventRegistrationToken; safecall;
    procedure remove_Added(token: EventRegistrationToken); safecall;
    function add_Updated(handler: TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate): EventRegistrationToken; safecall;
    procedure remove_Updated(token: EventRegistrationToken); safecall;
    function add_Removed(handler: TypedEventHandler_2__Pnp_IPnpObjectWatcher__Pnp_IPnpObjectUpdate): EventRegistrationToken; safecall;
    procedure remove_Removed(token: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(token: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__Pnp_IPnpObjectWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(token: EventRegistrationToken); safecall;
    function get_Status: DeviceWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: DeviceWatcherStatus read get_Status;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Enumeration.Pnp.IPnpObjectStatics
  [WinRTClassNameAttribute(SWindows_Devices_Enumeration_Pnp_PnpObject)]
  Pnp_IPnpObjectStatics = interface(IInspectable)
  ['{B3C32A3D-D168-4660-BBF3-A733B14B6E01}']
    function CreateFromIdAsync(&type: Pnp_PnpObjectType; id: HSTRING; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__Pnp_IPnpObject; safecall;
    function FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject; overload; safecall;
    function FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject; overload; safecall;
    function CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): Pnp_IPnpObjectWatcher; overload; safecall;
    function CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): Pnp_IPnpObjectWatcher; overload; safecall;
  end;

  // Windows.Devices.Enumeration.DeviceInformation
  // DualAPI
  // Implements: Windows.Devices.Enumeration.IDeviceInformation
  // Implements: Windows.Devices.Enumeration.IDeviceInformation2
  // Statics: "Windows.Devices.Enumeration.IDeviceInformationStatics"
  // Statics: "Windows.Devices.Enumeration.IDeviceInformationStatics2"
  // Statics: "Windows.Devices.Enumeration.IDeviceInformationStatics3"
  TDeviceInformation = class(TWinRTGenericImportS3<IDeviceInformationStatics, IDeviceInformationStatics2, IDeviceInformationStatics3>)
  public
    {$REGION 'IDeviceInformationStatics'}
    class function CreateFromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IDeviceInformation; overload; static; inline;
    class function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync: IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync(deviceClass: DeviceClass): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync(aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function CreateWatcher: IDeviceWatcher; overload; static; inline;
    class function CreateWatcher(deviceClass: DeviceClass): IDeviceWatcher; overload; static; inline;
    class function CreateWatcher(aqsFilter: HSTRING): IDeviceWatcher; overload; static; inline;
    class function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IDeviceWatcher; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IDeviceInformationStatics2'}
    class function GetAqsFilterFromDeviceClass(deviceClass: DeviceClass): HSTRING; static; inline;
    class function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IDeviceWatcher; overload; static; inline;
    {$ENDREGION}
    {$REGION 'IDeviceInformationStatics3'}
    class function CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IDeviceInformation; overload; static; inline;
    class function FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IVectorView_1__IDeviceInformation; overload; static; inline;
    class function CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IDeviceWatcher; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Enumeration.DeviceInformationPairing
  // Explicitly imported
  // Implements: Windows.Devices.Enumeration.IDeviceInformationPairing
  // Implements: Windows.Devices.Enumeration.IDeviceInformationPairing2
  // Statics: "Windows.Devices.Enumeration.IDeviceInformationPairingStatics"
  // Statics: "Windows.Devices.Enumeration.IDeviceInformationPairingStatics2"
  TDeviceInformationPairing = class(TWinRTGenericImportS2<IDeviceInformationPairingStatics, IDeviceInformationPairingStatics2>)
  public
    {$REGION 'IDeviceInformationPairingStatics'}
    class function TryRegisterForAllInboundPairingRequests(pairingKindsSupported: DevicePairingKinds): Boolean; static; inline;
    {$ENDREGION}
    {$REGION 'IDeviceInformationPairingStatics2'}
    class function TryRegisterForAllInboundPairingRequestsWithProtectionLevel(pairingKindsSupported: DevicePairingKinds; minProtectionLevel: DevicePairingProtectionLevel): Boolean; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Enumeration.DevicePicker
  // DualAPI
  // Implements: Windows.Devices.Enumeration.IDevicePicker
  // Instantiable: "IDevicePicker"
  TDevicePicker = class(TWinRTGenericImportI<IDevicePicker>) end;

  // Windows.Devices.Enumeration.Pnp.PnpObject
  // DualAPI
  // Implements: Windows.Devices.Enumeration.Pnp.IPnpObject
  // Statics: "Windows.Devices.Enumeration.Pnp.IPnpObjectStatics"
  TPnp_PnpObject = class(TWinRTGenericImportS<Pnp_IPnpObjectStatics>)
  public
    {$REGION 'Pnp_IPnpObjectStatics'}
    class function CreateFromIdAsync(&type: Pnp_PnpObjectType; id: HSTRING; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__Pnp_IPnpObject; static; inline;
    class function FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject; overload; static; inline;
    class function FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject; overload; static; inline;
    class function CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): Pnp_IPnpObjectWatcher; overload; static; inline;
    class function CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): Pnp_IPnpObjectWatcher; overload; static; inline;
    {$ENDREGION}
 end;

implementation

{ TDeviceInformation }

{$REGION 'Windows.Devices.Enumeration.IDeviceInformationStatics'}
class function TDeviceInformation.CreateFromIdAsync(deviceId: HSTRING): IAsyncOperation_1__IDeviceInformation;
begin
  Result := Statics.CreateFromIdAsync(deviceId);
end;

class function TDeviceInformation.CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IDeviceInformation;
begin
  Result := Statics.CreateFromIdAsync(deviceId, additionalProperties);
end;

class function TDeviceInformation.FindAllAsync: IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics.FindAllAsync;
end;

class function TDeviceInformation.FindAllAsync(deviceClass: DeviceClass): IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics.FindAllAsync(deviceClass);
end;

class function TDeviceInformation.FindAllAsync(aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics.FindAllAsync(aqsFilter);
end;

class function TDeviceInformation.FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics.FindAllAsync(aqsFilter, additionalProperties);
end;

class function TDeviceInformation.CreateWatcher: IDeviceWatcher;
begin
  Result := Statics.CreateWatcher;
end;

class function TDeviceInformation.CreateWatcher(deviceClass: DeviceClass): IDeviceWatcher;
begin
  Result := Statics.CreateWatcher(deviceClass);
end;

class function TDeviceInformation.CreateWatcher(aqsFilter: HSTRING): IDeviceWatcher;
begin
  Result := Statics.CreateWatcher(aqsFilter);
end;

class function TDeviceInformation.CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING): IDeviceWatcher;
begin
  Result := Statics.CreateWatcher(aqsFilter, additionalProperties);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Enumeration.IDeviceInformationStatics2'}
class function TDeviceInformation.GetAqsFilterFromDeviceClass(deviceClass: DeviceClass): HSTRING;
begin
  Result := Statics2.GetAqsFilterFromDeviceClass(deviceClass);
end;

class function TDeviceInformation.CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IDeviceInformation;
begin
  Result := Statics2.CreateFromIdAsync(deviceId, additionalProperties, kind);
end;

class function TDeviceInformation.FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics2.FindAllAsync(aqsFilter, additionalProperties, kind);
end;

class function TDeviceInformation.CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind): IDeviceWatcher;
begin
  Result := Statics2.CreateWatcher(aqsFilter, additionalProperties, kind);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Enumeration.IDeviceInformationStatics3'}
class function TDeviceInformation.CreateFromIdAsync(deviceId: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IDeviceInformation;
begin
  Result := Statics3.CreateFromIdAsync(deviceId, additionalProperties, kind, settings);
end;

class function TDeviceInformation.FindAllAsync(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IAsyncOperation_1__IVectorView_1__IDeviceInformation;
begin
  Result := Statics3.FindAllAsync(aqsFilter, additionalProperties, kind, settings);
end;

class function TDeviceInformation.CreateWatcher(aqsFilter: HSTRING; additionalProperties: IIterable_1__HSTRING; kind: DeviceInformationKind; settings: IDeviceEnumerationSettings): IDeviceWatcher;
begin
  Result := Statics3.CreateWatcher(aqsFilter, additionalProperties, kind, settings);
end;
{$ENDREGION}

{ TDeviceInformationPairing }

{$REGION 'Windows.Devices.Enumeration.IDeviceInformationPairingStatics'}
class function TDeviceInformationPairing.TryRegisterForAllInboundPairingRequests(pairingKindsSupported: DevicePairingKinds): Boolean;
begin
  Result := Statics.TryRegisterForAllInboundPairingRequests(pairingKindsSupported);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Enumeration.IDeviceInformationPairingStatics2'}
class function TDeviceInformationPairing.TryRegisterForAllInboundPairingRequestsWithProtectionLevel(pairingKindsSupported: DevicePairingKinds; minProtectionLevel: DevicePairingProtectionLevel): Boolean;
begin
  Result := Statics2.TryRegisterForAllInboundPairingRequestsWithProtectionLevel(pairingKindsSupported, minProtectionLevel);
end;
{$ENDREGION}

{ TDevicePicker }

{ TPnp_PnpObject }

{$REGION 'Windows.Devices.Enumeration.Pnp.IPnpObjectStatics'}
class function TPnp_PnpObject.CreateFromIdAsync(&type: Pnp_PnpObjectType; id: HSTRING; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__Pnp_IPnpObject;
begin
  Result := Statics.CreateFromIdAsync(&type, id, requestedProperties);
end;

class function TPnp_PnpObject.FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject;
begin
  Result := Statics.FindAllAsync(&type, requestedProperties);
end;

class function TPnp_PnpObject.FindAllAsync(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): IAsyncOperation_1__IVectorView_1__Pnp_IPnpObject;
begin
  Result := Statics.FindAllAsync(&type, requestedProperties, aqsFilter);
end;

class function TPnp_PnpObject.CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING): Pnp_IPnpObjectWatcher;
begin
  Result := Statics.CreateWatcher(&type, requestedProperties);
end;

class function TPnp_PnpObject.CreateWatcher(&type: Pnp_PnpObjectType; requestedProperties: IIterable_1__HSTRING; aqsFilter: HSTRING): Pnp_IPnpObjectWatcher;
begin
  Result := Statics.CreateWatcher(&type, requestedProperties, aqsFilter);
end;
{$ENDREGION}

end.
