{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Networking.NetworkOperators;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.DataRT,
  Winapi.Devices.Sms,
  Winapi.Networking.Connectivity,
  Winapi.Foundation.Collections,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult
  IHotspotCredentialsAuthenticationResult = interface;
  PIHotspotCredentialsAuthenticationResult = ^IHotspotCredentialsAuthenticationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult>
  AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult = interface;
  PAsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult = ^AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult>
  IAsyncOperation_1__IHotspotCredentialsAuthenticationResult = interface;
  PIAsyncOperation_1__IHotspotCredentialsAuthenticationResult = ^IAsyncOperation_1__IHotspotCredentialsAuthenticationResult;

  // Windows.Networking.NetworkOperators.IKnownCSimFilePathsStatics
  IKnownCSimFilePathsStatics = interface;
  PIKnownCSimFilePathsStatics = ^IKnownCSimFilePathsStatics;

  // Windows.Networking.NetworkOperators.IKnownRuimFilePathsStatics
  IKnownRuimFilePathsStatics = interface;
  PIKnownRuimFilePathsStatics = ^IKnownRuimFilePathsStatics;

  // Windows.Networking.NetworkOperators.IKnownSimFilePathsStatics
  IKnownSimFilePathsStatics = interface;
  PIKnownSimFilePathsStatics = ^IKnownSimFilePathsStatics;

  // Windows.Networking.NetworkOperators.IKnownUSimFilePathsStatics
  IKnownUSimFilePathsStatics = interface;
  PIKnownUSimFilePathsStatics = ^IKnownUSimFilePathsStatics;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetwork
  IMobileBroadbandNetwork = interface;
  PIMobileBroadbandNetwork = ^IMobileBroadbandNetwork;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation
  IMobileBroadbandDeviceInformation = interface;
  PIMobileBroadbandDeviceInformation = ^IMobileBroadbandDeviceInformation;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount
  IMobileBroadbandAccount = interface;
  PIMobileBroadbandAccount = ^IMobileBroadbandAccount;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount2
  IMobileBroadbandAccount2 = interface;
  PIMobileBroadbandAccount2 = ^IMobileBroadbandAccount2;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount3
  IMobileBroadbandAccount3 = interface;
  PIMobileBroadbandAccount3 = ^IMobileBroadbandAccount3;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountEventArgs
  IMobileBroadbandAccountEventArgs = interface;
  PIMobileBroadbandAccountEventArgs = ^IMobileBroadbandAccountEventArgs;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountStatics
  IMobileBroadbandAccountStatics = interface;
  PIMobileBroadbandAccountStatics = ^IMobileBroadbandAccountStatics;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountUpdatedEventArgs
  IMobileBroadbandAccountUpdatedEventArgs = interface;
  PIMobileBroadbandAccountUpdatedEventArgs = ^IMobileBroadbandAccountUpdatedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.IMobileBroadbandAccountEventArgs>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs = interface;
  PTypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs = ^TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.IMobileBroadbandAccountUpdatedEventArgs>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountUpdatedEventArgs = interface;
  PTypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountUpdatedEventArgs = ^TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountUpdatedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Object>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable = interface;
  PTypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable = ^TypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable;

  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher
  IMobileBroadbandAccountWatcher = interface;
  PIMobileBroadbandAccountWatcher = ^IMobileBroadbandAccountWatcher;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IIterator_1__MobileBroadbandPinType = interface;
  PIIterator_1__MobileBroadbandPinType = ^IIterator_1__MobileBroadbandPinType;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IIterable_1__MobileBroadbandPinType = interface;
  PIIterable_1__MobileBroadbandPinType = ^IIterable_1__MobileBroadbandPinType;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IVectorView_1__MobileBroadbandPinType = interface;
  PIVectorView_1__MobileBroadbandPinType = ^IVectorView_1__MobileBroadbandPinType;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult
  IMobileBroadbandPinOperationResult = interface;
  PIMobileBroadbandPinOperationResult = ^IMobileBroadbandPinOperationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult = ^AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult>
  IAsyncOperation_1__IMobileBroadbandPinOperationResult = interface;
  PIAsyncOperation_1__IMobileBroadbandPinOperationResult = ^IAsyncOperation_1__IMobileBroadbandPinOperationResult;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPin
  IMobileBroadbandPin = interface;
  PIMobileBroadbandPin = ^IMobileBroadbandPin;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinManager
  IMobileBroadbandPinManager = interface;
  PIMobileBroadbandPinManager = ^IMobileBroadbandPinManager;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation2
  IMobileBroadbandDeviceInformation2 = interface;
  PIMobileBroadbandDeviceInformation2 = ^IMobileBroadbandDeviceInformation2;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation3
  IMobileBroadbandDeviceInformation3 = interface;
  PIMobileBroadbandDeviceInformation3 = ^IMobileBroadbandDeviceInformation3;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandModemStatus>
  AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus = interface;
  PAsyncOperationCompletedHandler_1__MobileBroadbandModemStatus = ^AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandModemStatus>
  IAsyncOperation_1__MobileBroadbandModemStatus = interface;
  PIAsyncOperation_1__MobileBroadbandModemStatus = ^IAsyncOperation_1__MobileBroadbandModemStatus;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataReceivedEventArgs
  IMobileBroadbandDeviceServiceDataReceivedEventArgs = interface;
  PIMobileBroadbandDeviceServiceDataReceivedEventArgs = ^IMobileBroadbandDeviceServiceDataReceivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataSession,Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataReceivedEventArgs>
  TypedEventHandler_2__IMobileBroadbandDeviceServiceDataSession__IMobileBroadbandDeviceServiceDataReceivedEventArgs = interface;
  PTypedEventHandler_2__IMobileBroadbandDeviceServiceDataSession__IMobileBroadbandDeviceServiceDataReceivedEventArgs = ^TypedEventHandler_2__IMobileBroadbandDeviceServiceDataSession__IMobileBroadbandDeviceServiceDataReceivedEventArgs;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataSession
  IMobileBroadbandDeviceServiceDataSession = interface;
  PIMobileBroadbandDeviceServiceDataSession = ^IMobileBroadbandDeviceServiceDataSession;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult
  IMobileBroadbandDeviceServiceCommandResult = interface;
  PIMobileBroadbandDeviceServiceCommandResult = ^IMobileBroadbandDeviceServiceCommandResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult = ^AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult>
  IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult = interface;
  PIAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult = ^IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandSession
  IMobileBroadbandDeviceServiceCommandSession = interface;
  PIMobileBroadbandDeviceServiceCommandSession = ^IMobileBroadbandDeviceServiceCommandSession;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceService
  IMobileBroadbandDeviceService = interface;
  PIMobileBroadbandDeviceService = ^IMobileBroadbandDeviceService;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation
  IMobileBroadbandDeviceServiceInformation = interface;
  PIMobileBroadbandDeviceServiceInformation = ^IMobileBroadbandDeviceServiceInformation;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceTriggerDetails
  IMobileBroadbandDeviceServiceTriggerDetails = interface;
  PIMobileBroadbandDeviceServiceTriggerDetails = ^IMobileBroadbandDeviceServiceTriggerDetails;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceTriggerDetails2
  IMobileBroadbandDeviceServiceTriggerDetails2 = interface;
  PIMobileBroadbandDeviceServiceTriggerDetails2 = ^IMobileBroadbandDeviceServiceTriggerDetails2;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IIterator_1__IMobileBroadbandDeviceServiceInformation = interface;
  PIIterator_1__IMobileBroadbandDeviceServiceInformation = ^IIterator_1__IMobileBroadbandDeviceServiceInformation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IIterable_1__IMobileBroadbandDeviceServiceInformation = interface;
  PIIterable_1__IMobileBroadbandDeviceServiceInformation = ^IIterable_1__IMobileBroadbandDeviceServiceInformation;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IVectorView_1__IMobileBroadbandDeviceServiceInformation = interface;
  PIVectorView_1__IMobileBroadbandDeviceServiceInformation = ^IVectorView_1__IMobileBroadbandDeviceServiceInformation;

  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult
  IMobileBroadbandUiccAppRecordDetailsResult = interface;
  PIMobileBroadbandUiccAppRecordDetailsResult = ^IMobileBroadbandUiccAppRecordDetailsResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult = ^AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult = interface;
  PIAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult = ^IAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult;

  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult
  IMobileBroadbandUiccAppReadRecordResult = interface;
  PIMobileBroadbandUiccAppReadRecordResult = ^IMobileBroadbandUiccAppReadRecordResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult = ^AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult = interface;
  PIAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult = ^IAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult;

  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp
  IMobileBroadbandUiccApp = interface;
  PIMobileBroadbandUiccApp = ^IMobileBroadbandUiccApp;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IIterator_1__IMobileBroadbandUiccApp = interface;
  PIIterator_1__IMobileBroadbandUiccApp = ^IIterator_1__IMobileBroadbandUiccApp;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IIterable_1__IMobileBroadbandUiccApp = interface;
  PIIterable_1__IMobileBroadbandUiccApp = ^IIterable_1__IMobileBroadbandUiccApp;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IVectorView_1__IMobileBroadbandUiccApp = interface;
  PIVectorView_1__IMobileBroadbandUiccApp = ^IVectorView_1__IMobileBroadbandUiccApp;

  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult
  IMobileBroadbandUiccAppsResult = interface;
  PIMobileBroadbandUiccAppsResult = ^IMobileBroadbandUiccAppsResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult = ^AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppsResult = interface;
  PIAsyncOperation_1__IMobileBroadbandUiccAppsResult = ^IAsyncOperation_1__IMobileBroadbandUiccAppsResult;

  // Windows.Networking.NetworkOperators.IMobileBroadbandUicc
  IMobileBroadbandUicc = interface;
  PIMobileBroadbandUicc = ^IMobileBroadbandUicc;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration
  IMobileBroadbandModemConfiguration = interface;
  PIMobileBroadbandModemConfiguration = ^IMobileBroadbandModemConfiguration;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration>
  AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration = ^AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration>
  IAsyncOperation_1__IMobileBroadbandModemConfiguration = interface;
  PIAsyncOperation_1__IMobileBroadbandModemConfiguration = ^IAsyncOperation_1__IMobileBroadbandModemConfiguration;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModem
  IMobileBroadbandModem = interface;
  PIMobileBroadbandModem = ^IMobileBroadbandModem;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModem2
  IMobileBroadbandModem2 = interface;
  PIMobileBroadbandModem2 = ^IMobileBroadbandModem2;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPco
  IMobileBroadbandPco = interface;
  PIMobileBroadbandPco = ^IMobileBroadbandPco;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandPco>
  AsyncOperationCompletedHandler_1__IMobileBroadbandPco = interface;
  PAsyncOperationCompletedHandler_1__IMobileBroadbandPco = ^AsyncOperationCompletedHandler_1__IMobileBroadbandPco;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandPco>
  IAsyncOperation_1__IMobileBroadbandPco = interface;
  PIAsyncOperation_1__IMobileBroadbandPco = ^IAsyncOperation_1__IMobileBroadbandPco;

  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandModem,Object>
  TypedEventHandler_2__IMobileBroadbandModem__IInspectable = interface;
  PTypedEventHandler_2__IMobileBroadbandModem__IInspectable = ^TypedEventHandler_2__IMobileBroadbandModem__IInspectable;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModem3
  IMobileBroadbandModem3 = interface;
  PIMobileBroadbandModem3 = ^IMobileBroadbandModem3;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModem4
  IMobileBroadbandModem4 = interface;
  PIMobileBroadbandModem4 = ^IMobileBroadbandModem4;

  // Windows.Networking.NetworkOperators.IMobileBroadbandModemStatics
  IMobileBroadbandModemStatics = interface;
  PIMobileBroadbandModemStatics = ^IMobileBroadbandModemStatics;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetwork2
  IMobileBroadbandNetwork2 = interface;
  PIMobileBroadbandNetwork2 = ^IMobileBroadbandNetwork2;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange
  IMobileBroadbandNetworkRegistrationStateChange = interface;
  PIMobileBroadbandNetworkRegistrationStateChange = ^IMobileBroadbandNetworkRegistrationStateChange;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IIterator_1__IMobileBroadbandNetworkRegistrationStateChange = interface;
  PIIterator_1__IMobileBroadbandNetworkRegistrationStateChange = ^IIterator_1__IMobileBroadbandNetworkRegistrationStateChange;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IIterable_1__IMobileBroadbandNetworkRegistrationStateChange = interface;
  PIIterable_1__IMobileBroadbandNetworkRegistrationStateChange = ^IIterable_1__IMobileBroadbandNetworkRegistrationStateChange;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IVectorView_1__IMobileBroadbandNetworkRegistrationStateChange = interface;
  PIVectorView_1__IMobileBroadbandNetworkRegistrationStateChange = ^IVectorView_1__IMobileBroadbandNetworkRegistrationStateChange;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChangeTriggerDetails
  IMobileBroadbandNetworkRegistrationStateChangeTriggerDetails = interface;
  PIMobileBroadbandNetworkRegistrationStateChangeTriggerDetails = ^IMobileBroadbandNetworkRegistrationStateChangeTriggerDetails;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange
  IMobileBroadbandPinLockStateChange = interface;
  PIMobileBroadbandPinLockStateChange = ^IMobileBroadbandPinLockStateChange;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IIterator_1__IMobileBroadbandPinLockStateChange = interface;
  PIIterator_1__IMobileBroadbandPinLockStateChange = ^IIterator_1__IMobileBroadbandPinLockStateChange;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IIterable_1__IMobileBroadbandPinLockStateChange = interface;
  PIIterable_1__IMobileBroadbandPinLockStateChange = ^IIterable_1__IMobileBroadbandPinLockStateChange;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IVectorView_1__IMobileBroadbandPinLockStateChange = interface;
  PIVectorView_1__IMobileBroadbandPinLockStateChange = ^IVectorView_1__IMobileBroadbandPinLockStateChange;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChangeTriggerDetails
  IMobileBroadbandPinLockStateChangeTriggerDetails = interface;
  PIMobileBroadbandPinLockStateChangeTriggerDetails = ^IMobileBroadbandPinLockStateChangeTriggerDetails;

  // Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange
  IMobileBroadbandRadioStateChange = interface;
  PIMobileBroadbandRadioStateChange = ^IMobileBroadbandRadioStateChange;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IIterator_1__IMobileBroadbandRadioStateChange = interface;
  PIIterator_1__IMobileBroadbandRadioStateChange = ^IIterator_1__IMobileBroadbandRadioStateChange;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IIterable_1__IMobileBroadbandRadioStateChange = interface;
  PIIterable_1__IMobileBroadbandRadioStateChange = ^IIterable_1__IMobileBroadbandRadioStateChange;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IVectorView_1__IMobileBroadbandRadioStateChange = interface;
  PIVectorView_1__IMobileBroadbandRadioStateChange = ^IVectorView_1__IMobileBroadbandRadioStateChange;

  // Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChangeTriggerDetails
  IMobileBroadbandRadioStateChangeTriggerDetails = interface;
  PIMobileBroadbandRadioStateChangeTriggerDetails = ^IMobileBroadbandRadioStateChangeTriggerDetails;

  // Windows.Networking.NetworkOperators.INetworkOperatorNotificationEventDetails
  INetworkOperatorNotificationEventDetails = interface;
  PINetworkOperatorNotificationEventDetails = ^INetworkOperatorNotificationEventDetails;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration
  INetworkOperatorTetheringAccessPointConfiguration = interface;
  PINetworkOperatorTetheringAccessPointConfiguration = ^INetworkOperatorTetheringAccessPointConfiguration;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration2
  INetworkOperatorTetheringAccessPointConfiguration2 = interface;
  PINetworkOperatorTetheringAccessPointConfiguration2 = ^INetworkOperatorTetheringAccessPointConfiguration2;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration3
  INetworkOperatorTetheringAccessPointConfiguration3 = interface;
  PINetworkOperatorTetheringAccessPointConfiguration3 = ^INetworkOperatorTetheringAccessPointConfiguration3;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient
  INetworkOperatorTetheringClient = interface;
  PINetworkOperatorTetheringClient = ^INetworkOperatorTetheringClient;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IIterator_1__INetworkOperatorTetheringClient = interface;
  PIIterator_1__INetworkOperatorTetheringClient = ^IIterator_1__INetworkOperatorTetheringClient;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IIterable_1__INetworkOperatorTetheringClient = interface;
  PIIterable_1__INetworkOperatorTetheringClient = ^IIterable_1__INetworkOperatorTetheringClient;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IVectorView_1__INetworkOperatorTetheringClient = interface;
  PIVectorView_1__INetworkOperatorTetheringClient = ^IVectorView_1__INetworkOperatorTetheringClient;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringClientManager
  INetworkOperatorTetheringClientManager = interface;
  PINetworkOperatorTetheringClientManager = ^INetworkOperatorTetheringClientManager;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringEntitlementCheck
  INetworkOperatorTetheringEntitlementCheck = interface;
  PINetworkOperatorTetheringEntitlementCheck = ^INetworkOperatorTetheringEntitlementCheck;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult
  INetworkOperatorTetheringOperationResult = interface;
  PINetworkOperatorTetheringOperationResult = ^INetworkOperatorTetheringOperationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult>
  AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult = interface;
  PAsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult = ^AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult>
  IAsyncOperation_1__INetworkOperatorTetheringOperationResult = interface;
  PIAsyncOperation_1__INetworkOperatorTetheringOperationResult = ^IAsyncOperation_1__INetworkOperatorTetheringOperationResult;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager
  INetworkOperatorTetheringManager = interface;
  PINetworkOperatorTetheringManager = ^INetworkOperatorTetheringManager;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringSessionAccessPointConfiguration
  INetworkOperatorTetheringSessionAccessPointConfiguration = interface;
  PINetworkOperatorTetheringSessionAccessPointConfiguration = ^INetworkOperatorTetheringSessionAccessPointConfiguration;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager2
  INetworkOperatorTetheringManager2 = interface;
  PINetworkOperatorTetheringManager2 = ^INetworkOperatorTetheringManager2;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics
  INetworkOperatorTetheringManagerStatics = interface;
  PINetworkOperatorTetheringManagerStatics = ^INetworkOperatorTetheringManagerStatics;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics2
  INetworkOperatorTetheringManagerStatics2 = interface;
  PINetworkOperatorTetheringManagerStatics2 = ^INetworkOperatorTetheringManagerStatics2;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics3
  INetworkOperatorTetheringManagerStatics3 = interface;
  PINetworkOperatorTetheringManagerStatics3 = ^INetworkOperatorTetheringManagerStatics3;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics4
  INetworkOperatorTetheringManagerStatics4 = interface;
  PINetworkOperatorTetheringManagerStatics4 = ^INetworkOperatorTetheringManagerStatics4;

  // Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults
  IProvisionFromXmlDocumentResults = interface;
  PIProvisionFromXmlDocumentResults = ^IProvisionFromXmlDocumentResults;

  // Windows.Networking.NetworkOperators.IProvisionedProfile
  IProvisionedProfile = interface;
  PIProvisionedProfile = ^IProvisionedProfile;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults>
  AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults = interface;
  PAsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults = ^AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults>
  IAsyncOperation_1__IProvisionFromXmlDocumentResults = interface;
  PIAsyncOperation_1__IProvisionFromXmlDocumentResults = ^IAsyncOperation_1__IProvisionFromXmlDocumentResults;

  // Windows.Networking.NetworkOperators.IProvisioningAgent
  IProvisioningAgent = interface;
  PIProvisioningAgent = ^IProvisioningAgent;

  // Windows.Networking.NetworkOperators.IProvisioningAgentStaticMethods
  IProvisioningAgentStaticMethods = interface;
  PIProvisioningAgentStaticMethods = ^IProvisioningAgentStaticMethods;

  // Windows.Networking.NetworkOperators.IUssdMessage
  IUssdMessage = interface;
  PIUssdMessage = ^IUssdMessage;

  // Windows.Networking.NetworkOperators.IUssdMessageFactory
  IUssdMessageFactory = interface;
  PIUssdMessageFactory = ^IUssdMessageFactory;

  // Windows.Networking.NetworkOperators.IUssdReply
  IUssdReply = interface;
  PIUssdReply = ^IUssdReply;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IUssdReply>
  AsyncOperationCompletedHandler_1__IUssdReply = interface;
  PAsyncOperationCompletedHandler_1__IUssdReply = ^AsyncOperationCompletedHandler_1__IUssdReply;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IUssdReply>
  IAsyncOperation_1__IUssdReply = interface;
  PIAsyncOperation_1__IUssdReply = ^IAsyncOperation_1__IUssdReply;

  // Windows.Networking.NetworkOperators.IUssdSession
  IUssdSession = interface;
  PIUssdSession = ^IUssdSession;

  // Windows.Networking.NetworkOperators.IUssdSessionStatics
  IUssdSessionStatics = interface;
  PIUssdSessionStatics = ^IUssdSessionStatics;

  // Windows.Networking.NetworkOperators Enums

  // Windows.Networking.NetworkOperators.DataClasses
  DataClasses = (
    None = 0,
    Gprs = 1,
    Edge = 2,
    Umts = 4,
    Hsdpa = 8,
    Hsupa = 16,
    LteAdvanced = 32,
    NewRadioNonStandalone = 64,
    NewRadioStandalone = 128,
    Cdma1xRtt = 65536,
    Cdma1xEvdo = 131072,
    Cdma1xEvdoRevA = 262144,
    Cdma1xEvdv = 524288,
    Cdma3xRtt = 1048576,
    Cdma1xEvdoRevB = 2097152,
    CdmaUmb = 4194304,
    Custom = -2147483648
  );
  PDataClasses = ^DataClasses;

  // Windows.Networking.NetworkOperators.ESimAuthenticationPreference
  ESimAuthenticationPreference = (
    OnEntry = 0,
    OnAction = 1,
    Never = 2
  );
  PESimAuthenticationPreference = ^ESimAuthenticationPreference;

  // Windows.Networking.NetworkOperators.ESimDiscoverResultKind
  ESimDiscoverResultKind = (
    None = 0,
    Events = 1,
    ProfileMetadata = 2
  );
  PESimDiscoverResultKind = ^ESimDiscoverResultKind;

  // Windows.Networking.NetworkOperators.ESimOperationStatus
  ESimOperationStatus = (
    Success = 0,
    NotAuthorized = 1,
    NotFound = 2,
    PolicyViolation = 3,
    InsufficientSpaceOnCard = 4,
    ServerFailure = 5,
    ServerNotReachable = 6,
    TimeoutWaitingForUserConsent = 7,
    IncorrectConfirmationCode = 8,
    ConfirmationCodeMaxRetriesExceeded = 9,
    CardRemoved = 10,
    CardBusy = 11,
    Other = 12,
    CardGeneralFailure = 13,
    ConfirmationCodeMissing = 14,
    InvalidMatchingId = 15,
    NoEligibleProfileForThisDevice = 16,
    OperationAborted = 17,
    EidMismatch = 18,
    ProfileNotAvailableForNewBinding = 19,
    ProfileNotReleasedByOperator = 20,
    OperationProhibitedByProfileClass = 21,
    ProfileNotPresent = 22,
    NoCorrespondingRequest = 23,
    TimeoutWaitingForResponse = 24,
    IccidAlreadyExists = 25,
    ProfileProcessingError = 26,
    ServerNotTrusted = 27,
    ProfileDownloadMaxRetriesExceeded = 28
  );
  PESimOperationStatus = ^ESimOperationStatus;

  // Windows.Networking.NetworkOperators.ESimProfileClass
  ESimProfileClass = (
    Operational = 0,
    Test = 1,
    Provisioning = 2
  );
  PESimProfileClass = ^ESimProfileClass;

  // Windows.Networking.NetworkOperators.ESimProfileMetadataState
  ESimProfileMetadataState = (
    Unknown = 0,
    WaitingForInstall = 1,
    Downloading = 2,
    Installing = 3,
    Expired = 4,
    RejectingDownload = 5,
    NoLongerAvailable = 6,
    DeniedByPolicy = 7
  );
  PESimProfileMetadataState = ^ESimProfileMetadataState;

  // Windows.Networking.NetworkOperators.ESimProfileState
  ESimProfileState = (
    Unknown = 0,
    Disabled = 1,
    Enabled = 2,
    Deleted = 3
  );
  PESimProfileState = ^ESimProfileState;

  // Windows.Networking.NetworkOperators.ESimState
  ESimState = (
    Unknown = 0,
    Idle = 1,
    Removed = 2,
    Busy = 3
  );
  PESimState = ^ESimState;

  // Windows.Networking.NetworkOperators.ESimWatcherStatus
  ESimWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopping = 3,
    Stopped = 4
  );
  PESimWatcherStatus = ^ESimWatcherStatus;

  // Windows.Networking.NetworkOperators.HotspotAuthenticationResponseCode
  HotspotAuthenticationResponseCode = (
    NoError = 0,
    LoginSucceeded = 50,
    LoginFailed = 100,
    RadiusServerError = 102,
    NetworkAdministratorError = 105,
    LoginAborted = 151,
    AccessGatewayInternalError = 255
  );
  PHotspotAuthenticationResponseCode = ^HotspotAuthenticationResponseCode;

  // Windows.Networking.NetworkOperators.MobileBroadbandAccountWatcherStatus
  MobileBroadbandAccountWatcherStatus = (
    Created = 0,
    Started = 1,
    EnumerationCompleted = 2,
    Stopped = 3,
    Aborted = 4
  );
  PMobileBroadbandAccountWatcherStatus = ^MobileBroadbandAccountWatcherStatus;

  // Windows.Networking.NetworkOperators.MobileBroadbandDeviceType
  MobileBroadbandDeviceType = (
    Unknown = 0,
    Embedded = 1,
    Removable = 2,
    Remote = 3
  );
  PMobileBroadbandDeviceType = ^MobileBroadbandDeviceType;

  // Windows.Networking.NetworkOperators.MobileBroadbandModemStatus
  MobileBroadbandModemStatus = (
    Success = 0,
    OtherFailure = 1,
    Busy = 2,
    NoDeviceSupport = 3
  );
  PMobileBroadbandModemStatus = ^MobileBroadbandModemStatus;

  // Windows.Networking.NetworkOperators.MobileBroadbandPinFormat
  MobileBroadbandPinFormat = (
    Unknown = 0,
    Numeric = 1,
    Alphanumeric = 2
  );
  PMobileBroadbandPinFormat = ^MobileBroadbandPinFormat;

  // Windows.Networking.NetworkOperators.MobileBroadbandPinLockState
  MobileBroadbandPinLockState = (
    Unknown = 0,
    Unlocked = 1,
    PinRequired = 2,
    PinUnblockKeyRequired = 3
  );
  PMobileBroadbandPinLockState = ^MobileBroadbandPinLockState;

  // Windows.Networking.NetworkOperators.MobileBroadbandPinType
  MobileBroadbandPinType = (
    None = 0,
    Custom = 1,
    Pin1 = 2,
    Pin2 = 3,
    SimPin = 4,
    FirstSimPin = 5,
    NetworkPin = 6,
    NetworkSubsetPin = 7,
    ServiceProviderPin = 8,
    CorporatePin = 9,
    SubsidyLock = 10
  );
  PMobileBroadbandPinType = ^MobileBroadbandPinType;

  // Windows.Networking.NetworkOperators.MobileBroadbandRadioState
  MobileBroadbandRadioState = (
    Off = 0,
    &On = 1
  );
  PMobileBroadbandRadioState = ^MobileBroadbandRadioState;

  // Windows.Networking.NetworkOperators.MobileBroadbandSlotState
  MobileBroadbandSlotState = (
    Unmanaged = 0,
    Unknown = 1,
    OffEmpty = 2,
    Off = 3,
    Empty = 4,
    NotReady = 5,
    Active = 6,
    Error = 7,
    ActiveEsim = 8,
    ActiveEsimNoProfile = 9
  );
  PMobileBroadbandSlotState = ^MobileBroadbandSlotState;

  // Windows.Networking.NetworkOperators.MobileBroadbandUiccAppOperationStatus
  MobileBroadbandUiccAppOperationStatus = (
    Success = 0,
    InvalidUiccFilePath = 1,
    AccessConditionNotHeld = 2,
    UiccBusy = 3
  );
  PMobileBroadbandUiccAppOperationStatus = ^MobileBroadbandUiccAppOperationStatus;

  // Windows.Networking.NetworkOperators.NetworkDeviceStatus
  NetworkDeviceStatus = (
    DeviceNotReady = 0,
    DeviceReady = 1,
    SimNotInserted = 2,
    BadSim = 3,
    DeviceHardwareFailure = 4,
    AccountNotActivated = 5,
    DeviceLocked = 6,
    DeviceBlocked = 7
  );
  PNetworkDeviceStatus = ^NetworkDeviceStatus;

  // Windows.Networking.NetworkOperators.NetworkOperatorDataUsageNotificationKind
  NetworkOperatorDataUsageNotificationKind = (
    DataUsageProgress = 0
  );
  PNetworkOperatorDataUsageNotificationKind = ^NetworkOperatorDataUsageNotificationKind;

  // Windows.Networking.NetworkOperators.NetworkOperatorEventMessageType
  NetworkOperatorEventMessageType = (
    Gsm = 0,
    Cdma = 1,
    Ussd = 2,
    DataPlanThresholdReached = 3,
    DataPlanReset = 4,
    DataPlanDeleted = 5,
    ProfileConnected = 6,
    ProfileDisconnected = 7,
    RegisteredRoaming = 8,
    RegisteredHome = 9,
    TetheringEntitlementCheck = 10,
    TetheringOperationalStateChanged = 11,
    TetheringNumberOfClientsChanged = 12
  );
  PNetworkOperatorEventMessageType = ^NetworkOperatorEventMessageType;

  // Windows.Networking.NetworkOperators.NetworkRegistrationState
  NetworkRegistrationState = (
    None = 0,
    Deregistered = 1,
    Searching = 2,
    Home = 3,
    Roaming = 4,
    Partner = 5,
    Denied = 6
  );
  PNetworkRegistrationState = ^NetworkRegistrationState;

  // Windows.Networking.NetworkOperators.ProfileMediaType
  ProfileMediaType = (
    Wlan = 0,
    Wwan = 1
  );
  PProfileMediaType = ^ProfileMediaType;

  // Windows.Networking.NetworkOperators.TetheringCapability
  TetheringCapability = (
    Enabled = 0,
    DisabledByGroupPolicy = 1,
    DisabledByHardwareLimitation = 2,
    DisabledByOperator = 3,
    DisabledBySku = 4,
    DisabledByRequiredAppNotInstalled = 5,
    DisabledDueToUnknownCause = 6,
    DisabledBySystemCapability = 7
  );
  PTetheringCapability = ^TetheringCapability;

  // Windows.Networking.NetworkOperators.TetheringOperationStatus
  TetheringOperationStatus = (
    Success = 0,
    Unknown = 1,
    MobileBroadbandDeviceOff = 2,
    WiFiDeviceOff = 3,
    EntitlementCheckTimeout = 4,
    EntitlementCheckFailure = 5,
    OperationInProgress = 6,
    BluetoothDeviceOff = 7,
    NetworkLimitedConnectivity = 8,
    AlreadyOn = 9,
    RadioRestriction = 10,
    BandInterference = 11
  );
  PTetheringOperationStatus = ^TetheringOperationStatus;

  // Windows.Networking.NetworkOperators.TetheringOperationalState
  TetheringOperationalState = (
    Unknown = 0,
    &On = 1,
    Off = 2,
    InTransition = 3
  );
  PTetheringOperationalState = ^TetheringOperationalState;

  // Windows.Networking.NetworkOperators.TetheringWiFiAuthenticationKind
  TetheringWiFiAuthenticationKind = (
    Wpa2 = 0,
    Wpa3TransitionMode = 1,
    Wpa3 = 2
  );
  PTetheringWiFiAuthenticationKind = ^TetheringWiFiAuthenticationKind;

  // Windows.Networking.NetworkOperators.TetheringWiFiBand
  TetheringWiFiBand = (
    Auto = 0,
    TwoPointFourGigahertz = 1,
    FiveGigahertz = 2,
    SixGigahertz = 3
  );
  PTetheringWiFiBand = ^TetheringWiFiBand;

  // Windows.Networking.NetworkOperators.TetheringWiFiPerformancePriority
  TetheringWiFiPerformancePriority = (
    Default = 0,
    TetheringOverStation = 1
  );
  PTetheringWiFiPerformancePriority = ^TetheringWiFiPerformancePriority;

  // Windows.Networking.NetworkOperators.UiccAccessCondition
  UiccAccessCondition = (
    AlwaysAllowed = 0,
    Pin1 = 1,
    Pin2 = 2,
    Pin3 = 3,
    Pin4 = 4,
    Administrative5 = 5,
    Administrative6 = 6,
    NeverAllowed = 7
  );
  PUiccAccessCondition = ^UiccAccessCondition;

  // Windows.Networking.NetworkOperators.UiccAppKind
  UiccAppKind = (
    Unknown = 0,
    MF = 1,
    MFSim = 2,
    MFRuim = 3,
    USim = 4,
    CSim = 5,
    ISim = 6
  );
  PUiccAppKind = ^UiccAppKind;

  // Windows.Networking.NetworkOperators.UiccAppRecordKind
  UiccAppRecordKind = (
    Unknown = 0,
    Transparent = 1,
    RecordOriented = 2
  );
  PUiccAppRecordKind = ^UiccAppRecordKind;

  // Windows.Networking.NetworkOperators.UssdResultCode
  UssdResultCode = (
    NoActionRequired = 0,
    ActionRequired = 1,
    Terminated = 2,
    OtherLocalClient = 3,
    OperationNotSupported = 4,
    NetworkTimeout = 5
  );
  PUssdResultCode = ^UssdResultCode;

  // Windows.Networking.NetworkOperators Records

  // Windows.Networking.NetworkOperators.ESimProfileInstallProgress
  ESimProfileInstallProgress = record
    TotalSizeInBytes: Integer;
    InstalledSizeInBytes: Integer;
  end;
  PESimProfileInstallProgress = ^ESimProfileInstallProgress;

  // Windows.Networking.NetworkOperators.LegacyNetworkOperatorsContract
  LegacyNetworkOperatorsContract = record
  end;
  PLegacyNetworkOperatorsContract = ^LegacyNetworkOperatorsContract;

  // Windows.Networking.NetworkOperators.ProfileUsage
  ProfileUsage = record
    UsageInMegabytes: Cardinal;
    LastSyncTime: DateTime;
  end;
  PProfileUsage = ^ProfileUsage;

  // Windows.Networking.NetworkOperators Interfaces

  // Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult
  IHotspotCredentialsAuthenticationResult = interface(IInspectable)
  ['{E756C791-1005-4DE5-83C7-DE61D88831D0}']
    function get_HasNetworkErrorOccurred: Boolean; safecall;
    function get_ResponseCode: HotspotAuthenticationResponseCode; safecall;
    function get_LogoffUrl: IUriRuntimeClass; safecall;
    function get_AuthenticationReplyXml: Xml_Dom_IXmlDocument; safecall;
    property AuthenticationReplyXml: Xml_Dom_IXmlDocument read get_AuthenticationReplyXml;
    property HasNetworkErrorOccurred: Boolean read get_HasNetworkErrorOccurred;
    property LogoffUrl: IUriRuntimeClass read get_LogoffUrl;
    property ResponseCode: HotspotAuthenticationResponseCode read get_ResponseCode;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.HotspotCredentialsAuthenticationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult>
  AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult = interface(IUnknown)
  ['{7F254BEB-471F-5000-94CE-102CC333055F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IHotspotCredentialsAuthenticationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.HotspotCredentialsAuthenticationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IHotspotCredentialsAuthenticationResult>
  IAsyncOperation_1__IHotspotCredentialsAuthenticationResult = interface(IInspectable)
  ['{522781D8-29C8-5D89-8937-1D1C2032F0C8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult; safecall;
    function GetResults: IHotspotCredentialsAuthenticationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IHotspotCredentialsAuthenticationResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IKnownCSimFilePathsStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_KnownCSimFilePaths)]
  IKnownCSimFilePathsStatics = interface(IInspectable)
  ['{B458AEED-49F1-4C22-B073-96D511BF9C35}']
    function get_EFSpn: IVectorView_1__Cardinal; safecall;
    function get_Gid1: IVectorView_1__Cardinal; safecall;
    function get_Gid2: IVectorView_1__Cardinal; safecall;
    property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    property Gid1: IVectorView_1__Cardinal read get_Gid1;
    property Gid2: IVectorView_1__Cardinal read get_Gid2;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IKnownRuimFilePathsStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_KnownRuimFilePaths)]
  IKnownRuimFilePathsStatics = interface(IInspectable)
  ['{3883C8B9-FF24-4571-A867-09F960426E14}']
    function get_EFSpn: IVectorView_1__Cardinal; safecall;
    function get_Gid1: IVectorView_1__Cardinal; safecall;
    function get_Gid2: IVectorView_1__Cardinal; safecall;
    property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    property Gid1: IVectorView_1__Cardinal read get_Gid1;
    property Gid2: IVectorView_1__Cardinal read get_Gid2;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IKnownSimFilePathsStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_KnownSimFilePaths)]
  IKnownSimFilePathsStatics = interface(IInspectable)
  ['{80CD1A63-37A5-43D3-80A3-CCD23E8FECEE}']
    function get_EFOns: IVectorView_1__Cardinal; safecall;
    function get_EFSpn: IVectorView_1__Cardinal; safecall;
    function get_Gid1: IVectorView_1__Cardinal; safecall;
    function get_Gid2: IVectorView_1__Cardinal; safecall;
    property EFOns: IVectorView_1__Cardinal read get_EFOns;
    property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    property Gid1: IVectorView_1__Cardinal read get_Gid1;
    property Gid2: IVectorView_1__Cardinal read get_Gid2;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IKnownUSimFilePathsStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_KnownUSimFilePaths)]
  IKnownUSimFilePathsStatics = interface(IInspectable)
  ['{7C34E581-1F1B-43F4-9530-8B092D32D71F}']
    function get_EFSpn: IVectorView_1__Cardinal; safecall;
    function get_EFOpl: IVectorView_1__Cardinal; safecall;
    function get_EFPnn: IVectorView_1__Cardinal; safecall;
    function get_Gid1: IVectorView_1__Cardinal; safecall;
    function get_Gid2: IVectorView_1__Cardinal; safecall;
    property EFOpl: IVectorView_1__Cardinal read get_EFOpl;
    property EFPnn: IVectorView_1__Cardinal read get_EFPnn;
    property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    property Gid1: IVectorView_1__Cardinal read get_Gid1;
    property Gid2: IVectorView_1__Cardinal read get_Gid2;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandNetwork
  IMobileBroadbandNetwork = interface(IInspectable)
  ['{CB63928C-0309-4CB6-A8C1-6A5A3C8E1FF6}']
    function get_NetworkAdapter: INetworkAdapter; safecall;
    function get_NetworkRegistrationState: NetworkRegistrationState; safecall;
    function get_RegistrationNetworkError: Cardinal; safecall;
    function get_PacketAttachNetworkError: Cardinal; safecall;
    function get_ActivationNetworkError: Cardinal; safecall;
    function get_AccessPointName: HSTRING; safecall;
    function get_RegisteredDataClass: DataClasses; safecall;
    function get_RegisteredProviderId: HSTRING; safecall;
    function get_RegisteredProviderName: HSTRING; safecall;
    procedure ShowConnectionUI; safecall;
    property AccessPointName: HSTRING read get_AccessPointName;
    property ActivationNetworkError: Cardinal read get_ActivationNetworkError;
    property NetworkAdapter: INetworkAdapter read get_NetworkAdapter;
    property NetworkRegistrationState_: NetworkRegistrationState read get_NetworkRegistrationState;
    property PacketAttachNetworkError: Cardinal read get_PacketAttachNetworkError;
    property RegisteredDataClass: DataClasses read get_RegisteredDataClass;
    property RegisteredProviderId: HSTRING read get_RegisteredProviderId;
    property RegisteredProviderName: HSTRING read get_RegisteredProviderName;
    property RegistrationNetworkError: Cardinal read get_RegistrationNetworkError;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation
  IMobileBroadbandDeviceInformation = interface(IInspectable)
  ['{E6D08168-E381-4C6E-9BE8-FE156969A446}']
    function get_NetworkDeviceStatus: NetworkDeviceStatus; safecall;
    function get_Manufacturer: HSTRING; safecall;
    function get_Model: HSTRING; safecall;
    function get_FirmwareInformation: HSTRING; safecall;
    function get_CellularClass: CellularClass; safecall;
    function get_DataClasses: DataClasses; safecall;
    function get_CustomDataClass: HSTRING; safecall;
    function get_MobileEquipmentId: HSTRING; safecall;
    function get_TelephoneNumbers: IVectorView_1__HSTRING; safecall;
    function get_SubscriberId: HSTRING; safecall;
    function get_SimIccId: HSTRING; safecall;
    function get_DeviceType: MobileBroadbandDeviceType; safecall;
    function get_DeviceId: HSTRING; safecall;
    function get_CurrentRadioState: MobileBroadbandRadioState; safecall;
    property CellularClass_: CellularClass read get_CellularClass;
    property CurrentRadioState: MobileBroadbandRadioState read get_CurrentRadioState;
    property CustomDataClass: HSTRING read get_CustomDataClass;
    property DataClasses_: DataClasses read get_DataClasses;
    property DeviceId: HSTRING read get_DeviceId;
    property DeviceType: MobileBroadbandDeviceType read get_DeviceType;
    property FirmwareInformation: HSTRING read get_FirmwareInformation;
    property Manufacturer: HSTRING read get_Manufacturer;
    property MobileEquipmentId: HSTRING read get_MobileEquipmentId;
    property Model: HSTRING read get_Model;
    property NetworkDeviceStatus_: NetworkDeviceStatus read get_NetworkDeviceStatus;
    property SimIccId: HSTRING read get_SimIccId;
    property SubscriberId: HSTRING read get_SubscriberId;
    property TelephoneNumbers: IVectorView_1__HSTRING read get_TelephoneNumbers;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_MobileBroadbandAccount)]
  IMobileBroadbandAccount = interface(IInspectable)
  ['{36C24CCD-CEE2-43E0-A603-EE86A36D6570}']
    function get_NetworkAccountId: HSTRING; safecall;
    function get_ServiceProviderGuid: TGuid; safecall;
    function get_ServiceProviderName: HSTRING; safecall;
    function get_CurrentNetwork: IMobileBroadbandNetwork; safecall;
    function get_CurrentDeviceInformation: IMobileBroadbandDeviceInformation; safecall;
    property CurrentDeviceInformation: IMobileBroadbandDeviceInformation read get_CurrentDeviceInformation;
    property CurrentNetwork: IMobileBroadbandNetwork read get_CurrentNetwork;
    property NetworkAccountId: HSTRING read get_NetworkAccountId;
    property ServiceProviderGuid: TGuid read get_ServiceProviderGuid;
    property ServiceProviderName: HSTRING read get_ServiceProviderName;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount2
  IMobileBroadbandAccount2 = interface(IInspectable)
  ['{38F52F1C-1136-4257-959F-B658A352B6D4}']
    function GetConnectionProfiles: IVectorView_1__IConnectionProfile; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccount3
  IMobileBroadbandAccount3 = interface(IInspectable)
  ['{092A1E21-9379-4B9B-AD31-D5FEE2F748C6}']
    function get_AccountExperienceUrl: IUriRuntimeClass; safecall;
    property AccountExperienceUrl: IUriRuntimeClass read get_AccountExperienceUrl;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountEventArgs
  IMobileBroadbandAccountEventArgs = interface(IInspectable)
  ['{3853C880-77DE-4C04-BEAD-A123B08C9F59}']
    function get_NetworkAccountId: HSTRING; safecall;
    property NetworkAccountId: HSTRING read get_NetworkAccountId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_MobileBroadbandAccount)]
  IMobileBroadbandAccountStatics = interface(IInspectable)
  ['{AA7F4D24-AFC1-4FC8-AE9A-A9175310FAAD}']
    function get_AvailableNetworkAccountIds: IVectorView_1__HSTRING; safecall;
    function CreateFromNetworkAccountId(networkAccountId: HSTRING): IMobileBroadbandAccount; safecall;
    property AvailableNetworkAccountIds: IVectorView_1__HSTRING read get_AvailableNetworkAccountIds;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountUpdatedEventArgs
  IMobileBroadbandAccountUpdatedEventArgs = interface(IInspectable)
  ['{7BC31D88-A6BD-49E1-80AB-6B91354A57D4}']
    function get_NetworkAccountId: HSTRING; safecall;
    function get_HasDeviceInformationChanged: Boolean; safecall;
    function get_HasNetworkChanged: Boolean; safecall;
    property HasDeviceInformationChanged: Boolean read get_HasDeviceInformationChanged;
    property HasNetworkChanged: Boolean read get_HasNetworkChanged;
    property NetworkAccountId: HSTRING read get_NetworkAccountId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.MobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.MobileBroadbandAccountEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.IMobileBroadbandAccountEventArgs>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs = interface(IUnknown)
  ['{423CC41E-FE8C-5A7D-9FEE-AAE04EF85700}']
    procedure Invoke(sender: IMobileBroadbandAccountWatcher; args: IMobileBroadbandAccountEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.MobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.MobileBroadbandAccountUpdatedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Windows.Networking.NetworkOperators.IMobileBroadbandAccountUpdatedEventArgs>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountUpdatedEventArgs = interface(IUnknown)
  ['{0E865096-1FFA-5792-8D4F-8623E3C77F56}']
    procedure Invoke(sender: IMobileBroadbandAccountWatcher; args: IMobileBroadbandAccountUpdatedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.MobileBroadbandAccountWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher,Object>
  TypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable = interface(IUnknown)
  ['{E4DC9CFC-F462-5AFD-856D-04ACE229D00E}']
    procedure Invoke(sender: IMobileBroadbandAccountWatcher; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_MobileBroadbandAccountWatcher)]
  IMobileBroadbandAccountWatcher = interface(IInspectable)
  ['{6BF3335E-23B5-449F-928D-5E0D3E04471D}']
    function add_AccountAdded(handler: TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs): EventRegistrationToken; safecall;
    procedure remove_AccountAdded(cookie: EventRegistrationToken); safecall;
    function add_AccountUpdated(handler: TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountUpdatedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AccountUpdated(cookie: EventRegistrationToken); safecall;
    function add_AccountRemoved(handler: TypedEventHandler_2__IMobileBroadbandAccountWatcher__IMobileBroadbandAccountEventArgs): EventRegistrationToken; safecall;
    procedure remove_AccountRemoved(cookie: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(cookie: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__IMobileBroadbandAccountWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(cookie: EventRegistrationToken); safecall;
    function get_Status: MobileBroadbandAccountWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: MobileBroadbandAccountWatcherStatus read get_Status;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IIterator_1__MobileBroadbandPinType = interface(IInspectable)
  ['{23EFCF0C-1F8E-5BD9-8B57-F0850121201C}']
    function get_Current: MobileBroadbandPinType; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PMobileBroadbandPinType): Cardinal; safecall;
    property Current: MobileBroadbandPinType read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IIterable_1__MobileBroadbandPinType = interface(IInspectable)
  ['{9D55726D-813E-50FB-9498-87AA872DD6CA}']
    function First: IIterator_1__MobileBroadbandPinType; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.MobileBroadbandPinType>
  IVectorView_1__MobileBroadbandPinType = interface(IInspectable)
  ['{33394C13-028C-553E-867B-3C7C21B6F22D}']
    function GetAt(index: Cardinal): MobileBroadbandPinType; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: MobileBroadbandPinType; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PMobileBroadbandPinType): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult
  IMobileBroadbandPinOperationResult = interface(IInspectable)
  ['{11DDDC32-31E7-49F5-B663-123D3BEF0362}']
    function get_IsSuccessful: Boolean; safecall;
    function get_AttemptsRemaining: Cardinal; safecall;
    property AttemptsRemaining: Cardinal read get_AttemptsRemaining;
    property IsSuccessful: Boolean read get_IsSuccessful;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandPinOperationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult = interface(IUnknown)
  ['{595AD094-60E3-5349-8FE6-EA8ECBBB2541}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandPinOperationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandPinOperationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinOperationResult>
  IAsyncOperation_1__IMobileBroadbandPinOperationResult = interface(IInspectable)
  ['{2F76661C-2F74-5CE2-99F9-47D1A3A13633}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult; safecall;
    function GetResults: IMobileBroadbandPinOperationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandPinOperationResult read get_Completed write put_Completed;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPin
  IMobileBroadbandPin = interface(IInspectable)
  ['{E661D709-E779-45BF-8281-75323DF9E321}']
    function get_Type: MobileBroadbandPinType; safecall;
    function get_LockState: MobileBroadbandPinLockState; safecall;
    function get_Format: MobileBroadbandPinFormat; safecall;
    function get_Enabled: Boolean; safecall;
    function get_MaxLength: Cardinal; safecall;
    function get_MinLength: Cardinal; safecall;
    function get_AttemptsRemaining: Cardinal; safecall;
    function EnableAsync(currentPin: HSTRING): IAsyncOperation_1__IMobileBroadbandPinOperationResult; safecall;
    function DisableAsync(currentPin: HSTRING): IAsyncOperation_1__IMobileBroadbandPinOperationResult; safecall;
    function EnterAsync(currentPin: HSTRING): IAsyncOperation_1__IMobileBroadbandPinOperationResult; safecall;
    function ChangeAsync(currentPin: HSTRING; newPin: HSTRING): IAsyncOperation_1__IMobileBroadbandPinOperationResult; safecall;
    function UnblockAsync(pinUnblockKey: HSTRING; newPin: HSTRING): IAsyncOperation_1__IMobileBroadbandPinOperationResult; safecall;
    property AttemptsRemaining: Cardinal read get_AttemptsRemaining;
    property Enabled: Boolean read get_Enabled;
    property Format: MobileBroadbandPinFormat read get_Format;
    property LockState: MobileBroadbandPinLockState read get_LockState;
    property MaxLength: Cardinal read get_MaxLength;
    property MinLength: Cardinal read get_MinLength;
    property &Type: MobileBroadbandPinType read get_Type;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinManager
  IMobileBroadbandPinManager = interface(IInspectable)
  ['{83567EDD-6E1F-4B9B-A413-2B1F50CC36DF}']
    function get_SupportedPins: IVectorView_1__MobileBroadbandPinType; safecall;
    function GetPin(pinType: MobileBroadbandPinType): IMobileBroadbandPin; safecall;
    property SupportedPins: IVectorView_1__MobileBroadbandPinType read get_SupportedPins;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation2
  IMobileBroadbandDeviceInformation2 = interface(IInspectable)
  ['{2E467AF1-F932-4737-A722-03BA72370CB8}']
    function get_PinManager: IMobileBroadbandPinManager; safecall;
    function get_Revision: HSTRING; safecall;
    function get_SerialNumber: HSTRING; safecall;
    property PinManager: IMobileBroadbandPinManager read get_PinManager;
    property Revision: HSTRING read get_Revision;
    property SerialNumber: HSTRING read get_SerialNumber;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceInformation3
  IMobileBroadbandDeviceInformation3 = interface(IInspectable)
  ['{E08BB4BD-5D30-4B5A-92CC-D54DF881D49E}']
    function get_SimSpn: HSTRING; safecall;
    function get_SimPnn: HSTRING; safecall;
    function get_SimGid1: HSTRING; safecall;
    property SimGid1: HSTRING read get_SimGid1;
    property SimPnn: HSTRING read get_SimPnn;
    property SimSpn: HSTRING read get_SimSpn;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandModemStatus>
  AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus = interface(IUnknown)
  ['{B8628318-EE4F-5AF4-9E3B-AF994FA96C51}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__MobileBroadbandModemStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandModemStatus>
  IAsyncOperation_1__MobileBroadbandModemStatus = interface(IInspectable)
  ['{AB0D25AB-68CD-54AB-B19C-624711659D3D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus; safecall;
    function GetResults: MobileBroadbandModemStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__MobileBroadbandModemStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataReceivedEventArgs
  IMobileBroadbandDeviceServiceDataReceivedEventArgs = interface(IInspectable)
  ['{B6AA13DE-1380-40E3-8618-73CBCA48138C}']
    function get_ReceivedData: IBuffer; safecall;
    property ReceivedData: IBuffer read get_ReceivedData;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceDataSession,Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceDataReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataSession,Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataReceivedEventArgs>
  TypedEventHandler_2__IMobileBroadbandDeviceServiceDataSession__IMobileBroadbandDeviceServiceDataReceivedEventArgs = interface(IUnknown)
  ['{31F89CA6-DD7F-5325-9020-627D8B47EA02}']
    procedure Invoke(sender: IMobileBroadbandDeviceServiceDataSession; args: IMobileBroadbandDeviceServiceDataReceivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceDataSession
  IMobileBroadbandDeviceServiceDataSession = interface(IInspectable)
  ['{DAD62333-8BCF-4289-8A37-045C2169486A}']
    function WriteDataAsync(value: IBuffer): IAsyncAction; safecall;
    procedure CloseSession; safecall;
    function add_DataReceived(eventHandler: TypedEventHandler_2__IMobileBroadbandDeviceServiceDataSession__IMobileBroadbandDeviceServiceDataReceivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_DataReceived(eventCookie: EventRegistrationToken); safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult
  IMobileBroadbandDeviceServiceCommandResult = interface(IInspectable)
  ['{B0F46ABB-94D6-44B9-A538-F0810B645389}']
    function get_StatusCode: Cardinal; safecall;
    function get_ResponseData: IBuffer; safecall;
    property ResponseData: IBuffer read get_ResponseData;
    property StatusCode: Cardinal read get_StatusCode;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceCommandResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult = interface(IUnknown)
  ['{21F0CE4F-8F33-5E71-A457-DDA553B0D6BB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceCommandResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandResult>
  IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult = interface(IInspectable)
  ['{2C673AA8-6A35-50FD-9422-3615A1C28CCB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult; safecall;
    function GetResults: IMobileBroadbandDeviceServiceCommandResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandDeviceServiceCommandResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceCommandSession
  IMobileBroadbandDeviceServiceCommandSession = interface(IInspectable)
  ['{FC098A45-913B-4914-B6C3-AE6304593E75}']
    function SendQueryCommandAsync(commandId: Cardinal; data: IBuffer): IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult; safecall;
    function SendSetCommandAsync(commandId: Cardinal; data: IBuffer): IAsyncOperation_1__IMobileBroadbandDeviceServiceCommandResult; safecall;
    procedure CloseSession; safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceService
  IMobileBroadbandDeviceService = interface(IInspectable)
  ['{22BE1A52-BD80-40AC-8E1F-2E07836A3DBD}']
    function get_DeviceServiceId: TGuid; safecall;
    function get_SupportedCommands: IVectorView_1__Cardinal; safecall;
    function OpenDataSession: IMobileBroadbandDeviceServiceDataSession; safecall;
    function OpenCommandSession: IMobileBroadbandDeviceServiceCommandSession; safecall;
    property DeviceServiceId: TGuid read get_DeviceServiceId;
    property SupportedCommands: IVectorView_1__Cardinal read get_SupportedCommands;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation
  IMobileBroadbandDeviceServiceInformation = interface(IInspectable)
  ['{53D69B5B-C4ED-45F0-803A-D9417A6D9846}']
    function get_DeviceServiceId: TGuid; safecall;
    function get_IsDataReadSupported: Boolean; safecall;
    function get_IsDataWriteSupported: Boolean; safecall;
    property DeviceServiceId: TGuid read get_DeviceServiceId;
    property IsDataReadSupported: Boolean read get_IsDataReadSupported;
    property IsDataWriteSupported: Boolean read get_IsDataWriteSupported;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceTriggerDetails
  IMobileBroadbandDeviceServiceTriggerDetails = interface(IInspectable)
  ['{4A055B70-B9AE-4458-9241-A6A5FBF18A0C}']
    function get_DeviceId: HSTRING; safecall;
    function get_DeviceServiceId: TGuid; safecall;
    function get_ReceivedData: IBuffer; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property DeviceServiceId: TGuid read get_DeviceServiceId;
    property ReceivedData: IBuffer read get_ReceivedData;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceTriggerDetails2
  IMobileBroadbandDeviceServiceTriggerDetails2 = interface(IInspectable)
  ['{D83D5F16-336A-553F-94BB-0CD1A2FF0C81}']
    function get_EventId: Cardinal; safecall;
    property EventId: Cardinal read get_EventId;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceInformation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IIterator_1__IMobileBroadbandDeviceServiceInformation = interface(IInspectable)
  ['{D8D776F6-4692-5461-9155-816E63BAC874}']
    function get_Current: IMobileBroadbandDeviceServiceInformation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMobileBroadbandDeviceServiceInformation): Cardinal; safecall;
    property Current: IMobileBroadbandDeviceServiceInformation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandDeviceServiceInformation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IIterable_1__IMobileBroadbandDeviceServiceInformation = interface(IInspectable)
  ['{88511855-6FE6-5694-83A7-991E29033DE5}']
    function First: IIterator_1__IMobileBroadbandDeviceServiceInformation; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandDeviceServiceInformation>
  IVectorView_1__IMobileBroadbandDeviceServiceInformation = interface(IInspectable)
  ['{52C008C3-0273-53EC-80FE-EAF6B34CE03F}']
    function GetAt(index: Cardinal): IMobileBroadbandDeviceServiceInformation; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMobileBroadbandDeviceServiceInformation; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMobileBroadbandDeviceServiceInformation): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult
  IMobileBroadbandUiccAppRecordDetailsResult = interface(IInspectable)
  ['{D919682F-BE14-4934-981D-2F57B9ED83E6}']
    function get_Status: MobileBroadbandUiccAppOperationStatus; safecall;
    function get_Kind: UiccAppRecordKind; safecall;
    function get_RecordCount: Integer; safecall;
    function get_RecordSize: Integer; safecall;
    function get_ReadAccessCondition: UiccAccessCondition; safecall;
    function get_WriteAccessCondition: UiccAccessCondition; safecall;
    property Kind: UiccAppRecordKind read get_Kind;
    property ReadAccessCondition: UiccAccessCondition read get_ReadAccessCondition;
    property RecordCount: Integer read get_RecordCount;
    property RecordSize: Integer read get_RecordSize;
    property Status: MobileBroadbandUiccAppOperationStatus read get_Status;
    property WriteAccessCondition: UiccAccessCondition read get_WriteAccessCondition;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppRecordDetailsResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult = interface(IUnknown)
  ['{D0B53858-0E54-5791-82ED-3313DC75DA45}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppRecordDetailsResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppRecordDetailsResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult = interface(IInspectable)
  ['{0774F4A6-BDBE-59FF-AA1C-A62E3C6F9D37}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult; safecall;
    function GetResults: IMobileBroadbandUiccAppRecordDetailsResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppRecordDetailsResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult
  IMobileBroadbandUiccAppReadRecordResult = interface(IInspectable)
  ['{64C95285-358E-47C5-8249-695F383B2BDB}']
    function get_Status: MobileBroadbandUiccAppOperationStatus; safecall;
    function get_Data: IBuffer; safecall;
    property Data: IBuffer read get_Data;
    property Status: MobileBroadbandUiccAppOperationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppReadRecordResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult = interface(IUnknown)
  ['{B81892B3-4CA9-5EC4-8971-2FBC19B56CA9}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppReadRecordResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppReadRecordResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult = interface(IInspectable)
  ['{27FC8483-30D8-5BE3-BC1E-8CCA0B241DF3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult; safecall;
    function GetResults: IMobileBroadbandUiccAppReadRecordResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppReadRecordResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp
  IMobileBroadbandUiccApp = interface(IInspectable)
  ['{4D170556-98A1-43DD-B2EC-50C90CF248DF}']
    function get_Id: IBuffer; safecall;
    function get_Kind: UiccAppKind; safecall;
    function GetRecordDetailsAsync(uiccFilePath: IIterable_1__Cardinal): IAsyncOperation_1__IMobileBroadbandUiccAppRecordDetailsResult; safecall;
    function ReadRecordAsync(uiccFilePath: IIterable_1__Cardinal; recordIndex: Integer): IAsyncOperation_1__IMobileBroadbandUiccAppReadRecordResult; safecall;
    property Id: IBuffer read get_Id;
    property Kind: UiccAppKind read get_Kind;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccApp>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IIterator_1__IMobileBroadbandUiccApp = interface(IInspectable)
  ['{4BB2066F-1B75-57CF-A722-1E58BFC5AE50}']
    function get_Current: IMobileBroadbandUiccApp; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMobileBroadbandUiccApp): Cardinal; safecall;
    property Current: IMobileBroadbandUiccApp read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccApp>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IIterable_1__IMobileBroadbandUiccApp = interface(IInspectable)
  ['{AF538114-BD14-53B0-B1D1-841DCAA451AD}']
    function First: IIterator_1__IMobileBroadbandUiccApp; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccApp>
  IVectorView_1__IMobileBroadbandUiccApp = interface(IInspectable)
  ['{61E0715E-E1F9-522E-8BD9-B1D946F964AE}']
    function GetAt(index: Cardinal): IMobileBroadbandUiccApp; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMobileBroadbandUiccApp; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMobileBroadbandUiccApp): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult
  IMobileBroadbandUiccAppsResult = interface(IInspectable)
  ['{744930EB-8157-4A41-8494-6BF54C9B1D2B}']
    function get_Status: MobileBroadbandUiccAppOperationStatus; safecall;
    function get_UiccApps: IVectorView_1__IMobileBroadbandUiccApp; safecall;
    property Status: MobileBroadbandUiccAppOperationStatus read get_Status;
    property UiccApps: IVectorView_1__IMobileBroadbandUiccApp read get_UiccApps;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppsResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult>
  AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult = interface(IUnknown)
  ['{A12BED56-C672-595E-A67B-49ABC285ADDC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandUiccAppsResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandUiccAppsResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandUiccAppsResult>
  IAsyncOperation_1__IMobileBroadbandUiccAppsResult = interface(IInspectable)
  ['{CF1CE97F-1A81-5CE6-8AD5-55FF8B0E8D1B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult; safecall;
    function GetResults: IMobileBroadbandUiccAppsResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandUiccAppsResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandUicc
  IMobileBroadbandUicc = interface(IInspectable)
  ['{E634F691-525A-4CE2-8FCE-AA4162579154}']
    function get_SimIccId: HSTRING; safecall;
    function GetUiccAppsAsync: IAsyncOperation_1__IMobileBroadbandUiccAppsResult; safecall;
    property SimIccId: HSTRING read get_SimIccId;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration
  IMobileBroadbandModemConfiguration = interface(IInspectable)
  ['{FCE035A3-D6CD-4320-B982-BE9D3EC7890F}']
    function get_Uicc: IMobileBroadbandUicc; safecall;
    function get_HomeProviderId: HSTRING; safecall;
    function get_HomeProviderName: HSTRING; safecall;
    property HomeProviderId: HSTRING read get_HomeProviderId;
    property HomeProviderName: HSTRING read get_HomeProviderName;
    property Uicc: IMobileBroadbandUicc read get_Uicc;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandModemConfiguration>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration>
  AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration = interface(IUnknown)
  ['{C11E0649-8237-5C93-BBDB-2EDA5216FD3F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandModemConfiguration; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandModemConfiguration>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandModemConfiguration>
  IAsyncOperation_1__IMobileBroadbandModemConfiguration = interface(IInspectable)
  ['{CDBE0003-DAAA-5C89-92E6-A47FFC2418A2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration; safecall;
    function GetResults: IMobileBroadbandModemConfiguration; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandModemConfiguration read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModem
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_MobileBroadbandModem)]
  IMobileBroadbandModem = interface(IInspectable)
  ['{D0356912-E9F9-4F67-A03D-43189A316BF1}']
    function get_CurrentAccount: IMobileBroadbandAccount; safecall;
    function get_DeviceInformation: IMobileBroadbandDeviceInformation; safecall;
    function get_MaxDeviceServiceCommandSizeInBytes: Cardinal; safecall;
    function get_MaxDeviceServiceDataSizeInBytes: Cardinal; safecall;
    function get_DeviceServices: IVectorView_1__IMobileBroadbandDeviceServiceInformation; safecall;
    function GetDeviceService(deviceServiceId: TGuid): IMobileBroadbandDeviceService; safecall;
    function get_IsResetSupported: Boolean; safecall;
    function ResetAsync: IAsyncAction; safecall;
    function GetCurrentConfigurationAsync: IAsyncOperation_1__IMobileBroadbandModemConfiguration; safecall;
    function get_CurrentNetwork: IMobileBroadbandNetwork; safecall;
    property CurrentAccount: IMobileBroadbandAccount read get_CurrentAccount;
    property CurrentNetwork: IMobileBroadbandNetwork read get_CurrentNetwork;
    property DeviceInformation: IMobileBroadbandDeviceInformation read get_DeviceInformation;
    property DeviceServices: IVectorView_1__IMobileBroadbandDeviceServiceInformation read get_DeviceServices;
    property IsResetSupported: Boolean read get_IsResetSupported;
    property MaxDeviceServiceCommandSizeInBytes: Cardinal read get_MaxDeviceServiceCommandSizeInBytes;
    property MaxDeviceServiceDataSizeInBytes: Cardinal read get_MaxDeviceServiceDataSizeInBytes;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModem2
  IMobileBroadbandModem2 = interface(IInspectable)
  ['{12862B28-B9EB-4EE2-BBE3-711F53EEA373}']
    function GetIsPassthroughEnabledAsync: IAsyncOperation_1__Boolean; safecall;
    function SetIsPassthroughEnabledAsync(value: Boolean): IAsyncOperation_1__MobileBroadbandModemStatus; safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandPco
  IMobileBroadbandPco = interface(IInspectable)
  ['{D4E4FCBE-E3A3-43C5-A87B-6C86D229D7FA}']
    function get_Data: IBuffer; safecall;
    function get_IsComplete: Boolean; safecall;
    function get_DeviceId: HSTRING; safecall;
    property Data: IBuffer read get_Data;
    property DeviceId: HSTRING read get_DeviceId;
    property IsComplete: Boolean read get_IsComplete;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.MobileBroadbandPco>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IMobileBroadbandPco>
  AsyncOperationCompletedHandler_1__IMobileBroadbandPco = interface(IUnknown)
  ['{C7D3FC9E-C381-545C-A8AE-6A464EDB16A2}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMobileBroadbandPco; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.MobileBroadbandPco>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IMobileBroadbandPco>
  IAsyncOperation_1__IMobileBroadbandPco = interface(IInspectable)
  ['{AE622260-0D4B-5B39-976B-A7AB610AC185}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMobileBroadbandPco); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandPco; safecall;
    function GetResults: IMobileBroadbandPco; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMobileBroadbandPco read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.MobileBroadbandModem,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Networking.NetworkOperators.IMobileBroadbandModem,Object>
  TypedEventHandler_2__IMobileBroadbandModem__IInspectable = interface(IUnknown)
  ['{F2DF3C8F-20B5-555C-A381-7E29D5AB51D7}']
    procedure Invoke(sender: IMobileBroadbandModem; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModem3
  IMobileBroadbandModem3 = interface(IInspectable)
  ['{E9FEC6EA-2F34-4582-9102-C314D2A87EEC}']
    function TryGetPcoAsync: IAsyncOperation_1__IMobileBroadbandPco; safecall;
    function get_IsInEmergencyCallMode: Boolean; safecall;
    function add_IsInEmergencyCallModeChanged(handler: TypedEventHandler_2__IMobileBroadbandModem__IInspectable): EventRegistrationToken; safecall;
    procedure remove_IsInEmergencyCallModeChanged(token: EventRegistrationToken); safecall;
    property IsInEmergencyCallMode: Boolean read get_IsInEmergencyCallMode;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModem4
  IMobileBroadbandModem4 = interface(IInspectable)
  ['{4A0398C2-91BE-412B-B569-586E9F0030D1}']
    function SetIsPassthroughEnabledAsync(value: Boolean; slotindex: Integer): IAsyncOperation_1__MobileBroadbandModemStatus; safecall;
    function GetIsPassthroughEnabledAsync(slotindex: Integer): IAsyncOperation_1__Boolean; safecall;
    function SetIsPassthroughEnabled(value: Boolean; slotindex: Integer): MobileBroadbandModemStatus; safecall;
    function GetIsPassthroughEnabled(slotindex: Integer): Boolean; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IMobileBroadbandModemStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_MobileBroadbandModem)]
  IMobileBroadbandModemStatics = interface(IInspectable)
  ['{F99ED637-D6F1-4A78-8CBC-6421A65063C8}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromId(deviceId: HSTRING): IMobileBroadbandModem; safecall;
    function GetDefault: IMobileBroadbandModem; safecall;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetwork2
  IMobileBroadbandNetwork2 = interface(IInspectable)
  ['{5A55DB22-62F7-4BDD-BA1D-477441960BA0}']
    function GetVoiceCallSupportAsync: IAsyncOperation_1__Boolean; safecall;
    function get_RegistrationUiccApps: IVectorView_1__IMobileBroadbandUiccApp; safecall;
    property RegistrationUiccApps: IVectorView_1__IMobileBroadbandUiccApp read get_RegistrationUiccApps;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange
  IMobileBroadbandNetworkRegistrationStateChange = interface(IInspectable)
  ['{BEAF94E1-960F-49B4-A08D-7D85E968C7EC}']
    function get_DeviceId: HSTRING; safecall;
    function get_Network: IMobileBroadbandNetwork; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property Network: IMobileBroadbandNetwork read get_Network;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandNetworkRegistrationStateChange>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IIterator_1__IMobileBroadbandNetworkRegistrationStateChange = interface(IInspectable)
  ['{9CB0F858-E589-57A7-9D01-2C6291567CC7}']
    function get_Current: IMobileBroadbandNetworkRegistrationStateChange; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMobileBroadbandNetworkRegistrationStateChange): Cardinal; safecall;
    property Current: IMobileBroadbandNetworkRegistrationStateChange read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandNetworkRegistrationStateChange>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IIterable_1__IMobileBroadbandNetworkRegistrationStateChange = interface(IInspectable)
  ['{0B90BB30-660C-51C6-9B8C-31DD8486E10E}']
    function First: IIterator_1__IMobileBroadbandNetworkRegistrationStateChange; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChange>
  IVectorView_1__IMobileBroadbandNetworkRegistrationStateChange = interface(IInspectable)
  ['{BD95AB62-44B2-5ADD-B16E-03D48253F162}']
    function GetAt(index: Cardinal): IMobileBroadbandNetworkRegistrationStateChange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMobileBroadbandNetworkRegistrationStateChange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMobileBroadbandNetworkRegistrationStateChange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandNetworkRegistrationStateChangeTriggerDetails
  IMobileBroadbandNetworkRegistrationStateChangeTriggerDetails = interface(IInspectable)
  ['{89135CFF-28B8-46AA-B137-1C4B0F21EDFE}']
    function get_NetworkRegistrationStateChanges: IVectorView_1__IMobileBroadbandNetworkRegistrationStateChange; safecall;
    property NetworkRegistrationStateChanges: IVectorView_1__IMobileBroadbandNetworkRegistrationStateChange read get_NetworkRegistrationStateChanges;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange
  IMobileBroadbandPinLockStateChange = interface(IInspectable)
  ['{BE16673E-1F04-4F95-8B90-E7F559DDE7E5}']
    function get_DeviceId: HSTRING; safecall;
    function get_PinType: MobileBroadbandPinType; safecall;
    function get_PinLockState: MobileBroadbandPinLockState; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property PinLockState: MobileBroadbandPinLockState read get_PinLockState;
    property PinType: MobileBroadbandPinType read get_PinType;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandPinLockStateChange>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IIterator_1__IMobileBroadbandPinLockStateChange = interface(IInspectable)
  ['{E61B479F-7BD9-5550-BC69-F9C2F71C6A05}']
    function get_Current: IMobileBroadbandPinLockStateChange; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMobileBroadbandPinLockStateChange): Cardinal; safecall;
    property Current: IMobileBroadbandPinLockStateChange read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandPinLockStateChange>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IIterable_1__IMobileBroadbandPinLockStateChange = interface(IInspectable)
  ['{AA4A8700-9943-59A3-8647-D373FD5E0E2B}']
    function First: IIterator_1__IMobileBroadbandPinLockStateChange; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChange>
  IVectorView_1__IMobileBroadbandPinLockStateChange = interface(IInspectable)
  ['{8AAE04EC-BB01-53AD-A97D-612EEE2A0D2A}']
    function GetAt(index: Cardinal): IMobileBroadbandPinLockStateChange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMobileBroadbandPinLockStateChange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMobileBroadbandPinLockStateChange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandPinLockStateChangeTriggerDetails
  IMobileBroadbandPinLockStateChangeTriggerDetails = interface(IInspectable)
  ['{D338C091-3E91-4D38-9036-AEE83A6E79AD}']
    function get_PinLockStateChanges: IVectorView_1__IMobileBroadbandPinLockStateChange; safecall;
    property PinLockStateChanges: IVectorView_1__IMobileBroadbandPinLockStateChange read get_PinLockStateChanges;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange
  IMobileBroadbandRadioStateChange = interface(IInspectable)
  ['{B054A561-9833-4AED-9717-4348B21A24B3}']
    function get_DeviceId: HSTRING; safecall;
    function get_RadioState: MobileBroadbandRadioState; safecall;
    property DeviceId: HSTRING read get_DeviceId;
    property RadioState: MobileBroadbandRadioState read get_RadioState;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.MobileBroadbandRadioStateChange>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IIterator_1__IMobileBroadbandRadioStateChange = interface(IInspectable)
  ['{C088CEC3-08E5-5F35-A2B9-0900D028C83B}']
    function get_Current: IMobileBroadbandRadioStateChange; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMobileBroadbandRadioStateChange): Cardinal; safecall;
    property Current: IMobileBroadbandRadioStateChange read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.MobileBroadbandRadioStateChange>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IIterable_1__IMobileBroadbandRadioStateChange = interface(IInspectable)
  ['{C385ADAA-574C-5AD8-98C2-61309525132D}']
    function First: IIterator_1__IMobileBroadbandRadioStateChange; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChange>
  IVectorView_1__IMobileBroadbandRadioStateChange = interface(IInspectable)
  ['{D1CB8E13-2478-5488-A9F6-863309D9DF35}']
    function GetAt(index: Cardinal): IMobileBroadbandRadioStateChange; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMobileBroadbandRadioStateChange; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMobileBroadbandRadioStateChange): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Networking.NetworkOperators.IMobileBroadbandRadioStateChangeTriggerDetails
  IMobileBroadbandRadioStateChangeTriggerDetails = interface(IInspectable)
  ['{71301ACE-093C-42C6-B0DB-AD1F75A65445}']
    function get_RadioStateChanges: IVectorView_1__IMobileBroadbandRadioStateChange; safecall;
    property RadioStateChanges: IVectorView_1__IMobileBroadbandRadioStateChange read get_RadioStateChanges;
  end;

  // Windows.Networking.NetworkOperators.INetworkOperatorNotificationEventDetails
  INetworkOperatorNotificationEventDetails = interface(IInspectable)
  ['{BC68A9D1-82E1-4488-9F2C-1276C2468FAC}']
    function get_NotificationType: NetworkOperatorEventMessageType; safecall;
    function get_NetworkAccountId: HSTRING; safecall;
    function get_EncodingType: Byte; safecall;
    function get_Message: HSTRING; safecall;
    function get_RuleId: HSTRING; safecall;
    function get_SmsMessage: ISmsMessage; safecall;
    property EncodingType: Byte read get_EncodingType;
    property &Message: HSTRING read get_Message;
    property NetworkAccountId: HSTRING read get_NetworkAccountId;
    property NotificationType: NetworkOperatorEventMessageType read get_NotificationType;
    property RuleId: HSTRING read get_RuleId;
    property SmsMessage: ISmsMessage read get_SmsMessage;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringAccessPointConfiguration)]
  INetworkOperatorTetheringAccessPointConfiguration = interface(IInspectable)
  ['{0BCC0284-412E-403D-ACC6-B757E34774A4}']
    function get_Ssid: HSTRING; safecall;
    procedure put_Ssid(value: HSTRING); safecall;
    function get_Passphrase: HSTRING; safecall;
    procedure put_Passphrase(value: HSTRING); safecall;
    property Passphrase: HSTRING read get_Passphrase write put_Passphrase;
    property Ssid: HSTRING read get_Ssid write put_Ssid;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration2
  INetworkOperatorTetheringAccessPointConfiguration2 = interface(IInspectable)
  ['{B1809142-7238-59A0-928B-74AB46FD64B6}']
    function IsBandSupported(band: TetheringWiFiBand): Boolean; safecall;
    function IsBandSupportedAsync(band: TetheringWiFiBand): IAsyncOperation_1__Boolean; safecall;
    function get_Band: TetheringWiFiBand; safecall;
    procedure put_Band(value: TetheringWiFiBand); safecall;
    property Band: TetheringWiFiBand read get_Band write put_Band;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration3
  INetworkOperatorTetheringAccessPointConfiguration3 = interface(IInspectable)
  ['{A9BB0081-9EED-5D18-B676-24B74A182B8C}']
    function IsAuthenticationKindSupported(authenticationKind: TetheringWiFiAuthenticationKind): Boolean; safecall;
    function IsAuthenticationKindSupportedAsync(authenticationKind: TetheringWiFiAuthenticationKind): IAsyncOperation_1__Boolean; safecall;
    function get_AuthenticationKind: TetheringWiFiAuthenticationKind; safecall;
    procedure put_AuthenticationKind(value: TetheringWiFiAuthenticationKind); safecall;
    property AuthenticationKind: TetheringWiFiAuthenticationKind read get_AuthenticationKind write put_AuthenticationKind;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient
  INetworkOperatorTetheringClient = interface(IInspectable)
  ['{709D254C-595F-4847-BB30-646935542918}']
    function get_MacAddress: HSTRING; safecall;
    function get_HostNames: IVectorView_1__IHostName; safecall;
    property HostNames: IVectorView_1__IHostName read get_HostNames;
    property MacAddress: HSTRING read get_MacAddress;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.NetworkOperatorTetheringClient>
  // Windows.Foundation.Collections.IIterator`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IIterator_1__INetworkOperatorTetheringClient = interface(IInspectable)
  ['{5653D065-C708-5341-BC05-D3B9CECD2AC7}']
    function get_Current: INetworkOperatorTetheringClient; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PINetworkOperatorTetheringClient): Cardinal; safecall;
    property Current: INetworkOperatorTetheringClient read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.NetworkOperatorTetheringClient>
  // Windows.Foundation.Collections.IIterable`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IIterable_1__INetworkOperatorTetheringClient = interface(IInspectable)
  ['{4762ECB3-AF48-5B63-89B7-78A42056549F}']
    function First: IIterator_1__INetworkOperatorTetheringClient; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringClient>
  IVectorView_1__INetworkOperatorTetheringClient = interface(IInspectable)
  ['{23AA5A28-AD35-5C47-976A-53269CDC5293}']
    function GetAt(index: Cardinal): INetworkOperatorTetheringClient; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: INetworkOperatorTetheringClient; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PINetworkOperatorTetheringClient): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringClientManager
  INetworkOperatorTetheringClientManager = interface(IInspectable)
  ['{91B14016-8DCA-4225-BBED-EEF8B8D718D7}']
    function GetTetheringClients: IVectorView_1__INetworkOperatorTetheringClient; safecall;
  end;

  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringEntitlementCheck
  INetworkOperatorTetheringEntitlementCheck = interface(IInspectable)
  ['{0108916D-9E9A-4AF6-8DA3-60493B19C204}']
    procedure AuthorizeTethering(allow: Boolean; entitlementFailureReason: HSTRING); safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult
  INetworkOperatorTetheringOperationResult = interface(IInspectable)
  ['{EBD203A1-01BA-476D-B4B3-BF3D12C8F80C}']
    function get_Status: TetheringOperationStatus; safecall;
    function get_AdditionalErrorMessage: HSTRING; safecall;
    property AdditionalErrorMessage: HSTRING read get_AdditionalErrorMessage;
    property Status: TetheringOperationStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult>
  AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult = interface(IUnknown)
  ['{A936B927-7537-59C6-89DE-33F36A9725AB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__INetworkOperatorTetheringOperationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.INetworkOperatorTetheringOperationResult>
  IAsyncOperation_1__INetworkOperatorTetheringOperationResult = interface(IInspectable)
  ['{601B30ED-9B7F-54B6-B61B-24A09BC56304}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult; safecall;
    function GetResults: INetworkOperatorTetheringOperationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__INetworkOperatorTetheringOperationResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringManager)]
  INetworkOperatorTetheringManager = interface(IInspectable)
  ['{D45A8DA0-0E86-4D98-8BA4-DD70D4B764D3}']
    function get_MaxClientCount: Cardinal; safecall;
    function get_ClientCount: Cardinal; safecall;
    function get_TetheringOperationalState: TetheringOperationalState; safecall;
    function GetCurrentAccessPointConfiguration: INetworkOperatorTetheringAccessPointConfiguration; safecall;
    function ConfigureAccessPointAsync(configuration: INetworkOperatorTetheringAccessPointConfiguration): IAsyncAction; safecall;
    function StartTetheringAsync: IAsyncOperation_1__INetworkOperatorTetheringOperationResult; safecall;
    function StopTetheringAsync: IAsyncOperation_1__INetworkOperatorTetheringOperationResult; safecall;
    property ClientCount: Cardinal read get_ClientCount;
    property MaxClientCount: Cardinal read get_MaxClientCount;
    property TetheringOperationalState_: TetheringOperationalState read get_TetheringOperationalState;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringSessionAccessPointConfiguration
  INetworkOperatorTetheringSessionAccessPointConfiguration = interface(IInspectable)
  ['{0BCC1104-34B7-5212-858C-59D97404920A}']
    function get_Ssid: HSTRING; safecall;
    procedure put_Ssid(value: HSTRING); safecall;
    function get_Passphrase: HSTRING; safecall;
    procedure put_Passphrase(value: HSTRING); safecall;
    function IsBandSupported(band: TetheringWiFiBand): Boolean; safecall;
    function IsBandSupportedAsync(band: TetheringWiFiBand): IAsyncOperation_1__Boolean; safecall;
    function get_Band: TetheringWiFiBand; safecall;
    procedure put_Band(value: TetheringWiFiBand); safecall;
    function IsAuthenticationKindSupported(authenticationKind: TetheringWiFiAuthenticationKind): Boolean; safecall;
    function IsAuthenticationKindSupportedAsync(authenticationKind: TetheringWiFiAuthenticationKind): IAsyncOperation_1__Boolean; safecall;
    function get_AuthenticationKind: TetheringWiFiAuthenticationKind; safecall;
    procedure put_AuthenticationKind(value: TetheringWiFiAuthenticationKind); safecall;
    function get_PerformancePriority: TetheringWiFiPerformancePriority; safecall;
    procedure put_PerformancePriority(value: TetheringWiFiPerformancePriority); safecall;
    property AuthenticationKind: TetheringWiFiAuthenticationKind read get_AuthenticationKind write put_AuthenticationKind;
    property Band: TetheringWiFiBand read get_Band write put_Band;
    property Passphrase: HSTRING read get_Passphrase write put_Passphrase;
    property PerformancePriority: TetheringWiFiPerformancePriority read get_PerformancePriority write put_PerformancePriority;
    property Ssid: HSTRING read get_Ssid write put_Ssid;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager2
  INetworkOperatorTetheringManager2 = interface(IInspectable)
  ['{7C1A4DF2-B789-4FEA-BC4E-1F2B9E76C1F7}']
    function StartTetheringAsync(configuration: INetworkOperatorTetheringSessionAccessPointConfiguration): IAsyncOperation_1__INetworkOperatorTetheringOperationResult; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringManager)]
  INetworkOperatorTetheringManagerStatics = interface(IInspectable)
  ['{3EBCBACC-F8C3-405C-9964-70A1EEABE194}']
    function GetTetheringCapability(networkAccountId: HSTRING): TetheringCapability; safecall;
    function CreateFromNetworkAccountId(networkAccountId: HSTRING): INetworkOperatorTetheringManager; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics2
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringManager)]
  INetworkOperatorTetheringManagerStatics2 = interface(IInspectable)
  ['{5B235412-35F0-49E7-9B08-16D278FBAA42}']
    function GetTetheringCapabilityFromConnectionProfile(profile: IConnectionProfile): TetheringCapability; safecall;
    function CreateFromConnectionProfile(profile: IConnectionProfile): INetworkOperatorTetheringManager; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics3
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringManager)]
  INetworkOperatorTetheringManagerStatics3 = interface(IInspectable)
  ['{8FDAADB6-4AF9-4F21-9B58-D53E9F24231E}']
    function CreateFromConnectionProfile(profile: IConnectionProfile; adapter: INetworkAdapter): INetworkOperatorTetheringManager; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics4
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_NetworkOperatorTetheringManager)]
  INetworkOperatorTetheringManagerStatics4 = interface(IInspectable)
  ['{B3B9F9D0-EBFF-46A4-A847-D663D8B0977E}']
    function IsNoConnectionsTimeoutEnabled: Boolean; safecall;
    procedure EnableNoConnectionsTimeout; safecall;
    function EnableNoConnectionsTimeoutAsync: IAsyncAction; safecall;
    procedure DisableNoConnectionsTimeout; safecall;
    function DisableNoConnectionsTimeoutAsync: IAsyncAction; safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults
  IProvisionFromXmlDocumentResults = interface(IInspectable)
  ['{217700E0-8203-11DF-ADB9-F4CE462D9137}']
    function get_AllElementsProvisioned: Boolean; safecall;
    function get_ProvisionResultsXml: HSTRING; safecall;
    property AllElementsProvisioned: Boolean read get_AllElementsProvisioned;
    property ProvisionResultsXml: HSTRING read get_ProvisionResultsXml;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IProvisionedProfile
  IProvisionedProfile = interface(IInspectable)
  ['{217700E0-8202-11DF-ADB9-F4CE462D9137}']
    procedure UpdateCost(value: NetworkCostType); safecall;
    procedure UpdateUsage(value: ProfileUsage); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.ProvisionFromXmlDocumentResults>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults>
  AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults = interface(IUnknown)
  ['{7A7EEE1B-17F9-5A41-861B-C30EA127D0F1}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IProvisionFromXmlDocumentResults; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.ProvisionFromXmlDocumentResults>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IProvisionFromXmlDocumentResults>
  IAsyncOperation_1__IProvisionFromXmlDocumentResults = interface(IInspectable)
  ['{9F8FE338-C6B1-5614-A14F-8977A77E17F2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults; safecall;
    function GetResults: IProvisionFromXmlDocumentResults; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IProvisionFromXmlDocumentResults read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IProvisioningAgent
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_ProvisioningAgent)]
  IProvisioningAgent = interface(IInspectable)
  ['{217700E0-8201-11DF-ADB9-F4CE462D9137}']
    function ProvisionFromXmlDocumentAsync(provisioningXmlDocument: HSTRING): IAsyncOperation_1__IProvisionFromXmlDocumentResults; safecall;
    function GetProvisionedProfile(mediaType: ProfileMediaType; profileName: HSTRING): IProvisionedProfile; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IProvisioningAgentStaticMethods
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_ProvisioningAgent)]
  IProvisioningAgentStaticMethods = interface(IInspectable)
  ['{217700E0-8101-11DF-ADB9-F4CE462D9137}']
    function CreateFromNetworkAccountId(networkAccountId: HSTRING): IProvisioningAgent; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IUssdMessage
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_UssdMessage)]
  IUssdMessage = interface(IInspectable)
  ['{2F9ACF82-2004-4D5D-BF81-2ABA1B4BE4A8}']
    function get_DataCodingScheme: Byte; safecall;
    procedure put_DataCodingScheme(value: Byte); safecall;
    function GetPayload(resultSize: Cardinal; resultValue: PByte): HRESULT; stdcall;
    procedure SetPayload(valueSize: Cardinal; value: PByte); safecall;
    function get_PayloadAsText: HSTRING; safecall;
    procedure put_PayloadAsText(value: HSTRING); safecall;
    property DataCodingScheme: Byte read get_DataCodingScheme write put_DataCodingScheme;
    property PayloadAsText: HSTRING read get_PayloadAsText write put_PayloadAsText;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IUssdMessageFactory
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_UssdMessage)]
  IUssdMessageFactory = interface(IInspectable)
  ['{2F9ACF82-1003-4D5D-BF81-2ABA1B4BE4A8}']
    function CreateMessage(messageText: HSTRING): IUssdMessage; safecall;
  end;

  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IUssdReply
  IUssdReply = interface(IInspectable)
  ['{2F9ACF82-2005-4D5D-BF81-2ABA1B4BE4A8}']
    function get_ResultCode: UssdResultCode; safecall;
    function get_Message: IUssdMessage; safecall;
    property &Message: IUssdMessage read get_Message;
    property ResultCode: UssdResultCode read get_ResultCode;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.UssdReply>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Networking.NetworkOperators.IUssdReply>
  AsyncOperationCompletedHandler_1__IUssdReply = interface(IUnknown)
  ['{9385BD8F-5E14-557A-A7F1-63F33D9ECACF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IUssdReply; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.UssdReply>
  // Windows.Foundation.IAsyncOperation`1<Windows.Networking.NetworkOperators.IUssdReply>
  IAsyncOperation_1__IUssdReply = interface(IInspectable)
  ['{9DD0A063-6153-5AFD-8288-8770DDCFF2DB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IUssdReply); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IUssdReply; safecall;
    function GetResults: IUssdReply; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IUssdReply read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IUssdSession
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_UssdSession)]
  IUssdSession = interface(IInspectable)
  ['{2F9ACF82-2002-4D5D-BF81-2ABA1B4BE4A8}']
    function SendMessageAndGetReplyAsync(&message: IUssdMessage): IAsyncOperation_1__IUssdReply; safecall;
    procedure Close; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Networking.NetworkOperators.IUssdSessionStatics
  [WinRTClassNameAttribute(SWindows_Networking_NetworkOperators_UssdSession)]
  IUssdSessionStatics = interface(IInspectable)
  ['{2F9ACF82-1001-4D5D-BF81-2ABA1B4BE4A8}']
    function CreateFromNetworkAccountId(networkAccountId: HSTRING): IUssdSession; safecall;
    function CreateFromNetworkInterfaceId(networkInterfaceId: HSTRING): IUssdSession; safecall;
  end;

  // Windows.Networking.NetworkOperators.KnownCSimFilePaths
  // DualAPI
  // Statics: "Windows.Networking.NetworkOperators.IKnownCSimFilePathsStatics"
  TKnownCSimFilePaths = class(TWinRTGenericImportS<IKnownCSimFilePathsStatics>)
  public
    {$REGION 'IKnownCSimFilePathsStatics'}
    class function get_EFSpn: IVectorView_1__Cardinal; static; inline;
    class function get_Gid1: IVectorView_1__Cardinal; static; inline;
    class function get_Gid2: IVectorView_1__Cardinal; static; inline;
    class property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    class property Gid1: IVectorView_1__Cardinal read get_Gid1;
    class property Gid2: IVectorView_1__Cardinal read get_Gid2;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.KnownRuimFilePaths
  // DualAPI
  // Statics: "Windows.Networking.NetworkOperators.IKnownRuimFilePathsStatics"
  TKnownRuimFilePaths = class(TWinRTGenericImportS<IKnownRuimFilePathsStatics>)
  public
    {$REGION 'IKnownRuimFilePathsStatics'}
    class function get_EFSpn: IVectorView_1__Cardinal; static; inline;
    class function get_Gid1: IVectorView_1__Cardinal; static; inline;
    class function get_Gid2: IVectorView_1__Cardinal; static; inline;
    class property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    class property Gid1: IVectorView_1__Cardinal read get_Gid1;
    class property Gid2: IVectorView_1__Cardinal read get_Gid2;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.KnownSimFilePaths
  // DualAPI
  // Statics: "Windows.Networking.NetworkOperators.IKnownSimFilePathsStatics"
  TKnownSimFilePaths = class(TWinRTGenericImportS<IKnownSimFilePathsStatics>)
  public
    {$REGION 'IKnownSimFilePathsStatics'}
    class function get_EFOns: IVectorView_1__Cardinal; static; inline;
    class function get_EFSpn: IVectorView_1__Cardinal; static; inline;
    class function get_Gid1: IVectorView_1__Cardinal; static; inline;
    class function get_Gid2: IVectorView_1__Cardinal; static; inline;
    class property EFOns: IVectorView_1__Cardinal read get_EFOns;
    class property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    class property Gid1: IVectorView_1__Cardinal read get_Gid1;
    class property Gid2: IVectorView_1__Cardinal read get_Gid2;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.KnownUSimFilePaths
  // DualAPI
  // Statics: "Windows.Networking.NetworkOperators.IKnownUSimFilePathsStatics"
  TKnownUSimFilePaths = class(TWinRTGenericImportS<IKnownUSimFilePathsStatics>)
  public
    {$REGION 'IKnownUSimFilePathsStatics'}
    class function get_EFSpn: IVectorView_1__Cardinal; static; inline;
    class function get_EFOpl: IVectorView_1__Cardinal; static; inline;
    class function get_EFPnn: IVectorView_1__Cardinal; static; inline;
    class function get_Gid1: IVectorView_1__Cardinal; static; inline;
    class function get_Gid2: IVectorView_1__Cardinal; static; inline;
    class property EFOpl: IVectorView_1__Cardinal read get_EFOpl;
    class property EFPnn: IVectorView_1__Cardinal read get_EFPnn;
    class property EFSpn: IVectorView_1__Cardinal read get_EFSpn;
    class property Gid1: IVectorView_1__Cardinal read get_Gid1;
    class property Gid2: IVectorView_1__Cardinal read get_Gid2;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.MobileBroadbandAccount
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandAccount
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandAccount2
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandAccount3
  // Statics: "Windows.Networking.NetworkOperators.IMobileBroadbandAccountStatics"
  TMobileBroadbandAccount = class(TWinRTGenericImportS<IMobileBroadbandAccountStatics>)
  public
    {$REGION 'IMobileBroadbandAccountStatics'}
    class function get_AvailableNetworkAccountIds: IVectorView_1__HSTRING; static; inline;
    class function CreateFromNetworkAccountId(networkAccountId: HSTRING): IMobileBroadbandAccount; static; inline;
    class property AvailableNetworkAccountIds: IVectorView_1__HSTRING read get_AvailableNetworkAccountIds;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.MobileBroadbandAccountWatcher
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandAccountWatcher
  // Instantiable: "IMobileBroadbandAccountWatcher"
  TMobileBroadbandAccountWatcher = class(TWinRTGenericImportI<IMobileBroadbandAccountWatcher>) end;

  // Windows.Networking.NetworkOperators.MobileBroadbandModem
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandModem
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandModem2
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandModem3
  // Implements: Windows.Networking.NetworkOperators.IMobileBroadbandModem4
  // Statics: "Windows.Networking.NetworkOperators.IMobileBroadbandModemStatics"
  TMobileBroadbandModem = class(TWinRTGenericImportS<IMobileBroadbandModemStatics>)
  public
    {$REGION 'IMobileBroadbandModemStatics'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromId(deviceId: HSTRING): IMobileBroadbandModem; static; inline;
    class function GetDefault: IMobileBroadbandModem; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.NetworkOperatorTetheringAccessPointConfiguration
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration2
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringAccessPointConfiguration3
  // Instantiable: "INetworkOperatorTetheringAccessPointConfiguration"
  TNetworkOperatorTetheringAccessPointConfiguration = class(TWinRTGenericImportI<INetworkOperatorTetheringAccessPointConfiguration>) end;

  // Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringClientManager
  // Implements: Windows.Networking.NetworkOperators.INetworkOperatorTetheringManager2
  // Statics: "Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics"
  // Statics: "Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics2"
  // Statics: "Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics3"
  // Statics: "Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics4"
  TNetworkOperatorTetheringManager = class(TWinRTGenericImportS4<INetworkOperatorTetheringManagerStatics, INetworkOperatorTetheringManagerStatics2, INetworkOperatorTetheringManagerStatics3, INetworkOperatorTetheringManagerStatics4>)
  public
    {$REGION 'INetworkOperatorTetheringManagerStatics'}
    class function GetTetheringCapability(networkAccountId: HSTRING): TetheringCapability; static; inline;
    class function CreateFromNetworkAccountId(networkAccountId: HSTRING): INetworkOperatorTetheringManager; static; inline;
    {$ENDREGION}
    {$REGION 'INetworkOperatorTetheringManagerStatics2'}
    class function GetTetheringCapabilityFromConnectionProfile(profile: IConnectionProfile): TetheringCapability; static; inline;
    class function CreateFromConnectionProfile(profile: IConnectionProfile): INetworkOperatorTetheringManager; overload; static; inline;
    {$ENDREGION}
    {$REGION 'INetworkOperatorTetheringManagerStatics3'}
    class function CreateFromConnectionProfile(profile: IConnectionProfile; adapter: INetworkAdapter): INetworkOperatorTetheringManager; overload; static; inline;
    {$ENDREGION}
    {$REGION 'INetworkOperatorTetheringManagerStatics4'}
    class function IsNoConnectionsTimeoutEnabled: Boolean; static; inline;
    class procedure EnableNoConnectionsTimeout; static; inline;
    class function EnableNoConnectionsTimeoutAsync: IAsyncAction; static; inline;
    class procedure DisableNoConnectionsTimeout; static; inline;
    class function DisableNoConnectionsTimeoutAsync: IAsyncAction; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.ProvisioningAgent
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IProvisioningAgent
  // Statics: "Windows.Networking.NetworkOperators.IProvisioningAgentStaticMethods"
  // Instantiable: "IProvisioningAgent"
  TProvisioningAgent = class(TWinRTGenericImportSI<IProvisioningAgentStaticMethods, IProvisioningAgent>)
  public
    {$REGION 'IProvisioningAgentStaticMethods'}
    class function CreateFromNetworkAccountId(networkAccountId: HSTRING): IProvisioningAgent; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.UssdMessage
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IUssdMessage
  // Factory: "Windows.Networking.NetworkOperators.IUssdMessageFactory"
  TUssdMessage = class(TWinRTGenericImportF<IUssdMessageFactory>)
  public
    {$REGION 'IUssdMessageFactory'}
    class function CreateMessage(messageText: HSTRING): IUssdMessage; static; inline;
    {$ENDREGION}
 end;

  // Windows.Networking.NetworkOperators.UssdSession
  // DualAPI
  // Implements: Windows.Networking.NetworkOperators.IUssdSession
  // Statics: "Windows.Networking.NetworkOperators.IUssdSessionStatics"
  TUssdSession = class(TWinRTGenericImportS<IUssdSessionStatics>)
  public
    {$REGION 'IUssdSessionStatics'}
    class function CreateFromNetworkAccountId(networkAccountId: HSTRING): IUssdSession; static; inline;
    class function CreateFromNetworkInterfaceId(networkInterfaceId: HSTRING): IUssdSession; static; inline;
    {$ENDREGION}
 end;

implementation

{ TKnownCSimFilePaths }

{$REGION 'Windows.Networking.NetworkOperators.IKnownCSimFilePathsStatics'}
class function TKnownCSimFilePaths.get_EFSpn: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFSpn;
end;

class function TKnownCSimFilePaths.get_Gid1: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid1;
end;

class function TKnownCSimFilePaths.get_Gid2: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid2;
end;
{$ENDREGION}

{ TKnownRuimFilePaths }

{$REGION 'Windows.Networking.NetworkOperators.IKnownRuimFilePathsStatics'}
class function TKnownRuimFilePaths.get_EFSpn: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFSpn;
end;

class function TKnownRuimFilePaths.get_Gid1: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid1;
end;

class function TKnownRuimFilePaths.get_Gid2: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid2;
end;
{$ENDREGION}

{ TKnownSimFilePaths }

{$REGION 'Windows.Networking.NetworkOperators.IKnownSimFilePathsStatics'}
class function TKnownSimFilePaths.get_EFOns: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFOns;
end;

class function TKnownSimFilePaths.get_EFSpn: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFSpn;
end;

class function TKnownSimFilePaths.get_Gid1: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid1;
end;

class function TKnownSimFilePaths.get_Gid2: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid2;
end;
{$ENDREGION}

{ TKnownUSimFilePaths }

{$REGION 'Windows.Networking.NetworkOperators.IKnownUSimFilePathsStatics'}
class function TKnownUSimFilePaths.get_EFSpn: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFSpn;
end;

class function TKnownUSimFilePaths.get_EFOpl: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFOpl;
end;

class function TKnownUSimFilePaths.get_EFPnn: IVectorView_1__Cardinal;
begin
  Result := Statics.get_EFPnn;
end;

class function TKnownUSimFilePaths.get_Gid1: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid1;
end;

class function TKnownUSimFilePaths.get_Gid2: IVectorView_1__Cardinal;
begin
  Result := Statics.get_Gid2;
end;
{$ENDREGION}

{ TMobileBroadbandAccount }

{$REGION 'Windows.Networking.NetworkOperators.IMobileBroadbandAccountStatics'}
class function TMobileBroadbandAccount.get_AvailableNetworkAccountIds: IVectorView_1__HSTRING;
begin
  Result := Statics.get_AvailableNetworkAccountIds;
end;

class function TMobileBroadbandAccount.CreateFromNetworkAccountId(networkAccountId: HSTRING): IMobileBroadbandAccount;
begin
  Result := Statics.CreateFromNetworkAccountId(networkAccountId);
end;
{$ENDREGION}

{ TMobileBroadbandAccountWatcher }

{ TMobileBroadbandModem }

{$REGION 'Windows.Networking.NetworkOperators.IMobileBroadbandModemStatics'}
class function TMobileBroadbandModem.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TMobileBroadbandModem.FromId(deviceId: HSTRING): IMobileBroadbandModem;
begin
  Result := Statics.FromId(deviceId);
end;

class function TMobileBroadbandModem.GetDefault: IMobileBroadbandModem;
begin
  Result := Statics.GetDefault;
end;
{$ENDREGION}

{ TNetworkOperatorTetheringAccessPointConfiguration }

{ TNetworkOperatorTetheringManager }

{$REGION 'Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics'}
class function TNetworkOperatorTetheringManager.GetTetheringCapability(networkAccountId: HSTRING): TetheringCapability;
begin
  Result := Statics.GetTetheringCapability(networkAccountId);
end;

class function TNetworkOperatorTetheringManager.CreateFromNetworkAccountId(networkAccountId: HSTRING): INetworkOperatorTetheringManager;
begin
  Result := Statics.CreateFromNetworkAccountId(networkAccountId);
end;

{$ENDREGION}

{$REGION 'Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics2'}
class function TNetworkOperatorTetheringManager.GetTetheringCapabilityFromConnectionProfile(profile: IConnectionProfile): TetheringCapability;
begin
  Result := Statics2.GetTetheringCapabilityFromConnectionProfile(profile);
end;

class function TNetworkOperatorTetheringManager.CreateFromConnectionProfile(profile: IConnectionProfile): INetworkOperatorTetheringManager;
begin
  Result := Statics2.CreateFromConnectionProfile(profile);
end;

{$ENDREGION}

{$REGION 'Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics3'}
class function TNetworkOperatorTetheringManager.CreateFromConnectionProfile(profile: IConnectionProfile; adapter: INetworkAdapter): INetworkOperatorTetheringManager;
begin
  Result := Statics3.CreateFromConnectionProfile(profile, adapter);
end;

{$ENDREGION}

{$REGION 'Windows.Networking.NetworkOperators.INetworkOperatorTetheringManagerStatics4'}
class function TNetworkOperatorTetheringManager.IsNoConnectionsTimeoutEnabled: Boolean;
begin
  Result := Statics4.IsNoConnectionsTimeoutEnabled;
end;

class procedure TNetworkOperatorTetheringManager.EnableNoConnectionsTimeout;
begin
  Statics4.EnableNoConnectionsTimeout;
end;

class function TNetworkOperatorTetheringManager.EnableNoConnectionsTimeoutAsync: IAsyncAction;
begin
  Result := Statics4.EnableNoConnectionsTimeoutAsync;
end;

class procedure TNetworkOperatorTetheringManager.DisableNoConnectionsTimeout;
begin
  Statics4.DisableNoConnectionsTimeout;
end;

class function TNetworkOperatorTetheringManager.DisableNoConnectionsTimeoutAsync: IAsyncAction;
begin
  Result := Statics4.DisableNoConnectionsTimeoutAsync;
end;
{$ENDREGION}

{ TProvisioningAgent }

{$REGION 'Windows.Networking.NetworkOperators.IProvisioningAgentStaticMethods'}
class function TProvisioningAgent.CreateFromNetworkAccountId(networkAccountId: HSTRING): IProvisioningAgent;
begin
  Result := Statics.CreateFromNetworkAccountId(networkAccountId);
end;
{$ENDREGION}

{ TUssdMessage }

{$REGION 'Windows.Networking.NetworkOperators.IUssdMessageFactory'}
// Factory: "Windows.Networking.NetworkOperators.IUssdMessageFactory"
// -> IUssdMessageFactory

class function TUssdMessage.CreateMessage(messageText: HSTRING): IUssdMessage;
begin
  Result := Factory.CreateMessage(messageText);
end;
{$ENDREGION}

{ TUssdSession }

{$REGION 'Windows.Networking.NetworkOperators.IUssdSessionStatics'}
class function TUssdSession.CreateFromNetworkAccountId(networkAccountId: HSTRING): IUssdSession;
begin
  Result := Statics.CreateFromNetworkAccountId(networkAccountId);
end;

class function TUssdSession.CreateFromNetworkInterfaceId(networkInterfaceId: HSTRING): IUssdSession;
begin
  Result := Statics.CreateFromNetworkInterfaceId(networkInterfaceId);
end;
{$ENDREGION}

end.
