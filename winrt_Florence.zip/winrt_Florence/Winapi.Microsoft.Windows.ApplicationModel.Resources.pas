{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Microsoft.Windows.ApplicationModel.Resources;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Forward declarations for interfaces

  // Microsoft.Windows.ApplicationModel.Resources.IResourceCandidate
  Microsoft_Resources_IResourceCandidate = interface;
  PMicrosoft_Resources_IResourceCandidate = ^Microsoft_Resources_IResourceCandidate;

  // Microsoft.Windows.ApplicationModel.Resources.IResourceContext2
  Microsoft_Resources_IResourceContext2 = interface;
  PMicrosoft_Resources_IResourceContext2 = ^Microsoft_Resources_IResourceContext2;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Microsoft.Windows.ApplicationModel.Resources.IResourceCandidate>
  IKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate = interface;
  PIKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate = ^IKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate;

  // Microsoft.Windows.ApplicationModel.Resources.IResourceMap
  Microsoft_Resources_IResourceMap = interface;
  PMicrosoft_Resources_IResourceMap = ^Microsoft_Resources_IResourceMap;

  // Microsoft.Windows.ApplicationModel.Resources.IResourceManager2
  Microsoft_Resources_IResourceManager2 = interface;
  PMicrosoft_Resources_IResourceManager2 = ^Microsoft_Resources_IResourceManager2;

  // Microsoft.Windows.ApplicationModel.Resources.IResourceNotFoundEventArgs
  Microsoft_Resources_IResourceNotFoundEventArgs = interface;
  PMicrosoft_Resources_IResourceNotFoundEventArgs = ^Microsoft_Resources_IResourceNotFoundEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Microsoft.Windows.ApplicationModel.Resources.IResourceManager2,Microsoft.Windows.ApplicationModel.Resources.IResourceNotFoundEventArgs>
  TypedEventHandler_2__Microsoft_Resources_IResourceManager2__Microsoft_Resources_IResourceNotFoundEventArgs = interface;
  PTypedEventHandler_2__Microsoft_Resources_IResourceManager2__Microsoft_Resources_IResourceNotFoundEventArgs = ^TypedEventHandler_2__Microsoft_Resources_IResourceManager2__Microsoft_Resources_IResourceNotFoundEventArgs;

  // Microsoft.Windows.ApplicationModel.Resources.IResourceManager
  Microsoft_Resources_IResourceManager = interface;
  PMicrosoft_Resources_IResourceManager = ^Microsoft_Resources_IResourceManager;

  // Microsoft.Windows.ApplicationModel.Resources Enums

  // Microsoft.Windows.ApplicationModel.Resources.ResourceCandidateKind
  Microsoft_Resources_ResourceCandidateKind = (
    Unknown = 0,
    &String = 1,
    FilePath = 2,
    EmbeddedData = 3
  );
  PMicrosoft_Resources_ResourceCandidateKind = ^Microsoft_Resources_ResourceCandidateKind;

  // Microsoft.Windows.ApplicationModel.Resources Records

  // Microsoft.Windows.ApplicationModel.Resources.MrtCoreContract
  Microsoft_Resources_MrtCoreContract = record
  end;
  PMicrosoft_Resources_MrtCoreContract = ^Microsoft_Resources_MrtCoreContract;

  // Microsoft.Windows.ApplicationModel.Resources Interfaces

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceCandidate
  Microsoft_Resources_IResourceCandidate = interface(IInspectable)
  ['{6C54BC0C-EF1E-57B8-B478-34FECE737356}']
    function get_ValueAsString: HSTRING; safecall;
    function get_ValueAsBytes(resultSize: Cardinal; resultValue: PByte): HRESULT; stdcall;
    function get_Kind: Microsoft_Resources_ResourceCandidateKind; safecall;
    function get_QualifierValues: IMapView_2__HSTRING__HSTRING; safecall;
    property Kind: Microsoft_Resources_ResourceCandidateKind read get_Kind;
    property QualifierValues: IMapView_2__HSTRING__HSTRING read get_QualifierValues;
    // property ValueAsBytes: PByte read get_ValueAsBytes;
    property ValueAsString: HSTRING read get_ValueAsString;
  end;

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceContext2
  Microsoft_Resources_IResourceContext2 = interface(IInspectable)
  ['{7A3B1158-798C-5949-969D-03510B9CE6CA}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,Microsoft.Windows.ApplicationModel.Resources.IResourceCandidate>
  IKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate = interface(IInspectable)
  ['{0F62CD23-118F-5D47-9DCC-E99EA51FFECC}']
    function get_Key: HSTRING; safecall;
    function get_Value: Microsoft_Resources_IResourceCandidate; safecall;
    property Key: HSTRING read get_Key;
    property Value: Microsoft_Resources_IResourceCandidate read get_Value;
  end;

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceMap
  Microsoft_Resources_IResourceMap = interface(IInspectable)
  ['{4ABBD9BC-DF4E-5C7B-812C-7E7BB0C22377}']
    function get_ResourceCount: Cardinal; safecall;
    function GetSubtree(reference: HSTRING): Microsoft_Resources_IResourceMap; safecall;
    function TryGetSubtree(reference: HSTRING): Microsoft_Resources_IResourceMap; safecall;
    function GetValue(resource: HSTRING): Microsoft_Resources_IResourceCandidate; overload; safecall;
    function GetValue(resource: HSTRING; context: Microsoft_Resources_IResourceContext2): Microsoft_Resources_IResourceCandidate; overload; safecall;
    function GetValueByIndex(index: Cardinal): IKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate; overload; safecall;
    function GetValueByIndex(index: Cardinal; context: Microsoft_Resources_IResourceContext2): IKeyValuePair_2__HSTRING__Microsoft_Resources_IResourceCandidate; overload; safecall;
    function TryGetValue(resource: HSTRING): Microsoft_Resources_IResourceCandidate; overload; safecall;
    function TryGetValue(resource: HSTRING; context: Microsoft_Resources_IResourceContext2): Microsoft_Resources_IResourceCandidate; overload; safecall;
    property ResourceCount: Cardinal read get_ResourceCount;
  end;

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceManager2
  Microsoft_Resources_IResourceManager2 = interface(IInspectable)
  ['{7EC10160-A154-5C42-8268-30E306B1F585}']
  end;

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceNotFoundEventArgs
  Microsoft_Resources_IResourceNotFoundEventArgs = interface(IInspectable)
  ['{64ABB08B-E77D-5B26-830F-15941E0E8200}']
    function get_Context: Microsoft_Resources_IResourceContext2; safecall;
    function get_Name: HSTRING; safecall;
    procedure SetResolvedCandidate(candidate: Microsoft_Resources_IResourceCandidate); safecall;
    property Context: Microsoft_Resources_IResourceContext2 read get_Context;
    property Name: HSTRING read get_Name;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Windows.ApplicationModel.Resources.ResourceManager,Microsoft.Windows.ApplicationModel.Resources.ResourceNotFoundEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Microsoft.Windows.ApplicationModel.Resources.IResourceManager2,Microsoft.Windows.ApplicationModel.Resources.IResourceNotFoundEventArgs>
  TypedEventHandler_2__Microsoft_Resources_IResourceManager2__Microsoft_Resources_IResourceNotFoundEventArgs = interface(IUnknown)
  ['{968F9E92-4FC4-5737-ADA6-3EF7CFFA672F}']
    procedure Invoke(sender: Microsoft_Resources_IResourceManager2; args: Microsoft_Resources_IResourceNotFoundEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Microsoft.Windows.ApplicationModel.Resources.IResourceManager
  Microsoft_Resources_IResourceManager = interface(IInspectable)
  ['{AC2291EF-81BE-5C99-A0AE-BCEE0180B8A8}']
    function get_MainResourceMap: Microsoft_Resources_IResourceMap; safecall;
    function CreateResourceContext: Microsoft_Resources_IResourceContext2; safecall;
    function add_ResourceNotFound(handler: TypedEventHandler_2__Microsoft_Resources_IResourceManager2__Microsoft_Resources_IResourceNotFoundEventArgs): EventRegistrationToken; safecall;
    procedure remove_ResourceNotFound(token: EventRegistrationToken); safecall;
    property MainResourceMap: Microsoft_Resources_IResourceMap read get_MainResourceMap;
  end;

implementation

end.
