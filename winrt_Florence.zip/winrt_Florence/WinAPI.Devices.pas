{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Devices;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Foundation,
  Winapi.GraphicsRT,
  Winapi.Media,
  Winapi.Media.Devices,
  Winapi.Devices.Enumeration,
  Winapi.Storage.Streams,
  Winapi.Security.Credentials,
  Winapi.Networking.Sockets,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  Haptics_ISimpleHapticsController = Winapi.CommonTypes.Haptics_ISimpleHapticsController;
  PHaptics_ISimpleHapticsController = Winapi.CommonTypes.PHaptics_ISimpleHapticsController;
  Haptics_ISimpleHapticsControllerFeedback = Winapi.CommonTypes.Haptics_ISimpleHapticsControllerFeedback;
  PHaptics_ISimpleHapticsControllerFeedback = Winapi.CommonTypes.PHaptics_ISimpleHapticsControllerFeedback;
  Input_IPointerDevice = Winapi.CommonTypes.Input_IPointerDevice;
  PInput_IPointerDevice = Winapi.CommonTypes.PInput_IPointerDevice;
  Input_PointerDeviceType = Winapi.CommonTypes.Input_PointerDeviceType;
  PInput_PointerDeviceType = Winapi.CommonTypes.PInput_PointerDeviceType;
  Input_PointerDeviceUsage = Winapi.CommonTypes.Input_PointerDeviceUsage;
  PInput_PointerDeviceUsage = Winapi.CommonTypes.PInput_PointerDeviceUsage;
  IVectorView_1__Haptics_ISimpleHapticsController = Winapi.CommonTypes.IVectorView_1__Haptics_ISimpleHapticsController;
  PIVectorView_1__Haptics_ISimpleHapticsController = Winapi.CommonTypes.PIVectorView_1__Haptics_ISimpleHapticsController;
  IVectorView_1__Haptics_ISimpleHapticsControllerFeedback = Winapi.CommonTypes.IVectorView_1__Haptics_ISimpleHapticsControllerFeedback;
  PIVectorView_1__Haptics_ISimpleHapticsControllerFeedback = Winapi.CommonTypes.PIVectorView_1__Haptics_ISimpleHapticsControllerFeedback;
  IVectorView_1__Input_PointerDeviceUsage = Winapi.CommonTypes.IVectorView_1__Input_PointerDeviceUsage;
  PIVectorView_1__Input_PointerDeviceUsage = Winapi.CommonTypes.PIVectorView_1__Input_PointerDeviceUsage;
  Power_IBatteryReport = Winapi.CommonTypes.Power_IBatteryReport;
  PPower_IBatteryReport = Winapi.CommonTypes.PPower_IBatteryReport;

  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Input.PointerDeviceUsage>
  IIterator_1__Input_PointerDeviceUsage = interface;
  PIIterator_1__Input_PointerDeviceUsage = ^IIterator_1__Input_PointerDeviceUsage;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Input.PointerDeviceUsage>
  IIterable_1__Input_PointerDeviceUsage = interface;
  PIIterable_1__Input_PointerDeviceUsage = ^IIterable_1__Input_PointerDeviceUsage;

  // Windows.Devices.Input.IPenDevice
  Input_IPenDevice = interface;
  PInput_IPenDevice = ^Input_IPenDevice;

  // Windows.Devices.Adc.IAdcController
  Adc_IAdcController = interface;
  PAdc_IAdcController = ^Adc_IAdcController;

  // Windows.Devices.Adc.IAdcChannel
  Adc_IAdcChannel = interface;
  PAdc_IAdcChannel = ^Adc_IAdcChannel;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Adc.IAdcController>
  IIterator_1__Adc_IAdcController = interface;
  PIIterator_1__Adc_IAdcController = ^IIterator_1__Adc_IAdcController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Adc.IAdcController>
  IIterable_1__Adc_IAdcController = interface;
  PIIterable_1__Adc_IAdcController = ^IIterable_1__Adc_IAdcController;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>
  IVectorView_1__Adc_IAdcController = interface;
  PIVectorView_1__Adc_IAdcController = ^IVectorView_1__Adc_IAdcController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController = ^AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>>
  IAsyncOperation_1__IVectorView_1__Adc_IAdcController = interface;
  PIAsyncOperation_1__IVectorView_1__Adc_IAdcController = ^IAsyncOperation_1__IVectorView_1__Adc_IAdcController;

  // Windows.Devices.Adc.Provider.IAdcControllerProvider
  Adc_Provider_IAdcControllerProvider = interface;
  PAdc_Provider_IAdcControllerProvider = ^Adc_Provider_IAdcControllerProvider;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IIterator_1__Adc_Provider_IAdcControllerProvider = interface;
  PIIterator_1__Adc_Provider_IAdcControllerProvider = ^IIterator_1__Adc_Provider_IAdcControllerProvider;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IIterable_1__Adc_Provider_IAdcControllerProvider = interface;
  PIIterable_1__Adc_Provider_IAdcControllerProvider = ^IIterable_1__Adc_Provider_IAdcControllerProvider;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IVectorView_1__Adc_Provider_IAdcControllerProvider = interface;
  PIVectorView_1__Adc_Provider_IAdcControllerProvider = ^IVectorView_1__Adc_Provider_IAdcControllerProvider;

  // Windows.Devices.Adc.Provider.IAdcProvider
  Adc_Provider_IAdcProvider = interface;
  PAdc_Provider_IAdcProvider = ^Adc_Provider_IAdcProvider;

  // Windows.Devices.Adc.IAdcControllerStatics
  Adc_IAdcControllerStatics = interface;
  PAdc_IAdcControllerStatics = ^Adc_IAdcControllerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Adc.IAdcController>
  AsyncOperationCompletedHandler_1__Adc_IAdcController = interface;
  PAsyncOperationCompletedHandler_1__Adc_IAdcController = ^AsyncOperationCompletedHandler_1__Adc_IAdcController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Adc.IAdcController>
  IAsyncOperation_1__Adc_IAdcController = interface;
  PIAsyncOperation_1__Adc_IAdcController = ^IAsyncOperation_1__Adc_IAdcController;

  // Windows.Devices.Adc.IAdcControllerStatics2
  Adc_IAdcControllerStatics2 = interface;
  PAdc_IAdcControllerStatics2 = ^Adc_IAdcControllerStatics2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Radios.RadioAccessStatus>
  AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__Radios_RadioAccessStatus = ^AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Radios.RadioAccessStatus>
  IAsyncOperation_1__Radios_RadioAccessStatus = interface;
  PIAsyncOperation_1__Radios_RadioAccessStatus = ^IAsyncOperation_1__Radios_RadioAccessStatus;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Radios.IRadio,Object>
  TypedEventHandler_2__Radios_IRadio__IInspectable = interface;
  PTypedEventHandler_2__Radios_IRadio__IInspectable = ^TypedEventHandler_2__Radios_IRadio__IInspectable;

  // Windows.Devices.Radios.IRadio
  Radios_IRadio = interface;
  PRadios_IRadio = ^Radios_IRadio;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Radios.IRadio>
  AsyncOperationCompletedHandler_1__Radios_IRadio = interface;
  PAsyncOperationCompletedHandler_1__Radios_IRadio = ^AsyncOperationCompletedHandler_1__Radios_IRadio;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Radios.IRadio>
  IAsyncOperation_1__Radios_IRadio = interface;
  PIAsyncOperation_1__Radios_IRadio = ^IAsyncOperation_1__Radios_IRadio;

  // Windows.Devices.Custom.IIOControlCode
  Custom_IIOControlCode = interface;
  PCustom_IIOControlCode = ^Custom_IIOControlCode;

  // Windows.Devices.Custom.ICustomDevice
  Custom_ICustomDevice = interface;
  PCustom_ICustomDevice = ^Custom_ICustomDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Custom.ICustomDevice>
  AsyncOperationCompletedHandler_1__Custom_ICustomDevice = interface;
  PAsyncOperationCompletedHandler_1__Custom_ICustomDevice = ^AsyncOperationCompletedHandler_1__Custom_ICustomDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Custom.ICustomDevice>
  IAsyncOperation_1__Custom_ICustomDevice = interface;
  PIAsyncOperation_1__Custom_ICustomDevice = ^IAsyncOperation_1__Custom_ICustomDevice;

  // Windows.Devices.Custom.ICustomDeviceStatics
  Custom_ICustomDeviceStatics = interface;
  PCustom_ICustomDeviceStatics = ^Custom_ICustomDeviceStatics;

  // Windows.Devices.Custom.IIOControlCodeFactory
  Custom_IIOControlCodeFactory = interface;
  PCustom_IIOControlCodeFactory = ^Custom_IIOControlCodeFactory;

  // Windows.Devices.Custom.IKnownDeviceTypesStatics
  Custom_IKnownDeviceTypesStatics = interface;
  PCustom_IKnownDeviceTypesStatics = ^Custom_IKnownDeviceTypesStatics;

  // Windows.Devices.Display.IDisplayMonitor
  Display_IDisplayMonitor = interface;
  PDisplay_IDisplayMonitor = ^Display_IDisplayMonitor;

  // Windows.Foundation.IReference`1<Windows.Devices.Display.Core.DisplayPresentationRate>
  IReference_1__Display_Core_DisplayPresentationRate = interface;
  PIReference_1__Display_Core_DisplayPresentationRate = ^IReference_1__Display_Core_DisplayPresentationRate;

  // Windows.Devices.Display.IDisplayMonitor2
  Display_IDisplayMonitor2 = interface;
  PDisplay_IDisplayMonitor2 = ^Display_IDisplayMonitor2;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Display.IDisplayMonitor>
  AsyncOperationCompletedHandler_1__Display_IDisplayMonitor = interface;
  PAsyncOperationCompletedHandler_1__Display_IDisplayMonitor = ^AsyncOperationCompletedHandler_1__Display_IDisplayMonitor;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Display.IDisplayMonitor>
  IAsyncOperation_1__Display_IDisplayMonitor = interface;
  PIAsyncOperation_1__Display_IDisplayMonitor = ^IAsyncOperation_1__Display_IDisplayMonitor;

  // Windows.Devices.Display.IDisplayMonitorStatics
  Display_IDisplayMonitorStatics = interface;
  PDisplay_IDisplayMonitorStatics = ^Display_IDisplayMonitorStatics;

  // Windows.Devices.Gpio.IGpioChangeCounter
  Gpio_IGpioChangeCounter = interface;
  PGpio_IGpioChangeCounter = ^Gpio_IGpioChangeCounter;

  // Windows.Devices.Gpio.IGpioPinValueChangedEventArgs
  Gpio_IGpioPinValueChangedEventArgs = interface;
  PGpio_IGpioPinValueChangedEventArgs = ^Gpio_IGpioPinValueChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.IGpioPin,Windows.Devices.Gpio.IGpioPinValueChangedEventArgs>
  TypedEventHandler_2__Gpio_IGpioPin__Gpio_IGpioPinValueChangedEventArgs = interface;
  PTypedEventHandler_2__Gpio_IGpioPin__Gpio_IGpioPinValueChangedEventArgs = ^TypedEventHandler_2__Gpio_IGpioPin__Gpio_IGpioPinValueChangedEventArgs;

  // Windows.Devices.Gpio.IGpioPin
  Gpio_IGpioPin = interface;
  PGpio_IGpioPin = ^Gpio_IGpioPin;

  // Windows.Devices.Gpio.IGpioChangeCounterFactory
  Gpio_IGpioChangeCounterFactory = interface;
  PGpio_IGpioChangeCounterFactory = ^Gpio_IGpioChangeCounterFactory;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.GpioChangeRecord>
  IIterator_1__Gpio_GpioChangeRecord = interface;
  PIIterator_1__Gpio_GpioChangeRecord = ^IIterator_1__Gpio_GpioChangeRecord;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.GpioChangeRecord>
  IIterable_1__Gpio_GpioChangeRecord = interface;
  PIIterable_1__Gpio_GpioChangeRecord = ^IIterable_1__Gpio_GpioChangeRecord;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.GpioChangeRecord>
  IVectorView_1__Gpio_GpioChangeRecord = interface;
  PIVectorView_1__Gpio_GpioChangeRecord = ^IVectorView_1__Gpio_GpioChangeRecord;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Gpio.GpioChangeRecord>
  IVector_1__Gpio_GpioChangeRecord = interface;
  PIVector_1__Gpio_GpioChangeRecord = ^IVector_1__Gpio_GpioChangeRecord;

  // Windows.Devices.Gpio.IGpioChangeReader
  Gpio_IGpioChangeReader = interface;
  PGpio_IGpioChangeReader = ^Gpio_IGpioChangeReader;

  // Windows.Devices.Gpio.IGpioChangeReaderFactory
  Gpio_IGpioChangeReaderFactory = interface;
  PGpio_IGpioChangeReaderFactory = ^Gpio_IGpioChangeReaderFactory;

  // Windows.Devices.Gpio.IGpioController
  Gpio_IGpioController = interface;
  PGpio_IGpioController = ^Gpio_IGpioController;

  // Windows.Devices.Gpio.IGpioControllerStatics
  Gpio_IGpioControllerStatics = interface;
  PGpio_IGpioControllerStatics = ^Gpio_IGpioControllerStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.IGpioController>
  IIterator_1__Gpio_IGpioController = interface;
  PIIterator_1__Gpio_IGpioController = ^IIterator_1__Gpio_IGpioController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.IGpioController>
  IIterable_1__Gpio_IGpioController = interface;
  PIIterable_1__Gpio_IGpioController = ^IIterable_1__Gpio_IGpioController;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>
  IVectorView_1__Gpio_IGpioController = interface;
  PIVectorView_1__Gpio_IGpioController = ^IVectorView_1__Gpio_IGpioController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController = ^AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>>
  IAsyncOperation_1__IVectorView_1__Gpio_IGpioController = interface;
  PIAsyncOperation_1__IVectorView_1__Gpio_IGpioController = ^IAsyncOperation_1__IVectorView_1__Gpio_IGpioController;

  // Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgs
  Gpio_Provider_IGpioPinProviderValueChangedEventArgs = interface;
  PGpio_Provider_IGpioPinProviderValueChangedEventArgs = ^Gpio_Provider_IGpioPinProviderValueChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.Provider.IGpioPinProvider,Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgs>
  TypedEventHandler_2__Gpio_Provider_IGpioPinProvider__Gpio_Provider_IGpioPinProviderValueChangedEventArgs = interface;
  PTypedEventHandler_2__Gpio_Provider_IGpioPinProvider__Gpio_Provider_IGpioPinProviderValueChangedEventArgs = ^TypedEventHandler_2__Gpio_Provider_IGpioPinProvider__Gpio_Provider_IGpioPinProviderValueChangedEventArgs;

  // Windows.Devices.Gpio.Provider.IGpioPinProvider
  Gpio_Provider_IGpioPinProvider = interface;
  PGpio_Provider_IGpioPinProvider = ^Gpio_Provider_IGpioPinProvider;

  // Windows.Devices.Gpio.Provider.IGpioControllerProvider
  Gpio_Provider_IGpioControllerProvider = interface;
  PGpio_Provider_IGpioControllerProvider = ^Gpio_Provider_IGpioControllerProvider;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IIterator_1__Gpio_Provider_IGpioControllerProvider = interface;
  PIIterator_1__Gpio_Provider_IGpioControllerProvider = ^IIterator_1__Gpio_Provider_IGpioControllerProvider;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IIterable_1__Gpio_Provider_IGpioControllerProvider = interface;
  PIIterable_1__Gpio_Provider_IGpioControllerProvider = ^IIterable_1__Gpio_Provider_IGpioControllerProvider;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IVectorView_1__Gpio_Provider_IGpioControllerProvider = interface;
  PIVectorView_1__Gpio_Provider_IGpioControllerProvider = ^IVectorView_1__Gpio_Provider_IGpioControllerProvider;

  // Windows.Devices.Gpio.Provider.IGpioProvider
  Gpio_Provider_IGpioProvider = interface;
  PGpio_Provider_IGpioProvider = ^Gpio_Provider_IGpioProvider;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Gpio.IGpioController>
  AsyncOperationCompletedHandler_1__Gpio_IGpioController = interface;
  PAsyncOperationCompletedHandler_1__Gpio_IGpioController = ^AsyncOperationCompletedHandler_1__Gpio_IGpioController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Gpio.IGpioController>
  IAsyncOperation_1__Gpio_IGpioController = interface;
  PIAsyncOperation_1__Gpio_IGpioController = ^IAsyncOperation_1__Gpio_IGpioController;

  // Windows.Devices.Gpio.IGpioControllerStatics2
  Gpio_IGpioControllerStatics2 = interface;
  PGpio_IGpioControllerStatics2 = ^Gpio_IGpioControllerStatics2;

  // Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgsFactory
  Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory = interface;
  PGpio_Provider_IGpioPinProviderValueChangedEventArgsFactory = ^Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory;

  // Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics
  Haptics_IKnownSimpleHapticsControllerWaveformsStatics = interface;
  PHaptics_IKnownSimpleHapticsControllerWaveformsStatics = ^Haptics_IKnownSimpleHapticsControllerWaveformsStatics;

  // Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics2
  Haptics_IKnownSimpleHapticsControllerWaveformsStatics2 = interface;
  PHaptics_IKnownSimpleHapticsControllerWaveformsStatics2 = ^Haptics_IKnownSimpleHapticsControllerWaveformsStatics2;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  IIterator_1__Haptics_ISimpleHapticsControllerFeedback = interface;
  PIIterator_1__Haptics_ISimpleHapticsControllerFeedback = ^IIterator_1__Haptics_ISimpleHapticsControllerFeedback;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  IIterable_1__Haptics_ISimpleHapticsControllerFeedback = interface;
  PIIterable_1__Haptics_ISimpleHapticsControllerFeedback = ^IIterable_1__Haptics_ISimpleHapticsControllerFeedback;

  // Windows.Devices.Haptics.IVibrationDevice
  Haptics_IVibrationDevice = interface;
  PHaptics_IVibrationDevice = ^Haptics_IVibrationDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Haptics.VibrationAccessStatus>
  AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus = ^AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Haptics.VibrationAccessStatus>
  IAsyncOperation_1__Haptics_VibrationAccessStatus = interface;
  PIAsyncOperation_1__Haptics_VibrationAccessStatus = ^IAsyncOperation_1__Haptics_VibrationAccessStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Haptics.IVibrationDevice>
  AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice = interface;
  PAsyncOperationCompletedHandler_1__Haptics_IVibrationDevice = ^AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Haptics.IVibrationDevice>
  IAsyncOperation_1__Haptics_IVibrationDevice = interface;
  PIAsyncOperation_1__Haptics_IVibrationDevice = ^IAsyncOperation_1__Haptics_IVibrationDevice;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.IVibrationDevice>
  IIterator_1__Haptics_IVibrationDevice = interface;
  PIIterator_1__Haptics_IVibrationDevice = ^IIterator_1__Haptics_IVibrationDevice;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.IVibrationDevice>
  IIterable_1__Haptics_IVibrationDevice = interface;
  PIIterable_1__Haptics_IVibrationDevice = ^IIterable_1__Haptics_IVibrationDevice;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>
  IVectorView_1__Haptics_IVibrationDevice = interface;
  PIVectorView_1__Haptics_IVibrationDevice = ^IVectorView_1__Haptics_IVibrationDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice = ^AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>>
  IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice = interface;
  PIAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice = ^IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice;

  // Windows.Devices.Haptics.IVibrationDeviceStatics
  Haptics_IVibrationDeviceStatics = interface;
  PHaptics_IVibrationDeviceStatics = ^Haptics_IVibrationDeviceStatics;

  // Windows.Devices.HumanInterfaceDevice.IHidCollection
  HumanInterfaceDevice_IHidCollection = interface;
  PHumanInterfaceDevice_IHidCollection = ^HumanInterfaceDevice_IHidCollection;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IIterator_1__HumanInterfaceDevice_IHidCollection = interface;
  PIIterator_1__HumanInterfaceDevice_IHidCollection = ^IIterator_1__HumanInterfaceDevice_IHidCollection;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IIterable_1__HumanInterfaceDevice_IHidCollection = interface;
  PIIterable_1__HumanInterfaceDevice_IHidCollection = ^IIterable_1__HumanInterfaceDevice_IHidCollection;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IVectorView_1__HumanInterfaceDevice_IHidCollection = interface;
  PIVectorView_1__HumanInterfaceDevice_IHidCollection = ^IVectorView_1__HumanInterfaceDevice_IHidCollection;

  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription
  HumanInterfaceDevice_IHidBooleanControlDescription = interface;
  PHumanInterfaceDevice_IHidBooleanControlDescription = ^HumanInterfaceDevice_IHidBooleanControlDescription;

  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControl
  HumanInterfaceDevice_IHidBooleanControl = interface;
  PHumanInterfaceDevice_IHidBooleanControl = ^HumanInterfaceDevice_IHidBooleanControl;

  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription2
  HumanInterfaceDevice_IHidBooleanControlDescription2 = interface;
  PHumanInterfaceDevice_IHidBooleanControlDescription2 = ^HumanInterfaceDevice_IHidBooleanControlDescription2;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IIterator_1__HumanInterfaceDevice_IHidBooleanControl = interface;
  PIIterator_1__HumanInterfaceDevice_IHidBooleanControl = ^IIterator_1__HumanInterfaceDevice_IHidBooleanControl;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IIterable_1__HumanInterfaceDevice_IHidBooleanControl = interface;
  PIIterable_1__HumanInterfaceDevice_IHidBooleanControl = ^IIterable_1__HumanInterfaceDevice_IHidBooleanControl;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IVectorView_1__HumanInterfaceDevice_IHidBooleanControl = interface;
  PIVectorView_1__HumanInterfaceDevice_IHidBooleanControl = ^IVectorView_1__HumanInterfaceDevice_IHidBooleanControl;

  // Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription
  HumanInterfaceDevice_IHidNumericControlDescription = interface;
  PHumanInterfaceDevice_IHidNumericControlDescription = ^HumanInterfaceDevice_IHidNumericControlDescription;

  // Windows.Devices.HumanInterfaceDevice.IHidNumericControl
  HumanInterfaceDevice_IHidNumericControl = interface;
  PHumanInterfaceDevice_IHidNumericControl = ^HumanInterfaceDevice_IHidNumericControl;

  // Windows.Devices.HumanInterfaceDevice.IHidInputReport
  HumanInterfaceDevice_IHidInputReport = interface;
  PHumanInterfaceDevice_IHidInputReport = ^HumanInterfaceDevice_IHidInputReport;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidInputReport>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport = interface;
  PAsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport = ^AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidInputReport>
  IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport = interface;
  PIAsyncOperation_1__HumanInterfaceDevice_IHidInputReport = ^IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport;

  // Windows.Devices.HumanInterfaceDevice.IHidFeatureReport
  HumanInterfaceDevice_IHidFeatureReport = interface;
  PHumanInterfaceDevice_IHidFeatureReport = ^HumanInterfaceDevice_IHidFeatureReport;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidFeatureReport>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport = interface;
  PAsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport = ^AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidFeatureReport>
  IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport = interface;
  PIAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport = ^IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport;

  // Windows.Devices.HumanInterfaceDevice.IHidOutputReport
  HumanInterfaceDevice_IHidOutputReport = interface;
  PHumanInterfaceDevice_IHidOutputReport = ^HumanInterfaceDevice_IHidOutputReport;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IIterator_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface;
  PIIterator_1__HumanInterfaceDevice_IHidBooleanControlDescription = ^IIterator_1__HumanInterfaceDevice_IHidBooleanControlDescription;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IIterable_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface;
  PIIterable_1__HumanInterfaceDevice_IHidBooleanControlDescription = ^IIterable_1__HumanInterfaceDevice_IHidBooleanControlDescription;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IVectorView_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface;
  PIVectorView_1__HumanInterfaceDevice_IHidBooleanControlDescription = ^IVectorView_1__HumanInterfaceDevice_IHidBooleanControlDescription;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IIterator_1__HumanInterfaceDevice_IHidNumericControlDescription = interface;
  PIIterator_1__HumanInterfaceDevice_IHidNumericControlDescription = ^IIterator_1__HumanInterfaceDevice_IHidNumericControlDescription;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IIterable_1__HumanInterfaceDevice_IHidNumericControlDescription = interface;
  PIIterable_1__HumanInterfaceDevice_IHidNumericControlDescription = ^IIterable_1__HumanInterfaceDevice_IHidNumericControlDescription;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IVectorView_1__HumanInterfaceDevice_IHidNumericControlDescription = interface;
  PIVectorView_1__HumanInterfaceDevice_IHidNumericControlDescription = ^IVectorView_1__HumanInterfaceDevice_IHidNumericControlDescription;

  // Windows.Devices.HumanInterfaceDevice.IHidInputReportReceivedEventArgs
  HumanInterfaceDevice_IHidInputReportReceivedEventArgs = interface;
  PHumanInterfaceDevice_IHidInputReportReceivedEventArgs = ^HumanInterfaceDevice_IHidInputReportReceivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.HumanInterfaceDevice.IHidDevice,Windows.Devices.HumanInterfaceDevice.IHidInputReportReceivedEventArgs>
  TypedEventHandler_2__HumanInterfaceDevice_IHidDevice__HumanInterfaceDevice_IHidInputReportReceivedEventArgs = interface;
  PTypedEventHandler_2__HumanInterfaceDevice_IHidDevice__HumanInterfaceDevice_IHidInputReportReceivedEventArgs = ^TypedEventHandler_2__HumanInterfaceDevice_IHidDevice__HumanInterfaceDevice_IHidInputReportReceivedEventArgs;

  // Windows.Devices.HumanInterfaceDevice.IHidDevice
  HumanInterfaceDevice_IHidDevice = interface;
  PHumanInterfaceDevice_IHidDevice = ^HumanInterfaceDevice_IHidDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidDevice>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice = interface;
  PAsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice = ^AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidDevice>
  IAsyncOperation_1__HumanInterfaceDevice_IHidDevice = interface;
  PIAsyncOperation_1__HumanInterfaceDevice_IHidDevice = ^IAsyncOperation_1__HumanInterfaceDevice_IHidDevice;

  // Windows.Devices.HumanInterfaceDevice.IHidDeviceStatics
  HumanInterfaceDevice_IHidDeviceStatics = interface;
  PHumanInterfaceDevice_IHidDeviceStatics = ^HumanInterfaceDevice_IHidDeviceStatics;

  // Windows.Devices.I2c.II2cConnectionSettings
  I2c_II2cConnectionSettings = interface;
  PI2c_II2cConnectionSettings = ^I2c_II2cConnectionSettings;

  // Windows.Devices.I2c.II2cConnectionSettingsFactory
  I2c_II2cConnectionSettingsFactory = interface;
  PI2c_II2cConnectionSettingsFactory = ^I2c_II2cConnectionSettingsFactory;

  // Windows.Devices.I2c.II2cDevice
  I2c_II2cDevice = interface;
  PI2c_II2cDevice = ^I2c_II2cDevice;

  // Windows.Devices.I2c.II2cController
  I2c_II2cController = interface;
  PI2c_II2cController = ^I2c_II2cController;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.I2c.II2cController>
  IIterator_1__I2c_II2cController = interface;
  PIIterator_1__I2c_II2cController = ^IIterator_1__I2c_II2cController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.I2c.II2cController>
  IIterable_1__I2c_II2cController = interface;
  PIIterable_1__I2c_II2cController = ^IIterable_1__I2c_II2cController;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>
  IVectorView_1__I2c_II2cController = interface;
  PIVectorView_1__I2c_II2cController = ^IVectorView_1__I2c_II2cController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController = ^AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>>
  IAsyncOperation_1__IVectorView_1__I2c_II2cController = interface;
  PIAsyncOperation_1__IVectorView_1__I2c_II2cController = ^IAsyncOperation_1__IVectorView_1__I2c_II2cController;

  // Windows.Devices.I2c.Provider.II2cDeviceProvider
  I2c_Provider_II2cDeviceProvider = interface;
  PI2c_Provider_II2cDeviceProvider = ^I2c_Provider_II2cDeviceProvider;

  // Windows.Devices.I2c.Provider.IProviderI2cConnectionSettings
  I2c_Provider_IProviderI2cConnectionSettings = interface;
  PI2c_Provider_IProviderI2cConnectionSettings = ^I2c_Provider_IProviderI2cConnectionSettings;

  // Windows.Devices.I2c.Provider.II2cControllerProvider
  I2c_Provider_II2cControllerProvider = interface;
  PI2c_Provider_II2cControllerProvider = ^I2c_Provider_II2cControllerProvider;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IIterator_1__I2c_Provider_II2cControllerProvider = interface;
  PIIterator_1__I2c_Provider_II2cControllerProvider = ^IIterator_1__I2c_Provider_II2cControllerProvider;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IIterable_1__I2c_Provider_II2cControllerProvider = interface;
  PIIterable_1__I2c_Provider_II2cControllerProvider = ^IIterable_1__I2c_Provider_II2cControllerProvider;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IVectorView_1__I2c_Provider_II2cControllerProvider = interface;
  PIVectorView_1__I2c_Provider_II2cControllerProvider = ^IVectorView_1__I2c_Provider_II2cControllerProvider;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>>
  AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider = ^AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>>
  IAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider = interface;
  PIAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider = ^IAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider;

  // Windows.Devices.I2c.Provider.II2cProvider
  I2c_Provider_II2cProvider = interface;
  PI2c_Provider_II2cProvider = ^I2c_Provider_II2cProvider;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.II2cController>
  AsyncOperationCompletedHandler_1__I2c_II2cController = interface;
  PAsyncOperationCompletedHandler_1__I2c_II2cController = ^AsyncOperationCompletedHandler_1__I2c_II2cController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.II2cController>
  IAsyncOperation_1__I2c_II2cController = interface;
  PIAsyncOperation_1__I2c_II2cController = ^IAsyncOperation_1__I2c_II2cController;

  // Windows.Devices.I2c.II2cControllerStatics
  I2c_II2cControllerStatics = interface;
  PI2c_II2cControllerStatics = ^I2c_II2cControllerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.II2cDevice>
  AsyncOperationCompletedHandler_1__I2c_II2cDevice = interface;
  PAsyncOperationCompletedHandler_1__I2c_II2cDevice = ^AsyncOperationCompletedHandler_1__I2c_II2cDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.II2cDevice>
  IAsyncOperation_1__I2c_II2cDevice = interface;
  PIAsyncOperation_1__I2c_II2cDevice = ^IAsyncOperation_1__I2c_II2cDevice;

  // Windows.Devices.I2c.II2cDeviceStatics
  I2c_II2cDeviceStatics = interface;
  PI2c_II2cDeviceStatics = ^I2c_II2cDeviceStatics;

  // Windows.Devices.Pwm.Provider.IPwmControllerProvider
  Pwm_Provider_IPwmControllerProvider = interface;
  PPwm_Provider_IPwmControllerProvider = ^Pwm_Provider_IPwmControllerProvider;

  // Windows.Devices.Spi.Provider.IProviderSpiConnectionSettings
  Spi_Provider_IProviderSpiConnectionSettings = interface;
  PSpi_Provider_IProviderSpiConnectionSettings = ^Spi_Provider_IProviderSpiConnectionSettings;

  // Windows.Devices.Spi.Provider.ISpiDeviceProvider
  Spi_Provider_ISpiDeviceProvider = interface;
  PSpi_Provider_ISpiDeviceProvider = ^Spi_Provider_ISpiDeviceProvider;

  // Windows.Devices.Spi.Provider.ISpiControllerProvider
  Spi_Provider_ISpiControllerProvider = interface;
  PSpi_Provider_ISpiControllerProvider = ^Spi_Provider_ISpiControllerProvider;

  // Windows.Devices.ILowLevelDevicesAggregateProvider
  ILowLevelDevicesAggregateProvider = interface;
  PILowLevelDevicesAggregateProvider = ^ILowLevelDevicesAggregateProvider;

  // Windows.Devices.ILowLevelDevicesAggregateProviderFactory
  ILowLevelDevicesAggregateProviderFactory = interface;
  PILowLevelDevicesAggregateProviderFactory = ^ILowLevelDevicesAggregateProviderFactory;

  // Windows.Devices.ILowLevelDevicesController
  ILowLevelDevicesController = interface;
  PILowLevelDevicesController = ^ILowLevelDevicesController;

  // Windows.Devices.ILowLevelDevicesControllerStatics
  ILowLevelDevicesControllerStatics = interface;
  PILowLevelDevicesControllerStatics = ^ILowLevelDevicesControllerStatics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Object>
  TypedEventHandler_2__Input_IPenButtonListener__IInspectable = interface;
  PTypedEventHandler_2__Input_IPenButtonListener__IInspectable = ^TypedEventHandler_2__Input_IPenButtonListener__IInspectable;

  // Windows.Devices.Input.IPenTailButtonClickedEventArgs
  Input_IPenTailButtonClickedEventArgs = interface;
  PInput_IPenTailButtonClickedEventArgs = ^Input_IPenTailButtonClickedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonClickedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonClickedEventArgs = interface;
  PTypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonClickedEventArgs = ^TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonClickedEventArgs;

  // Windows.Devices.Input.IPenTailButtonDoubleClickedEventArgs
  Input_IPenTailButtonDoubleClickedEventArgs = interface;
  PInput_IPenTailButtonDoubleClickedEventArgs = ^Input_IPenTailButtonDoubleClickedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonDoubleClickedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonDoubleClickedEventArgs = interface;
  PTypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonDoubleClickedEventArgs = ^TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonDoubleClickedEventArgs;

  // Windows.Devices.Input.IPenTailButtonLongPressedEventArgs
  Input_IPenTailButtonLongPressedEventArgs = interface;
  PInput_IPenTailButtonLongPressedEventArgs = ^Input_IPenTailButtonLongPressedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonLongPressedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonLongPressedEventArgs = interface;
  PTypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonLongPressedEventArgs = ^TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonLongPressedEventArgs;

  // Windows.Devices.Input.IPenButtonListener
  Input_IPenButtonListener = interface;
  PInput_IPenButtonListener = ^Input_IPenButtonListener;

  // Windows.Devices.Input.IPenButtonListenerStatics
  Input_IPenButtonListenerStatics = interface;
  PInput_IPenButtonListenerStatics = ^Input_IPenButtonListenerStatics;

  // Windows.Devices.Input.IPenDevice2
  Input_IPenDevice2 = interface;
  PInput_IPenDevice2 = ^Input_IPenDevice2;

  // Windows.Devices.Input.IPenDeviceStatics
  Input_IPenDeviceStatics = interface;
  PInput_IPenDeviceStatics = ^Input_IPenDeviceStatics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Object>
  TypedEventHandler_2__Input_IPenDockListener__IInspectable = interface;
  PTypedEventHandler_2__Input_IPenDockListener__IInspectable = ^TypedEventHandler_2__Input_IPenDockListener__IInspectable;

  // Windows.Devices.Input.IPenDockedEventArgs
  Input_IPenDockedEventArgs = interface;
  PInput_IPenDockedEventArgs = ^Input_IPenDockedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Windows.Devices.Input.IPenDockedEventArgs>
  TypedEventHandler_2__Input_IPenDockListener__Input_IPenDockedEventArgs = interface;
  PTypedEventHandler_2__Input_IPenDockListener__Input_IPenDockedEventArgs = ^TypedEventHandler_2__Input_IPenDockListener__Input_IPenDockedEventArgs;

  // Windows.Devices.Input.IPenUndockedEventArgs
  Input_IPenUndockedEventArgs = interface;
  PInput_IPenUndockedEventArgs = ^Input_IPenUndockedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Windows.Devices.Input.IPenUndockedEventArgs>
  TypedEventHandler_2__Input_IPenDockListener__Input_IPenUndockedEventArgs = interface;
  PTypedEventHandler_2__Input_IPenDockListener__Input_IPenUndockedEventArgs = ^TypedEventHandler_2__Input_IPenDockListener__Input_IPenUndockedEventArgs;

  // Windows.Devices.Input.IPenDockListener
  Input_IPenDockListener = interface;
  PInput_IPenDockListener = ^Input_IPenDockListener;

  // Windows.Devices.Input.IPenDockListenerStatics
  Input_IPenDockListenerStatics = interface;
  PInput_IPenDockListenerStatics = ^Input_IPenDockListenerStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Input.IPointerDevice>
  IIterator_1__Input_IPointerDevice = interface;
  PIIterator_1__Input_IPointerDevice = ^IIterator_1__Input_IPointerDevice;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Input.IPointerDevice>
  IIterable_1__Input_IPointerDevice = interface;
  PIIterable_1__Input_IPointerDevice = ^IIterable_1__Input_IPointerDevice;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Input.IPointerDevice>
  IVectorView_1__Input_IPointerDevice = interface;
  PIVectorView_1__Input_IPointerDevice = ^IVectorView_1__Input_IPointerDevice;

  // Windows.Devices.Perception.IKnownCameraIntrinsicsPropertiesStatics
  Perception_IKnownCameraIntrinsicsPropertiesStatics = interface;
  PPerception_IKnownCameraIntrinsicsPropertiesStatics = ^Perception_IKnownCameraIntrinsicsPropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionColorFrameSourcePropertiesStatics
  Perception_IKnownPerceptionColorFrameSourcePropertiesStatics = interface;
  PPerception_IKnownPerceptionColorFrameSourcePropertiesStatics = ^Perception_IKnownPerceptionColorFrameSourcePropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionDepthFrameSourcePropertiesStatics
  Perception_IKnownPerceptionDepthFrameSourcePropertiesStatics = interface;
  PPerception_IKnownPerceptionDepthFrameSourcePropertiesStatics = ^Perception_IKnownPerceptionDepthFrameSourcePropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics
  Perception_IKnownPerceptionFrameSourcePropertiesStatics = interface;
  PPerception_IKnownPerceptionFrameSourcePropertiesStatics = ^Perception_IKnownPerceptionFrameSourcePropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics2
  Perception_IKnownPerceptionFrameSourcePropertiesStatics2 = interface;
  PPerception_IKnownPerceptionFrameSourcePropertiesStatics2 = ^Perception_IKnownPerceptionFrameSourcePropertiesStatics2;

  // Windows.Devices.Perception.IKnownPerceptionInfraredFrameSourcePropertiesStatics
  Perception_IKnownPerceptionInfraredFrameSourcePropertiesStatics = interface;
  PPerception_IKnownPerceptionInfraredFrameSourcePropertiesStatics = ^Perception_IKnownPerceptionInfraredFrameSourcePropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionVideoFrameSourcePropertiesStatics
  Perception_IKnownPerceptionVideoFrameSourcePropertiesStatics = interface;
  PPerception_IKnownPerceptionVideoFrameSourcePropertiesStatics = ^Perception_IKnownPerceptionVideoFrameSourcePropertiesStatics;

  // Windows.Devices.Perception.IKnownPerceptionVideoProfilePropertiesStatics
  Perception_IKnownPerceptionVideoProfilePropertiesStatics = interface;
  PPerception_IKnownPerceptionVideoProfilePropertiesStatics = ^Perception_IKnownPerceptionVideoProfilePropertiesStatics;

  // Windows.Devices.Perception.IPerceptionColorFrame
  Perception_IPerceptionColorFrame = interface;
  PPerception_IPerceptionColorFrame = ^Perception_IPerceptionColorFrame;

  // Windows.Devices.Perception.IPerceptionColorFrameArrivedEventArgs
  Perception_IPerceptionColorFrameArrivedEventArgs = interface;
  PPerception_IPerceptionColorFrameArrivedEventArgs = ^Perception_IPerceptionColorFrameArrivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameReader,Windows.Devices.Perception.IPerceptionColorFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameReader__Perception_IPerceptionColorFrameArrivedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameReader__Perception_IPerceptionColorFrameArrivedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionColorFrameReader__Perception_IPerceptionColorFrameArrivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable;

  // Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs
  Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface;
  PPerception_IPerceptionFrameSourcePropertiesChangedEventArgs = ^Perception_IPerceptionFrameSourcePropertiesChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionColorFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs;

  // Windows.Devices.Perception.IPerceptionVideoProfile
  Perception_IPerceptionVideoProfile = interface;
  PPerception_IPerceptionVideoProfile = ^Perception_IPerceptionVideoProfile;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IIterator_1__Perception_IPerceptionVideoProfile = interface;
  PIIterator_1__Perception_IPerceptionVideoProfile = ^IIterator_1__Perception_IPerceptionVideoProfile;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IIterable_1__Perception_IPerceptionVideoProfile = interface;
  PIIterable_1__Perception_IPerceptionVideoProfile = ^IIterable_1__Perception_IPerceptionVideoProfile;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IVectorView_1__Perception_IPerceptionVideoProfile = interface;
  PIVectorView_1__Perception_IPerceptionVideoProfile = ^IVectorView_1__Perception_IPerceptionVideoProfile;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionControlSession,Object>
  TypedEventHandler_2__Perception_IPerceptionControlSession__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionControlSession__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionControlSession__IInspectable;

  // Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult
  Perception_IPerceptionFrameSourcePropertyChangeResult = interface;
  PPerception_IPerceptionFrameSourcePropertyChangeResult = ^Perception_IPerceptionFrameSourcePropertyChangeResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult>
  IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult = interface;
  PIAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult = ^IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult;

  // Windows.Devices.Perception.IPerceptionControlSession
  Perception_IPerceptionControlSession = interface;
  PPerception_IPerceptionControlSession = ^Perception_IPerceptionControlSession;

  // Windows.Devices.Perception.IPerceptionDepthFrame
  Perception_IPerceptionDepthFrame = interface;
  PPerception_IPerceptionDepthFrame = ^Perception_IPerceptionDepthFrame;

  // Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics
  Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface;
  PPerception_IPerceptionDepthCorrelatedCameraIntrinsics = ^Perception_IPerceptionDepthCorrelatedCameraIntrinsics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics>
  IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface;
  PIAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = ^IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs;

  // Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper
  Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface;
  PPerception_IPerceptionDepthCorrelatedCoordinateMapper = ^Perception_IPerceptionDepthCorrelatedCoordinateMapper;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper>
  IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface;
  PIAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = ^IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper;

  // Windows.Devices.Perception.IPerceptionDepthFrameArrivedEventArgs
  Perception_IPerceptionDepthFrameArrivedEventArgs = interface;
  PPerception_IPerceptionDepthFrameArrivedEventArgs = ^Perception_IPerceptionDepthFrameArrivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameReader,Windows.Devices.Perception.IPerceptionDepthFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameReader__Perception_IPerceptionDepthFrameArrivedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameReader__Perception_IPerceptionDepthFrameArrivedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameReader__Perception_IPerceptionDepthFrameArrivedEventArgs;

  // Windows.Devices.Perception.IPerceptionDepthFrameReader
  Perception_IPerceptionDepthFrameReader = interface;
  PPerception_IPerceptionDepthFrameReader = ^Perception_IPerceptionDepthFrameReader;

  // Windows.Devices.Perception.IPerceptionDepthFrameSource
  Perception_IPerceptionDepthFrameSource = interface;
  PPerception_IPerceptionDepthFrameSource = ^Perception_IPerceptionDepthFrameSource;

  // Windows.Devices.Perception.IPerceptionColorFrameSource
  Perception_IPerceptionColorFrameSource = interface;
  PPerception_IPerceptionColorFrameSource = ^Perception_IPerceptionColorFrameSource;

  // Windows.Devices.Perception.IPerceptionColorFrameReader
  Perception_IPerceptionColorFrameReader = interface;
  PPerception_IPerceptionColorFrameReader = ^Perception_IPerceptionColorFrameReader;

  // Windows.Devices.Perception.IPerceptionColorFrameSource2
  Perception_IPerceptionColorFrameSource2 = interface;
  PPerception_IPerceptionColorFrameSource2 = ^Perception_IPerceptionColorFrameSource2;

  // Windows.Devices.Perception.IPerceptionColorFrameSourceAddedEventArgs
  Perception_IPerceptionColorFrameSourceAddedEventArgs = interface;
  PPerception_IPerceptionColorFrameSourceAddedEventArgs = ^Perception_IPerceptionColorFrameSourceAddedEventArgs;

  // Windows.Devices.Perception.IPerceptionColorFrameSourceRemovedEventArgs
  Perception_IPerceptionColorFrameSourceRemovedEventArgs = interface;
  PPerception_IPerceptionColorFrameSourceRemovedEventArgs = ^Perception_IPerceptionColorFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Windows.Devices.Perception.IPerceptionColorFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceAddedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceAddedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceAddedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Windows.Devices.Perception.IPerceptionColorFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceRemovedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceRemovedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable;

  // Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher
  Perception_IPerceptionColorFrameSourceWatcher = interface;
  PPerception_IPerceptionColorFrameSourceWatcher = ^Perception_IPerceptionColorFrameSourceWatcher;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IIterator_1__Perception_IPerceptionColorFrameSource = interface;
  PIIterator_1__Perception_IPerceptionColorFrameSource = ^IIterator_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IIterable_1__Perception_IPerceptionColorFrameSource = interface;
  PIIterable_1__Perception_IPerceptionColorFrameSource = ^IIterable_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IVectorView_1__Perception_IPerceptionColorFrameSource = interface;
  PIVectorView_1__Perception_IPerceptionColorFrameSource = ^IVectorView_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource = ^AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource = interface;
  PIAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource = ^IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IAsyncOperation_1__Perception_IPerceptionColorFrameSource = interface;
  PIAsyncOperation_1__Perception_IPerceptionColorFrameSource = ^IAsyncOperation_1__Perception_IPerceptionColorFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionFrameSourceAccessStatus>
  AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus = ^AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionFrameSourceAccessStatus>
  IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus = interface;
  PIAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus = ^IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus;

  // Windows.Devices.Perception.IPerceptionColorFrameSourceStatics
  Perception_IPerceptionColorFrameSourceStatics = interface;
  PPerception_IPerceptionColorFrameSourceStatics = ^Perception_IPerceptionColorFrameSourceStatics;

  // Windows.Devices.Perception.IPerceptionDepthFrameSource2
  Perception_IPerceptionDepthFrameSource2 = interface;
  PPerception_IPerceptionDepthFrameSource2 = ^Perception_IPerceptionDepthFrameSource2;

  // Windows.Devices.Perception.IPerceptionDepthFrameSourceAddedEventArgs
  Perception_IPerceptionDepthFrameSourceAddedEventArgs = interface;
  PPerception_IPerceptionDepthFrameSourceAddedEventArgs = ^Perception_IPerceptionDepthFrameSourceAddedEventArgs;

  // Windows.Devices.Perception.IPerceptionDepthFrameSourceRemovedEventArgs
  Perception_IPerceptionDepthFrameSourceRemovedEventArgs = interface;
  PPerception_IPerceptionDepthFrameSourceRemovedEventArgs = ^Perception_IPerceptionDepthFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.IPerceptionDepthFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceAddedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceAddedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceAddedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.IPerceptionDepthFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceRemovedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceRemovedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable;

  // Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher
  Perception_IPerceptionDepthFrameSourceWatcher = interface;
  PPerception_IPerceptionDepthFrameSourceWatcher = ^Perception_IPerceptionDepthFrameSourceWatcher;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IIterator_1__Perception_IPerceptionDepthFrameSource = interface;
  PIIterator_1__Perception_IPerceptionDepthFrameSource = ^IIterator_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IIterable_1__Perception_IPerceptionDepthFrameSource = interface;
  PIIterable_1__Perception_IPerceptionDepthFrameSource = ^IIterable_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IVectorView_1__Perception_IPerceptionDepthFrameSource = interface;
  PIVectorView_1__Perception_IPerceptionDepthFrameSource = ^IVectorView_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = ^AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = interface;
  PIAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = ^IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IAsyncOperation_1__Perception_IPerceptionDepthFrameSource = interface;
  PIAsyncOperation_1__Perception_IPerceptionDepthFrameSource = ^IAsyncOperation_1__Perception_IPerceptionDepthFrameSource;

  // Windows.Devices.Perception.IPerceptionDepthFrameSourceStatics
  Perception_IPerceptionDepthFrameSourceStatics = interface;
  PPerception_IPerceptionDepthFrameSourceStatics = ^Perception_IPerceptionDepthFrameSourceStatics;

  // Windows.Devices.Perception.IPerceptionInfraredFrame
  Perception_IPerceptionInfraredFrame = interface;
  PPerception_IPerceptionInfraredFrame = ^Perception_IPerceptionInfraredFrame;

  // Windows.Devices.Perception.IPerceptionInfraredFrameArrivedEventArgs
  Perception_IPerceptionInfraredFrameArrivedEventArgs = interface;
  PPerception_IPerceptionInfraredFrameArrivedEventArgs = ^Perception_IPerceptionInfraredFrameArrivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameReader,Windows.Devices.Perception.IPerceptionInfraredFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameReader__Perception_IPerceptionInfraredFrameArrivedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameReader__Perception_IPerceptionInfraredFrameArrivedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameReader__Perception_IPerceptionInfraredFrameArrivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSource
  Perception_IPerceptionInfraredFrameSource = interface;
  PPerception_IPerceptionInfraredFrameSource = ^Perception_IPerceptionInfraredFrameSource;

  // Windows.Devices.Perception.IPerceptionInfraredFrameReader
  Perception_IPerceptionInfraredFrameReader = interface;
  PPerception_IPerceptionInfraredFrameReader = ^Perception_IPerceptionInfraredFrameReader;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSource2
  Perception_IPerceptionInfraredFrameSource2 = interface;
  PPerception_IPerceptionInfraredFrameSource2 = ^Perception_IPerceptionInfraredFrameSource2;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceAddedEventArgs
  Perception_IPerceptionInfraredFrameSourceAddedEventArgs = interface;
  PPerception_IPerceptionInfraredFrameSourceAddedEventArgs = ^Perception_IPerceptionInfraredFrameSourceAddedEventArgs;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceRemovedEventArgs
  Perception_IPerceptionInfraredFrameSourceRemovedEventArgs = interface;
  PPerception_IPerceptionInfraredFrameSourceRemovedEventArgs = ^Perception_IPerceptionInfraredFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.IPerceptionInfraredFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceAddedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceAddedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceAddedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.IPerceptionInfraredFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceRemovedEventArgs = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceRemovedEventArgs = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceRemovedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable = interface;
  PTypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable = ^TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher
  Perception_IPerceptionInfraredFrameSourceWatcher = interface;
  PPerception_IPerceptionInfraredFrameSourceWatcher = ^Perception_IPerceptionInfraredFrameSourceWatcher;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IIterator_1__Perception_IPerceptionInfraredFrameSource = interface;
  PIIterator_1__Perception_IPerceptionInfraredFrameSource = ^IIterator_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IIterable_1__Perception_IPerceptionInfraredFrameSource = interface;
  PIIterable_1__Perception_IPerceptionInfraredFrameSource = ^IIterable_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface;
  PIVectorView_1__Perception_IPerceptionInfraredFrameSource = ^IVectorView_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = ^AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface;
  PIAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = ^IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource = interface;
  PAsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource = ^AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource = interface;
  PIAsyncOperation_1__Perception_IPerceptionInfraredFrameSource = ^IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource;

  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceStatics
  Perception_IPerceptionInfraredFrameSourceStatics = interface;
  PPerception_IPerceptionInfraredFrameSourceStatics = ^Perception_IPerceptionInfraredFrameSourceStatics;

  // Windows.Devices.Perception.Provider.IKnownPerceptionFrameKindStatics
  Perception_Provider_IKnownPerceptionFrameKindStatics = interface;
  PPerception_Provider_IKnownPerceptionFrameKindStatics = ^Perception_Provider_IKnownPerceptionFrameKindStatics;

  // Windows.Devices.Perception.Provider.IPerceptionControlGroup
  Perception_Provider_IPerceptionControlGroup = interface;
  PPerception_Provider_IPerceptionControlGroup = ^Perception_Provider_IPerceptionControlGroup;

  // Windows.Devices.Perception.Provider.IPerceptionControlGroupFactory
  Perception_Provider_IPerceptionControlGroupFactory = interface;
  PPerception_Provider_IPerceptionControlGroupFactory = ^Perception_Provider_IPerceptionControlGroupFactory;

  // Windows.Devices.Perception.Provider.IPerceptionCorrelation
  Perception_Provider_IPerceptionCorrelation = interface;
  PPerception_Provider_IPerceptionCorrelation = ^Perception_Provider_IPerceptionCorrelation;

  // Windows.Devices.Perception.Provider.IPerceptionCorrelationFactory
  Perception_Provider_IPerceptionCorrelationFactory = interface;
  PPerception_Provider_IPerceptionCorrelationFactory = ^Perception_Provider_IPerceptionCorrelationFactory;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IIterator_1__Perception_Provider_IPerceptionCorrelation = interface;
  PIIterator_1__Perception_Provider_IPerceptionCorrelation = ^IIterator_1__Perception_Provider_IPerceptionCorrelation;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IIterable_1__Perception_Provider_IPerceptionCorrelation = interface;
  PIIterable_1__Perception_Provider_IPerceptionCorrelation = ^IIterable_1__Perception_Provider_IPerceptionCorrelation;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IVectorView_1__Perception_Provider_IPerceptionCorrelation = interface;
  PIVectorView_1__Perception_Provider_IPerceptionCorrelation = ^IVectorView_1__Perception_Provider_IPerceptionCorrelation;

  // Windows.Devices.Perception.Provider.IPerceptionCorrelationGroup
  Perception_Provider_IPerceptionCorrelationGroup = interface;
  PPerception_Provider_IPerceptionCorrelationGroup = ^Perception_Provider_IPerceptionCorrelationGroup;

  // Windows.Devices.Perception.Provider.IPerceptionCorrelationGroupFactory
  Perception_Provider_IPerceptionCorrelationGroupFactory = interface;
  PPerception_Provider_IPerceptionCorrelationGroupFactory = ^Perception_Provider_IPerceptionCorrelationGroupFactory;

  // Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroup
  Perception_Provider_IPerceptionFaceAuthenticationGroup = interface;
  PPerception_Provider_IPerceptionFaceAuthenticationGroup = ^Perception_Provider_IPerceptionFaceAuthenticationGroup;

  // Windows.Devices.Perception.Provider.PerceptionStartFaceAuthenticationHandler
  Perception_Provider_PerceptionStartFaceAuthenticationHandler = interface;
  PPerception_Provider_PerceptionStartFaceAuthenticationHandler = ^Perception_Provider_PerceptionStartFaceAuthenticationHandler;

  // Windows.Devices.Perception.Provider.PerceptionStopFaceAuthenticationHandler
  Perception_Provider_PerceptionStopFaceAuthenticationHandler = interface;
  PPerception_Provider_PerceptionStopFaceAuthenticationHandler = ^Perception_Provider_PerceptionStopFaceAuthenticationHandler;

  // Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroupFactory
  Perception_Provider_IPerceptionFaceAuthenticationGroupFactory = interface;
  PPerception_Provider_IPerceptionFaceAuthenticationGroupFactory = ^Perception_Provider_IPerceptionFaceAuthenticationGroupFactory;

  // Windows.Devices.Perception.Provider.IPerceptionFrame
  Perception_Provider_IPerceptionFrame = interface;
  PPerception_Provider_IPerceptionFrame = ^Perception_Provider_IPerceptionFrame;

  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderInfo
  Perception_Provider_IPerceptionFrameProviderInfo = interface;
  PPerception_Provider_IPerceptionFrameProviderInfo = ^Perception_Provider_IPerceptionFrameProviderInfo;

  // Windows.Devices.Perception.Provider.IPerceptionPropertyChangeRequest
  Perception_Provider_IPerceptionPropertyChangeRequest = interface;
  PPerception_Provider_IPerceptionPropertyChangeRequest = ^Perception_Provider_IPerceptionPropertyChangeRequest;

  // Windows.Devices.Perception.Provider.IPerceptionFrameProvider
  Perception_Provider_IPerceptionFrameProvider = interface;
  PPerception_Provider_IPerceptionFrameProvider = ^Perception_Provider_IPerceptionFrameProvider;

  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderManager
  Perception_Provider_IPerceptionFrameProviderManager = interface;
  PPerception_Provider_IPerceptionFrameProviderManager = ^Perception_Provider_IPerceptionFrameProviderManager;

  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderManagerServiceStatics
  Perception_Provider_IPerceptionFrameProviderManagerServiceStatics = interface;
  PPerception_Provider_IPerceptionFrameProviderManagerServiceStatics = ^Perception_Provider_IPerceptionFrameProviderManagerServiceStatics;

  // Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocator
  Perception_Provider_IPerceptionVideoFrameAllocator = interface;
  PPerception_Provider_IPerceptionVideoFrameAllocator = ^Perception_Provider_IPerceptionVideoFrameAllocator;

  // Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocatorFactory
  Perception_Provider_IPerceptionVideoFrameAllocatorFactory = interface;
  PPerception_Provider_IPerceptionVideoFrameAllocatorFactory = ^Perception_Provider_IPerceptionVideoFrameAllocatorFactory;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Power.IBattery,Object>
  TypedEventHandler_2__Power_IBattery__IInspectable = interface;
  PTypedEventHandler_2__Power_IBattery__IInspectable = ^TypedEventHandler_2__Power_IBattery__IInspectable;

  // Windows.Devices.Power.IBattery
  Power_IBattery = interface;
  PPower_IBattery = ^Power_IBattery;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Power.IBattery>
  AsyncOperationCompletedHandler_1__Power_IBattery = interface;
  PAsyncOperationCompletedHandler_1__Power_IBattery = ^AsyncOperationCompletedHandler_1__Power_IBattery;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Power.IBattery>
  IAsyncOperation_1__Power_IBattery = interface;
  PIAsyncOperation_1__Power_IBattery = ^IAsyncOperation_1__Power_IBattery;

  // Windows.Devices.Power.IBatteryStatics
  Power_IBatteryStatics = interface;
  PPower_IBatteryStatics = ^Power_IBatteryStatics;

  // Windows.Devices.Pwm.IPwmPin
  Pwm_IPwmPin = interface;
  PPwm_IPwmPin = ^Pwm_IPwmPin;

  // Windows.Devices.Pwm.IPwmController
  Pwm_IPwmController = interface;
  PPwm_IPwmController = ^Pwm_IPwmController;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Pwm.IPwmController>
  IIterator_1__Pwm_IPwmController = interface;
  PIIterator_1__Pwm_IPwmController = ^IIterator_1__Pwm_IPwmController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Pwm.IPwmController>
  IIterable_1__Pwm_IPwmController = interface;
  PIIterable_1__Pwm_IPwmController = ^IIterable_1__Pwm_IPwmController;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>
  IVectorView_1__Pwm_IPwmController = interface;
  PIVectorView_1__Pwm_IPwmController = ^IVectorView_1__Pwm_IPwmController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController = ^AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>>
  IAsyncOperation_1__IVectorView_1__Pwm_IPwmController = interface;
  PIAsyncOperation_1__IVectorView_1__Pwm_IPwmController = ^IAsyncOperation_1__IVectorView_1__Pwm_IPwmController;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IIterator_1__Pwm_Provider_IPwmControllerProvider = interface;
  PIIterator_1__Pwm_Provider_IPwmControllerProvider = ^IIterator_1__Pwm_Provider_IPwmControllerProvider;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IIterable_1__Pwm_Provider_IPwmControllerProvider = interface;
  PIIterable_1__Pwm_Provider_IPwmControllerProvider = ^IIterable_1__Pwm_Provider_IPwmControllerProvider;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IVectorView_1__Pwm_Provider_IPwmControllerProvider = interface;
  PIVectorView_1__Pwm_Provider_IPwmControllerProvider = ^IVectorView_1__Pwm_Provider_IPwmControllerProvider;

  // Windows.Devices.Pwm.Provider.IPwmProvider
  Pwm_Provider_IPwmProvider = interface;
  PPwm_Provider_IPwmProvider = ^Pwm_Provider_IPwmProvider;

  // Windows.Devices.Pwm.IPwmControllerStatics
  Pwm_IPwmControllerStatics = interface;
  PPwm_IPwmControllerStatics = ^Pwm_IPwmControllerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Pwm.IPwmController>
  AsyncOperationCompletedHandler_1__Pwm_IPwmController = interface;
  PAsyncOperationCompletedHandler_1__Pwm_IPwmController = ^AsyncOperationCompletedHandler_1__Pwm_IPwmController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Pwm.IPwmController>
  IAsyncOperation_1__Pwm_IPwmController = interface;
  PIAsyncOperation_1__Pwm_IPwmController = ^IAsyncOperation_1__Pwm_IPwmController;

  // Windows.Devices.Pwm.IPwmControllerStatics2
  Pwm_IPwmControllerStatics2 = interface;
  PPwm_IPwmControllerStatics2 = ^Pwm_IPwmControllerStatics2;

  // Windows.Devices.Pwm.IPwmControllerStatics3
  Pwm_IPwmControllerStatics3 = interface;
  PPwm_IPwmControllerStatics3 = ^Pwm_IPwmControllerStatics3;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Radios.IRadio>
  IIterator_1__Radios_IRadio = interface;
  PIIterator_1__Radios_IRadio = ^IIterator_1__Radios_IRadio;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Radios.IRadio>
  IIterable_1__Radios_IRadio = interface;
  PIIterable_1__Radios_IRadio = ^IIterable_1__Radios_IRadio;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>
  IVectorView_1__Radios_IRadio = interface;
  PIVectorView_1__Radios_IRadio = ^IVectorView_1__Radios_IRadio;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio = ^AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>>
  IAsyncOperation_1__IVectorView_1__Radios_IRadio = interface;
  PIAsyncOperation_1__IVectorView_1__Radios_IRadio = ^IAsyncOperation_1__IVectorView_1__Radios_IRadio;

  // Windows.Devices.Radios.IRadioStatics
  Radios_IRadioStatics = interface;
  PRadios_IRadioStatics = ^Radios_IRadioStatics;

  // Windows.Devices.SerialCommunication.IErrorReceivedEventArgs
  SerialCommunication_IErrorReceivedEventArgs = interface;
  PSerialCommunication_IErrorReceivedEventArgs = ^SerialCommunication_IErrorReceivedEventArgs;

  // Windows.Devices.SerialCommunication.IPinChangedEventArgs
  SerialCommunication_IPinChangedEventArgs = interface;
  PSerialCommunication_IPinChangedEventArgs = ^SerialCommunication_IPinChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.ISerialDevice,Windows.Devices.SerialCommunication.IErrorReceivedEventArgs>
  TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IErrorReceivedEventArgs = interface;
  PTypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IErrorReceivedEventArgs = ^TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IErrorReceivedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.ISerialDevice,Windows.Devices.SerialCommunication.IPinChangedEventArgs>
  TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IPinChangedEventArgs = interface;
  PTypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IPinChangedEventArgs = ^TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IPinChangedEventArgs;

  // Windows.Devices.SerialCommunication.ISerialDevice
  SerialCommunication_ISerialDevice = interface;
  PSerialCommunication_ISerialDevice = ^SerialCommunication_ISerialDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SerialCommunication.ISerialDevice>
  AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice = interface;
  PAsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice = ^AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SerialCommunication.ISerialDevice>
  IAsyncOperation_1__SerialCommunication_ISerialDevice = interface;
  PIAsyncOperation_1__SerialCommunication_ISerialDevice = ^IAsyncOperation_1__SerialCommunication_ISerialDevice;

  // Windows.Devices.SerialCommunication.ISerialDeviceStatics
  SerialCommunication_ISerialDeviceStatics = interface;
  PSerialCommunication_ISerialDeviceStatics = ^SerialCommunication_ISerialDeviceStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardReaderStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus = interface;
  PAsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus = ^AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardReaderStatus>
  IAsyncOperation_1__SmartCards_SmartCardReaderStatus = interface;
  PIAsyncOperation_1__SmartCards_SmartCardReaderStatus = ^IAsyncOperation_1__SmartCards_SmartCardReaderStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus = interface;
  PAsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus = ^AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardStatus>
  IAsyncOperation_1__SmartCards_SmartCardStatus = interface;
  PIAsyncOperation_1__SmartCards_SmartCardStatus = ^IAsyncOperation_1__SmartCards_SmartCardStatus;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardActivationPolicyChangeResult>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult = interface;
  PAsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult = ^AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardActivationPolicyChangeResult>
  IAsyncOperation_1__SmartCards_SmartCardActivationPolicyChangeResult = interface;
  PIAsyncOperation_1__SmartCards_SmartCardActivationPolicyChangeResult = ^IAsyncOperation_1__SmartCards_SmartCardActivationPolicyChangeResult;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialType = interface;
  PIIterator_1__SmartCards_SmartCardCryptogramMaterialType = ^IIterator_1__SmartCards_SmartCardCryptogramMaterialType;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialType = interface;
  PIIterable_1__SmartCards_SmartCardCryptogramMaterialType = ^IIterable_1__SmartCards_SmartCardCryptogramMaterialType;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialType = interface;
  PIVectorView_1__SmartCards_SmartCardCryptogramMaterialType = ^IVectorView_1__SmartCards_SmartCardCryptogramMaterialType;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IIterator_1__SmartCards_SmartCardCryptogramAlgorithm = interface;
  PIIterator_1__SmartCards_SmartCardCryptogramAlgorithm = ^IIterator_1__SmartCards_SmartCardCryptogramAlgorithm;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IIterable_1__SmartCards_SmartCardCryptogramAlgorithm = interface;
  PIIterable_1__SmartCards_SmartCardCryptogramAlgorithm = ^IIterable_1__SmartCards_SmartCardCryptogramAlgorithm;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IVectorView_1__SmartCards_SmartCardCryptogramAlgorithm = interface;
  PIVectorView_1__SmartCards_SmartCardCryptogramAlgorithm = ^IVectorView_1__SmartCards_SmartCardCryptogramAlgorithm;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface;
  PIIterator_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = ^IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageFormat;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface;
  PIIterable_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = ^IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageFormat;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface;
  PIVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = ^IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageFormat;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface;
  PIIterator_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = ^IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface;
  PIIterable_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = ^IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface;
  PIVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = ^IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IIterator_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface;
  PIIterator_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = ^IIterator_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IIterable_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface;
  PIIterable_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = ^IIterable_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IVectorView_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface;
  PIVectorView_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = ^IVectorView_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardCryptogramGeneratorOperationStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = interface;
  PAsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = ^AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardCryptogramGeneratorOperationStatus>
  IAsyncOperation_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = interface;
  PIAsyncOperation_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = ^IAsyncOperation_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus;

  // Windows.Devices.Spi.ISpiBusInfo
  Spi_ISpiBusInfo = interface;
  PSpi_ISpiBusInfo = ^Spi_ISpiBusInfo;

  // Windows.Devices.Spi.ISpiConnectionSettings
  Spi_ISpiConnectionSettings = interface;
  PSpi_ISpiConnectionSettings = ^Spi_ISpiConnectionSettings;

  // Windows.Devices.Spi.ISpiConnectionSettingsFactory
  Spi_ISpiConnectionSettingsFactory = interface;
  PSpi_ISpiConnectionSettingsFactory = ^Spi_ISpiConnectionSettingsFactory;

  // Windows.Devices.Spi.ISpiDevice
  Spi_ISpiDevice = interface;
  PSpi_ISpiDevice = ^Spi_ISpiDevice;

  // Windows.Devices.Spi.ISpiController
  Spi_ISpiController = interface;
  PSpi_ISpiController = ^Spi_ISpiController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.ISpiController>
  AsyncOperationCompletedHandler_1__Spi_ISpiController = interface;
  PAsyncOperationCompletedHandler_1__Spi_ISpiController = ^AsyncOperationCompletedHandler_1__Spi_ISpiController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.ISpiController>
  IAsyncOperation_1__Spi_ISpiController = interface;
  PIAsyncOperation_1__Spi_ISpiController = ^IAsyncOperation_1__Spi_ISpiController;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Spi.ISpiController>
  IIterator_1__Spi_ISpiController = interface;
  PIIterator_1__Spi_ISpiController = ^IIterator_1__Spi_ISpiController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Spi.ISpiController>
  IIterable_1__Spi_ISpiController = interface;
  PIIterable_1__Spi_ISpiController = ^IIterable_1__Spi_ISpiController;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>
  IVectorView_1__Spi_ISpiController = interface;
  PIVectorView_1__Spi_ISpiController = ^IVectorView_1__Spi_ISpiController;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController = ^AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>>
  IAsyncOperation_1__IVectorView_1__Spi_ISpiController = interface;
  PIAsyncOperation_1__IVectorView_1__Spi_ISpiController = ^IAsyncOperation_1__IVectorView_1__Spi_ISpiController;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IIterator_1__Spi_Provider_ISpiControllerProvider = interface;
  PIIterator_1__Spi_Provider_ISpiControllerProvider = ^IIterator_1__Spi_Provider_ISpiControllerProvider;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IIterable_1__Spi_Provider_ISpiControllerProvider = interface;
  PIIterable_1__Spi_Provider_ISpiControllerProvider = ^IIterable_1__Spi_Provider_ISpiControllerProvider;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IVectorView_1__Spi_Provider_ISpiControllerProvider = interface;
  PIVectorView_1__Spi_Provider_ISpiControllerProvider = ^IVectorView_1__Spi_Provider_ISpiControllerProvider;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = ^AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>>
  IAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = interface;
  PIAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = ^IAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider;

  // Windows.Devices.Spi.Provider.ISpiProvider
  Spi_Provider_ISpiProvider = interface;
  PSpi_Provider_ISpiProvider = ^Spi_Provider_ISpiProvider;

  // Windows.Devices.Spi.ISpiControllerStatics
  Spi_ISpiControllerStatics = interface;
  PSpi_ISpiControllerStatics = ^Spi_ISpiControllerStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.ISpiDevice>
  AsyncOperationCompletedHandler_1__Spi_ISpiDevice = interface;
  PAsyncOperationCompletedHandler_1__Spi_ISpiDevice = ^AsyncOperationCompletedHandler_1__Spi_ISpiDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.ISpiDevice>
  IAsyncOperation_1__Spi_ISpiDevice = interface;
  PIAsyncOperation_1__Spi_ISpiDevice = ^IAsyncOperation_1__Spi_ISpiDevice;

  // Windows.Devices.Spi.ISpiDeviceStatics
  Spi_ISpiDeviceStatics = interface;
  PSpi_ISpiDeviceStatics = ^Spi_ISpiDeviceStatics;

  // Windows.Devices.Spi.Provider.IProviderSpiConnectionSettingsFactory
  Spi_Provider_IProviderSpiConnectionSettingsFactory = interface;
  PSpi_Provider_IProviderSpiConnectionSettingsFactory = ^Spi_Provider_IProviderSpiConnectionSettingsFactory;

  // Windows.Devices.Usb.IUsbBulkInPipe
  Usb_IUsbBulkInPipe = interface;
  PUsb_IUsbBulkInPipe = ^Usb_IUsbBulkInPipe;

  // Windows.Devices.Usb.IUsbBulkInEndpointDescriptor
  Usb_IUsbBulkInEndpointDescriptor = interface;
  PUsb_IUsbBulkInEndpointDescriptor = ^Usb_IUsbBulkInEndpointDescriptor;

  // Windows.Devices.Usb.IUsbBulkOutPipe
  Usb_IUsbBulkOutPipe = interface;
  PUsb_IUsbBulkOutPipe = ^Usb_IUsbBulkOutPipe;

  // Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor
  Usb_IUsbBulkOutEndpointDescriptor = interface;
  PUsb_IUsbBulkOutEndpointDescriptor = ^Usb_IUsbBulkOutEndpointDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IIterator_1__Usb_IUsbBulkInPipe = interface;
  PIIterator_1__Usb_IUsbBulkInPipe = ^IIterator_1__Usb_IUsbBulkInPipe;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IIterable_1__Usb_IUsbBulkInPipe = interface;
  PIIterable_1__Usb_IUsbBulkInPipe = ^IIterable_1__Usb_IUsbBulkInPipe;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IVectorView_1__Usb_IUsbBulkInPipe = interface;
  PIVectorView_1__Usb_IUsbBulkInPipe = ^IVectorView_1__Usb_IUsbBulkInPipe;

  // Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor
  Usb_IUsbInterruptInEndpointDescriptor = interface;
  PUsb_IUsbInterruptInEndpointDescriptor = ^Usb_IUsbInterruptInEndpointDescriptor;

  // Windows.Devices.Usb.IUsbInterruptInEventArgs
  Usb_IUsbInterruptInEventArgs = interface;
  PUsb_IUsbInterruptInEventArgs = ^Usb_IUsbInterruptInEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Usb.IUsbInterruptInPipe,Windows.Devices.Usb.IUsbInterruptInEventArgs>
  TypedEventHandler_2__Usb_IUsbInterruptInPipe__Usb_IUsbInterruptInEventArgs = interface;
  PTypedEventHandler_2__Usb_IUsbInterruptInPipe__Usb_IUsbInterruptInEventArgs = ^TypedEventHandler_2__Usb_IUsbInterruptInPipe__Usb_IUsbInterruptInEventArgs;

  // Windows.Devices.Usb.IUsbInterruptInPipe
  Usb_IUsbInterruptInPipe = interface;
  PUsb_IUsbInterruptInPipe = ^Usb_IUsbInterruptInPipe;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IIterator_1__Usb_IUsbInterruptInPipe = interface;
  PIIterator_1__Usb_IUsbInterruptInPipe = ^IIterator_1__Usb_IUsbInterruptInPipe;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IIterable_1__Usb_IUsbInterruptInPipe = interface;
  PIIterable_1__Usb_IUsbInterruptInPipe = ^IIterable_1__Usb_IUsbInterruptInPipe;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IVectorView_1__Usb_IUsbInterruptInPipe = interface;
  PIVectorView_1__Usb_IUsbInterruptInPipe = ^IVectorView_1__Usb_IUsbInterruptInPipe;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IIterator_1__Usb_IUsbBulkOutPipe = interface;
  PIIterator_1__Usb_IUsbBulkOutPipe = ^IIterator_1__Usb_IUsbBulkOutPipe;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IIterable_1__Usb_IUsbBulkOutPipe = interface;
  PIIterable_1__Usb_IUsbBulkOutPipe = ^IIterable_1__Usb_IUsbBulkOutPipe;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IVectorView_1__Usb_IUsbBulkOutPipe = interface;
  PIVectorView_1__Usb_IUsbBulkOutPipe = ^IVectorView_1__Usb_IUsbBulkOutPipe;

  // Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor
  Usb_IUsbInterruptOutEndpointDescriptor = interface;
  PUsb_IUsbInterruptOutEndpointDescriptor = ^Usb_IUsbInterruptOutEndpointDescriptor;

  // Windows.Devices.Usb.IUsbInterruptOutPipe
  Usb_IUsbInterruptOutPipe = interface;
  PUsb_IUsbInterruptOutPipe = ^Usb_IUsbInterruptOutPipe;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IIterator_1__Usb_IUsbInterruptOutPipe = interface;
  PIIterator_1__Usb_IUsbInterruptOutPipe = ^IIterator_1__Usb_IUsbInterruptOutPipe;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IIterable_1__Usb_IUsbInterruptOutPipe = interface;
  PIIterable_1__Usb_IUsbInterruptOutPipe = ^IIterable_1__Usb_IUsbInterruptOutPipe;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IVectorView_1__Usb_IUsbInterruptOutPipe = interface;
  PIVectorView_1__Usb_IUsbInterruptOutPipe = ^IVectorView_1__Usb_IUsbInterruptOutPipe;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IIterator_1__Usb_IUsbBulkInEndpointDescriptor = interface;
  PIIterator_1__Usb_IUsbBulkInEndpointDescriptor = ^IIterator_1__Usb_IUsbBulkInEndpointDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IIterable_1__Usb_IUsbBulkInEndpointDescriptor = interface;
  PIIterable_1__Usb_IUsbBulkInEndpointDescriptor = ^IIterable_1__Usb_IUsbBulkInEndpointDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IVectorView_1__Usb_IUsbBulkInEndpointDescriptor = interface;
  PIVectorView_1__Usb_IUsbBulkInEndpointDescriptor = ^IVectorView_1__Usb_IUsbBulkInEndpointDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IIterator_1__Usb_IUsbInterruptInEndpointDescriptor = interface;
  PIIterator_1__Usb_IUsbInterruptInEndpointDescriptor = ^IIterator_1__Usb_IUsbInterruptInEndpointDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IIterable_1__Usb_IUsbInterruptInEndpointDescriptor = interface;
  PIIterable_1__Usb_IUsbInterruptInEndpointDescriptor = ^IIterable_1__Usb_IUsbInterruptInEndpointDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IVectorView_1__Usb_IUsbInterruptInEndpointDescriptor = interface;
  PIVectorView_1__Usb_IUsbInterruptInEndpointDescriptor = ^IVectorView_1__Usb_IUsbInterruptInEndpointDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IIterator_1__Usb_IUsbBulkOutEndpointDescriptor = interface;
  PIIterator_1__Usb_IUsbBulkOutEndpointDescriptor = ^IIterator_1__Usb_IUsbBulkOutEndpointDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IIterable_1__Usb_IUsbBulkOutEndpointDescriptor = interface;
  PIIterable_1__Usb_IUsbBulkOutEndpointDescriptor = ^IIterable_1__Usb_IUsbBulkOutEndpointDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IVectorView_1__Usb_IUsbBulkOutEndpointDescriptor = interface;
  PIVectorView_1__Usb_IUsbBulkOutEndpointDescriptor = ^IVectorView_1__Usb_IUsbBulkOutEndpointDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IIterator_1__Usb_IUsbInterruptOutEndpointDescriptor = interface;
  PIIterator_1__Usb_IUsbInterruptOutEndpointDescriptor = ^IIterator_1__Usb_IUsbInterruptOutEndpointDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IIterable_1__Usb_IUsbInterruptOutEndpointDescriptor = interface;
  PIIterable_1__Usb_IUsbInterruptOutEndpointDescriptor = ^IIterable_1__Usb_IUsbInterruptOutEndpointDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor = interface;
  PIVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor = ^IVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor;

  // Windows.Devices.Usb.IUsbInterfaceDescriptor
  Usb_IUsbInterfaceDescriptor = interface;
  PUsb_IUsbInterfaceDescriptor = ^Usb_IUsbInterfaceDescriptor;

  // Windows.Devices.Usb.IUsbDescriptor
  Usb_IUsbDescriptor = interface;
  PUsb_IUsbDescriptor = ^Usb_IUsbDescriptor;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbDescriptor>
  IIterator_1__Usb_IUsbDescriptor = interface;
  PIIterator_1__Usb_IUsbDescriptor = ^IIterator_1__Usb_IUsbDescriptor;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbDescriptor>
  IIterable_1__Usb_IUsbDescriptor = interface;
  PIIterable_1__Usb_IUsbDescriptor = ^IIterable_1__Usb_IUsbDescriptor;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbDescriptor>
  IVectorView_1__Usb_IUsbDescriptor = interface;
  PIVectorView_1__Usb_IUsbDescriptor = ^IVectorView_1__Usb_IUsbDescriptor;

  // Windows.Devices.Usb.IUsbInterfaceSetting
  Usb_IUsbInterfaceSetting = interface;
  PUsb_IUsbInterfaceSetting = ^Usb_IUsbInterfaceSetting;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IIterator_1__Usb_IUsbInterfaceSetting = interface;
  PIIterator_1__Usb_IUsbInterfaceSetting = ^IIterator_1__Usb_IUsbInterfaceSetting;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IIterable_1__Usb_IUsbInterfaceSetting = interface;
  PIIterable_1__Usb_IUsbInterfaceSetting = ^IIterable_1__Usb_IUsbInterfaceSetting;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IVectorView_1__Usb_IUsbInterfaceSetting = interface;
  PIVectorView_1__Usb_IUsbInterfaceSetting = ^IVectorView_1__Usb_IUsbInterfaceSetting;

  // Windows.Devices.Usb.IUsbInterface
  Usb_IUsbInterface = interface;
  PUsb_IUsbInterface = ^Usb_IUsbInterface;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterface>
  IIterator_1__Usb_IUsbInterface = interface;
  PIIterator_1__Usb_IUsbInterface = ^IIterator_1__Usb_IUsbInterface;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterface>
  IIterable_1__Usb_IUsbInterface = interface;
  PIIterable_1__Usb_IUsbInterface = ^IIterable_1__Usb_IUsbInterface;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterface>
  IVectorView_1__Usb_IUsbInterface = interface;
  PIVectorView_1__Usb_IUsbInterface = ^IVectorView_1__Usb_IUsbInterface;

  // Windows.Devices.Usb.IUsbConfigurationDescriptor
  Usb_IUsbConfigurationDescriptor = interface;
  PUsb_IUsbConfigurationDescriptor = ^Usb_IUsbConfigurationDescriptor;

  // Windows.Devices.Usb.IUsbConfiguration
  Usb_IUsbConfiguration = interface;
  PUsb_IUsbConfiguration = ^Usb_IUsbConfiguration;

  // Windows.Devices.Usb.IUsbConfigurationDescriptorStatics
  Usb_IUsbConfigurationDescriptorStatics = interface;
  PUsb_IUsbConfigurationDescriptorStatics = ^Usb_IUsbConfigurationDescriptorStatics;

  // Windows.Devices.Usb.IUsbControlRequestType
  Usb_IUsbControlRequestType = interface;
  PUsb_IUsbControlRequestType = ^Usb_IUsbControlRequestType;

  // Windows.Devices.Usb.IUsbSetupPacket
  Usb_IUsbSetupPacket = interface;
  PUsb_IUsbSetupPacket = ^Usb_IUsbSetupPacket;

  // Windows.Devices.Usb.IUsbDeviceDescriptor
  Usb_IUsbDeviceDescriptor = interface;
  PUsb_IUsbDeviceDescriptor = ^Usb_IUsbDeviceDescriptor;

  // Windows.Devices.Usb.IUsbDevice
  Usb_IUsbDevice = interface;
  PUsb_IUsbDevice = ^Usb_IUsbDevice;

  // Windows.Devices.Usb.IUsbDeviceClass
  Usb_IUsbDeviceClass = interface;
  PUsb_IUsbDeviceClass = ^Usb_IUsbDeviceClass;

  // Windows.Devices.Usb.IUsbDeviceClasses
  Usb_IUsbDeviceClasses = interface;
  PUsb_IUsbDeviceClasses = ^Usb_IUsbDeviceClasses;

  // Windows.Devices.Usb.IUsbDeviceClassesStatics
  Usb_IUsbDeviceClassesStatics = interface;
  PUsb_IUsbDeviceClassesStatics = ^Usb_IUsbDeviceClassesStatics;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Usb.IUsbDevice>
  AsyncOperationCompletedHandler_1__Usb_IUsbDevice = interface;
  PAsyncOperationCompletedHandler_1__Usb_IUsbDevice = ^AsyncOperationCompletedHandler_1__Usb_IUsbDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Usb.IUsbDevice>
  IAsyncOperation_1__Usb_IUsbDevice = interface;
  PIAsyncOperation_1__Usb_IUsbDevice = ^IAsyncOperation_1__Usb_IUsbDevice;

  // Windows.Devices.Usb.IUsbDeviceStatics
  Usb_IUsbDeviceStatics = interface;
  PUsb_IUsbDeviceStatics = ^Usb_IUsbDeviceStatics;

  // Windows.Devices.Usb.IUsbEndpointDescriptor
  Usb_IUsbEndpointDescriptor = interface;
  PUsb_IUsbEndpointDescriptor = ^Usb_IUsbEndpointDescriptor;

  // Windows.Devices.Usb.IUsbEndpointDescriptorStatics
  Usb_IUsbEndpointDescriptorStatics = interface;
  PUsb_IUsbEndpointDescriptorStatics = ^Usb_IUsbEndpointDescriptorStatics;

  // Windows.Devices.Usb.IUsbInterfaceDescriptorStatics
  Usb_IUsbInterfaceDescriptorStatics = interface;
  PUsb_IUsbInterfaceDescriptorStatics = ^Usb_IUsbInterfaceDescriptorStatics;

  // Windows.Devices.Usb.IUsbSetupPacketFactory
  Usb_IUsbSetupPacketFactory = interface;
  PUsb_IUsbSetupPacketFactory = ^Usb_IUsbSetupPacketFactory;

  // Windows.Devices.WiFi.IWiFiAvailableNetwork
  WiFi_IWiFiAvailableNetwork = interface;
  PWiFi_IWiFiAvailableNetwork = ^WiFi_IWiFiAvailableNetwork;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IIterator_1__WiFi_IWiFiAvailableNetwork = interface;
  PIIterator_1__WiFi_IWiFiAvailableNetwork = ^IIterator_1__WiFi_IWiFiAvailableNetwork;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IIterable_1__WiFi_IWiFiAvailableNetwork = interface;
  PIIterable_1__WiFi_IWiFiAvailableNetwork = ^IIterable_1__WiFi_IWiFiAvailableNetwork;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IVectorView_1__WiFi_IWiFiAvailableNetwork = interface;
  PIVectorView_1__WiFi_IWiFiAvailableNetwork = ^IVectorView_1__WiFi_IWiFiAvailableNetwork;

  // Windows.Devices.WiFi.IWiFiNetworkReport
  WiFi_IWiFiNetworkReport = interface;
  PWiFi_IWiFiNetworkReport = ^WiFi_IWiFiNetworkReport;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFi.IWiFiAdapter,Object>
  TypedEventHandler_2__WiFi_IWiFiAdapter__IInspectable = interface;
  PTypedEventHandler_2__WiFi_IWiFiAdapter__IInspectable = ^TypedEventHandler_2__WiFi_IWiFiAdapter__IInspectable;

  // Windows.Devices.WiFi.IWiFiConnectionResult
  WiFi_IWiFiConnectionResult = interface;
  PWiFi_IWiFiConnectionResult = ^WiFi_IWiFiConnectionResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiConnectionResult>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult = interface;
  PAsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult = ^AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiConnectionResult>
  IAsyncOperation_1__WiFi_IWiFiConnectionResult = interface;
  PIAsyncOperation_1__WiFi_IWiFiConnectionResult = ^IAsyncOperation_1__WiFi_IWiFiConnectionResult;

  // Windows.Devices.WiFi.IWiFiAdapter
  WiFi_IWiFiAdapter = interface;
  PWiFi_IWiFiAdapter = ^WiFi_IWiFiAdapter;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.WiFiWpsKind>
  IIterator_1__WiFi_WiFiWpsKind = interface;
  PIIterator_1__WiFi_WiFiWpsKind = ^IIterator_1__WiFi_WiFiWpsKind;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.WiFiWpsKind>
  IIterable_1__WiFi_WiFiWpsKind = interface;
  PIIterable_1__WiFi_WiFiWpsKind = ^IIterable_1__WiFi_WiFiWpsKind;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.WiFiWpsKind>
  IVectorView_1__WiFi_WiFiWpsKind = interface;
  PIVectorView_1__WiFi_WiFiWpsKind = ^IVectorView_1__WiFi_WiFiWpsKind;

  // Windows.Devices.WiFi.IWiFiWpsConfigurationResult
  WiFi_IWiFiWpsConfigurationResult = interface;
  PWiFi_IWiFiWpsConfigurationResult = ^WiFi_IWiFiWpsConfigurationResult;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiWpsConfigurationResult>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult = interface;
  PAsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult = ^AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiWpsConfigurationResult>
  IAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult = interface;
  PIAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult = ^IAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult;

  // Windows.Devices.WiFi.IWiFiAdapter2
  WiFi_IWiFiAdapter2 = interface;
  PWiFi_IWiFiAdapter2 = ^WiFi_IWiFiAdapter2;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.IWiFiAdapter>
  IIterator_1__WiFi_IWiFiAdapter = interface;
  PIIterator_1__WiFi_IWiFiAdapter = ^IIterator_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.IWiFiAdapter>
  IIterable_1__WiFi_IWiFiAdapter = interface;
  PIIterable_1__WiFi_IWiFiAdapter = ^IIterable_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>
  IVectorView_1__WiFi_IWiFiAdapter = interface;
  PIVectorView_1__WiFi_IWiFiAdapter = ^IVectorView_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>>
  AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter = ^AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>>
  IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter = interface;
  PIAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter = ^IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiAdapter>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter = interface;
  PAsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter = ^AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiAdapter>
  IAsyncOperation_1__WiFi_IWiFiAdapter = interface;
  PIAsyncOperation_1__WiFi_IWiFiAdapter = ^IAsyncOperation_1__WiFi_IWiFiAdapter;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.WiFiAccessStatus>
  AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus = interface;
  PAsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus = ^AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.WiFiAccessStatus>
  IAsyncOperation_1__WiFi_WiFiAccessStatus = interface;
  PIAsyncOperation_1__WiFi_WiFiAccessStatus = ^IAsyncOperation_1__WiFi_WiFiAccessStatus;

  // Windows.Devices.WiFi.IWiFiAdapterStatics
  WiFi_IWiFiAdapterStatics = interface;
  PWiFi_IWiFiAdapterStatics = ^WiFi_IWiFiAdapterStatics;

  // Windows.Foundation.IReference`1<Windows.Devices.WiFi.WiFiOnDemandHotspotCellularBars>
  IReference_1__WiFi_WiFiOnDemandHotspotCellularBars = interface;
  PIReference_1__WiFi_WiFiOnDemandHotspotCellularBars = ^IReference_1__WiFi_WiFiOnDemandHotspotCellularBars;

  // Windows.Devices.WiFiDirect.IWiFiDirectInformationElement
  WiFiDirect_IWiFiDirectInformationElement = interface;
  PWiFiDirect_IWiFiDirectInformationElement = ^WiFiDirect_IWiFiDirectInformationElement;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IIterator_1__WiFiDirect_IWiFiDirectInformationElement = interface;
  PIIterator_1__WiFiDirect_IWiFiDirectInformationElement = ^IIterator_1__WiFiDirect_IWiFiDirectInformationElement;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IIterable_1__WiFiDirect_IWiFiDirectInformationElement = interface;
  PIIterable_1__WiFiDirect_IWiFiDirectInformationElement = ^IIterable_1__WiFiDirect_IWiFiDirectInformationElement;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IVectorView_1__WiFiDirect_IWiFiDirectInformationElement = interface;
  PIVectorView_1__WiFiDirect_IWiFiDirectInformationElement = ^IVectorView_1__WiFiDirect_IWiFiDirectInformationElement;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IVector_1__WiFiDirect_IWiFiDirectInformationElement = interface;
  PIVector_1__WiFiDirect_IWiFiDirectInformationElement = ^IVector_1__WiFiDirect_IWiFiDirectInformationElement;

  // Windows.Devices.WiFiDirect.IWiFiDirectLegacySettings
  WiFiDirect_IWiFiDirectLegacySettings = interface;
  PWiFiDirect_IWiFiDirectLegacySettings = ^WiFiDirect_IWiFiDirectLegacySettings;

  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisement
  WiFiDirect_IWiFiDirectAdvertisement = interface;
  PWiFiDirect_IWiFiDirectAdvertisement = ^WiFiDirect_IWiFiDirectAdvertisement;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IIterator_1__WiFiDirect_WiFiDirectConfigurationMethod = interface;
  PIIterator_1__WiFiDirect_WiFiDirectConfigurationMethod = ^IIterator_1__WiFiDirect_WiFiDirectConfigurationMethod;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IIterable_1__WiFiDirect_WiFiDirectConfigurationMethod = interface;
  PIIterable_1__WiFiDirect_WiFiDirectConfigurationMethod = ^IIterable_1__WiFiDirect_WiFiDirectConfigurationMethod;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IVectorView_1__WiFiDirect_WiFiDirectConfigurationMethod = interface;
  PIVectorView_1__WiFiDirect_WiFiDirectConfigurationMethod = ^IVectorView_1__WiFiDirect_WiFiDirectConfigurationMethod;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IVector_1__WiFiDirect_WiFiDirectConfigurationMethod = interface;
  PIVector_1__WiFiDirect_WiFiDirectConfigurationMethod = ^IVector_1__WiFiDirect_WiFiDirectConfigurationMethod;

  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisement2
  WiFiDirect_IWiFiDirectAdvertisement2 = interface;
  PWiFiDirect_IWiFiDirectAdvertisement2 = ^WiFiDirect_IWiFiDirectAdvertisement2;

  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisherStatusChangedEventArgs
  WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = interface;
  PWiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = ^WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisher,Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisherStatusChangedEventArgs>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectAdvertisementPublisher__WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_IWiFiDirectAdvertisementPublisher__WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = ^TypedEventHandler_2__WiFiDirect_IWiFiDirectAdvertisementPublisher__WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs;

  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisher
  WiFiDirect_IWiFiDirectAdvertisementPublisher = interface;
  PWiFiDirect_IWiFiDirectAdvertisementPublisher = ^WiFiDirect_IWiFiDirectAdvertisementPublisher;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequest
  WiFiDirect_IWiFiDirectConnectionRequest = interface;
  PWiFiDirect_IWiFiDirectConnectionRequest = ^WiFiDirect_IWiFiDirectConnectionRequest;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequestedEventArgs
  WiFiDirect_IWiFiDirectConnectionRequestedEventArgs = interface;
  PWiFiDirect_IWiFiDirectConnectionRequestedEventArgs = ^WiFiDirect_IWiFiDirectConnectionRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectConnectionListener,Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequestedEventArgs>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectConnectionListener__WiFiDirect_IWiFiDirectConnectionRequestedEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_IWiFiDirectConnectionListener__WiFiDirect_IWiFiDirectConnectionRequestedEventArgs = ^TypedEventHandler_2__WiFiDirect_IWiFiDirectConnectionListener__WiFiDirect_IWiFiDirectConnectionRequestedEventArgs;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionListener
  WiFiDirect_IWiFiDirectConnectionListener = interface;
  PWiFiDirect_IWiFiDirectConnectionListener = ^WiFiDirect_IWiFiDirectConnectionListener;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters
  WiFiDirect_IWiFiDirectConnectionParameters = interface;
  PWiFiDirect_IWiFiDirectConnectionParameters = ^WiFiDirect_IWiFiDirectConnectionParameters;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters2
  WiFiDirect_IWiFiDirectConnectionParameters2 = interface;
  PWiFiDirect_IWiFiDirectConnectionParameters2 = ^WiFiDirect_IWiFiDirectConnectionParameters2;

  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParametersStatics
  WiFiDirect_IWiFiDirectConnectionParametersStatics = interface;
  PWiFiDirect_IWiFiDirectConnectionParametersStatics = ^WiFiDirect_IWiFiDirectConnectionParametersStatics;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectDevice,Object>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectDevice__IInspectable = interface;
  PTypedEventHandler_2__WiFiDirect_IWiFiDirectDevice__IInspectable = ^TypedEventHandler_2__WiFiDirect_IWiFiDirectDevice__IInspectable;

  // Windows.Devices.WiFiDirect.IWiFiDirectDevice
  WiFiDirect_IWiFiDirectDevice = interface;
  PWiFiDirect_IWiFiDirectDevice = ^WiFiDirect_IWiFiDirectDevice;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.IWiFiDirectDevice>
  AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice = interface;
  PAsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice = ^AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.IWiFiDirectDevice>
  IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice = interface;
  PIAsyncOperation_1__WiFiDirect_IWiFiDirectDevice = ^IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice;

  // Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics
  WiFiDirect_IWiFiDirectDeviceStatics = interface;
  PWiFiDirect_IWiFiDirectDeviceStatics = ^WiFiDirect_IWiFiDirectDeviceStatics;

  // Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics2
  WiFiDirect_IWiFiDirectDeviceStatics2 = interface;
  PWiFiDirect_IWiFiDirectDeviceStatics2 = ^WiFiDirect_IWiFiDirectDeviceStatics2;

  // Windows.Devices.WiFiDirect.IWiFiDirectInformationElementStatics
  WiFiDirect_IWiFiDirectInformationElementStatics = interface;
  PWiFiDirect_IWiFiDirectInformationElementStatics = ^WiFiDirect_IWiFiDirectInformationElementStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IIterator_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface;
  PIIterator_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = ^IIterator_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IIterable_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface;
  PIIterable_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = ^IIterable_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface;
  PIVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = ^IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionDeferredEventArgs
  WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = interface;
  PWiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = ^WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectService,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionDeferredEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectService__WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectService__WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectService__WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo
  WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface;
  PWiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = ^WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface;
  PAsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = ^AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface;
  PIAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = ^IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession,Object>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__IInspectable = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__IInspectable = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__IInspectable;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceRemotePortAddedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = interface;
  PWiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = ^WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceRemotePortAddedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession
  WiFiDirect_Services_IWiFiDirectServiceSession = interface;
  PWiFiDirect_Services_IWiFiDirectServiceSession = ^WiFiDirect_Services_IWiFiDirectServiceSession;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession = interface;
  PAsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession = ^AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession = interface;
  PIAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession = ^IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectService
  WiFiDirect_Services_IWiFiDirectService = interface;
  PWiFiDirect_Services_IWiFiDirectService = ^WiFiDirect_Services_IWiFiDirectService;

  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface;
  PIVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = ^IVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequest
  WiFiDirect_Services_IWiFiDirectServiceSessionRequest = interface;
  PWiFiDirect_Services_IWiFiDirectServiceSessionRequest = ^WiFiDirect_Services_IWiFiDirectServiceSessionRequest;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequestedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = interface;
  PWiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = ^WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequestedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = interface;
  PWiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = ^WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs;

  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Object>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__IInspectable = interface;
  PTypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__IInspectable = ^TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__IInspectable;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser
  WiFiDirect_Services_IWiFiDirectServiceAdvertiser = interface;
  PWiFiDirect_Services_IWiFiDirectServiceAdvertiser = ^WiFiDirect_Services_IWiFiDirectServiceAdvertiser;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiserFactory
  WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory = interface;
  PWiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory = ^WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectService>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService = interface;
  PAsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService = ^AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectService>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService = interface;
  PIAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService = ^IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService;

  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceStatics
  WiFiDirect_Services_IWiFiDirectServiceStatics = interface;
  PWiFiDirect_Services_IWiFiDirectServiceStatics = ^WiFiDirect_Services_IWiFiDirectServiceStatics;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.ISimpleHapticsController>
  IIterator_1__Haptics_ISimpleHapticsController = interface;
  PIIterator_1__Haptics_ISimpleHapticsController = ^IIterator_1__Haptics_ISimpleHapticsController;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.ISimpleHapticsController>
  IIterable_1__Haptics_ISimpleHapticsController = interface;
  PIIterable_1__Haptics_ISimpleHapticsController = ^IIterable_1__Haptics_ISimpleHapticsController;

  // Windows.Devices Enums

  // Windows.Devices.Adc.AdcChannelMode
  Adc_AdcChannelMode = (
    SingleEnded = 0,
    Differential = 1
  );
  PAdc_AdcChannelMode = ^Adc_AdcChannelMode;

  // Windows.Devices.Adc.Provider.ProviderAdcChannelMode
  Adc_Provider_ProviderAdcChannelMode = (
    SingleEnded = 0,
    Differential = 1
  );
  PAdc_Provider_ProviderAdcChannelMode = ^Adc_Provider_ProviderAdcChannelMode;

  // Windows.Devices.Custom.DeviceAccessMode
  Custom_DeviceAccessMode = (
    Read = 0,
    Write = 1,
    ReadWrite = 2
  );
  PCustom_DeviceAccessMode = ^Custom_DeviceAccessMode;

  // Windows.Devices.Custom.DeviceSharingMode
  Custom_DeviceSharingMode = (
    Shared = 0,
    Exclusive = 1
  );
  PCustom_DeviceSharingMode = ^Custom_DeviceSharingMode;

  // Windows.Devices.Custom.IOControlAccessMode
  Custom_IOControlAccessMode = (
    Any = 0,
    Read = 1,
    Write = 2,
    ReadWrite = 3
  );
  PCustom_IOControlAccessMode = ^Custom_IOControlAccessMode;

  // Windows.Devices.Custom.IOControlBufferingMethod
  Custom_IOControlBufferingMethod = (
    Buffered = 0,
    DirectInput = 1,
    DirectOutput = 2,
    Neither = 3
  );
  PCustom_IOControlBufferingMethod = ^Custom_IOControlBufferingMethod;

  // Windows.Devices.Display.Core.DisplayBitsPerChannel
  Display_Core_DisplayBitsPerChannel = (
    None = 0,
    Bpc6 = 1,
    Bpc8 = 2,
    Bpc10 = 4,
    Bpc12 = 8,
    Bpc14 = 16,
    Bpc16 = 32
  );
  PDisplay_Core_DisplayBitsPerChannel = ^Display_Core_DisplayBitsPerChannel;

  // Windows.Devices.Display.Core.DisplayDeviceCapability
  Display_Core_DisplayDeviceCapability = (
    FlipOverride = 0
  );
  PDisplay_Core_DisplayDeviceCapability = ^Display_Core_DisplayDeviceCapability;

  // Windows.Devices.Display.Core.DisplayManagerOptions
  Display_Core_DisplayManagerOptions = (
    None = 0,
    EnforceSourceOwnership = 1,
    VirtualRefreshRateAware = 2
  );
  PDisplay_Core_DisplayManagerOptions = ^Display_Core_DisplayManagerOptions;

  // Windows.Devices.Display.Core.DisplayManagerResult
  Display_Core_DisplayManagerResult = (
    Success = 0,
    UnknownFailure = 1,
    TargetAccessDenied = 2,
    TargetStale = 3,
    RemoteSessionNotSupported = 4
  );
  PDisplay_Core_DisplayManagerResult = ^Display_Core_DisplayManagerResult;

  // Windows.Devices.Display.Core.DisplayModeQueryOptions
  Display_Core_DisplayModeQueryOptions = (
    None = 0,
    OnlyPreferredResolution = 1
  );
  PDisplay_Core_DisplayModeQueryOptions = ^Display_Core_DisplayModeQueryOptions;

  // Windows.Devices.Display.Core.DisplayPathScaling
  Display_Core_DisplayPathScaling = (
    Identity = 0,
    Centered = 1,
    Stretched = 2,
    AspectRatioStretched = 3,
    Custom = 4,
    DriverPreferred = 5
  );
  PDisplay_Core_DisplayPathScaling = ^Display_Core_DisplayPathScaling;

  // Windows.Devices.Display.Core.DisplayPathStatus
  Display_Core_DisplayPathStatus = (
    Unknown = 0,
    Succeeded = 1,
    Pending = 2,
    Failed = 3,
    FailedAsync = 4,
    InvalidatedAsync = 5
  );
  PDisplay_Core_DisplayPathStatus = ^Display_Core_DisplayPathStatus;

  // Windows.Devices.Display.Core.DisplayPresentStatus
  Display_Core_DisplayPresentStatus = (
    Success = 0,
    SourceStatusPreventedPresent = 1,
    ScanoutInvalid = 2,
    SourceInvalid = 3,
    DeviceInvalid = 4,
    UnknownFailure = 5
  );
  PDisplay_Core_DisplayPresentStatus = ^Display_Core_DisplayPresentStatus;

  // Windows.Devices.Display.Core.DisplayRotation
  Display_Core_DisplayRotation = (
    None = 0,
    Clockwise90Degrees = 1,
    Clockwise180Degrees = 2,
    Clockwise270Degrees = 3
  );
  PDisplay_Core_DisplayRotation = ^Display_Core_DisplayRotation;

  // Windows.Devices.Display.Core.DisplayScanoutOptions
  Display_Core_DisplayScanoutOptions = (
    None = 0,
    AllowTearing = 2
  );
  PDisplay_Core_DisplayScanoutOptions = ^Display_Core_DisplayScanoutOptions;

  // Windows.Devices.Display.Core.DisplaySourceStatus
  Display_Core_DisplaySourceStatus = (
    Active = 0,
    PoweredOff = 1,
    Invalid = 2,
    OwnedByAnotherDevice = 3,
    Unowned = 4
  );
  PDisplay_Core_DisplaySourceStatus = ^Display_Core_DisplaySourceStatus;

  // Windows.Devices.Display.Core.DisplayStateApplyOptions
  Display_Core_DisplayStateApplyOptions = (
    None = 0,
    FailIfStateChanged = 1,
    ForceReapply = 2,
    ForceModeEnumeration = 4
  );
  PDisplay_Core_DisplayStateApplyOptions = ^Display_Core_DisplayStateApplyOptions;

  // Windows.Devices.Display.Core.DisplayStateFunctionalizeOptions
  Display_Core_DisplayStateFunctionalizeOptions = (
    None = 0,
    FailIfStateChanged = 1,
    ValidateTopologyOnly = 2
  );
  PDisplay_Core_DisplayStateFunctionalizeOptions = ^Display_Core_DisplayStateFunctionalizeOptions;

  // Windows.Devices.Display.Core.DisplayStateOperationStatus
  Display_Core_DisplayStateOperationStatus = (
    Success = 0,
    PartialFailure = 1,
    UnknownFailure = 2,
    TargetOwnershipLost = 3,
    SystemStateChanged = 4,
    TooManyPathsForAdapter = 5,
    ModesNotSupported = 6,
    RemoteSessionNotSupported = 7
  );
  PDisplay_Core_DisplayStateOperationStatus = ^Display_Core_DisplayStateOperationStatus;

  // Windows.Devices.Display.Core.DisplayTargetPersistence
  Display_Core_DisplayTargetPersistence = (
    None = 0,
    BootPersisted = 1,
    TemporaryPersisted = 2,
    PathPersisted = 3
  );
  PDisplay_Core_DisplayTargetPersistence = ^Display_Core_DisplayTargetPersistence;

  // Windows.Devices.Display.Core.DisplayTaskSignalKind
  Display_Core_DisplayTaskSignalKind = (
    OnPresentFlipAway = 0,
    OnPresentFlipTo = 1
  );
  PDisplay_Core_DisplayTaskSignalKind = ^Display_Core_DisplayTaskSignalKind;

  // Windows.Devices.Display.Core.DisplayWireFormatColorSpace
  Display_Core_DisplayWireFormatColorSpace = (
    BT709 = 0,
    BT2020 = 1,
    ProfileDefinedWideColorGamut = 2
  );
  PDisplay_Core_DisplayWireFormatColorSpace = ^Display_Core_DisplayWireFormatColorSpace;

  // Windows.Devices.Display.Core.DisplayWireFormatEotf
  Display_Core_DisplayWireFormatEotf = (
    Sdr = 0,
    HdrSmpte2084 = 1
  );
  PDisplay_Core_DisplayWireFormatEotf = ^Display_Core_DisplayWireFormatEotf;

  // Windows.Devices.Display.Core.DisplayWireFormatHdrMetadata
  Display_Core_DisplayWireFormatHdrMetadata = (
    None = 0,
    Hdr10 = 1,
    Hdr10Plus = 2,
    DolbyVisionLowLatency = 3
  );
  PDisplay_Core_DisplayWireFormatHdrMetadata = ^Display_Core_DisplayWireFormatHdrMetadata;

  // Windows.Devices.Display.Core.DisplayWireFormatPixelEncoding
  Display_Core_DisplayWireFormatPixelEncoding = (
    Rgb444 = 0,
    Ycc444 = 1,
    Ycc422 = 2,
    Ycc420 = 3,
    Intensity = 4
  );
  PDisplay_Core_DisplayWireFormatPixelEncoding = ^Display_Core_DisplayWireFormatPixelEncoding;

  // Windows.Devices.Display.DisplayMonitorConnectionKind
  Display_DisplayMonitorConnectionKind = (
    Internal = 0,
    Wired = 1,
    Wireless = 2,
    &Virtual = 3
  );
  PDisplay_DisplayMonitorConnectionKind = ^Display_DisplayMonitorConnectionKind;

  // Windows.Devices.Display.DisplayMonitorDescriptorKind
  Display_DisplayMonitorDescriptorKind = (
    Edid = 0,
    DisplayId = 1
  );
  PDisplay_DisplayMonitorDescriptorKind = ^Display_DisplayMonitorDescriptorKind;

  // Windows.Devices.Display.DisplayMonitorPhysicalConnectorKind
  Display_DisplayMonitorPhysicalConnectorKind = (
    Unknown = 0,
    HD15 = 1,
    AnalogTV = 2,
    Dvi = 3,
    Hdmi = 4,
    Lvds = 5,
    Sdi = 6,
    DisplayPort = 7
  );
  PDisplay_DisplayMonitorPhysicalConnectorKind = ^Display_DisplayMonitorPhysicalConnectorKind;

  // Windows.Devices.Display.DisplayMonitorUsageKind
  Display_DisplayMonitorUsageKind = (
    Standard = 0,
    HeadMounted = 1,
    SpecialPurpose = 2
  );
  PDisplay_DisplayMonitorUsageKind = ^Display_DisplayMonitorUsageKind;

  // Windows.Devices.Gpio.GpioChangePolarity
  Gpio_GpioChangePolarity = (
    Falling = 0,
    Rising = 1,
    Both = 2
  );
  PGpio_GpioChangePolarity = ^Gpio_GpioChangePolarity;

  // Windows.Devices.Gpio.GpioOpenStatus
  Gpio_GpioOpenStatus = (
    PinOpened = 0,
    PinUnavailable = 1,
    SharingViolation = 2,
    MuxingConflict = 3,
    UnknownError = 4
  );
  PGpio_GpioOpenStatus = ^Gpio_GpioOpenStatus;

  // Windows.Devices.Gpio.GpioPinDriveMode
  Gpio_GpioPinDriveMode = (
    Input = 0,
    Output = 1,
    InputPullUp = 2,
    InputPullDown = 3,
    OutputOpenDrain = 4,
    OutputOpenDrainPullUp = 5,
    OutputOpenSource = 6,
    OutputOpenSourcePullDown = 7
  );
  PGpio_GpioPinDriveMode = ^Gpio_GpioPinDriveMode;

  // Windows.Devices.Gpio.GpioPinEdge
  Gpio_GpioPinEdge = (
    FallingEdge = 0,
    RisingEdge = 1
  );
  PGpio_GpioPinEdge = ^Gpio_GpioPinEdge;

  // Windows.Devices.Gpio.GpioPinValue
  Gpio_GpioPinValue = (
    Low = 0,
    High = 1
  );
  PGpio_GpioPinValue = ^Gpio_GpioPinValue;

  // Windows.Devices.Gpio.GpioSharingMode
  Gpio_GpioSharingMode = (
    Exclusive = 0,
    SharedReadOnly = 1
  );
  PGpio_GpioSharingMode = ^Gpio_GpioSharingMode;

  // Windows.Devices.Gpio.Provider.ProviderGpioPinDriveMode
  Gpio_Provider_ProviderGpioPinDriveMode = (
    Input = 0,
    Output = 1,
    InputPullUp = 2,
    InputPullDown = 3,
    OutputOpenDrain = 4,
    OutputOpenDrainPullUp = 5,
    OutputOpenSource = 6,
    OutputOpenSourcePullDown = 7
  );
  PGpio_Provider_ProviderGpioPinDriveMode = ^Gpio_Provider_ProviderGpioPinDriveMode;

  // Windows.Devices.Gpio.Provider.ProviderGpioPinEdge
  Gpio_Provider_ProviderGpioPinEdge = (
    FallingEdge = 0,
    RisingEdge = 1
  );
  PGpio_Provider_ProviderGpioPinEdge = ^Gpio_Provider_ProviderGpioPinEdge;

  // Windows.Devices.Gpio.Provider.ProviderGpioPinValue
  Gpio_Provider_ProviderGpioPinValue = (
    Low = 0,
    High = 1
  );
  PGpio_Provider_ProviderGpioPinValue = ^Gpio_Provider_ProviderGpioPinValue;

  // Windows.Devices.Gpio.Provider.ProviderGpioSharingMode
  Gpio_Provider_ProviderGpioSharingMode = (
    Exclusive = 0,
    SharedReadOnly = 1
  );
  PGpio_Provider_ProviderGpioSharingMode = ^Gpio_Provider_ProviderGpioSharingMode;

  // Windows.Devices.Haptics.VibrationAccessStatus
  Haptics_VibrationAccessStatus = (
    Allowed = 0,
    DeniedByUser = 1,
    DeniedBySystem = 2,
    DeniedByEnergySaver = 3
  );
  PHaptics_VibrationAccessStatus = ^Haptics_VibrationAccessStatus;

  // Windows.Devices.HumanInterfaceDevice.HidCollectionType
  HumanInterfaceDevice_HidCollectionType = (
    Physical = 0,
    Application = 1,
    Logical = 2,
    Report = 3,
    NamedArray = 4,
    UsageSwitch = 5,
    UsageModifier = 6,
    Other = 7
  );
  PHumanInterfaceDevice_HidCollectionType = ^HumanInterfaceDevice_HidCollectionType;

  // Windows.Devices.HumanInterfaceDevice.HidReportType
  HumanInterfaceDevice_HidReportType = (
    Input = 0,
    Output = 1,
    Feature = 2
  );
  PHumanInterfaceDevice_HidReportType = ^HumanInterfaceDevice_HidReportType;

  // Windows.Devices.I2c.I2cBusSpeed
  I2c_I2cBusSpeed = (
    StandardMode = 0,
    FastMode = 1
  );
  PI2c_I2cBusSpeed = ^I2c_I2cBusSpeed;

  // Windows.Devices.I2c.I2cSharingMode
  I2c_I2cSharingMode = (
    Exclusive = 0,
    Shared = 1
  );
  PI2c_I2cSharingMode = ^I2c_I2cSharingMode;

  // Windows.Devices.I2c.I2cTransferStatus
  I2c_I2cTransferStatus = (
    FullTransfer = 0,
    PartialTransfer = 1,
    SlaveAddressNotAcknowledged = 2,
    ClockStretchTimeout = 3,
    UnknownError = 4
  );
  PI2c_I2cTransferStatus = ^I2c_I2cTransferStatus;

  // Windows.Devices.I2c.Provider.ProviderI2cBusSpeed
  I2c_Provider_ProviderI2cBusSpeed = (
    StandardMode = 0,
    FastMode = 1
  );
  PI2c_Provider_ProviderI2cBusSpeed = ^I2c_Provider_ProviderI2cBusSpeed;

  // Windows.Devices.I2c.Provider.ProviderI2cSharingMode
  I2c_Provider_ProviderI2cSharingMode = (
    Exclusive = 0,
    Shared = 1
  );
  PI2c_Provider_ProviderI2cSharingMode = ^I2c_Provider_ProviderI2cSharingMode;

  // Windows.Devices.I2c.Provider.ProviderI2cTransferStatus
  I2c_Provider_ProviderI2cTransferStatus = (
    FullTransfer = 0,
    PartialTransfer = 1,
    SlaveAddressNotAcknowledged = 2
  );
  PI2c_Provider_ProviderI2cTransferStatus = ^I2c_Provider_ProviderI2cTransferStatus;

  // Windows.Devices.Input.Preview.GazeDeviceConfigurationStatePreview
  Input_Preview_GazeDeviceConfigurationStatePreview = (
    Unknown = 0,
    Ready = 1,
    Configuring = 2,
    ScreenSetupNeeded = 3,
    UserCalibrationNeeded = 4
  );
  PInput_Preview_GazeDeviceConfigurationStatePreview = ^Input_Preview_GazeDeviceConfigurationStatePreview;

  // Windows.Devices.Lights.Effects.LampArrayEffectCompletionBehavior
  Lights_Effects_LampArrayEffectCompletionBehavior = (
    ClearState = 0,
    KeepState = 1
  );
  PLights_Effects_LampArrayEffectCompletionBehavior = ^Lights_Effects_LampArrayEffectCompletionBehavior;

  // Windows.Devices.Lights.Effects.LampArrayEffectStartMode
  Lights_Effects_LampArrayEffectStartMode = (
    Sequential = 0,
    Simultaneous = 1
  );
  PLights_Effects_LampArrayEffectStartMode = ^Lights_Effects_LampArrayEffectStartMode;

  // Windows.Devices.Lights.Effects.LampArrayRepetitionMode
  Lights_Effects_LampArrayRepetitionMode = (
    Occurrences = 0,
    Forever = 1
  );
  PLights_Effects_LampArrayRepetitionMode = ^Lights_Effects_LampArrayRepetitionMode;

  // Windows.Devices.Lights.LampArrayKind
  Lights_LampArrayKind = (
    Undefined = 0,
    Keyboard = 1,
    Mouse = 2,
    GameController = 3,
    Peripheral = 4,
    Scene = 5,
    Notification = 6,
    Chassis = 7,
    Wearable = 8,
    Furniture = 9,
    Art = 10,
    Headset = 11,
    Microphone = 12,
    Speaker = 13
  );
  PLights_LampArrayKind = ^Lights_LampArrayKind;

  // Windows.Devices.Lights.LampPurposes
  Lights_LampPurposes = (
    Undefined = 0,
    Control = 1,
    Accent = 2,
    Branding = 4,
    Status = 8,
    Illumination = 16,
    Presentation = 32
  );
  PLights_LampPurposes = ^Lights_LampPurposes;

  // Windows.Devices.Perception.PerceptionFrameSourceAccessStatus
  Perception_PerceptionFrameSourceAccessStatus = (
    Unspecified = 0,
    Allowed = 1,
    DeniedByUser = 2,
    DeniedBySystem = 3
  );
  PPerception_PerceptionFrameSourceAccessStatus = ^Perception_PerceptionFrameSourceAccessStatus;

  // Windows.Devices.Perception.PerceptionFrameSourcePropertyChangeStatus
  Perception_PerceptionFrameSourcePropertyChangeStatus = (
    Unknown = 0,
    Accepted = 1,
    LostControl = 2,
    PropertyNotSupported = 3,
    PropertyReadOnly = 4,
    ValueOutOfRange = 5
  );
  PPerception_PerceptionFrameSourcePropertyChangeStatus = ^Perception_PerceptionFrameSourcePropertyChangeStatus;

  // Windows.Devices.Portable.ServiceDeviceType
  Portable_ServiceDeviceType = (
    CalendarService = 0,
    ContactsService = 1,
    DeviceStatusService = 2,
    NotesService = 3,
    RingtonesService = 4,
    SmsService = 5,
    TasksService = 6
  );
  PPortable_ServiceDeviceType = ^Portable_ServiceDeviceType;

  // Windows.Devices.Printers.Extensions.Print3DWorkflowDetail
  Printers_Extensions_Print3DWorkflowDetail = (
    Unknown = 0,
    ModelExceedsPrintBed = 1,
    UploadFailed = 2,
    InvalidMaterialSelection = 3,
    InvalidModel = 4,
    ModelNotManifold = 5,
    InvalidPrintTicket = 6
  );
  PPrinters_Extensions_Print3DWorkflowDetail = ^Printers_Extensions_Print3DWorkflowDetail;

  // Windows.Devices.Printers.Extensions.Print3DWorkflowStatus
  Printers_Extensions_Print3DWorkflowStatus = (
    Abandoned = 0,
    Canceled = 1,
    Failed = 2,
    Slicing = 3,
    Submitted = 4
  );
  PPrinters_Extensions_Print3DWorkflowStatus = ^Printers_Extensions_Print3DWorkflowStatus;

  // Windows.Devices.Printers.IppAttributeErrorReason
  Printers_IppAttributeErrorReason = (
    RequestEntityTooLarge = 0,
    AttributeNotSupported = 1,
    AttributeValuesNotSupported = 2,
    AttributeNotSettable = 3,
    ConflictingAttributes = 4
  );
  PPrinters_IppAttributeErrorReason = ^Printers_IppAttributeErrorReason;

  // Windows.Devices.Printers.IppAttributeValueKind
  Printers_IppAttributeValueKind = (
    Unsupported = 0,
    Unknown = 1,
    NoValue = 2,
    Integer = 3,
    Boolean = 4,
    Enum = 5,
    OctetString = 6,
    DateTime = 7,
    Resolution = 8,
    RangeOfInteger = 9,
    Collection = 10,
    TextWithLanguage = 11,
    NameWithLanguage = 12,
    TextWithoutLanguage = 13,
    NameWithoutLanguage = 14,
    Keyword = 15,
    Uri = 16,
    UriSchema = 17,
    Charset = 18,
    NaturalLanguage = 19,
    MimeMediaType = 20
  );
  PPrinters_IppAttributeValueKind = ^Printers_IppAttributeValueKind;

  // Windows.Devices.Printers.IppPrintDeviceKind
  Printers_IppPrintDeviceKind = (
    Printer = 0,
    FaxOut = 1,
    VirtualPrinter = 2
  );
  PPrinters_IppPrintDeviceKind = ^Printers_IppPrintDeviceKind;

  // Windows.Devices.Printers.IppResolutionUnit
  Printers_IppResolutionUnit = (
    DotsPerInch = 0,
    DotsPerCentimeter = 1
  );
  PPrinters_IppResolutionUnit = ^Printers_IppResolutionUnit;

  // Windows.Devices.Printers.PageConfigurationSource
  Printers_PageConfigurationSource = (
    PrintJobConfiguration = 0,
    PdlContent = 1
  );
  PPrinters_PageConfigurationSource = ^Printers_PageConfigurationSource;

  // Windows.Devices.Printers.VirtualPrinterInstallationStatus
  Printers_VirtualPrinterInstallationStatus = (
    InstallationSucceeded = 0,
    PrinterAlreadyInstalled = 1,
    PrinterInstallationAccessDenied = 2,
    PrinterInstallationFailed = 3
  );
  PPrinters_VirtualPrinterInstallationStatus = ^Printers_VirtualPrinterInstallationStatus;

  // Windows.Devices.Printers.VirtualPrinterPreferredInputFormat
  Printers_VirtualPrinterPreferredInputFormat = (
    OpenXps = 0,
    PostScript = 1
  );
  PPrinters_VirtualPrinterPreferredInputFormat = ^Printers_VirtualPrinterPreferredInputFormat;

  // Windows.Devices.Pwm.PwmPulsePolarity
  Pwm_PwmPulsePolarity = (
    ActiveHigh = 0,
    ActiveLow = 1
  );
  PPwm_PwmPulsePolarity = ^Pwm_PwmPulsePolarity;

  // Windows.Devices.Radios.RadioAccessStatus
  Radios_RadioAccessStatus = (
    Unspecified = 0,
    Allowed = 1,
    DeniedByUser = 2,
    DeniedBySystem = 3
  );
  PRadios_RadioAccessStatus = ^Radios_RadioAccessStatus;

  // Windows.Devices.Radios.RadioKind
  Radios_RadioKind = (
    Other = 0,
    WiFi = 1,
    MobileBroadband = 2,
    Bluetooth = 3,
    FM = 4
  );
  PRadios_RadioKind = ^Radios_RadioKind;

  // Windows.Devices.Radios.RadioState
  Radios_RadioState = (
    Unknown = 0,
    &On = 1,
    Off = 2,
    Disabled = 3
  );
  PRadios_RadioState = ^Radios_RadioState;

  // Windows.Devices.SerialCommunication.SerialError
  SerialCommunication_SerialError = (
    Frame = 0,
    BufferOverrun = 1,
    ReceiveFull = 2,
    ReceiveParity = 3,
    TransmitFull = 4
  );
  PSerialCommunication_SerialError = ^SerialCommunication_SerialError;

  // Windows.Devices.SerialCommunication.SerialHandshake
  SerialCommunication_SerialHandshake = (
    None = 0,
    RequestToSend = 1,
    XOnXOff = 2,
    RequestToSendXOnXOff = 3
  );
  PSerialCommunication_SerialHandshake = ^SerialCommunication_SerialHandshake;

  // Windows.Devices.SerialCommunication.SerialParity
  SerialCommunication_SerialParity = (
    None = 0,
    Odd = 1,
    Even = 2,
    Mark = 3,
    Space = 4
  );
  PSerialCommunication_SerialParity = ^SerialCommunication_SerialParity;

  // Windows.Devices.SerialCommunication.SerialPinChange
  SerialCommunication_SerialPinChange = (
    BreakSignal = 0,
    CarrierDetect = 1,
    ClearToSend = 2,
    DataSetReady = 3,
    RingIndicator = 4
  );
  PSerialCommunication_SerialPinChange = ^SerialCommunication_SerialPinChange;

  // Windows.Devices.SerialCommunication.SerialStopBitCount
  SerialCommunication_SerialStopBitCount = (
    One = 0,
    OnePointFive = 1,
    Two = 2
  );
  PSerialCommunication_SerialStopBitCount = ^SerialCommunication_SerialStopBitCount;

  // Windows.Devices.SmartCards.SmartCardActivationPolicyChangeResult
  SmartCards_SmartCardActivationPolicyChangeResult = (
    Denied = 0,
    Allowed = 1
  );
  PSmartCards_SmartCardActivationPolicyChangeResult = ^SmartCards_SmartCardActivationPolicyChangeResult;

  // Windows.Devices.SmartCards.SmartCardAppletIdGroupActivationPolicy
  SmartCards_SmartCardAppletIdGroupActivationPolicy = (
    Disabled = 0,
    ForegroundOverride = 1,
    Enabled = 2
  );
  PSmartCards_SmartCardAppletIdGroupActivationPolicy = ^SmartCards_SmartCardAppletIdGroupActivationPolicy;

  // Windows.Devices.SmartCards.SmartCardAutomaticResponseStatus
  SmartCards_SmartCardAutomaticResponseStatus = (
    None = 0,
    Success = 1,
    UnknownError = 2
  );
  PSmartCards_SmartCardAutomaticResponseStatus = ^SmartCards_SmartCardAutomaticResponseStatus;

  // Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm
  SmartCards_SmartCardCryptogramAlgorithm = (
    None = 0,
    CbcMac = 1,
    Cvc3Umd = 2,
    DecimalizedMsd = 3,
    Cvc3MD = 4,
    Sha1 = 5,
    SignedDynamicApplicationData = 6,
    RsaPkcs1 = 7,
    Sha256Hmac = 8
  );
  PSmartCards_SmartCardCryptogramAlgorithm = ^SmartCards_SmartCardCryptogramAlgorithm;

  // Windows.Devices.SmartCards.SmartCardCryptogramGeneratorOperationStatus
  SmartCards_SmartCardCryptogramGeneratorOperationStatus = (
    Success = 0,
    AuthorizationFailed = 1,
    AuthorizationCanceled = 2,
    AuthorizationRequired = 3,
    CryptogramMaterialPackageStorageKeyExists = 4,
    NoCryptogramMaterialPackageStorageKey = 5,
    NoCryptogramMaterialPackage = 6,
    UnsupportedCryptogramMaterialPackage = 7,
    UnknownCryptogramMaterialName = 8,
    InvalidCryptogramMaterialUsage = 9,
    ApduResponseNotSent = 10,
    OtherError = 11,
    ValidationFailed = 12,
    NotSupported = 13
  );
  PSmartCards_SmartCardCryptogramGeneratorOperationStatus = ^SmartCards_SmartCardCryptogramGeneratorOperationStatus;

  // Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat
  SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = (
    None = 0,
    VisaHmac = 1
  );
  PSmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = ^SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat;

  // Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat
  SmartCards_SmartCardCryptogramMaterialPackageFormat = (
    None = 0,
    JweRsaPki = 1
  );
  PSmartCards_SmartCardCryptogramMaterialPackageFormat = ^SmartCards_SmartCardCryptogramMaterialPackageFormat;

  // Windows.Devices.SmartCards.SmartCardCryptogramMaterialProtectionMethod
  SmartCards_SmartCardCryptogramMaterialProtectionMethod = (
    None = 0,
    WhiteBoxing = 1
  );
  PSmartCards_SmartCardCryptogramMaterialProtectionMethod = ^SmartCards_SmartCardCryptogramMaterialProtectionMethod;

  // Windows.Devices.SmartCards.SmartCardCryptogramMaterialType
  SmartCards_SmartCardCryptogramMaterialType = (
    None = 0,
    StaticDataAuthentication = 1,
    TripleDes112 = 2,
    Aes = 3,
    RsaPkcs1 = 4
  );
  PSmartCards_SmartCardCryptogramMaterialType = ^SmartCards_SmartCardCryptogramMaterialType;

  // Windows.Devices.SmartCards.SmartCardCryptogramPlacementOptions
  SmartCards_SmartCardCryptogramPlacementOptions = (
    None = 0,
    UnitsAreInNibbles = 1,
    ChainOutput = 2
  );
  PSmartCards_SmartCardCryptogramPlacementOptions = ^SmartCards_SmartCardCryptogramPlacementOptions;

  // Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyAlgorithm
  SmartCards_SmartCardCryptogramStorageKeyAlgorithm = (
    None = 0,
    Rsa2048 = 1
  );
  PSmartCards_SmartCardCryptogramStorageKeyAlgorithm = ^SmartCards_SmartCardCryptogramStorageKeyAlgorithm;

  // Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities
  SmartCards_SmartCardCryptogramStorageKeyCapabilities = (
    None = 0,
    HardwareProtection = 1,
    UnlockPrompt = 2
  );
  PSmartCards_SmartCardCryptogramStorageKeyCapabilities = ^SmartCards_SmartCardCryptogramStorageKeyCapabilities;

  // Windows.Devices.SmartCards.SmartCardCryptographicKeyAttestationStatus
  SmartCards_SmartCardCryptographicKeyAttestationStatus = (
    NoAttestation = 0,
    SoftwareKeyWithoutTpm = 1,
    SoftwareKeyWithTpm = 2,
    TpmKeyUnknownAttestationStatus = 3,
    TpmKeyWithoutAttestationCapability = 4,
    TpmKeyWithTemporaryAttestationFailure = 5,
    TpmKeyWithLongTermAttestationFailure = 6,
    TpmKeyWithAttestation = 7
  );
  PSmartCards_SmartCardCryptographicKeyAttestationStatus = ^SmartCards_SmartCardCryptographicKeyAttestationStatus;

  // Windows.Devices.SmartCards.SmartCardEmulationCategory
  SmartCards_SmartCardEmulationCategory = (
    Other = 0,
    Payment = 1
  );
  PSmartCards_SmartCardEmulationCategory = ^SmartCards_SmartCardEmulationCategory;

  // Windows.Devices.SmartCards.SmartCardEmulationType
  SmartCards_SmartCardEmulationType = (
    Host = 0,
    Uicc = 1,
    EmbeddedSE = 2
  );
  PSmartCards_SmartCardEmulationType = ^SmartCards_SmartCardEmulationType;

  // Windows.Devices.SmartCards.SmartCardEmulatorConnectionDeactivatedReason
  SmartCards_SmartCardEmulatorConnectionDeactivatedReason = (
    ConnectionLost = 0,
    ConnectionRedirected = 1
  );
  PSmartCards_SmartCardEmulatorConnectionDeactivatedReason = ^SmartCards_SmartCardEmulatorConnectionDeactivatedReason;

  // Windows.Devices.SmartCards.SmartCardEmulatorConnectionSource
  SmartCards_SmartCardEmulatorConnectionSource = (
    Unknown = 0,
    NfcReader = 1
  );
  PSmartCards_SmartCardEmulatorConnectionSource = ^SmartCards_SmartCardEmulatorConnectionSource;

  // Windows.Devices.SmartCards.SmartCardEmulatorEnablementPolicy
  SmartCards_SmartCardEmulatorEnablementPolicy = (
    Never = 0,
    Always = 1,
    ScreenOn = 2,
    ScreenUnlocked = 3
  );
  PSmartCards_SmartCardEmulatorEnablementPolicy = ^SmartCards_SmartCardEmulatorEnablementPolicy;

  // Windows.Devices.SmartCards.SmartCardLaunchBehavior
  SmartCards_SmartCardLaunchBehavior = (
    Default = 0,
    AboveLock = 1
  );
  PSmartCards_SmartCardLaunchBehavior = ^SmartCards_SmartCardLaunchBehavior;

  // Windows.Devices.SmartCards.SmartCardPinCharacterPolicyOption
  SmartCards_SmartCardPinCharacterPolicyOption = (
    Allow = 0,
    RequireAtLeastOne = 1,
    Disallow = 2
  );
  PSmartCards_SmartCardPinCharacterPolicyOption = ^SmartCards_SmartCardPinCharacterPolicyOption;

  // Windows.Devices.SmartCards.SmartCardReaderKind
  SmartCards_SmartCardReaderKind = (
    Any = 0,
    Generic = 1,
    Tpm = 2,
    Nfc = 3,
    Uicc = 4,
    EmbeddedSE = 5
  );
  PSmartCards_SmartCardReaderKind = ^SmartCards_SmartCardReaderKind;

  // Windows.Devices.SmartCards.SmartCardReaderStatus
  SmartCards_SmartCardReaderStatus = (
    Disconnected = 0,
    Ready = 1,
    Exclusive = 2
  );
  PSmartCards_SmartCardReaderStatus = ^SmartCards_SmartCardReaderStatus;

  // Windows.Devices.SmartCards.SmartCardStatus
  SmartCards_SmartCardStatus = (
    Disconnected = 0,
    Ready = 1,
    Shared = 2,
    Exclusive = 3,
    Unresponsive = 4
  );
  PSmartCards_SmartCardStatus = ^SmartCards_SmartCardStatus;

  // Windows.Devices.SmartCards.SmartCardTriggerType
  SmartCards_SmartCardTriggerType = (
    EmulatorTransaction = 0,
    EmulatorNearFieldEntry = 1,
    EmulatorNearFieldExit = 2,
    EmulatorHostApplicationActivated = 3,
    EmulatorAppletIdGroupRegistrationChanged = 4,
    ReaderCardAdded = 5
  );
  PSmartCards_SmartCardTriggerType = ^SmartCards_SmartCardTriggerType;

  // Windows.Devices.SmartCards.SmartCardUnlockPromptingBehavior
  SmartCards_SmartCardUnlockPromptingBehavior = (
    AllowUnlockPrompt = 0,
    RequireUnlockPrompt = 1,
    PreventUnlockPrompt = 2
  );
  PSmartCards_SmartCardUnlockPromptingBehavior = ^SmartCards_SmartCardUnlockPromptingBehavior;

  // Windows.Devices.Spi.Provider.ProviderSpiMode
  Spi_Provider_ProviderSpiMode = (
    Mode0 = 0,
    Mode1 = 1,
    Mode2 = 2,
    Mode3 = 3
  );
  PSpi_Provider_ProviderSpiMode = ^Spi_Provider_ProviderSpiMode;

  // Windows.Devices.Spi.Provider.ProviderSpiSharingMode
  Spi_Provider_ProviderSpiSharingMode = (
    Exclusive = 0,
    Shared = 1
  );
  PSpi_Provider_ProviderSpiSharingMode = ^Spi_Provider_ProviderSpiSharingMode;

  // Windows.Devices.Spi.SpiMode
  Spi_SpiMode = (
    Mode0 = 0,
    Mode1 = 1,
    Mode2 = 2,
    Mode3 = 3
  );
  PSpi_SpiMode = ^Spi_SpiMode;

  // Windows.Devices.Spi.SpiSharingMode
  Spi_SpiSharingMode = (
    Exclusive = 0,
    Shared = 1
  );
  PSpi_SpiSharingMode = ^Spi_SpiSharingMode;

  // Windows.Devices.Usb.UsbControlRecipient
  Usb_UsbControlRecipient = (
    Device = 0,
    SpecifiedInterface = 1,
    Endpoint = 2,
    Other = 3,
    DefaultInterface = 4
  );
  PUsb_UsbControlRecipient = ^Usb_UsbControlRecipient;

  // Windows.Devices.Usb.UsbControlTransferType
  Usb_UsbControlTransferType = (
    Standard = 0,
    &Class = 1,
    Vendor = 2
  );
  PUsb_UsbControlTransferType = ^Usb_UsbControlTransferType;

  // Windows.Devices.Usb.UsbEndpointType
  Usb_UsbEndpointType = (
    Control = 0,
    Isochronous = 1,
    Bulk = 2,
    Interrupt = 3
  );
  PUsb_UsbEndpointType = ^Usb_UsbEndpointType;

  // Windows.Devices.Usb.UsbReadOptions
  Usb_UsbReadOptions = (
    None = 0,
    AutoClearStall = 1,
    OverrideAutomaticBufferManagement = 2,
    IgnoreShortPacket = 4,
    AllowPartialReads = 8
  );
  PUsb_UsbReadOptions = ^Usb_UsbReadOptions;

  // Windows.Devices.Usb.UsbTransferDirection
  Usb_UsbTransferDirection = (
    &Out = 0,
    &In = 1
  );
  PUsb_UsbTransferDirection = ^Usb_UsbTransferDirection;

  // Windows.Devices.Usb.UsbWriteOptions
  Usb_UsbWriteOptions = (
    None = 0,
    AutoClearStall = 1,
    ShortPacketTerminate = 2
  );
  PUsb_UsbWriteOptions = ^Usb_UsbWriteOptions;

  // Windows.Devices.WiFi.WiFiAccessStatus
  WiFi_WiFiAccessStatus = (
    Unspecified = 0,
    Allowed = 1,
    DeniedByUser = 2,
    DeniedBySystem = 3
  );
  PWiFi_WiFiAccessStatus = ^WiFi_WiFiAccessStatus;

  // Windows.Devices.WiFi.WiFiConnectionMethod
  WiFi_WiFiConnectionMethod = (
    Default = 0,
    WpsPin = 1,
    WpsPushButton = 2
  );
  PWiFi_WiFiConnectionMethod = ^WiFi_WiFiConnectionMethod;

  // Windows.Devices.WiFi.WiFiConnectionStatus
  WiFi_WiFiConnectionStatus = (
    UnspecifiedFailure = 0,
    Success = 1,
    AccessRevoked = 2,
    InvalidCredential = 3,
    NetworkNotAvailable = 4,
    Timeout = 5,
    UnsupportedAuthenticationProtocol = 6
  );
  PWiFi_WiFiConnectionStatus = ^WiFi_WiFiConnectionStatus;

  // Windows.Devices.WiFi.WiFiNetworkKind
  WiFi_WiFiNetworkKind = (
    Any = 0,
    Infrastructure = 1,
    Adhoc = 2
  );
  PWiFi_WiFiNetworkKind = ^WiFi_WiFiNetworkKind;

  // Windows.Devices.WiFi.WiFiOnDemandHotspotAvailability
  WiFi_WiFiOnDemandHotspotAvailability = (
    Available = 0,
    Unavailable = 1
  );
  PWiFi_WiFiOnDemandHotspotAvailability = ^WiFi_WiFiOnDemandHotspotAvailability;

  // Windows.Devices.WiFi.WiFiOnDemandHotspotCellularBars
  WiFi_WiFiOnDemandHotspotCellularBars = (
    ZeroBars = 0,
    OneBar = 1,
    TwoBars = 2,
    ThreeBars = 3,
    FourBars = 4,
    FiveBars = 5
  );
  PWiFi_WiFiOnDemandHotspotCellularBars = ^WiFi_WiFiOnDemandHotspotCellularBars;

  // Windows.Devices.WiFi.WiFiOnDemandHotspotConnectStatus
  WiFi_WiFiOnDemandHotspotConnectStatus = (
    UnspecifiedFailure = 0,
    Success = 1,
    AppTimedOut = 2,
    InvalidCredential = 3,
    NetworkNotAvailable = 4,
    UnsupportedAuthenticationProtocol = 5,
    BluetoothConnectFailed = 6,
    BluetoothTransmissionError = 7,
    OperationCanceledByUser = 8,
    EntitlementCheckFailed = 9,
    NoCellularSignal = 10,
    CellularDataTurnedOff = 11,
    WlanConnectFailed = 12,
    WlanNotVisible = 13,
    AccessPointCannotConnect = 14,
    CellularConnectTimedOut = 15,
    RoamingNotAllowed = 16,
    PairingRequired = 17,
    DataLimitReached = 18
  );
  PWiFi_WiFiOnDemandHotspotConnectStatus = ^WiFi_WiFiOnDemandHotspotConnectStatus;

  // Windows.Devices.WiFi.WiFiPhyKind
  WiFi_WiFiPhyKind = (
    Unknown = 0,
    Fhss = 1,
    Dsss = 2,
    IRBaseband = 3,
    Ofdm = 4,
    Hrdsss = 5,
    Erp = 6,
    HT = 7,
    Vht = 8,
    Dmg = 9,
    HE = 10,
    Eht = 11
  );
  PWiFi_WiFiPhyKind = ^WiFi_WiFiPhyKind;

  // Windows.Devices.WiFi.WiFiReconnectionKind
  WiFi_WiFiReconnectionKind = (
    Automatic = 0,
    Manual = 1
  );
  PWiFi_WiFiReconnectionKind = ^WiFi_WiFiReconnectionKind;

  // Windows.Devices.WiFi.WiFiWpsConfigurationStatus
  WiFi_WiFiWpsConfigurationStatus = (
    UnspecifiedFailure = 0,
    Success = 1,
    Timeout = 2
  );
  PWiFi_WiFiWpsConfigurationStatus = ^WiFi_WiFiWpsConfigurationStatus;

  // Windows.Devices.WiFi.WiFiWpsKind
  WiFi_WiFiWpsKind = (
    Unknown = 0,
    Pin = 1,
    PushButton = 2,
    Nfc = 3,
    Ethernet = 4,
    Usb = 5
  );
  PWiFi_WiFiWpsKind = ^WiFi_WiFiWpsKind;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAdvertisementStatus
  WiFiDirect_Services_WiFiDirectServiceAdvertisementStatus = (
    Created = 0,
    Started = 1,
    Stopped = 2,
    Aborted = 3
  );
  PWiFiDirect_Services_WiFiDirectServiceAdvertisementStatus = ^WiFiDirect_Services_WiFiDirectServiceAdvertisementStatus;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod
  WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = (
    Default = 0,
    PinDisplay = 1,
    PinEntry = 2
  );
  PWiFiDirect_Services_WiFiDirectServiceConfigurationMethod = ^WiFiDirect_Services_WiFiDirectServiceConfigurationMethod;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceError
  WiFiDirect_Services_WiFiDirectServiceError = (
    Success = 0,
    RadioNotAvailable = 1,
    ResourceInUse = 2,
    UnsupportedHardware = 3,
    NoHardware = 4
  );
  PWiFiDirect_Services_WiFiDirectServiceError = ^WiFiDirect_Services_WiFiDirectServiceError;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceIPProtocol
  WiFiDirect_Services_WiFiDirectServiceIPProtocol = (
    Tcp = 6,
    Udp = 17
  );
  PWiFiDirect_Services_WiFiDirectServiceIPProtocol = ^WiFiDirect_Services_WiFiDirectServiceIPProtocol;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSessionErrorStatus
  WiFiDirect_Services_WiFiDirectServiceSessionErrorStatus = (
    Ok = 0,
    Disassociated = 1,
    LocalClose = 2,
    RemoteClose = 3,
    SystemFailure = 4,
    NoResponseFromRemote = 5
  );
  PWiFiDirect_Services_WiFiDirectServiceSessionErrorStatus = ^WiFiDirect_Services_WiFiDirectServiceSessionErrorStatus;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSessionStatus
  WiFiDirect_Services_WiFiDirectServiceSessionStatus = (
    Closed = 0,
    Initiated = 1,
    Requested = 2,
    Open = 3
  );
  PWiFiDirect_Services_WiFiDirectServiceSessionStatus = ^WiFiDirect_Services_WiFiDirectServiceSessionStatus;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceStatus
  WiFiDirect_Services_WiFiDirectServiceStatus = (
    Available = 0,
    Busy = 1,
    Custom = 2
  );
  PWiFiDirect_Services_WiFiDirectServiceStatus = ^WiFiDirect_Services_WiFiDirectServiceStatus;

  // Windows.Devices.WiFiDirect.WiFiDirectAdvertisementListenStateDiscoverability
  WiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability = (
    None = 0,
    Normal = 1,
    Intensive = 2
  );
  PWiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability = ^WiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability;

  // Windows.Devices.WiFiDirect.WiFiDirectAdvertisementPublisherStatus
  WiFiDirect_WiFiDirectAdvertisementPublisherStatus = (
    Created = 0,
    Started = 1,
    Stopped = 2,
    Aborted = 3
  );
  PWiFiDirect_WiFiDirectAdvertisementPublisherStatus = ^WiFiDirect_WiFiDirectAdvertisementPublisherStatus;

  // Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod
  WiFiDirect_WiFiDirectConfigurationMethod = (
    ProvidePin = 0,
    DisplayPin = 1,
    PushButton = 2
  );
  PWiFiDirect_WiFiDirectConfigurationMethod = ^WiFiDirect_WiFiDirectConfigurationMethod;

  // Windows.Devices.WiFiDirect.WiFiDirectConnectionStatus
  WiFiDirect_WiFiDirectConnectionStatus = (
    Disconnected = 0,
    Connected = 1
  );
  PWiFiDirect_WiFiDirectConnectionStatus = ^WiFiDirect_WiFiDirectConnectionStatus;

  // Windows.Devices.WiFiDirect.WiFiDirectDeviceSelectorType
  WiFiDirect_WiFiDirectDeviceSelectorType = (
    DeviceInterface = 0,
    AssociationEndpoint = 1
  );
  PWiFiDirect_WiFiDirectDeviceSelectorType = ^WiFiDirect_WiFiDirectDeviceSelectorType;

  // Windows.Devices.WiFiDirect.WiFiDirectError
  WiFiDirect_WiFiDirectError = (
    Success = 0,
    RadioNotAvailable = 1,
    ResourceInUse = 2
  );
  PWiFiDirect_WiFiDirectError = ^WiFiDirect_WiFiDirectError;

  // Windows.Devices.WiFiDirect.WiFiDirectPairingProcedure
  WiFiDirect_WiFiDirectPairingProcedure = (
    GroupOwnerNegotiation = 0,
    Invitation = 1
  );
  PWiFiDirect_WiFiDirectPairingProcedure = ^WiFiDirect_WiFiDirectPairingProcedure;

  // Windows.Devices Records

  // Windows.Devices.Custom.CustomDeviceContract
  Custom_CustomDeviceContract = record
  end;
  PCustom_CustomDeviceContract = ^Custom_CustomDeviceContract;

  // Windows.Devices.DevicesLowLevelContract
  DevicesLowLevelContract = record
  end;
  PDevicesLowLevelContract = ^DevicesLowLevelContract;

  // Windows.Devices.Display.Core.DisplayPresentationRate
  Display_Core_DisplayPresentationRate = record
    VerticalSyncRate: Numerics_Rational;
    VerticalSyncsPerPresentation: Integer;
  end;
  PDisplay_Core_DisplayPresentationRate = ^Display_Core_DisplayPresentationRate;

  // Windows.Devices.Gpio.GpioChangeCount
  Gpio_GpioChangeCount = record
    Count: UInt64;
    RelativeTime: TimeSpan;
  end;
  PGpio_GpioChangeCount = ^Gpio_GpioChangeCount;

  // Windows.Devices.Gpio.GpioChangeRecord
  Gpio_GpioChangeRecord = record
    RelativeTime: TimeSpan;
    Edge: Gpio_GpioPinEdge;
  end;
  PGpio_GpioChangeRecord = ^Gpio_GpioChangeRecord;

  // Windows.Devices.I2c.I2cTransferResult
  I2c_I2cTransferResult = record
    Status: I2c_I2cTransferStatus;
    BytesTransferred: Cardinal;
  end;
  PI2c_I2cTransferResult = ^I2c_I2cTransferResult;

  // Windows.Devices.I2c.Provider.ProviderI2cTransferResult
  I2c_Provider_ProviderI2cTransferResult = record
    Status: I2c_Provider_ProviderI2cTransferStatus;
    BytesTransferred: Cardinal;
  end;
  PI2c_Provider_ProviderI2cTransferResult = ^I2c_Provider_ProviderI2cTransferResult;

  // Windows.Devices.Input.MouseDelta
  Input_MouseDelta = record
    X: Integer;
    Y: Integer;
  end;
  PInput_MouseDelta = ^Input_MouseDelta;

  // Windows.Devices.Portable.PortableDeviceContract
  Portable_PortableDeviceContract = record
  end;
  PPortable_PortableDeviceContract = ^Portable_PortableDeviceContract;

  // Windows.Devices.Power.PowerGridApiContract
  Power_PowerGridApiContract = record
  end;
  PPower_PowerGridApiContract = ^Power_PowerGridApiContract;

  // Windows.Devices.Printers.Extensions.ExtensionsContract
  Printers_Extensions_ExtensionsContract = record
  end;
  PPrinters_Extensions_ExtensionsContract = ^Printers_Extensions_ExtensionsContract;

  // Windows.Devices.Printers.PrintersContract
  Printers_PrintersContract = record
  end;
  PPrinters_PrintersContract = ^Printers_PrintersContract;

  // Windows.Devices.SmartCards.SmartCardBackgroundTriggerContract
  SmartCards_SmartCardBackgroundTriggerContract = record
  end;
  PSmartCards_SmartCardBackgroundTriggerContract = ^SmartCards_SmartCardBackgroundTriggerContract;

  // Windows.Devices.SmartCards.SmartCardEmulatorContract
  SmartCards_SmartCardEmulatorContract = record
  end;
  PSmartCards_SmartCardEmulatorContract = ^SmartCards_SmartCardEmulatorContract;

  // Windows.Devices Interfaces

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Input.PointerDeviceUsage>
  IIterator_1__Input_PointerDeviceUsage = interface(IInspectable)
  ['{9AB2160D-11EF-5ECA-8DD9-3E13AA4E5F99}']
    function get_Current: Input_PointerDeviceUsage; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PInput_PointerDeviceUsage): Cardinal; safecall;
    property Current: Input_PointerDeviceUsage read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Input.PointerDeviceUsage>
  IIterable_1__Input_PointerDeviceUsage = interface(IInspectable)
  ['{592D6618-EAAB-5A79-A47A-C7FC0B749A4E}']
    function First: IIterator_1__Input_PointerDeviceUsage; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenDevice
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenDevice)]
  Input_IPenDevice = interface(IInspectable)
  ['{31856EBA-A738-5A8C-B8F6-F97EF68D18EF}']
    function get_PenId: TGuid; safecall;
    property PenId: TGuid read get_PenId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Adc.IAdcController
  [WinRTClassNameAttribute(SWindows_Devices_Adc_AdcController)]
  Adc_IAdcController = interface(IInspectable)
  ['{2A76E4B0-A896-4219-86B6-EA8CDCE98F56}']
    function get_ChannelCount: Integer; safecall;
    function get_ResolutionInBits: Integer; safecall;
    function get_MinValue: Integer; safecall;
    function get_MaxValue: Integer; safecall;
    function get_ChannelMode: Adc_AdcChannelMode; safecall;
    procedure put_ChannelMode(value: Adc_AdcChannelMode); safecall;
    function IsChannelModeSupported(channelMode: Adc_AdcChannelMode): Boolean; safecall;
    function OpenChannel(channelNumber: Integer): Adc_IAdcChannel; safecall;
    property ChannelCount: Integer read get_ChannelCount;
    property ChannelMode: Adc_AdcChannelMode read get_ChannelMode write put_ChannelMode;
    property MaxValue: Integer read get_MaxValue;
    property MinValue: Integer read get_MinValue;
    property ResolutionInBits: Integer read get_ResolutionInBits;
  end;

  // UsedAPI Interface
  // Windows.Devices.Adc.IAdcChannel
  Adc_IAdcChannel = interface(IInspectable)
  ['{040BF414-2588-4A56-ABEF-73A260ACC60A}']
    function get_Controller: Adc_IAdcController; safecall;
    function ReadValue: Integer; safecall;
    function ReadRatio: Double; safecall;
    property Controller: Adc_IAdcController read get_Controller;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Adc.AdcController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Adc.IAdcController>
  IIterator_1__Adc_IAdcController = interface(IInspectable)
  ['{A10B62C1-A014-5335-8867-747FCAB16005}']
    function get_Current: Adc_IAdcController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PAdc_IAdcController): Cardinal; safecall;
    property Current: Adc_IAdcController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Adc.AdcController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Adc.IAdcController>
  IIterable_1__Adc_IAdcController = interface(IInspectable)
  ['{4E478AAD-4861-5758-B64B-5B4F28D8F86E}']
    function First: IIterator_1__Adc_IAdcController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>
  IVectorView_1__Adc_IAdcController = interface(IInspectable)
  ['{706FC9A6-CC21-545F-94AE-A87FF514A04A}']
    function GetAt(index: Cardinal): Adc_IAdcController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Adc_IAdcController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PAdc_IAdcController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.AdcController>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController = interface(IUnknown)
  ['{7C4038C8-D920-53C7-A5D6-A976070D7637}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Adc_IAdcController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.AdcController>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.IAdcController>>
  IAsyncOperation_1__IVectorView_1__Adc_IAdcController = interface(IInspectable)
  ['{1B0CDDFB-D255-5A93-BCB9-DE2047A3E4F3}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController; safecall;
    function GetResults: IVectorView_1__Adc_IAdcController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Adc_IAdcController read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Adc.Provider.IAdcControllerProvider
  Adc_Provider_IAdcControllerProvider = interface(IInspectable)
  ['{BE545828-816D-4DE5-A048-ABA06958AAA8}']
    function get_ChannelCount: Integer; safecall;
    function get_ResolutionInBits: Integer; safecall;
    function get_MinValue: Integer; safecall;
    function get_MaxValue: Integer; safecall;
    function get_ChannelMode: Adc_Provider_ProviderAdcChannelMode; safecall;
    procedure put_ChannelMode(value: Adc_Provider_ProviderAdcChannelMode); safecall;
    function IsChannelModeSupported(channelMode: Adc_Provider_ProviderAdcChannelMode): Boolean; safecall;
    procedure AcquireChannel(channel: Integer); safecall;
    procedure ReleaseChannel(channel: Integer); safecall;
    function ReadValue(channelNumber: Integer): Integer; safecall;
    property ChannelCount: Integer read get_ChannelCount;
    property ChannelMode: Adc_Provider_ProviderAdcChannelMode read get_ChannelMode write put_ChannelMode;
    property MaxValue: Integer read get_MaxValue;
    property MinValue: Integer read get_MinValue;
    property ResolutionInBits: Integer read get_ResolutionInBits;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IIterator_1__Adc_Provider_IAdcControllerProvider = interface(IInspectable)
  ['{B43ACF15-A24A-5B00-B710-1737BA550A18}']
    function get_Current: Adc_Provider_IAdcControllerProvider; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PAdc_Provider_IAdcControllerProvider): Cardinal; safecall;
    property Current: Adc_Provider_IAdcControllerProvider read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IIterable_1__Adc_Provider_IAdcControllerProvider = interface(IInspectable)
  ['{30047155-1F71-5223-8482-E5159D0137D0}']
    function First: IIterator_1__Adc_Provider_IAdcControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Adc.Provider.IAdcControllerProvider>
  IVectorView_1__Adc_Provider_IAdcControllerProvider = interface(IInspectable)
  ['{7C4789C0-8445-5757-AAB7-659CBF50AAA7}']
    function GetAt(index: Cardinal): Adc_Provider_IAdcControllerProvider; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Adc_Provider_IAdcControllerProvider; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PAdc_Provider_IAdcControllerProvider): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Adc.Provider.IAdcProvider
  Adc_Provider_IAdcProvider = interface(IInspectable)
  ['{28953668-9359-4C57-BC88-E275E81638C9}']
    function GetControllers: IVectorView_1__Adc_Provider_IAdcControllerProvider; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Adc.IAdcControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Adc_AdcController)]
  Adc_IAdcControllerStatics = interface(IInspectable)
  ['{CCE98E0C-01F8-4891-BC3B-BE53EF279CA4}']
    function GetControllersAsync(provider: Adc_Provider_IAdcProvider): IAsyncOperation_1__IVectorView_1__Adc_IAdcController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Adc.AdcController>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Adc.IAdcController>
  AsyncOperationCompletedHandler_1__Adc_IAdcController = interface(IUnknown)
  ['{BAF66488-202F-5D51-B05E-18606C46B808}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Adc_IAdcController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Adc.AdcController>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Adc.IAdcController>
  IAsyncOperation_1__Adc_IAdcController = interface(IInspectable)
  ['{69420262-35C9-583F-A40E-C2694562C9E2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Adc_IAdcController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Adc_IAdcController; safecall;
    function GetResults: Adc_IAdcController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Adc_IAdcController read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Adc.IAdcControllerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Adc_AdcController)]
  Adc_IAdcControllerStatics2 = interface(IInspectable)
  ['{A2B93B1D-977B-4F5A-A5FE-A6ABAFFE6484}']
    function GetDefaultAsync: IAsyncOperation_1__Adc_IAdcController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Radios.RadioAccessStatus>
  AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus = interface(IUnknown)
  ['{BD248E73-F05F-574C-AE3D-9B95C4BF282A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Radios_RadioAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Radios.RadioAccessStatus>
  IAsyncOperation_1__Radios_RadioAccessStatus = interface(IInspectable)
  ['{21FB30EF-072F-502C-9898-D0C3B2CD9AC5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus; safecall;
    function GetResults: Radios_RadioAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Radios_RadioAccessStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Radios.Radio,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Radios.IRadio,Object>
  TypedEventHandler_2__Radios_IRadio__IInspectable = interface(IUnknown)
  ['{FC6AA329-B586-5EBB-9E85-3F6B84EBDF18}']
    procedure Invoke(sender: Radios_IRadio; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Radios.IRadio
  [WinRTClassNameAttribute(SWindows_Devices_Radios_Radio)]
  Radios_IRadio = interface(IInspectable)
  ['{252118DF-B33E-416A-875F-1CF38AE2D83E}']
    function SetStateAsync(value: Radios_RadioState): IAsyncOperation_1__Radios_RadioAccessStatus; safecall;
    function add_StateChanged(handler: TypedEventHandler_2__Radios_IRadio__IInspectable): EventRegistrationToken; safecall;
    procedure remove_StateChanged(eventCookie: EventRegistrationToken); safecall;
    function get_State: Radios_RadioState; safecall;
    function get_Name: HSTRING; safecall;
    function get_Kind: Radios_RadioKind; safecall;
    property Kind: Radios_RadioKind read get_Kind;
    property Name: HSTRING read get_Name;
    property State: Radios_RadioState read get_State;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Radios.Radio>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Radios.IRadio>
  AsyncOperationCompletedHandler_1__Radios_IRadio = interface(IUnknown)
  ['{8A5C7E3A-80E2-585B-8630-7A8E777F0354}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Radios_IRadio; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Radios.Radio>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Radios.IRadio>
  IAsyncOperation_1__Radios_IRadio = interface(IInspectable)
  ['{EAC62C40-8DBC-5854-8BA0-B7B9940E7389}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Radios_IRadio); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Radios_IRadio; safecall;
    function GetResults: Radios_IRadio; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Radios_IRadio read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Custom.IIOControlCode
  [WinRTClassNameAttribute(SWindows_Devices_Custom_IOControlCode)]
  Custom_IIOControlCode = interface(IInspectable)
  ['{0E9559E7-60C8-4375-A761-7F8808066C60}']
    function get_AccessMode: Custom_IOControlAccessMode; safecall;
    function get_BufferingMethod: Custom_IOControlBufferingMethod; safecall;
    function get_Function: Word; safecall;
    function get_DeviceType: Word; safecall;
    function get_ControlCode: Cardinal; safecall;
    property AccessMode: Custom_IOControlAccessMode read get_AccessMode;
    property BufferingMethod: Custom_IOControlBufferingMethod read get_BufferingMethod;
    property ControlCode: Cardinal read get_ControlCode;
    property DeviceType: Word read get_DeviceType;
    property &Function: Word read get_Function;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Custom.ICustomDevice
  [WinRTClassNameAttribute(SWindows_Devices_Custom_CustomDevice)]
  Custom_ICustomDevice = interface(IInspectable)
  ['{DD30251F-C48B-43BD-BCB1-DEC88F15143E}']
    function get_InputStream: IInputStream; safecall;
    function get_OutputStream: IOutputStream; safecall;
    function SendIOControlAsync(ioControlCode: Custom_IIOControlCode; inputBuffer: IBuffer; outputBuffer: IBuffer): IAsyncOperation_1__Cardinal; safecall;
    function TrySendIOControlAsync(ioControlCode: Custom_IIOControlCode; inputBuffer: IBuffer; outputBuffer: IBuffer): IAsyncOperation_1__Boolean; safecall;
    property InputStream: IInputStream read get_InputStream;
    property OutputStream: IOutputStream read get_OutputStream;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Custom.CustomDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Custom.ICustomDevice>
  AsyncOperationCompletedHandler_1__Custom_ICustomDevice = interface(IUnknown)
  ['{1FDD39B0-E0E5-5C59-B27D-A549B1075CE9}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Custom_ICustomDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Custom.CustomDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Custom.ICustomDevice>
  IAsyncOperation_1__Custom_ICustomDevice = interface(IInspectable)
  ['{2A6344AA-0568-548E-A1A2-B6BB451D228C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Custom_ICustomDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Custom_ICustomDevice; safecall;
    function GetResults: Custom_ICustomDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Custom_ICustomDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Custom.ICustomDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Custom_CustomDevice)]
  Custom_ICustomDeviceStatics = interface(IInspectable)
  ['{C8220312-EF4C-46B1-A58E-EEB308DC8917}']
    function GetDeviceSelector(classGuid: TGuid): HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING; desiredAccess: Custom_DeviceAccessMode; sharingMode: Custom_DeviceSharingMode): IAsyncOperation_1__Custom_ICustomDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Custom.IIOControlCodeFactory
  [WinRTClassNameAttribute(SWindows_Devices_Custom_IOControlCode)]
  Custom_IIOControlCodeFactory = interface(IInspectable)
  ['{856A7CF0-4C11-44AE-AFC6-B8D4A212788F}']
    function CreateIOControlCode(deviceType: Word; &function: Word; accessMode: Custom_IOControlAccessMode; bufferingMethod: Custom_IOControlBufferingMethod): Custom_IIOControlCode; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Custom.IKnownDeviceTypesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Custom_KnownDeviceTypes)]
  Custom_IKnownDeviceTypesStatics = interface(IInspectable)
  ['{EE5479C2-5448-45DA-AD1B-24948C239094}']
    function get_Unknown: Word; safecall;
    property Unknown: Word read get_Unknown;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Display.IDisplayMonitor
  [WinRTClassNameAttribute(SWindows_Devices_Display_DisplayMonitor)]
  Display_IDisplayMonitor = interface(IInspectable)
  ['{1F6B15D4-1D01-4C51-87E2-6F954A772B59}']
    function get_DeviceId: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_ConnectionKind: Display_DisplayMonitorConnectionKind; safecall;
    function get_PhysicalConnector: Display_DisplayMonitorPhysicalConnectorKind; safecall;
    function get_DisplayAdapterDeviceId: HSTRING; safecall;
    function get_DisplayAdapterId: DisplayAdapterId; safecall;
    function get_DisplayAdapterTargetId: Cardinal; safecall;
    function get_UsageKind: Display_DisplayMonitorUsageKind; safecall;
    function get_NativeResolutionInRawPixels: SizeInt32; safecall;
    function get_PhysicalSizeInInches: IReference_1__Size; safecall;
    function get_RawDpiX: Single; safecall;
    function get_RawDpiY: Single; safecall;
    function get_RedPrimary: TPointF; safecall;
    function get_GreenPrimary: TPointF; safecall;
    function get_BluePrimary: TPointF; safecall;
    function get_WhitePoint: TPointF; safecall;
    function get_MaxLuminanceInNits: Single; safecall;
    function get_MinLuminanceInNits: Single; safecall;
    function get_MaxAverageFullFrameLuminanceInNits: Single; safecall;
    function GetDescriptor(descriptorKind: Display_DisplayMonitorDescriptorKind; resultSize: Cardinal; resultValue: PByte): HRESULT; stdcall;
    property BluePrimary: TPointF read get_BluePrimary;
    property ConnectionKind: Display_DisplayMonitorConnectionKind read get_ConnectionKind;
    property DeviceId: HSTRING read get_DeviceId;
    property DisplayAdapterDeviceId: HSTRING read get_DisplayAdapterDeviceId;
    property DisplayAdapterId_: DisplayAdapterId read get_DisplayAdapterId;
    property DisplayAdapterTargetId: Cardinal read get_DisplayAdapterTargetId;
    property DisplayName: HSTRING read get_DisplayName;
    property GreenPrimary: TPointF read get_GreenPrimary;
    property MaxAverageFullFrameLuminanceInNits: Single read get_MaxAverageFullFrameLuminanceInNits;
    property MaxLuminanceInNits: Single read get_MaxLuminanceInNits;
    property MinLuminanceInNits: Single read get_MinLuminanceInNits;
    property NativeResolutionInRawPixels: SizeInt32 read get_NativeResolutionInRawPixels;
    property PhysicalConnector: Display_DisplayMonitorPhysicalConnectorKind read get_PhysicalConnector;
    property PhysicalSizeInInches: IReference_1__Size read get_PhysicalSizeInInches;
    property RawDpiX: Single read get_RawDpiX;
    property RawDpiY: Single read get_RawDpiY;
    property RedPrimary: TPointF read get_RedPrimary;
    property UsageKind: Display_DisplayMonitorUsageKind read get_UsageKind;
    property WhitePoint: TPointF read get_WhitePoint;
  end;

  // Windows.Foundation.IReference`1<Windows.Devices.Display.Core.DisplayPresentationRate>
  IReference_1__Display_Core_DisplayPresentationRate = interface(IInspectable)
  ['{08882DDB-A981-5887-B751-106993D66229}']
    function get_Value: Display_Core_DisplayPresentationRate; safecall;
    property Value: Display_Core_DisplayPresentationRate read get_Value;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Display.IDisplayMonitor2
  Display_IDisplayMonitor2 = interface(IInspectable)
  ['{023018E6-CB23-5830-96DF-A7BF6E602577}']
    function get_IsDolbyVisionSupportedInHdrMode: Boolean; safecall;
    property IsDolbyVisionSupportedInHdrMode: Boolean read get_IsDolbyVisionSupportedInHdrMode;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Display.DisplayMonitor>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Display.IDisplayMonitor>
  AsyncOperationCompletedHandler_1__Display_IDisplayMonitor = interface(IUnknown)
  ['{620F34A8-5DBA-59DF-B719-99B77970344C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Display_IDisplayMonitor; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Display.DisplayMonitor>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Display.IDisplayMonitor>
  IAsyncOperation_1__Display_IDisplayMonitor = interface(IInspectable)
  ['{28C0E623-4E46-58C3-AD82-502BDECC4345}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Display_IDisplayMonitor); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Display_IDisplayMonitor; safecall;
    function GetResults: Display_IDisplayMonitor; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Display_IDisplayMonitor read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Display.IDisplayMonitorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Display_DisplayMonitor)]
  Display_IDisplayMonitorStatics = interface(IInspectable)
  ['{6EAE698F-A228-4C05-821D-B695D667DE8E}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor; safecall;
    function FromInterfaceIdAsync(deviceInterfaceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioChangeCounter
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioChangeCounter)]
  Gpio_IGpioChangeCounter = interface(IInspectable)
  ['{CB5EC0DE-6801-43FF-803D-4576628A8B26}']
    procedure put_Polarity(value: Gpio_GpioChangePolarity); safecall;
    function get_Polarity: Gpio_GpioChangePolarity; safecall;
    function get_IsStarted: Boolean; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    function Read: Gpio_GpioChangeCount; safecall;
    function Reset: Gpio_GpioChangeCount; safecall;
    property IsStarted: Boolean read get_IsStarted;
    property Polarity: Gpio_GpioChangePolarity read get_Polarity write put_Polarity;
  end;

  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioPinValueChangedEventArgs
  Gpio_IGpioPinValueChangedEventArgs = interface(IInspectable)
  ['{3137AAE1-703D-4059-BD24-B5B25DFFB84E}']
    function get_Edge: Gpio_GpioPinEdge; safecall;
    property Edge: Gpio_GpioPinEdge read get_Edge;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.GpioPin,Windows.Devices.Gpio.GpioPinValueChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.IGpioPin,Windows.Devices.Gpio.IGpioPinValueChangedEventArgs>
  TypedEventHandler_2__Gpio_IGpioPin__Gpio_IGpioPinValueChangedEventArgs = interface(IUnknown)
  ['{44BA689B-7D42-5374-ADD9-AB41E877A34B}']
    procedure Invoke(sender: Gpio_IGpioPin; args: Gpio_IGpioPinValueChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioPin
  Gpio_IGpioPin = interface(IInspectable)
  ['{11D9B087-AFAE-4790-9EE9-E0EAC942D201}']
    function add_ValueChanged(handler: TypedEventHandler_2__Gpio_IGpioPin__Gpio_IGpioPinValueChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ValueChanged(token: EventRegistrationToken); safecall;
    function get_DebounceTimeout: TimeSpan; safecall;
    procedure put_DebounceTimeout(value: TimeSpan); safecall;
    function get_PinNumber: Integer; safecall;
    function get_SharingMode: Gpio_GpioSharingMode; safecall;
    function IsDriveModeSupported(driveMode: Gpio_GpioPinDriveMode): Boolean; safecall;
    function GetDriveMode: Gpio_GpioPinDriveMode; safecall;
    procedure SetDriveMode(value: Gpio_GpioPinDriveMode); safecall;
    procedure Write(value: Gpio_GpioPinValue); safecall;
    function Read: Gpio_GpioPinValue; safecall;
    property DebounceTimeout: TimeSpan read get_DebounceTimeout write put_DebounceTimeout;
    property PinNumber: Integer read get_PinNumber;
    property SharingMode: Gpio_GpioSharingMode read get_SharingMode;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioChangeCounterFactory
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioChangeCounter)]
  Gpio_IGpioChangeCounterFactory = interface(IInspectable)
  ['{147D94B6-0A9E-410C-B4FA-F89F4052084D}']
    function Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeCounter; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.GpioChangeRecord>
  IIterator_1__Gpio_GpioChangeRecord = interface(IInspectable)
  ['{A4C620B9-CB89-5A25-BF16-5F412C1A3388}']
    function get_Current: Gpio_GpioChangeRecord; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGpio_GpioChangeRecord): Cardinal; safecall;
    property Current: Gpio_GpioChangeRecord read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.GpioChangeRecord>
  IIterable_1__Gpio_GpioChangeRecord = interface(IInspectable)
  ['{B4AFBF4F-620E-5725-878A-78C6ED10374E}']
    function First: IIterator_1__Gpio_GpioChangeRecord; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.GpioChangeRecord>
  IVectorView_1__Gpio_GpioChangeRecord = interface(IInspectable)
  ['{D30AB625-1264-539E-ACEF-306DD214DC3B}']
    function GetAt(index: Cardinal): Gpio_GpioChangeRecord; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Gpio_GpioChangeRecord; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGpio_GpioChangeRecord): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.Gpio.GpioChangeRecord>
  IVector_1__Gpio_GpioChangeRecord = interface(IInspectable)
  ['{C8C443C2-F7D4-5386-AD15-31838882BD9E}']
    function GetAt(index: Cardinal): Gpio_GpioChangeRecord; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Gpio_GpioChangeRecord; safecall;
    function IndexOf(value: Gpio_GpioChangeRecord; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Gpio_GpioChangeRecord); safecall;
    procedure InsertAt(index: Cardinal; value: Gpio_GpioChangeRecord); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Gpio_GpioChangeRecord); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGpio_GpioChangeRecord): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PGpio_GpioChangeRecord); safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioChangeReader
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioChangeReader)]
  Gpio_IGpioChangeReader = interface(IInspectable)
  ['{0ABC885F-E031-48E8-8590-70DE78363C6D}']
    function get_Capacity: Integer; safecall;
    function get_Length: Integer; safecall;
    function get_IsEmpty: Boolean; safecall;
    function get_IsOverflowed: Boolean; safecall;
    procedure put_Polarity(value: Gpio_GpioChangePolarity); safecall;
    function get_Polarity: Gpio_GpioChangePolarity; safecall;
    function get_IsStarted: Boolean; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    procedure Clear; safecall;
    function GetNextItem: Gpio_GpioChangeRecord; safecall;
    function PeekNextItem: Gpio_GpioChangeRecord; safecall;
    function GetAllItems: IVector_1__Gpio_GpioChangeRecord; safecall;
    function WaitForItemsAsync(count: Integer): IAsyncAction; safecall;
    property Capacity: Integer read get_Capacity;
    property IsEmpty: Boolean read get_IsEmpty;
    property IsOverflowed: Boolean read get_IsOverflowed;
    property IsStarted: Boolean read get_IsStarted;
    property Length: Integer read get_Length;
    property Polarity: Gpio_GpioChangePolarity read get_Polarity write put_Polarity;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioChangeReaderFactory
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioChangeReader)]
  Gpio_IGpioChangeReaderFactory = interface(IInspectable)
  ['{A9598EF3-390E-441A-9D1C-E8DE0B2DF0DF}']
    function Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeReader; safecall;
    function CreateWithCapacity(pin: Gpio_IGpioPin; minCapacity: Integer): Gpio_IGpioChangeReader; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioController
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioController)]
  Gpio_IGpioController = interface(IInspectable)
  ['{284012E3-7461-469C-A8BC-61D69D08A53C}']
    function get_PinCount: Integer; safecall;
    function OpenPin(pinNumber: Integer): Gpio_IGpioPin; overload; safecall;
    function OpenPin(pinNumber: Integer; sharingMode: Gpio_GpioSharingMode): Gpio_IGpioPin; overload; safecall;
    function TryOpenPin(pinNumber: Integer; sharingMode: Gpio_GpioSharingMode; out pin: Gpio_IGpioPin; out openStatus: Gpio_GpioOpenStatus): Boolean; safecall;
    property PinCount: Integer read get_PinCount;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioController)]
  Gpio_IGpioControllerStatics = interface(IInspectable)
  ['{2ED6F42E-7AF7-4116-9533-C43D99A1FB64}']
    function GetDefault: Gpio_IGpioController; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.GpioController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.IGpioController>
  IIterator_1__Gpio_IGpioController = interface(IInspectable)
  ['{67944DB0-6C56-5A2F-9E7B-63CA1AA8C411}']
    function get_Current: Gpio_IGpioController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGpio_IGpioController): Cardinal; safecall;
    property Current: Gpio_IGpioController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.GpioController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.IGpioController>
  IIterable_1__Gpio_IGpioController = interface(IInspectable)
  ['{415C3794-B2B6-5F5C-9A05-AE9268514726}']
    function First: IIterator_1__Gpio_IGpioController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>
  IVectorView_1__Gpio_IGpioController = interface(IInspectable)
  ['{88121F4A-7A82-5E04-9D18-F29C074EBA84}']
    function GetAt(index: Cardinal): Gpio_IGpioController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Gpio_IGpioController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGpio_IGpioController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.GpioController>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController = interface(IUnknown)
  ['{EE427F2E-7D37-558F-9718-9CBCBFF40C94}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Gpio_IGpioController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.GpioController>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.IGpioController>>
  IAsyncOperation_1__IVectorView_1__Gpio_IGpioController = interface(IInspectable)
  ['{5DA3FAF4-60A7-5A14-9319-3941DFB13FED}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController; safecall;
    function GetResults: IVectorView_1__Gpio_IGpioController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Gpio_IGpioController read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgs
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_Provider_GpioPinProviderValueChangedEventArgs)]
  Gpio_Provider_IGpioPinProviderValueChangedEventArgs = interface(IInspectable)
  ['{32A6D6F2-3D5B-44CD-8FBE-13A69F2EDB24}']
    function get_Edge: Gpio_Provider_ProviderGpioPinEdge; safecall;
    property Edge: Gpio_Provider_ProviderGpioPinEdge read get_Edge;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.Provider.IGpioPinProvider,Windows.Devices.Gpio.Provider.GpioPinProviderValueChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Gpio.Provider.IGpioPinProvider,Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgs>
  TypedEventHandler_2__Gpio_Provider_IGpioPinProvider__Gpio_Provider_IGpioPinProviderValueChangedEventArgs = interface(IUnknown)
  ['{AF259D89-9E01-529E-A879-C6763142D160}']
    procedure Invoke(sender: Gpio_Provider_IGpioPinProvider; args: Gpio_Provider_IGpioPinProviderValueChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Gpio.Provider.IGpioPinProvider
  Gpio_Provider_IGpioPinProvider = interface(IInspectable)
  ['{42344CB7-6ABC-40FF-9CE7-73B85301B900}']
    function add_ValueChanged(handler: TypedEventHandler_2__Gpio_Provider_IGpioPinProvider__Gpio_Provider_IGpioPinProviderValueChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ValueChanged(token: EventRegistrationToken); safecall;
    function get_DebounceTimeout: TimeSpan; safecall;
    procedure put_DebounceTimeout(value: TimeSpan); safecall;
    function get_PinNumber: Integer; safecall;
    function get_SharingMode: Gpio_Provider_ProviderGpioSharingMode; safecall;
    function IsDriveModeSupported(driveMode: Gpio_Provider_ProviderGpioPinDriveMode): Boolean; safecall;
    function GetDriveMode: Gpio_Provider_ProviderGpioPinDriveMode; safecall;
    procedure SetDriveMode(value: Gpio_Provider_ProviderGpioPinDriveMode); safecall;
    procedure Write(value: Gpio_Provider_ProviderGpioPinValue); safecall;
    function Read: Gpio_Provider_ProviderGpioPinValue; safecall;
    property DebounceTimeout: TimeSpan read get_DebounceTimeout write put_DebounceTimeout;
    property PinNumber: Integer read get_PinNumber;
    property SharingMode: Gpio_Provider_ProviderGpioSharingMode read get_SharingMode;
  end;

  // UsedAPI Interface
  // Windows.Devices.Gpio.Provider.IGpioControllerProvider
  Gpio_Provider_IGpioControllerProvider = interface(IInspectable)
  ['{AD11CEC7-19EA-4B21-874F-B91AED4A25DB}']
    function get_PinCount: Integer; safecall;
    function OpenPinProvider(pin: Integer; sharingMode: Gpio_Provider_ProviderGpioSharingMode): Gpio_Provider_IGpioPinProvider; safecall;
    property PinCount: Integer read get_PinCount;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IIterator_1__Gpio_Provider_IGpioControllerProvider = interface(IInspectable)
  ['{6AC0EDB9-E3C9-5840-8AA8-1BC45366F6CA}']
    function get_Current: Gpio_Provider_IGpioControllerProvider; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGpio_Provider_IGpioControllerProvider): Cardinal; safecall;
    property Current: Gpio_Provider_IGpioControllerProvider read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IIterable_1__Gpio_Provider_IGpioControllerProvider = interface(IInspectable)
  ['{09212BD4-851B-52BD-B82C-421BF3D6F511}']
    function First: IIterator_1__Gpio_Provider_IGpioControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Gpio.Provider.IGpioControllerProvider>
  IVectorView_1__Gpio_Provider_IGpioControllerProvider = interface(IInspectable)
  ['{F429355F-7A16-5DCF-A575-DB7D2A20ECED}']
    function GetAt(index: Cardinal): Gpio_Provider_IGpioControllerProvider; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Gpio_Provider_IGpioControllerProvider; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGpio_Provider_IGpioControllerProvider): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Gpio.Provider.IGpioProvider
  Gpio_Provider_IGpioProvider = interface(IInspectable)
  ['{44E82707-08CA-434A-AFE0-D61580446F7E}']
    function GetControllers: IVectorView_1__Gpio_Provider_IGpioControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Gpio.GpioController>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Gpio.IGpioController>
  AsyncOperationCompletedHandler_1__Gpio_IGpioController = interface(IUnknown)
  ['{370167C0-0F7B-5E77-9BAE-D35089A3DB75}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Gpio_IGpioController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Gpio.GpioController>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Gpio.IGpioController>
  IAsyncOperation_1__Gpio_IGpioController = interface(IInspectable)
  ['{ED045917-96C7-5735-B4BE-D79619D4835E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Gpio_IGpioController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Gpio_IGpioController; safecall;
    function GetResults: Gpio_IGpioController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Gpio_IGpioController read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.IGpioControllerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_GpioController)]
  Gpio_IGpioControllerStatics2 = interface(IInspectable)
  ['{912B7D20-6CA4-4106-A373-FFFD346B0E5B}']
    function GetControllersAsync(provider: Gpio_Provider_IGpioProvider): IAsyncOperation_1__IVectorView_1__Gpio_IGpioController; safecall;
    function GetDefaultAsync: IAsyncOperation_1__Gpio_IGpioController; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgsFactory
  [WinRTClassNameAttribute(SWindows_Devices_Gpio_Provider_GpioPinProviderValueChangedEventArgs)]
  Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory = interface(IInspectable)
  ['{3ECB0B59-568C-4392-B24A-8A59A902B1F1}']
    function Create(edge: Gpio_Provider_ProviderGpioPinEdge): Gpio_Provider_IGpioPinProviderValueChangedEventArgs; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics
  [WinRTClassNameAttribute(SWindows_Devices_Haptics_KnownSimpleHapticsControllerWaveforms)]
  Haptics_IKnownSimpleHapticsControllerWaveformsStatics = interface(IInspectable)
  ['{3D577EF7-4CEE-11E6-B535-001BDC06AB3B}']
    function get_Click: Word; safecall;
    function get_BuzzContinuous: Word; safecall;
    function get_RumbleContinuous: Word; safecall;
    function get_Press: Word; safecall;
    function get_Release: Word; safecall;
    property BuzzContinuous: Word read get_BuzzContinuous;
    property Click: Word read get_Click;
    property Press: Word read get_Press;
    property Release: Word read get_Release;
    property RumbleContinuous: Word read get_RumbleContinuous;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Haptics_KnownSimpleHapticsControllerWaveforms)]
  Haptics_IKnownSimpleHapticsControllerWaveformsStatics2 = interface(IInspectable)
  ['{A7D24C27-B79D-510A-BF79-FF6D49173E1D}']
    function get_BrushContinuous: Word; safecall;
    function get_ChiselMarkerContinuous: Word; safecall;
    function get_EraserContinuous: Word; safecall;
    function get_Error: Word; safecall;
    function get_GalaxyPenContinuous: Word; safecall;
    function get_Hover: Word; safecall;
    function get_InkContinuous: Word; safecall;
    function get_MarkerContinuous: Word; safecall;
    function get_PencilContinuous: Word; safecall;
    function get_Success: Word; safecall;
    property BrushContinuous: Word read get_BrushContinuous;
    property ChiselMarkerContinuous: Word read get_ChiselMarkerContinuous;
    property EraserContinuous: Word read get_EraserContinuous;
    property Error: Word read get_Error;
    property GalaxyPenContinuous: Word read get_GalaxyPenContinuous;
    property Hover: Word read get_Hover;
    property InkContinuous: Word read get_InkContinuous;
    property MarkerContinuous: Word read get_MarkerContinuous;
    property PencilContinuous: Word read get_PencilContinuous;
    property Success: Word read get_Success;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.SimpleHapticsControllerFeedback>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  IIterator_1__Haptics_ISimpleHapticsControllerFeedback = interface(IInspectable)
  ['{B7D297D6-9666-5C9E-9DCC-5C382EAE6750}']
    function get_Current: Haptics_ISimpleHapticsControllerFeedback; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHaptics_ISimpleHapticsControllerFeedback): Cardinal; safecall;
    property Current: Haptics_ISimpleHapticsControllerFeedback read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.SimpleHapticsControllerFeedback>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.ISimpleHapticsControllerFeedback>
  IIterable_1__Haptics_ISimpleHapticsControllerFeedback = interface(IInspectable)
  ['{8894A0DF-33B0-57B0-AA1A-9255EEE72DD5}']
    function First: IIterator_1__Haptics_ISimpleHapticsControllerFeedback; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Haptics.IVibrationDevice
  [WinRTClassNameAttribute(SWindows_Devices_Haptics_VibrationDevice)]
  Haptics_IVibrationDevice = interface(IInspectable)
  ['{40F21A3E-8844-47FF-B312-06185A3844DA}']
    function get_Id: HSTRING; safecall;
    function get_SimpleHapticsController: Haptics_ISimpleHapticsController; safecall;
    property Id: HSTRING read get_Id;
    property SimpleHapticsController: Haptics_ISimpleHapticsController read get_SimpleHapticsController;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Haptics.VibrationAccessStatus>
  AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus = interface(IUnknown)
  ['{A38B59DB-4EF1-5BD2-89EF-F1D9F1FACA96}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Haptics_VibrationAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Haptics.VibrationAccessStatus>
  IAsyncOperation_1__Haptics_VibrationAccessStatus = interface(IInspectable)
  ['{076B2611-5614-55A5-9C58-F9D17A8F0B79}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus; safecall;
    function GetResults: Haptics_VibrationAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Haptics_VibrationAccessStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Haptics.VibrationDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Haptics.IVibrationDevice>
  AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice = interface(IUnknown)
  ['{4E22A135-F59A-546D-9FCF-82DEB833D968}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Haptics_IVibrationDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Haptics.VibrationDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Haptics.IVibrationDevice>
  IAsyncOperation_1__Haptics_IVibrationDevice = interface(IInspectable)
  ['{44193494-E331-50CA-BB61-6A71BD9B01C4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice; safecall;
    function GetResults: Haptics_IVibrationDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Haptics_IVibrationDevice read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.VibrationDevice>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.IVibrationDevice>
  IIterator_1__Haptics_IVibrationDevice = interface(IInspectable)
  ['{24E9B323-EEF1-533F-AD38-DE8FC8CA5692}']
    function get_Current: Haptics_IVibrationDevice; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHaptics_IVibrationDevice): Cardinal; safecall;
    property Current: Haptics_IVibrationDevice read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.VibrationDevice>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.IVibrationDevice>
  IIterable_1__Haptics_IVibrationDevice = interface(IInspectable)
  ['{1A40C994-8810-5688-9362-C4BB51018552}']
    function First: IIterator_1__Haptics_IVibrationDevice; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>
  IVectorView_1__Haptics_IVibrationDevice = interface(IInspectable)
  ['{FC58B864-3BA2-54FE-9C85-6C98492DD7C5}']
    function GetAt(index: Cardinal): Haptics_IVibrationDevice; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Haptics_IVibrationDevice; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHaptics_IVibrationDevice): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.VibrationDevice>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice = interface(IUnknown)
  ['{096F6389-6757-56DF-AF12-CFE1D8F23FC1}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.VibrationDevice>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Haptics.IVibrationDevice>>
  IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice = interface(IInspectable)
  ['{BDA8B138-7862-59F3-BFD9-5F1CB063DF02}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice; safecall;
    function GetResults: IVectorView_1__Haptics_IVibrationDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Haptics_IVibrationDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Haptics.IVibrationDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Haptics_VibrationDevice)]
  Haptics_IVibrationDeviceStatics = interface(IInspectable)
  ['{53E2EDED-2290-4AC9-8EB3-1A84122EB71C}']
    function RequestAccessAsync: IAsyncOperation_1__Haptics_VibrationAccessStatus; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Haptics_IVibrationDevice; safecall;
    function GetDefaultAsync: IAsyncOperation_1__Haptics_IVibrationDevice; safecall;
    function FindAllAsync: IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidCollection
  HumanInterfaceDevice_IHidCollection = interface(IInspectable)
  ['{7189F5A3-32F1-46E3-BEFD-44D2663B7E6A}']
    function get_Id: Cardinal; safecall;
    function get_Type: HumanInterfaceDevice_HidCollectionType; safecall;
    function get_UsagePage: Cardinal; safecall;
    function get_UsageId: Cardinal; safecall;
    property Id: Cardinal read get_Id;
    property &Type: HumanInterfaceDevice_HidCollectionType read get_Type;
    property UsageId: Cardinal read get_UsageId;
    property UsagePage: Cardinal read get_UsagePage;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.HidCollection>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IIterator_1__HumanInterfaceDevice_IHidCollection = interface(IInspectable)
  ['{CEFCEE70-C7FF-57C1-A675-A0DF8976A988}']
    function get_Current: HumanInterfaceDevice_IHidCollection; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidCollection): Cardinal; safecall;
    property Current: HumanInterfaceDevice_IHidCollection read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.HidCollection>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IIterable_1__HumanInterfaceDevice_IHidCollection = interface(IInspectable)
  ['{BBEADA0F-708F-5B5E-A017-5C64FFB96B69}']
    function First: IIterator_1__HumanInterfaceDevice_IHidCollection; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidCollection>
  IVectorView_1__HumanInterfaceDevice_IHidCollection = interface(IInspectable)
  ['{909C5998-72D1-5649-82E6-3D323471498B}']
    function GetAt(index: Cardinal): HumanInterfaceDevice_IHidCollection; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: HumanInterfaceDevice_IHidCollection; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidCollection): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription
  HumanInterfaceDevice_IHidBooleanControlDescription = interface(IInspectable)
  ['{6196E543-29D8-4A2A-8683-849E207BBE31}']
    function get_Id: Cardinal; safecall;
    function get_ReportId: Word; safecall;
    function get_ReportType: HumanInterfaceDevice_HidReportType; safecall;
    function get_UsagePage: Word; safecall;
    function get_UsageId: Word; safecall;
    function get_ParentCollections: IVectorView_1__HumanInterfaceDevice_IHidCollection; safecall;
    property Id: Cardinal read get_Id;
    property ParentCollections: IVectorView_1__HumanInterfaceDevice_IHidCollection read get_ParentCollections;
    property ReportId: Word read get_ReportId;
    property ReportType: HumanInterfaceDevice_HidReportType read get_ReportType;
    property UsageId: Word read get_UsageId;
    property UsagePage: Word read get_UsagePage;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControl
  HumanInterfaceDevice_IHidBooleanControl = interface(IInspectable)
  ['{524DF48A-3695-408C-BBA2-E2EB5ABFBC20}']
    function get_Id: Cardinal; safecall;
    function get_UsagePage: Word; safecall;
    function get_UsageId: Word; safecall;
    function get_IsActive: Boolean; safecall;
    procedure put_IsActive(value: Boolean); safecall;
    function get_ControlDescription: HumanInterfaceDevice_IHidBooleanControlDescription; safecall;
    property ControlDescription: HumanInterfaceDevice_IHidBooleanControlDescription read get_ControlDescription;
    property Id: Cardinal read get_Id;
    property IsActive: Boolean read get_IsActive write put_IsActive;
    property UsageId: Word read get_UsageId;
    property UsagePage: Word read get_UsagePage;
  end;

  // Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription2
  HumanInterfaceDevice_IHidBooleanControlDescription2 = interface(IInspectable)
  ['{C8EED2EA-8A77-4C36-AA00-5FF0449D3E73}']
    function get_IsAbsolute: Boolean; safecall;
    property IsAbsolute: Boolean read get_IsAbsolute;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.HidBooleanControl>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IIterator_1__HumanInterfaceDevice_IHidBooleanControl = interface(IInspectable)
  ['{5CDE3C23-D054-53D6-ABF1-41E73379B472}']
    function get_Current: HumanInterfaceDevice_IHidBooleanControl; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidBooleanControl): Cardinal; safecall;
    property Current: HumanInterfaceDevice_IHidBooleanControl read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.HidBooleanControl>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IIterable_1__HumanInterfaceDevice_IHidBooleanControl = interface(IInspectable)
  ['{1111E585-5AB0-5D2B-8AED-B6D6186D1C3F}']
    function First: IIterator_1__HumanInterfaceDevice_IHidBooleanControl; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControl>
  IVectorView_1__HumanInterfaceDevice_IHidBooleanControl = interface(IInspectable)
  ['{71D6B8C2-DAD6-54BD-AF65-892273FA8456}']
    function GetAt(index: Cardinal): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: HumanInterfaceDevice_IHidBooleanControl; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidBooleanControl): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription
  HumanInterfaceDevice_IHidNumericControlDescription = interface(IInspectable)
  ['{638D5E86-1D97-4C75-927F-5FF58BA05E32}']
    function get_Id: Cardinal; safecall;
    function get_ReportId: Word; safecall;
    function get_ReportType: HumanInterfaceDevice_HidReportType; safecall;
    function get_ReportSize: Cardinal; safecall;
    function get_ReportCount: Cardinal; safecall;
    function get_UsagePage: Word; safecall;
    function get_UsageId: Word; safecall;
    function get_LogicalMinimum: Integer; safecall;
    function get_LogicalMaximum: Integer; safecall;
    function get_PhysicalMinimum: Integer; safecall;
    function get_PhysicalMaximum: Integer; safecall;
    function get_UnitExponent: Cardinal; safecall;
    function get_Unit: Cardinal; safecall;
    function get_IsAbsolute: Boolean; safecall;
    function get_HasNull: Boolean; safecall;
    function get_ParentCollections: IVectorView_1__HumanInterfaceDevice_IHidCollection; safecall;
    property HasNull: Boolean read get_HasNull;
    property Id: Cardinal read get_Id;
    property IsAbsolute: Boolean read get_IsAbsolute;
    property LogicalMaximum: Integer read get_LogicalMaximum;
    property LogicalMinimum: Integer read get_LogicalMinimum;
    property ParentCollections: IVectorView_1__HumanInterfaceDevice_IHidCollection read get_ParentCollections;
    property PhysicalMaximum: Integer read get_PhysicalMaximum;
    property PhysicalMinimum: Integer read get_PhysicalMinimum;
    property ReportCount: Cardinal read get_ReportCount;
    property ReportId: Word read get_ReportId;
    property ReportSize: Cardinal read get_ReportSize;
    property ReportType: HumanInterfaceDevice_HidReportType read get_ReportType;
    property &Unit: Cardinal read get_Unit;
    property UnitExponent: Cardinal read get_UnitExponent;
    property UsageId: Word read get_UsageId;
    property UsagePage: Word read get_UsagePage;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidNumericControl
  HumanInterfaceDevice_IHidNumericControl = interface(IInspectable)
  ['{E38A12A5-35A7-4B75-89C8-FB1F28B10823}']
    function get_Id: Cardinal; safecall;
    function get_IsGrouped: Boolean; safecall;
    function get_UsagePage: Word; safecall;
    function get_UsageId: Word; safecall;
    function get_Value: Int64; safecall;
    procedure put_Value(value: Int64); safecall;
    function get_ScaledValue: Int64; safecall;
    procedure put_ScaledValue(value: Int64); safecall;
    function get_ControlDescription: HumanInterfaceDevice_IHidNumericControlDescription; safecall;
    property ControlDescription: HumanInterfaceDevice_IHidNumericControlDescription read get_ControlDescription;
    property Id: Cardinal read get_Id;
    property IsGrouped: Boolean read get_IsGrouped;
    property ScaledValue: Int64 read get_ScaledValue write put_ScaledValue;
    property UsageId: Word read get_UsageId;
    property UsagePage: Word read get_UsagePage;
    property Value: Int64 read get_Value write put_Value;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidInputReport
  HumanInterfaceDevice_IHidInputReport = interface(IInspectable)
  ['{C35D0E50-F7E7-4E8D-B23E-CABBE56B90E9}']
    function get_Id: Word; safecall;
    function get_Data: IBuffer; safecall;
    function get_ActivatedBooleanControls: IVectorView_1__HumanInterfaceDevice_IHidBooleanControl; safecall;
    function get_TransitionedBooleanControls: IVectorView_1__HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetBooleanControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetBooleanControlByDescription(controlDescription: HumanInterfaceDevice_IHidBooleanControlDescription): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetNumericControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidNumericControl; safecall;
    function GetNumericControlByDescription(controlDescription: HumanInterfaceDevice_IHidNumericControlDescription): HumanInterfaceDevice_IHidNumericControl; safecall;
    property ActivatedBooleanControls: IVectorView_1__HumanInterfaceDevice_IHidBooleanControl read get_ActivatedBooleanControls;
    property Data: IBuffer read get_Data;
    property Id: Word read get_Id;
    property TransitionedBooleanControls: IVectorView_1__HumanInterfaceDevice_IHidBooleanControl read get_TransitionedBooleanControls;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.HidInputReport>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidInputReport>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport = interface(IUnknown)
  ['{01C83770-03AB-5576-98B4-8D75CE1A9885}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.HidInputReport>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidInputReport>
  IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport = interface(IInspectable)
  ['{B3E28917-CD48-57B3-A0B1-321432E85BD6}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport; safecall;
    function GetResults: HumanInterfaceDevice_IHidInputReport; safecall;
    property Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidInputReport read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidFeatureReport
  HumanInterfaceDevice_IHidFeatureReport = interface(IInspectable)
  ['{841D9B79-5AE5-46E3-82EF-1FEC5C8942F4}']
    function get_Id: Word; safecall;
    function get_Data: IBuffer; safecall;
    procedure put_Data(value: IBuffer); safecall;
    function GetBooleanControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetBooleanControlByDescription(controlDescription: HumanInterfaceDevice_IHidBooleanControlDescription): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetNumericControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidNumericControl; safecall;
    function GetNumericControlByDescription(controlDescription: HumanInterfaceDevice_IHidNumericControlDescription): HumanInterfaceDevice_IHidNumericControl; safecall;
    property Data: IBuffer read get_Data write put_Data;
    property Id: Word read get_Id;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.HidFeatureReport>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidFeatureReport>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport = interface(IUnknown)
  ['{DB643555-3D16-57FE-B7EF-2BDBD719FDBF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.HidFeatureReport>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidFeatureReport>
  IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport = interface(IInspectable)
  ['{D72FB6F9-42F6-5F45-BFE3-29AF247C2E85}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport; safecall;
    function GetResults: HumanInterfaceDevice_IHidFeatureReport; safecall;
    property Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidFeatureReport read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidOutputReport
  HumanInterfaceDevice_IHidOutputReport = interface(IInspectable)
  ['{62CB2544-C896-4463-93C1-DF9DB053C450}']
    function get_Id: Word; safecall;
    function get_Data: IBuffer; safecall;
    procedure put_Data(value: IBuffer); safecall;
    function GetBooleanControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetBooleanControlByDescription(controlDescription: HumanInterfaceDevice_IHidBooleanControlDescription): HumanInterfaceDevice_IHidBooleanControl; safecall;
    function GetNumericControl(usagePage: Word; usageId: Word): HumanInterfaceDevice_IHidNumericControl; safecall;
    function GetNumericControlByDescription(controlDescription: HumanInterfaceDevice_IHidNumericControlDescription): HumanInterfaceDevice_IHidNumericControl; safecall;
    property Data: IBuffer read get_Data write put_Data;
    property Id: Word read get_Id;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.HidBooleanControlDescription>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IIterator_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface(IInspectable)
  ['{203203B0-B7F4-542D-B0D0-9CAA1FB55D7F}']
    function get_Current: HumanInterfaceDevice_IHidBooleanControlDescription; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidBooleanControlDescription): Cardinal; safecall;
    property Current: HumanInterfaceDevice_IHidBooleanControlDescription read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.HidBooleanControlDescription>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IIterable_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface(IInspectable)
  ['{D0FF0FED-A156-58BF-9411-5777DF9D57BF}']
    function First: IIterator_1__HumanInterfaceDevice_IHidBooleanControlDescription; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidBooleanControlDescription>
  IVectorView_1__HumanInterfaceDevice_IHidBooleanControlDescription = interface(IInspectable)
  ['{DD5CD347-21F8-5CE7-B15B-216CA9F4CEDE}']
    function GetAt(index: Cardinal): HumanInterfaceDevice_IHidBooleanControlDescription; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: HumanInterfaceDevice_IHidBooleanControlDescription; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidBooleanControlDescription): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.HidNumericControlDescription>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IIterator_1__HumanInterfaceDevice_IHidNumericControlDescription = interface(IInspectable)
  ['{52B9C36E-7D95-5D1C-ACAB-23C19EA76F01}']
    function get_Current: HumanInterfaceDevice_IHidNumericControlDescription; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidNumericControlDescription): Cardinal; safecall;
    property Current: HumanInterfaceDevice_IHidNumericControlDescription read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.HidNumericControlDescription>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IIterable_1__HumanInterfaceDevice_IHidNumericControlDescription = interface(IInspectable)
  ['{868F060D-E0D4-571B-B2F7-431D6984A513}']
    function First: IIterator_1__HumanInterfaceDevice_IHidNumericControlDescription; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.HumanInterfaceDevice.IHidNumericControlDescription>
  IVectorView_1__HumanInterfaceDevice_IHidNumericControlDescription = interface(IInspectable)
  ['{8BFE8BFD-2BAE-5AC2-AB76-C73F50FF5A2C}']
    function GetAt(index: Cardinal): HumanInterfaceDevice_IHidNumericControlDescription; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: HumanInterfaceDevice_IHidNumericControlDescription; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PHumanInterfaceDevice_IHidNumericControlDescription): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidInputReportReceivedEventArgs
  HumanInterfaceDevice_IHidInputReportReceivedEventArgs = interface(IInspectable)
  ['{7059C5CB-59B2-4DC2-985C-0ADC6136FA2D}']
    function get_Report: HumanInterfaceDevice_IHidInputReport; safecall;
    property Report: HumanInterfaceDevice_IHidInputReport read get_Report;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.HumanInterfaceDevice.HidDevice,Windows.Devices.HumanInterfaceDevice.HidInputReportReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.HumanInterfaceDevice.IHidDevice,Windows.Devices.HumanInterfaceDevice.IHidInputReportReceivedEventArgs>
  TypedEventHandler_2__HumanInterfaceDevice_IHidDevice__HumanInterfaceDevice_IHidInputReportReceivedEventArgs = interface(IUnknown)
  ['{31E757C8-8F6A-540B-938B-ABA79B6F03EC}']
    procedure Invoke(sender: HumanInterfaceDevice_IHidDevice; args: HumanInterfaceDevice_IHidInputReportReceivedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidDevice
  [WinRTClassNameAttribute(SWindows_Devices_HumanInterfaceDevice_HidDevice)]
  HumanInterfaceDevice_IHidDevice = interface(IInspectable)
  ['{5F8A14E7-2200-432E-95DA-D09B87D574A8}']
    function get_VendorId: Word; safecall;
    function get_ProductId: Word; safecall;
    function get_Version: Word; safecall;
    function get_UsagePage: Word; safecall;
    function get_UsageId: Word; safecall;
    function GetInputReportAsync: IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport; overload; safecall;
    function GetInputReportAsync(reportId: Word): IAsyncOperation_1__HumanInterfaceDevice_IHidInputReport; overload; safecall;
    function GetFeatureReportAsync: IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport; overload; safecall;
    function GetFeatureReportAsync(reportId: Word): IAsyncOperation_1__HumanInterfaceDevice_IHidFeatureReport; overload; safecall;
    function CreateOutputReport: HumanInterfaceDevice_IHidOutputReport; overload; safecall;
    function CreateOutputReport(reportId: Word): HumanInterfaceDevice_IHidOutputReport; overload; safecall;
    function CreateFeatureReport: HumanInterfaceDevice_IHidFeatureReport; overload; safecall;
    function CreateFeatureReport(reportId: Word): HumanInterfaceDevice_IHidFeatureReport; overload; safecall;
    function SendOutputReportAsync(outputReport: HumanInterfaceDevice_IHidOutputReport): IAsyncOperation_1__Cardinal; safecall;
    function SendFeatureReportAsync(featureReport: HumanInterfaceDevice_IHidFeatureReport): IAsyncOperation_1__Cardinal; safecall;
    function GetBooleanControlDescriptions(reportType: HumanInterfaceDevice_HidReportType; usagePage: Word; usageId: Word): IVectorView_1__HumanInterfaceDevice_IHidBooleanControlDescription; safecall;
    function GetNumericControlDescriptions(reportType: HumanInterfaceDevice_HidReportType; usagePage: Word; usageId: Word): IVectorView_1__HumanInterfaceDevice_IHidNumericControlDescription; safecall;
    function add_InputReportReceived(reportHandler: TypedEventHandler_2__HumanInterfaceDevice_IHidDevice__HumanInterfaceDevice_IHidInputReportReceivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_InputReportReceived(token: EventRegistrationToken); safecall;
    property ProductId: Word read get_ProductId;
    property UsageId: Word read get_UsageId;
    property UsagePage: Word read get_UsagePage;
    property VendorId: Word read get_VendorId;
    property Version: Word read get_Version;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.HidDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.HumanInterfaceDevice.IHidDevice>
  AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice = interface(IUnknown)
  ['{B0E8E149-0CB6-55A7-BCC1-D996324D65C4}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__HumanInterfaceDevice_IHidDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.HidDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.HumanInterfaceDevice.IHidDevice>
  IAsyncOperation_1__HumanInterfaceDevice_IHidDevice = interface(IInspectable)
  ['{A76A4FBF-5177-5256-84A8-B31A8DCF1048}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice; safecall;
    function GetResults: HumanInterfaceDevice_IHidDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__HumanInterfaceDevice_IHidDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.HumanInterfaceDevice.IHidDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_HumanInterfaceDevice_HidDevice)]
  HumanInterfaceDevice_IHidDeviceStatics = interface(IInspectable)
  ['{9E5981E4-9856-418C-9F73-77DE0CD85754}']
    function GetDeviceSelector(usagePage: Word; usageId: Word): HSTRING; overload; safecall;
    function GetDeviceSelector(usagePage: Word; usageId: Word; vendorId: Word; productId: Word): HSTRING; overload; safecall;
    function FromIdAsync(deviceId: HSTRING; accessMode: FileAccessMode): IAsyncOperation_1__HumanInterfaceDevice_IHidDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cConnectionSettings
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cConnectionSettings)]
  I2c_II2cConnectionSettings = interface(IInspectable)
  ['{F2DB1307-AB6F-4639-A767-54536DC3460F}']
    function get_SlaveAddress: Integer; safecall;
    procedure put_SlaveAddress(value: Integer); safecall;
    function get_BusSpeed: I2c_I2cBusSpeed; safecall;
    procedure put_BusSpeed(value: I2c_I2cBusSpeed); safecall;
    function get_SharingMode: I2c_I2cSharingMode; safecall;
    procedure put_SharingMode(value: I2c_I2cSharingMode); safecall;
    property BusSpeed: I2c_I2cBusSpeed read get_BusSpeed write put_BusSpeed;
    property SharingMode: I2c_I2cSharingMode read get_SharingMode write put_SharingMode;
    property SlaveAddress: Integer read get_SlaveAddress write put_SlaveAddress;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cConnectionSettingsFactory
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cConnectionSettings)]
  I2c_II2cConnectionSettingsFactory = interface(IInspectable)
  ['{81B586B3-9693-41B1-A243-DED4F6E66926}']
    function Create(slaveAddress: Integer): I2c_II2cConnectionSettings; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cDevice
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cDevice)]
  I2c_II2cDevice = interface(IInspectable)
  ['{8636C136-B9C5-4F70-9449-CC46DC6F57EB}']
    function get_DeviceId: HSTRING; safecall;
    function get_ConnectionSettings: I2c_II2cConnectionSettings; safecall;
    procedure Write(bufferSize: Cardinal; buffer: PByte); safecall;
    function WritePartial(bufferSize: Cardinal; buffer: PByte): I2c_I2cTransferResult; safecall;
    procedure Read(bufferSize: Cardinal; buffer: PByte); safecall;
    function ReadPartial(bufferSize: Cardinal; buffer: PByte): I2c_I2cTransferResult; safecall;
    procedure WriteRead(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    function WriteReadPartial(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte): I2c_I2cTransferResult; safecall;
    property ConnectionSettings: I2c_II2cConnectionSettings read get_ConnectionSettings;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cController
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cController)]
  I2c_II2cController = interface(IInspectable)
  ['{C48AB1B2-87A0-4166-8E3E-B4B8F97CD729}']
    function GetDevice(settings: I2c_II2cConnectionSettings): I2c_II2cDevice; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.I2c.I2cController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.I2c.II2cController>
  IIterator_1__I2c_II2cController = interface(IInspectable)
  ['{8F6822FC-E4EA-5B35-939A-27F3B3D550D2}']
    function get_Current: I2c_II2cController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PI2c_II2cController): Cardinal; safecall;
    property Current: I2c_II2cController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.I2c.I2cController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.I2c.II2cController>
  IIterable_1__I2c_II2cController = interface(IInspectable)
  ['{A5EE8233-2429-5B26-9A02-993E4E7EDFA9}']
    function First: IIterator_1__I2c_II2cController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>
  IVectorView_1__I2c_II2cController = interface(IInspectable)
  ['{FC2CE606-BAD0-592E-B954-ECA6ABC2F43D}']
    function GetAt(index: Cardinal): I2c_II2cController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: I2c_II2cController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PI2c_II2cController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.I2cController>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController = interface(IUnknown)
  ['{3B9D7CB1-AE0B-56AF-8ED5-6856B1E7CD5B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__I2c_II2cController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.I2cController>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.II2cController>>
  IAsyncOperation_1__IVectorView_1__I2c_II2cController = interface(IInspectable)
  ['{77F52FF7-ABA0-54BB-891A-49351A838E33}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController; safecall;
    function GetResults: IVectorView_1__I2c_II2cController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_II2cController read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.I2c.Provider.II2cDeviceProvider
  I2c_Provider_II2cDeviceProvider = interface(IInspectable)
  ['{AD342654-57E8-453E-8329-D1E447D103A9}']
    function get_DeviceId: HSTRING; safecall;
    procedure Write(bufferSize: Cardinal; buffer: PByte); safecall;
    function WritePartial(bufferSize: Cardinal; buffer: PByte): I2c_Provider_ProviderI2cTransferResult; safecall;
    procedure Read(bufferSize: Cardinal; buffer: PByte); safecall;
    function ReadPartial(bufferSize: Cardinal; buffer: PByte): I2c_Provider_ProviderI2cTransferResult; safecall;
    procedure WriteRead(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    function WriteReadPartial(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte): I2c_Provider_ProviderI2cTransferResult; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // UsedAPI Interface
  // Windows.Devices.I2c.Provider.IProviderI2cConnectionSettings
  I2c_Provider_IProviderI2cConnectionSettings = interface(IInspectable)
  ['{E9DB4E34-E510-44B7-809D-F2F85B555339}']
    function get_SlaveAddress: Integer; safecall;
    procedure put_SlaveAddress(value: Integer); safecall;
    function get_BusSpeed: I2c_Provider_ProviderI2cBusSpeed; safecall;
    procedure put_BusSpeed(value: I2c_Provider_ProviderI2cBusSpeed); safecall;
    function get_SharingMode: I2c_Provider_ProviderI2cSharingMode; safecall;
    procedure put_SharingMode(value: I2c_Provider_ProviderI2cSharingMode); safecall;
    property BusSpeed: I2c_Provider_ProviderI2cBusSpeed read get_BusSpeed write put_BusSpeed;
    property SharingMode: I2c_Provider_ProviderI2cSharingMode read get_SharingMode write put_SharingMode;
    property SlaveAddress: Integer read get_SlaveAddress write put_SlaveAddress;
  end;

  // UsedAPI Interface
  // Windows.Devices.I2c.Provider.II2cControllerProvider
  I2c_Provider_II2cControllerProvider = interface(IInspectable)
  ['{61C2BB82-4510-4163-A87C-4E15A9558980}']
    function GetDeviceProvider(settings: I2c_Provider_IProviderI2cConnectionSettings): I2c_Provider_II2cDeviceProvider; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IIterator_1__I2c_Provider_II2cControllerProvider = interface(IInspectable)
  ['{F6232961-C660-50A1-82E8-12892FCD91F7}']
    function get_Current: I2c_Provider_II2cControllerProvider; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PI2c_Provider_II2cControllerProvider): Cardinal; safecall;
    property Current: I2c_Provider_II2cControllerProvider read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IIterable_1__I2c_Provider_II2cControllerProvider = interface(IInspectable)
  ['{11341A6C-3A02-5F73-9DB8-C3EC5823E35D}']
    function First: IIterator_1__I2c_Provider_II2cControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>
  IVectorView_1__I2c_Provider_II2cControllerProvider = interface(IInspectable)
  ['{511F8A39-98CA-550D-AF25-1DF2C1193C01}']
    function GetAt(index: Cardinal): I2c_Provider_II2cControllerProvider; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: I2c_Provider_II2cControllerProvider; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PI2c_Provider_II2cControllerProvider): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>>
  AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider = interface(IUnknown)
  ['{771E22ED-DA9E-50BE-B730-A3BADA6BFB25}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.I2c.Provider.II2cControllerProvider>>
  IAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider = interface(IInspectable)
  ['{5FE77838-1125-5B2C-A281-E06A3DFBB76E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider; safecall;
    function GetResults: IVectorView_1__I2c_Provider_II2cControllerProvider; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__I2c_Provider_II2cControllerProvider read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.I2c.Provider.II2cProvider
  I2c_Provider_II2cProvider = interface(IInspectable)
  ['{6F13083E-BF62-4FE2-A95A-F08999669818}']
    function GetControllersAsync: IAsyncOperation_1__IVectorView_1__I2c_Provider_II2cControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.I2cController>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.II2cController>
  AsyncOperationCompletedHandler_1__I2c_II2cController = interface(IUnknown)
  ['{6FF64B72-A5AA-5986-B563-27612AFB373C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__I2c_II2cController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.I2cController>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.II2cController>
  IAsyncOperation_1__I2c_II2cController = interface(IInspectable)
  ['{A4FB1DD4-80C9-5A61-AE8D-C8A7AFC03275}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__I2c_II2cController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__I2c_II2cController; safecall;
    function GetResults: I2c_II2cController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__I2c_II2cController read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cController)]
  I2c_II2cControllerStatics = interface(IInspectable)
  ['{40FC0365-5F05-4E7E-84BD-100DB8E0AEC5}']
    function GetControllersAsync(provider: I2c_Provider_II2cProvider): IAsyncOperation_1__IVectorView_1__I2c_II2cController; safecall;
    function GetDefaultAsync: IAsyncOperation_1__I2c_II2cController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.I2cDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.I2c.II2cDevice>
  AsyncOperationCompletedHandler_1__I2c_II2cDevice = interface(IUnknown)
  ['{2DF5BB6A-5E73-5AE3-A0B2-22E1C9D8EF4D}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__I2c_II2cDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.I2cDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.I2c.II2cDevice>
  IAsyncOperation_1__I2c_II2cDevice = interface(IInspectable)
  ['{1E8A7CD8-E41B-5A41-82B1-80055012AE00}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__I2c_II2cDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__I2c_II2cDevice; safecall;
    function GetResults: I2c_II2cDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__I2c_II2cDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.I2c.II2cDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_I2c_I2cDevice)]
  I2c_II2cDeviceStatics = interface(IInspectable)
  ['{91A33BE3-7334-4512-96BC-FBAE9459F5F6}']
    function GetDeviceSelector: HSTRING; overload; safecall;
    function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; safecall;
    function FromIdAsync(deviceId: HSTRING; settings: I2c_II2cConnectionSettings): IAsyncOperation_1__I2c_II2cDevice; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Pwm.Provider.IPwmControllerProvider
  Pwm_Provider_IPwmControllerProvider = interface(IInspectable)
  ['{1300593B-E2E3-40A4-B7D9-48DFF0377A52}']
    function get_PinCount: Integer; safecall;
    function get_ActualFrequency: Double; safecall;
    function SetDesiredFrequency(frequency: Double): Double; safecall;
    function get_MaxFrequency: Double; safecall;
    function get_MinFrequency: Double; safecall;
    procedure AcquirePin(pin: Integer); safecall;
    procedure ReleasePin(pin: Integer); safecall;
    procedure EnablePin(pin: Integer); safecall;
    procedure DisablePin(pin: Integer); safecall;
    procedure SetPulseParameters(pin: Integer; dutyCycle: Double; invertPolarity: Boolean); safecall;
    property ActualFrequency: Double read get_ActualFrequency;
    property MaxFrequency: Double read get_MaxFrequency;
    property MinFrequency: Double read get_MinFrequency;
    property PinCount: Integer read get_PinCount;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.Provider.IProviderSpiConnectionSettings
  [WinRTClassNameAttribute(SWindows_Devices_Spi_Provider_ProviderSpiConnectionSettings)]
  Spi_Provider_IProviderSpiConnectionSettings = interface(IInspectable)
  ['{F6034550-A542-4EC0-9601-A4DD68F8697B}']
    function get_ChipSelectLine: Integer; safecall;
    procedure put_ChipSelectLine(value: Integer); safecall;
    function get_Mode: Spi_Provider_ProviderSpiMode; safecall;
    procedure put_Mode(value: Spi_Provider_ProviderSpiMode); safecall;
    function get_DataBitLength: Integer; safecall;
    procedure put_DataBitLength(value: Integer); safecall;
    function get_ClockFrequency: Integer; safecall;
    procedure put_ClockFrequency(value: Integer); safecall;
    function get_SharingMode: Spi_Provider_ProviderSpiSharingMode; safecall;
    procedure put_SharingMode(value: Spi_Provider_ProviderSpiSharingMode); safecall;
    property ChipSelectLine: Integer read get_ChipSelectLine write put_ChipSelectLine;
    property ClockFrequency: Integer read get_ClockFrequency write put_ClockFrequency;
    property DataBitLength: Integer read get_DataBitLength write put_DataBitLength;
    property Mode: Spi_Provider_ProviderSpiMode read get_Mode write put_Mode;
    property SharingMode: Spi_Provider_ProviderSpiSharingMode read get_SharingMode write put_SharingMode;
  end;

  // UsedAPI Interface
  // Windows.Devices.Spi.Provider.ISpiDeviceProvider
  Spi_Provider_ISpiDeviceProvider = interface(IInspectable)
  ['{0D1C3443-304B-405C-B4F7-F5AB1074461E}']
    function get_DeviceId: HSTRING; safecall;
    function get_ConnectionSettings: Spi_Provider_IProviderSpiConnectionSettings; safecall;
    procedure Write(bufferSize: Cardinal; buffer: PByte); safecall;
    procedure Read(bufferSize: Cardinal; buffer: PByte); safecall;
    procedure TransferSequential(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    procedure TransferFullDuplex(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    property ConnectionSettings: Spi_Provider_IProviderSpiConnectionSettings read get_ConnectionSettings;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // UsedAPI Interface
  // Windows.Devices.Spi.Provider.ISpiControllerProvider
  Spi_Provider_ISpiControllerProvider = interface(IInspectable)
  ['{C1686504-02CE-4226-A385-4F11FB04B41B}']
    function GetDeviceProvider(settings: Spi_Provider_IProviderSpiConnectionSettings): Spi_Provider_ISpiDeviceProvider; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.ILowLevelDevicesAggregateProvider
  [WinRTClassNameAttribute(SWindows_Devices_LowLevelDevicesAggregateProvider)]
  ILowLevelDevicesAggregateProvider = interface(IInspectable)
  ['{A73E561C-AAC1-4EC7-A852-479F7060D01F}']
    function get_AdcControllerProvider: Adc_Provider_IAdcControllerProvider; safecall;
    function get_PwmControllerProvider: Pwm_Provider_IPwmControllerProvider; safecall;
    function get_GpioControllerProvider: Gpio_Provider_IGpioControllerProvider; safecall;
    function get_I2cControllerProvider: I2c_Provider_II2cControllerProvider; safecall;
    function get_SpiControllerProvider: Spi_Provider_ISpiControllerProvider; safecall;
    property AdcControllerProvider: Adc_Provider_IAdcControllerProvider read get_AdcControllerProvider;
    property GpioControllerProvider: Gpio_Provider_IGpioControllerProvider read get_GpioControllerProvider;
    property I2cControllerProvider: I2c_Provider_II2cControllerProvider read get_I2cControllerProvider;
    property PwmControllerProvider: Pwm_Provider_IPwmControllerProvider read get_PwmControllerProvider;
    property SpiControllerProvider: Spi_Provider_ISpiControllerProvider read get_SpiControllerProvider;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.ILowLevelDevicesAggregateProviderFactory
  [WinRTClassNameAttribute(SWindows_Devices_LowLevelDevicesAggregateProvider)]
  ILowLevelDevicesAggregateProviderFactory = interface(IInspectable)
  ['{9AC4AAF6-3473-465E-96D5-36281A2C57AF}']
    function Create(adc: Adc_Provider_IAdcControllerProvider; pwm: Pwm_Provider_IPwmControllerProvider; gpio: Gpio_Provider_IGpioControllerProvider; i2c: I2c_Provider_II2cControllerProvider; spi: Spi_Provider_ISpiControllerProvider): ILowLevelDevicesAggregateProvider; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.ILowLevelDevicesController
  [WinRTClassNameAttribute(SWindows_Devices_LowLevelDevicesController)]
  ILowLevelDevicesController = interface(IInspectable)
  ['{2EC23DD4-179B-45DE-9B39-3AE02527DE52}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.ILowLevelDevicesControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_LowLevelDevicesController)]
  ILowLevelDevicesControllerStatics = interface(IInspectable)
  ['{093E926A-FCCB-4394-A697-19DE637C2DB3}']
    function get_DefaultProvider: ILowLevelDevicesAggregateProvider; safecall;
    procedure put_DefaultProvider(value: ILowLevelDevicesAggregateProvider); safecall;
    property DefaultProvider: ILowLevelDevicesAggregateProvider read get_DefaultProvider write put_DefaultProvider;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenButtonListener,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Object>
  TypedEventHandler_2__Input_IPenButtonListener__IInspectable = interface(IUnknown)
  ['{0A0EE5ED-041B-5569-B4A4-A1E58F1343A2}']
    procedure Invoke(sender: Input_IPenButtonListener; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Input.IPenTailButtonClickedEventArgs
  Input_IPenTailButtonClickedEventArgs = interface(IInspectable)
  ['{5D2FB7B6-6AD3-5D3E-AB29-05EA2410E390}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenButtonListener,Windows.Devices.Input.PenTailButtonClickedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonClickedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonClickedEventArgs = interface(IUnknown)
  ['{2EDA7109-F1C9-5F26-A054-3D25062CC0DE}']
    procedure Invoke(sender: Input_IPenButtonListener; args: Input_IPenTailButtonClickedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Input.IPenTailButtonDoubleClickedEventArgs
  Input_IPenTailButtonDoubleClickedEventArgs = interface(IInspectable)
  ['{846321A2-618A-5478-B04C-B358231DA4A7}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenButtonListener,Windows.Devices.Input.PenTailButtonDoubleClickedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonDoubleClickedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonDoubleClickedEventArgs = interface(IUnknown)
  ['{E6E58D94-6F7B-593F-81F0-033150B4432C}']
    procedure Invoke(sender: Input_IPenButtonListener; args: Input_IPenTailButtonDoubleClickedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Input.IPenTailButtonLongPressedEventArgs
  Input_IPenTailButtonLongPressedEventArgs = interface(IInspectable)
  ['{F37C606E-C60A-5F42-B818-A53112406C13}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenButtonListener,Windows.Devices.Input.PenTailButtonLongPressedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenButtonListener,Windows.Devices.Input.IPenTailButtonLongPressedEventArgs>
  TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonLongPressedEventArgs = interface(IUnknown)
  ['{CA6DAB1F-20D6-52B0-94CE-6DCC75A1A984}']
    procedure Invoke(sender: Input_IPenButtonListener; args: Input_IPenTailButtonLongPressedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenButtonListener
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenButtonListener)]
  Input_IPenButtonListener = interface(IInspectable)
  ['{8245C376-1EE3-53F7-B1F7-8334A16F2815}']
    function IsSupported: Boolean; safecall;
    function add_IsSupportedChanged(handler: TypedEventHandler_2__Input_IPenButtonListener__IInspectable): EventRegistrationToken; safecall;
    procedure remove_IsSupportedChanged(token: EventRegistrationToken); safecall;
    function add_TailButtonClicked(handler: TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonClickedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TailButtonClicked(token: EventRegistrationToken); safecall;
    function add_TailButtonDoubleClicked(handler: TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonDoubleClickedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TailButtonDoubleClicked(token: EventRegistrationToken); safecall;
    function add_TailButtonLongPressed(handler: TypedEventHandler_2__Input_IPenButtonListener__Input_IPenTailButtonLongPressedEventArgs): EventRegistrationToken; safecall;
    procedure remove_TailButtonLongPressed(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenButtonListenerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenButtonListener)]
  Input_IPenButtonListenerStatics = interface(IInspectable)
  ['{19A8A584-862F-5F69-BFEA-05F6584F133F}']
    function GetDefault: Input_IPenButtonListener; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenDevice2
  Input_IPenDevice2 = interface(IInspectable)
  ['{0207D327-7FB8-5566-8C34-F8342037B7F9}']
    function get_SimpleHapticsController: Haptics_ISimpleHapticsController; safecall;
    property SimpleHapticsController: Haptics_ISimpleHapticsController read get_SimpleHapticsController;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenDevice)]
  Input_IPenDeviceStatics = interface(IInspectable)
  ['{9DFBBE01-0966-5180-BCB4-B85060E39479}']
    function GetFromPointerId(pointerId: Cardinal): Input_IPenDevice; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenDockListener,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Object>
  TypedEventHandler_2__Input_IPenDockListener__IInspectable = interface(IUnknown)
  ['{7CEAE82F-499A-5B31-A1D8-3B11C53C7871}']
    procedure Invoke(sender: Input_IPenDockListener; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Input.IPenDockedEventArgs
  Input_IPenDockedEventArgs = interface(IInspectable)
  ['{FD4277C6-CA63-5D4E-9ED3-A28A54521C8C}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenDockListener,Windows.Devices.Input.PenDockedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Windows.Devices.Input.IPenDockedEventArgs>
  TypedEventHandler_2__Input_IPenDockListener__Input_IPenDockedEventArgs = interface(IUnknown)
  ['{19786A6C-8E23-5DE7-A773-E711A5A068C5}']
    procedure Invoke(sender: Input_IPenDockListener; args: Input_IPenDockedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Input.IPenUndockedEventArgs
  Input_IPenUndockedEventArgs = interface(IInspectable)
  ['{CCD09150-261B-59E6-A5D4-C1964CD03FEB}']
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.PenDockListener,Windows.Devices.Input.PenUndockedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Input.IPenDockListener,Windows.Devices.Input.IPenUndockedEventArgs>
  TypedEventHandler_2__Input_IPenDockListener__Input_IPenUndockedEventArgs = interface(IUnknown)
  ['{51DBA508-3194-5C91-A2E7-F94637E75A13}']
    procedure Invoke(sender: Input_IPenDockListener; args: Input_IPenUndockedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenDockListener
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenDockListener)]
  Input_IPenDockListener = interface(IInspectable)
  ['{759F4D90-1DC0-55CB-AD18-B9101456F592}']
    function IsSupported: Boolean; safecall;
    function add_IsSupportedChanged(handler: TypedEventHandler_2__Input_IPenDockListener__IInspectable): EventRegistrationToken; safecall;
    procedure remove_IsSupportedChanged(token: EventRegistrationToken); safecall;
    function add_Docked(handler: TypedEventHandler_2__Input_IPenDockListener__Input_IPenDockedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Docked(token: EventRegistrationToken); safecall;
    function add_Undocked(handler: TypedEventHandler_2__Input_IPenDockListener__Input_IPenUndockedEventArgs): EventRegistrationToken; safecall;
    procedure remove_Undocked(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Input.IPenDockListenerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Input_PenDockListener)]
  Input_IPenDockListenerStatics = interface(IInspectable)
  ['{CAB75E9A-0016-5C72-969E-A97E11992A93}']
    function GetDefault: Input_IPenDockListener; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Input.PointerDevice>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Input.IPointerDevice>
  IIterator_1__Input_IPointerDevice = interface(IInspectable)
  ['{DE94641C-7960-5FCD-ABE8-D6BA609EF7D3}']
    function get_Current: Input_IPointerDevice; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PInput_IPointerDevice): Cardinal; safecall;
    property Current: Input_IPointerDevice read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Input.PointerDevice>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Input.IPointerDevice>
  IIterable_1__Input_IPointerDevice = interface(IInspectable)
  ['{AD26662C-845B-5C6D-AEAA-406F48C21AE9}']
    function First: IIterator_1__Input_IPointerDevice; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Input.IPointerDevice>
  IVectorView_1__Input_IPointerDevice = interface(IInspectable)
  ['{84EBCA20-739B-5879-A514-CA20C1771BFE}']
    function GetAt(index: Cardinal): Input_IPointerDevice; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Input_IPointerDevice; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInput_IPointerDevice): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownCameraIntrinsicsPropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownCameraIntrinsicsProperties)]
  Perception_IKnownCameraIntrinsicsPropertiesStatics = interface(IInspectable)
  ['{08C03978-437A-4D97-A663-FD3195600249}']
    function get_FocalLength: HSTRING; safecall;
    function get_PrincipalPoint: HSTRING; safecall;
    function get_RadialDistortion: HSTRING; safecall;
    function get_TangentialDistortion: HSTRING; safecall;
    property FocalLength: HSTRING read get_FocalLength;
    property PrincipalPoint: HSTRING read get_PrincipalPoint;
    property RadialDistortion: HSTRING read get_RadialDistortion;
    property TangentialDistortion: HSTRING read get_TangentialDistortion;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionColorFrameSourcePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionColorFrameSourceProperties)]
  Perception_IKnownPerceptionColorFrameSourcePropertiesStatics = interface(IInspectable)
  ['{5DF1CCA2-01F8-4A87-B859-D5E5B7E1DE4B}']
    function get_Exposure: HSTRING; safecall;
    function get_AutoExposureEnabled: HSTRING; safecall;
    function get_ExposureCompensation: HSTRING; safecall;
    property AutoExposureEnabled: HSTRING read get_AutoExposureEnabled;
    property Exposure: HSTRING read get_Exposure;
    property ExposureCompensation: HSTRING read get_ExposureCompensation;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionDepthFrameSourcePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionDepthFrameSourceProperties)]
  Perception_IKnownPerceptionDepthFrameSourcePropertiesStatics = interface(IInspectable)
  ['{5DF1CCA2-01F8-4A87-B859-D5E5B7E1DE4A}']
    function get_MinDepth: HSTRING; safecall;
    function get_MaxDepth: HSTRING; safecall;
    property MaxDepth: HSTRING read get_MaxDepth;
    property MinDepth: HSTRING read get_MinDepth;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionFrameSourceProperties)]
  Perception_IKnownPerceptionFrameSourcePropertiesStatics = interface(IInspectable)
  ['{5DF1CCA2-01F8-4A87-B859-D5E5B7E1DE47}']
    function get_Id: HSTRING; safecall;
    function get_PhysicalDeviceIds: HSTRING; safecall;
    function get_FrameKind: HSTRING; safecall;
    function get_DeviceModelVersion: HSTRING; safecall;
    function get_EnclosureLocation: HSTRING; safecall;
    property DeviceModelVersion: HSTRING read get_DeviceModelVersion;
    property EnclosureLocation: HSTRING read get_EnclosureLocation;
    property FrameKind: HSTRING read get_FrameKind;
    property Id: HSTRING read get_Id;
    property PhysicalDeviceIds: HSTRING read get_PhysicalDeviceIds;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionFrameSourceProperties)]
  Perception_IKnownPerceptionFrameSourcePropertiesStatics2 = interface(IInspectable)
  ['{A9C86871-05DC-4A4D-8A5C-A4ECF26BBC46}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionInfraredFrameSourcePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionInfraredFrameSourceProperties)]
  Perception_IKnownPerceptionInfraredFrameSourcePropertiesStatics = interface(IInspectable)
  ['{5DF1CCA2-01F8-4A87-B859-D5E5B7E1DE49}']
    function get_Exposure: HSTRING; safecall;
    function get_AutoExposureEnabled: HSTRING; safecall;
    function get_ExposureCompensation: HSTRING; safecall;
    function get_ActiveIlluminationEnabled: HSTRING; safecall;
    function get_AmbientSubtractionEnabled: HSTRING; safecall;
    function get_StructureLightPatternEnabled: HSTRING; safecall;
    function get_InterleavedIlluminationEnabled: HSTRING; safecall;
    property ActiveIlluminationEnabled: HSTRING read get_ActiveIlluminationEnabled;
    property AmbientSubtractionEnabled: HSTRING read get_AmbientSubtractionEnabled;
    property AutoExposureEnabled: HSTRING read get_AutoExposureEnabled;
    property Exposure: HSTRING read get_Exposure;
    property ExposureCompensation: HSTRING read get_ExposureCompensation;
    property InterleavedIlluminationEnabled: HSTRING read get_InterleavedIlluminationEnabled;
    property StructureLightPatternEnabled: HSTRING read get_StructureLightPatternEnabled;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionVideoFrameSourcePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionVideoFrameSourceProperties)]
  Perception_IKnownPerceptionVideoFrameSourcePropertiesStatics = interface(IInspectable)
  ['{5DF1CCA2-01F8-4A87-B859-D5E5B7E1DE48}']
    function get_VideoProfile: HSTRING; safecall;
    function get_SupportedVideoProfiles: HSTRING; safecall;
    function get_AvailableVideoProfiles: HSTRING; safecall;
    function get_IsMirrored: HSTRING; safecall;
    function get_CameraIntrinsics: HSTRING; safecall;
    property AvailableVideoProfiles: HSTRING read get_AvailableVideoProfiles;
    property CameraIntrinsics: HSTRING read get_CameraIntrinsics;
    property IsMirrored: HSTRING read get_IsMirrored;
    property SupportedVideoProfiles: HSTRING read get_SupportedVideoProfiles;
    property VideoProfile: HSTRING read get_VideoProfile;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IKnownPerceptionVideoProfilePropertiesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_KnownPerceptionVideoProfileProperties)]
  Perception_IKnownPerceptionVideoProfilePropertiesStatics = interface(IInspectable)
  ['{8F08E2E7-5A76-43E3-A13A-DA3D91A9EF98}']
    function get_BitmapPixelFormat: HSTRING; safecall;
    function get_BitmapAlphaMode: HSTRING; safecall;
    function get_Width: HSTRING; safecall;
    function get_Height: HSTRING; safecall;
    function get_FrameDuration: HSTRING; safecall;
    property BitmapAlphaMode: HSTRING read get_BitmapAlphaMode;
    property BitmapPixelFormat: HSTRING read get_BitmapPixelFormat;
    property FrameDuration: HSTRING read get_FrameDuration;
    property Height: HSTRING read get_Height;
    property Width: HSTRING read get_Width;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrame
  Perception_IPerceptionColorFrame = interface(IInspectable)
  ['{FE621549-2CBF-4F94-9861-F817EA317747}']
    function get_VideoFrame: IVideoFrame; safecall;
    property VideoFrame: IVideoFrame read get_VideoFrame;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameArrivedEventArgs
  Perception_IPerceptionColorFrameArrivedEventArgs = interface(IInspectable)
  ['{8FAD02D5-86F7-4D8D-B966-5A3761BA9F59}']
    function get_RelativeTime: TimeSpan; safecall;
    function TryOpenFrame: Perception_IPerceptionColorFrame; safecall;
    property RelativeTime: TimeSpan read get_RelativeTime;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameReader,Windows.Devices.Perception.PerceptionColorFrameArrivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameReader,Windows.Devices.Perception.IPerceptionColorFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameReader__Perception_IPerceptionColorFrameArrivedEventArgs = interface(IUnknown)
  ['{A4A50EA5-778D-5056-A1CF-546A1BE2C010}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameReader; args: Perception_IPerceptionColorFrameArrivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameSource,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable = interface(IUnknown)
  ['{023444D9-7B47-5497-9569-4399FAF96717}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameSource; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs
  Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface(IInspectable)
  ['{6C68E068-BCF1-4ECC-B891-7625D1244B6B}']
    function get_CollectionChange: CollectionChange; safecall;
    function get_Key: HSTRING; safecall;
    property CollectionChange_: CollectionChange read get_CollectionChange;
    property Key: HSTRING read get_Key;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameSource,Windows.Devices.Perception.PerceptionFrameSourcePropertiesChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface(IUnknown)
  ['{B2C3A488-7ED9-5110-804A-9792EF7F26BE}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameSource; args: Perception_IPerceptionFrameSourcePropertiesChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionVideoProfile
  Perception_IPerceptionVideoProfile = interface(IInspectable)
  ['{75763EA3-011A-470E-8225-6F05ADE25648}']
    function get_BitmapPixelFormat: Imaging_BitmapPixelFormat; safecall;
    function get_BitmapAlphaMode: Imaging_BitmapAlphaMode; safecall;
    function get_Width: Integer; safecall;
    function get_Height: Integer; safecall;
    function get_FrameDuration: TimeSpan; safecall;
    function IsEqual(other: Perception_IPerceptionVideoProfile): Boolean; safecall;
    property BitmapAlphaMode: Imaging_BitmapAlphaMode read get_BitmapAlphaMode;
    property BitmapPixelFormat: Imaging_BitmapPixelFormat read get_BitmapPixelFormat;
    property FrameDuration: TimeSpan read get_FrameDuration;
    property Height: Integer read get_Height;
    property Width: Integer read get_Width;
  end deprecated;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.PerceptionVideoProfile>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IIterator_1__Perception_IPerceptionVideoProfile = interface(IInspectable)
  ['{38CE8062-7079-5D7B-841F-9AA4580FD5F1}']
    function get_Current: Perception_IPerceptionVideoProfile; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPerception_IPerceptionVideoProfile): Cardinal; safecall;
    property Current: Perception_IPerceptionVideoProfile read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.PerceptionVideoProfile>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IIterable_1__Perception_IPerceptionVideoProfile = interface(IInspectable)
  ['{F6AEA351-EB9B-564D-B10A-06673094ACC8}']
    function First: IIterator_1__Perception_IPerceptionVideoProfile; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionVideoProfile>
  IVectorView_1__Perception_IPerceptionVideoProfile = interface(IInspectable)
  ['{78D23A35-FAE7-593F-A5CA-5C411AA74009}']
    function GetAt(index: Cardinal): Perception_IPerceptionVideoProfile; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Perception_IPerceptionVideoProfile; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPerception_IPerceptionVideoProfile): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionControlSession,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionControlSession,Object>
  TypedEventHandler_2__Perception_IPerceptionControlSession__IInspectable = interface(IUnknown)
  ['{ABC21152-2495-5E8C-AED3-7DC55309AC08}']
    procedure Invoke(sender: Perception_IPerceptionControlSession; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult
  Perception_IPerceptionFrameSourcePropertyChangeResult = interface(IInspectable)
  ['{1E33390A-3C90-4D22-B898-F42BBA6418FF}']
    function get_Status: Perception_PerceptionFrameSourcePropertyChangeStatus; safecall;
    function get_NewValue: IInspectable; safecall;
    property NewValue: IInspectable read get_NewValue;
    property Status: Perception_PerceptionFrameSourcePropertyChangeStatus read get_Status;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionFrameSourcePropertyChangeResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult = interface(IUnknown)
  ['{3A06099C-DBA6-58A5-8464-E2326896841A}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionFrameSourcePropertyChangeResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionFrameSourcePropertyChangeResult>
  IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult = interface(IInspectable)
  ['{4A7BCB69-2B09-55D1-AF68-B5AA5C2C6471}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
    function GetResults: Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionFrameSourcePropertyChangeResult read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionControlSession
  Perception_IPerceptionControlSession = interface(IInspectable)
  ['{99998653-5A3D-417F-9239-F1889E548B48}']
    function add_ControlLost(handler: TypedEventHandler_2__Perception_IPerceptionControlSession__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ControlLost(token: EventRegistrationToken); safecall;
    function TrySetPropertyAsync(name: HSTRING; value: IInspectable): IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrame
  Perception_IPerceptionDepthFrame = interface(IInspectable)
  ['{A37B81FC-9906-4FFD-9161-0024B360B657}']
    function get_VideoFrame: IVideoFrame; safecall;
    property VideoFrame: IVideoFrame read get_VideoFrame;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics
  Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface(IInspectable)
  ['{6548CA01-86DE-5BE1-6582-807FCF4C95CF}']
    function UnprojectPixelAtCorrelatedDepth(pixelCoordinate: TPointF; depthFrame: Perception_IPerceptionDepthFrame): Numerics_Vector3; safecall;
    procedure UnprojectPixelsAtCorrelatedDepth(sourceCoordinatesSize: Cardinal; sourceCoordinates: PPointF; depthFrame: Perception_IPerceptionDepthFrame; resultsSize: Cardinal; results: PNumerics_Vector3); safecall;
    function UnprojectRegionPixelsAtCorrelatedDepthAsync(region: TRectF; depthFrame: Perception_IPerceptionDepthFrame; resultsSize: Cardinal; results: PNumerics_Vector3): IAsyncAction; safecall;
    function UnprojectAllPixelsAtCorrelatedDepthAsync(depthFrame: Perception_IPerceptionDepthFrame; resultsSize: Cardinal; results: PNumerics_Vector3): IAsyncAction; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionDepthCorrelatedCameraIntrinsics>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface(IUnknown)
  ['{F396602A-3D8D-5FD5-99E3-1D3630BE5938}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionDepthCorrelatedCameraIntrinsics>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCameraIntrinsics>
  IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics = interface(IInspectable)
  ['{702B0F49-A742-5C3A-ABD6-77F9999B8A09}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics; safecall;
    function GetResults: Perception_IPerceptionDepthCorrelatedCameraIntrinsics; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameSource,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable = interface(IUnknown)
  ['{135BA76A-AB44-5F69-B208-E732CCE9403B}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameSource; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameSource,Windows.Devices.Perception.PerceptionFrameSourcePropertiesChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface(IUnknown)
  ['{188FDEF2-D829-548B-A89D-38A34C5CB641}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameSource; args: Perception_IPerceptionFrameSourcePropertiesChangedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper
  Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface(IInspectable)
  ['{5B4D9D1D-B5F6-469C-B8C2-B97A45E6863B}']
    function MapPixelToTarget(sourcePixelCoordinate: TPointF; depthFrame: Perception_IPerceptionDepthFrame): TPointF; safecall;
    procedure MapPixelsToTarget(sourceCoordinatesSize: Cardinal; sourceCoordinates: PPointF; depthFrame: Perception_IPerceptionDepthFrame; resultsSize: Cardinal; results: PPointF); safecall;
    function MapRegionOfPixelsToTargetAsync(region: TRectF; depthFrame: Perception_IPerceptionDepthFrame; targetCoordinatesSize: Cardinal; targetCoordinates: PPointF): IAsyncAction; safecall;
    function MapAllPixelsToTargetAsync(depthFrame: Perception_IPerceptionDepthFrame; targetCoordinatesSize: Cardinal; targetCoordinates: PPointF): IAsyncAction; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionDepthCorrelatedCoordinateMapper>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface(IUnknown)
  ['{48DEEDA0-684D-51E6-B07C-D234D1006BFC}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionDepthCorrelatedCoordinateMapper>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthCorrelatedCoordinateMapper>
  IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper = interface(IInspectable)
  ['{F04B9D99-C0D5-5B48-9AE5-9802093CB45E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper; safecall;
    function GetResults: Perception_IPerceptionDepthCorrelatedCoordinateMapper; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameArrivedEventArgs
  Perception_IPerceptionDepthFrameArrivedEventArgs = interface(IInspectable)
  ['{443D25B2-B282-4637-9173-AC978435C985}']
    function get_RelativeTime: TimeSpan; safecall;
    function TryOpenFrame: Perception_IPerceptionDepthFrame; safecall;
    property RelativeTime: TimeSpan read get_RelativeTime;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameReader,Windows.Devices.Perception.PerceptionDepthFrameArrivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameReader,Windows.Devices.Perception.IPerceptionDepthFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameReader__Perception_IPerceptionDepthFrameArrivedEventArgs = interface(IUnknown)
  ['{4D529B7E-EEA0-511B-8285-47E8C85D0295}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameReader; args: Perception_IPerceptionDepthFrameArrivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameReader
  Perception_IPerceptionDepthFrameReader = interface(IInspectable)
  ['{B1A3C09F-299B-4612-A4F7-270F25A096EC}']
    function add_FrameArrived(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameReader__Perception_IPerceptionDepthFrameArrivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_FrameArrived(token: EventRegistrationToken); safecall;
    function get_Source: Perception_IPerceptionDepthFrameSource; safecall;
    function get_IsPaused: Boolean; safecall;
    procedure put_IsPaused(value: Boolean); safecall;
    function TryReadLatestFrame: Perception_IPerceptionDepthFrame; safecall;
    property IsPaused: Boolean read get_IsPaused write put_IsPaused;
    property Source: Perception_IPerceptionDepthFrameSource read get_Source;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSource
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionDepthFrameSource)]
  Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{79D433D6-47FB-4DF1-BFC9-F01D40BD9942}']
    function add_AvailableChanged(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AvailableChanged(token: EventRegistrationToken); safecall;
    function add_ActiveChanged(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ActiveChanged(token: EventRegistrationToken); safecall;
    function add_PropertiesChanged(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PropertiesChanged(token: EventRegistrationToken); safecall;
    function add_VideoProfileChanged(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_VideoProfileChanged(token: EventRegistrationToken); safecall;
    function add_CameraIntrinsicsChanged(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_CameraIntrinsicsChanged(token: EventRegistrationToken); safecall;
    function get_Id: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_DeviceKind: HSTRING; safecall;
    function get_Available: Boolean; safecall;
    function get_Active: Boolean; safecall;
    function get_IsControlled: Boolean; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    function get_SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_VideoProfile: Perception_IPerceptionVideoProfile; safecall;
    function get_CameraIntrinsics: Core_ICameraIntrinsics; safecall;
    function AcquireControlSession: Perception_IPerceptionControlSession; safecall;
    function CanControlIndependentlyFrom(targetId: HSTRING): Boolean; safecall;
    function IsCorrelatedWith(targetId: HSTRING): Boolean; safecall;
    function TryGetTransformTo(targetId: HSTRING; out a_result: Numerics_Matrix4x4): Boolean; safecall;
    function TryGetDepthCorrelatedCameraIntrinsicsAsync(target: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics; safecall;
    function TryGetDepthCorrelatedCoordinateMapperAsync(targetId: HSTRING; depthFrameSourceToMapWith: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper; safecall;
    function TrySetVideoProfileAsync(controlSession: Perception_IPerceptionControlSession; profile: Perception_IPerceptionVideoProfile): IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
    function OpenReader: Perception_IPerceptionDepthFrameReader; safecall;
    property Active: Boolean read get_Active;
    property Available: Boolean read get_Available;
    property AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_AvailableVideoProfiles;
    property CameraIntrinsics: Core_ICameraIntrinsics read get_CameraIntrinsics;
    property DeviceKind: HSTRING read get_DeviceKind;
    property DisplayName: HSTRING read get_DisplayName;
    property Id: HSTRING read get_Id;
    property IsControlled: Boolean read get_IsControlled;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_SupportedVideoProfiles;
    property VideoProfile: Perception_IPerceptionVideoProfile read get_VideoProfile;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSource
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionColorFrameSource)]
  Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{DC6DBA7C-0B58-468D-9CA1-6DB04CC0477C}']
    function add_AvailableChanged(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AvailableChanged(token: EventRegistrationToken); safecall;
    function add_ActiveChanged(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ActiveChanged(token: EventRegistrationToken); safecall;
    function add_PropertiesChanged(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PropertiesChanged(token: EventRegistrationToken); safecall;
    function add_VideoProfileChanged(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_VideoProfileChanged(token: EventRegistrationToken); safecall;
    function add_CameraIntrinsicsChanged(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_CameraIntrinsicsChanged(token: EventRegistrationToken); safecall;
    function get_Id: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_DeviceKind: HSTRING; safecall;
    function get_Available: Boolean; safecall;
    function get_Active: Boolean; safecall;
    function get_IsControlled: Boolean; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    function get_SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_VideoProfile: Perception_IPerceptionVideoProfile; safecall;
    function get_CameraIntrinsics: Core_ICameraIntrinsics; safecall;
    function AcquireControlSession: Perception_IPerceptionControlSession; safecall;
    function CanControlIndependentlyFrom(targetId: HSTRING): Boolean; safecall;
    function IsCorrelatedWith(targetId: HSTRING): Boolean; safecall;
    function TryGetTransformTo(targetId: HSTRING; out a_result: Numerics_Matrix4x4): Boolean; safecall;
    function TryGetDepthCorrelatedCameraIntrinsicsAsync(correlatedDepthFrameSource: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics; safecall;
    function TryGetDepthCorrelatedCoordinateMapperAsync(targetSourceId: HSTRING; correlatedDepthFrameSource: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper; safecall;
    function TrySetVideoProfileAsync(controlSession: Perception_IPerceptionControlSession; profile: Perception_IPerceptionVideoProfile): IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
    function OpenReader: Perception_IPerceptionColorFrameReader; safecall;
    property Active: Boolean read get_Active;
    property Available: Boolean read get_Available;
    property AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_AvailableVideoProfiles;
    property CameraIntrinsics: Core_ICameraIntrinsics read get_CameraIntrinsics;
    property DeviceKind: HSTRING read get_DeviceKind;
    property DisplayName: HSTRING read get_DisplayName;
    property Id: HSTRING read get_Id;
    property IsControlled: Boolean read get_IsControlled;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_SupportedVideoProfiles;
    property VideoProfile: Perception_IPerceptionVideoProfile read get_VideoProfile;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameReader
  Perception_IPerceptionColorFrameReader = interface(IInspectable)
  ['{7650F56E-B9F5-461B-83AD-F222AF2AAADC}']
    function add_FrameArrived(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameReader__Perception_IPerceptionColorFrameArrivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_FrameArrived(token: EventRegistrationToken); safecall;
    function get_Source: Perception_IPerceptionColorFrameSource; safecall;
    function get_IsPaused: Boolean; safecall;
    procedure put_IsPaused(value: Boolean); safecall;
    function TryReadLatestFrame: Perception_IPerceptionColorFrame; safecall;
    property IsPaused: Boolean read get_IsPaused write put_IsPaused;
    property Source: Perception_IPerceptionColorFrameSource read get_Source;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSource2
  Perception_IPerceptionColorFrameSource2 = interface(IInspectable)
  ['{F88008E5-5631-45ED-AD98-8C6AA04CFB91}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSourceAddedEventArgs
  Perception_IPerceptionColorFrameSourceAddedEventArgs = interface(IInspectable)
  ['{D16BF4E6-DA24-442C-BBD5-55549B5B94F3}']
    function get_FrameSource: Perception_IPerceptionColorFrameSource; safecall;
    property FrameSource: Perception_IPerceptionColorFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSourceRemovedEventArgs
  Perception_IPerceptionColorFrameSourceRemovedEventArgs = interface(IInspectable)
  ['{D277FA69-EB4C-42EF-BA4F-288F615C93C1}']
    function get_FrameSource: Perception_IPerceptionColorFrameSource; safecall;
    property FrameSource: Perception_IPerceptionColorFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameSourceWatcher,Windows.Devices.Perception.PerceptionColorFrameSourceAddedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Windows.Devices.Perception.IPerceptionColorFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceAddedEventArgs = interface(IUnknown)
  ['{7202E817-22B8-5E7B-86B5-C4A90CCC23AA}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameSourceWatcher; args: Perception_IPerceptionColorFrameSourceAddedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameSourceWatcher,Windows.Devices.Perception.PerceptionColorFrameSourceRemovedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Windows.Devices.Perception.IPerceptionColorFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceRemovedEventArgs = interface(IUnknown)
  ['{C7131DDD-FF22-5FB7-ADA0-961E3B28917B}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameSourceWatcher; args: Perception_IPerceptionColorFrameSourceRemovedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionColorFrameSourceWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable = interface(IUnknown)
  ['{B3F5BF64-7FC0-5D8C-978C-A38D5B18A51D}']
    procedure Invoke(sender: Perception_IPerceptionColorFrameSourceWatcher; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSourceWatcher
  Perception_IPerceptionColorFrameSourceWatcher = interface(IInspectable)
  ['{96BD1392-E667-40C4-89F9-1462DEA6A9CC}']
    function add_SourceAdded(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceAddedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceAdded(token: EventRegistrationToken); safecall;
    function add_SourceRemoved(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__Perception_IPerceptionColorFrameSourceRemovedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceRemoved(token: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(token: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__Perception_IPerceptionColorFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(token: EventRegistrationToken); safecall;
    function get_Status: DeviceWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: DeviceWatcherStatus read get_Status;
  end deprecated;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.PerceptionColorFrameSource>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IIterator_1__Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{24089F00-BA6D-50D4-AC46-F288755E4181}']
    function get_Current: Perception_IPerceptionColorFrameSource; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPerception_IPerceptionColorFrameSource): Cardinal; safecall;
    property Current: Perception_IPerceptionColorFrameSource read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.PerceptionColorFrameSource>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IIterable_1__Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{DB18069E-7B5A-54C3-A627-D56F9517FDF5}']
    function First: IIterator_1__Perception_IPerceptionColorFrameSource; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IVectorView_1__Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{82FDFAC9-2B68-56EA-944D-1AAD4C421424}']
    function GetAt(index: Cardinal): Perception_IPerceptionColorFrameSource; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Perception_IPerceptionColorFrameSource; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPerception_IPerceptionColorFrameSource): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionColorFrameSource>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource = interface(IUnknown)
  ['{0A36A7AF-DA9E-553F-8DC5-E89D705BB40B}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionColorFrameSource>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionColorFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{33845B5F-D59E-5271-BB68-F74E9D6A538D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource; safecall;
    function GetResults: IVectorView_1__Perception_IPerceptionColorFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionColorFrameSource read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionColorFrameSource>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource = interface(IUnknown)
  ['{3B56ACC2-E275-54FB-BE08-9FDC8F1A1E10}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionColorFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionColorFrameSource>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionColorFrameSource>
  IAsyncOperation_1__Perception_IPerceptionColorFrameSource = interface(IInspectable)
  ['{9647FEC8-2C56-5348-86C8-A9C3A97FB944}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource; safecall;
    function GetResults: Perception_IPerceptionColorFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionColorFrameSource read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionFrameSourceAccessStatus>
  AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus = interface(IUnknown)
  ['{62744EA4-3447-5722-AB5E-02567B4FCEEB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionFrameSourceAccessStatus>
  IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus = interface(IInspectable)
  ['{2C2F22A8-F383-5802-BA2C-0CBBCD989C9A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus; safecall;
    function GetResults: Perception_PerceptionFrameSourceAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_PerceptionFrameSourceAccessStatus read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionColorFrameSourceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionColorFrameSource)]
  Perception_IPerceptionColorFrameSourceStatics = interface(IInspectable)
  ['{5DF3CCA2-01F8-4A87-B859-D5E5B7E1DE49}']
    function CreateWatcher: Perception_IPerceptionColorFrameSourceWatcher; safecall;
    function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource; safecall;
    function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionColorFrameSource; safecall;
    function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSource2
  Perception_IPerceptionDepthFrameSource2 = interface(IInspectable)
  ['{E3D23D2E-6E2C-4E6D-91D9-704CD8DFF79D}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSourceAddedEventArgs
  Perception_IPerceptionDepthFrameSourceAddedEventArgs = interface(IInspectable)
  ['{93A48168-8BF8-45D2-A2F8-4AC0931CC7A6}']
    function get_FrameSource: Perception_IPerceptionDepthFrameSource; safecall;
    property FrameSource: Perception_IPerceptionDepthFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSourceRemovedEventArgs
  Perception_IPerceptionDepthFrameSourceRemovedEventArgs = interface(IInspectable)
  ['{A0C0CC4D-E96C-4D81-86DD-38B95E49C6DF}']
    function get_FrameSource: Perception_IPerceptionDepthFrameSource; safecall;
    property FrameSource: Perception_IPerceptionDepthFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.PerceptionDepthFrameSourceAddedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.IPerceptionDepthFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceAddedEventArgs = interface(IUnknown)
  ['{A3C1E25F-3574-5A27-A791-16E1BCC424F4}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameSourceWatcher; args: Perception_IPerceptionDepthFrameSourceAddedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.PerceptionDepthFrameSourceRemovedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Windows.Devices.Perception.IPerceptionDepthFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceRemovedEventArgs = interface(IUnknown)
  ['{5CF5FAF7-0785-5589-A621-089D900412C8}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameSourceWatcher; args: Perception_IPerceptionDepthFrameSourceRemovedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionDepthFrameSourceWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable = interface(IUnknown)
  ['{C5EFA976-D948-50C7-8555-664190F9A968}']
    procedure Invoke(sender: Perception_IPerceptionDepthFrameSourceWatcher; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSourceWatcher
  Perception_IPerceptionDepthFrameSourceWatcher = interface(IInspectable)
  ['{780E96D1-8D02-4D2B-ADA4-5BA624A0EB10}']
    function add_SourceAdded(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceAddedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceAdded(token: EventRegistrationToken); safecall;
    function add_SourceRemoved(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__Perception_IPerceptionDepthFrameSourceRemovedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceRemoved(token: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(token: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__Perception_IPerceptionDepthFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(token: EventRegistrationToken); safecall;
    function get_Status: DeviceWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: DeviceWatcherStatus read get_Status;
  end deprecated;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.PerceptionDepthFrameSource>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IIterator_1__Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{20CFF8C2-7844-54E5-AE4F-57E7768F9B69}']
    function get_Current: Perception_IPerceptionDepthFrameSource; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPerception_IPerceptionDepthFrameSource): Cardinal; safecall;
    property Current: Perception_IPerceptionDepthFrameSource read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.PerceptionDepthFrameSource>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IIterable_1__Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{8A07E1E8-5A02-585B-A26E-AD79BEAA94CF}']
    function First: IIterator_1__Perception_IPerceptionDepthFrameSource; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IVectorView_1__Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{FFF44896-404D-5542-9542-55332E49F017}']
    function GetAt(index: Cardinal): Perception_IPerceptionDepthFrameSource; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Perception_IPerceptionDepthFrameSource; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPerception_IPerceptionDepthFrameSource): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionDepthFrameSource>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = interface(IUnknown)
  ['{C06E62A4-965B-5A29-9732-8AC8669B585E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionDepthFrameSource>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{E20A534D-D406-5964-8465-E6DC75C5821D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource; safecall;
    function GetResults: IVectorView_1__Perception_IPerceptionDepthFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionDepthFrameSource read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionDepthFrameSource>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource = interface(IUnknown)
  ['{B48CB886-3476-58D9-B76D-FDA6B3E81F54}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionDepthFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionDepthFrameSource>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionDepthFrameSource>
  IAsyncOperation_1__Perception_IPerceptionDepthFrameSource = interface(IInspectable)
  ['{4382B038-D4B1-540B-859A-7016626BB99D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource; safecall;
    function GetResults: Perception_IPerceptionDepthFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionDepthFrameSource read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionDepthFrameSourceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionDepthFrameSource)]
  Perception_IPerceptionDepthFrameSourceStatics = interface(IInspectable)
  ['{5DF3CCA2-01F8-4A87-B859-D5E5B7E1DE48}']
    function CreateWatcher: Perception_IPerceptionDepthFrameSourceWatcher; safecall;
    function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource; safecall;
    function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionDepthFrameSource; safecall;
    function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrame
  Perception_IPerceptionInfraredFrame = interface(IInspectable)
  ['{B0886276-849E-4C7A-8AE6-B56064532153}']
    function get_VideoFrame: IVideoFrame; safecall;
    property VideoFrame: IVideoFrame read get_VideoFrame;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameArrivedEventArgs
  Perception_IPerceptionInfraredFrameArrivedEventArgs = interface(IInspectable)
  ['{9F77FAC7-B4BD-4857-9D50-BE8EF075DAEF}']
    function get_RelativeTime: TimeSpan; safecall;
    function TryOpenFrame: Perception_IPerceptionInfraredFrame; safecall;
    property RelativeTime: TimeSpan read get_RelativeTime;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameReader,Windows.Devices.Perception.PerceptionInfraredFrameArrivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameReader,Windows.Devices.Perception.IPerceptionInfraredFrameArrivedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameReader__Perception_IPerceptionInfraredFrameArrivedEventArgs = interface(IUnknown)
  ['{687FEF67-8871-56FE-8E7E-1D2929CC6F42}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameReader; args: Perception_IPerceptionInfraredFrameArrivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameSource,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSource,Object>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable = interface(IUnknown)
  ['{31EDABBD-D123-5E88-89D8-C80EE8F0F2CA}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameSource; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameSource,Windows.Devices.Perception.PerceptionFrameSourcePropertiesChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSource,Windows.Devices.Perception.IPerceptionFrameSourcePropertiesChangedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs = interface(IUnknown)
  ['{B6C1B828-A157-54ED-9C18-6919B9F91BE9}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameSource; args: Perception_IPerceptionFrameSourcePropertiesChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSource
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionInfraredFrameSource)]
  Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{55B08742-1808-494E-9E30-9D2A7BE8F700}']
    function add_AvailableChanged(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AvailableChanged(token: EventRegistrationToken); safecall;
    function add_ActiveChanged(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ActiveChanged(token: EventRegistrationToken); safecall;
    function add_PropertiesChanged(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__Perception_IPerceptionFrameSourcePropertiesChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PropertiesChanged(token: EventRegistrationToken); safecall;
    function add_VideoProfileChanged(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_VideoProfileChanged(token: EventRegistrationToken); safecall;
    function add_CameraIntrinsicsChanged(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSource__IInspectable): EventRegistrationToken; safecall;
    procedure remove_CameraIntrinsicsChanged(token: EventRegistrationToken); safecall;
    function get_Id: HSTRING; safecall;
    function get_DisplayName: HSTRING; safecall;
    function get_DeviceKind: HSTRING; safecall;
    function get_Available: Boolean; safecall;
    function get_Active: Boolean; safecall;
    function get_IsControlled: Boolean; safecall;
    function get_Properties: IMapView_2__HSTRING__IInspectable; safecall;
    function get_SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile; safecall;
    function get_VideoProfile: Perception_IPerceptionVideoProfile; safecall;
    function get_CameraIntrinsics: Core_ICameraIntrinsics; safecall;
    function AcquireControlSession: Perception_IPerceptionControlSession; safecall;
    function CanControlIndependentlyFrom(targetId: HSTRING): Boolean; safecall;
    function IsCorrelatedWith(targetId: HSTRING): Boolean; safecall;
    function TryGetTransformTo(targetId: HSTRING; out a_result: Numerics_Matrix4x4): Boolean; safecall;
    function TryGetDepthCorrelatedCameraIntrinsicsAsync(target: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCameraIntrinsics; safecall;
    function TryGetDepthCorrelatedCoordinateMapperAsync(targetId: HSTRING; depthFrameSourceToMapWith: Perception_IPerceptionDepthFrameSource): IAsyncOperation_1__Perception_IPerceptionDepthCorrelatedCoordinateMapper; safecall;
    function TrySetVideoProfileAsync(controlSession: Perception_IPerceptionControlSession; profile: Perception_IPerceptionVideoProfile): IAsyncOperation_1__Perception_IPerceptionFrameSourcePropertyChangeResult; safecall;
    function OpenReader: Perception_IPerceptionInfraredFrameReader; safecall;
    property Active: Boolean read get_Active;
    property Available: Boolean read get_Available;
    property AvailableVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_AvailableVideoProfiles;
    property CameraIntrinsics: Core_ICameraIntrinsics read get_CameraIntrinsics;
    property DeviceKind: HSTRING read get_DeviceKind;
    property DisplayName: HSTRING read get_DisplayName;
    property Id: HSTRING read get_Id;
    property IsControlled: Boolean read get_IsControlled;
    property Properties: IMapView_2__HSTRING__IInspectable read get_Properties;
    property SupportedVideoProfiles: IVectorView_1__Perception_IPerceptionVideoProfile read get_SupportedVideoProfiles;
    property VideoProfile: Perception_IPerceptionVideoProfile read get_VideoProfile;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameReader
  Perception_IPerceptionInfraredFrameReader = interface(IInspectable)
  ['{7960CE18-D39B-4FC8-A04A-929734C6756C}']
    function add_FrameArrived(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameReader__Perception_IPerceptionInfraredFrameArrivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_FrameArrived(token: EventRegistrationToken); safecall;
    function get_Source: Perception_IPerceptionInfraredFrameSource; safecall;
    function get_IsPaused: Boolean; safecall;
    procedure put_IsPaused(value: Boolean); safecall;
    function TryReadLatestFrame: Perception_IPerceptionInfraredFrame; safecall;
    property IsPaused: Boolean read get_IsPaused write put_IsPaused;
    property Source: Perception_IPerceptionInfraredFrameSource read get_Source;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSource2
  Perception_IPerceptionInfraredFrameSource2 = interface(IInspectable)
  ['{DCD4D798-4B0B-4300-8D85-410817FAA032}']
    function get_DeviceId: HSTRING; safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceAddedEventArgs
  Perception_IPerceptionInfraredFrameSourceAddedEventArgs = interface(IInspectable)
  ['{6D334120-95CE-4660-907A-D98035AA2B7C}']
    function get_FrameSource: Perception_IPerceptionInfraredFrameSource; safecall;
    property FrameSource: Perception_IPerceptionInfraredFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceRemovedEventArgs
  Perception_IPerceptionInfraredFrameSourceRemovedEventArgs = interface(IInspectable)
  ['{EA1A8071-7A70-4A61-AF94-07303853F695}']
    function get_FrameSource: Perception_IPerceptionInfraredFrameSource; safecall;
    property FrameSource: Perception_IPerceptionInfraredFrameSource read get_FrameSource;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.PerceptionInfraredFrameSourceAddedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.IPerceptionInfraredFrameSourceAddedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceAddedEventArgs = interface(IUnknown)
  ['{A8180CD1-C25B-5C7F-94DD-198423BB56D5}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameSourceWatcher; args: Perception_IPerceptionInfraredFrameSourceAddedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.PerceptionInfraredFrameSourceRemovedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Windows.Devices.Perception.IPerceptionInfraredFrameSourceRemovedEventArgs>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceRemovedEventArgs = interface(IUnknown)
  ['{2CA3A9B7-3348-5953-8D0D-EF8D78640B23}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameSourceWatcher; args: Perception_IPerceptionInfraredFrameSourceRemovedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.PerceptionInfraredFrameSourceWatcher,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher,Object>
  TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable = interface(IUnknown)
  ['{1555A628-3DFF-5FD0-B10A-CA6ADB2440C6}']
    procedure Invoke(sender: Perception_IPerceptionInfraredFrameSourceWatcher; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceWatcher
  Perception_IPerceptionInfraredFrameSourceWatcher = interface(IInspectable)
  ['{383CFF99-D70C-444D-A8B0-720C2E66FE3B}']
    function add_SourceAdded(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceAddedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceAdded(token: EventRegistrationToken); safecall;
    function add_SourceRemoved(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__Perception_IPerceptionInfraredFrameSourceRemovedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SourceRemoved(token: EventRegistrationToken); safecall;
    function add_Stopped(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_Stopped(token: EventRegistrationToken); safecall;
    function add_EnumerationCompleted(handler: TypedEventHandler_2__Perception_IPerceptionInfraredFrameSourceWatcher__IInspectable): EventRegistrationToken; safecall;
    procedure remove_EnumerationCompleted(token: EventRegistrationToken); safecall;
    function get_Status: DeviceWatcherStatus; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Status: DeviceWatcherStatus read get_Status;
  end deprecated;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IIterator_1__Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{B22B294F-A4D2-5726-A7FC-5E331432D9B4}']
    function get_Current: Perception_IPerceptionInfraredFrameSource; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPerception_IPerceptionInfraredFrameSource): Cardinal; safecall;
    property Current: Perception_IPerceptionInfraredFrameSource read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IIterable_1__Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{9309D0DB-338D-5ADF-8B3E-509BFDFCCEF3}']
    function First: IIterator_1__Perception_IPerceptionInfraredFrameSource; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{6FE8CCAE-DF9C-55D2-BDC7-8AC2BE1DE6C4}']
    function GetAt(index: Cardinal): Perception_IPerceptionInfraredFrameSource; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Perception_IPerceptionInfraredFrameSource; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPerception_IPerceptionInfraredFrameSource): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface(IUnknown)
  ['{3AAC58A8-4454-57E5-A90B-2449C5B7DFE8}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>>
  IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{B11EECAA-6F8C-5040-8D46-C3204C562582}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource; safecall;
    function GetResults: IVectorView_1__Perception_IPerceptionInfraredFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource = interface(IUnknown)
  ['{A8D4CD8E-B210-54F7-AE2B-7770E19B3E36}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.PerceptionInfraredFrameSource>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Perception.IPerceptionInfraredFrameSource>
  IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource = interface(IInspectable)
  ['{55122E42-CC65-5CCD-8F6C-84CED09DB24E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource; safecall;
    function GetResults: Perception_IPerceptionInfraredFrameSource; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Perception_IPerceptionInfraredFrameSource read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.IPerceptionInfraredFrameSourceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_PerceptionInfraredFrameSource)]
  Perception_IPerceptionInfraredFrameSourceStatics = interface(IInspectable)
  ['{5DF3CCA2-01F8-4A87-B859-D5E5B7E1DE47}']
    function CreateWatcher: Perception_IPerceptionInfraredFrameSourceWatcher; safecall;
    function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource; safecall;
    function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource; safecall;
    function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IKnownPerceptionFrameKindStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_KnownPerceptionFrameKind)]
  Perception_Provider_IKnownPerceptionFrameKindStatics = interface(IInspectable)
  ['{3AE651D6-9669-4106-9FAE-4835C1B96104}']
    function get_Color: HSTRING; safecall;
    function get_Depth: HSTRING; safecall;
    function get_Infrared: HSTRING; safecall;
    property Color: HSTRING read get_Color;
    property Depth: HSTRING read get_Depth;
    property Infrared: HSTRING read get_Infrared;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionControlGroup
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionControlGroup)]
  Perception_Provider_IPerceptionControlGroup = interface(IInspectable)
  ['{172C4882-2FD9-4C4E-BA34-FDF20A73DDE5}']
    function get_FrameProviderIds: IVectorView_1__HSTRING; safecall;
    property FrameProviderIds: IVectorView_1__HSTRING read get_FrameProviderIds;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionControlGroupFactory
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionControlGroup)]
  Perception_Provider_IPerceptionControlGroupFactory = interface(IInspectable)
  ['{2F1AF2E0-BAF1-453B-BED4-CD9D4619154C}']
    function Create(ids: IIterable_1__HSTRING): Perception_Provider_IPerceptionControlGroup; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionCorrelation
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionCorrelation)]
  Perception_Provider_IPerceptionCorrelation = interface(IInspectable)
  ['{B4131A82-DFF5-4047-8A19-3B4D805F7176}']
    function get_TargetId: HSTRING; safecall;
    function get_Position: Numerics_Vector3; safecall;
    function get_Orientation: Numerics_Quaternion; safecall;
    property Orientation: Numerics_Quaternion read get_Orientation;
    property Position: Numerics_Vector3 read get_Position;
    property TargetId: HSTRING read get_TargetId;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionCorrelationFactory
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionCorrelation)]
  Perception_Provider_IPerceptionCorrelationFactory = interface(IInspectable)
  ['{D4A6C425-2884-4A8F-8134-2835D7286CBF}']
    function Create(targetId: HSTRING; position: Numerics_Vector3; orientation: Numerics_Quaternion): Perception_Provider_IPerceptionCorrelation; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.Provider.PerceptionCorrelation>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IIterator_1__Perception_Provider_IPerceptionCorrelation = interface(IInspectable)
  ['{C4DB1093-D705-5503-8BCE-68535CD42FFA}']
    function get_Current: Perception_Provider_IPerceptionCorrelation; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPerception_Provider_IPerceptionCorrelation): Cardinal; safecall;
    property Current: Perception_Provider_IPerceptionCorrelation read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.Provider.PerceptionCorrelation>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IIterable_1__Perception_Provider_IPerceptionCorrelation = interface(IInspectable)
  ['{CA6BF87E-1745-5CD0-AEE2-59736F5A206D}']
    function First: IIterator_1__Perception_Provider_IPerceptionCorrelation; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Perception.Provider.IPerceptionCorrelation>
  IVectorView_1__Perception_Provider_IPerceptionCorrelation = interface(IInspectable)
  ['{28C0D4FB-231F-5627-AE3E-81A37BDA576A}']
    function GetAt(index: Cardinal): Perception_Provider_IPerceptionCorrelation; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Perception_Provider_IPerceptionCorrelation; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPerception_Provider_IPerceptionCorrelation): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionCorrelationGroup
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionCorrelationGroup)]
  Perception_Provider_IPerceptionCorrelationGroup = interface(IInspectable)
  ['{752A0906-36A7-47BB-9B79-56CC6B746770}']
    function get_RelativeLocations: IVectorView_1__Perception_Provider_IPerceptionCorrelation; safecall;
    property RelativeLocations: IVectorView_1__Perception_Provider_IPerceptionCorrelation read get_RelativeLocations;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionCorrelationGroupFactory
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionCorrelationGroup)]
  Perception_Provider_IPerceptionCorrelationGroupFactory = interface(IInspectable)
  ['{7DFE2088-63DF-48ED-83B1-4AB829132995}']
    function Create(relativeLocations: IIterable_1__Perception_Provider_IPerceptionCorrelation): Perception_Provider_IPerceptionCorrelationGroup; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroup
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionFaceAuthenticationGroup)]
  Perception_Provider_IPerceptionFaceAuthenticationGroup = interface(IInspectable)
  ['{E8019814-4A91-41B0-83A6-881A1775353E}']
    function get_FrameProviderIds: IVectorView_1__HSTRING; safecall;
    property FrameProviderIds: IVectorView_1__HSTRING read get_FrameProviderIds;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.PerceptionStartFaceAuthenticationHandler
  Perception_Provider_PerceptionStartFaceAuthenticationHandler = interface(IUnknown)
  ['{74816D2A-2090-4670-8C48-EF39E7FF7C26}']
    function Invoke(sender: Perception_Provider_IPerceptionFaceAuthenticationGroup): Boolean; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.PerceptionStopFaceAuthenticationHandler
  Perception_Provider_PerceptionStopFaceAuthenticationHandler = interface(IUnknown)
  ['{387EE6AA-89CD-481E-AADE-DD92F70B2AD7}']
    procedure Invoke(sender: Perception_Provider_IPerceptionFaceAuthenticationGroup); safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroupFactory
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionFaceAuthenticationGroup)]
  Perception_Provider_IPerceptionFaceAuthenticationGroupFactory = interface(IInspectable)
  ['{E68A05D4-B60C-40F4-BCB9-F24D46467320}']
    function Create(ids: IIterable_1__HSTRING; startHandler: Perception_Provider_PerceptionStartFaceAuthenticationHandler; stopHandler: Perception_Provider_PerceptionStopFaceAuthenticationHandler): Perception_Provider_IPerceptionFaceAuthenticationGroup; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFrame
  Perception_Provider_IPerceptionFrame = interface(IInspectable)
  ['{7CFE7825-54BB-4D9D-BEC5-8EF66151D2AC}']
    function get_RelativeTime: TimeSpan; safecall;
    procedure put_RelativeTime(value: TimeSpan); safecall;
    function get_Properties: IPropertySet; safecall;
    function get_FrameData: IMemoryBuffer; safecall;
    property FrameData: IMemoryBuffer read get_FrameData;
    property Properties: IPropertySet read get_Properties;
    property RelativeTime: TimeSpan read get_RelativeTime write put_RelativeTime;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderInfo
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionFrameProviderInfo)]
  Perception_Provider_IPerceptionFrameProviderInfo = interface(IInspectable)
  ['{CCA959E8-797E-4E83-9B87-036A74142FC4}']
    function get_Id: HSTRING; safecall;
    procedure put_Id(value: HSTRING); safecall;
    function get_DisplayName: HSTRING; safecall;
    procedure put_DisplayName(value: HSTRING); safecall;
    function get_DeviceKind: HSTRING; safecall;
    procedure put_DeviceKind(value: HSTRING); safecall;
    function get_FrameKind: HSTRING; safecall;
    procedure put_FrameKind(value: HSTRING); safecall;
    function get_Hidden: Boolean; safecall;
    procedure put_Hidden(value: Boolean); safecall;
    property DeviceKind: HSTRING read get_DeviceKind write put_DeviceKind;
    property DisplayName: HSTRING read get_DisplayName write put_DisplayName;
    property FrameKind: HSTRING read get_FrameKind write put_FrameKind;
    property Hidden: Boolean read get_Hidden write put_Hidden;
    property Id: HSTRING read get_Id write put_Id;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionPropertyChangeRequest
  Perception_Provider_IPerceptionPropertyChangeRequest = interface(IInspectable)
  ['{3C5AEB51-350B-4DF8-9414-59E09815510B}']
    function get_Name: HSTRING; safecall;
    function get_Value: IInspectable; safecall;
    function get_Status: Perception_PerceptionFrameSourcePropertyChangeStatus; safecall;
    procedure put_Status(value: Perception_PerceptionFrameSourcePropertyChangeStatus); safecall;
    function GetDeferral: IDeferral; safecall;
    property Name: HSTRING read get_Name;
    property Status: Perception_PerceptionFrameSourcePropertyChangeStatus read get_Status write put_Status;
    property Value: IInspectable read get_Value;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFrameProvider
  Perception_Provider_IPerceptionFrameProvider = interface(IInspectable)
  ['{794F7AB9-B37D-3B33-A10D-30626419CE65}']
    function get_FrameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo; safecall;
    function get_Available: Boolean; safecall;
    function get_Properties: IPropertySet; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    procedure SetProperty(value: Perception_Provider_IPerceptionPropertyChangeRequest); safecall;
    property Available: Boolean read get_Available;
    property FrameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo read get_FrameProviderInfo;
    property Properties: IPropertySet read get_Properties;
  end deprecated;

  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderManager
  Perception_Provider_IPerceptionFrameProviderManager = interface(IInspectable)
  ['{A959CE07-EAD3-33DF-8EC1-B924ABE019C4}']
    function GetFrameProvider(frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo): Perception_Provider_IPerceptionFrameProvider; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionFrameProviderManagerServiceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionFrameProviderManagerService)]
  Perception_Provider_IPerceptionFrameProviderManagerServiceStatics = interface(IInspectable)
  ['{AE8386E6-CAD9-4359-8F96-8EAE51810526}']
    procedure RegisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo); safecall;
    procedure UnregisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo); safecall;
    procedure RegisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup); safecall;
    procedure UnregisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup); safecall;
    procedure RegisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup); safecall;
    procedure UnregisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup); safecall;
    procedure RegisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup); safecall;
    procedure UnregisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup); safecall;
    procedure UpdateAvailabilityForProvider(provider: Perception_Provider_IPerceptionFrameProvider; available: Boolean); safecall;
    procedure PublishFrameForProvider(provider: Perception_Provider_IPerceptionFrameProvider; frame: Perception_Provider_IPerceptionFrame); safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocator
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionVideoFrameAllocator)]
  Perception_Provider_IPerceptionVideoFrameAllocator = interface(IInspectable)
  ['{4C38A7DA-FDD8-4ED4-A039-2A6F9B235038}']
    function AllocateFrame: Perception_Provider_IPerceptionFrame; safecall;
    function CopyFromVideoFrame(frame: IVideoFrame): Perception_Provider_IPerceptionFrame; safecall;
  end deprecated;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocatorFactory
  [WinRTClassNameAttribute(SWindows_Devices_Perception_Provider_PerceptionVideoFrameAllocator)]
  Perception_Provider_IPerceptionVideoFrameAllocatorFactory = interface(IInspectable)
  ['{1A58B0E1-E91A-481E-B876-A89E2BBC6B33}']
    function Create(maxOutstandingFrameCountForWrite: Cardinal; format: Imaging_BitmapPixelFormat; resolution: TSizeF; alpha: Imaging_BitmapAlphaMode): Perception_Provider_IPerceptionVideoFrameAllocator; safecall;
  end deprecated;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Power.Battery,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Power.IBattery,Object>
  TypedEventHandler_2__Power_IBattery__IInspectable = interface(IUnknown)
  ['{4D4AA646-767F-5645-AF5C-546464D3EC09}']
    procedure Invoke(sender: Power_IBattery; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Power.IBattery
  [WinRTClassNameAttribute(SWindows_Devices_Power_Battery)]
  Power_IBattery = interface(IInspectable)
  ['{BC894FC6-0072-47C8-8B5D-614AAA7A437E}']
    function get_DeviceId: HSTRING; safecall;
    function GetReport: Power_IBatteryReport; safecall;
    function add_ReportUpdated(handler: TypedEventHandler_2__Power_IBattery__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ReportUpdated(token: EventRegistrationToken); safecall;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Power.Battery>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Power.IBattery>
  AsyncOperationCompletedHandler_1__Power_IBattery = interface(IUnknown)
  ['{97F82115-3822-507B-82E6-2777B336E98E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Power_IBattery; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Power.Battery>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Power.IBattery>
  IAsyncOperation_1__Power_IBattery = interface(IInspectable)
  ['{DAA3D556-1529-56D2-A5F8-BFB6C22A3DFE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Power_IBattery); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Power_IBattery; safecall;
    function GetResults: Power_IBattery; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Power_IBattery read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Power.IBatteryStatics
  [WinRTClassNameAttribute(SWindows_Devices_Power_Battery)]
  Power_IBatteryStatics = interface(IInspectable)
  ['{79CD72B6-9E5E-4452-BEA6-DFCD541E597F}']
    function get_AggregateBattery: Power_IBattery; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Power_IBattery; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    property AggregateBattery: Power_IBattery read get_AggregateBattery;
  end;

  // UsedAPI Interface
  // Windows.Devices.Pwm.IPwmPin
  Pwm_IPwmPin = interface(IInspectable)
  ['{22972DC8-C6CF-4821-B7F9-C6454FB6AF79}']
    function get_Controller: Pwm_IPwmController; safecall;
    function GetActiveDutyCyclePercentage: Double; safecall;
    procedure SetActiveDutyCyclePercentage(dutyCyclePercentage: Double); safecall;
    function get_Polarity: Pwm_PwmPulsePolarity; safecall;
    procedure put_Polarity(value: Pwm_PwmPulsePolarity); safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    function get_IsStarted: Boolean; safecall;
    property Controller: Pwm_IPwmController read get_Controller;
    property IsStarted: Boolean read get_IsStarted;
    property Polarity: Pwm_PwmPulsePolarity read get_Polarity write put_Polarity;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Pwm.IPwmController
  [WinRTClassNameAttribute(SWindows_Devices_Pwm_PwmController)]
  Pwm_IPwmController = interface(IInspectable)
  ['{C45F5C85-D2E8-42CF-9BD6-CF5ED029E6A7}']
    function get_PinCount: Integer; safecall;
    function get_ActualFrequency: Double; safecall;
    function SetDesiredFrequency(desiredFrequency: Double): Double; safecall;
    function get_MinFrequency: Double; safecall;
    function get_MaxFrequency: Double; safecall;
    function OpenPin(pinNumber: Integer): Pwm_IPwmPin; safecall;
    property ActualFrequency: Double read get_ActualFrequency;
    property MaxFrequency: Double read get_MaxFrequency;
    property MinFrequency: Double read get_MinFrequency;
    property PinCount: Integer read get_PinCount;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Pwm.PwmController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Pwm.IPwmController>
  IIterator_1__Pwm_IPwmController = interface(IInspectable)
  ['{599330BD-B0CA-533E-938F-5DD4242BF513}']
    function get_Current: Pwm_IPwmController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPwm_IPwmController): Cardinal; safecall;
    property Current: Pwm_IPwmController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Pwm.PwmController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Pwm.IPwmController>
  IIterable_1__Pwm_IPwmController = interface(IInspectable)
  ['{1403A6AB-73CB-5805-9BBC-A0DD39D476B0}']
    function First: IIterator_1__Pwm_IPwmController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>
  IVectorView_1__Pwm_IPwmController = interface(IInspectable)
  ['{98B1BFDB-A27C-50F2-B43B-A67F3DE0E65A}']
    function GetAt(index: Cardinal): Pwm_IPwmController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Pwm_IPwmController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPwm_IPwmController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.PwmController>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController = interface(IUnknown)
  ['{E72BD078-CE02-55AC-A7B9-ABD01248D888}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Pwm_IPwmController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.PwmController>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.IPwmController>>
  IAsyncOperation_1__IVectorView_1__Pwm_IPwmController = interface(IInspectable)
  ['{E4151E8D-4688-5023-9F5D-008BBD904891}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController; safecall;
    function GetResults: IVectorView_1__Pwm_IPwmController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Pwm_IPwmController read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IIterator_1__Pwm_Provider_IPwmControllerProvider = interface(IInspectable)
  ['{90389702-F036-56E1-A94F-6D99D52B9578}']
    function get_Current: Pwm_Provider_IPwmControllerProvider; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PPwm_Provider_IPwmControllerProvider): Cardinal; safecall;
    property Current: Pwm_Provider_IPwmControllerProvider read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IIterable_1__Pwm_Provider_IPwmControllerProvider = interface(IInspectable)
  ['{4936ED59-B494-5128-BC7E-03E630346475}']
    function First: IIterator_1__Pwm_Provider_IPwmControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Pwm.Provider.IPwmControllerProvider>
  IVectorView_1__Pwm_Provider_IPwmControllerProvider = interface(IInspectable)
  ['{1A166093-1A7A-5E12-9D38-F892FEC3EC66}']
    function GetAt(index: Cardinal): Pwm_Provider_IPwmControllerProvider; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Pwm_Provider_IPwmControllerProvider; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PPwm_Provider_IPwmControllerProvider): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Pwm.Provider.IPwmProvider
  Pwm_Provider_IPwmProvider = interface(IInspectable)
  ['{A3301228-52F1-47B0-9349-66BA43D25902}']
    function GetControllers: IVectorView_1__Pwm_Provider_IPwmControllerProvider; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Pwm.IPwmControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Pwm_PwmController)]
  Pwm_IPwmControllerStatics = interface(IInspectable)
  ['{4263BDA1-8946-4404-BD48-81DD124AF4D9}']
    function GetControllersAsync(provider: Pwm_Provider_IPwmProvider): IAsyncOperation_1__IVectorView_1__Pwm_IPwmController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Pwm.PwmController>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Pwm.IPwmController>
  AsyncOperationCompletedHandler_1__Pwm_IPwmController = interface(IUnknown)
  ['{5FC68E9F-FFFF-5D53-BA21-9C33EF56B240}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Pwm_IPwmController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Pwm.PwmController>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Pwm.IPwmController>
  IAsyncOperation_1__Pwm_IPwmController = interface(IInspectable)
  ['{0A288D41-1F20-5D16-85DD-52855B11569A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Pwm_IPwmController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Pwm_IPwmController; safecall;
    function GetResults: Pwm_IPwmController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Pwm_IPwmController read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Pwm.IPwmControllerStatics2
  [WinRTClassNameAttribute(SWindows_Devices_Pwm_PwmController)]
  Pwm_IPwmControllerStatics2 = interface(IInspectable)
  ['{44FC5B1F-F119-4BDD-97AD-F76EF986736D}']
    function GetDefaultAsync: IAsyncOperation_1__Pwm_IPwmController; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Pwm.IPwmControllerStatics3
  [WinRTClassNameAttribute(SWindows_Devices_Pwm_PwmController)]
  Pwm_IPwmControllerStatics3 = interface(IInspectable)
  ['{B2581871-0229-4344-AE3F-9B7CD0E66B94}']
    function GetDeviceSelector: HSTRING; overload; safecall;
    function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Pwm_IPwmController; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Radios.Radio>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Radios.IRadio>
  IIterator_1__Radios_IRadio = interface(IInspectable)
  ['{CF37EDE7-EAEC-5B8F-AD31-4D51ABD9DB05}']
    function get_Current: Radios_IRadio; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PRadios_IRadio): Cardinal; safecall;
    property Current: Radios_IRadio read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Radios.Radio>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Radios.IRadio>
  IIterable_1__Radios_IRadio = interface(IInspectable)
  ['{E82500AF-1F53-504E-B8BE-DAC4FBB69084}']
    function First: IIterator_1__Radios_IRadio; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>
  IVectorView_1__Radios_IRadio = interface(IInspectable)
  ['{58A077B6-FC4B-55DB-84EC-B64EBC9E3F96}']
    function GetAt(index: Cardinal): Radios_IRadio; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Radios_IRadio; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PRadios_IRadio): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.Radio>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio = interface(IUnknown)
  ['{D30691E6-60A0-59C9-8965-5BBE282E8208}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Radios_IRadio; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.Radio>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Radios.IRadio>>
  IAsyncOperation_1__IVectorView_1__Radios_IRadio = interface(IInspectable)
  ['{040B54A1-203E-58F5-943F-C1CCA86BD532}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio; safecall;
    function GetResults: IVectorView_1__Radios_IRadio; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Radios_IRadio read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Radios.IRadioStatics
  [WinRTClassNameAttribute(SWindows_Devices_Radios_Radio)]
  Radios_IRadioStatics = interface(IInspectable)
  ['{5FB6A12E-67CB-46AE-AAE9-65919F86EFF4}']
    function GetRadiosAsync: IAsyncOperation_1__IVectorView_1__Radios_IRadio; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Radios_IRadio; safecall;
    function RequestAccessAsync: IAsyncOperation_1__Radios_RadioAccessStatus; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.SerialCommunication.IErrorReceivedEventArgs
  SerialCommunication_IErrorReceivedEventArgs = interface(IInspectable)
  ['{FCC6BF59-1283-4D8A-BFDF-566B33DDB28F}']
    function get_Error: SerialCommunication_SerialError; safecall;
    property Error: SerialCommunication_SerialError read get_Error;
  end;

  // UsedAPI Interface
  // Windows.Devices.SerialCommunication.IPinChangedEventArgs
  SerialCommunication_IPinChangedEventArgs = interface(IInspectable)
  ['{A2BF1DB0-FC9C-4607-93D0-FA5E8343EE22}']
    function get_PinChange: SerialCommunication_SerialPinChange; safecall;
    property PinChange: SerialCommunication_SerialPinChange read get_PinChange;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.SerialDevice,Windows.Devices.SerialCommunication.ErrorReceivedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.ISerialDevice,Windows.Devices.SerialCommunication.IErrorReceivedEventArgs>
  TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IErrorReceivedEventArgs = interface(IUnknown)
  ['{D92EA323-B7BF-5E02-B9FB-C61F97D080E9}']
    procedure Invoke(sender: SerialCommunication_ISerialDevice; args: SerialCommunication_IErrorReceivedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.SerialDevice,Windows.Devices.SerialCommunication.PinChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.SerialCommunication.ISerialDevice,Windows.Devices.SerialCommunication.IPinChangedEventArgs>
  TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IPinChangedEventArgs = interface(IUnknown)
  ['{E496C3EF-5802-5AC4-AC2E-96BC23FA9447}']
    procedure Invoke(sender: SerialCommunication_ISerialDevice; args: SerialCommunication_IPinChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.SerialCommunication.ISerialDevice
  [WinRTClassNameAttribute(SWindows_Devices_SerialCommunication_SerialDevice)]
  SerialCommunication_ISerialDevice = interface(IInspectable)
  ['{E187CCC6-2210-414F-B65A-F5553A03372A}']
    function get_BaudRate: Cardinal; safecall;
    procedure put_BaudRate(value: Cardinal); safecall;
    function get_BreakSignalState: Boolean; safecall;
    procedure put_BreakSignalState(value: Boolean); safecall;
    function get_BytesReceived: Cardinal; safecall;
    function get_CarrierDetectState: Boolean; safecall;
    function get_ClearToSendState: Boolean; safecall;
    function get_DataBits: Word; safecall;
    procedure put_DataBits(value: Word); safecall;
    function get_DataSetReadyState: Boolean; safecall;
    function get_Handshake: SerialCommunication_SerialHandshake; safecall;
    procedure put_Handshake(value: SerialCommunication_SerialHandshake); safecall;
    function get_IsDataTerminalReadyEnabled: Boolean; safecall;
    procedure put_IsDataTerminalReadyEnabled(value: Boolean); safecall;
    function get_IsRequestToSendEnabled: Boolean; safecall;
    procedure put_IsRequestToSendEnabled(value: Boolean); safecall;
    function get_Parity: SerialCommunication_SerialParity; safecall;
    procedure put_Parity(value: SerialCommunication_SerialParity); safecall;
    function get_PortName: HSTRING; safecall;
    function get_ReadTimeout: TimeSpan; safecall;
    procedure put_ReadTimeout(value: TimeSpan); safecall;
    function get_StopBits: SerialCommunication_SerialStopBitCount; safecall;
    procedure put_StopBits(value: SerialCommunication_SerialStopBitCount); safecall;
    function get_UsbVendorId: Word; safecall;
    function get_UsbProductId: Word; safecall;
    function get_WriteTimeout: TimeSpan; safecall;
    procedure put_WriteTimeout(value: TimeSpan); safecall;
    function get_InputStream: IInputStream; safecall;
    function get_OutputStream: IOutputStream; safecall;
    function add_ErrorReceived(reportHandler: TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IErrorReceivedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ErrorReceived(token: EventRegistrationToken); safecall;
    function add_PinChanged(reportHandler: TypedEventHandler_2__SerialCommunication_ISerialDevice__SerialCommunication_IPinChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_PinChanged(token: EventRegistrationToken); safecall;
    property BaudRate: Cardinal read get_BaudRate write put_BaudRate;
    property BreakSignalState: Boolean read get_BreakSignalState write put_BreakSignalState;
    property BytesReceived: Cardinal read get_BytesReceived;
    property CarrierDetectState: Boolean read get_CarrierDetectState;
    property ClearToSendState: Boolean read get_ClearToSendState;
    property DataBits: Word read get_DataBits write put_DataBits;
    property DataSetReadyState: Boolean read get_DataSetReadyState;
    property Handshake: SerialCommunication_SerialHandshake read get_Handshake write put_Handshake;
    property InputStream: IInputStream read get_InputStream;
    property IsDataTerminalReadyEnabled: Boolean read get_IsDataTerminalReadyEnabled write put_IsDataTerminalReadyEnabled;
    property IsRequestToSendEnabled: Boolean read get_IsRequestToSendEnabled write put_IsRequestToSendEnabled;
    property OutputStream: IOutputStream read get_OutputStream;
    property Parity: SerialCommunication_SerialParity read get_Parity write put_Parity;
    property PortName: HSTRING read get_PortName;
    property ReadTimeout: TimeSpan read get_ReadTimeout write put_ReadTimeout;
    property StopBits: SerialCommunication_SerialStopBitCount read get_StopBits write put_StopBits;
    property UsbProductId: Word read get_UsbProductId;
    property UsbVendorId: Word read get_UsbVendorId;
    property WriteTimeout: TimeSpan read get_WriteTimeout write put_WriteTimeout;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SerialCommunication.SerialDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SerialCommunication.ISerialDevice>
  AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice = interface(IUnknown)
  ['{84A34B33-06FC-5E63-8EE2-EAB4FF69ACB7}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__SerialCommunication_ISerialDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SerialCommunication.SerialDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SerialCommunication.ISerialDevice>
  IAsyncOperation_1__SerialCommunication_ISerialDevice = interface(IInspectable)
  ['{44EF26ED-C1FF-546A-A46B-6A37DE9187FB}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice; safecall;
    function GetResults: SerialCommunication_ISerialDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__SerialCommunication_ISerialDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.SerialCommunication.ISerialDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_SerialCommunication_SerialDevice)]
  SerialCommunication_ISerialDeviceStatics = interface(IInspectable)
  ['{058C4A70-0836-4993-AE1A-B61AE3BE056B}']
    function GetDeviceSelector: HSTRING; overload; safecall;
    function GetDeviceSelector(portName: HSTRING): HSTRING; overload; safecall;
    function GetDeviceSelectorFromUsbVidPid(vendorId: Word; productId: Word): HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__SerialCommunication_ISerialDevice; safecall;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardReaderStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus = interface(IUnknown)
  ['{3D7E6EA9-E739-555C-9C02-07396C5321F5}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__SmartCards_SmartCardReaderStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardReaderStatus>
  IAsyncOperation_1__SmartCards_SmartCardReaderStatus = interface(IInspectable)
  ['{5AE402FA-1F22-5570-A0C8-B2320ADEDB81}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus; safecall;
    function GetResults: SmartCards_SmartCardReaderStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardReaderStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus = interface(IUnknown)
  ['{BDAF4A41-3B4A-56B0-AEEC-FEE71CC7F328}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__SmartCards_SmartCardStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardStatus>
  IAsyncOperation_1__SmartCards_SmartCardStatus = interface(IInspectable)
  ['{E2223376-8CF6-51BD-9907-1344AA665E5D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus; safecall;
    function GetResults: SmartCards_SmartCardStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardStatus read get_Completed write put_Completed;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardActivationPolicyChangeResult>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult = interface(IUnknown)
  ['{9528F94B-047B-5E2A-8FC0-7017F5DADDFF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__SmartCards_SmartCardActivationPolicyChangeResult; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardActivationPolicyChangeResult>
  IAsyncOperation_1__SmartCards_SmartCardActivationPolicyChangeResult = interface(IInspectable)
  ['{B8F15D35-2F3D-53AA-B5C6-FACA4C7FF16E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult; safecall;
    function GetResults: SmartCards_SmartCardActivationPolicyChangeResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardActivationPolicyChangeResult read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialType = interface(IInspectable)
  ['{97E1414D-439A-5DC2-81FC-D988E32C8DAB}']
    function get_Current: SmartCards_SmartCardCryptogramMaterialType; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialType): Cardinal; safecall;
    property Current: SmartCards_SmartCardCryptogramMaterialType read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialType = interface(IInspectable)
  ['{2D379F84-389C-5809-A2C6-919B47CAAB88}']
    function First: IIterator_1__SmartCards_SmartCardCryptogramMaterialType; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialType>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialType = interface(IInspectable)
  ['{394BC0CC-C621-5BA3-B4F0-712FCF591392}']
    function GetAt(index: Cardinal): SmartCards_SmartCardCryptogramMaterialType; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmartCards_SmartCardCryptogramMaterialType; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialType): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IIterator_1__SmartCards_SmartCardCryptogramAlgorithm = interface(IInspectable)
  ['{4F1E0492-DAB2-53C3-B5FB-C4B4373B1EC2}']
    function get_Current: SmartCards_SmartCardCryptogramAlgorithm; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramAlgorithm): Cardinal; safecall;
    property Current: SmartCards_SmartCardCryptogramAlgorithm read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IIterable_1__SmartCards_SmartCardCryptogramAlgorithm = interface(IInspectable)
  ['{8E0DE0E9-0742-559E-9B1B-460268622C1F}']
    function First: IIterator_1__SmartCards_SmartCardCryptogramAlgorithm; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramAlgorithm>
  IVectorView_1__SmartCards_SmartCardCryptogramAlgorithm = interface(IInspectable)
  ['{A9DF831C-C22B-5D30-A86C-5A31FE192433}']
    function GetAt(index: Cardinal): SmartCards_SmartCardCryptogramAlgorithm; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmartCards_SmartCardCryptogramAlgorithm; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramAlgorithm): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface(IInspectable)
  ['{7BF75A02-EE7E-513A-80F8-F7D8F004C907}']
    function get_Current: SmartCards_SmartCardCryptogramMaterialPackageFormat; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialPackageFormat): Cardinal; safecall;
    property Current: SmartCards_SmartCardCryptogramMaterialPackageFormat read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface(IInspectable)
  ['{3E241ACC-1745-57CE-9368-21BA2130C3C1}']
    function First: IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageFormat; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageFormat>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageFormat = interface(IInspectable)
  ['{B7CCE3F2-9889-586C-BEB1-68FEDDB7CB15}']
    function GetAt(index: Cardinal): SmartCards_SmartCardCryptogramMaterialPackageFormat; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmartCards_SmartCardCryptogramMaterialPackageFormat; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialPackageFormat): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface(IInspectable)
  ['{9D1091AE-BE37-5BE7-8EDF-60C5164880B6}']
    function get_Current: SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat): Cardinal; safecall;
    property Current: SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IIterable_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface(IInspectable)
  ['{C40C4451-4EBB-5635-9C7D-33C8C5D37A09}']
    function First: IIterator_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramMaterialPackageConfirmationResponseFormat>
  IVectorView_1__SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat = interface(IInspectable)
  ['{3A4176A2-D221-5A9F-A4C2-A5B8736DA2D8}']
    function GetAt(index: Cardinal): SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramMaterialPackageConfirmationResponseFormat): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IIterator_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface(IInspectable)
  ['{9C12738D-E06E-5269-B455-B4D0CD128000}']
    function get_Current: SmartCards_SmartCardCryptogramStorageKeyCapabilities; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramStorageKeyCapabilities): Cardinal; safecall;
    property Current: SmartCards_SmartCardCryptogramStorageKeyCapabilities read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IIterable_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface(IInspectable)
  ['{E457FBB7-CEF9-5C43-B951-328DA58D0B62}']
    function First: IIterator_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities; safecall;
  end;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.SmartCards.SmartCardCryptogramStorageKeyCapabilities>
  IVectorView_1__SmartCards_SmartCardCryptogramStorageKeyCapabilities = interface(IInspectable)
  ['{8F4607F4-FF4B-584B-B2CF-4952A4D68AFD}']
    function GetAt(index: Cardinal): SmartCards_SmartCardCryptogramStorageKeyCapabilities; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmartCards_SmartCardCryptogramStorageKeyCapabilities; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmartCards_SmartCardCryptogramStorageKeyCapabilities): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.SmartCards.SmartCardCryptogramGeneratorOperationStatus>
  AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = interface(IUnknown)
  ['{C6C447C7-A60D-500A-9BFE-59F25C33E979}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.SmartCards.SmartCardCryptogramGeneratorOperationStatus>
  IAsyncOperation_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus = interface(IInspectable)
  ['{F5B0E1B0-57A7-5AB3-AEAA-D6B635257866}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus; safecall;
    function GetResults: SmartCards_SmartCardCryptogramGeneratorOperationStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__SmartCards_SmartCardCryptogramGeneratorOperationStatus read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiBusInfo
  Spi_ISpiBusInfo = interface(IInspectable)
  ['{9929444A-54F2-48C6-B952-9C32FC02C669}']
    function get_ChipSelectLineCount: Integer; safecall;
    function get_MinClockFrequency: Integer; safecall;
    function get_MaxClockFrequency: Integer; safecall;
    function get_SupportedDataBitLengths: IVectorView_1__Integer; safecall;
    property ChipSelectLineCount: Integer read get_ChipSelectLineCount;
    property MaxClockFrequency: Integer read get_MaxClockFrequency;
    property MinClockFrequency: Integer read get_MinClockFrequency;
    property SupportedDataBitLengths: IVectorView_1__Integer read get_SupportedDataBitLengths;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiConnectionSettings
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiConnectionSettings)]
  Spi_ISpiConnectionSettings = interface(IInspectable)
  ['{5283A37F-F935-4B9F-A7A7-3A7890AFA5CE}']
    function get_ChipSelectLine: Integer; safecall;
    procedure put_ChipSelectLine(value: Integer); safecall;
    function get_Mode: Spi_SpiMode; safecall;
    procedure put_Mode(value: Spi_SpiMode); safecall;
    function get_DataBitLength: Integer; safecall;
    procedure put_DataBitLength(value: Integer); safecall;
    function get_ClockFrequency: Integer; safecall;
    procedure put_ClockFrequency(value: Integer); safecall;
    function get_SharingMode: Spi_SpiSharingMode; safecall;
    procedure put_SharingMode(value: Spi_SpiSharingMode); safecall;
    property ChipSelectLine: Integer read get_ChipSelectLine write put_ChipSelectLine;
    property ClockFrequency: Integer read get_ClockFrequency write put_ClockFrequency;
    property DataBitLength: Integer read get_DataBitLength write put_DataBitLength;
    property Mode: Spi_SpiMode read get_Mode write put_Mode;
    property SharingMode: Spi_SpiSharingMode read get_SharingMode write put_SharingMode;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiConnectionSettingsFactory
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiConnectionSettings)]
  Spi_ISpiConnectionSettingsFactory = interface(IInspectable)
  ['{FF99081E-10C4-44B7-9FEA-A748B5A46F31}']
    function Create(chipSelectLine: Integer): Spi_ISpiConnectionSettings; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiDevice
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiDevice)]
  Spi_ISpiDevice = interface(IInspectable)
  ['{05D5356D-11B6-4D39-84D5-95DFB4C9F2CE}']
    function get_DeviceId: HSTRING; safecall;
    function get_ConnectionSettings: Spi_ISpiConnectionSettings; safecall;
    procedure Write(bufferSize: Cardinal; buffer: PByte); safecall;
    procedure Read(bufferSize: Cardinal; buffer: PByte); safecall;
    procedure TransferSequential(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    procedure TransferFullDuplex(writeBufferSize: Cardinal; writeBuffer: PByte; readBufferSize: Cardinal; readBuffer: PByte); safecall;
    property ConnectionSettings: Spi_ISpiConnectionSettings read get_ConnectionSettings;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiController
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiController)]
  Spi_ISpiController = interface(IInspectable)
  ['{A8D3C829-9895-4159-A934-8741F1EE6D27}']
    function GetDevice(settings: Spi_ISpiConnectionSettings): Spi_ISpiDevice; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.SpiController>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.ISpiController>
  AsyncOperationCompletedHandler_1__Spi_ISpiController = interface(IUnknown)
  ['{5E94D949-A844-5B25-A3CC-AFABEB18C1D2}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Spi_ISpiController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.SpiController>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.ISpiController>
  IAsyncOperation_1__Spi_ISpiController = interface(IInspectable)
  ['{B6B0DF6F-C097-5844-93BD-7821998FDB8E}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Spi_ISpiController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Spi_ISpiController; safecall;
    function GetResults: Spi_ISpiController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Spi_ISpiController read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Spi.SpiController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Spi.ISpiController>
  IIterator_1__Spi_ISpiController = interface(IInspectable)
  ['{FD7D5997-544C-5BE9-B0FA-1D0EFBFC4A03}']
    function get_Current: Spi_ISpiController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSpi_ISpiController): Cardinal; safecall;
    property Current: Spi_ISpiController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Spi.SpiController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Spi.ISpiController>
  IIterable_1__Spi_ISpiController = interface(IInspectable)
  ['{7B076938-DC1B-5368-9003-059291D37F35}']
    function First: IIterator_1__Spi_ISpiController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>
  IVectorView_1__Spi_ISpiController = interface(IInspectable)
  ['{3D32F598-38DD-5778-914B-3287BB83E935}']
    function GetAt(index: Cardinal): Spi_ISpiController; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Spi_ISpiController; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSpi_ISpiController): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.SpiController>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController = interface(IUnknown)
  ['{C8AFC9CB-6807-57EC-84C9-9F3DBC003450}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Spi_ISpiController; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.SpiController>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.ISpiController>>
  IAsyncOperation_1__IVectorView_1__Spi_ISpiController = interface(IInspectable)
  ['{89624331-F802-56F7-9B33-17C616ECBCFA}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController; safecall;
    function GetResults: IVectorView_1__Spi_ISpiController; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_ISpiController read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IIterator_1__Spi_Provider_ISpiControllerProvider = interface(IInspectable)
  ['{CF1D15D3-A6C8-56DD-80C8-E8D960262277}']
    function get_Current: Spi_Provider_ISpiControllerProvider; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSpi_Provider_ISpiControllerProvider): Cardinal; safecall;
    property Current: Spi_Provider_ISpiControllerProvider read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IIterable_1__Spi_Provider_ISpiControllerProvider = interface(IInspectable)
  ['{71BA027D-8C84-58B1-8D66-9177C11698EB}']
    function First: IIterator_1__Spi_Provider_ISpiControllerProvider; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>
  IVectorView_1__Spi_Provider_ISpiControllerProvider = interface(IInspectable)
  ['{96A4919B-3229-5E41-8B10-C8198C44F10C}']
    function GetAt(index: Cardinal): Spi_Provider_ISpiControllerProvider; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Spi_Provider_ISpiControllerProvider; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSpi_Provider_ISpiControllerProvider): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = interface(IUnknown)
  ['{E9E2AE03-42D6-5211-AB52-325E722E2611}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Spi.Provider.ISpiControllerProvider>>
  IAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider = interface(IInspectable)
  ['{B3AF3490-DEDE-59D1-B562-1F6BE71AE139}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider; safecall;
    function GetResults: IVectorView_1__Spi_Provider_ISpiControllerProvider; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Spi_Provider_ISpiControllerProvider read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Devices.Spi.Provider.ISpiProvider
  Spi_Provider_ISpiProvider = interface(IInspectable)
  ['{96B461E2-77D4-48CE-AAA0-75715A8362CF}']
    function GetControllersAsync: IAsyncOperation_1__IVectorView_1__Spi_Provider_ISpiControllerProvider; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiControllerStatics
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiController)]
  Spi_ISpiControllerStatics = interface(IInspectable)
  ['{0D5229E2-138B-4E48-B964-4F2F79B9C5A2}']
    function GetDefaultAsync: IAsyncOperation_1__Spi_ISpiController; safecall;
    function GetControllersAsync(provider: Spi_Provider_ISpiProvider): IAsyncOperation_1__IVectorView_1__Spi_ISpiController; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.SpiDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Spi.ISpiDevice>
  AsyncOperationCompletedHandler_1__Spi_ISpiDevice = interface(IUnknown)
  ['{A88A28BA-6966-55E7-8C81-7C65F74E39C0}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Spi_ISpiDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.SpiDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Spi.ISpiDevice>
  IAsyncOperation_1__Spi_ISpiDevice = interface(IInspectable)
  ['{FEB8466A-878F-577B-BBCA-89575CFC56E4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Spi_ISpiDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Spi_ISpiDevice; safecall;
    function GetResults: Spi_ISpiDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Spi_ISpiDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.ISpiDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Spi_SpiDevice)]
  Spi_ISpiDeviceStatics = interface(IInspectable)
  ['{A278E559-5720-4D3F-BD93-56F5FF5A5879}']
    function GetDeviceSelector: HSTRING; overload; safecall;
    function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; safecall;
    function GetBusInfo(busId: HSTRING): Spi_ISpiBusInfo; safecall;
    function FromIdAsync(busId: HSTRING; settings: Spi_ISpiConnectionSettings): IAsyncOperation_1__Spi_ISpiDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Spi.Provider.IProviderSpiConnectionSettingsFactory
  [WinRTClassNameAttribute(SWindows_Devices_Spi_Provider_ProviderSpiConnectionSettings)]
  Spi_Provider_IProviderSpiConnectionSettingsFactory = interface(IInspectable)
  ['{66456B5A-0C79-43E3-9F3C-E59780AC18FA}']
    function Create(chipSelectLine: Integer): Spi_Provider_IProviderSpiConnectionSettings; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbBulkInPipe
  Usb_IUsbBulkInPipe = interface(IInspectable)
  ['{F01D2D3B-4548-4D50-B326-D82CDABE1220}']
    function get_MaxTransferSizeBytes: Cardinal; safecall;
    function get_EndpointDescriptor: Usb_IUsbBulkInEndpointDescriptor; safecall;
    function ClearStallAsync: IAsyncAction; safecall;
    procedure put_ReadOptions(value: Usb_UsbReadOptions); safecall;
    function get_ReadOptions: Usb_UsbReadOptions; safecall;
    procedure FlushBuffer; safecall;
    function get_InputStream: IInputStream; safecall;
    property EndpointDescriptor: Usb_IUsbBulkInEndpointDescriptor read get_EndpointDescriptor;
    property InputStream: IInputStream read get_InputStream;
    property MaxTransferSizeBytes: Cardinal read get_MaxTransferSizeBytes;
    property ReadOptions: Usb_UsbReadOptions read get_ReadOptions write put_ReadOptions;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbBulkInEndpointDescriptor
  Usb_IUsbBulkInEndpointDescriptor = interface(IInspectable)
  ['{3C6E4846-06CF-42A9-9DC2-971C1B14B6E3}']
    function get_MaxPacketSize: Cardinal; safecall;
    function get_EndpointNumber: Byte; safecall;
    function get_Pipe: Usb_IUsbBulkInPipe; safecall;
    property EndpointNumber: Byte read get_EndpointNumber;
    property MaxPacketSize: Cardinal read get_MaxPacketSize;
    property Pipe: Usb_IUsbBulkInPipe read get_Pipe;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbBulkOutPipe
  Usb_IUsbBulkOutPipe = interface(IInspectable)
  ['{A8E9EE6E-0115-45AA-8B21-37B225BCCEE7}']
    function get_EndpointDescriptor: Usb_IUsbBulkOutEndpointDescriptor; safecall;
    function ClearStallAsync: IAsyncAction; safecall;
    procedure put_WriteOptions(value: Usb_UsbWriteOptions); safecall;
    function get_WriteOptions: Usb_UsbWriteOptions; safecall;
    function get_OutputStream: IOutputStream; safecall;
    property EndpointDescriptor: Usb_IUsbBulkOutEndpointDescriptor read get_EndpointDescriptor;
    property OutputStream: IOutputStream read get_OutputStream;
    property WriteOptions: Usb_UsbWriteOptions read get_WriteOptions write put_WriteOptions;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor
  Usb_IUsbBulkOutEndpointDescriptor = interface(IInspectable)
  ['{2820847A-FFEE-4F60-9BE1-956CAC3ECB65}']
    function get_MaxPacketSize: Cardinal; safecall;
    function get_EndpointNumber: Byte; safecall;
    function get_Pipe: Usb_IUsbBulkOutPipe; safecall;
    property EndpointNumber: Byte read get_EndpointNumber;
    property MaxPacketSize: Cardinal read get_MaxPacketSize;
    property Pipe: Usb_IUsbBulkOutPipe read get_Pipe;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbBulkInPipe>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IIterator_1__Usb_IUsbBulkInPipe = interface(IInspectable)
  ['{D7AF2C5B-528D-5CBB-A997-D830ADE704C7}']
    function get_Current: Usb_IUsbBulkInPipe; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbBulkInPipe): Cardinal; safecall;
    property Current: Usb_IUsbBulkInPipe read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbBulkInPipe>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IIterable_1__Usb_IUsbBulkInPipe = interface(IInspectable)
  ['{2201A671-42D2-508D-A848-64B5447083C8}']
    function First: IIterator_1__Usb_IUsbBulkInPipe; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkInPipe>
  IVectorView_1__Usb_IUsbBulkInPipe = interface(IInspectable)
  ['{07B6F572-D3C2-524D-836E-7C3D8CFA3F01}']
    function GetAt(index: Cardinal): Usb_IUsbBulkInPipe; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbBulkInPipe; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbBulkInPipe): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor
  Usb_IUsbInterruptInEndpointDescriptor = interface(IInspectable)
  ['{C0528967-C911-4C3A-86B2-419C2DA89039}']
    function get_MaxPacketSize: Cardinal; safecall;
    function get_EndpointNumber: Byte; safecall;
    function get_Interval: TimeSpan; safecall;
    function get_Pipe: Usb_IUsbInterruptInPipe; safecall;
    property EndpointNumber: Byte read get_EndpointNumber;
    property Interval: TimeSpan read get_Interval;
    property MaxPacketSize: Cardinal read get_MaxPacketSize;
    property Pipe: Usb_IUsbInterruptInPipe read get_Pipe;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterruptInEventArgs
  Usb_IUsbInterruptInEventArgs = interface(IInspectable)
  ['{B7B04092-1418-4936-8209-299CF5605583}']
    function get_InterruptData: IBuffer; safecall;
    property InterruptData: IBuffer read get_InterruptData;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Usb.UsbInterruptInPipe,Windows.Devices.Usb.UsbInterruptInEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.Usb.IUsbInterruptInPipe,Windows.Devices.Usb.IUsbInterruptInEventArgs>
  TypedEventHandler_2__Usb_IUsbInterruptInPipe__Usb_IUsbInterruptInEventArgs = interface(IUnknown)
  ['{E6DB9449-F36A-50F2-926C-2AFD85C49F01}']
    procedure Invoke(sender: Usb_IUsbInterruptInPipe; args: Usb_IUsbInterruptInEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterruptInPipe
  Usb_IUsbInterruptInPipe = interface(IInspectable)
  ['{FA007116-84D7-48C7-8A3F-4C0B235F2EA6}']
    function get_EndpointDescriptor: Usb_IUsbInterruptInEndpointDescriptor; safecall;
    function ClearStallAsync: IAsyncAction; safecall;
    function add_DataReceived(handler: TypedEventHandler_2__Usb_IUsbInterruptInPipe__Usb_IUsbInterruptInEventArgs): EventRegistrationToken; safecall;
    procedure remove_DataReceived(token: EventRegistrationToken); safecall;
    property EndpointDescriptor: Usb_IUsbInterruptInEndpointDescriptor read get_EndpointDescriptor;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterruptInPipe>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IIterator_1__Usb_IUsbInterruptInPipe = interface(IInspectable)
  ['{E3A7B1C0-74F6-5292-A22A-672AA2B49985}']
    function get_Current: Usb_IUsbInterruptInPipe; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterruptInPipe): Cardinal; safecall;
    property Current: Usb_IUsbInterruptInPipe read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterruptInPipe>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IIterable_1__Usb_IUsbInterruptInPipe = interface(IInspectable)
  ['{39AEF336-18AA-5BE4-86D9-E332FE2632F3}']
    function First: IIterator_1__Usb_IUsbInterruptInPipe; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptInPipe>
  IVectorView_1__Usb_IUsbInterruptInPipe = interface(IInspectable)
  ['{9E237120-79D7-5D18-9D14-E7F5F2AB8062}']
    function GetAt(index: Cardinal): Usb_IUsbInterruptInPipe; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterruptInPipe; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterruptInPipe): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbBulkOutPipe>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IIterator_1__Usb_IUsbBulkOutPipe = interface(IInspectable)
  ['{46DD2F6A-573B-5C45-B168-9223038491DD}']
    function get_Current: Usb_IUsbBulkOutPipe; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbBulkOutPipe): Cardinal; safecall;
    property Current: Usb_IUsbBulkOutPipe read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbBulkOutPipe>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IIterable_1__Usb_IUsbBulkOutPipe = interface(IInspectable)
  ['{9824CABA-5CA6-5C2D-80CF-1949026D7857}']
    function First: IIterator_1__Usb_IUsbBulkOutPipe; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkOutPipe>
  IVectorView_1__Usb_IUsbBulkOutPipe = interface(IInspectable)
  ['{A8E1014C-A104-577D-B617-85F5BCF273C5}']
    function GetAt(index: Cardinal): Usb_IUsbBulkOutPipe; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbBulkOutPipe; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbBulkOutPipe): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor
  Usb_IUsbInterruptOutEndpointDescriptor = interface(IInspectable)
  ['{CC9FED81-10CA-4533-952D-9E278341E80F}']
    function get_MaxPacketSize: Cardinal; safecall;
    function get_EndpointNumber: Byte; safecall;
    function get_Interval: TimeSpan; safecall;
    function get_Pipe: Usb_IUsbInterruptOutPipe; safecall;
    property EndpointNumber: Byte read get_EndpointNumber;
    property Interval: TimeSpan read get_Interval;
    property MaxPacketSize: Cardinal read get_MaxPacketSize;
    property Pipe: Usb_IUsbInterruptOutPipe read get_Pipe;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterruptOutPipe
  Usb_IUsbInterruptOutPipe = interface(IInspectable)
  ['{E984C8A9-AAF9-49D0-B96C-F661AB4A7F95}']
    function get_EndpointDescriptor: Usb_IUsbInterruptOutEndpointDescriptor; safecall;
    function ClearStallAsync: IAsyncAction; safecall;
    procedure put_WriteOptions(value: Usb_UsbWriteOptions); safecall;
    function get_WriteOptions: Usb_UsbWriteOptions; safecall;
    function get_OutputStream: IOutputStream; safecall;
    property EndpointDescriptor: Usb_IUsbInterruptOutEndpointDescriptor read get_EndpointDescriptor;
    property OutputStream: IOutputStream read get_OutputStream;
    property WriteOptions: Usb_UsbWriteOptions read get_WriteOptions write put_WriteOptions;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterruptOutPipe>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IIterator_1__Usb_IUsbInterruptOutPipe = interface(IInspectable)
  ['{CBD8D8A8-2286-5CBD-A6E4-962742FFD91A}']
    function get_Current: Usb_IUsbInterruptOutPipe; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterruptOutPipe): Cardinal; safecall;
    property Current: Usb_IUsbInterruptOutPipe read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterruptOutPipe>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IIterable_1__Usb_IUsbInterruptOutPipe = interface(IInspectable)
  ['{E61A011E-4ABE-53F2-83B3-ED4A949D2E3F}']
    function First: IIterator_1__Usb_IUsbInterruptOutPipe; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptOutPipe>
  IVectorView_1__Usb_IUsbInterruptOutPipe = interface(IInspectable)
  ['{AE2EFE6E-75DD-5DC0-B7E6-DBF87C02595D}']
    function GetAt(index: Cardinal): Usb_IUsbInterruptOutPipe; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterruptOutPipe; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterruptOutPipe): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbBulkInEndpointDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IIterator_1__Usb_IUsbBulkInEndpointDescriptor = interface(IInspectable)
  ['{EA511030-89C4-503D-8CAF-667F4230D2A9}']
    function get_Current: Usb_IUsbBulkInEndpointDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbBulkInEndpointDescriptor): Cardinal; safecall;
    property Current: Usb_IUsbBulkInEndpointDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbBulkInEndpointDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IIterable_1__Usb_IUsbBulkInEndpointDescriptor = interface(IInspectable)
  ['{101B1FD9-F1C9-5DDA-9AD4-71176FA839B2}']
    function First: IIterator_1__Usb_IUsbBulkInEndpointDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkInEndpointDescriptor>
  IVectorView_1__Usb_IUsbBulkInEndpointDescriptor = interface(IInspectable)
  ['{C69418D9-6878-5B7A-A0C7-A6B6B7A6B5A8}']
    function GetAt(index: Cardinal): Usb_IUsbBulkInEndpointDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbBulkInEndpointDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbBulkInEndpointDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterruptInEndpointDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IIterator_1__Usb_IUsbInterruptInEndpointDescriptor = interface(IInspectable)
  ['{6717500F-EC1C-5B12-BF33-0E3E3D244587}']
    function get_Current: Usb_IUsbInterruptInEndpointDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterruptInEndpointDescriptor): Cardinal; safecall;
    property Current: Usb_IUsbInterruptInEndpointDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterruptInEndpointDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IIterable_1__Usb_IUsbInterruptInEndpointDescriptor = interface(IInspectable)
  ['{8A7BAC69-1F10-59C7-9837-72CFED7154A4}']
    function First: IIterator_1__Usb_IUsbInterruptInEndpointDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptInEndpointDescriptor>
  IVectorView_1__Usb_IUsbInterruptInEndpointDescriptor = interface(IInspectable)
  ['{F0CEC6BF-FA60-5D88-A442-AB418F04D974}']
    function GetAt(index: Cardinal): Usb_IUsbInterruptInEndpointDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterruptInEndpointDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterruptInEndpointDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbBulkOutEndpointDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IIterator_1__Usb_IUsbBulkOutEndpointDescriptor = interface(IInspectable)
  ['{A8B89AB3-883D-5361-9903-F489CC62BEA5}']
    function get_Current: Usb_IUsbBulkOutEndpointDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbBulkOutEndpointDescriptor): Cardinal; safecall;
    property Current: Usb_IUsbBulkOutEndpointDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbBulkOutEndpointDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IIterable_1__Usb_IUsbBulkOutEndpointDescriptor = interface(IInspectable)
  ['{B80BEB39-62B3-5F59-B3E7-882CC9C5B0C0}']
    function First: IIterator_1__Usb_IUsbBulkOutEndpointDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbBulkOutEndpointDescriptor>
  IVectorView_1__Usb_IUsbBulkOutEndpointDescriptor = interface(IInspectable)
  ['{96922C96-FBD4-5EEB-83A6-B1E2BD6739BB}']
    function GetAt(index: Cardinal): Usb_IUsbBulkOutEndpointDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbBulkOutEndpointDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbBulkOutEndpointDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterruptOutEndpointDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IIterator_1__Usb_IUsbInterruptOutEndpointDescriptor = interface(IInspectable)
  ['{4B6426DB-DB32-5B51-ADAD-04532EA94ACD}']
    function get_Current: Usb_IUsbInterruptOutEndpointDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterruptOutEndpointDescriptor): Cardinal; safecall;
    property Current: Usb_IUsbInterruptOutEndpointDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterruptOutEndpointDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IIterable_1__Usb_IUsbInterruptOutEndpointDescriptor = interface(IInspectable)
  ['{09393D62-2316-536B-8A10-7038884AB2A7}']
    function First: IIterator_1__Usb_IUsbInterruptOutEndpointDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterruptOutEndpointDescriptor>
  IVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor = interface(IInspectable)
  ['{02341969-0617-5C88-957D-BEFF461E3278}']
    function GetAt(index: Cardinal): Usb_IUsbInterruptOutEndpointDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterruptOutEndpointDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterruptOutEndpointDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterfaceDescriptor
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbInterfaceDescriptor)]
  Usb_IUsbInterfaceDescriptor = interface(IInspectable)
  ['{199670C7-B7EE-4F90-8CD5-94A2E257598A}']
    function get_ClassCode: Byte; safecall;
    function get_SubclassCode: Byte; safecall;
    function get_ProtocolCode: Byte; safecall;
    function get_AlternateSettingNumber: Byte; safecall;
    function get_InterfaceNumber: Byte; safecall;
    property AlternateSettingNumber: Byte read get_AlternateSettingNumber;
    property ClassCode: Byte read get_ClassCode;
    property InterfaceNumber: Byte read get_InterfaceNumber;
    property ProtocolCode: Byte read get_ProtocolCode;
    property SubclassCode: Byte read get_SubclassCode;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDescriptor
  Usb_IUsbDescriptor = interface(IInspectable)
  ['{0A89F216-5F9D-4874-8904-DA9AD3F5528F}']
    function get_Length: Byte; safecall;
    function get_DescriptorType: Byte; safecall;
    procedure ReadDescriptorBuffer(buffer: IBuffer); safecall;
    property DescriptorType: Byte read get_DescriptorType;
    property Length: Byte read get_Length;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbDescriptor>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbDescriptor>
  IIterator_1__Usb_IUsbDescriptor = interface(IInspectable)
  ['{521598ED-0167-528E-990D-52ABB712F072}']
    function get_Current: Usb_IUsbDescriptor; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbDescriptor): Cardinal; safecall;
    property Current: Usb_IUsbDescriptor read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbDescriptor>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbDescriptor>
  IIterable_1__Usb_IUsbDescriptor = interface(IInspectable)
  ['{989909A5-5A03-51FB-BD94-84DA7BDA8819}']
    function First: IIterator_1__Usb_IUsbDescriptor; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbDescriptor>
  IVectorView_1__Usb_IUsbDescriptor = interface(IInspectable)
  ['{02B8F396-E5FD-5862-8C3D-552DD08C089B}']
    function GetAt(index: Cardinal): Usb_IUsbDescriptor; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbDescriptor; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbDescriptor): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterfaceSetting
  Usb_IUsbInterfaceSetting = interface(IInspectable)
  ['{1827BBA7-8DA7-4AF7-8F4C-7F3032E781F5}']
    function get_BulkInEndpoints: IVectorView_1__Usb_IUsbBulkInEndpointDescriptor; safecall;
    function get_InterruptInEndpoints: IVectorView_1__Usb_IUsbInterruptInEndpointDescriptor; safecall;
    function get_BulkOutEndpoints: IVectorView_1__Usb_IUsbBulkOutEndpointDescriptor; safecall;
    function get_InterruptOutEndpoints: IVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor; safecall;
    function get_Selected: Boolean; safecall;
    function SelectSettingAsync: IAsyncAction; safecall;
    function get_InterfaceDescriptor: Usb_IUsbInterfaceDescriptor; safecall;
    function get_Descriptors: IVectorView_1__Usb_IUsbDescriptor; safecall;
    property BulkInEndpoints: IVectorView_1__Usb_IUsbBulkInEndpointDescriptor read get_BulkInEndpoints;
    property BulkOutEndpoints: IVectorView_1__Usb_IUsbBulkOutEndpointDescriptor read get_BulkOutEndpoints;
    property Descriptors: IVectorView_1__Usb_IUsbDescriptor read get_Descriptors;
    property InterfaceDescriptor: Usb_IUsbInterfaceDescriptor read get_InterfaceDescriptor;
    property InterruptInEndpoints: IVectorView_1__Usb_IUsbInterruptInEndpointDescriptor read get_InterruptInEndpoints;
    property InterruptOutEndpoints: IVectorView_1__Usb_IUsbInterruptOutEndpointDescriptor read get_InterruptOutEndpoints;
    property Selected: Boolean read get_Selected;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterfaceSetting>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IIterator_1__Usb_IUsbInterfaceSetting = interface(IInspectable)
  ['{71267EC7-5697-5DEA-B2F8-14CF698EC0AD}']
    function get_Current: Usb_IUsbInterfaceSetting; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterfaceSetting): Cardinal; safecall;
    property Current: Usb_IUsbInterfaceSetting read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterfaceSetting>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IIterable_1__Usb_IUsbInterfaceSetting = interface(IInspectable)
  ['{1AAF5739-9C2C-533E-A0E9-D53FDB45D15D}']
    function First: IIterator_1__Usb_IUsbInterfaceSetting; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterfaceSetting>
  IVectorView_1__Usb_IUsbInterfaceSetting = interface(IInspectable)
  ['{9F7E471F-AA3B-5F83-A82D-A51187D16707}']
    function GetAt(index: Cardinal): Usb_IUsbInterfaceSetting; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterfaceSetting; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterfaceSetting): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterface
  Usb_IUsbInterface = interface(IInspectable)
  ['{A0322B95-7F47-48AB-A727-678C25BE2112}']
    function get_BulkInPipes: IVectorView_1__Usb_IUsbBulkInPipe; safecall;
    function get_InterruptInPipes: IVectorView_1__Usb_IUsbInterruptInPipe; safecall;
    function get_BulkOutPipes: IVectorView_1__Usb_IUsbBulkOutPipe; safecall;
    function get_InterruptOutPipes: IVectorView_1__Usb_IUsbInterruptOutPipe; safecall;
    function get_InterfaceSettings: IVectorView_1__Usb_IUsbInterfaceSetting; safecall;
    function get_InterfaceNumber: Byte; safecall;
    function get_Descriptors: IVectorView_1__Usb_IUsbDescriptor; safecall;
    property BulkInPipes: IVectorView_1__Usb_IUsbBulkInPipe read get_BulkInPipes;
    property BulkOutPipes: IVectorView_1__Usb_IUsbBulkOutPipe read get_BulkOutPipes;
    property Descriptors: IVectorView_1__Usb_IUsbDescriptor read get_Descriptors;
    property InterfaceNumber: Byte read get_InterfaceNumber;
    property InterfaceSettings: IVectorView_1__Usb_IUsbInterfaceSetting read get_InterfaceSettings;
    property InterruptInPipes: IVectorView_1__Usb_IUsbInterruptInPipe read get_InterruptInPipes;
    property InterruptOutPipes: IVectorView_1__Usb_IUsbInterruptOutPipe read get_InterruptOutPipes;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.UsbInterface>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Usb.IUsbInterface>
  IIterator_1__Usb_IUsbInterface = interface(IInspectable)
  ['{216B5A5F-63E3-5A9B-9C99-B09CBC0FF3B1}']
    function get_Current: Usb_IUsbInterface; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUsb_IUsbInterface): Cardinal; safecall;
    property Current: Usb_IUsbInterface read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.UsbInterface>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Usb.IUsbInterface>
  IIterable_1__Usb_IUsbInterface = interface(IInspectable)
  ['{F54037ED-92E9-590D-B904-3AD7BFA9A621}']
    function First: IIterator_1__Usb_IUsbInterface; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.Usb.IUsbInterface>
  IVectorView_1__Usb_IUsbInterface = interface(IInspectable)
  ['{CF4B10AB-3239-583A-8B72-82ECC4DB8AF3}']
    function GetAt(index: Cardinal): Usb_IUsbInterface; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Usb_IUsbInterface; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUsb_IUsbInterface): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbConfigurationDescriptor
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbConfigurationDescriptor)]
  Usb_IUsbConfigurationDescriptor = interface(IInspectable)
  ['{F2176D92-B442-407A-8207-7D646C0385F3}']
    function get_ConfigurationValue: Byte; safecall;
    function get_MaxPowerMilliamps: Cardinal; safecall;
    function get_SelfPowered: Boolean; safecall;
    function get_RemoteWakeup: Boolean; safecall;
    property ConfigurationValue: Byte read get_ConfigurationValue;
    property MaxPowerMilliamps: Cardinal read get_MaxPowerMilliamps;
    property RemoteWakeup: Boolean read get_RemoteWakeup;
    property SelfPowered: Boolean read get_SelfPowered;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbConfiguration
  Usb_IUsbConfiguration = interface(IInspectable)
  ['{68177429-36A9-46D7-B873-FC689251EC30}']
    function get_UsbInterfaces: IVectorView_1__Usb_IUsbInterface; safecall;
    function get_ConfigurationDescriptor: Usb_IUsbConfigurationDescriptor; safecall;
    function get_Descriptors: IVectorView_1__Usb_IUsbDescriptor; safecall;
    property ConfigurationDescriptor: Usb_IUsbConfigurationDescriptor read get_ConfigurationDescriptor;
    property Descriptors: IVectorView_1__Usb_IUsbDescriptor read get_Descriptors;
    property UsbInterfaces: IVectorView_1__Usb_IUsbInterface read get_UsbInterfaces;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbConfigurationDescriptorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbConfigurationDescriptor)]
  Usb_IUsbConfigurationDescriptorStatics = interface(IInspectable)
  ['{424CED93-E740-40A1-92BD-DA120EA04914}']
    function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbConfigurationDescriptor): Boolean; safecall;
    function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbConfigurationDescriptor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbControlRequestType
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbControlRequestType)]
  Usb_IUsbControlRequestType = interface(IInspectable)
  ['{8E9465A6-D73D-46DE-94BE-AAE7F07C0F5C}']
    function get_Direction: Usb_UsbTransferDirection; safecall;
    procedure put_Direction(value: Usb_UsbTransferDirection); safecall;
    function get_ControlTransferType: Usb_UsbControlTransferType; safecall;
    procedure put_ControlTransferType(value: Usb_UsbControlTransferType); safecall;
    function get_Recipient: Usb_UsbControlRecipient; safecall;
    procedure put_Recipient(value: Usb_UsbControlRecipient); safecall;
    function get_AsByte: Byte; safecall;
    procedure put_AsByte(value: Byte); safecall;
    property AsByte: Byte read get_AsByte write put_AsByte;
    property ControlTransferType: Usb_UsbControlTransferType read get_ControlTransferType write put_ControlTransferType;
    property Direction: Usb_UsbTransferDirection read get_Direction write put_Direction;
    property Recipient: Usb_UsbControlRecipient read get_Recipient write put_Recipient;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbSetupPacket
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbSetupPacket)]
  Usb_IUsbSetupPacket = interface(IInspectable)
  ['{104BA132-C78F-4C51-B654-E49D02F2CB03}']
    function get_RequestType: Usb_IUsbControlRequestType; safecall;
    procedure put_RequestType(value: Usb_IUsbControlRequestType); safecall;
    function get_Request: Byte; safecall;
    procedure put_Request(value: Byte); safecall;
    function get_Value: Cardinal; safecall;
    procedure put_Value(value: Cardinal); safecall;
    function get_Index: Cardinal; safecall;
    procedure put_Index(value: Cardinal); safecall;
    function get_Length: Cardinal; safecall;
    procedure put_Length(value: Cardinal); safecall;
    property Index: Cardinal read get_Index write put_Index;
    property Length: Cardinal read get_Length write put_Length;
    property Request: Byte read get_Request write put_Request;
    property RequestType: Usb_IUsbControlRequestType read get_RequestType write put_RequestType;
    property Value: Cardinal read get_Value write put_Value;
  end;

  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDeviceDescriptor
  Usb_IUsbDeviceDescriptor = interface(IInspectable)
  ['{1F48D1F6-BA97-4322-B92C-B5B189216588}']
    function get_BcdUsb: Cardinal; safecall;
    function get_MaxPacketSize0: Byte; safecall;
    function get_VendorId: Cardinal; safecall;
    function get_ProductId: Cardinal; safecall;
    function get_BcdDeviceRevision: Cardinal; safecall;
    function get_NumberOfConfigurations: Byte; safecall;
    property BcdDeviceRevision: Cardinal read get_BcdDeviceRevision;
    property BcdUsb: Cardinal read get_BcdUsb;
    property MaxPacketSize0: Byte read get_MaxPacketSize0;
    property NumberOfConfigurations: Byte read get_NumberOfConfigurations;
    property ProductId: Cardinal read get_ProductId;
    property VendorId: Cardinal read get_VendorId;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDevice
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbDevice)]
  Usb_IUsbDevice = interface(IInspectable)
  ['{5249B992-C456-44D5-AD5E-24F5A089F63B}']
    function SendControlOutTransferAsync(setupPacket: Usb_IUsbSetupPacket; buffer: IBuffer): IAsyncOperation_1__Cardinal; overload; safecall;
    function SendControlOutTransferAsync(setupPacket: Usb_IUsbSetupPacket): IAsyncOperation_1__Cardinal; overload; safecall;
    function SendControlInTransferAsync(setupPacket: Usb_IUsbSetupPacket; buffer: IBuffer): IAsyncOperation_1__IBuffer; overload; safecall;
    function SendControlInTransferAsync(setupPacket: Usb_IUsbSetupPacket): IAsyncOperation_1__IBuffer; overload; safecall;
    function get_DefaultInterface: Usb_IUsbInterface; safecall;
    function get_DeviceDescriptor: Usb_IUsbDeviceDescriptor; safecall;
    function get_Configuration: Usb_IUsbConfiguration; safecall;
    property Configuration: Usb_IUsbConfiguration read get_Configuration;
    property DefaultInterface: Usb_IUsbInterface read get_DefaultInterface;
    property DeviceDescriptor: Usb_IUsbDeviceDescriptor read get_DeviceDescriptor;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDeviceClass
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbDeviceClass)]
  Usb_IUsbDeviceClass = interface(IInspectable)
  ['{051942F9-845E-47EB-B12A-38F2F617AFE7}']
    function get_ClassCode: Byte; safecall;
    procedure put_ClassCode(value: Byte); safecall;
    function get_SubclassCode: IReference_1__Byte; safecall;
    procedure put_SubclassCode(value: IReference_1__Byte); safecall;
    function get_ProtocolCode: IReference_1__Byte; safecall;
    procedure put_ProtocolCode(value: IReference_1__Byte); safecall;
    property ClassCode: Byte read get_ClassCode write put_ClassCode;
    property ProtocolCode: IReference_1__Byte read get_ProtocolCode write put_ProtocolCode;
    property SubclassCode: IReference_1__Byte read get_SubclassCode write put_SubclassCode;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDeviceClasses
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbDeviceClasses)]
  Usb_IUsbDeviceClasses = interface(IInspectable)
  ['{686F955D-9B92-4B30-9781-C22C55AC35CB}']
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDeviceClassesStatics
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbDeviceClasses)]
  Usb_IUsbDeviceClassesStatics = interface(IInspectable)
  ['{B20B0527-C580-4599-A165-981B4FD03230}']
    function get_CdcControl: Usb_IUsbDeviceClass; safecall;
    function get_Physical: Usb_IUsbDeviceClass; safecall;
    function get_PersonalHealthcare: Usb_IUsbDeviceClass; safecall;
    function get_ActiveSync: Usb_IUsbDeviceClass; safecall;
    function get_PalmSync: Usb_IUsbDeviceClass; safecall;
    function get_DeviceFirmwareUpdate: Usb_IUsbDeviceClass; safecall;
    function get_Irda: Usb_IUsbDeviceClass; safecall;
    function get_Measurement: Usb_IUsbDeviceClass; safecall;
    function get_VendorSpecific: Usb_IUsbDeviceClass; safecall;
    property ActiveSync: Usb_IUsbDeviceClass read get_ActiveSync;
    property CdcControl: Usb_IUsbDeviceClass read get_CdcControl;
    property DeviceFirmwareUpdate: Usb_IUsbDeviceClass read get_DeviceFirmwareUpdate;
    property Irda: Usb_IUsbDeviceClass read get_Irda;
    property Measurement: Usb_IUsbDeviceClass read get_Measurement;
    property PalmSync: Usb_IUsbDeviceClass read get_PalmSync;
    property PersonalHealthcare: Usb_IUsbDeviceClass read get_PersonalHealthcare;
    property Physical: Usb_IUsbDeviceClass read get_Physical;
    property VendorSpecific: Usb_IUsbDeviceClass read get_VendorSpecific;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Usb.UsbDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.Usb.IUsbDevice>
  AsyncOperationCompletedHandler_1__Usb_IUsbDevice = interface(IUnknown)
  ['{7331254F-6CAF-587D-9C2A-018C66D312DB}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__Usb_IUsbDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Usb.UsbDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.Usb.IUsbDevice>
  IAsyncOperation_1__Usb_IUsbDevice = interface(IInspectable)
  ['{2138C5ED-B71A-5166-9948-D55792748F5C}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__Usb_IUsbDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__Usb_IUsbDevice; safecall;
    function GetResults: Usb_IUsbDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__Usb_IUsbDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbDevice)]
  Usb_IUsbDeviceStatics = interface(IInspectable)
  ['{066B85A2-09B7-4446-8502-6FE6DCAA7309}']
    function GetDeviceSelector(vendorId: Cardinal; productId: Cardinal; winUsbInterfaceClass: TGuid): HSTRING; overload; safecall;
    function GetDeviceSelector(winUsbInterfaceClass: TGuid): HSTRING; overload; safecall;
    function GetDeviceSelector(vendorId: Cardinal; productId: Cardinal): HSTRING; overload; safecall;
    function GetDeviceClassSelector(usbClass: Usb_IUsbDeviceClass): HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Usb_IUsbDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbEndpointDescriptor
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbEndpointDescriptor)]
  Usb_IUsbEndpointDescriptor = interface(IInspectable)
  ['{6B4862D9-8DF7-4B40-AC83-578F139F0575}']
    function get_EndpointNumber: Byte; safecall;
    function get_Direction: Usb_UsbTransferDirection; safecall;
    function get_EndpointType: Usb_UsbEndpointType; safecall;
    function get_AsBulkInEndpointDescriptor: Usb_IUsbBulkInEndpointDescriptor; safecall;
    function get_AsInterruptInEndpointDescriptor: Usb_IUsbInterruptInEndpointDescriptor; safecall;
    function get_AsBulkOutEndpointDescriptor: Usb_IUsbBulkOutEndpointDescriptor; safecall;
    function get_AsInterruptOutEndpointDescriptor: Usb_IUsbInterruptOutEndpointDescriptor; safecall;
    property AsBulkInEndpointDescriptor: Usb_IUsbBulkInEndpointDescriptor read get_AsBulkInEndpointDescriptor;
    property AsBulkOutEndpointDescriptor: Usb_IUsbBulkOutEndpointDescriptor read get_AsBulkOutEndpointDescriptor;
    property AsInterruptInEndpointDescriptor: Usb_IUsbInterruptInEndpointDescriptor read get_AsInterruptInEndpointDescriptor;
    property AsInterruptOutEndpointDescriptor: Usb_IUsbInterruptOutEndpointDescriptor read get_AsInterruptOutEndpointDescriptor;
    property Direction: Usb_UsbTransferDirection read get_Direction;
    property EndpointNumber: Byte read get_EndpointNumber;
    property EndpointType: Usb_UsbEndpointType read get_EndpointType;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbEndpointDescriptorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbEndpointDescriptor)]
  Usb_IUsbEndpointDescriptorStatics = interface(IInspectable)
  ['{C890B201-9A6A-495E-A82C-295B9E708106}']
    function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbEndpointDescriptor): Boolean; safecall;
    function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbEndpointDescriptor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbInterfaceDescriptorStatics
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbInterfaceDescriptor)]
  Usb_IUsbInterfaceDescriptorStatics = interface(IInspectable)
  ['{E34A9FF5-77D6-48B6-B0BE-16C6422316FE}']
    function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbInterfaceDescriptor): Boolean; safecall;
    function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbInterfaceDescriptor; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.Usb.IUsbSetupPacketFactory
  [WinRTClassNameAttribute(SWindows_Devices_Usb_UsbSetupPacket)]
  Usb_IUsbSetupPacketFactory = interface(IInspectable)
  ['{C9257D50-1B2E-4A41-A2A7-338F0CEF3C14}']
    function CreateWithEightByteBuffer(eightByteBuffer: IBuffer): Usb_IUsbSetupPacket; safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiAvailableNetwork
  WiFi_IWiFiAvailableNetwork = interface(IInspectable)
  ['{26E96246-183E-4704-9826-71B4A2F0F668}']
    function get_Uptime: TimeSpan; safecall;
    function get_Ssid: HSTRING; safecall;
    function get_Bssid: HSTRING; safecall;
    function get_ChannelCenterFrequencyInKilohertz: Integer; safecall;
    function get_NetworkRssiInDecibelMilliwatts: Double; safecall;
    function get_SignalBars: Byte; safecall;
    function get_NetworkKind: WiFi_WiFiNetworkKind; safecall;
    function get_PhyKind: WiFi_WiFiPhyKind; safecall;
    function get_SecuritySettings: INetworkSecuritySettings; safecall;
    function get_BeaconInterval: TimeSpan; safecall;
    function get_IsWiFiDirect: Boolean; safecall;
    property BeaconInterval: TimeSpan read get_BeaconInterval;
    property Bssid: HSTRING read get_Bssid;
    property ChannelCenterFrequencyInKilohertz: Integer read get_ChannelCenterFrequencyInKilohertz;
    property IsWiFiDirect: Boolean read get_IsWiFiDirect;
    property NetworkKind: WiFi_WiFiNetworkKind read get_NetworkKind;
    property NetworkRssiInDecibelMilliwatts: Double read get_NetworkRssiInDecibelMilliwatts;
    property PhyKind: WiFi_WiFiPhyKind read get_PhyKind;
    property SecuritySettings: INetworkSecuritySettings read get_SecuritySettings;
    property SignalBars: Byte read get_SignalBars;
    property Ssid: HSTRING read get_Ssid;
    property Uptime: TimeSpan read get_Uptime;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.WiFiAvailableNetwork>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IIterator_1__WiFi_IWiFiAvailableNetwork = interface(IInspectable)
  ['{468677C4-EBB9-5196-836D-72FAA9FE673E}']
    function get_Current: WiFi_IWiFiAvailableNetwork; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFi_IWiFiAvailableNetwork): Cardinal; safecall;
    property Current: WiFi_IWiFiAvailableNetwork read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.WiFiAvailableNetwork>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IIterable_1__WiFi_IWiFiAvailableNetwork = interface(IInspectable)
  ['{F17484EA-C71E-5D3E-B74C-3A0E61DD9C20}']
    function First: IIterator_1__WiFi_IWiFiAvailableNetwork; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAvailableNetwork>
  IVectorView_1__WiFi_IWiFiAvailableNetwork = interface(IInspectable)
  ['{9DDD5C88-94EF-5125-8BC1-B324F35BCF9E}']
    function GetAt(index: Cardinal): WiFi_IWiFiAvailableNetwork; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFi_IWiFiAvailableNetwork; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFi_IWiFiAvailableNetwork): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiNetworkReport
  WiFi_IWiFiNetworkReport = interface(IInspectable)
  ['{9524DED2-5911-445E-8194-BE4F1A704895}']
    function get_Timestamp: DateTime; safecall;
    function get_AvailableNetworks: IVectorView_1__WiFi_IWiFiAvailableNetwork; safecall;
    property AvailableNetworks: IVectorView_1__WiFi_IWiFiAvailableNetwork read get_AvailableNetworks;
    property Timestamp: DateTime read get_Timestamp;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFi.WiFiAdapter,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFi.IWiFiAdapter,Object>
  TypedEventHandler_2__WiFi_IWiFiAdapter__IInspectable = interface(IUnknown)
  ['{F6C02D1B-43E8-5FC8-8E8E-EE7B8094B683}']
    procedure Invoke(sender: WiFi_IWiFiAdapter; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiConnectionResult
  WiFi_IWiFiConnectionResult = interface(IInspectable)
  ['{143BDFD9-C37D-40BE-A5C8-857BCE85A931}']
    function get_ConnectionStatus: WiFi_WiFiConnectionStatus; safecall;
    property ConnectionStatus: WiFi_WiFiConnectionStatus read get_ConnectionStatus;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.WiFiConnectionResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiConnectionResult>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult = interface(IUnknown)
  ['{F380EB8D-1E52-5350-A288-861C963A84F0}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFi_IWiFiConnectionResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.WiFiConnectionResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiConnectionResult>
  IAsyncOperation_1__WiFi_IWiFiConnectionResult = interface(IInspectable)
  ['{FFA41F49-4C30-50D3-9549-E4F055B417B4}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult; safecall;
    function GetResults: WiFi_IWiFiConnectionResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiConnectionResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiAdapter
  [WinRTClassNameAttribute(SWindows_Devices_WiFi_WiFiAdapter)]
  WiFi_IWiFiAdapter = interface(IInspectable)
  ['{A6C4E423-3D75-43A4-B9DE-11E26B72D9B0}']
    function get_NetworkAdapter: INetworkAdapter; safecall;
    function ScanAsync: IAsyncAction; safecall;
    function get_NetworkReport: WiFi_IWiFiNetworkReport; safecall;
    function add_AvailableNetworksChanged(args: TypedEventHandler_2__WiFi_IWiFiAdapter__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AvailableNetworksChanged(eventCookie: EventRegistrationToken); safecall;
    function ConnectAsync(availableNetwork: WiFi_IWiFiAvailableNetwork; reconnectionKind: WiFi_WiFiReconnectionKind): IAsyncOperation_1__WiFi_IWiFiConnectionResult; overload; safecall;
    function ConnectAsync(availableNetwork: WiFi_IWiFiAvailableNetwork; reconnectionKind: WiFi_WiFiReconnectionKind; passwordCredential: IPasswordCredential): IAsyncOperation_1__WiFi_IWiFiConnectionResult; overload; safecall;
    function ConnectAsync(availableNetwork: WiFi_IWiFiAvailableNetwork; reconnectionKind: WiFi_WiFiReconnectionKind; passwordCredential: IPasswordCredential; ssid: HSTRING): IAsyncOperation_1__WiFi_IWiFiConnectionResult; overload; safecall;
    procedure Disconnect; safecall;
    property NetworkAdapter: INetworkAdapter read get_NetworkAdapter;
    property NetworkReport: WiFi_IWiFiNetworkReport read get_NetworkReport;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.WiFiWpsKind>
  IIterator_1__WiFi_WiFiWpsKind = interface(IInspectable)
  ['{9B19593C-602D-57D9-A852-A48A8204FF42}']
    function get_Current: WiFi_WiFiWpsKind; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFi_WiFiWpsKind): Cardinal; safecall;
    property Current: WiFi_WiFiWpsKind read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.WiFiWpsKind>
  IIterable_1__WiFi_WiFiWpsKind = interface(IInspectable)
  ['{41E16513-A8F2-55ED-9BE4-5665167D49D7}']
    function First: IIterator_1__WiFi_WiFiWpsKind; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.WiFiWpsKind>
  IVectorView_1__WiFi_WiFiWpsKind = interface(IInspectable)
  ['{AAE7E5E5-27F0-5B28-8C58-9039356D3DC7}']
    function GetAt(index: Cardinal): WiFi_WiFiWpsKind; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFi_WiFiWpsKind; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFi_WiFiWpsKind): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiWpsConfigurationResult
  WiFi_IWiFiWpsConfigurationResult = interface(IInspectable)
  ['{67B49871-17EE-42D1-B14F-5A11F1226FB5}']
    function get_Status: WiFi_WiFiWpsConfigurationStatus; safecall;
    function get_SupportedWpsKinds: IVectorView_1__WiFi_WiFiWpsKind; safecall;
    property Status: WiFi_WiFiWpsConfigurationStatus read get_Status;
    property SupportedWpsKinds: IVectorView_1__WiFi_WiFiWpsKind read get_SupportedWpsKinds;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.WiFiWpsConfigurationResult>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiWpsConfigurationResult>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult = interface(IUnknown)
  ['{33FA345B-28CD-58A8-BCFC-BE4CFD108E91}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.WiFiWpsConfigurationResult>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiWpsConfigurationResult>
  IAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult = interface(IInspectable)
  ['{4B721D74-0289-583C-A81D-F3BE03EA596D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult; safecall;
    function GetResults: WiFi_IWiFiWpsConfigurationResult; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiWpsConfigurationResult read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiAdapter2
  WiFi_IWiFiAdapter2 = interface(IInspectable)
  ['{5BC4501D-81E4-453D-9430-1FCAFBADD6B6}']
    function GetWpsConfigurationAsync(availableNetwork: WiFi_IWiFiAvailableNetwork): IAsyncOperation_1__WiFi_IWiFiWpsConfigurationResult; safecall;
    function ConnectAsync(availableNetwork: WiFi_IWiFiAvailableNetwork; reconnectionKind: WiFi_WiFiReconnectionKind; passwordCredential: IPasswordCredential; ssid: HSTRING; connectionMethod: WiFi_WiFiConnectionMethod): IAsyncOperation_1__WiFi_IWiFiConnectionResult; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.WiFiAdapter>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFi.IWiFiAdapter>
  IIterator_1__WiFi_IWiFiAdapter = interface(IInspectable)
  ['{144136C6-B502-5A52-90FC-22A09318F932}']
    function get_Current: WiFi_IWiFiAdapter; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFi_IWiFiAdapter): Cardinal; safecall;
    property Current: WiFi_IWiFiAdapter read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.WiFiAdapter>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFi.IWiFiAdapter>
  IIterable_1__WiFi_IWiFiAdapter = interface(IInspectable)
  ['{E0BC76C4-8D0C-53FC-BCD4-228F47210ACE}']
    function First: IIterator_1__WiFi_IWiFiAdapter; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>
  IVectorView_1__WiFi_IWiFiAdapter = interface(IInspectable)
  ['{E9CDED59-810B-5D57-98DA-A23C1FCE0032}']
    function GetAt(index: Cardinal): WiFi_IWiFiAdapter; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFi_IWiFiAdapter; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFi_IWiFiAdapter): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.WiFiAdapter>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>>
  AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter = interface(IUnknown)
  ['{92902A07-2F18-56E9-87FB-24FE19F70688}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.WiFiAdapter>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFi.IWiFiAdapter>>
  IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter = interface(IInspectable)
  ['{3140802B-987C-5C56-A430-90FBC1898DDA}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter; safecall;
    function GetResults: IVectorView_1__WiFi_IWiFiAdapter; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__WiFi_IWiFiAdapter read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.WiFiAdapter>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.IWiFiAdapter>
  AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter = interface(IUnknown)
  ['{35362F75-6AAE-560D-B3D0-3FAE9C7260A8}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFi_IWiFiAdapter; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.WiFiAdapter>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.IWiFiAdapter>
  IAsyncOperation_1__WiFi_IWiFiAdapter = interface(IInspectable)
  ['{1DCF739D-10B7-59E9-AB47-8B0277E20193}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter; safecall;
    function GetResults: WiFi_IWiFiAdapter; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFi_IWiFiAdapter read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFi.WiFiAccessStatus>
  AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus = interface(IUnknown)
  ['{65E889CA-F6C9-5C75-BEF9-05AB88A49A54}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFi_WiFiAccessStatus; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFi.WiFiAccessStatus>
  IAsyncOperation_1__WiFi_WiFiAccessStatus = interface(IInspectable)
  ['{F8C75A3A-739A-57AA-986D-1F7604D7E386}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus; safecall;
    function GetResults: WiFi_WiFiAccessStatus; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFi_WiFiAccessStatus read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFi.IWiFiAdapterStatics
  [WinRTClassNameAttribute(SWindows_Devices_WiFi_WiFiAdapter)]
  WiFi_IWiFiAdapterStatics = interface(IInspectable)
  ['{DA25FDDD-D24C-43E3-AABD-C4659F730F99}']
    function FindAllAdaptersAsync: IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter; safecall;
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFi_IWiFiAdapter; safecall;
    function RequestAccessAsync: IAsyncOperation_1__WiFi_WiFiAccessStatus; safecall;
  end;

  // Windows.Foundation.IReference`1<Windows.Devices.WiFi.WiFiOnDemandHotspotCellularBars>
  IReference_1__WiFi_WiFiOnDemandHotspotCellularBars = interface(IInspectable)
  ['{D5CC7E52-2520-5460-84E6-8258C83D0C68}']
    function get_Value: WiFi_WiFiOnDemandHotspotCellularBars; safecall;
    property Value: WiFi_WiFiOnDemandHotspotCellularBars read get_Value;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectInformationElement
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectInformationElement)]
  WiFiDirect_IWiFiDirectInformationElement = interface(IInspectable)
  ['{AFFB72D6-76BB-497E-AC8B-DC72838BC309}']
    function get_Oui: IBuffer; safecall;
    procedure put_Oui(value: IBuffer); safecall;
    function get_OuiType: Byte; safecall;
    procedure put_OuiType(value: Byte); safecall;
    function get_Value: IBuffer; safecall;
    procedure put_Value(value: IBuffer); safecall;
    property Oui: IBuffer read get_Oui write put_Oui;
    property OuiType: Byte read get_OuiType write put_OuiType;
    property Value: IBuffer read get_Value write put_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.WiFiDirectInformationElement>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IIterator_1__WiFiDirect_IWiFiDirectInformationElement = interface(IInspectable)
  ['{CF806026-C915-553E-AF3C-8DA43871B693}']
    function get_Current: WiFiDirect_IWiFiDirectInformationElement; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFiDirect_IWiFiDirectInformationElement): Cardinal; safecall;
    property Current: WiFiDirect_IWiFiDirectInformationElement read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.WiFiDirectInformationElement>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IIterable_1__WiFiDirect_IWiFiDirectInformationElement = interface(IInspectable)
  ['{19C1CA4E-9561-5253-96D9-DBAF28D47D89}']
    function First: IIterator_1__WiFiDirect_IWiFiDirectInformationElement; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IVectorView_1__WiFiDirect_IWiFiDirectInformationElement = interface(IInspectable)
  ['{3E40623D-5498-5C64-A898-2C06586E5EA5}']
    function GetAt(index: Cardinal): WiFiDirect_IWiFiDirectInformationElement; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFiDirect_IWiFiDirectInformationElement; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_IWiFiDirectInformationElement): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.WiFiDirectInformationElement>
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.IWiFiDirectInformationElement>
  IVector_1__WiFiDirect_IWiFiDirectInformationElement = interface(IInspectable)
  ['{B8C55492-E4DE-5BA7-8476-D3BAB557CDD6}']
    function GetAt(index: Cardinal): WiFiDirect_IWiFiDirectInformationElement; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__WiFiDirect_IWiFiDirectInformationElement; safecall;
    function IndexOf(value: WiFiDirect_IWiFiDirectInformationElement; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: WiFiDirect_IWiFiDirectInformationElement); safecall;
    procedure InsertAt(index: Cardinal; value: WiFiDirect_IWiFiDirectInformationElement); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: WiFiDirect_IWiFiDirectInformationElement); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_IWiFiDirectInformationElement): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PWiFiDirect_IWiFiDirectInformationElement); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectLegacySettings
  WiFiDirect_IWiFiDirectLegacySettings = interface(IInspectable)
  ['{A64FDBBA-F2FD-4567-A91B-F5C2F5321057}']
    function get_IsEnabled: Boolean; safecall;
    procedure put_IsEnabled(value: Boolean); safecall;
    function get_Ssid: HSTRING; safecall;
    procedure put_Ssid(value: HSTRING); safecall;
    function get_Passphrase: IPasswordCredential; safecall;
    procedure put_Passphrase(value: IPasswordCredential); safecall;
    property IsEnabled: Boolean read get_IsEnabled write put_IsEnabled;
    property Passphrase: IPasswordCredential read get_Passphrase write put_Passphrase;
    property Ssid: HSTRING read get_Ssid write put_Ssid;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisement
  WiFiDirect_IWiFiDirectAdvertisement = interface(IInspectable)
  ['{AB511A2D-2A06-49A1-A584-61435C7905A6}']
    function get_InformationElements: IVector_1__WiFiDirect_IWiFiDirectInformationElement; safecall;
    procedure put_InformationElements(value: IVector_1__WiFiDirect_IWiFiDirectInformationElement); safecall;
    function get_ListenStateDiscoverability: WiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability; safecall;
    procedure put_ListenStateDiscoverability(value: WiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability); safecall;
    function get_IsAutonomousGroupOwnerEnabled: Boolean; safecall;
    procedure put_IsAutonomousGroupOwnerEnabled(value: Boolean); safecall;
    function get_LegacySettings: WiFiDirect_IWiFiDirectLegacySettings; safecall;
    property InformationElements: IVector_1__WiFiDirect_IWiFiDirectInformationElement read get_InformationElements write put_InformationElements;
    property IsAutonomousGroupOwnerEnabled: Boolean read get_IsAutonomousGroupOwnerEnabled write put_IsAutonomousGroupOwnerEnabled;
    property LegacySettings: WiFiDirect_IWiFiDirectLegacySettings read get_LegacySettings;
    property ListenStateDiscoverability: WiFiDirect_WiFiDirectAdvertisementListenStateDiscoverability read get_ListenStateDiscoverability write put_ListenStateDiscoverability;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IIterator_1__WiFiDirect_WiFiDirectConfigurationMethod = interface(IInspectable)
  ['{201940F9-A368-57F4-9EF2-3F64E243E0A4}']
    function get_Current: WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFiDirect_WiFiDirectConfigurationMethod): Cardinal; safecall;
    property Current: WiFiDirect_WiFiDirectConfigurationMethod read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IIterable_1__WiFiDirect_WiFiDirectConfigurationMethod = interface(IInspectable)
  ['{794F12DA-2DC6-5277-82DC-B0781610537B}']
    function First: IIterator_1__WiFiDirect_WiFiDirectConfigurationMethod; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IVectorView_1__WiFiDirect_WiFiDirectConfigurationMethod = interface(IInspectable)
  ['{61A32670-04D3-551D-AD66-BD04E9EF5C78}']
    function GetAt(index: Cardinal): WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFiDirect_WiFiDirectConfigurationMethod; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_WiFiDirectConfigurationMethod): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.WiFiDirectConfigurationMethod>
  IVector_1__WiFiDirect_WiFiDirectConfigurationMethod = interface(IInspectable)
  ['{9B498BC0-B474-5587-B65C-E600965F8FD0}']
    function GetAt(index: Cardinal): WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    function IndexOf(value: WiFiDirect_WiFiDirectConfigurationMethod; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: WiFiDirect_WiFiDirectConfigurationMethod); safecall;
    procedure InsertAt(index: Cardinal; value: WiFiDirect_WiFiDirectConfigurationMethod); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: WiFiDirect_WiFiDirectConfigurationMethod); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_WiFiDirectConfigurationMethod): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PWiFiDirect_WiFiDirectConfigurationMethod); safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisement2
  WiFiDirect_IWiFiDirectAdvertisement2 = interface(IInspectable)
  ['{B759AA46-D816-491B-917A-B40D7DC403A2}']
    function get_SupportedConfigurationMethods: IVector_1__WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    property SupportedConfigurationMethods: IVector_1__WiFiDirect_WiFiDirectConfigurationMethod read get_SupportedConfigurationMethods;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisherStatusChangedEventArgs
  WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = interface(IInspectable)
  ['{AAFDE53C-5481-46E6-90DD-32116518F192}']
    function get_Status: WiFiDirect_WiFiDirectAdvertisementPublisherStatus; safecall;
    function get_Error: WiFiDirect_WiFiDirectError; safecall;
    property Error: WiFiDirect_WiFiDirectError read get_Error;
    property Status: WiFiDirect_WiFiDirectAdvertisementPublisherStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.WiFiDirectAdvertisementPublisher,Windows.Devices.WiFiDirect.WiFiDirectAdvertisementPublisherStatusChangedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisher,Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisherStatusChangedEventArgs>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectAdvertisementPublisher__WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs = interface(IUnknown)
  ['{DE73CBA7-370D-550C-B23A-53DD0B4E480D}']
    procedure Invoke(sender: WiFiDirect_IWiFiDirectAdvertisementPublisher; args: WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisher
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectAdvertisementPublisher)]
  WiFiDirect_IWiFiDirectAdvertisementPublisher = interface(IInspectable)
  ['{B35A2D1A-9B1F-45D9-925A-694D66DF68EF}']
    function get_Advertisement: WiFiDirect_IWiFiDirectAdvertisement; safecall;
    function get_Status: WiFiDirect_WiFiDirectAdvertisementPublisherStatus; safecall;
    function add_StatusChanged(handler: TypedEventHandler_2__WiFiDirect_IWiFiDirectAdvertisementPublisher__WiFiDirect_IWiFiDirectAdvertisementPublisherStatusChangedEventArgs): EventRegistrationToken; safecall;
    procedure remove_StatusChanged(token: EventRegistrationToken); safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property Advertisement: WiFiDirect_IWiFiDirectAdvertisement read get_Advertisement;
    property Status: WiFiDirect_WiFiDirectAdvertisementPublisherStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequest
  WiFiDirect_IWiFiDirectConnectionRequest = interface(IInspectable)
  ['{8EB99605-914F-49C3-A614-D18DC5B19B43}']
    function get_DeviceInformation: IDeviceInformation; safecall;
    property DeviceInformation: IDeviceInformation read get_DeviceInformation;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequestedEventArgs
  WiFiDirect_IWiFiDirectConnectionRequestedEventArgs = interface(IInspectable)
  ['{F99D20BE-D38D-484F-8215-E7B65ABF244C}']
    function GetConnectionRequest: WiFiDirect_IWiFiDirectConnectionRequest; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.WiFiDirectConnectionListener,Windows.Devices.WiFiDirect.WiFiDirectConnectionRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectConnectionListener,Windows.Devices.WiFiDirect.IWiFiDirectConnectionRequestedEventArgs>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectConnectionListener__WiFiDirect_IWiFiDirectConnectionRequestedEventArgs = interface(IUnknown)
  ['{D04B0403-1FE2-532F-8E47-4823A14E624F}']
    procedure Invoke(sender: WiFiDirect_IWiFiDirectConnectionListener; args: WiFiDirect_IWiFiDirectConnectionRequestedEventArgs); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionListener
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectConnectionListener)]
  WiFiDirect_IWiFiDirectConnectionListener = interface(IInspectable)
  ['{699C1B0D-8D13-4EE9-B9EC-9C72F8251F7D}']
    function add_ConnectionRequested(handler: TypedEventHandler_2__WiFiDirect_IWiFiDirectConnectionListener__WiFiDirect_IWiFiDirectConnectionRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_ConnectionRequested(token: EventRegistrationToken); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectConnectionParameters)]
  WiFiDirect_IWiFiDirectConnectionParameters = interface(IInspectable)
  ['{B2E55405-5702-4B16-A02C-BBCD21EF6098}']
    function get_GroupOwnerIntent: SmallInt; safecall;
    procedure put_GroupOwnerIntent(value: SmallInt); safecall;
    property GroupOwnerIntent: SmallInt read get_GroupOwnerIntent write put_GroupOwnerIntent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters2
  WiFiDirect_IWiFiDirectConnectionParameters2 = interface(IInspectable)
  ['{AB3B0FBE-AA82-44B4-88C8-E3056B89801D}']
    function get_PreferenceOrderedConfigurationMethods: IVector_1__WiFiDirect_WiFiDirectConfigurationMethod; safecall;
    function get_PreferredPairingProcedure: WiFiDirect_WiFiDirectPairingProcedure; safecall;
    procedure put_PreferredPairingProcedure(value: WiFiDirect_WiFiDirectPairingProcedure); safecall;
    property PreferenceOrderedConfigurationMethods: IVector_1__WiFiDirect_WiFiDirectConfigurationMethod read get_PreferenceOrderedConfigurationMethods;
    property PreferredPairingProcedure: WiFiDirect_WiFiDirectPairingProcedure read get_PreferredPairingProcedure write put_PreferredPairingProcedure;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectConnectionParametersStatics
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectConnectionParameters)]
  WiFiDirect_IWiFiDirectConnectionParametersStatics = interface(IInspectable)
  ['{598AF493-7642-456F-B9D8-E8A9EB1F401A}']
    function GetDevicePairingKinds(configurationMethod: WiFiDirect_WiFiDirectConfigurationMethod): DevicePairingKinds; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.WiFiDirectDevice,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.IWiFiDirectDevice,Object>
  TypedEventHandler_2__WiFiDirect_IWiFiDirectDevice__IInspectable = interface(IUnknown)
  ['{9208929A-2A3C-50AD-AA08-A0A986EDBABE}']
    procedure Invoke(sender: WiFiDirect_IWiFiDirectDevice; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectDevice
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectDevice)]
  WiFiDirect_IWiFiDirectDevice = interface(IInspectable)
  ['{72DEAAA8-72EB-4DAE-8A28-8513355D2777}']
    function get_ConnectionStatus: WiFiDirect_WiFiDirectConnectionStatus; safecall;
    function get_DeviceId: HSTRING; safecall;
    function add_ConnectionStatusChanged(handler: TypedEventHandler_2__WiFiDirect_IWiFiDirectDevice__IInspectable): EventRegistrationToken; safecall;
    procedure remove_ConnectionStatusChanged(token: EventRegistrationToken); safecall;
    function GetConnectionEndpointPairs: IVectorView_1__IEndpointPair; safecall;
    property ConnectionStatus: WiFiDirect_WiFiDirectConnectionStatus read get_ConnectionStatus;
    property DeviceId: HSTRING read get_DeviceId;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.WiFiDirectDevice>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.IWiFiDirectDevice>
  AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice = interface(IUnknown)
  ['{D34ABE17-FB19-57BE-BC41-0EB83DEA151C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.WiFiDirectDevice>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.IWiFiDirectDevice>
  IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice = interface(IInspectable)
  ['{DAD01B61-A82D-566C-BA82-224C11500669}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice; safecall;
    function GetResults: WiFiDirect_IWiFiDirectDevice; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFiDirect_IWiFiDirectDevice read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectDevice)]
  WiFiDirect_IWiFiDirectDeviceStatics = interface(IInspectable)
  ['{E86CB57C-3AAC-4851-A792-482AAF931B04}']
    function GetDeviceSelector: HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics2
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectDevice)]
  WiFiDirect_IWiFiDirectDeviceStatics2 = interface(IInspectable)
  ['{1A953E49-B103-437E-9226-AB67971342F9}']
    function GetDeviceSelector(&type: WiFiDirect_WiFiDirectDeviceSelectorType): HSTRING; safecall;
    function FromIdAsync(deviceId: HSTRING; connectionParameters: WiFiDirect_IWiFiDirectConnectionParameters): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.IWiFiDirectInformationElementStatics
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_WiFiDirectInformationElement)]
  WiFiDirect_IWiFiDirectInformationElementStatics = interface(IInspectable)
  ['{DBD02F16-11A5-4E60-8CAA-34772148378A}']
    function CreateFromBuffer(buffer: IBuffer): IVector_1__WiFiDirect_IWiFiDirectInformationElement; safecall;
    function CreateFromDeviceInformation(deviceInformation: IDeviceInformation): IVector_1__WiFiDirect_IWiFiDirectInformationElement; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IIterator_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface(IInspectable)
  ['{19889F5E-49AE-5E31-B059-083F9F1532C3}']
    function get_Current: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWiFiDirect_Services_WiFiDirectServiceConfigurationMethod): Cardinal; safecall;
    property Current: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IIterable_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface(IInspectable)
  ['{D9773B1A-A148-58BF-9C4B-AFEAC9BE3AB4}']
    function First: IIterator_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface(IInspectable)
  ['{DC710FE1-7F04-515B-8AC1-1C5D3C0D2B28}']
    function GetAt(index: Cardinal): WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_Services_WiFiDirectServiceConfigurationMethod): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionDeferredEventArgs
  WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = interface(IInspectable)
  ['{8DFC197F-1201-4F1F-B6F4-5DF1B7B9FB2E}']
    function get_DeferredSessionInfo: IBuffer; safecall;
    property DeferredSessionInfo: IBuffer read get_DeferredSessionInfo;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectService,Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSessionDeferredEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectService,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionDeferredEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectService__WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs = interface(IUnknown)
  ['{FC3DFC2C-9CFA-5822-BA3F-FF3AFB65777E}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectService; args: WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo
  WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface(IInspectable)
  ['{8BDB7CFE-97D9-45A2-8E99-DB50910FB6A6}']
    function get_SelectedConfigurationMethod: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_IsGroupFormationNeeded: Boolean; safecall;
    property IsGroupFormationNeeded: Boolean read get_IsGroupFormationNeeded;
    property SelectedConfigurationMethod: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod read get_SelectedConfigurationMethod;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceProvisioningInfo>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface(IUnknown)
  ['{94CB9568-040A-5186-A3C9-52680EE17984}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceProvisioningInfo>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceProvisioningInfo>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo = interface(IInspectable)
  ['{D7FA4DC4-4730-506E-BFF0-801EB4A831A8}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo; safecall;
    function GetResults: WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSession,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession,Object>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__IInspectable = interface(IUnknown)
  ['{10C33301-E31C-5CCE-B2A0-C1DC2D8D0E13}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectServiceSession; args: IInspectable); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceRemotePortAddedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = interface(IInspectable)
  ['{D4CEBAC1-3FD3-4F0E-B7BD-782906F44411}']
    function get_EndpointPairs: IVectorView_1__IEndpointPair; safecall;
    function get_Protocol: WiFiDirect_Services_WiFiDirectServiceIPProtocol; safecall;
    property EndpointPairs: IVectorView_1__IEndpointPair read get_EndpointPairs;
    property Protocol: WiFiDirect_Services_WiFiDirectServiceIPProtocol read get_Protocol;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSession,Windows.Devices.WiFiDirect.Services.WiFiDirectServiceRemotePortAddedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceRemotePortAddedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs = interface(IUnknown)
  ['{8326A337-3C19-57A7-80EC-CCA2EA62EF12}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectServiceSession; args: WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession
  WiFiDirect_Services_IWiFiDirectServiceSession = interface(IInspectable)
  ['{81142163-E426-47CB-8640-E1B3588BF26F}']
    function get_ServiceName: HSTRING; safecall;
    function get_Status: WiFiDirect_Services_WiFiDirectServiceSessionStatus; safecall;
    function get_ErrorStatus: WiFiDirect_Services_WiFiDirectServiceSessionErrorStatus; safecall;
    function get_SessionId: Cardinal; safecall;
    function get_AdvertisementId: Cardinal; safecall;
    function get_ServiceAddress: HSTRING; safecall;
    function get_SessionAddress: HSTRING; safecall;
    function GetConnectionEndpointPairs: IVectorView_1__IEndpointPair; safecall;
    function add_SessionStatusChanged(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__IInspectable): EventRegistrationToken; safecall;
    procedure remove_SessionStatusChanged(token: EventRegistrationToken); safecall;
    function AddStreamSocketListenerAsync(value: IStreamSocketListener): IAsyncAction; safecall;
    function AddDatagramSocketAsync(value: IDatagramSocket): IAsyncAction; safecall;
    function add_RemotePortAdded(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceSession__WiFiDirect_Services_IWiFiDirectServiceRemotePortAddedEventArgs): EventRegistrationToken; safecall;
    procedure remove_RemotePortAdded(token: EventRegistrationToken); safecall;
    property AdvertisementId: Cardinal read get_AdvertisementId;
    property ErrorStatus: WiFiDirect_Services_WiFiDirectServiceSessionErrorStatus read get_ErrorStatus;
    property ServiceAddress: HSTRING read get_ServiceAddress;
    property ServiceName: HSTRING read get_ServiceName;
    property SessionAddress: HSTRING read get_SessionAddress;
    property SessionId: Cardinal read get_SessionId;
    property Status: WiFiDirect_Services_WiFiDirectServiceSessionStatus read get_Status;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSession>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession = interface(IUnknown)
  ['{B29DE711-60B8-59DA-8F4D-FC79D8CCD422}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSession>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSession>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession = interface(IInspectable)
  ['{C2DA4E97-728B-5401-A9D9-3A0185450AF2}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession; safecall;
    function GetResults: WiFiDirect_Services_IWiFiDirectServiceSession; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectServiceSession read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectService
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_Services_WiFiDirectService)]
  WiFiDirect_Services_IWiFiDirectService = interface(IInspectable)
  ['{50AABBB8-5F71-45EC-84F1-A1E4FC7879A3}']
    function get_RemoteServiceInfo: IBuffer; safecall;
    function get_SupportedConfigurationMethods: IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_PreferGroupOwnerMode: Boolean; safecall;
    procedure put_PreferGroupOwnerMode(value: Boolean); safecall;
    function get_SessionInfo: IBuffer; safecall;
    procedure put_SessionInfo(value: IBuffer); safecall;
    function get_ServiceError: WiFiDirect_Services_WiFiDirectServiceError; safecall;
    function add_SessionDeferred(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectService__WiFiDirect_Services_IWiFiDirectServiceSessionDeferredEventArgs): EventRegistrationToken; safecall;
    procedure remove_SessionDeferred(token: EventRegistrationToken); safecall;
    function GetProvisioningInfoAsync(selectedConfigurationMethod: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo; safecall;
    function ConnectAsync: IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession; overload; safecall;
    function ConnectAsync(pin: HSTRING): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession; overload; safecall;
    property PreferGroupOwnerMode: Boolean read get_PreferGroupOwnerMode write put_PreferGroupOwnerMode;
    property RemoteServiceInfo: IBuffer read get_RemoteServiceInfo;
    property ServiceError: WiFiDirect_Services_WiFiDirectServiceError read get_ServiceError;
    property SessionInfo: IBuffer read get_SessionInfo write put_SessionInfo;
    property SupportedConfigurationMethods: IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod read get_SupportedConfigurationMethods;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceConfigurationMethod>
  IVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod = interface(IInspectable)
  ['{F6A6F91C-0579-565D-BE07-4538A55690BE}']
    function GetAt(index: Cardinal): WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function IndexOf(value: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod); safecall;
    procedure InsertAt(index: Cardinal; value: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: WiFiDirect_Services_WiFiDirectServiceConfigurationMethod); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWiFiDirect_Services_WiFiDirectServiceConfigurationMethod): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PWiFiDirect_Services_WiFiDirectServiceConfigurationMethod); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequest
  WiFiDirect_Services_IWiFiDirectServiceSessionRequest = interface(IInspectable)
  ['{A0E27C8B-50CB-4A58-9BCF-E472B99FBA04}']
    function get_DeviceInformation: IDeviceInformation; safecall;
    function get_ProvisioningInfo: WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo; safecall;
    function get_SessionInfo: IBuffer; safecall;
    property DeviceInformation: IDeviceInformation read get_DeviceInformation;
    property ProvisioningInfo: WiFiDirect_Services_IWiFiDirectServiceProvisioningInfo read get_ProvisioningInfo;
    property SessionInfo: IBuffer read get_SessionInfo;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequestedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = interface(IInspectable)
  ['{74BDCC11-53D6-4999-B4F8-6C8ECC1771E7}']
    function GetSessionRequest: WiFiDirect_Services_IWiFiDirectServiceSessionRequest; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.WiFiDirectServiceSessionRequestedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceSessionRequestedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs = interface(IUnknown)
  ['{CB98FD74-871D-5730-91FE-81EF947FE78F}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectServiceAdvertiser; args: WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs
  WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = interface(IInspectable)
  ['{DCD9E01E-83DF-43E5-8F43-CBE8479E84EB}']
    function get_Session: WiFiDirect_Services_IWiFiDirectServiceSession; safecall;
    function get_SessionInfo: IBuffer; safecall;
    property Session: WiFiDirect_Services_IWiFiDirectServiceSession read get_Session;
    property SessionInfo: IBuffer read get_SessionInfo;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAutoAcceptSessionConnectedEventArgs>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs = interface(IUnknown)
  ['{3BE2D508-A856-5C09-9998-522597B44B07}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectServiceAdvertiser; args: WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAdvertiser,Object>
  // Windows.Foundation.TypedEventHandler`2<Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser,Object>
  TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__IInspectable = interface(IUnknown)
  ['{67FC3121-C1A0-5C23-AF58-ECB7F2A7D773}']
    procedure Invoke(sender: WiFiDirect_Services_IWiFiDirectServiceAdvertiser; args: IInspectable); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_Services_WiFiDirectServiceAdvertiser)]
  WiFiDirect_Services_IWiFiDirectServiceAdvertiser = interface(IInspectable)
  ['{A4AA1EE1-9D8F-4F4F-93EE-7DDEA2E37F46}']
    function get_ServiceName: HSTRING; safecall;
    function get_ServiceNamePrefixes: IVector_1__HSTRING; safecall;
    function get_ServiceInfo: IBuffer; safecall;
    procedure put_ServiceInfo(value: IBuffer); safecall;
    function get_AutoAcceptSession: Boolean; safecall;
    procedure put_AutoAcceptSession(value: Boolean); safecall;
    function get_PreferGroupOwnerMode: Boolean; safecall;
    procedure put_PreferGroupOwnerMode(value: Boolean); safecall;
    function get_PreferredConfigurationMethods: IVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod; safecall;
    function get_ServiceStatus: WiFiDirect_Services_WiFiDirectServiceStatus; safecall;
    procedure put_ServiceStatus(value: WiFiDirect_Services_WiFiDirectServiceStatus); safecall;
    function get_CustomServiceStatusCode: Cardinal; safecall;
    procedure put_CustomServiceStatusCode(value: Cardinal); safecall;
    function get_DeferredSessionInfo: IBuffer; safecall;
    procedure put_DeferredSessionInfo(value: IBuffer); safecall;
    function get_AdvertisementStatus: WiFiDirect_Services_WiFiDirectServiceAdvertisementStatus; safecall;
    function get_ServiceError: WiFiDirect_Services_WiFiDirectServiceError; safecall;
    function add_SessionRequested(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceSessionRequestedEventArgs): EventRegistrationToken; safecall;
    procedure remove_SessionRequested(token: EventRegistrationToken); safecall;
    function add_AutoAcceptSessionConnected(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__WiFiDirect_Services_IWiFiDirectServiceAutoAcceptSessionConnectedEventArgs): EventRegistrationToken; safecall;
    procedure remove_AutoAcceptSessionConnected(token: EventRegistrationToken); safecall;
    function add_AdvertisementStatusChanged(handler: TypedEventHandler_2__WiFiDirect_Services_IWiFiDirectServiceAdvertiser__IInspectable): EventRegistrationToken; safecall;
    procedure remove_AdvertisementStatusChanged(token: EventRegistrationToken); safecall;
    function ConnectAsync(deviceInfo: IDeviceInformation): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession; overload; safecall;
    function ConnectAsync(deviceInfo: IDeviceInformation; pin: HSTRING): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectServiceSession; overload; safecall;
    procedure Start; safecall;
    procedure Stop; safecall;
    property AdvertisementStatus: WiFiDirect_Services_WiFiDirectServiceAdvertisementStatus read get_AdvertisementStatus;
    property AutoAcceptSession: Boolean read get_AutoAcceptSession write put_AutoAcceptSession;
    property CustomServiceStatusCode: Cardinal read get_CustomServiceStatusCode write put_CustomServiceStatusCode;
    property DeferredSessionInfo: IBuffer read get_DeferredSessionInfo write put_DeferredSessionInfo;
    property PreferGroupOwnerMode: Boolean read get_PreferGroupOwnerMode write put_PreferGroupOwnerMode;
    property PreferredConfigurationMethods: IVector_1__WiFiDirect_Services_WiFiDirectServiceConfigurationMethod read get_PreferredConfigurationMethods;
    property ServiceError: WiFiDirect_Services_WiFiDirectServiceError read get_ServiceError;
    property ServiceInfo: IBuffer read get_ServiceInfo write put_ServiceInfo;
    property ServiceName: HSTRING read get_ServiceName;
    property ServiceNamePrefixes: IVector_1__HSTRING read get_ServiceNamePrefixes;
    property ServiceStatus: WiFiDirect_Services_WiFiDirectServiceStatus read get_ServiceStatus write put_ServiceStatus;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiserFactory
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_Services_WiFiDirectServiceAdvertiser)]
  WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory = interface(IInspectable)
  ['{3106AC0D-B446-4F13-9F9A-8AE925FEBA2B}']
    function CreateWiFiDirectServiceAdvertiser(serviceName: HSTRING): WiFiDirect_Services_IWiFiDirectServiceAdvertiser; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.WiFiDirectService>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectService>
  AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService = interface(IUnknown)
  ['{F505A3C8-4837-5E0E-8A4D-1E2AF5477E5C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.WiFiDirectService>
  // Windows.Foundation.IAsyncOperation`1<Windows.Devices.WiFiDirect.Services.IWiFiDirectService>
  IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService = interface(IInspectable)
  ['{C4FA2AE8-4FF7-5AA0-AF97-ED85EA66F9AE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService; safecall;
    function GetResults: WiFiDirect_Services_IWiFiDirectService; safecall;
    property Completed: AsyncOperationCompletedHandler_1__WiFiDirect_Services_IWiFiDirectService read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceStatics
  [WinRTClassNameAttribute(SWindows_Devices_WiFiDirect_Services_WiFiDirectService)]
  WiFiDirect_Services_IWiFiDirectServiceStatics = interface(IInspectable)
  ['{7DB40045-FD74-4688-B725-5DCE86ACF233}']
    function GetSelector(serviceName: HSTRING): HSTRING; overload; safecall;
    function GetSelector(serviceName: HSTRING; serviceInfoFilter: IBuffer): HSTRING; overload; safecall;
    function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.SimpleHapticsController>
  // Windows.Foundation.Collections.IIterator`1<Windows.Devices.Haptics.ISimpleHapticsController>
  IIterator_1__Haptics_ISimpleHapticsController = interface(IInspectable)
  ['{3C501BA4-EDA4-5238-BDB7-D10BA350CD83}']
    function get_Current: Haptics_ISimpleHapticsController; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PHaptics_ISimpleHapticsController): Cardinal; safecall;
    property Current: Haptics_ISimpleHapticsController read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.SimpleHapticsController>
  // Windows.Foundation.Collections.IIterable`1<Windows.Devices.Haptics.ISimpleHapticsController>
  IIterable_1__Haptics_ISimpleHapticsController = interface(IInspectable)
  ['{B50DA692-4A2B-5C8A-8E14-0439C0B1DBA4}']
    function First: IIterator_1__Haptics_ISimpleHapticsController; safecall;
  end;

  // Windows.Devices.Adc.AdcController
  // DualAPI
  // Implements: Windows.Devices.Adc.IAdcController
  // Statics: "Windows.Devices.Adc.IAdcControllerStatics"
  // Statics: "Windows.Devices.Adc.IAdcControllerStatics2"
  TAdc_AdcController = class(TWinRTGenericImportS2<Adc_IAdcControllerStatics, Adc_IAdcControllerStatics2>)
  public
    {$REGION 'Adc_IAdcControllerStatics'}
    class function GetControllersAsync(provider: Adc_Provider_IAdcProvider): IAsyncOperation_1__IVectorView_1__Adc_IAdcController; static; inline;
    {$ENDREGION}
    {$REGION 'Adc_IAdcControllerStatics2'}
    class function GetDefaultAsync: IAsyncOperation_1__Adc_IAdcController; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Custom.CustomDevice
  // DualAPI
  // Implements: Windows.Devices.Custom.ICustomDevice
  // Statics: "Windows.Devices.Custom.ICustomDeviceStatics"
  TCustom_CustomDevice = class(TWinRTGenericImportS<Custom_ICustomDeviceStatics>)
  public
    {$REGION 'Custom_ICustomDeviceStatics'}
    class function GetDeviceSelector(classGuid: TGuid): HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING; desiredAccess: Custom_DeviceAccessMode; sharingMode: Custom_DeviceSharingMode): IAsyncOperation_1__Custom_ICustomDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Custom.IOControlCode
  // DualAPI
  // Implements: Windows.Devices.Custom.IIOControlCode
  // Factory: "Windows.Devices.Custom.IIOControlCodeFactory"
  TCustom_IOControlCode = class(TWinRTGenericImportF<Custom_IIOControlCodeFactory>)
  public
    {$REGION 'Custom_IIOControlCodeFactory'}
    class function CreateIOControlCode(deviceType: Word; &function: Word; accessMode: Custom_IOControlAccessMode; bufferingMethod: Custom_IOControlBufferingMethod): Custom_IIOControlCode; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Custom.KnownDeviceTypes
  // DualAPI
  // Statics: "Windows.Devices.Custom.IKnownDeviceTypesStatics"
  TCustom_KnownDeviceTypes = class(TWinRTGenericImportS<Custom_IKnownDeviceTypesStatics>)
  public
    {$REGION 'Custom_IKnownDeviceTypesStatics'}
    class function get_Unknown: Word; static; inline;
    class property Unknown: Word read get_Unknown;
    {$ENDREGION}
 end;

  // Windows.Devices.Display.DisplayMonitor
  // DualAPI
  // Implements: Windows.Devices.Display.IDisplayMonitor
  // Implements: Windows.Devices.Display.IDisplayMonitor2
  // Statics: "Windows.Devices.Display.IDisplayMonitorStatics"
  TDisplay_DisplayMonitor = class(TWinRTGenericImportS<Display_IDisplayMonitorStatics>)
  public
    {$REGION 'Display_IDisplayMonitorStatics'}
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor; static; inline;
    class function FromInterfaceIdAsync(deviceInterfaceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Gpio.GpioChangeCounter
  // DualAPI
  // Implements: Windows.Devices.Gpio.IGpioChangeCounter
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Devices.Gpio.IGpioChangeCounterFactory"
  TGpio_GpioChangeCounter = class(TWinRTGenericImportF<Gpio_IGpioChangeCounterFactory>)
  public
    {$REGION 'Gpio_IGpioChangeCounterFactory'}
    class function Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeCounter; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Gpio.GpioChangeReader
  // DualAPI
  // Implements: Windows.Devices.Gpio.IGpioChangeReader
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Devices.Gpio.IGpioChangeReaderFactory"
  TGpio_GpioChangeReader = class(TWinRTGenericImportF<Gpio_IGpioChangeReaderFactory>)
  public
    {$REGION 'Gpio_IGpioChangeReaderFactory'}
    class function Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeReader; static; inline;
    class function CreateWithCapacity(pin: Gpio_IGpioPin; minCapacity: Integer): Gpio_IGpioChangeReader; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Gpio.GpioController
  // DualAPI
  // Implements: Windows.Devices.Gpio.IGpioController
  // Statics: "Windows.Devices.Gpio.IGpioControllerStatics"
  // Statics: "Windows.Devices.Gpio.IGpioControllerStatics2"
  TGpio_GpioController = class(TWinRTGenericImportS2<Gpio_IGpioControllerStatics, Gpio_IGpioControllerStatics2>)
  public
    {$REGION 'Gpio_IGpioControllerStatics'}
    class function GetDefault: Gpio_IGpioController; static; inline;
    {$ENDREGION}
    {$REGION 'Gpio_IGpioControllerStatics2'}
    class function GetControllersAsync(provider: Gpio_Provider_IGpioProvider): IAsyncOperation_1__IVectorView_1__Gpio_IGpioController; static; inline;
    class function GetDefaultAsync: IAsyncOperation_1__Gpio_IGpioController; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Gpio.Provider.GpioPinProviderValueChangedEventArgs
  // DualAPI
  // Implements: Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgs
  // Factory: "Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgsFactory"
  TGpio_Provider_GpioPinProviderValueChangedEventArgs = class(TWinRTGenericImportF<Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory>)
  public
    {$REGION 'Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory'}
    class function Create(edge: Gpio_Provider_ProviderGpioPinEdge): Gpio_Provider_IGpioPinProviderValueChangedEventArgs; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Haptics.KnownSimpleHapticsControllerWaveforms
  // DualAPI
  // Statics: "Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics"
  // Statics: "Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics2"
  THaptics_KnownSimpleHapticsControllerWaveforms = class(TWinRTGenericImportS2<Haptics_IKnownSimpleHapticsControllerWaveformsStatics, Haptics_IKnownSimpleHapticsControllerWaveformsStatics2>)
  public
    {$REGION 'Haptics_IKnownSimpleHapticsControllerWaveformsStatics'}
    class function get_Click: Word; static; inline;
    class function get_BuzzContinuous: Word; static; inline;
    class function get_RumbleContinuous: Word; static; inline;
    class function get_Press: Word; static; inline;
    class function get_Release: Word; static; inline;
    class property BuzzContinuous: Word read get_BuzzContinuous;
    class property Click: Word read get_Click;
    class property Press: Word read get_Press;
    class property Release: Word read get_Release;
    class property RumbleContinuous: Word read get_RumbleContinuous;
    {$ENDREGION}
    {$REGION 'Haptics_IKnownSimpleHapticsControllerWaveformsStatics2'}
    class function get_BrushContinuous: Word; static; inline;
    class function get_ChiselMarkerContinuous: Word; static; inline;
    class function get_EraserContinuous: Word; static; inline;
    class function get_Error: Word; static; inline;
    class function get_GalaxyPenContinuous: Word; static; inline;
    class function get_Hover: Word; static; inline;
    class function get_InkContinuous: Word; static; inline;
    class function get_MarkerContinuous: Word; static; inline;
    class function get_PencilContinuous: Word; static; inline;
    class function get_Success: Word; static; inline;
    class property BrushContinuous: Word read get_BrushContinuous;
    class property ChiselMarkerContinuous: Word read get_ChiselMarkerContinuous;
    class property EraserContinuous: Word read get_EraserContinuous;
    class property Error: Word read get_Error;
    class property GalaxyPenContinuous: Word read get_GalaxyPenContinuous;
    class property Hover: Word read get_Hover;
    class property InkContinuous: Word read get_InkContinuous;
    class property MarkerContinuous: Word read get_MarkerContinuous;
    class property PencilContinuous: Word read get_PencilContinuous;
    class property Success: Word read get_Success;
    {$ENDREGION}
 end;

  // Windows.Devices.Haptics.VibrationDevice
  // DualAPI
  // Implements: Windows.Devices.Haptics.IVibrationDevice
  // Statics: "Windows.Devices.Haptics.IVibrationDeviceStatics"
  THaptics_VibrationDevice = class(TWinRTGenericImportS<Haptics_IVibrationDeviceStatics>)
  public
    {$REGION 'Haptics_IVibrationDeviceStatics'}
    class function RequestAccessAsync: IAsyncOperation_1__Haptics_VibrationAccessStatus; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Haptics_IVibrationDevice; static; inline;
    class function GetDefaultAsync: IAsyncOperation_1__Haptics_IVibrationDevice; static; inline;
    class function FindAllAsync: IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.HumanInterfaceDevice.HidDevice
  // DualAPI
  // Implements: Windows.Devices.HumanInterfaceDevice.IHidDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.HumanInterfaceDevice.IHidDeviceStatics"
  THumanInterfaceDevice_HidDevice = class(TWinRTGenericImportS<HumanInterfaceDevice_IHidDeviceStatics>)
  public
    {$REGION 'HumanInterfaceDevice_IHidDeviceStatics'}
    class function GetDeviceSelector(usagePage: Word; usageId: Word): HSTRING; overload; static; inline;
    class function GetDeviceSelector(usagePage: Word; usageId: Word; vendorId: Word; productId: Word): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING; accessMode: FileAccessMode): IAsyncOperation_1__HumanInterfaceDevice_IHidDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.I2c.I2cConnectionSettings
  // DualAPI
  // Implements: Windows.Devices.I2c.II2cConnectionSettings
  // Factory: "Windows.Devices.I2c.II2cConnectionSettingsFactory"
  TI2c_I2cConnectionSettings = class(TWinRTGenericImportF<I2c_II2cConnectionSettingsFactory>)
  public
    {$REGION 'I2c_II2cConnectionSettingsFactory'}
    class function Create(slaveAddress: Integer): I2c_II2cConnectionSettings; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.I2c.I2cController
  // DualAPI
  // Implements: Windows.Devices.I2c.II2cController
  // Statics: "Windows.Devices.I2c.II2cControllerStatics"
  TI2c_I2cController = class(TWinRTGenericImportS<I2c_II2cControllerStatics>)
  public
    {$REGION 'I2c_II2cControllerStatics'}
    class function GetControllersAsync(provider: I2c_Provider_II2cProvider): IAsyncOperation_1__IVectorView_1__I2c_II2cController; static; inline;
    class function GetDefaultAsync: IAsyncOperation_1__I2c_II2cController; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.I2c.I2cDevice
  // DualAPI
  // Implements: Windows.Devices.I2c.II2cDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.I2c.II2cDeviceStatics"
  TI2c_I2cDevice = class(TWinRTGenericImportS<I2c_II2cDeviceStatics>)
  public
    {$REGION 'I2c_II2cDeviceStatics'}
    class function GetDeviceSelector: HSTRING; overload; static; inline;
    class function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING; settings: I2c_II2cConnectionSettings): IAsyncOperation_1__I2c_II2cDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Input.PenButtonListener
  // DualAPI
  // Implements: Windows.Devices.Input.IPenButtonListener
  // Statics: "Windows.Devices.Input.IPenButtonListenerStatics"
  TInput_PenButtonListener = class(TWinRTGenericImportS<Input_IPenButtonListenerStatics>)
  public
    {$REGION 'Input_IPenButtonListenerStatics'}
    class function GetDefault: Input_IPenButtonListener; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Input.PenDevice
  // DualAPI
  // Implements: Windows.Devices.Input.IPenDevice
  // Implements: Windows.Devices.Input.IPenDevice2
  // Statics: "Windows.Devices.Input.IPenDeviceStatics"
  TInput_PenDevice = class(TWinRTGenericImportS<Input_IPenDeviceStatics>)
  public
    {$REGION 'Input_IPenDeviceStatics'}
    class function GetFromPointerId(pointerId: Cardinal): Input_IPenDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Input.PenDockListener
  // DualAPI
  // Implements: Windows.Devices.Input.IPenDockListener
  // Statics: "Windows.Devices.Input.IPenDockListenerStatics"
  TInput_PenDockListener = class(TWinRTGenericImportS<Input_IPenDockListenerStatics>)
  public
    {$REGION 'Input_IPenDockListenerStatics'}
    class function GetDefault: Input_IPenDockListener; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.LowLevelDevicesAggregateProvider
  // DualAPI
  // Implements: Windows.Devices.ILowLevelDevicesAggregateProvider
  // Factory: "Windows.Devices.ILowLevelDevicesAggregateProviderFactory"
  TLowLevelDevicesAggregateProvider = class(TWinRTGenericImportF<ILowLevelDevicesAggregateProviderFactory>)
  public
    {$REGION 'ILowLevelDevicesAggregateProviderFactory'}
    class function Create(adc: Adc_Provider_IAdcControllerProvider; pwm: Pwm_Provider_IPwmControllerProvider; gpio: Gpio_Provider_IGpioControllerProvider; i2c: I2c_Provider_II2cControllerProvider; spi: Spi_Provider_ISpiControllerProvider): ILowLevelDevicesAggregateProvider; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.LowLevelDevicesController
  // DualAPI
  // Implements: Windows.Devices.ILowLevelDevicesController
  // Statics: "Windows.Devices.ILowLevelDevicesControllerStatics"
  TLowLevelDevicesController = class(TWinRTGenericImportS<ILowLevelDevicesControllerStatics>)
  public
    {$REGION 'ILowLevelDevicesControllerStatics'}
    class function get_DefaultProvider: ILowLevelDevicesAggregateProvider; static; inline;
    class procedure put_DefaultProvider(value: ILowLevelDevicesAggregateProvider); static; inline;
    class property DefaultProvider: ILowLevelDevicesAggregateProvider read get_DefaultProvider write put_DefaultProvider;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownCameraIntrinsicsProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownCameraIntrinsicsPropertiesStatics"
  TPerception_KnownCameraIntrinsicsProperties = class(TWinRTGenericImportS<Perception_IKnownCameraIntrinsicsPropertiesStatics>)
  public
    {$REGION 'Perception_IKnownCameraIntrinsicsPropertiesStatics'}
    class function get_FocalLength: HSTRING; static; inline;
    class function get_PrincipalPoint: HSTRING; static; inline;
    class function get_RadialDistortion: HSTRING; static; inline;
    class function get_TangentialDistortion: HSTRING; static; inline;
    class property FocalLength: HSTRING read get_FocalLength;
    class property PrincipalPoint: HSTRING read get_PrincipalPoint;
    class property RadialDistortion: HSTRING read get_RadialDistortion;
    class property TangentialDistortion: HSTRING read get_TangentialDistortion;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionColorFrameSourceProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionColorFrameSourcePropertiesStatics"
  TPerception_KnownPerceptionColorFrameSourceProperties = class(TWinRTGenericImportS<Perception_IKnownPerceptionColorFrameSourcePropertiesStatics>)
  public
    {$REGION 'Perception_IKnownPerceptionColorFrameSourcePropertiesStatics'}
    class function get_Exposure: HSTRING; static; inline;
    class function get_AutoExposureEnabled: HSTRING; static; inline;
    class function get_ExposureCompensation: HSTRING; static; inline;
    class property AutoExposureEnabled: HSTRING read get_AutoExposureEnabled;
    class property Exposure: HSTRING read get_Exposure;
    class property ExposureCompensation: HSTRING read get_ExposureCompensation;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionDepthFrameSourceProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionDepthFrameSourcePropertiesStatics"
  TPerception_KnownPerceptionDepthFrameSourceProperties = class(TWinRTGenericImportS<Perception_IKnownPerceptionDepthFrameSourcePropertiesStatics>)
  public
    {$REGION 'Perception_IKnownPerceptionDepthFrameSourcePropertiesStatics'}
    class function get_MinDepth: HSTRING; static; inline;
    class function get_MaxDepth: HSTRING; static; inline;
    class property MaxDepth: HSTRING read get_MaxDepth;
    class property MinDepth: HSTRING read get_MinDepth;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionFrameSourceProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics"
  // Statics: "Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics2"
  TPerception_KnownPerceptionFrameSourceProperties = class(TWinRTGenericImportS2<Perception_IKnownPerceptionFrameSourcePropertiesStatics, Perception_IKnownPerceptionFrameSourcePropertiesStatics2>)
  public
    {$REGION 'Perception_IKnownPerceptionFrameSourcePropertiesStatics'}
    class function get_Id: HSTRING; static; inline;
    class function get_PhysicalDeviceIds: HSTRING; static; inline;
    class function get_FrameKind: HSTRING; static; inline;
    class function get_DeviceModelVersion: HSTRING; static; inline;
    class function get_EnclosureLocation: HSTRING; static; inline;
    class property DeviceModelVersion: HSTRING read get_DeviceModelVersion;
    class property EnclosureLocation: HSTRING read get_EnclosureLocation;
    class property FrameKind: HSTRING read get_FrameKind;
    class property Id: HSTRING read get_Id;
    class property PhysicalDeviceIds: HSTRING read get_PhysicalDeviceIds;
    {$ENDREGION}
    {$REGION 'Perception_IKnownPerceptionFrameSourcePropertiesStatics2'}
    class function get_DeviceId: HSTRING; static; inline;
    class property DeviceId: HSTRING read get_DeviceId;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionInfraredFrameSourceProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionInfraredFrameSourcePropertiesStatics"
  TPerception_KnownPerceptionInfraredFrameSourceProperties = class(TWinRTGenericImportS<Perception_IKnownPerceptionInfraredFrameSourcePropertiesStatics>)
  public
    {$REGION 'Perception_IKnownPerceptionInfraredFrameSourcePropertiesStatics'}
    class function get_Exposure: HSTRING; static; inline;
    class function get_AutoExposureEnabled: HSTRING; static; inline;
    class function get_ExposureCompensation: HSTRING; static; inline;
    class function get_ActiveIlluminationEnabled: HSTRING; static; inline;
    class function get_AmbientSubtractionEnabled: HSTRING; static; inline;
    class function get_StructureLightPatternEnabled: HSTRING; static; inline;
    class function get_InterleavedIlluminationEnabled: HSTRING; static; inline;
    class property ActiveIlluminationEnabled: HSTRING read get_ActiveIlluminationEnabled;
    class property AmbientSubtractionEnabled: HSTRING read get_AmbientSubtractionEnabled;
    class property AutoExposureEnabled: HSTRING read get_AutoExposureEnabled;
    class property Exposure: HSTRING read get_Exposure;
    class property ExposureCompensation: HSTRING read get_ExposureCompensation;
    class property InterleavedIlluminationEnabled: HSTRING read get_InterleavedIlluminationEnabled;
    class property StructureLightPatternEnabled: HSTRING read get_StructureLightPatternEnabled;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionVideoFrameSourceProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionVideoFrameSourcePropertiesStatics"
  TPerception_KnownPerceptionVideoFrameSourceProperties = class(TWinRTGenericImportS<Perception_IKnownPerceptionVideoFrameSourcePropertiesStatics>)
  public
    {$REGION 'Perception_IKnownPerceptionVideoFrameSourcePropertiesStatics'}
    class function get_VideoProfile: HSTRING; static; inline;
    class function get_SupportedVideoProfiles: HSTRING; static; inline;
    class function get_AvailableVideoProfiles: HSTRING; static; inline;
    class function get_IsMirrored: HSTRING; static; inline;
    class function get_CameraIntrinsics: HSTRING; static; inline;
    class property AvailableVideoProfiles: HSTRING read get_AvailableVideoProfiles;
    class property CameraIntrinsics: HSTRING read get_CameraIntrinsics;
    class property IsMirrored: HSTRING read get_IsMirrored;
    class property SupportedVideoProfiles: HSTRING read get_SupportedVideoProfiles;
    class property VideoProfile: HSTRING read get_VideoProfile;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.KnownPerceptionVideoProfileProperties
  // DualAPI
  // Statics: "Windows.Devices.Perception.IKnownPerceptionVideoProfilePropertiesStatics"
  TPerception_KnownPerceptionVideoProfileProperties = class(TWinRTGenericImportS<Perception_IKnownPerceptionVideoProfilePropertiesStatics>)
  public
    {$REGION 'Perception_IKnownPerceptionVideoProfilePropertiesStatics'}
    class function get_BitmapPixelFormat: HSTRING; static; inline;
    class function get_BitmapAlphaMode: HSTRING; static; inline;
    class function get_Width: HSTRING; static; inline;
    class function get_Height: HSTRING; static; inline;
    class function get_FrameDuration: HSTRING; static; inline;
    class property BitmapAlphaMode: HSTRING read get_BitmapAlphaMode;
    class property BitmapPixelFormat: HSTRING read get_BitmapPixelFormat;
    class property FrameDuration: HSTRING read get_FrameDuration;
    class property Height: HSTRING read get_Height;
    class property Width: HSTRING read get_Width;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.PerceptionColorFrameSource
  // DualAPI
  // Implements: Windows.Devices.Perception.IPerceptionColorFrameSource
  // Implements: Windows.Devices.Perception.IPerceptionColorFrameSource2
  // Statics: "Windows.Devices.Perception.IPerceptionColorFrameSourceStatics"
  TPerception_PerceptionColorFrameSource = class(TWinRTGenericImportS<Perception_IPerceptionColorFrameSourceStatics>)
  public
    {$REGION 'Perception_IPerceptionColorFrameSourceStatics'}
    class function CreateWatcher: Perception_IPerceptionColorFrameSourceWatcher; static; inline;
    class function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource; static; inline;
    class function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionColorFrameSource; static; inline;
    class function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.PerceptionDepthFrameSource
  // DualAPI
  // Implements: Windows.Devices.Perception.IPerceptionDepthFrameSource
  // Implements: Windows.Devices.Perception.IPerceptionDepthFrameSource2
  // Statics: "Windows.Devices.Perception.IPerceptionDepthFrameSourceStatics"
  TPerception_PerceptionDepthFrameSource = class(TWinRTGenericImportS<Perception_IPerceptionDepthFrameSourceStatics>)
  public
    {$REGION 'Perception_IPerceptionDepthFrameSourceStatics'}
    class function CreateWatcher: Perception_IPerceptionDepthFrameSourceWatcher; static; inline;
    class function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource; static; inline;
    class function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionDepthFrameSource; static; inline;
    class function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.PerceptionInfraredFrameSource
  // DualAPI
  // Implements: Windows.Devices.Perception.IPerceptionInfraredFrameSource
  // Implements: Windows.Devices.Perception.IPerceptionInfraredFrameSource2
  // Statics: "Windows.Devices.Perception.IPerceptionInfraredFrameSourceStatics"
  TPerception_PerceptionInfraredFrameSource = class(TWinRTGenericImportS<Perception_IPerceptionInfraredFrameSourceStatics>)
  public
    {$REGION 'Perception_IPerceptionInfraredFrameSourceStatics'}
    class function CreateWatcher: Perception_IPerceptionInfraredFrameSourceWatcher; static; inline;
    class function FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource; static; inline;
    class function FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource; static; inline;
    class function RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.KnownPerceptionFrameKind
  // DualAPI
  // Statics: "Windows.Devices.Perception.Provider.IKnownPerceptionFrameKindStatics"
  TPerception_Provider_KnownPerceptionFrameKind = class(TWinRTGenericImportS<Perception_Provider_IKnownPerceptionFrameKindStatics>)
  public
    {$REGION 'Perception_Provider_IKnownPerceptionFrameKindStatics'}
    class function get_Color: HSTRING; static; inline;
    class function get_Depth: HSTRING; static; inline;
    class function get_Infrared: HSTRING; static; inline;
    class property Color: HSTRING read get_Color;
    class property Depth: HSTRING read get_Depth;
    class property Infrared: HSTRING read get_Infrared;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionControlGroup
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionControlGroup
  // Factory: "Windows.Devices.Perception.Provider.IPerceptionControlGroupFactory"
  TPerception_Provider_PerceptionControlGroup = class(TWinRTGenericImportF<Perception_Provider_IPerceptionControlGroupFactory>)
  public
    {$REGION 'Perception_Provider_IPerceptionControlGroupFactory'}
    class function Create(ids: IIterable_1__HSTRING): Perception_Provider_IPerceptionControlGroup; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionCorrelation
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionCorrelation
  // Factory: "Windows.Devices.Perception.Provider.IPerceptionCorrelationFactory"
  TPerception_Provider_PerceptionCorrelation = class(TWinRTGenericImportF<Perception_Provider_IPerceptionCorrelationFactory>)
  public
    {$REGION 'Perception_Provider_IPerceptionCorrelationFactory'}
    class function Create(targetId: HSTRING; position: Numerics_Vector3; orientation: Numerics_Quaternion): Perception_Provider_IPerceptionCorrelation; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionCorrelationGroup
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionCorrelationGroup
  // Factory: "Windows.Devices.Perception.Provider.IPerceptionCorrelationGroupFactory"
  TPerception_Provider_PerceptionCorrelationGroup = class(TWinRTGenericImportF<Perception_Provider_IPerceptionCorrelationGroupFactory>)
  public
    {$REGION 'Perception_Provider_IPerceptionCorrelationGroupFactory'}
    class function Create(relativeLocations: IIterable_1__Perception_Provider_IPerceptionCorrelation): Perception_Provider_IPerceptionCorrelationGroup; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionFaceAuthenticationGroup
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroup
  // Factory: "Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroupFactory"
  TPerception_Provider_PerceptionFaceAuthenticationGroup = class(TWinRTGenericImportF<Perception_Provider_IPerceptionFaceAuthenticationGroupFactory>)
  public
    {$REGION 'Perception_Provider_IPerceptionFaceAuthenticationGroupFactory'}
    class function Create(ids: IIterable_1__HSTRING; startHandler: Perception_Provider_PerceptionStartFaceAuthenticationHandler; stopHandler: Perception_Provider_PerceptionStopFaceAuthenticationHandler): Perception_Provider_IPerceptionFaceAuthenticationGroup; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionFrameProviderInfo
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionFrameProviderInfo
  // Instantiable: "Perception_Provider_IPerceptionFrameProviderInfo"
  TPerception_Provider_PerceptionFrameProviderInfo = class(TWinRTGenericImportI<Perception_Provider_IPerceptionFrameProviderInfo>) end;

  // Windows.Devices.Perception.Provider.PerceptionFrameProviderManagerService
  // DualAPI
  // Statics: "Windows.Devices.Perception.Provider.IPerceptionFrameProviderManagerServiceStatics"
  TPerception_Provider_PerceptionFrameProviderManagerService = class(TWinRTGenericImportS<Perception_Provider_IPerceptionFrameProviderManagerServiceStatics>)
  public
    {$REGION 'Perception_Provider_IPerceptionFrameProviderManagerServiceStatics'}
    class procedure RegisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo); static; inline;
    class procedure UnregisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo); static; inline;
    class procedure RegisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup); static; inline;
    class procedure UnregisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup); static; inline;
    class procedure RegisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup); static; inline;
    class procedure UnregisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup); static; inline;
    class procedure RegisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup); static; inline;
    class procedure UnregisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup); static; inline;
    class procedure UpdateAvailabilityForProvider(provider: Perception_Provider_IPerceptionFrameProvider; available: Boolean); static; inline;
    class procedure PublishFrameForProvider(provider: Perception_Provider_IPerceptionFrameProvider; frame: Perception_Provider_IPerceptionFrame); static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Perception.Provider.PerceptionVideoFrameAllocator
  // DualAPI
  // Implements: Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocator
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocatorFactory"
  TPerception_Provider_PerceptionVideoFrameAllocator = class(TWinRTGenericImportF<Perception_Provider_IPerceptionVideoFrameAllocatorFactory>)
  public
    {$REGION 'Perception_Provider_IPerceptionVideoFrameAllocatorFactory'}
    class function Create(maxOutstandingFrameCountForWrite: Cardinal; format: Imaging_BitmapPixelFormat; resolution: TSizeF; alpha: Imaging_BitmapAlphaMode): Perception_Provider_IPerceptionVideoFrameAllocator; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Power.Battery
  // DualAPI
  // Implements: Windows.Devices.Power.IBattery
  // Statics: "Windows.Devices.Power.IBatteryStatics"
  TPower_Battery = class(TWinRTGenericImportS<Power_IBatteryStatics>)
  public
    {$REGION 'Power_IBatteryStatics'}
    class function get_AggregateBattery: Power_IBattery; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Power_IBattery; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class property AggregateBattery: Power_IBattery read get_AggregateBattery;
    {$ENDREGION}
 end;

  // Windows.Devices.Pwm.PwmController
  // DualAPI
  // Implements: Windows.Devices.Pwm.IPwmController
  // Statics: "Windows.Devices.Pwm.IPwmControllerStatics"
  // Statics: "Windows.Devices.Pwm.IPwmControllerStatics2"
  // Statics: "Windows.Devices.Pwm.IPwmControllerStatics3"
  TPwm_PwmController = class(TWinRTGenericImportS3<Pwm_IPwmControllerStatics, Pwm_IPwmControllerStatics2, Pwm_IPwmControllerStatics3>)
  public
    {$REGION 'Pwm_IPwmControllerStatics'}
    class function GetControllersAsync(provider: Pwm_Provider_IPwmProvider): IAsyncOperation_1__IVectorView_1__Pwm_IPwmController; static; inline;
    {$ENDREGION}
    {$REGION 'Pwm_IPwmControllerStatics2'}
    class function GetDefaultAsync: IAsyncOperation_1__Pwm_IPwmController; static; inline;
    {$ENDREGION}
    {$REGION 'Pwm_IPwmControllerStatics3'}
    class function GetDeviceSelector: HSTRING; overload; static; inline;
    class function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Pwm_IPwmController; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Radios.Radio
  // DualAPI
  // Implements: Windows.Devices.Radios.IRadio
  // Statics: "Windows.Devices.Radios.IRadioStatics"
  TRadios_Radio = class(TWinRTGenericImportS<Radios_IRadioStatics>)
  public
    {$REGION 'Radios_IRadioStatics'}
    class function GetRadiosAsync: IAsyncOperation_1__IVectorView_1__Radios_IRadio; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Radios_IRadio; static; inline;
    class function RequestAccessAsync: IAsyncOperation_1__Radios_RadioAccessStatus; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.SerialCommunication.SerialDevice
  // DualAPI
  // Implements: Windows.Devices.SerialCommunication.ISerialDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.SerialCommunication.ISerialDeviceStatics"
  TSerialCommunication_SerialDevice = class(TWinRTGenericImportS<SerialCommunication_ISerialDeviceStatics>)
  public
    {$REGION 'SerialCommunication_ISerialDeviceStatics'}
    class function GetDeviceSelector: HSTRING; overload; static; inline;
    class function GetDeviceSelector(portName: HSTRING): HSTRING; overload; static; inline;
    class function GetDeviceSelectorFromUsbVidPid(vendorId: Word; productId: Word): HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__SerialCommunication_ISerialDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Spi.Provider.ProviderSpiConnectionSettings
  // DualAPI
  // Implements: Windows.Devices.Spi.Provider.IProviderSpiConnectionSettings
  // Factory: "Windows.Devices.Spi.Provider.IProviderSpiConnectionSettingsFactory"
  TSpi_Provider_ProviderSpiConnectionSettings = class(TWinRTGenericImportF<Spi_Provider_IProviderSpiConnectionSettingsFactory>)
  public
    {$REGION 'Spi_Provider_IProviderSpiConnectionSettingsFactory'}
    class function Create(chipSelectLine: Integer): Spi_Provider_IProviderSpiConnectionSettings; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Spi.SpiConnectionSettings
  // DualAPI
  // Implements: Windows.Devices.Spi.ISpiConnectionSettings
  // Factory: "Windows.Devices.Spi.ISpiConnectionSettingsFactory"
  TSpi_SpiConnectionSettings = class(TWinRTGenericImportF<Spi_ISpiConnectionSettingsFactory>)
  public
    {$REGION 'Spi_ISpiConnectionSettingsFactory'}
    class function Create(chipSelectLine: Integer): Spi_ISpiConnectionSettings; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Spi.SpiController
  // DualAPI
  // Implements: Windows.Devices.Spi.ISpiController
  // Statics: "Windows.Devices.Spi.ISpiControllerStatics"
  TSpi_SpiController = class(TWinRTGenericImportS<Spi_ISpiControllerStatics>)
  public
    {$REGION 'Spi_ISpiControllerStatics'}
    class function GetDefaultAsync: IAsyncOperation_1__Spi_ISpiController; static; inline;
    class function GetControllersAsync(provider: Spi_Provider_ISpiProvider): IAsyncOperation_1__IVectorView_1__Spi_ISpiController; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Spi.SpiDevice
  // DualAPI
  // Implements: Windows.Devices.Spi.ISpiDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.Spi.ISpiDeviceStatics"
  TSpi_SpiDevice = class(TWinRTGenericImportS<Spi_ISpiDeviceStatics>)
  public
    {$REGION 'Spi_ISpiDeviceStatics'}
    class function GetDeviceSelector: HSTRING; overload; static; inline;
    class function GetDeviceSelector(friendlyName: HSTRING): HSTRING; overload; static; inline;
    class function GetBusInfo(busId: HSTRING): Spi_ISpiBusInfo; static; inline;
    class function FromIdAsync(busId: HSTRING; settings: Spi_ISpiConnectionSettings): IAsyncOperation_1__Spi_ISpiDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbConfigurationDescriptor
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbConfigurationDescriptor
  // Statics: "Windows.Devices.Usb.IUsbConfigurationDescriptorStatics"
  TUsb_UsbConfigurationDescriptor = class(TWinRTGenericImportS<Usb_IUsbConfigurationDescriptorStatics>)
  public
    {$REGION 'Usb_IUsbConfigurationDescriptorStatics'}
    class function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbConfigurationDescriptor): Boolean; static; inline;
    class function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbConfigurationDescriptor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbControlRequestType
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbControlRequestType
  // Instantiable: "Usb_IUsbControlRequestType"
  TUsb_UsbControlRequestType = class(TWinRTGenericImportI<Usb_IUsbControlRequestType>) end;

  // Windows.Devices.Usb.UsbDevice
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.Usb.IUsbDeviceStatics"
  TUsb_UsbDevice = class(TWinRTGenericImportS<Usb_IUsbDeviceStatics>)
  public
    {$REGION 'Usb_IUsbDeviceStatics'}
    class function GetDeviceSelector(vendorId: Cardinal; productId: Cardinal; winUsbInterfaceClass: TGuid): HSTRING; overload; static; inline;
    class function GetDeviceSelector(winUsbInterfaceClass: TGuid): HSTRING; overload; static; inline;
    class function GetDeviceSelector(vendorId: Cardinal; productId: Cardinal): HSTRING; overload; static; inline;
    class function GetDeviceClassSelector(usbClass: Usb_IUsbDeviceClass): HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Usb_IUsbDevice; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbDeviceClass
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbDeviceClass
  // Instantiable: "Usb_IUsbDeviceClass"
  TUsb_UsbDeviceClass = class(TWinRTGenericImportI<Usb_IUsbDeviceClass>) end;

  // Windows.Devices.Usb.UsbDeviceClasses
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbDeviceClasses
  // Statics: "Windows.Devices.Usb.IUsbDeviceClassesStatics"
  TUsb_UsbDeviceClasses = class(TWinRTGenericImportS<Usb_IUsbDeviceClassesStatics>)
  public
    {$REGION 'Usb_IUsbDeviceClassesStatics'}
    class function get_CdcControl: Usb_IUsbDeviceClass; static; inline;
    class function get_Physical: Usb_IUsbDeviceClass; static; inline;
    class function get_PersonalHealthcare: Usb_IUsbDeviceClass; static; inline;
    class function get_ActiveSync: Usb_IUsbDeviceClass; static; inline;
    class function get_PalmSync: Usb_IUsbDeviceClass; static; inline;
    class function get_DeviceFirmwareUpdate: Usb_IUsbDeviceClass; static; inline;
    class function get_Irda: Usb_IUsbDeviceClass; static; inline;
    class function get_Measurement: Usb_IUsbDeviceClass; static; inline;
    class function get_VendorSpecific: Usb_IUsbDeviceClass; static; inline;
    class property ActiveSync: Usb_IUsbDeviceClass read get_ActiveSync;
    class property CdcControl: Usb_IUsbDeviceClass read get_CdcControl;
    class property DeviceFirmwareUpdate: Usb_IUsbDeviceClass read get_DeviceFirmwareUpdate;
    class property Irda: Usb_IUsbDeviceClass read get_Irda;
    class property Measurement: Usb_IUsbDeviceClass read get_Measurement;
    class property PalmSync: Usb_IUsbDeviceClass read get_PalmSync;
    class property PersonalHealthcare: Usb_IUsbDeviceClass read get_PersonalHealthcare;
    class property Physical: Usb_IUsbDeviceClass read get_Physical;
    class property VendorSpecific: Usb_IUsbDeviceClass read get_VendorSpecific;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbEndpointDescriptor
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbEndpointDescriptor
  // Statics: "Windows.Devices.Usb.IUsbEndpointDescriptorStatics"
  TUsb_UsbEndpointDescriptor = class(TWinRTGenericImportS<Usb_IUsbEndpointDescriptorStatics>)
  public
    {$REGION 'Usb_IUsbEndpointDescriptorStatics'}
    class function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbEndpointDescriptor): Boolean; static; inline;
    class function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbEndpointDescriptor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbInterfaceDescriptor
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbInterfaceDescriptor
  // Statics: "Windows.Devices.Usb.IUsbInterfaceDescriptorStatics"
  TUsb_UsbInterfaceDescriptor = class(TWinRTGenericImportS<Usb_IUsbInterfaceDescriptorStatics>)
  public
    {$REGION 'Usb_IUsbInterfaceDescriptorStatics'}
    class function TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbInterfaceDescriptor): Boolean; static; inline;
    class function Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbInterfaceDescriptor; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.Usb.UsbSetupPacket
  // DualAPI
  // Implements: Windows.Devices.Usb.IUsbSetupPacket
  // Factory: "Windows.Devices.Usb.IUsbSetupPacketFactory"
  // Instantiable: "Usb_IUsbSetupPacket"
  TUsb_UsbSetupPacket = class(TWinRTGenericImportFI<Usb_IUsbSetupPacketFactory, Usb_IUsbSetupPacket>)
  public
    {$REGION 'Usb_IUsbSetupPacketFactory'}
    class function CreateWithEightByteBuffer(eightByteBuffer: IBuffer): Usb_IUsbSetupPacket; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFi.WiFiAdapter
  // DualAPI
  // Implements: Windows.Devices.WiFi.IWiFiAdapter
  // Implements: Windows.Devices.WiFi.IWiFiAdapter2
  // Statics: "Windows.Devices.WiFi.IWiFiAdapterStatics"
  TWiFi_WiFiAdapter = class(TWinRTGenericImportS<WiFi_IWiFiAdapterStatics>)
  public
    {$REGION 'WiFi_IWiFiAdapterStatics'}
    class function FindAllAdaptersAsync: IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter; static; inline;
    class function GetDeviceSelector: HSTRING; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFi_IWiFiAdapter; static; inline;
    class function RequestAccessAsync: IAsyncOperation_1__WiFi_WiFiAccessStatus; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectService
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.Services.IWiFiDirectService
  // Statics: "Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceStatics"
  TWiFiDirect_Services_WiFiDirectService = class(TWinRTGenericImportS<WiFiDirect_Services_IWiFiDirectServiceStatics>)
  public
    {$REGION 'WiFiDirect_Services_IWiFiDirectServiceStatics'}
    class function GetSelector(serviceName: HSTRING): HSTRING; overload; static; inline;
    class function GetSelector(serviceName: HSTRING; serviceInfoFilter: IBuffer): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFiDirect.Services.WiFiDirectServiceAdvertiser
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiser
  // Factory: "Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiserFactory"
  TWiFiDirect_Services_WiFiDirectServiceAdvertiser = class(TWinRTGenericImportF<WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory>)
  public
    {$REGION 'WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory'}
    class function CreateWiFiDirectServiceAdvertiser(serviceName: HSTRING): WiFiDirect_Services_IWiFiDirectServiceAdvertiser; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFiDirect.WiFiDirectAdvertisementPublisher
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectAdvertisementPublisher
  // Instantiable: "WiFiDirect_IWiFiDirectAdvertisementPublisher"
  TWiFiDirect_WiFiDirectAdvertisementPublisher = class(TWinRTGenericImportI<WiFiDirect_IWiFiDirectAdvertisementPublisher>) end;

  // Windows.Devices.WiFiDirect.WiFiDirectConnectionListener
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectConnectionListener
  // Instantiable: "WiFiDirect_IWiFiDirectConnectionListener"
  TWiFiDirect_WiFiDirectConnectionListener = class(TWinRTGenericImportI<WiFiDirect_IWiFiDirectConnectionListener>) end;

  // Windows.Devices.WiFiDirect.WiFiDirectConnectionParameters
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectConnectionParameters2
  // Implements: Windows.Devices.Enumeration.IDevicePairingSettings
  // Statics: "Windows.Devices.WiFiDirect.IWiFiDirectConnectionParametersStatics"
  // Instantiable: "WiFiDirect_IWiFiDirectConnectionParameters"
  TWiFiDirect_WiFiDirectConnectionParameters = class(TWinRTGenericImportSI<WiFiDirect_IWiFiDirectConnectionParametersStatics, WiFiDirect_IWiFiDirectConnectionParameters>)
  public
    {$REGION 'WiFiDirect_IWiFiDirectConnectionParametersStatics'}
    class function GetDevicePairingKinds(configurationMethod: WiFiDirect_WiFiDirectConfigurationMethod): DevicePairingKinds; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFiDirect.WiFiDirectDevice
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectDevice
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics"
  // Statics: "Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics2"
  TWiFiDirect_WiFiDirectDevice = class(TWinRTGenericImportS2<WiFiDirect_IWiFiDirectDeviceStatics, WiFiDirect_IWiFiDirectDeviceStatics2>)
  public
    {$REGION 'WiFiDirect_IWiFiDirectDeviceStatics'}
    class function GetDeviceSelector: HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice; overload; static; inline;
    {$ENDREGION}
    {$REGION 'WiFiDirect_IWiFiDirectDeviceStatics2'}
    class function GetDeviceSelector(&type: WiFiDirect_WiFiDirectDeviceSelectorType): HSTRING; overload; static; inline;
    class function FromIdAsync(deviceId: HSTRING; connectionParameters: WiFiDirect_IWiFiDirectConnectionParameters): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice; overload; static; inline;
    {$ENDREGION}
 end;

  // Windows.Devices.WiFiDirect.WiFiDirectInformationElement
  // DualAPI
  // Implements: Windows.Devices.WiFiDirect.IWiFiDirectInformationElement
  // Statics: "Windows.Devices.WiFiDirect.IWiFiDirectInformationElementStatics"
  // Instantiable: "WiFiDirect_IWiFiDirectInformationElement"
  TWiFiDirect_WiFiDirectInformationElement = class(TWinRTGenericImportSI<WiFiDirect_IWiFiDirectInformationElementStatics, WiFiDirect_IWiFiDirectInformationElement>)
  public
    {$REGION 'WiFiDirect_IWiFiDirectInformationElementStatics'}
    class function CreateFromBuffer(buffer: IBuffer): IVector_1__WiFiDirect_IWiFiDirectInformationElement; static; inline;
    class function CreateFromDeviceInformation(deviceInformation: IDeviceInformation): IVector_1__WiFiDirect_IWiFiDirectInformationElement; static; inline;
    {$ENDREGION}
 end;

implementation

{ TAdc_AdcController }

{$REGION 'Windows.Devices.Adc.IAdcControllerStatics'}
class function TAdc_AdcController.GetControllersAsync(provider: Adc_Provider_IAdcProvider): IAsyncOperation_1__IVectorView_1__Adc_IAdcController;
begin
  Result := Statics.GetControllersAsync(provider);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Adc.IAdcControllerStatics2'}
class function TAdc_AdcController.GetDefaultAsync: IAsyncOperation_1__Adc_IAdcController;
begin
  Result := Statics2.GetDefaultAsync;
end;
{$ENDREGION}

{ TCustom_CustomDevice }

{$REGION 'Windows.Devices.Custom.ICustomDeviceStatics'}
class function TCustom_CustomDevice.GetDeviceSelector(classGuid: TGuid): HSTRING;
begin
  Result := Statics.GetDeviceSelector(classGuid);
end;

class function TCustom_CustomDevice.FromIdAsync(deviceId: HSTRING; desiredAccess: Custom_DeviceAccessMode; sharingMode: Custom_DeviceSharingMode): IAsyncOperation_1__Custom_ICustomDevice;
begin
  Result := Statics.FromIdAsync(deviceId, desiredAccess, sharingMode);
end;
{$ENDREGION}

{ TCustom_IOControlCode }

{$REGION 'Windows.Devices.Custom.IIOControlCodeFactory'}
// Factory: "Windows.Devices.Custom.IIOControlCodeFactory"
// -> Custom_IIOControlCodeFactory

class function TCustom_IOControlCode.CreateIOControlCode(deviceType: Word; &function: Word; accessMode: Custom_IOControlAccessMode; bufferingMethod: Custom_IOControlBufferingMethod): Custom_IIOControlCode;
begin
  Result := Factory.CreateIOControlCode(deviceType, &function, accessMode, bufferingMethod);
end;
{$ENDREGION}

{ TCustom_KnownDeviceTypes }

{$REGION 'Windows.Devices.Custom.IKnownDeviceTypesStatics'}
class function TCustom_KnownDeviceTypes.get_Unknown: Word;
begin
  Result := Statics.get_Unknown;
end;
{$ENDREGION}

{ TDisplay_DisplayMonitor }

{$REGION 'Windows.Devices.Display.IDisplayMonitorStatics'}
class function TDisplay_DisplayMonitor.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TDisplay_DisplayMonitor.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TDisplay_DisplayMonitor.FromInterfaceIdAsync(deviceInterfaceId: HSTRING): IAsyncOperation_1__Display_IDisplayMonitor;
begin
  Result := Statics.FromInterfaceIdAsync(deviceInterfaceId);
end;
{$ENDREGION}

{ TGpio_GpioChangeCounter }

{$REGION 'Windows.Devices.Gpio.IGpioChangeCounterFactory'}
// Factory: "Windows.Devices.Gpio.IGpioChangeCounterFactory"
// -> Gpio_IGpioChangeCounterFactory

class function TGpio_GpioChangeCounter.Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeCounter;
begin
  Result := Factory.Create(pin);
end;
{$ENDREGION}

{ TGpio_GpioChangeReader }

{$REGION 'Windows.Devices.Gpio.IGpioChangeReaderFactory'}
// Factory: "Windows.Devices.Gpio.IGpioChangeReaderFactory"
// -> Gpio_IGpioChangeReaderFactory

class function TGpio_GpioChangeReader.Create(pin: Gpio_IGpioPin): Gpio_IGpioChangeReader;
begin
  Result := Factory.Create(pin);
end;

class function TGpio_GpioChangeReader.CreateWithCapacity(pin: Gpio_IGpioPin; minCapacity: Integer): Gpio_IGpioChangeReader;
begin
  Result := Factory.CreateWithCapacity(pin, minCapacity);
end;
{$ENDREGION}

{ TGpio_GpioController }

{$REGION 'Windows.Devices.Gpio.IGpioControllerStatics'}
class function TGpio_GpioController.GetDefault: Gpio_IGpioController;
begin
  Result := Statics.GetDefault;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Gpio.IGpioControllerStatics2'}
class function TGpio_GpioController.GetControllersAsync(provider: Gpio_Provider_IGpioProvider): IAsyncOperation_1__IVectorView_1__Gpio_IGpioController;
begin
  Result := Statics2.GetControllersAsync(provider);
end;

class function TGpio_GpioController.GetDefaultAsync: IAsyncOperation_1__Gpio_IGpioController;
begin
  Result := Statics2.GetDefaultAsync;
end;
{$ENDREGION}

{ TGpio_Provider_GpioPinProviderValueChangedEventArgs }

{$REGION 'Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgsFactory'}
// Factory: "Windows.Devices.Gpio.Provider.IGpioPinProviderValueChangedEventArgsFactory"
// -> Gpio_Provider_IGpioPinProviderValueChangedEventArgsFactory

class function TGpio_Provider_GpioPinProviderValueChangedEventArgs.Create(edge: Gpio_Provider_ProviderGpioPinEdge): Gpio_Provider_IGpioPinProviderValueChangedEventArgs;
begin
  Result := Factory.Create(edge);
end;
{$ENDREGION}

{ THaptics_KnownSimpleHapticsControllerWaveforms }

{$REGION 'Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics'}
class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Click: Word;
begin
  Result := Statics.get_Click;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_BuzzContinuous: Word;
begin
  Result := Statics.get_BuzzContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_RumbleContinuous: Word;
begin
  Result := Statics.get_RumbleContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Press: Word;
begin
  Result := Statics.get_Press;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Release: Word;
begin
  Result := Statics.get_Release;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Haptics.IKnownSimpleHapticsControllerWaveformsStatics2'}
class function THaptics_KnownSimpleHapticsControllerWaveforms.get_BrushContinuous: Word;
begin
  Result := Statics2.get_BrushContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_ChiselMarkerContinuous: Word;
begin
  Result := Statics2.get_ChiselMarkerContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_EraserContinuous: Word;
begin
  Result := Statics2.get_EraserContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Error: Word;
begin
  Result := Statics2.get_Error;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_GalaxyPenContinuous: Word;
begin
  Result := Statics2.get_GalaxyPenContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Hover: Word;
begin
  Result := Statics2.get_Hover;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_InkContinuous: Word;
begin
  Result := Statics2.get_InkContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_MarkerContinuous: Word;
begin
  Result := Statics2.get_MarkerContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_PencilContinuous: Word;
begin
  Result := Statics2.get_PencilContinuous;
end;

class function THaptics_KnownSimpleHapticsControllerWaveforms.get_Success: Word;
begin
  Result := Statics2.get_Success;
end;
{$ENDREGION}

{ THaptics_VibrationDevice }

{$REGION 'Windows.Devices.Haptics.IVibrationDeviceStatics'}
class function THaptics_VibrationDevice.RequestAccessAsync: IAsyncOperation_1__Haptics_VibrationAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;

class function THaptics_VibrationDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function THaptics_VibrationDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Haptics_IVibrationDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function THaptics_VibrationDevice.GetDefaultAsync: IAsyncOperation_1__Haptics_IVibrationDevice;
begin
  Result := Statics.GetDefaultAsync;
end;

class function THaptics_VibrationDevice.FindAllAsync: IAsyncOperation_1__IVectorView_1__Haptics_IVibrationDevice;
begin
  Result := Statics.FindAllAsync;
end;
{$ENDREGION}

{ THumanInterfaceDevice_HidDevice }

{$REGION 'Windows.Devices.HumanInterfaceDevice.IHidDeviceStatics'}
class function THumanInterfaceDevice_HidDevice.GetDeviceSelector(usagePage: Word; usageId: Word): HSTRING;
begin
  Result := Statics.GetDeviceSelector(usagePage, usageId);
end;

class function THumanInterfaceDevice_HidDevice.GetDeviceSelector(usagePage: Word; usageId: Word; vendorId: Word; productId: Word): HSTRING;
begin
  Result := Statics.GetDeviceSelector(usagePage, usageId, vendorId, productId);
end;

class function THumanInterfaceDevice_HidDevice.FromIdAsync(deviceId: HSTRING; accessMode: FileAccessMode): IAsyncOperation_1__HumanInterfaceDevice_IHidDevice;
begin
  Result := Statics.FromIdAsync(deviceId, accessMode);
end;
{$ENDREGION}

{ TI2c_I2cConnectionSettings }

{$REGION 'Windows.Devices.I2c.II2cConnectionSettingsFactory'}
// Factory: "Windows.Devices.I2c.II2cConnectionSettingsFactory"
// -> I2c_II2cConnectionSettingsFactory

class function TI2c_I2cConnectionSettings.Create(slaveAddress: Integer): I2c_II2cConnectionSettings;
begin
  Result := Factory.Create(slaveAddress);
end;
{$ENDREGION}

{ TI2c_I2cController }

{$REGION 'Windows.Devices.I2c.II2cControllerStatics'}
class function TI2c_I2cController.GetControllersAsync(provider: I2c_Provider_II2cProvider): IAsyncOperation_1__IVectorView_1__I2c_II2cController;
begin
  Result := Statics.GetControllersAsync(provider);
end;

class function TI2c_I2cController.GetDefaultAsync: IAsyncOperation_1__I2c_II2cController;
begin
  Result := Statics.GetDefaultAsync;
end;
{$ENDREGION}

{ TI2c_I2cDevice }

{$REGION 'Windows.Devices.I2c.II2cDeviceStatics'}
class function TI2c_I2cDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TI2c_I2cDevice.GetDeviceSelector(friendlyName: HSTRING): HSTRING;
begin
  Result := Statics.GetDeviceSelector(friendlyName);
end;

class function TI2c_I2cDevice.FromIdAsync(deviceId: HSTRING; settings: I2c_II2cConnectionSettings): IAsyncOperation_1__I2c_II2cDevice;
begin
  Result := Statics.FromIdAsync(deviceId, settings);
end;
{$ENDREGION}

{ TInput_PenButtonListener }

{$REGION 'Windows.Devices.Input.IPenButtonListenerStatics'}
class function TInput_PenButtonListener.GetDefault: Input_IPenButtonListener;
begin
  Result := Statics.GetDefault;
end;
{$ENDREGION}

{ TInput_PenDevice }

{$REGION 'Windows.Devices.Input.IPenDeviceStatics'}
class function TInput_PenDevice.GetFromPointerId(pointerId: Cardinal): Input_IPenDevice;
begin
  Result := Statics.GetFromPointerId(pointerId);
end;
{$ENDREGION}

{ TInput_PenDockListener }

{$REGION 'Windows.Devices.Input.IPenDockListenerStatics'}
class function TInput_PenDockListener.GetDefault: Input_IPenDockListener;
begin
  Result := Statics.GetDefault;
end;
{$ENDREGION}

{ TLowLevelDevicesAggregateProvider }

{$REGION 'Windows.Devices.ILowLevelDevicesAggregateProviderFactory'}
// Factory: "Windows.Devices.ILowLevelDevicesAggregateProviderFactory"
// -> ILowLevelDevicesAggregateProviderFactory

class function TLowLevelDevicesAggregateProvider.Create(adc: Adc_Provider_IAdcControllerProvider; pwm: Pwm_Provider_IPwmControllerProvider; gpio: Gpio_Provider_IGpioControllerProvider; i2c: I2c_Provider_II2cControllerProvider; spi: Spi_Provider_ISpiControllerProvider): ILowLevelDevicesAggregateProvider;
begin
  Result := Factory.Create(adc, pwm, gpio, i2c, spi);
end;
{$ENDREGION}

{ TLowLevelDevicesController }

{$REGION 'Windows.Devices.ILowLevelDevicesControllerStatics'}
class function TLowLevelDevicesController.get_DefaultProvider: ILowLevelDevicesAggregateProvider;
begin
  Result := Statics.get_DefaultProvider;
end;

class procedure TLowLevelDevicesController.put_DefaultProvider(value: ILowLevelDevicesAggregateProvider);
begin
  Statics.put_DefaultProvider(value);
end;
{$ENDREGION}

{ TPerception_KnownCameraIntrinsicsProperties }

{$REGION 'Windows.Devices.Perception.IKnownCameraIntrinsicsPropertiesStatics'}
class function TPerception_KnownCameraIntrinsicsProperties.get_FocalLength: HSTRING;
begin
  Result := Statics.get_FocalLength;
end;

class function TPerception_KnownCameraIntrinsicsProperties.get_PrincipalPoint: HSTRING;
begin
  Result := Statics.get_PrincipalPoint;
end;

class function TPerception_KnownCameraIntrinsicsProperties.get_RadialDistortion: HSTRING;
begin
  Result := Statics.get_RadialDistortion;
end;

class function TPerception_KnownCameraIntrinsicsProperties.get_TangentialDistortion: HSTRING;
begin
  Result := Statics.get_TangentialDistortion;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionColorFrameSourceProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionColorFrameSourcePropertiesStatics'}
class function TPerception_KnownPerceptionColorFrameSourceProperties.get_Exposure: HSTRING;
begin
  Result := Statics.get_Exposure;
end;

class function TPerception_KnownPerceptionColorFrameSourceProperties.get_AutoExposureEnabled: HSTRING;
begin
  Result := Statics.get_AutoExposureEnabled;
end;

class function TPerception_KnownPerceptionColorFrameSourceProperties.get_ExposureCompensation: HSTRING;
begin
  Result := Statics.get_ExposureCompensation;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionDepthFrameSourceProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionDepthFrameSourcePropertiesStatics'}
class function TPerception_KnownPerceptionDepthFrameSourceProperties.get_MinDepth: HSTRING;
begin
  Result := Statics.get_MinDepth;
end;

class function TPerception_KnownPerceptionDepthFrameSourceProperties.get_MaxDepth: HSTRING;
begin
  Result := Statics.get_MaxDepth;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionFrameSourceProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics'}
class function TPerception_KnownPerceptionFrameSourceProperties.get_Id: HSTRING;
begin
  Result := Statics.get_Id;
end;

class function TPerception_KnownPerceptionFrameSourceProperties.get_PhysicalDeviceIds: HSTRING;
begin
  Result := Statics.get_PhysicalDeviceIds;
end;

class function TPerception_KnownPerceptionFrameSourceProperties.get_FrameKind: HSTRING;
begin
  Result := Statics.get_FrameKind;
end;

class function TPerception_KnownPerceptionFrameSourceProperties.get_DeviceModelVersion: HSTRING;
begin
  Result := Statics.get_DeviceModelVersion;
end;

class function TPerception_KnownPerceptionFrameSourceProperties.get_EnclosureLocation: HSTRING;
begin
  Result := Statics.get_EnclosureLocation;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Perception.IKnownPerceptionFrameSourcePropertiesStatics2'}
class function TPerception_KnownPerceptionFrameSourceProperties.get_DeviceId: HSTRING;
begin
  Result := Statics2.get_DeviceId;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionInfraredFrameSourceProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionInfraredFrameSourcePropertiesStatics'}
class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_Exposure: HSTRING;
begin
  Result := Statics.get_Exposure;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_AutoExposureEnabled: HSTRING;
begin
  Result := Statics.get_AutoExposureEnabled;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_ExposureCompensation: HSTRING;
begin
  Result := Statics.get_ExposureCompensation;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_ActiveIlluminationEnabled: HSTRING;
begin
  Result := Statics.get_ActiveIlluminationEnabled;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_AmbientSubtractionEnabled: HSTRING;
begin
  Result := Statics.get_AmbientSubtractionEnabled;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_StructureLightPatternEnabled: HSTRING;
begin
  Result := Statics.get_StructureLightPatternEnabled;
end;

class function TPerception_KnownPerceptionInfraredFrameSourceProperties.get_InterleavedIlluminationEnabled: HSTRING;
begin
  Result := Statics.get_InterleavedIlluminationEnabled;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionVideoFrameSourceProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionVideoFrameSourcePropertiesStatics'}
class function TPerception_KnownPerceptionVideoFrameSourceProperties.get_VideoProfile: HSTRING;
begin
  Result := Statics.get_VideoProfile;
end;

class function TPerception_KnownPerceptionVideoFrameSourceProperties.get_SupportedVideoProfiles: HSTRING;
begin
  Result := Statics.get_SupportedVideoProfiles;
end;

class function TPerception_KnownPerceptionVideoFrameSourceProperties.get_AvailableVideoProfiles: HSTRING;
begin
  Result := Statics.get_AvailableVideoProfiles;
end;

class function TPerception_KnownPerceptionVideoFrameSourceProperties.get_IsMirrored: HSTRING;
begin
  Result := Statics.get_IsMirrored;
end;

class function TPerception_KnownPerceptionVideoFrameSourceProperties.get_CameraIntrinsics: HSTRING;
begin
  Result := Statics.get_CameraIntrinsics;
end;
{$ENDREGION}

{ TPerception_KnownPerceptionVideoProfileProperties }

{$REGION 'Windows.Devices.Perception.IKnownPerceptionVideoProfilePropertiesStatics'}
class function TPerception_KnownPerceptionVideoProfileProperties.get_BitmapPixelFormat: HSTRING;
begin
  Result := Statics.get_BitmapPixelFormat;
end;

class function TPerception_KnownPerceptionVideoProfileProperties.get_BitmapAlphaMode: HSTRING;
begin
  Result := Statics.get_BitmapAlphaMode;
end;

class function TPerception_KnownPerceptionVideoProfileProperties.get_Width: HSTRING;
begin
  Result := Statics.get_Width;
end;

class function TPerception_KnownPerceptionVideoProfileProperties.get_Height: HSTRING;
begin
  Result := Statics.get_Height;
end;

class function TPerception_KnownPerceptionVideoProfileProperties.get_FrameDuration: HSTRING;
begin
  Result := Statics.get_FrameDuration;
end;
{$ENDREGION}

{ TPerception_PerceptionColorFrameSource }

{$REGION 'Windows.Devices.Perception.IPerceptionColorFrameSourceStatics'}
class function TPerception_PerceptionColorFrameSource.CreateWatcher: Perception_IPerceptionColorFrameSourceWatcher;
begin
  Result := Statics.CreateWatcher;
end;

class function TPerception_PerceptionColorFrameSource.FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionColorFrameSource;
begin
  Result := Statics.FindAllAsync;
end;

class function TPerception_PerceptionColorFrameSource.FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionColorFrameSource;
begin
  Result := Statics.FromIdAsync(id);
end;

class function TPerception_PerceptionColorFrameSource.RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;
{$ENDREGION}

{ TPerception_PerceptionDepthFrameSource }

{$REGION 'Windows.Devices.Perception.IPerceptionDepthFrameSourceStatics'}
class function TPerception_PerceptionDepthFrameSource.CreateWatcher: Perception_IPerceptionDepthFrameSourceWatcher;
begin
  Result := Statics.CreateWatcher;
end;

class function TPerception_PerceptionDepthFrameSource.FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionDepthFrameSource;
begin
  Result := Statics.FindAllAsync;
end;

class function TPerception_PerceptionDepthFrameSource.FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionDepthFrameSource;
begin
  Result := Statics.FromIdAsync(id);
end;

class function TPerception_PerceptionDepthFrameSource.RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;
{$ENDREGION}

{ TPerception_PerceptionInfraredFrameSource }

{$REGION 'Windows.Devices.Perception.IPerceptionInfraredFrameSourceStatics'}
class function TPerception_PerceptionInfraredFrameSource.CreateWatcher: Perception_IPerceptionInfraredFrameSourceWatcher;
begin
  Result := Statics.CreateWatcher;
end;

class function TPerception_PerceptionInfraredFrameSource.FindAllAsync: IAsyncOperation_1__IVectorView_1__Perception_IPerceptionInfraredFrameSource;
begin
  Result := Statics.FindAllAsync;
end;

class function TPerception_PerceptionInfraredFrameSource.FromIdAsync(id: HSTRING): IAsyncOperation_1__Perception_IPerceptionInfraredFrameSource;
begin
  Result := Statics.FromIdAsync(id);
end;

class function TPerception_PerceptionInfraredFrameSource.RequestAccessAsync: IAsyncOperation_1__Perception_PerceptionFrameSourceAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;
{$ENDREGION}

{ TPerception_Provider_KnownPerceptionFrameKind }

{$REGION 'Windows.Devices.Perception.Provider.IKnownPerceptionFrameKindStatics'}
class function TPerception_Provider_KnownPerceptionFrameKind.get_Color: HSTRING;
begin
  Result := Statics.get_Color;
end;

class function TPerception_Provider_KnownPerceptionFrameKind.get_Depth: HSTRING;
begin
  Result := Statics.get_Depth;
end;

class function TPerception_Provider_KnownPerceptionFrameKind.get_Infrared: HSTRING;
begin
  Result := Statics.get_Infrared;
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionControlGroup }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionControlGroupFactory'}
// Factory: "Windows.Devices.Perception.Provider.IPerceptionControlGroupFactory"
// -> Perception_Provider_IPerceptionControlGroupFactory

class function TPerception_Provider_PerceptionControlGroup.Create(ids: IIterable_1__HSTRING): Perception_Provider_IPerceptionControlGroup;
begin
  Result := Factory.Create(ids);
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionCorrelation }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionCorrelationFactory'}
// Factory: "Windows.Devices.Perception.Provider.IPerceptionCorrelationFactory"
// -> Perception_Provider_IPerceptionCorrelationFactory

class function TPerception_Provider_PerceptionCorrelation.Create(targetId: HSTRING; position: Numerics_Vector3; orientation: Numerics_Quaternion): Perception_Provider_IPerceptionCorrelation;
begin
  Result := Factory.Create(targetId, position, orientation);
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionCorrelationGroup }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionCorrelationGroupFactory'}
// Factory: "Windows.Devices.Perception.Provider.IPerceptionCorrelationGroupFactory"
// -> Perception_Provider_IPerceptionCorrelationGroupFactory

class function TPerception_Provider_PerceptionCorrelationGroup.Create(relativeLocations: IIterable_1__Perception_Provider_IPerceptionCorrelation): Perception_Provider_IPerceptionCorrelationGroup;
begin
  Result := Factory.Create(relativeLocations);
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionFaceAuthenticationGroup }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroupFactory'}
// Factory: "Windows.Devices.Perception.Provider.IPerceptionFaceAuthenticationGroupFactory"
// -> Perception_Provider_IPerceptionFaceAuthenticationGroupFactory

class function TPerception_Provider_PerceptionFaceAuthenticationGroup.Create(ids: IIterable_1__HSTRING; startHandler: Perception_Provider_PerceptionStartFaceAuthenticationHandler; stopHandler: Perception_Provider_PerceptionStopFaceAuthenticationHandler): Perception_Provider_IPerceptionFaceAuthenticationGroup;
begin
  Result := Factory.Create(ids, startHandler, stopHandler);
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionFrameProviderInfo }

{ TPerception_Provider_PerceptionFrameProviderManagerService }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionFrameProviderManagerServiceStatics'}
class procedure TPerception_Provider_PerceptionFrameProviderManagerService.RegisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo);
begin
  Statics.RegisterFrameProviderInfo(manager, frameProviderInfo);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.UnregisterFrameProviderInfo(manager: Perception_Provider_IPerceptionFrameProviderManager; frameProviderInfo: Perception_Provider_IPerceptionFrameProviderInfo);
begin
  Statics.UnregisterFrameProviderInfo(manager, frameProviderInfo);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.RegisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup);
begin
  Statics.RegisterFaceAuthenticationGroup(manager, faceAuthenticationGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.UnregisterFaceAuthenticationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; faceAuthenticationGroup: Perception_Provider_IPerceptionFaceAuthenticationGroup);
begin
  Statics.UnregisterFaceAuthenticationGroup(manager, faceAuthenticationGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.RegisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup);
begin
  Statics.RegisterControlGroup(manager, controlGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.UnregisterControlGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; controlGroup: Perception_Provider_IPerceptionControlGroup);
begin
  Statics.UnregisterControlGroup(manager, controlGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.RegisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup);
begin
  Statics.RegisterCorrelationGroup(manager, correlationGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.UnregisterCorrelationGroup(manager: Perception_Provider_IPerceptionFrameProviderManager; correlationGroup: Perception_Provider_IPerceptionCorrelationGroup);
begin
  Statics.UnregisterCorrelationGroup(manager, correlationGroup);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.UpdateAvailabilityForProvider(provider: Perception_Provider_IPerceptionFrameProvider; available: Boolean);
begin
  Statics.UpdateAvailabilityForProvider(provider, available);
end;

class procedure TPerception_Provider_PerceptionFrameProviderManagerService.PublishFrameForProvider(provider: Perception_Provider_IPerceptionFrameProvider; frame: Perception_Provider_IPerceptionFrame);
begin
  Statics.PublishFrameForProvider(provider, frame);
end;
{$ENDREGION}

{ TPerception_Provider_PerceptionVideoFrameAllocator }

{$REGION 'Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocatorFactory'}
// Factory: "Windows.Devices.Perception.Provider.IPerceptionVideoFrameAllocatorFactory"
// -> Perception_Provider_IPerceptionVideoFrameAllocatorFactory

class function TPerception_Provider_PerceptionVideoFrameAllocator.Create(maxOutstandingFrameCountForWrite: Cardinal; format: Imaging_BitmapPixelFormat; resolution: TSizeF; alpha: Imaging_BitmapAlphaMode): Perception_Provider_IPerceptionVideoFrameAllocator;
begin
  Result := Factory.Create(maxOutstandingFrameCountForWrite, format, resolution, alpha);
end;
{$ENDREGION}

{ TPower_Battery }

{$REGION 'Windows.Devices.Power.IBatteryStatics'}
class function TPower_Battery.get_AggregateBattery: Power_IBattery;
begin
  Result := Statics.get_AggregateBattery;
end;

class function TPower_Battery.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Power_IBattery;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TPower_Battery.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;
{$ENDREGION}

{ TPwm_PwmController }

{$REGION 'Windows.Devices.Pwm.IPwmControllerStatics'}
class function TPwm_PwmController.GetControllersAsync(provider: Pwm_Provider_IPwmProvider): IAsyncOperation_1__IVectorView_1__Pwm_IPwmController;
begin
  Result := Statics.GetControllersAsync(provider);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Pwm.IPwmControllerStatics2'}
class function TPwm_PwmController.GetDefaultAsync: IAsyncOperation_1__Pwm_IPwmController;
begin
  Result := Statics2.GetDefaultAsync;
end;

{$ENDREGION}

{$REGION 'Windows.Devices.Pwm.IPwmControllerStatics3'}
class function TPwm_PwmController.GetDeviceSelector: HSTRING;
begin
  Result := Statics3.GetDeviceSelector;
end;

class function TPwm_PwmController.GetDeviceSelector(friendlyName: HSTRING): HSTRING;
begin
  Result := Statics3.GetDeviceSelector(friendlyName);
end;

class function TPwm_PwmController.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Pwm_IPwmController;
begin
  Result := Statics3.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TRadios_Radio }

{$REGION 'Windows.Devices.Radios.IRadioStatics'}
class function TRadios_Radio.GetRadiosAsync: IAsyncOperation_1__IVectorView_1__Radios_IRadio;
begin
  Result := Statics.GetRadiosAsync;
end;

class function TRadios_Radio.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TRadios_Radio.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Radios_IRadio;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TRadios_Radio.RequestAccessAsync: IAsyncOperation_1__Radios_RadioAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;
{$ENDREGION}

{ TSerialCommunication_SerialDevice }

{$REGION 'Windows.Devices.SerialCommunication.ISerialDeviceStatics'}
class function TSerialCommunication_SerialDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TSerialCommunication_SerialDevice.GetDeviceSelector(portName: HSTRING): HSTRING;
begin
  Result := Statics.GetDeviceSelector(portName);
end;

class function TSerialCommunication_SerialDevice.GetDeviceSelectorFromUsbVidPid(vendorId: Word; productId: Word): HSTRING;
begin
  Result := Statics.GetDeviceSelectorFromUsbVidPid(vendorId, productId);
end;

class function TSerialCommunication_SerialDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__SerialCommunication_ISerialDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TSpi_Provider_ProviderSpiConnectionSettings }

{$REGION 'Windows.Devices.Spi.Provider.IProviderSpiConnectionSettingsFactory'}
// Factory: "Windows.Devices.Spi.Provider.IProviderSpiConnectionSettingsFactory"
// -> Spi_Provider_IProviderSpiConnectionSettingsFactory

class function TSpi_Provider_ProviderSpiConnectionSettings.Create(chipSelectLine: Integer): Spi_Provider_IProviderSpiConnectionSettings;
begin
  Result := Factory.Create(chipSelectLine);
end;
{$ENDREGION}

{ TSpi_SpiConnectionSettings }

{$REGION 'Windows.Devices.Spi.ISpiConnectionSettingsFactory'}
// Factory: "Windows.Devices.Spi.ISpiConnectionSettingsFactory"
// -> Spi_ISpiConnectionSettingsFactory

class function TSpi_SpiConnectionSettings.Create(chipSelectLine: Integer): Spi_ISpiConnectionSettings;
begin
  Result := Factory.Create(chipSelectLine);
end;
{$ENDREGION}

{ TSpi_SpiController }

{$REGION 'Windows.Devices.Spi.ISpiControllerStatics'}
class function TSpi_SpiController.GetDefaultAsync: IAsyncOperation_1__Spi_ISpiController;
begin
  Result := Statics.GetDefaultAsync;
end;

class function TSpi_SpiController.GetControllersAsync(provider: Spi_Provider_ISpiProvider): IAsyncOperation_1__IVectorView_1__Spi_ISpiController;
begin
  Result := Statics.GetControllersAsync(provider);
end;
{$ENDREGION}

{ TSpi_SpiDevice }

{$REGION 'Windows.Devices.Spi.ISpiDeviceStatics'}
class function TSpi_SpiDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TSpi_SpiDevice.GetDeviceSelector(friendlyName: HSTRING): HSTRING;
begin
  Result := Statics.GetDeviceSelector(friendlyName);
end;

class function TSpi_SpiDevice.GetBusInfo(busId: HSTRING): Spi_ISpiBusInfo;
begin
  Result := Statics.GetBusInfo(busId);
end;

class function TSpi_SpiDevice.FromIdAsync(busId: HSTRING; settings: Spi_ISpiConnectionSettings): IAsyncOperation_1__Spi_ISpiDevice;
begin
  Result := Statics.FromIdAsync(busId, settings);
end;
{$ENDREGION}

{ TUsb_UsbConfigurationDescriptor }

{$REGION 'Windows.Devices.Usb.IUsbConfigurationDescriptorStatics'}
class function TUsb_UsbConfigurationDescriptor.TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbConfigurationDescriptor): Boolean;
begin
  Result := Statics.TryParse(descriptor, parsed);
end;

class function TUsb_UsbConfigurationDescriptor.Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbConfigurationDescriptor;
begin
  Result := Statics.Parse(descriptor);
end;
{$ENDREGION}

{ TUsb_UsbControlRequestType }

{ TUsb_UsbDevice }

{$REGION 'Windows.Devices.Usb.IUsbDeviceStatics'}
class function TUsb_UsbDevice.GetDeviceSelector(vendorId: Cardinal; productId: Cardinal; winUsbInterfaceClass: TGuid): HSTRING;
begin
  Result := Statics.GetDeviceSelector(vendorId, productId, winUsbInterfaceClass);
end;

class function TUsb_UsbDevice.GetDeviceSelector(winUsbInterfaceClass: TGuid): HSTRING;
begin
  Result := Statics.GetDeviceSelector(winUsbInterfaceClass);
end;

class function TUsb_UsbDevice.GetDeviceSelector(vendorId: Cardinal; productId: Cardinal): HSTRING;
begin
  Result := Statics.GetDeviceSelector(vendorId, productId);
end;

class function TUsb_UsbDevice.GetDeviceClassSelector(usbClass: Usb_IUsbDeviceClass): HSTRING;
begin
  Result := Statics.GetDeviceClassSelector(usbClass);
end;

class function TUsb_UsbDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__Usb_IUsbDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TUsb_UsbDeviceClass }

{ TUsb_UsbDeviceClasses }

{$REGION 'Windows.Devices.Usb.IUsbDeviceClassesStatics'}
class function TUsb_UsbDeviceClasses.get_CdcControl: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_CdcControl;
end;

class function TUsb_UsbDeviceClasses.get_Physical: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_Physical;
end;

class function TUsb_UsbDeviceClasses.get_PersonalHealthcare: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_PersonalHealthcare;
end;

class function TUsb_UsbDeviceClasses.get_ActiveSync: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_ActiveSync;
end;

class function TUsb_UsbDeviceClasses.get_PalmSync: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_PalmSync;
end;

class function TUsb_UsbDeviceClasses.get_DeviceFirmwareUpdate: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_DeviceFirmwareUpdate;
end;

class function TUsb_UsbDeviceClasses.get_Irda: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_Irda;
end;

class function TUsb_UsbDeviceClasses.get_Measurement: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_Measurement;
end;

class function TUsb_UsbDeviceClasses.get_VendorSpecific: Usb_IUsbDeviceClass;
begin
  Result := Statics.get_VendorSpecific;
end;
{$ENDREGION}

{ TUsb_UsbEndpointDescriptor }

{$REGION 'Windows.Devices.Usb.IUsbEndpointDescriptorStatics'}
class function TUsb_UsbEndpointDescriptor.TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbEndpointDescriptor): Boolean;
begin
  Result := Statics.TryParse(descriptor, parsed);
end;

class function TUsb_UsbEndpointDescriptor.Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbEndpointDescriptor;
begin
  Result := Statics.Parse(descriptor);
end;
{$ENDREGION}

{ TUsb_UsbInterfaceDescriptor }

{$REGION 'Windows.Devices.Usb.IUsbInterfaceDescriptorStatics'}
class function TUsb_UsbInterfaceDescriptor.TryParse(descriptor: Usb_IUsbDescriptor; out parsed: Usb_IUsbInterfaceDescriptor): Boolean;
begin
  Result := Statics.TryParse(descriptor, parsed);
end;

class function TUsb_UsbInterfaceDescriptor.Parse(descriptor: Usb_IUsbDescriptor): Usb_IUsbInterfaceDescriptor;
begin
  Result := Statics.Parse(descriptor);
end;
{$ENDREGION}

{ TUsb_UsbSetupPacket }

{$REGION 'Windows.Devices.Usb.IUsbSetupPacketFactory'}
// Factory: "Windows.Devices.Usb.IUsbSetupPacketFactory"
// -> Usb_IUsbSetupPacketFactory

class function TUsb_UsbSetupPacket.CreateWithEightByteBuffer(eightByteBuffer: IBuffer): Usb_IUsbSetupPacket;
begin
  Result := Factory.CreateWithEightByteBuffer(eightByteBuffer);
end;
{$ENDREGION}

{ TWiFi_WiFiAdapter }

{$REGION 'Windows.Devices.WiFi.IWiFiAdapterStatics'}
class function TWiFi_WiFiAdapter.FindAllAdaptersAsync: IAsyncOperation_1__IVectorView_1__WiFi_IWiFiAdapter;
begin
  Result := Statics.FindAllAdaptersAsync;
end;

class function TWiFi_WiFiAdapter.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TWiFi_WiFiAdapter.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFi_IWiFiAdapter;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

class function TWiFi_WiFiAdapter.RequestAccessAsync: IAsyncOperation_1__WiFi_WiFiAccessStatus;
begin
  Result := Statics.RequestAccessAsync;
end;
{$ENDREGION}

{ TWiFiDirect_Services_WiFiDirectService }

{$REGION 'Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceStatics'}
class function TWiFiDirect_Services_WiFiDirectService.GetSelector(serviceName: HSTRING): HSTRING;
begin
  Result := Statics.GetSelector(serviceName);
end;

class function TWiFiDirect_Services_WiFiDirectService.GetSelector(serviceName: HSTRING; serviceInfoFilter: IBuffer): HSTRING;
begin
  Result := Statics.GetSelector(serviceName, serviceInfoFilter);
end;

class function TWiFiDirect_Services_WiFiDirectService.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_Services_IWiFiDirectService;
begin
  Result := Statics.FromIdAsync(deviceId);
end;
{$ENDREGION}

{ TWiFiDirect_Services_WiFiDirectServiceAdvertiser }

{$REGION 'Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiserFactory'}
// Factory: "Windows.Devices.WiFiDirect.Services.IWiFiDirectServiceAdvertiserFactory"
// -> WiFiDirect_Services_IWiFiDirectServiceAdvertiserFactory

class function TWiFiDirect_Services_WiFiDirectServiceAdvertiser.CreateWiFiDirectServiceAdvertiser(serviceName: HSTRING): WiFiDirect_Services_IWiFiDirectServiceAdvertiser;
begin
  Result := Factory.CreateWiFiDirectServiceAdvertiser(serviceName);
end;
{$ENDREGION}

{ TWiFiDirect_WiFiDirectAdvertisementPublisher }

{ TWiFiDirect_WiFiDirectConnectionListener }

{ TWiFiDirect_WiFiDirectConnectionParameters }

{$REGION 'Windows.Devices.WiFiDirect.IWiFiDirectConnectionParametersStatics'}
class function TWiFiDirect_WiFiDirectConnectionParameters.GetDevicePairingKinds(configurationMethod: WiFiDirect_WiFiDirectConfigurationMethod): DevicePairingKinds;
begin
  Result := Statics.GetDevicePairingKinds(configurationMethod);
end;
{$ENDREGION}

{ TWiFiDirect_WiFiDirectDevice }

{$REGION 'Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics'}
class function TWiFiDirect_WiFiDirectDevice.GetDeviceSelector: HSTRING;
begin
  Result := Statics.GetDeviceSelector;
end;

class function TWiFiDirect_WiFiDirectDevice.FromIdAsync(deviceId: HSTRING): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice;
begin
  Result := Statics.FromIdAsync(deviceId);
end;

{$ENDREGION}

{$REGION 'Windows.Devices.WiFiDirect.IWiFiDirectDeviceStatics2'}
class function TWiFiDirect_WiFiDirectDevice.GetDeviceSelector(&type: WiFiDirect_WiFiDirectDeviceSelectorType): HSTRING;
begin
  Result := Statics2.GetDeviceSelector(&type);
end;

class function TWiFiDirect_WiFiDirectDevice.FromIdAsync(deviceId: HSTRING; connectionParameters: WiFiDirect_IWiFiDirectConnectionParameters): IAsyncOperation_1__WiFiDirect_IWiFiDirectDevice;
begin
  Result := Statics2.FromIdAsync(deviceId, connectionParameters);
end;
{$ENDREGION}

{ TWiFiDirect_WiFiDirectInformationElement }

{$REGION 'Windows.Devices.WiFiDirect.IWiFiDirectInformationElementStatics'}
class function TWiFiDirect_WiFiDirectInformationElement.CreateFromBuffer(buffer: IBuffer): IVector_1__WiFiDirect_IWiFiDirectInformationElement;
begin
  Result := Statics.CreateFromBuffer(buffer);
end;

class function TWiFiDirect_WiFiDirectInformationElement.CreateFromDeviceInformation(deviceInformation: IDeviceInformation): IVector_1__WiFiDirect_IWiFiDirectInformationElement;
begin
  Result := Statics.CreateFromDeviceInformation(deviceInformation);
end;
{$ENDREGION}

end.
