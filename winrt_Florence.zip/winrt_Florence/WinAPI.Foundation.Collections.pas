{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Foundation.Collections;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Microsoft.CommonTypes,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  AsyncOperationCompletedHandler_1__IPropertySet = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IPropertySet;
  AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IVectorView_1__HSTRING;
  AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IVectorView_1__IInspectable;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IInspectable = Winapi.CommonTypes.PAsyncOperationCompletedHandler_1__IVectorView_1__IInspectable;
  CollectionChange = Winapi.CommonTypes.CollectionChange;
  PCollectionChange = Winapi.CommonTypes.PCollectionChange;
  IAsyncOperation_1__IPropertySet = Winapi.CommonTypes.IAsyncOperation_1__IPropertySet;
  IAsyncOperation_1__IVectorView_1__HSTRING = Winapi.CommonTypes.IAsyncOperation_1__IVectorView_1__HSTRING;
  IAsyncOperation_1__IVectorView_1__IInspectable = Winapi.CommonTypes.IAsyncOperation_1__IVectorView_1__IInspectable;
  PIAsyncOperation_1__IVectorView_1__IInspectable = Winapi.CommonTypes.PIAsyncOperation_1__IVectorView_1__IInspectable;
  IIterable_1__HSTRING = Winapi.CommonTypes.IIterable_1__HSTRING;
  PIIterable_1__HSTRING = Winapi.CommonTypes.PIIterable_1__HSTRING;
  IIterator_1__HSTRING = Winapi.CommonTypes.IIterator_1__HSTRING;
  PIIterator_1__HSTRING = Winapi.CommonTypes.PIIterator_1__HSTRING;
  IMap_2__HSTRING__HSTRING = Winapi.CommonTypes.IMap_2__HSTRING__HSTRING;
  PIMap_2__HSTRING__HSTRING = Winapi.CommonTypes.PIMap_2__HSTRING__HSTRING;
  IMap_2__IInspectable__IInspectable = Winapi.CommonTypes.IMap_2__IInspectable__IInspectable;
  PIMap_2__IInspectable__IInspectable = Winapi.CommonTypes.PIMap_2__IInspectable__IInspectable;
  IMap_2__TGuid__IInspectable = Winapi.CommonTypes.IMap_2__TGuid__IInspectable;
  PIMap_2__TGuid__IInspectable = Winapi.CommonTypes.PIMap_2__TGuid__IInspectable;
  IMapView_2__HSTRING__Double = Winapi.CommonTypes.IMapView_2__HSTRING__Double;
  PIMapView_2__HSTRING__Double = Winapi.CommonTypes.PIMapView_2__HSTRING__Double;
  IMapView_2__HSTRING__HSTRING = Winapi.CommonTypes.IMapView_2__HSTRING__HSTRING;
  PIMapView_2__HSTRING__HSTRING = Winapi.CommonTypes.PIMapView_2__HSTRING__HSTRING;
  IMapView_2__HSTRING__IInspectable = Winapi.CommonTypes.IMapView_2__HSTRING__IInspectable;
  PIMapView_2__HSTRING__IInspectable = Winapi.CommonTypes.PIMapView_2__HSTRING__IInspectable;
  IMapView_2__HSTRING__IVectorView_1__HSTRING = Winapi.CommonTypes.IMapView_2__HSTRING__IVectorView_1__HSTRING;
  IMapView_2__IInspectable__IInspectable = Winapi.CommonTypes.IMapView_2__IInspectable__IInspectable;
  PIMapView_2__IInspectable__IInspectable = Winapi.CommonTypes.PIMapView_2__IInspectable__IInspectable;
  IMapView_2__TGuid__IInspectable = Winapi.CommonTypes.IMapView_2__TGuid__IInspectable;
  PIMapView_2__TGuid__IInspectable = Winapi.CommonTypes.PIMapView_2__TGuid__IInspectable;
  IObservableVector_1__IInspectable = Winapi.CommonTypes.IObservableVector_1__IInspectable;
  PIObservableVector_1__IInspectable = Winapi.CommonTypes.PIObservableVector_1__IInspectable;
  IPropertySet = Winapi.CommonTypes.IPropertySet;
  PIPropertySet = Winapi.CommonTypes.PIPropertySet;
  IVector_1__HSTRING = Winapi.CommonTypes.IVector_1__HSTRING;
  PIVector_1__HSTRING = Winapi.CommonTypes.PIVector_1__HSTRING;
  IVector_1__IInspectable = Winapi.CommonTypes.IVector_1__IInspectable;
  PIVector_1__IInspectable = Winapi.CommonTypes.PIVector_1__IInspectable;
  IVector_1__Integer = Winapi.CommonTypes.IVector_1__Integer;
  PIVector_1__Integer = Winapi.CommonTypes.PIVector_1__Integer;
  IVector_1__Single = Winapi.CommonTypes.IVector_1__Single;
  PIVector_1__Single = Winapi.CommonTypes.PIVector_1__Single;
  IVectorChangedEventArgs = Winapi.CommonTypes.IVectorChangedEventArgs;
  PIVectorChangedEventArgs = Winapi.CommonTypes.PIVectorChangedEventArgs;
  IVectorView_1__Cardinal = Winapi.CommonTypes.IVectorView_1__Cardinal;
  PIVectorView_1__Cardinal = Winapi.CommonTypes.PIVectorView_1__Cardinal;
  IVectorView_1__HSTRING = Winapi.CommonTypes.IVectorView_1__HSTRING;
  PIVectorView_1__HSTRING = Winapi.CommonTypes.PIVectorView_1__HSTRING;
  IVectorView_1__IInspectable = Winapi.CommonTypes.IVectorView_1__IInspectable;
  PIVectorView_1__IInspectable = Winapi.CommonTypes.PIVectorView_1__IInspectable;
  IVectorView_1__Integer = Winapi.CommonTypes.IVectorView_1__Integer;
  PIVectorView_1__Integer = Winapi.CommonTypes.PIVectorView_1__Integer;
  IVectorView_1__Single = Winapi.CommonTypes.IVectorView_1__Single;
  PIVectorView_1__Single = Winapi.CommonTypes.PIVectorView_1__Single;
  TypedEventHandler_2__ITabView__IVectorChangedEventArgs = Winapi.Microsoft.CommonTypes.TypedEventHandler_2__ITabView__IVectorChangedEventArgs;
  TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs = Winapi.CommonTypes.TypedEventHandler_2__Playback_IMediaPlaybackItem__IVectorChangedEventArgs;
  VectorChangedEventHandler_1__IInspectable = Winapi.CommonTypes.VectorChangedEventHandler_1__IInspectable;
  PVectorChangedEventHandler_1__IInspectable = Winapi.CommonTypes.PVectorChangedEventHandler_1__IInspectable;

  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>
  IKeyValuePair_2__IInspectable__IInspectable = interface;
  PIKeyValuePair_2__IInspectable__IInspectable = ^IKeyValuePair_2__IInspectable__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>>
  IIterator_1__IKeyValuePair_2__IInspectable__IInspectable = interface;
  PIIterator_1__IKeyValuePair_2__IInspectable__IInspectable = ^IIterator_1__IKeyValuePair_2__IInspectable__IInspectable;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>>
  IIterable_1__IKeyValuePair_2__IInspectable__IInspectable = interface;
  PIIterable_1__IKeyValuePair_2__IInspectable__IInspectable = ^IIterable_1__IKeyValuePair_2__IInspectable__IInspectable;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Object>
  IKeyValuePair_2__HSTRING__IInspectable = interface;
  PIKeyValuePair_2__HSTRING__IInspectable = ^IKeyValuePair_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  IIterator_1__IKeyValuePair_2__HSTRING__IInspectable = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IInspectable = ^IIterator_1__IKeyValuePair_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  IIterable_1__IKeyValuePair_2__HSTRING__IInspectable = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IInspectable = ^IIterable_1__IKeyValuePair_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IMap`2<String,Object>
  IMap_2__HSTRING__IInspectable = interface;
  PIMap_2__HSTRING__IInspectable = ^IMap_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Object>
  IIterator_1__IInspectable = interface;
  PIIterator_1__IInspectable = ^IIterator_1__IInspectable;

  // Windows.Foundation.Collections.IIterable`1<Object>
  IIterable_1__IInspectable = interface;
  PIIterable_1__IInspectable = ^IIterable_1__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Int32>
  IIterator_1__Integer = interface;
  PIIterator_1__Integer = ^IIterator_1__Integer;

  // Windows.Foundation.Collections.IIterable`1<Int32>
  IIterable_1__Integer = interface;
  PIIterable_1__Integer = ^IIterable_1__Integer;

  // Windows.Foundation.Collections.IIterator`1<Single>
  IIterator_1__Single = interface;
  PIIterator_1__Single = ^IIterator_1__Single;

  // Windows.Foundation.Collections.IIterable`1<Single>
  IIterable_1__Single = interface;
  PIIterable_1__Single = ^IIterable_1__Single;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Double>
  IKeyValuePair_2__HSTRING__Double = interface;
  PIKeyValuePair_2__HSTRING__Double = ^IKeyValuePair_2__HSTRING__Double;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Double>>
  IIterator_1__IKeyValuePair_2__HSTRING__Double = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__Double = ^IIterator_1__IKeyValuePair_2__HSTRING__Double;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Double>>
  IIterable_1__IKeyValuePair_2__HSTRING__Double = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__Double = ^IIterable_1__IKeyValuePair_2__HSTRING__Double;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,String>
  IKeyValuePair_2__HSTRING__HSTRING = interface;
  PIKeyValuePair_2__HSTRING__HSTRING = ^IKeyValuePair_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,String>>
  IIterator_1__IKeyValuePair_2__HSTRING__HSTRING = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__HSTRING = ^IIterator_1__IKeyValuePair_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,String>>
  IIterable_1__IKeyValuePair_2__HSTRING__HSTRING = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__HSTRING = ^IIterable_1__IKeyValuePair_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IMapChangedEventArgs`1<String>
  IMapChangedEventArgs_1__HSTRING = interface;
  PIMapChangedEventArgs_1__HSTRING = ^IMapChangedEventArgs_1__HSTRING;

  // Windows.Foundation.Collections.MapChangedEventHandler`2<String,Object>
  MapChangedEventHandler_2__HSTRING__IInspectable = interface;
  PMapChangedEventHandler_2__HSTRING__IInspectable = ^MapChangedEventHandler_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IObservableMap`2<String,Object>
  IObservableMap_2__HSTRING__IInspectable = interface;
  PIObservableMap_2__HSTRING__IInspectable = ^IObservableMap_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Double>
  IIterator_1__Double = interface;
  PIIterator_1__Double = ^IIterator_1__Double;

  // Windows.Foundation.Collections.IIterable`1<Double>
  IIterable_1__Double = interface;
  PIIterable_1__Double = ^IIterable_1__Double;

  // Windows.Foundation.Collections.IVectorView`1<Double>
  IVectorView_1__Double = interface;
  PIVectorView_1__Double = ^IVectorView_1__Double;

  // Windows.Foundation.Collections.IVector`1<Double>
  IVector_1__Double = interface;
  PIVector_1__Double = ^IVector_1__Double;

  // Windows.Foundation.Collections.IIterator`1<UInt64>
  IIterator_1__UInt64 = interface;
  PIIterator_1__UInt64 = ^IIterator_1__UInt64;

  // Windows.Foundation.Collections.IIterable`1<UInt64>
  IIterable_1__UInt64 = interface;
  PIIterable_1__UInt64 = ^IIterable_1__UInt64;

  // Windows.Foundation.Collections.IVectorView`1<UInt64>
  IVectorView_1__UInt64 = interface;
  PIVectorView_1__UInt64 = ^IVectorView_1__UInt64;

  // Windows.Foundation.Collections.IIterator`1<Int64>
  IIterator_1__Int64 = interface;
  PIIterator_1__Int64 = ^IIterator_1__Int64;

  // Windows.Foundation.Collections.IIterable`1<Int64>
  IIterable_1__Int64 = interface;
  PIIterable_1__Int64 = ^IIterable_1__Int64;

  // Windows.Foundation.Collections.IVectorView`1<Int64>
  IVectorView_1__Int64 = interface;
  PIVectorView_1__Int64 = ^IVectorView_1__Int64;

  // Windows.Foundation.Collections.IIterator`1<Boolean>
  IIterator_1__Boolean = interface;
  PIIterator_1__Boolean = ^IIterator_1__Boolean;

  // Windows.Foundation.Collections.IIterable`1<Boolean>
  IIterable_1__Boolean = interface;
  PIIterable_1__Boolean = ^IIterable_1__Boolean;

  // Windows.Foundation.Collections.IVectorView`1<Boolean>
  IVectorView_1__Boolean = interface;
  PIVectorView_1__Boolean = ^IVectorView_1__Boolean;

  // Windows.Foundation.Collections.IIterator`1<Int16>
  IIterator_1__SmallInt = interface;
  PIIterator_1__SmallInt = ^IIterator_1__SmallInt;

  // Windows.Foundation.Collections.IIterable`1<Int16>
  IIterable_1__SmallInt = interface;
  PIIterable_1__SmallInt = ^IIterable_1__SmallInt;

  // Windows.Foundation.Collections.IVectorView`1<Int16>
  IVectorView_1__SmallInt = interface;
  PIVectorView_1__SmallInt = ^IVectorView_1__SmallInt;

  // Windows.Foundation.Collections.IIterator`1<UInt8>
  IIterator_1__Byte = interface;
  PIIterator_1__Byte = ^IIterator_1__Byte;

  // Windows.Foundation.Collections.IIterable`1<UInt8>
  IIterable_1__Byte = interface;
  PIIterable_1__Byte = ^IIterable_1__Byte;

  // Windows.Foundation.Collections.IVectorView`1<UInt8>
  IVectorView_1__Byte = interface;
  PIVectorView_1__Byte = ^IVectorView_1__Byte;

  // Windows.Foundation.Collections.IIterator`1<UInt16>
  IIterator_1__Word = interface;
  PIIterator_1__Word = ^IIterator_1__Word;

  // Windows.Foundation.Collections.IIterable`1<UInt16>
  IIterable_1__Word = interface;
  PIIterable_1__Word = ^IIterable_1__Word;

  // Windows.Foundation.Collections.IVectorView`1<UInt16>
  IVectorView_1__Word = interface;
  PIVectorView_1__Word = ^IVectorView_1__Word;

  // Windows.Foundation.Collections.IIterator`1<UInt32>
  IIterator_1__Cardinal = interface;
  PIIterator_1__Cardinal = ^IIterator_1__Cardinal;

  // Windows.Foundation.Collections.IIterable`1<UInt32>
  IIterable_1__Cardinal = interface;
  PIIterable_1__Cardinal = ^IIterable_1__Cardinal;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>
  IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface;
  PIKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = ^IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>>
  IIterator_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = ^IIterator_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>>
  IIterable_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = ^IIterable_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING;

  // Windows.Foundation.Collections.IIterator`1<Guid>
  IIterator_1__TGuid = interface;
  PIIterator_1__TGuid = ^IIterator_1__TGuid;

  // Windows.Foundation.Collections.IIterable`1<Guid>
  IIterable_1__TGuid = interface;
  PIIterable_1__TGuid = ^IIterable_1__TGuid;

  // Windows.Foundation.Collections.IVectorView`1<Guid>
  IVectorView_1__TGuid = interface;
  PIVectorView_1__TGuid = ^IVectorView_1__TGuid;

  // Windows.Foundation.Collections.IVector`1<Guid>
  IVector_1__TGuid = interface;
  PIVector_1__TGuid = ^IVector_1__TGuid;

  // Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>
  IKeyValuePair_2__TGuid__IInspectable = interface;
  PIKeyValuePair_2__TGuid__IInspectable = ^IKeyValuePair_2__TGuid__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>>
  IIterator_1__IKeyValuePair_2__TGuid__IInspectable = interface;
  PIIterator_1__IKeyValuePair_2__TGuid__IInspectable = ^IIterator_1__IKeyValuePair_2__TGuid__IInspectable;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>>
  IIterable_1__IKeyValuePair_2__TGuid__IInspectable = interface;
  PIIterable_1__IKeyValuePair_2__TGuid__IInspectable = ^IIterable_1__IKeyValuePair_2__TGuid__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVector`1<String>>
  AsyncOperationCompletedHandler_1__IVector_1__HSTRING = interface;
  PAsyncOperationCompletedHandler_1__IVector_1__HSTRING = ^AsyncOperationCompletedHandler_1__IVector_1__HSTRING;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVector`1<String>>
  IAsyncOperation_1__IVector_1__HSTRING = interface;
  PIAsyncOperation_1__IVector_1__HSTRING = ^IAsyncOperation_1__IVector_1__HSTRING;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<UInt32>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__Cardinal = ^AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<UInt32>>
  IAsyncOperation_1__IVectorView_1__Cardinal = interface;
  PIAsyncOperation_1__IVectorView_1__Cardinal = ^IAsyncOperation_1__IVectorView_1__Cardinal;

  // Windows.Foundation.Collections.MapChangedEventHandler`2<String,String>
  MapChangedEventHandler_2__HSTRING__HSTRING = interface;
  PMapChangedEventHandler_2__HSTRING__HSTRING = ^MapChangedEventHandler_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IObservableMap`2<String,String>
  IObservableMap_2__HSTRING__HSTRING = interface;
  PIObservableMap_2__HSTRING__HSTRING = ^IObservableMap_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IVector`1<UInt32>
  IVector_1__Cardinal = interface;
  PIVector_1__Cardinal = ^IVector_1__Cardinal;

  // Windows.Foundation.Collections.IVector`1<Boolean>
  IVector_1__Boolean = interface;
  PIVector_1__Boolean = ^IVector_1__Boolean;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMap`2<String,Object>>
  AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable = interface;
  PAsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable = ^AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMap`2<String,Object>>
  IAsyncOperation_1__IMap_2__HSTRING__IInspectable = interface;
  PIAsyncOperation_1__IMap_2__HSTRING__IInspectable = ^IAsyncOperation_1__IMap_2__HSTRING__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMap`2<String,String>>
  AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING = interface;
  PAsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING = ^AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMap`2<String,String>>
  IAsyncOperation_1__IMap_2__HSTRING__HSTRING = interface;
  PIAsyncOperation_1__IMap_2__HSTRING__HSTRING = ^IAsyncOperation_1__IMap_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface;
  PIKeyValuePair_2__HSTRING__IVector_1__HSTRING = ^IKeyValuePair_2__HSTRING__IVector_1__HSTRING;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>>
  IIterator_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = ^IIterator_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>>
  IIterable_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = ^IIterable_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IMapView_2__HSTRING__IVector_1__HSTRING = interface;
  PIMapView_2__HSTRING__IVector_1__HSTRING = ^IMapView_2__HSTRING__IVector_1__HSTRING;

  // Windows.Foundation.Collections.IMap`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IMap_2__HSTRING__IVector_1__HSTRING = interface;
  PIMap_2__HSTRING__IVector_1__HSTRING = ^IMap_2__HSTRING__IVector_1__HSTRING;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable = interface;
  PAsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable = ^AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IAsyncOperation_1__IMapView_2__HSTRING__IInspectable = interface;
  PIAsyncOperation_1__IMapView_2__HSTRING__IInspectable = ^IAsyncOperation_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IIterator_1__IMapView_2__HSTRING__IInspectable = interface;
  PIIterator_1__IMapView_2__HSTRING__IInspectable = ^IIterator_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IIterable_1__IMapView_2__HSTRING__IInspectable = interface;
  PIIterable_1__IMapView_2__HSTRING__IInspectable = ^IIterable_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IVectorView_1__IMapView_2__HSTRING__IInspectable = interface;
  PIVectorView_1__IMapView_2__HSTRING__IInspectable = ^IVectorView_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = ^AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>>
  IAsyncOperation_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = interface;
  PIAsyncOperation_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = ^IAsyncOperation_1__IVectorView_1__IMapView_2__HSTRING__IInspectable;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,String>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING = interface;
  PAsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING = ^AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,String>>
  IAsyncOperation_1__IMapView_2__HSTRING__HSTRING = interface;
  PIAsyncOperation_1__IMapView_2__HSTRING__HSTRING = ^IAsyncOperation_1__IMapView_2__HSTRING__HSTRING;

  // Windows.Foundation.Collections Interfaces

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>
  IKeyValuePair_2__IInspectable__IInspectable = interface(IInspectable)
  ['{59E7AE0C-C29D-5AD6-BEF5-DEDB52A198E1}']
    function get_Key: IInspectable; safecall;
    function get_Value: IInspectable; safecall;
    property Key: IInspectable read get_Key;
    property Value: IInspectable read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>>
  IIterator_1__IKeyValuePair_2__IInspectable__IInspectable = interface(IInspectable)
  ['{31E55E8A-0F05-52FD-90D3-B04AA331AAA4}']
    function get_Current: IKeyValuePair_2__IInspectable__IInspectable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__IInspectable__IInspectable): Cardinal; safecall;
    property Current: IKeyValuePair_2__IInspectable__IInspectable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Object,Object>>
  IIterable_1__IKeyValuePair_2__IInspectable__IInspectable = interface(IInspectable)
  ['{33AC68F0-1084-529A-8A17-4E7C8ADB7A0C}']
    function First: IIterator_1__IKeyValuePair_2__IInspectable__IInspectable; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,Object>
  IKeyValuePair_2__HSTRING__IInspectable = interface(IInspectable)
  ['{09335560-6C6B-5A26-9348-97B781132B20}']
    function get_Key: HSTRING; safecall;
    function get_Value: IInspectable; safecall;
    property Key: HSTRING read get_Key;
    property Value: IInspectable read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  IIterator_1__IKeyValuePair_2__HSTRING__IInspectable = interface(IInspectable)
  ['{5DB5FA32-707C-5849-A06B-91C8EB9D10E8}']
    function get_Current: IKeyValuePair_2__HSTRING__IInspectable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IInspectable): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IInspectable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  IIterable_1__IKeyValuePair_2__HSTRING__IInspectable = interface(IInspectable)
  ['{FE2F3D47-5D47-5499-8374-430C7CDA0204}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IInspectable; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IMap`2<String,Object>
  IMap_2__HSTRING__IInspectable = interface(IInspectable)
  ['{1B0D3570-0877-5EC2-8A2C-3B9539506ACA}']
    function Lookup(key: HSTRING): IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    function GetView: IMapView_2__HSTRING__IInspectable; safecall;
    function Insert(key: HSTRING; value: IInspectable): Boolean; safecall;
    procedure Remove(key: HSTRING); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Object>
  IIterator_1__IInspectable = interface(IInspectable)
  ['{44A94F2D-04F8-5091-B336-BE7892DD10BE}']
    function get_Current: IInspectable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIInspectable): Cardinal; safecall;
    property Current: IInspectable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Object>
  IIterable_1__IInspectable = interface(IInspectable)
  ['{092B849B-60B1-52BE-A44A-6FE8E933CBE4}']
    function First: IIterator_1__IInspectable; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Int32>
  IIterator_1__Integer = interface(IInspectable)
  ['{BFEA7F78-50C2-5F1D-A6EA-9E978D2699FF}']
    function get_Current: Integer; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PInteger): Cardinal; safecall;
    property Current: Integer read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Int32>
  IIterable_1__Integer = interface(IInspectable)
  ['{81A643FB-F51C-5565-83C4-F96425777B66}']
    function First: IIterator_1__Integer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Single>
  IIterator_1__Single = interface(IInspectable)
  ['{42614E61-B0AA-5E72-9354-2771DB20B7A8}']
    function get_Current: Single; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSingle): Cardinal; safecall;
    property Current: Single read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Single>
  IIterable_1__Single = interface(IInspectable)
  ['{B01BEE51-063A-5FDA-BD72-D76637BB8CB8}']
    function First: IIterator_1__Single; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,Double>
  IKeyValuePair_2__HSTRING__Double = interface(IInspectable)
  ['{F3F8B9B7-456E-5A34-93A8-FBC5C63E9F0A}']
    function get_Key: HSTRING; safecall;
    function get_Value: Double; safecall;
    property Key: HSTRING read get_Key;
    property Value: Double read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Double>>
  IIterator_1__IKeyValuePair_2__HSTRING__Double = interface(IInspectable)
  ['{4E32FE35-DF21-5EF4-BA75-7E351D69CF7E}']
    function get_Current: IKeyValuePair_2__HSTRING__Double; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__Double): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__Double read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Double>>
  IIterable_1__IKeyValuePair_2__HSTRING__Double = interface(IInspectable)
  ['{822B22EF-209F-56AA-A4C3-DC0113B25E4C}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__Double; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,String>
  IKeyValuePair_2__HSTRING__HSTRING = interface(IInspectable)
  ['{60310303-49C5-52E6-ABC6-A9B36ECCC716}']
    function get_Key: HSTRING; safecall;
    function get_Value: HSTRING; safecall;
    property Key: HSTRING read get_Key;
    property Value: HSTRING read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,String>>
  IIterator_1__IKeyValuePair_2__HSTRING__HSTRING = interface(IInspectable)
  ['{05EB86F1-7140-5517-B88D-CBAEBE57E6B1}']
    function get_Current: IKeyValuePair_2__HSTRING__HSTRING; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__HSTRING): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__HSTRING read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,String>>
  IIterable_1__IKeyValuePair_2__HSTRING__HSTRING = interface(IInspectable)
  ['{E9BDAAF0-CBF6-5C72-BE90-29CBF3A1319B}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapChangedEventArgs`1<String>
  IMapChangedEventArgs_1__HSTRING = interface(IInspectable)
  ['{60141EFB-F2F9-5377-96FD-F8C60D9558B5}']
    function get_CollectionChange: CollectionChange; safecall;
    function get_Key: HSTRING; safecall;
    property CollectionChange_: CollectionChange read get_CollectionChange;
    property Key: HSTRING read get_Key;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.MapChangedEventHandler`2<String,Object>
  MapChangedEventHandler_2__HSTRING__IInspectable = interface(IUnknown)
  ['{24F981E5-DDCA-538D-AADA-A59906084CF1}']
    procedure Invoke(sender: IObservableMap_2__HSTRING__IInspectable; event: IMapChangedEventArgs_1__HSTRING); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IObservableMap`2<String,Object>
  IObservableMap_2__HSTRING__IInspectable = interface(IInspectable)
  ['{236AAC9D-FB12-5C4D-A41C-9E445FB4D7EC}']
    function add_MapChanged(vhnd: MapChangedEventHandler_2__HSTRING__IInspectable): EventRegistrationToken; safecall;
    procedure remove_MapChanged(token: EventRegistrationToken); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Double>
  IIterator_1__Double = interface(IInspectable)
  ['{638A2CF4-F474-5318-9055-141CB909AC4B}']
    function get_Current: Double; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PDouble): Cardinal; safecall;
    property Current: Double read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Double>
  IIterable_1__Double = interface(IInspectable)
  ['{C738964E-9C64-5BCE-B5CE-61E9A282EC4A}']
    function First: IIterator_1__Double; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Double>
  IVectorView_1__Double = interface(IInspectable)
  ['{AF7586A8-6B21-5F61-BFF1-1B682293AD96}']
    function GetAt(index: Cardinal): Double; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Double; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDouble): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Double>
  [WinRTClassNameAttribute(SMicrosoft_UI_Xaml_Media_DoubleCollection)]
  IVector_1__Double = interface(IInspectable)
  ['{F452D23C-BF05-5F3E-88E7-D17A6716B911}']
    function GetAt(index: Cardinal): Double; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Double; safecall;
    function IndexOf(value: Double; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Double); safecall;
    procedure InsertAt(index: Cardinal; value: Double); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Double); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PDouble): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PDouble); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<UInt64>
  IIterator_1__UInt64 = interface(IInspectable)
  ['{C473ED96-76E3-5FF2-9435-47FEEBFE9539}']
    function get_Current: UInt64; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PUInt64): Cardinal; safecall;
    property Current: UInt64 read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<UInt64>
  IIterable_1__UInt64 = interface(IInspectable)
  ['{4B3A3229-7995-5F3C-B248-6C1F7E664F01}']
    function First: IIterator_1__UInt64; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<UInt64>
  IVectorView_1__UInt64 = interface(IInspectable)
  ['{23D156C7-7EF9-5096-AABA-1E6C9AB5CEB4}']
    function GetAt(index: Cardinal): UInt64; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: UInt64; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PUInt64): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Int64>
  IIterator_1__Int64 = interface(IInspectable)
  ['{FB98034C-86B7-581F-8CD9-5AD0692201A9}']
    function get_Current: Int64; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PInt64): Cardinal; safecall;
    property Current: Int64 read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Int64>
  IIterable_1__Int64 = interface(IInspectable)
  ['{7784427E-F9CC-518D-964B-E50D5CE727F1}']
    function First: IIterator_1__Int64; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Int64>
  IVectorView_1__Int64 = interface(IInspectable)
  ['{8221AA0E-D1D2-5B22-A918-05672812D12F}']
    function GetAt(index: Cardinal): Int64; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Int64; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PInt64): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Boolean>
  IIterator_1__Boolean = interface(IInspectable)
  ['{740A0296-A535-572A-BF0B-17C18FF71FE6}']
    function get_Current: Boolean; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PBoolean): Cardinal; safecall;
    property Current: Boolean read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Boolean>
  IIterable_1__Boolean = interface(IInspectable)
  ['{30160817-1D7D-54E9-99DB-D7636266A476}']
    function First: IIterator_1__Boolean; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Boolean>
  IVectorView_1__Boolean = interface(IInspectable)
  ['{243A09CB-6F40-56AF-A442-FE81431FBEF5}']
    function GetAt(index: Cardinal): Boolean; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Boolean; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PBoolean): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Int16>
  IIterator_1__SmallInt = interface(IInspectable)
  ['{5409069F-E7C1-5732-BB69-E5736F03F9A9}']
    function get_Current: SmallInt; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PSmallInt): Cardinal; safecall;
    property Current: SmallInt read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Int16>
  IIterable_1__SmallInt = interface(IInspectable)
  ['{72FF2923-4B4E-53BB-8FEB-41EC5F2BB734}']
    function First: IIterator_1__SmallInt; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Int16>
  IVectorView_1__SmallInt = interface(IInspectable)
  ['{E53056AD-8A0E-5C41-A62D-C92E3AC2DE58}']
    function GetAt(index: Cardinal): SmallInt; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: SmallInt; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PSmallInt): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<UInt8>
  IIterator_1__Byte = interface(IInspectable)
  ['{40556131-A2A1-5FAB-AAEE-5F35268CA26B}']
    function get_Current: Byte; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PByte): Cardinal; safecall;
    property Current: Byte read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<UInt8>
  IIterable_1__Byte = interface(IInspectable)
  ['{88318266-F3FD-50FC-8F08-B823A41B60C1}']
    function First: IIterator_1__Byte; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<UInt8>
  IVectorView_1__Byte = interface(IInspectable)
  ['{6D05FB29-7885-544E-9382-A1AD391A3FA4}']
    function GetAt(index: Cardinal): Byte; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Byte; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PByte): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<UInt16>
  IIterator_1__Word = interface(IInspectable)
  ['{5738FC25-402B-5FC1-B1E4-0AA24EF652F1}']
    function get_Current: Word; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PWord): Cardinal; safecall;
    property Current: Word read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<UInt16>
  IIterable_1__Word = interface(IInspectable)
  ['{ECFA9A6F-FA2E-5345-B297-EFB4E8C6BE87}']
    function First: IIterator_1__Word; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<UInt16>
  IVectorView_1__Word = interface(IInspectable)
  ['{9D0D0D9F-6A82-55A3-98C5-228499DF38F9}']
    function GetAt(index: Cardinal): Word; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: Word; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PWord): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<UInt32>
  IIterator_1__Cardinal = interface(IInspectable)
  ['{F06A2739-9443-5EF0-B284-DC5AFF3E7D10}']
    function get_Current: Cardinal; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PCardinal): Cardinal; safecall;
    property Current: Cardinal read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<UInt32>
  IIterable_1__Cardinal = interface(IInspectable)
  ['{421D4B91-B13B-5F37-AE54-B5249BD80539}']
    function First: IIterator_1__Cardinal; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>
  IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface(IInspectable)
  ['{BCDE03AD-EA71-5077-A961-1C0ECFF57202}']
    function get_Key: HSTRING; safecall;
    function get_Value: IVectorView_1__HSTRING; safecall;
    property Key: HSTRING read get_Key;
    property Value: IVectorView_1__HSTRING read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Resources.Core.ResourceContextLanguagesVectorView>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>>
  IIterator_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface(IInspectable)
  ['{E9C43F49-A8EB-5D3F-95F3-57FCF58D4E58}']
    function get_Current: IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IVectorView_1__HSTRING): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.ApplicationModel.Resources.Core.ResourceContextLanguagesVectorView>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVectorView`1<String>>>
  IIterable_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING = interface(IInspectable)
  ['{3C9F34A8-555B-54F3-B057-436A0EBB5B2E}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IVectorView_1__HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Guid>
  IIterator_1__TGuid = interface(IInspectable)
  ['{D3D64048-82B3-53C7-9285-B0BE18368482}']
    function get_Current: TGuid; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PGuid): Cardinal; safecall;
    property Current: TGuid read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Guid>
  IIterable_1__TGuid = interface(IInspectable)
  ['{F4CA3045-5DD7-54BE-982E-D88D8CA0876E}']
    function First: IIterator_1__TGuid; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Guid>
  IVectorView_1__TGuid = interface(IInspectable)
  ['{9520E64B-15B2-52A6-98ED-3191FA6CF68A}']
    function GetAt(index: Cardinal): TGuid; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: TGuid; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGuid): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Guid>
  IVector_1__TGuid = interface(IInspectable)
  ['{482E676D-B913-5EC1-AFA8-5F96922E94AE}']
    function GetAt(index: Cardinal): TGuid; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__TGuid; safecall;
    function IndexOf(value: TGuid; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: TGuid); safecall;
    procedure InsertAt(index: Cardinal; value: TGuid); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: TGuid); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PGuid): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PGuid); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>
  IKeyValuePair_2__TGuid__IInspectable = interface(IInspectable)
  ['{3BDA1540-D089-5A1A-8F0D-94EBA8068E58}']
    function get_Key: TGuid; safecall;
    function get_Value: IInspectable; safecall;
    property Key: TGuid read get_Key;
    property Value: IInspectable read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>>
  IIterator_1__IKeyValuePair_2__TGuid__IInspectable = interface(IInspectable)
  ['{4F25059A-0B9A-5F25-9B9E-4B9F1D22FF65}']
    function get_Current: IKeyValuePair_2__TGuid__IInspectable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__TGuid__IInspectable): Cardinal; safecall;
    property Current: IKeyValuePair_2__TGuid__IInspectable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<Guid,Object>>
  IIterable_1__IKeyValuePair_2__TGuid__IInspectable = interface(IInspectable)
  ['{F3B20528-E3B3-5331-B2D0-0C2623AEE785}']
    function First: IIterator_1__IKeyValuePair_2__TGuid__IInspectable; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Pickers.FileExtensionVector>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVector`1<String>>
  AsyncOperationCompletedHandler_1__IVector_1__HSTRING = interface(IUnknown)
  ['{CF19F489-10FA-5C99-9863-832BAFD70D0F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVector_1__HSTRING; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Pickers.FileExtensionVector>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVector`1<String>>
  IAsyncOperation_1__IVector_1__HSTRING = interface(IInspectable)
  ['{D644CC8E-66AC-5D8B-A204-6344AF2DEC9D}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVector_1__HSTRING); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVector_1__HSTRING; safecall;
    function GetResults: IVector_1__HSTRING; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVector_1__HSTRING read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<UInt32>>
  AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal = interface(IUnknown)
  ['{55772F29-DA64-5C87-871C-074337A84573}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__Cardinal; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<UInt32>>
  IAsyncOperation_1__IVectorView_1__Cardinal = interface(IInspectable)
  ['{52C56F3C-713A-5162-9E62-362CE7ED53BE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal; safecall;
    function GetResults: IVectorView_1__Cardinal; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__Cardinal read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.MapChangedEventHandler`2<String,String>
  MapChangedEventHandler_2__HSTRING__HSTRING = interface(IUnknown)
  ['{E2663F37-2E1B-500C-AD68-C3ED7A8F74C8}']
    procedure Invoke(sender: IObservableMap_2__HSTRING__HSTRING; event: IMapChangedEventArgs_1__HSTRING); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Foundation.Collections.IObservableMap`2<String,String>
  IObservableMap_2__HSTRING__HSTRING = interface(IInspectable)
  ['{1E036276-2F60-55F6-B7F3-F86079E6900B}']
    function add_MapChanged(vhnd: MapChangedEventHandler_2__HSTRING__HSTRING): EventRegistrationToken; safecall;
    procedure remove_MapChanged(token: EventRegistrationToken); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<UInt32>
  IVector_1__Cardinal = interface(IInspectable)
  ['{534832ED-2A03-5604-890D-5A928CD427B9}']
    function GetAt(index: Cardinal): Cardinal; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Cardinal; safecall;
    function IndexOf(value: Cardinal; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Cardinal); safecall;
    procedure InsertAt(index: Cardinal; value: Cardinal); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Cardinal); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PCardinal): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PCardinal); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Boolean>
  IVector_1__Boolean = interface(IInspectable)
  ['{6180171D-2ED8-5E24-8A55-01ECB1009EB2}']
    function GetAt(index: Cardinal): Boolean; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__Boolean; safecall;
    function IndexOf(value: Boolean; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: Boolean); safecall;
    procedure InsertAt(index: Cardinal; value: Boolean); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: Boolean); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PBoolean): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PBoolean); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMap`2<String,Object>>
  AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable = interface(IUnknown)
  ['{7344F356-8399-5756-A2F8-ABD50C4146FF}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMap_2__HSTRING__IInspectable; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMap`2<String,Object>>
  IAsyncOperation_1__IMap_2__HSTRING__IInspectable = interface(IInspectable)
  ['{127E39C7-07C1-58E5-B48E-3A4729839FEC}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable; safecall;
    function GetResults: IMap_2__HSTRING__IInspectable; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__IInspectable read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.StringMap>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMap`2<String,String>>
  AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING = interface(IUnknown)
  ['{E5449A0D-A54F-592E-B6F2-B861C6D3DDE2}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMap_2__HSTRING__HSTRING; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.StringMap>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMap`2<String,String>>
  IAsyncOperation_1__IMap_2__HSTRING__HSTRING = interface(IInspectable)
  ['{A7ADF6C2-2CC7-5AEE-A987-22872D91DF62}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING; safecall;
    function GetResults: IMap_2__HSTRING__HSTRING; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMap_2__HSTRING__HSTRING read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface(IInspectable)
  ['{174F26C7-79EA-5F7C-BD70-AC4457F2CAC8}']
    function get_Key: HSTRING; safecall;
    function get_Value: IVector_1__HSTRING; safecall;
    property Key: HSTRING read get_Key;
    property Value: IVector_1__HSTRING read get_Value;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Pickers.FileExtensionVector>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>>
  IIterator_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface(IInspectable)
  ['{92406DB2-9901-54A1-8CDB-9281E9527273}']
    function get_Current: IKeyValuePair_2__HSTRING__IVector_1__HSTRING; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IVector_1__HSTRING): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IVector_1__HSTRING read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Pickers.FileExtensionVector>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Foundation.Collections.IVector`1<String>>>
  IIterable_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING = interface(IInspectable)
  ['{6441120A-4821-5FC2-B799-83E7E4D321B4}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IVector_1__HSTRING; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Pickers.FileExtensionVector>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IMapView_2__HSTRING__IVector_1__HSTRING = interface(IInspectable)
  ['{43BC4657-4309-5A06-8143-D62AB5ADC4FA}']
    function Lookup(key: HSTRING): IVector_1__HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IVector_1__HSTRING; out second: IMapView_2__HSTRING__IVector_1__HSTRING); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMap`2<String,Windows.Foundation.Collections.IVector`1<String>>
  IMap_2__HSTRING__IVector_1__HSTRING = interface(IInspectable)
  ['{E475CA9D-6AFB-5992-993E-53E6EF7A9ECD}']
    function Lookup(key: HSTRING): IVector_1__HSTRING; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    function GetView: IMapView_2__HSTRING__IVector_1__HSTRING; safecall;
    function Insert(key: HSTRING; value: IVector_1__HSTRING): Boolean; safecall;
    procedure Remove(key: HSTRING); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable = interface(IUnknown)
  ['{89981889-1207-5AE6-9B28-CCC58F3AAC6E}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMapView_2__HSTRING__IInspectable; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IAsyncOperation_1__IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{5DCBEE48-9965-51DA-A461-177C885BE7E5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable; safecall;
    function GetResults: IMapView_2__HSTRING__IInspectable; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IInspectable read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IIterator_1__IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{53A2E825-9BF1-5083-8A7B-9D94F312DADE}']
    function get_Current: IMapView_2__HSTRING__IInspectable; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIMapView_2__HSTRING__IInspectable): Cardinal; safecall;
    property Current: IMapView_2__HSTRING__IInspectable read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IIterable_1__IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{E1670FAE-49CD-5C47-A8C8-F6FA2C650C6C}']
    function First: IIterator_1__IMapView_2__HSTRING__IInspectable; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>
  IVectorView_1__IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{172A655B-B3B8-5EAE-BC2E-A6A1F1708B4B}']
    function GetAt(index: Cardinal): IMapView_2__HSTRING__IInspectable; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IMapView_2__HSTRING__IInspectable; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIMapView_2__HSTRING__IInspectable): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = interface(IUnknown)
  ['{A782A13A-16A0-5326-B985-C4CA49E54E77}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IMapView_2__HSTRING__IInspectable; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Foundation.Collections.IMapView`2<String,Object>>>
  IAsyncOperation_1__IVectorView_1__IMapView_2__HSTRING__IInspectable = interface(IInspectable)
  ['{FC227365-219D-5D59-8B5B-58EB0A91CA0A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable; safecall;
    function GetResults: IVectorView_1__IMapView_2__HSTRING__IInspectable; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IMapView_2__HSTRING__IInspectable read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.ApplicationModel.Resources.Core.ResourceQualifierMapView>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<String,String>>
  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING = interface(IUnknown)
  ['{012F1A92-1236-5D03-8643-55E9F2857B77}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMapView_2__HSTRING__HSTRING; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.ApplicationModel.Resources.Core.ResourceQualifierMapView>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<String,String>>
  IAsyncOperation_1__IMapView_2__HSTRING__HSTRING = interface(IInspectable)
  ['{70E59728-8728-5408-A693-D96ED067949B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING; safecall;
    function GetResults: IMapView_2__HSTRING__HSTRING; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__HSTRING read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.PropertySet
  // DualAPI
  // Implements: Windows.Foundation.Collections.IPropertySet
  // Implements: Windows.Foundation.Collections.IObservableMap`2<String,Object>
  // Implements: Windows.Foundation.Collections.IMap`2<String,Object>
  // Implements: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  // Instantiable: "IPropertySet"
  TPropertySet = class(TWinRTGenericImportI<IPropertySet>) end;

  // Windows.Foundation.Collections.StringMap
  // DualAPI
  // Implements: Windows.Foundation.Collections.IMap`2<String,String>
  // Implements: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,String>>
  // Implements: Windows.Foundation.Collections.IObservableMap`2<String,String>
  // Instantiable: "IMap_2__HSTRING__HSTRING"
  TStringMap = class(TWinRTGenericImportI<IMap_2__HSTRING__HSTRING>) end;

  // Windows.Foundation.Collections.ValueSet
  // DualAPI
  // Implements: Windows.Foundation.Collections.IPropertySet
  // Implements: Windows.Foundation.Collections.IObservableMap`2<String,Object>
  // Implements: Windows.Foundation.Collections.IMap`2<String,Object>
  // Implements: Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Object>>
  // Instantiable: "IPropertySet"
  TValueSet = class(TWinRTGenericImportI<IPropertySet>) end;

implementation

{ TPropertySet }

{ TStringMap }

{ TValueSet }

end.
