{*******************************************************}
{                                                       }
{           CodeGear Delphi Runtime Library             }
{                                                       }
{ Copyright(c) 2020-2025 Embarcadero Technologies, Inc. }
{              All rights reserved                      }
{                                                       }
{*******************************************************}

unit Winapi.Storage.Streams;

{$WEAKPACKAGEUNIT OFF}

{$HPPEMIT NOUSINGNAMESPACE}

{$WARN SYMBOL_DEPRECATED OFF}

interface

{$MINENUMSIZE 4}

uses
  Winapi.Windows,
  Winapi.WinRT,
  System.Types,
  System.Win.WinRT,
  Winapi.CommonTypes,
  Winapi.Foundation,
  Winapi.CommonNames;

{$SCOPEDENUMS ON}

type
  // Alias type definitions for types moved from this unit

  AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IMapView_2__HSTRING__IRandomAccessStreamReference;
  AsyncOperationCompletedHandler_1__IRandomAccessStream = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IRandomAccessStream;
  AsyncOperationCompletedHandler_1__IRandomAccessStreamReference = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IRandomAccessStreamReference;
  AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType = Winapi.CommonTypes.AsyncOperationCompletedHandler_1__IRandomAccessStreamWithContentType;
  AsyncOperationProgressHandler_2__IBuffer__Cardinal = Winapi.CommonTypes.AsyncOperationProgressHandler_2__IBuffer__Cardinal;
  AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal = Winapi.CommonTypes.AsyncOperationWithProgressCompletedHandler_2__IBuffer__Cardinal;
  IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference = Winapi.CommonTypes.IAsyncOperation_1__IMapView_2__HSTRING__IRandomAccessStreamReference;
  IAsyncOperation_1__IRandomAccessStream = Winapi.CommonTypes.IAsyncOperation_1__IRandomAccessStream;
  IAsyncOperation_1__IRandomAccessStreamReference = Winapi.CommonTypes.IAsyncOperation_1__IRandomAccessStreamReference;
  IAsyncOperation_1__IRandomAccessStreamWithContentType = Winapi.CommonTypes.IAsyncOperation_1__IRandomAccessStreamWithContentType;
  IAsyncOperationWithProgress_2__IBuffer__Cardinal = Winapi.CommonTypes.IAsyncOperationWithProgress_2__IBuffer__Cardinal;
  IBuffer = Winapi.CommonTypes.IBuffer;
  PIBuffer = Winapi.CommonTypes.PIBuffer;
  IInputStream = Winapi.CommonTypes.IInputStream;
  PIInputStream = Winapi.CommonTypes.PIInputStream;
  IMap_2__HSTRING__IRandomAccessStreamReference = Winapi.CommonTypes.IMap_2__HSTRING__IRandomAccessStreamReference;
  PIMap_2__HSTRING__IRandomAccessStreamReference = Winapi.CommonTypes.PIMap_2__HSTRING__IRandomAccessStreamReference;
  IMapView_2__HSTRING__IRandomAccessStreamReference = Winapi.CommonTypes.IMapView_2__HSTRING__IRandomAccessStreamReference;
  InputStreamOptions = Winapi.CommonTypes.InputStreamOptions;
  PInputStreamOptions = Winapi.CommonTypes.PInputStreamOptions;
  IOutputStream = Winapi.CommonTypes.IOutputStream;
  PIOutputStream = Winapi.CommonTypes.PIOutputStream;
  IRandomAccessStream = Winapi.CommonTypes.IRandomAccessStream;
  PIRandomAccessStream = Winapi.CommonTypes.PIRandomAccessStream;
  IRandomAccessStreamReference = Winapi.CommonTypes.IRandomAccessStreamReference;
  PIRandomAccessStreamReference = Winapi.CommonTypes.PIRandomAccessStreamReference;
  IRandomAccessStreamWithContentType = Winapi.CommonTypes.IRandomAccessStreamWithContentType;
  PIRandomAccessStreamWithContentType = Winapi.CommonTypes.PIRandomAccessStreamWithContentType;

  // Forward declarations for interfaces

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface;
  PIKeyValuePair_2__HSTRING__IRandomAccessStreamReference = ^IKeyValuePair_2__HSTRING__IRandomAccessStreamReference;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  IIterator_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = ^IIterator_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  IIterable_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = ^IIterable_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStream>
  IIterator_1__IRandomAccessStream = interface;
  PIIterator_1__IRandomAccessStream = ^IIterator_1__IRandomAccessStream;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStream>
  IIterable_1__IRandomAccessStream = interface;
  PIIterable_1__IRandomAccessStream = ^IIterable_1__IRandomAccessStream;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStream>
  IVectorView_1__IRandomAccessStream = interface;
  PIVectorView_1__IRandomAccessStream = ^IVectorView_1__IRandomAccessStream;

  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.IRandomAccessStream>
  IVector_1__IRandomAccessStream = interface;
  PIVector_1__IRandomAccessStream = ^IVector_1__IRandomAccessStream;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IBuffer>
  AsyncOperationCompletedHandler_1__IBuffer = interface;
  PAsyncOperationCompletedHandler_1__IBuffer = ^AsyncOperationCompletedHandler_1__IBuffer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IBuffer>
  IAsyncOperation_1__IBuffer = interface;
  PIAsyncOperation_1__IBuffer = ^IAsyncOperation_1__IBuffer;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IInputStream>
  AsyncOperationCompletedHandler_1__IInputStream = interface;
  PAsyncOperationCompletedHandler_1__IInputStream = ^AsyncOperationCompletedHandler_1__IInputStream;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IInputStream>
  IAsyncOperation_1__IInputStream = interface;
  PIAsyncOperation_1__IInputStream = ^IAsyncOperation_1__IInputStream;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IBuffer>
  IIterator_1__IBuffer = interface;
  PIIterator_1__IBuffer = ^IIterator_1__IBuffer;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IBuffer>
  IIterable_1__IBuffer = interface;
  PIIterable_1__IBuffer = ^IIterable_1__IBuffer;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IBuffer>
  IVectorView_1__IBuffer = interface;
  PIVectorView_1__IBuffer = ^IVectorView_1__IBuffer;

  // Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>
  IKeyValuePair_2__Cardinal__IBuffer = interface;
  PIKeyValuePair_2__Cardinal__IBuffer = ^IKeyValuePair_2__Cardinal__IBuffer;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IIterator_1__IKeyValuePair_2__Cardinal__IBuffer = interface;
  PIIterator_1__IKeyValuePair_2__Cardinal__IBuffer = ^IIterator_1__IKeyValuePair_2__Cardinal__IBuffer;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IIterable_1__IKeyValuePair_2__Cardinal__IBuffer = interface;
  PIIterable_1__IKeyValuePair_2__Cardinal__IBuffer = ^IIterable_1__IKeyValuePair_2__Cardinal__IBuffer;

  // Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>
  IMapView_2__Cardinal__IBuffer = interface;
  PIMapView_2__Cardinal__IBuffer = ^IMapView_2__Cardinal__IBuffer;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>>
  AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer = interface;
  PAsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer = ^AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IAsyncOperation_1__IMapView_2__Cardinal__IBuffer = interface;
  PIAsyncOperation_1__IMapView_2__Cardinal__IBuffer = ^IAsyncOperation_1__IMapView_2__Cardinal__IBuffer;

  // Windows.Foundation.Collections.IMap`2<UInt32,Windows.Storage.Streams.IBuffer>
  IMap_2__Cardinal__IBuffer = interface;
  PIMap_2__Cardinal__IBuffer = ^IMap_2__Cardinal__IBuffer;

  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.IBuffer>
  IVector_1__IBuffer = interface;
  PIVector_1__IBuffer = ^IVector_1__IBuffer;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IOutputStream>
  AsyncOperationCompletedHandler_1__IOutputStream = interface;
  PAsyncOperationCompletedHandler_1__IOutputStream = ^AsyncOperationCompletedHandler_1__IOutputStream;

  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IOutputStream>
  IAsyncOperation_1__IOutputStream = interface;
  PIAsyncOperation_1__IOutputStream = ^IAsyncOperation_1__IOutputStream;

  // Windows.Storage.Streams.IDataReader
  IDataReader = interface;
  PIDataReader = ^IDataReader;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>
  IKeyValuePair_2__HSTRING__IBuffer = interface;
  PIKeyValuePair_2__HSTRING__IBuffer = ^IKeyValuePair_2__HSTRING__IBuffer;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>>
  IIterator_1__IKeyValuePair_2__HSTRING__IBuffer = interface;
  PIIterator_1__IKeyValuePair_2__HSTRING__IBuffer = ^IIterator_1__IKeyValuePair_2__HSTRING__IBuffer;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>>
  IIterable_1__IKeyValuePair_2__HSTRING__IBuffer = interface;
  PIIterable_1__IKeyValuePair_2__HSTRING__IBuffer = ^IIterable_1__IKeyValuePair_2__HSTRING__IBuffer;

  // Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IBuffer>
  IMapView_2__HSTRING__IBuffer = interface;
  PIMapView_2__HSTRING__IBuffer = ^IMapView_2__HSTRING__IBuffer;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IBuffer,UInt64>
  AsyncOperationProgressHandler_2__IBuffer__UInt64 = interface;
  PAsyncOperationProgressHandler_2__IBuffer__UInt64 = ^AsyncOperationProgressHandler_2__IBuffer__UInt64;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IBuffer,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64 = interface;
  PAsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64 = ^AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IBuffer,UInt64>
  IAsyncOperationWithProgress_2__IBuffer__UInt64 = interface;
  PIAsyncOperationWithProgress_2__IBuffer__UInt64 = ^IAsyncOperationWithProgress_2__IBuffer__UInt64;

  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IInputStream,UInt64>
  AsyncOperationProgressHandler_2__IInputStream__UInt64 = interface;
  PAsyncOperationProgressHandler_2__IInputStream__UInt64 = ^AsyncOperationProgressHandler_2__IInputStream__UInt64;

  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IInputStream,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64 = interface;
  PAsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64 = ^AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64;

  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IInputStream,UInt64>
  IAsyncOperationWithProgress_2__IInputStream__UInt64 = interface;
  PIAsyncOperationWithProgress_2__IInputStream__UInt64 = ^IAsyncOperationWithProgress_2__IInputStream__UInt64;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IIterator_1__IRandomAccessStreamWithContentType = interface;
  PIIterator_1__IRandomAccessStreamWithContentType = ^IIterator_1__IRandomAccessStreamWithContentType;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IIterable_1__IRandomAccessStreamWithContentType = interface;
  PIIterable_1__IRandomAccessStreamWithContentType = ^IIterable_1__IRandomAccessStreamWithContentType;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IVectorView_1__IRandomAccessStreamWithContentType = interface;
  PIVectorView_1__IRandomAccessStreamWithContentType = ^IVectorView_1__IRandomAccessStreamWithContentType;

  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType = interface;
  PAsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType = ^AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType;

  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>>
  IAsyncOperation_1__IVectorView_1__IRandomAccessStreamWithContentType = interface;
  PIAsyncOperation_1__IVectorView_1__IRandomAccessStreamWithContentType = ^IAsyncOperation_1__IVectorView_1__IRandomAccessStreamWithContentType;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IIterator_1__IRandomAccessStreamReference = interface;
  PIIterator_1__IRandomAccessStreamReference = ^IIterator_1__IRandomAccessStreamReference;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IIterable_1__IRandomAccessStreamReference = interface;
  PIIterable_1__IRandomAccessStreamReference = ^IIterable_1__IRandomAccessStreamReference;

  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IVectorView_1__IRandomAccessStreamReference = interface;
  PIVectorView_1__IRandomAccessStreamReference = ^IVectorView_1__IRandomAccessStreamReference;

  // Windows.Storage.Streams.IBufferFactory
  IBufferFactory = interface;
  PIBufferFactory = ^IBufferFactory;

  // Windows.Storage.Streams.IBufferStatics
  IBufferStatics = interface;
  PIBufferStatics = ^IBufferStatics;

  // Windows.Storage.Streams.IDataReaderFactory
  IDataReaderFactory = interface;
  PIDataReaderFactory = ^IDataReaderFactory;

  // Windows.Storage.Streams.IDataReaderStatics
  IDataReaderStatics = interface;
  PIDataReaderStatics = ^IDataReaderStatics;

  // Windows.Storage.Streams.IDataWriter
  IDataWriter = interface;
  PIDataWriter = ^IDataWriter;

  // Windows.Storage.Streams.IDataWriterFactory
  IDataWriterFactory = interface;
  PIDataWriterFactory = ^IDataWriterFactory;

  // Windows.Storage.Streams.IInputStreamReference
  IInputStreamReference = interface;
  PIInputStreamReference = ^IInputStreamReference;

  // Windows.Storage.Streams.IPropertySetSerializer
  IPropertySetSerializer = interface;
  PIPropertySetSerializer = ^IPropertySetSerializer;

  // Windows.Storage.Streams.IRandomAccessStreamReferenceStatics
  IRandomAccessStreamReferenceStatics = interface;
  PIRandomAccessStreamReferenceStatics = ^IRandomAccessStreamReferenceStatics;

  // Windows.Storage.Streams Enums

  // Windows.Storage.Streams.ByteOrder
  ByteOrder = (
    LittleEndian = 0,
    BigEndian = 1
  );
  PByteOrder = ^ByteOrder;

  // Windows.Storage.Streams.FileOpenDisposition
  FileOpenDisposition = (
    OpenExisting = 0,
    OpenAlways = 1,
    CreateNew = 2,
    CreateAlways = 3,
    TruncateExisting = 4
  );
  PFileOpenDisposition = ^FileOpenDisposition;

  // Windows.Storage.Streams.UnicodeEncoding
  UnicodeEncoding = (
    Utf8 = 0,
    Utf16LE = 1,
    Utf16BE = 2
  );
  PUnicodeEncoding = ^UnicodeEncoding;

  // Windows.Storage.Streams Interfaces

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>
  IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{02C75FC1-0806-5B2B-A690-DA0F3E03EF45}']
    function get_Key: HSTRING; safecall;
    function get_Value: IRandomAccessStreamReference; safecall;
    property Key: HSTRING read get_Key;
    property Value: IRandomAccessStreamReference read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.TargetedContentFile>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  IIterator_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{FCD5C86F-07E0-5913-A023-B8A898D869F9}']
    function get_Current: IKeyValuePair_2__HSTRING__IRandomAccessStreamReference; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IRandomAccessStreamReference): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IRandomAccessStreamReference read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Services.TargetedContent.TargetedContentFile>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IRandomAccessStreamReference>>
  IIterable_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference = interface(IInspectable)
  ['{3E3C7C86-0B46-5FF2-A85F-CDF917CF56FD}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IRandomAccessStreamReference; safecall;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.FileRandomAccessStream>
  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStream>
  IIterator_1__IRandomAccessStream = interface(IInspectable)
  ['{928144C1-3E5A-54F0-8AA6-CEF352290E33}']
    function get_Current: IRandomAccessStream; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIRandomAccessStream): Cardinal; safecall;
    property Current: IRandomAccessStream read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.FileRandomAccessStream>
  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStream>
  IIterable_1__IRandomAccessStream = interface(IInspectable)
  ['{E92DC1B4-2577-59B7-8B4C-4DF35FF0AE61}']
    function First: IIterator_1__IRandomAccessStream; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStream>
  IVectorView_1__IRandomAccessStream = interface(IInspectable)
  ['{92CD0A46-2266-5CD6-9293-E111299F2793}']
    function GetAt(index: Cardinal): IRandomAccessStream; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IRandomAccessStream; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIRandomAccessStream): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.FileRandomAccessStream>
  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.IRandomAccessStream>
  IVector_1__IRandomAccessStream = interface(IInspectable)
  ['{4DB31225-E4BF-5170-AE9C-BBA582659316}']
    function GetAt(index: Cardinal): IRandomAccessStream; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IRandomAccessStream; safecall;
    function IndexOf(value: IRandomAccessStream; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IRandomAccessStream); safecall;
    procedure InsertAt(index: Cardinal; value: IRandomAccessStream); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IRandomAccessStream); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIRandomAccessStream): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIRandomAccessStream); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.Buffer>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IBuffer>
  AsyncOperationCompletedHandler_1__IBuffer = interface(IUnknown)
  ['{C61F4F87-0899-532E-BB03-5548626176BD}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IBuffer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.Buffer>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IBuffer>
  IAsyncOperation_1__IBuffer = interface(IInspectable)
  ['{C28C7EEE-2B20-5F75-B92E-48CFFC3EFA2A}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IBuffer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IBuffer; safecall;
    function GetResults: IBuffer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IBuffer read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.FileInputStream>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IInputStream>
  AsyncOperationCompletedHandler_1__IInputStream = interface(IUnknown)
  ['{2C48DDFC-8F3F-5D8A-BFC1-7D35E22C319F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IInputStream; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.FileInputStream>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IInputStream>
  IAsyncOperation_1__IInputStream = interface(IInspectable)
  ['{EF884D45-7C4B-5CEF-98C1-349AFC1DC3D5}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IInputStream); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IInputStream; safecall;
    function GetResults: IInputStream; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IInputStream read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.Buffer>
  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IBuffer>
  IIterator_1__IBuffer = interface(IInspectable)
  ['{22D9080A-F5FF-550F-BCD4-0E11E25AE1B2}']
    function get_Current: IBuffer; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIBuffer): Cardinal; safecall;
    property Current: IBuffer read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.Buffer>
  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IBuffer>
  IIterable_1__IBuffer = interface(IInspectable)
  ['{DC8B9D9C-EE3B-5292-BFB0-5D77BEC05076}']
    function First: IIterator_1__IBuffer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IBuffer>
  IVectorView_1__IBuffer = interface(IInspectable)
  ['{FD944562-11D6-5EAB-BD72-701993B68FAC}']
    function GetAt(index: Cardinal): IBuffer; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IBuffer; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIBuffer): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>
  IKeyValuePair_2__Cardinal__IBuffer = interface(IInspectable)
  ['{82A3A3B7-E04A-5395-8487-7F94F1508CE7}']
    function get_Key: Cardinal; safecall;
    function get_Value: IBuffer; safecall;
    property Key: Cardinal read get_Key;
    property Value: IBuffer read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IIterator_1__IKeyValuePair_2__Cardinal__IBuffer = interface(IInspectable)
  ['{39FD3369-806B-57A2-B93D-18A6068E99B1}']
    function get_Current: IKeyValuePair_2__Cardinal__IBuffer; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__Cardinal__IBuffer): Cardinal; safecall;
    property Current: IKeyValuePair_2__Cardinal__IBuffer read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IIterable_1__IKeyValuePair_2__Cardinal__IBuffer = interface(IInspectable)
  ['{73BD03D8-EEDA-5D67-A031-A98DB498EFB2}']
    function First: IIterator_1__IKeyValuePair_2__Cardinal__IBuffer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.Buffer>
  // Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>
  IMapView_2__Cardinal__IBuffer = interface(IInspectable)
  ['{2D039569-7A61-5984-8A97-1B96BF362359}']
    function Lookup(key: Cardinal): IBuffer; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: Cardinal): Boolean; safecall;
    procedure Split(out first: IMapView_2__Cardinal__IBuffer; out second: IMapView_2__Cardinal__IBuffer); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>>
  AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer = interface(IUnknown)
  ['{58A24F8C-BCA1-5048-A659-5444A2C4721F}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IMapView_2__Cardinal__IBuffer; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IMapView`2<UInt32,Windows.Storage.Streams.IBuffer>>
  IAsyncOperation_1__IMapView_2__Cardinal__IBuffer = interface(IInspectable)
  ['{6E43B5E6-7784-54F8-B1D5-F37B42DE885B}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer; safecall;
    function GetResults: IMapView_2__Cardinal__IBuffer; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IMapView_2__Cardinal__IBuffer read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMap`2<UInt32,Windows.Storage.Streams.IBuffer>
  IMap_2__Cardinal__IBuffer = interface(IInspectable)
  ['{5D2591DF-48C5-5734-9EF1-BD639B032007}']
    function Lookup(key: Cardinal): IBuffer; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: Cardinal): Boolean; safecall;
    function GetView: IMapView_2__Cardinal__IBuffer; safecall;
    function Insert(key: Cardinal; value: IBuffer): Boolean; safecall;
    procedure Remove(key: Cardinal); safecall;
    procedure Clear; safecall;
    property Size: Cardinal read get_Size;
  end;

  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.Buffer>
  // Windows.Foundation.Collections.IVector`1<Windows.Storage.Streams.IBuffer>
  IVector_1__IBuffer = interface(IInspectable)
  ['{19B92A28-30D8-5FCA-B5E8-2A41D0BF21F8}']
    function GetAt(index: Cardinal): IBuffer; safecall;
    function get_Size: Cardinal; safecall;
    function GetView: IVectorView_1__IBuffer; safecall;
    function IndexOf(value: IBuffer; out index: Cardinal): Boolean; safecall;
    procedure SetAt(index: Cardinal; value: IBuffer); safecall;
    procedure InsertAt(index: Cardinal; value: IBuffer); safecall;
    procedure RemoveAt(index: Cardinal); safecall;
    procedure Append(value: IBuffer); safecall;
    procedure RemoveAtEnd; safecall;
    procedure Clear; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIBuffer): Cardinal; safecall;
    procedure ReplaceAll(itemsSize: Cardinal; items: PIBuffer); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.StreamedFileDataRequest>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Storage.Streams.IOutputStream>
  AsyncOperationCompletedHandler_1__IOutputStream = interface(IUnknown)
  ['{023C7E1C-C8F7-5CCD-A7D9-E8683EDAB905}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IOutputStream; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.StreamedFileDataRequest>
  // Windows.Foundation.IAsyncOperation`1<Windows.Storage.Streams.IOutputStream>
  IAsyncOperation_1__IOutputStream = interface(IInspectable)
  ['{63DC3F5F-E345-5583-9456-919D40E69AAE}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IOutputStream); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IOutputStream; safecall;
    function GetResults: IOutputStream; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IOutputStream read get_Completed write put_Completed;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IDataReader
  [WinRTClassNameAttribute(SWindows_Storage_Streams_DataReader)]
  IDataReader = interface(IInspectable)
  ['{E2B50029-B4C1-4314-A4B8-FB813A2F275E}']
    function get_UnconsumedBufferLength: Cardinal; safecall;
    function get_UnicodeEncoding: UnicodeEncoding; safecall;
    procedure put_UnicodeEncoding(value: UnicodeEncoding); safecall;
    function get_ByteOrder: ByteOrder; safecall;
    procedure put_ByteOrder(value: ByteOrder); safecall;
    function get_InputStreamOptions: InputStreamOptions; safecall;
    procedure put_InputStreamOptions(value: InputStreamOptions); safecall;
    function ReadByte: Byte; safecall;
    procedure ReadBytes(valueSize: Cardinal; value: PByte); safecall;
    function ReadBuffer(length: Cardinal): IBuffer; safecall;
    function ReadBoolean: Boolean; safecall;
    function ReadGuid: TGuid; safecall;
    function ReadInt16: SmallInt; safecall;
    function ReadInt32: Integer; safecall;
    function ReadInt64: Int64; safecall;
    function ReadUInt16: Word; safecall;
    function ReadUInt32: Cardinal; safecall;
    function ReadUInt64: UInt64; safecall;
    function ReadSingle: Single; safecall;
    function ReadDouble: Double; safecall;
    function ReadString(codeUnitCount: Cardinal): HSTRING; safecall;
    function ReadDateTime: DateTime; safecall;
    function ReadTimeSpan: TimeSpan; safecall;
    function LoadAsync(count: Cardinal): IAsyncOperation_1__Cardinal; safecall;
    function DetachBuffer: IBuffer; safecall;
    function DetachStream: IInputStream; safecall;
    property ByteOrder_: ByteOrder read get_ByteOrder write put_ByteOrder;
    property InputStreamOptions_: InputStreamOptions read get_InputStreamOptions write put_InputStreamOptions;
    property UnconsumedBufferLength: Cardinal read get_UnconsumedBufferLength;
    property UnicodeEncoding_: UnicodeEncoding read get_UnicodeEncoding write put_UnicodeEncoding;
  end;

  // Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>
  IKeyValuePair_2__HSTRING__IBuffer = interface(IInspectable)
  ['{9114F794-2CEB-5B03-9B22-36884E1F58B3}']
    function get_Key: HSTRING; safecall;
    function get_Value: IBuffer; safecall;
    property Key: HSTRING read get_Key;
    property Value: IBuffer read get_Value;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.Collections.IIterator`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>>
  IIterator_1__IKeyValuePair_2__HSTRING__IBuffer = interface(IInspectable)
  ['{5516400B-05D3-5C9B-816B-1317421A6022}']
    function get_Current: IKeyValuePair_2__HSTRING__IBuffer; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIKeyValuePair_2__HSTRING__IBuffer): Cardinal; safecall;
    property Current: IKeyValuePair_2__HSTRING__IBuffer read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.Buffer>>
  // Windows.Foundation.Collections.IIterable`1<Windows.Foundation.Collections.IKeyValuePair`2<String,Windows.Storage.Streams.IBuffer>>
  IIterable_1__IKeyValuePair_2__HSTRING__IBuffer = interface(IInspectable)
  ['{28572633-830C-56B6-B9B2-E5B596D01C98}']
    function First: IIterator_1__IKeyValuePair_2__HSTRING__IBuffer; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.Buffer>
  // Windows.Foundation.Collections.IMapView`2<String,Windows.Storage.Streams.IBuffer>
  IMapView_2__HSTRING__IBuffer = interface(IInspectable)
  ['{C8F27D3F-91C8-53A2-B3AC-0DA61BA70717}']
    function Lookup(key: HSTRING): IBuffer; safecall;
    function get_Size: Cardinal; safecall;
    function HasKey(key: HSTRING): Boolean; safecall;
    procedure Split(out first: IMapView_2__HSTRING__IBuffer; out second: IMapView_2__HSTRING__IBuffer); safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.Buffer,UInt64>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IBuffer,UInt64>
  AsyncOperationProgressHandler_2__IBuffer__UInt64 = interface(IUnknown)
  ['{B53A6D84-0D58-50F1-B1CB-995CACF25AD9}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IBuffer__UInt64; progressInfo: UInt64); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.Buffer,UInt64>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IBuffer,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64 = interface(IUnknown)
  ['{7D296BF1-ADAD-5C71-84ED-6525565F042E}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IBuffer__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.Buffer,UInt64>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IBuffer,UInt64>
  IAsyncOperationWithProgress_2__IBuffer__UInt64 = interface(IInspectable)
  ['{C5F965E4-7A35-58BD-8EBF-398FA8E62C73}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__IBuffer__UInt64); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__IBuffer__UInt64; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64; safecall;
    function GetResults: IBuffer; safecall;
    property Progress: AsyncOperationProgressHandler_2__IBuffer__UInt64 read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__IBuffer__UInt64 read get_Completed write put_Completed;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.FileInputStream,UInt64>
  // Windows.Foundation.AsyncOperationProgressHandler`2<Windows.Storage.Streams.IInputStream,UInt64>
  AsyncOperationProgressHandler_2__IInputStream__UInt64 = interface(IUnknown)
  ['{6A9F728E-4833-558A-A695-941718A3A70D}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IInputStream__UInt64; progressInfo: UInt64); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.FileInputStream,UInt64>
  // Windows.Foundation.AsyncOperationWithProgressCompletedHandler`2<Windows.Storage.Streams.IInputStream,UInt64>
  AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64 = interface(IUnknown)
  ['{297D4923-D62E-58B3-93D5-96620D3E5CB6}']
    procedure Invoke(asyncInfo: IAsyncOperationWithProgress_2__IInputStream__UInt64; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.FileInputStream,UInt64>
  // Windows.Foundation.IAsyncOperationWithProgress`2<Windows.Storage.Streams.IInputStream,UInt64>
  IAsyncOperationWithProgress_2__IInputStream__UInt64 = interface(IInspectable)
  ['{47DCC7A2-5A59-5131-A78C-79D20D759066}']
    procedure put_Progress(handler: AsyncOperationProgressHandler_2__IInputStream__UInt64); safecall;
    function get_Progress: AsyncOperationProgressHandler_2__IInputStream__UInt64; safecall;
    procedure put_Completed(handler: AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64); safecall;
    function get_Completed: AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64; safecall;
    function GetResults: IInputStream; safecall;
    property Progress: AsyncOperationProgressHandler_2__IInputStream__UInt64 read get_Progress write put_Progress;
    property Completed: AsyncOperationWithProgressCompletedHandler_2__IInputStream__UInt64 read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.FileProperties.StorageItemThumbnail>
  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IIterator_1__IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{5CDB391C-D466-56DB-B800-03875667E7A1}']
    function get_Current: IRandomAccessStreamWithContentType; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIRandomAccessStreamWithContentType): Cardinal; safecall;
    property Current: IRandomAccessStreamWithContentType read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.FileProperties.StorageItemThumbnail>
  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IIterable_1__IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{CD2C6C03-5F04-52AA-A38D-744C6CC68CB2}']
    function First: IIterator_1__IRandomAccessStreamWithContentType; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>
  IVectorView_1__IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{20A82375-0F34-55AF-AE7E-AE77BC3D542F}']
    function GetAt(index: Cardinal): IRandomAccessStreamWithContentType; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IRandomAccessStreamWithContentType; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIRandomAccessStreamWithContentType): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // UsedAPI Interface
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.FileProperties.StorageItemThumbnail>>
  // Windows.Foundation.AsyncOperationCompletedHandler`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>>
  AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType = interface(IUnknown)
  ['{5523C9AB-FD61-5863-B264-88A3A098DE4C}']
    procedure Invoke(asyncInfo: IAsyncOperation_1__IVectorView_1__IRandomAccessStreamWithContentType; asyncStatus: AsyncStatus); safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.FileProperties.StorageItemThumbnail>>
  // Windows.Foundation.IAsyncOperation`1<Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamWithContentType>>
  IAsyncOperation_1__IVectorView_1__IRandomAccessStreamWithContentType = interface(IInspectable)
  ['{A519B496-149C-575C-B3E1-A2121C83A242}']
    procedure put_Completed(handler: AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType); safecall;
    function get_Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType; safecall;
    function GetResults: IVectorView_1__IRandomAccessStreamWithContentType; safecall;
    property Completed: AsyncOperationCompletedHandler_1__IVectorView_1__IRandomAccessStreamWithContentType read get_Completed write put_Completed;
  end;

  // Windows.Foundation.Collections.IIterator`1<Windows.Services.TargetedContent.TargetedContentFile>
  // Windows.Foundation.Collections.IIterator`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IIterator_1__IRandomAccessStreamReference = interface(IInspectable)
  ['{6A957F20-ED25-5019-90E7-9890D4F912F2}']
    function get_Current: IRandomAccessStreamReference; safecall;
    function get_HasCurrent: Boolean; safecall;
    function MoveNext: Boolean; safecall;
    function GetMany(itemsSize: Cardinal; items: PIRandomAccessStreamReference): Cardinal; safecall;
    property Current: IRandomAccessStreamReference read get_Current;
    property HasCurrent: Boolean read get_HasCurrent;
  end;

  // Windows.Foundation.Collections.IIterable`1<Windows.Services.TargetedContent.TargetedContentFile>
  // Windows.Foundation.Collections.IIterable`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IIterable_1__IRandomAccessStreamReference = interface(IInspectable)
  ['{5F65D649-CCBD-5728-A85B-D3FF92FCA962}']
    function First: IIterator_1__IRandomAccessStreamReference; safecall;
  end;

  // UsedAPI Interface
  // Windows.Foundation.Collections.IVectorView`1<Windows.Storage.Streams.IRandomAccessStreamReference>
  IVectorView_1__IRandomAccessStreamReference = interface(IInspectable)
  ['{4D904A36-6418-5C09-A622-A1CC8C27EEFF}']
    function GetAt(index: Cardinal): IRandomAccessStreamReference; safecall;
    function get_Size: Cardinal; safecall;
    function IndexOf(value: IRandomAccessStreamReference; out index: Cardinal): Boolean; safecall;
    function GetMany(startIndex: Cardinal; itemsSize: Cardinal; items: PIRandomAccessStreamReference): Cardinal; safecall;
    property Size: Cardinal read get_Size;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IBufferFactory
  [WinRTClassNameAttribute(SWindows_Storage_Streams_Buffer)]
  IBufferFactory = interface(IInspectable)
  ['{71AF914D-C10F-484B-BC50-14BC623B3A27}']
    function Create(capacity: Cardinal): IBuffer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IBufferStatics
  [WinRTClassNameAttribute(SWindows_Storage_Streams_Buffer)]
  IBufferStatics = interface(IInspectable)
  ['{E901E65B-D716-475A-A90A-AF7229B1E741}']
    function CreateCopyFromMemoryBuffer(input: IMemoryBuffer): IBuffer; safecall;
    function CreateMemoryBufferOverIBuffer(input: IBuffer): IMemoryBuffer; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IDataReaderFactory
  [WinRTClassNameAttribute(SWindows_Storage_Streams_DataReader)]
  IDataReaderFactory = interface(IInspectable)
  ['{D7527847-57DA-4E15-914C-06806699A098}']
    function CreateDataReader(inputStream: IInputStream): IDataReader; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IDataReaderStatics
  [WinRTClassNameAttribute(SWindows_Storage_Streams_DataReader)]
  IDataReaderStatics = interface(IInspectable)
  ['{11FCBFC8-F93A-471B-B121-F379E349313C}']
    function FromBuffer(buffer: IBuffer): IDataReader; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IDataWriter
  [WinRTClassNameAttribute(SWindows_Storage_Streams_DataWriter)]
  IDataWriter = interface(IInspectable)
  ['{64B89265-D341-4922-B38A-DD4AF8808C4E}']
    function get_UnstoredBufferLength: Cardinal; safecall;
    function get_UnicodeEncoding: UnicodeEncoding; safecall;
    procedure put_UnicodeEncoding(value: UnicodeEncoding); safecall;
    function get_ByteOrder: ByteOrder; safecall;
    procedure put_ByteOrder(value: ByteOrder); safecall;
    procedure WriteByte(value: Byte); safecall;
    procedure WriteBytes(valueSize: Cardinal; value: PByte); safecall;
    procedure WriteBuffer(buffer: IBuffer); overload; safecall;
    procedure WriteBuffer(buffer: IBuffer; start: Cardinal; count: Cardinal); overload; safecall;
    procedure WriteBoolean(value: Boolean); safecall;
    procedure WriteGuid(value: TGuid); safecall;
    procedure WriteInt16(value: SmallInt); safecall;
    procedure WriteInt32(value: Integer); safecall;
    procedure WriteInt64(value: Int64); safecall;
    procedure WriteUInt16(value: Word); safecall;
    procedure WriteUInt32(value: Cardinal); safecall;
    procedure WriteUInt64(value: UInt64); safecall;
    procedure WriteSingle(value: Single); safecall;
    procedure WriteDouble(value: Double); safecall;
    procedure WriteDateTime(value: DateTime); safecall;
    procedure WriteTimeSpan(value: TimeSpan); safecall;
    function WriteString(value: HSTRING): Cardinal; safecall;
    function MeasureString(value: HSTRING): Cardinal; safecall;
    function StoreAsync: IAsyncOperation_1__Cardinal; safecall;
    function FlushAsync: IAsyncOperation_1__Boolean; safecall;
    function DetachBuffer: IBuffer; safecall;
    function DetachStream: IOutputStream; safecall;
    property ByteOrder_: ByteOrder read get_ByteOrder write put_ByteOrder;
    property UnicodeEncoding_: UnicodeEncoding read get_UnicodeEncoding write put_UnicodeEncoding;
    property UnstoredBufferLength: Cardinal read get_UnstoredBufferLength;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IDataWriterFactory
  [WinRTClassNameAttribute(SWindows_Storage_Streams_DataWriter)]
  IDataWriterFactory = interface(IInspectable)
  ['{338C67C2-8B84-4C2B-9C50-7B8767847A1F}']
    function CreateDataWriter(outputStream: IOutputStream): IDataWriter; safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IInputStreamReference
  IInputStreamReference = interface(IInspectable)
  ['{43929D18-5EC9-4B5A-919C-4205B0C804B6}']
    function OpenSequentialReadAsync: IAsyncOperation_1__IInputStream; safecall;
  end;

  // Windows.Storage.Streams.IPropertySetSerializer
  IPropertySetSerializer = interface(IInspectable)
  ['{6E8EBF1C-EF3D-4376-B20E-5BE638AEAC77}']
    function Serialize(propertySet: IPropertySet): IBuffer; safecall;
    procedure Deserialize(propertySet: IPropertySet; buffer: IBuffer); safecall;
  end;

  // DualAPI Interface
  // UsedAPI Interface
  // Windows.Storage.Streams.IRandomAccessStreamReferenceStatics
  [WinRTClassNameAttribute(SWindows_Storage_Streams_RandomAccessStreamReference)]
  IRandomAccessStreamReferenceStatics = interface(IInspectable)
  ['{857309DC-3FBF-4E7D-986F-EF3B1A07A964}']
    function CreateFromFile(&file: IStorageFile): IRandomAccessStreamReference; safecall;
    function CreateFromUri(uri: IUriRuntimeClass): IRandomAccessStreamReference; safecall;
    function CreateFromStream(stream: IRandomAccessStream): IRandomAccessStreamReference; safecall;
  end;

  // Windows.Storage.Streams.Buffer
  // DualAPI
  // Implements: Windows.Storage.Streams.IBuffer
  // Statics: "Windows.Storage.Streams.IBufferStatics"
  // Factory: "Windows.Storage.Streams.IBufferFactory"
  TBuffer = class(TWinRTGenericImportFS<IBufferFactory, IBufferStatics>)
  public
    {$REGION 'IBufferStatics'}
    class function CreateCopyFromMemoryBuffer(input: IMemoryBuffer): IBuffer; static; inline;
    class function CreateMemoryBufferOverIBuffer(input: IBuffer): IMemoryBuffer; static; inline;
    {$ENDREGION}
    {$REGION 'IBufferFactory'}
    class function Create(capacity: Cardinal): IBuffer; static; inline;
    {$ENDREGION}
 end;

  // Windows.Storage.Streams.DataReader
  // DualAPI
  // Explicitly imported
  // Implements: Windows.Storage.Streams.IDataReader
  // Implements: Windows.Foundation.IClosable
  // Statics: "Windows.Storage.Streams.IDataReaderStatics"
  // Factory: "Windows.Storage.Streams.IDataReaderFactory"
  TDataReader = class(TWinRTGenericImportFS<IDataReaderFactory, IDataReaderStatics>)
  public
    {$REGION 'IDataReaderStatics'}
    class function FromBuffer(buffer: IBuffer): IDataReader; static; inline;
    {$ENDREGION}
    {$REGION 'IDataReaderFactory'}
    class function CreateDataReader(inputStream: IInputStream): IDataReader; static; inline;
    {$ENDREGION}
 end;

  // Windows.Storage.Streams.DataWriter
  // DualAPI
  // Explicitly imported
  // Implements: Windows.Storage.Streams.IDataWriter
  // Implements: Windows.Foundation.IClosable
  // Factory: "Windows.Storage.Streams.IDataWriterFactory"
  // Instantiable: "IDataWriter"
  TDataWriter = class(TWinRTGenericImportFI<IDataWriterFactory, IDataWriter>)
  public
    {$REGION 'IDataWriterFactory'}
    class function CreateDataWriter(outputStream: IOutputStream): IDataWriter; static; inline;
    {$ENDREGION}
 end;

  // Windows.Storage.Streams.RandomAccessStreamReference
  // Explicitly imported
  // Implements: Windows.Storage.Streams.IRandomAccessStreamReference
  // Statics: "Windows.Storage.Streams.IRandomAccessStreamReferenceStatics"
  TRandomAccessStreamReference = class(TWinRTGenericImportS<IRandomAccessStreamReferenceStatics>)
  public
    {$REGION 'IRandomAccessStreamReferenceStatics'}
    class function CreateFromFile(&file: IStorageFile): IRandomAccessStreamReference; static; inline;
    class function CreateFromUri(uri: IUriRuntimeClass): IRandomAccessStreamReference; static; inline;
    class function CreateFromStream(stream: IRandomAccessStream): IRandomAccessStreamReference; static; inline;
    {$ENDREGION}
 end;

implementation

{ TBuffer }

{$REGION 'Windows.Storage.Streams.IBufferStatics'}
class function TBuffer.CreateCopyFromMemoryBuffer(input: IMemoryBuffer): IBuffer;
begin
  Result := Statics.CreateCopyFromMemoryBuffer(input);
end;

class function TBuffer.CreateMemoryBufferOverIBuffer(input: IBuffer): IMemoryBuffer;
begin
  Result := Statics.CreateMemoryBufferOverIBuffer(input);
end;
{$ENDREGION}

{$REGION 'Windows.Storage.Streams.IBufferFactory'}
// Factory: "Windows.Storage.Streams.IBufferFactory"
// -> IBufferFactory

class function TBuffer.Create(capacity: Cardinal): IBuffer;
begin
  Result := Factory.Create(capacity);
end;
{$ENDREGION}

{ TDataReader }

{$REGION 'Windows.Storage.Streams.IDataReaderStatics'}
class function TDataReader.FromBuffer(buffer: IBuffer): IDataReader;
begin
  Result := Statics.FromBuffer(buffer);
end;
{$ENDREGION}

{$REGION 'Windows.Storage.Streams.IDataReaderFactory'}
// Factory: "Windows.Storage.Streams.IDataReaderFactory"
// -> IDataReaderFactory

class function TDataReader.CreateDataReader(inputStream: IInputStream): IDataReader;
begin
  Result := Factory.CreateDataReader(inputStream);
end;
{$ENDREGION}

{ TDataWriter }

{$REGION 'Windows.Storage.Streams.IDataWriterFactory'}
// Factory: "Windows.Storage.Streams.IDataWriterFactory"
// -> IDataWriterFactory

class function TDataWriter.CreateDataWriter(outputStream: IOutputStream): IDataWriter;
begin
  Result := Factory.CreateDataWriter(outputStream);
end;
{$ENDREGION}

{ TRandomAccessStreamReference }

{$REGION 'Windows.Storage.Streams.IRandomAccessStreamReferenceStatics'}
class function TRandomAccessStreamReference.CreateFromFile(&file: IStorageFile): IRandomAccessStreamReference;
begin
  Result := Statics.CreateFromFile(&file);
end;

class function TRandomAccessStreamReference.CreateFromUri(uri: IUriRuntimeClass): IRandomAccessStreamReference;
begin
  Result := Statics.CreateFromUri(uri);
end;

class function TRandomAccessStreamReference.CreateFromStream(stream: IRandomAccessStream): IRandomAccessStreamReference;
begin
  Result := Statics.CreateFromStream(stream);
end;
{$ENDREGION}

end.
